#!/bin/sh
[ -d /usr/camscript ] || mkdir -p /usr/camscript;

oscam=/usr/bin
script=/usr/camscript

echo "En yeni OSCam alınıyor"
	www="http://oscam.dreamosat.net/index.php?&direction=0&order=mod&directory=1.20_TRUNK/mips-tuxbox-oe2.0&"
	wget $www -q -O /tmp/oscam.info
	version=$(cat /tmp/oscam.info | grep -A 32 "archives" | grep "mipsoe20-webif-oscam-emu-patched.tar.gz"|sed 's/[ ][ ]*/'/g''|cut -b 35-39)
	LINK='http://oscam.dreamosat.net/index.php?action=downloadfile&filename=oscam-svn'$version'-mipsoe20-webif-oscam-emu-patched.tar.gz&directory=1.20_TRUNK/mips-tuxbox-oe2.0&'
echo "Kopyalanıyor OSCam_$version"
	wget $LINK -q -O /tmp/OscamUpdate-audi06_19.tar.gz
	tar -xzf /tmp/OscamUpdate-audi06_19.tar.gz -C /tmp/
	[ -e /tmp/*-arm_dream-list_smargo ] && rm /tmp/*-arm_dream-list_smargo
	mv /tmp/oscam-svn* /tmp/OSCam_$version
	[ -e /usr/bin/OSCam_$version ] && rm -rf /usr/bin/OSCam_$version
	[ -e /usr/camscript/OSCam_$version ] && rm -rf /usr/camscript/OSCam_$version
echo "Kopyalandı OSCam_$version /usr/bin"
	cp -rf /tmp/OSCam_$version /usr/bin/OSCam_$version
	[ -e /tmp/doc ] && rm -rf /tmp/doc 
	[ -e /tmp/oscam.info ] && rm /tmp/oscam.info 
	[ -e /tmp/OscamUpdate-audi06_19.tar.gz ] && rm /tmp/OscamUpdate-audi06_19.tar.gz 
	[ -e /tmp/OSCam_$version ] && rm /tmp/OSCam_$version
	[ -e /tmp/CHANGES ] && rm /tmp/CHANGES 
	
	
dest="/usr/camscript/OSCam_$version.sh"
echo "Oscam için Script oluşturuluyor "$dest
echo -e "#!/bin/sh" > $dest
echo -e "" >> $dest
echo -e "CAM=\0042OSCam_$version\0042" >> $dest
echo -e "OSD=\0042OSCam r$version\0042" >> $dest
echo -e "PID=\0044CAM" >> $dest
echo -e "Action=\00441" >> $dest
echo -e "" >> $dest
echo -e "cam_clean () {" >> $dest
echo -e "		rm -rf /tmp/*.info*	/tmp/.oscam /tmp/*.pid" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "cam_handle () {" >> $dest
echo -e "		if test	-z \0042\0044{PID}\0042	; then" >> $dest
echo -e "				cam_up;" >> $dest
echo -e "		else" >> $dest
echo -e "				cam_down;" >> $dest
echo -e "		fi;" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "cam_down ()	{" >> $dest
echo -e "		killall	-9 \0044CAM 2>/dev/null" >> $dest
echo -e "		sleep 2" >> $dest
echo -e "		cam_clean" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "cam_up () {" >> $dest
echo -e "		/usr/bin/\0044CAM -c /etc/tuxbox/config/ &" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "if test	\0042\0044Action\0042 =	\0042cam_startup\0042 ;	then" >> $dest
echo -e "	if test	-z \0042\0044{PID}\0042 ; then" >> $dest
echo -e "		cam_down" >> $dest
echo -e "		cam_up" >> $dest
echo -e "	else" >> $dest
echo -e "		echo \0042\0044CAM already running, exiting...\0042" >> $dest
echo -e "	fi" >> $dest
echo -e "elif test	\0042\0044Action\0042 =	\0042cam_res\0042 ;	then" >> $dest
echo -e "		cam_down" >> $dest
echo -e "		cam_up" >> $dest
echo -e "elif test \0042\0044Action\0042	= \0042cam_down\0042 ; then" >> $dest
echo -e "		cam_down" >> $dest
echo -e "elif test \0042\0044Action\0042	= \0042cam_up\0042 ; then" >> $dest
echo -e "		cam_up" >> $dest
echo -e "else" >> $dest
echo -e "		cam_handle" >> $dest
echo -e "fi" >> $dest
echo -e "" >> $dest
echo -e "exit 0" >> $dest
chmod 755 $dest
chmod 755 /usr/bin/OSCam_$version
sleep 1
echo ""
echo "Güncel OSCam r$version indirildi"
echo ""
echo "En Yeni OSCam çalıştırılmaya hazır"
echo ""
echo "... DreamOSat camManager açın ve OSCam r$version çalıştırın..."
echo ""
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1
exit 0
