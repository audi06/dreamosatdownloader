#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com
wget http://depo.dreamosat.net/CaMs-EmU/CCcam/CCcam.cfg -qO /etc/CCcam.cfg;
rm -rf /usr/keys/CCcam.cfg;
cp /etc/CCcam.cfg /usr/keys/;
chmod 0755 /usr/keys/CCcam.cfg -R;
chmod 0755 /etc/CCcam.cfg -R;
echo "";
echo "CCcam.cfg Server güncellendi";
echo "";
echo "DreamOSat camManager Restart Etmeyi Unutmayınız. iyi seyirler...";
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0
