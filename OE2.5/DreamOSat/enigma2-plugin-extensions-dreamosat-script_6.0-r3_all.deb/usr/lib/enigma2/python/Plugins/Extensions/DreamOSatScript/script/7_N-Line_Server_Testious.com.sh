#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com
echo "";
[ -d /usr/keys ] || mkdir -p /usr/keys > /dev/null;

DATUM0=$(date +%Y-%m-%d|awk -vFS="-" -vOFS="-" '{$3=$3;print}')
DATUM1=$(date +%Y-%m-%d|awk -vFS="-" -vOFS="-" '{$3=$3-1;print}')
DATUM2=$(date +%Y-%m-%d|awk -vFS="-" -vOFS="-" '{$3=$3-2;print}')
DATUM3=$(date +%Y-%m-%d|awk -vFS="-" -vOFS="-" '{$3=$3-3;print}')
DATUM4=$(date +%Y-%m-%d|awk -vFS="-" -vOFS="-" '{$3=$3-4;print}')
DATUM5=$(date +%Y-%m-%d|awk -vFS="-" -vOFS="-" '{$3=$3-5;print}')
DATUM6=$(date +%Y-%m-%d|awk -vFS="-" -vOFS="-" '{$3=$3-6;print}')
DATUM7=$(date +%Y-%m-%d|awk -vFS="-" -vOFS="-" '{$3=$3-7;print}')
DATUM8=$(date +%Y-%m-%d|awk -vFS="-" -vOFS="-" '{$3=$3-8;print}')
DATUM9=$(date +%Y-%m-%d|awk -vFS="-" -vOFS="-" '{$3=$3-9;print}')

#CONT=$(grep "CWS =" /usr/keys/newcamd.list) > /dev/null 2>&1
WGET1="https://www.testious.com/free-cccam-servers"
EMU="/usr/keys/newcamd.list"
EMU_CP="/usr/keys/newcamd-1.list"

if grep -qs 'CWS =' cat $EMU ; then
   cp -rd $EMU $EMU_CP > /dev/null 2>&1
   echo "usr keys içerisinden, newcamd.list Yedek alındı..."
   echo "";
else
   echo "usr keys içerisinden, newcamd.list Yedek alınamadı..."
   echo "";
fi

rm -rf $EMU > /dev/null 2>&1

cat > $EMU << EOF
CWS_KEEPALIVE = 300
CWS_INCOMING_PORT = 21000
EOF

chmod 755 $EMU > /dev/null 2>&1

wget --quiet -O -  "$WGET1"  --header="User-Agent: Mozilla/5.0 (Windows NT 5.1; rv:23.0) Gecko/20100101 Firefox/23.0" $WGET1/$DATUM0 | grep -o 'N:[^<]*' >>$EMU
wget --quiet -O -  "$WGET1"  --header="User-Agent: Mozilla/5.0 (Windows NT 5.1; rv:23.0) Gecko/20100101 Firefox/23.0" $WGET1/$DATUM1 | grep -o 'N:[^<]*' >>$EMU
wget --quiet -O -  "$WGET1"  --header="User-Agent: Mozilla/5.0 (Windows NT 5.1; rv:23.0) Gecko/20100101 Firefox/23.0" $WGET1/$DATUM2 | grep -o 'N:[^<]*' >>$EMU
#wget --quiet -O -  "$WGET1"  --header="User-Agent: Mozilla/5.0 (Windows NT 5.1; rv:23.0) Gecko/20100101 Firefox/23.0" $WGET1/$DATUM3 | grep -o 'N:[^<]*' >>$EMU
#wget --quiet -O -  "$WGET1"  --header="User-Agent: Mozilla/5.0 (Windows NT 5.1; rv:23.0) Gecko/20100101 Firefox/23.0" $WGET1/$DATUM4 | grep -o 'N:[^<]*' >>$EMU
#wget --quiet -O -  "$WGET1"  --header="User-Agent: Mozilla/5.0 (Windows NT 5.1; rv:23.0) Gecko/20100101 Firefox/23.0" $WGET1/$DATUM5 | grep -o 'N:[^<]*' >>$EMU
#wget --quiet -O -  "$WGET1"  --header="User-Agent: Mozilla/5.0 (Windows NT 5.1; rv:23.0) Gecko/20100101 Firefox/23.0" $WGET1/$DATUM6 | grep -o 'N:[^<]*' >>$EMU
#wget --quiet -O -  "$WGET1"  --header="User-Agent: Mozilla/5.0 (Windows NT 5.1; rv:23.0) Gecko/20100101 Firefox/23.0" $WGET1/$DATUM7 | grep -o 'N:[^<]*' >>$EMU
#wget --quiet -O -  "$WGET1"  --header="User-Agent: Mozilla/5.0 (Windows NT 5.1; rv:23.0) Gecko/20100101 Firefox/23.0" $WGET1/$DATUM8 | grep -o 'N:[^<]*' >>$EMU
#wget --quiet -O -  "$WGET1"  --header="User-Agent: Mozilla/5.0 (Windows NT 5.1; rv:23.0) Gecko/20100101 Firefox/23.0" $WGET1/$DATUM9 | grep -o 'N:[^<]*' >>$EMU

dos2unix $EMU > /dev/null 2>&1

sed -i '3,122s/^N:/CWS =/g' $EMU > /dev/null 2>&1
sed -i 's/^N:/#N:/g' $EMU > /dev/null 2>&1

echo "";
if grep -qs 'CWS =' cat $EMU ; then
echo "N + Line server (www.testious.com) indirildi, usr keys içerisine yazıldı..."
echo "";
else
      if [ -f /usr/keys/newcamd.list ] ; then
         cp -rd $EMU_CP $EMU
      else
         echo ""
      fi
   echo "Server Off, www.testious.com bağlantı kurulamadı..."
   echo "";
   echo "N + Line server Yedek geri yuklendi..."
fi
echo ""
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 3;
exit 0


