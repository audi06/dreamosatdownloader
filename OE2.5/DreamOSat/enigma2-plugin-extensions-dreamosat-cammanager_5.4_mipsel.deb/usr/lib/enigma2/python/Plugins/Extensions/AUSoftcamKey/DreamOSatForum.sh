#!/bin/sh
echo "*     ..:: B E K L E Y İ N İ Z ::..       *"
[ -d /etc/tuxbox/config/ncam ] || mkdir -p /etc/tuxbox/config/ncam > /dev/null;
[ -d /etc/tuxbox/config/oscamymod ] || mkdir -p /etc/tuxbox/config/oscamymod > /dev/null;
[ -d /etc/tuxbox/config/oscampowervu ] || mkdir -p /etc/tuxbox/config/oscampowervu > /dev/null;
[ -d /usr/keys ] || mkdir -p /usr/keys > /dev/null;
[ -d /tmp/DreamOSat ] || mkdir -p /tmp/DreamOSat > /dev/null;
#keys
wget http://depo.dreamosat-forum.com/CaMs-EmU/readme.txt -qO /tmp/DreamOSat/readme.txt > /dev/null;
wget http://depo.dreamosat-forum.com/CaMs-EmU/SoftCam.Key -qO /tmp/DreamOSat/SoftCam.Key > /dev/null;
wget http://depo.dreamosat-forum.com/CaMs-EmU/constant.cw -qO /tmp/DreamOSat/constant.cw > /dev/null;
wget http://depo.dreamosat-forum.com/CaMs-EmU/CCcam/AutoRoll.Key -qO /tmp/DreamOSat/AutoRoll.Key > /dev/null;
wget http://depo.dreamosat-forum.com/CaMs-EmU/BTKcam/btkcam.cfg -qO /tmp/DreamOSat/btkcam.cfg > /dev/null;
#script
wget http://depo.dreamosat-forum.com/CaMs-EmU/DreamOSatForum.sh -qO /tmp/DreamOSat/DreamOSatForum.sh > /dev/null;
#
chmod 0755 /tmp/DreamOSat/ -R > /dev/null;
#
cd /tmp/DreamOSat > /dev/null;
#
cp -rd DreamOSatForum.sh /usr/lib/enigma2/python/Plugins/Extensions/AUSoftcamKey/ > /dev/null;
cp -rd AutoRoll.Key /usr/keys/ > /dev/null;
cp -rd SoftCam.Key /etc/tuxbox/config/ > /dev/null;
cp -rd SoftCam.Key /etc/tuxbox/config/ncam/ > /dev/null;
cp -rd SoftCam.Key /etc/tuxbox/config/oscampowervu/ > /dev/null;
cp -rd SoftCam.Key /etc/tuxbox/config/oscamymod/ > /dev/null;
cp -rd SoftCam.Key /usr/keys/ > /dev/null;
cp -rd constant.cw /etc/tuxbox/config/ > /dev/null;
cp -rd constant.cw /etc/tuxbox/config/ncam/ > /dev/null;
cp -rd constant.cw /etc/tuxbox/config/oscampowervu/ > /dev/null;
cp -rd constant.cw /etc/tuxbox/config/oscamymod/ > /dev/null;
cp -rd constant.cw /usr/keys/ > /dev/null;
cp -rd btkcam.cfg /usr/keys/ > /dev/null;
#
cd / > /dev/null;
#
more /tmp/DreamOSat/readme.txt;
#
rm /tmp/DreamOSat/readme.txt > /dev/null;
rm -rf /tmp/DreamOSat > /dev/null;
#
echo "";
echo "   www.dreamosat-forum.com   ";
echo "";
KeyDate=`/bin/date -r /usr/keys/SoftCam.Key +%d.%m.%y-%H:%M:%S`
	echo "GÜNCELLEME TARİHİ VE SAATİ: $KeyDate"
sleep 2
exit 0
