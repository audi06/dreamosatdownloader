#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com 2017
FIN="==================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."
echo $FIN
STOP1=$(ps -A | awk '/OSCam*/{print $4}')
STOP2=$(ps -A | awk '/Oscam*/{print $4}')
STOP3=$(ps -A | awk '/oscam*/{print $4}')
sleep 1;
echo ":========> Yüklü OSCamlar Aranıyor..."
echo ":========> OSCam Dosya yolları..."
echo ""
find /usr/bin/ -iname oscam*
echo ""
echo ":========> Çalışan OSCamlar..."
echo ""
sleep 1;
ps -A | awk '/OSCam*/{print $4}'
ps -A | awk '/Oscam*/{print $4}'
ps -A | awk '/oscam*/{print $4}'
sleep 1;
echo ""
echo ":========> Stop"
killall /usr/bin/$STOP1 2>/dev/null
killall /usr/bin/$STOP2 2>/dev/null
killall /usr/bin/$STOP3 2>/dev/null
sleep 1;
##################################################################################################
echo ""
[ -d /tmp/DreamOSat ] || mkdir -p /tmp/DreamOSat > /dev/null;
[ -d /usr/camscript ] || mkdir -p /usr/camscript > /dev/null;
echo ":========> Cihazınızın işlemcisini kontrol ediyorum..."
echo ""
uname -m >> /tmp/DreamOSat/name.txt
sleep 1;
if grep -qs 'armv7l' cat /tmp/DreamOSat/name.txt ; then
	echo ":========> ARM işlemci kullandığınızı tespit ettim... :)"
	www="http://oscam.dreamosat.net/index.php?&direction=0&order=mod&directory=1.20_TRUNK/arm_dm900-solo4k&"
	wget $www -q -O /tmp/oscam.info
	version=$(cat /tmp/oscam.info | grep -A 32 "archives" | grep "arm_dm900-solo4k-webif-oscam-emu-patched.tar.gz"|sed 's/[ ][ ]*/'/g''|cut -b 35-39)
	LINK='http://oscam.dreamosat.net/index.php?action=downloadfile&filename=oscam-svn'$version'-arm_dm900-solo4k-webif-oscam-emu-patched.tar.gz&directory=1.20_TRUNK/arm_dm900-solo4k&'
	echo ""
	echo ":========> Kopyalanıyor ARM OSCam_r$version"
	wget $LINK -q -O /tmp/OscamUpdate-audi06_19.tar.gz
	tar -xzf /tmp/OscamUpdate-audi06_19.tar.gz -C /tmp/ > /dev/null;
	[ -e /tmp/*-arm_dream-list_smargo ] && rm /tmp/*-arm_dream-list_smargo
	mv /tmp/oscam-svn* /tmp/OSCam_r$version
	[ -e /usr/bin/OSCam_r* ] && rm -rf /usr/bin/OSCam_r*
	[ -e /usr/camscript/OSCam_r$version ] && rm -rf /usr/camscript/OSCam_r$version
	echo ""
echo ":========> Kopyalandı ARM OSCam_$version /usr/bin"
	cp -rf /tmp/OSCam_r$version /usr/bin/OSCam_r$version
	[ -e /tmp/doc ] && rm -rf /tmp/doc 
	[ -e /tmp/oscam.info ] && rm /tmp/oscam.info 
	[ -e /tmp/OscamUpdate-audi06_19.tar.gz ] && rm /tmp/OscamUpdate-audi06_19.tar.gz 
	[ -e /tmp/OSCam_r$version ] && rm /tmp/OSCam_r$version
	[ -e /tmp/CHANGES ] && rm /tmp/CHANGES
	[ -e /usr/camscript/OSCam_r* ] && rm -rf /usr/camscript/OSCam_r*
echo ""
dest="/usr/camscript/OSCam_r$version.sh"
echo ":========> OSCam_r$version için Script oluşturuluyor... "$dest
echo -e "#!/bin/sh" > $dest
echo -e "" >> $dest
echo -e "CAM=\0042OSCam_r$version\0042" >> $dest
echo -e "OSD=\0042OSCam r$version\0042" >> $dest
echo -e "PID=\0044CAM" >> $dest
echo -e "Action=\00441" >> $dest
echo -e "" >> $dest
echo -e "cam_clean () {" >> $dest
echo -e "		rm -rf /tmp/*.info*	/tmp/.oscam /tmp/*.pid" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "cam_handle () {" >> $dest
echo -e "		if test	-z \0042\0044{PID}\0042	; then" >> $dest
echo -e "				cam_up;" >> $dest
echo -e "		else" >> $dest
echo -e "				cam_down;" >> $dest
echo -e "		fi;" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "cam_down ()	{" >> $dest
echo -e "		killall	-9 \0044CAM 2>/dev/null" >> $dest
echo -e "		sleep 2" >> $dest
echo -e "		cam_clean" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "cam_up () {" >> $dest
echo -e "		/usr/bin/\0044CAM -c /etc/tuxbox/config/ &" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "if test	\0042\0044Action\0042 =	\0042cam_startup\0042 ;	then" >> $dest
echo -e "	if test	-z \0042\0044{PID}\0042 ; then" >> $dest
echo -e "		cam_down" >> $dest
echo -e "		cam_up" >> $dest
echo -e "	else" >> $dest
echo -e "		echo \0042\0044CAM already running, exiting...\0042" >> $dest
echo -e "	fi" >> $dest
echo -e "elif test	\0042\0044Action\0042 =	\0042cam_res\0042 ;	then" >> $dest
echo -e "		cam_down" >> $dest
echo -e "		cam_up" >> $dest
echo -e "elif test \0042\0044Action\0042	= \0042cam_down\0042 ; then" >> $dest
echo -e "		cam_down" >> $dest
echo -e "elif test \0042\0044Action\0042	= \0042cam_up\0042 ; then" >> $dest
echo -e "		cam_up" >> $dest
echo -e "else" >> $dest
echo -e "		cam_handle" >> $dest
echo -e "fi" >> $dest
echo -e "" >> $dest
echo -e "exit 0" >> $dest
sleep 1
chmod 755 $dest > /dev/null;
chmod 755 /usr/bin/OSCam_r$version > /dev/null;
echo ""
echo ":========> Güncel OSCam r$version indirildi"
echo ""
echo ":========> En Yeni OSCam çalıştırılmaya hazır"
echo ""
echo ":== DİKKAT ==>... DreamOSat camManager açın ve OSCam r$version çalıştırın..."
echo ""
else
uname -m >> /tmp/DreamOSat/name2.txt
sleep 1;
if grep -qs 'mips' cat /tmp/DreamOSat/name2.txt ; then
	echo ":========> Mips işlemci kullandığınızı tespit ettim... :)"
	www="http://oscam.dreamosat.net/index.php?&direction=0&order=mod&directory=1.20_TRUNK/mips-tuxbox-oe2.0"
	wget $www -q -O /tmp/oscam.info
	version=$(cat /tmp/oscam.info | grep -A 32 "archives" | grep "mipsoe20-webif-oscam-emu-patched.tar.gz"|sed 's/[ ][ ]*/'/g''|cut -b 35-39)
	LINK='http://oscam.dreamosat.net/index.php?action=downloadfile&filename=oscam-svn'$version'-mipsoe20-webif-oscam-emu-patched.tar.gz&directory=1.20_TRUNK/mips-tuxbox-oe2.0&'
	echo ""
	echo ":========> Kopyalanıyor Mips OSCam_r$version"
	wget $LINK -q -O /tmp/OscamUpdate-audi06_19.tar.gz > /dev/null;
	tar -xzf /tmp/OscamUpdate-audi06_19.tar.gz -C /tmp/ > /dev/null;
#	[ -e /tmp/*-arm_dream-list_smargo ] && rm /tmp/*-arm_dream-list_smargo
	mv /tmp/oscam-svn* /tmp/OSCam_r$version
	[ -e /usr/bin/OSCam_r* ] && rm -rf /usr/bin/OSCam_r*
	[ -e /usr/camscript/OSCam_r$version ] && rm -rf /usr/camscript/OSCam_r$version
	echo ""
echo ":========> Kopyalandı Mipsel OSCam_$version /usr/bin"
	cp -rf /tmp/OSCam_r$version /usr/bin/OSCam_r$version
	[ -e /tmp/doc ] && rm -rf /tmp/doc 
	[ -e /tmp/oscam.info ] && rm /tmp/oscam.info 
	[ -e /tmp/OscamUpdate-audi06_19.tar.gz ] && rm /tmp/OscamUpdate-audi06_19.tar.gz 
	[ -e /tmp/OSCam_r$version ] && rm /tmp/OSCam_r$version
	[ -e /tmp/CHANGES ] && rm /tmp/CHANGES
	[ -e /usr/camscript/OSCam_r* ] && rm -rf /usr/camscript/OSCam_r*
echo ""
dest="/usr/camscript/OSCam_r$version.sh"
echo ":========> OSCam_r$version için Script oluşturuluyor... "$dest
echo -e "#!/bin/sh" > $dest
echo -e "" >> $dest
echo -e "CAM=\0042OSCam_r$version\0042" >> $dest
echo -e "OSD=\0042OSCam r$version\0042" >> $dest
echo -e "PID=\0044CAM" >> $dest
echo -e "Action=\00441" >> $dest
echo -e "" >> $dest
echo -e "cam_clean () {" >> $dest
echo -e "		rm -rf /tmp/*.info*	/tmp/.oscam /tmp/*.pid" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "cam_handle () {" >> $dest
echo -e "		if test	-z \0042\0044{PID}\0042	; then" >> $dest
echo -e "				cam_up;" >> $dest
echo -e "		else" >> $dest
echo -e "				cam_down;" >> $dest
echo -e "		fi;" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "cam_down ()	{" >> $dest
echo -e "		killall	-9 \0044CAM 2>/dev/null" >> $dest
echo -e "		sleep 2" >> $dest
echo -e "		cam_clean" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "cam_up () {" >> $dest
echo -e "		/usr/bin/\0044CAM -c /etc/tuxbox/config/ &" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "if test	\0042\0044Action\0042 =	\0042cam_startup\0042 ;	then" >> $dest
echo -e "	if test	-z \0042\0044{PID}\0042 ; then" >> $dest
echo -e "		cam_down" >> $dest
echo -e "		cam_up" >> $dest
echo -e "	else" >> $dest
echo -e "		echo \0042\0044CAM already running, exiting...\0042" >> $dest
echo -e "	fi" >> $dest
echo -e "elif test	\0042\0044Action\0042 =	\0042cam_res\0042 ;	then" >> $dest
echo -e "		cam_down" >> $dest
echo -e "		cam_up" >> $dest
echo -e "elif test \0042\0044Action\0042	= \0042cam_down\0042 ; then" >> $dest
echo -e "		cam_down" >> $dest
echo -e "elif test \0042\0044Action\0042	= \0042cam_up\0042 ; then" >> $dest
echo -e "		cam_up" >> $dest
echo -e "else" >> $dest
echo -e "		cam_handle" >> $dest
echo -e "fi" >> $dest
echo -e "" >> $dest
echo -e "exit 0" >> $dest
sleep 1
chmod 755 $dest > /dev/null;
chmod 755 /usr/bin/OSCam_r$version > /dev/null;
echo ""
echo ":========> Güncel OSCam r$version indirildi"
echo ""
echo ":========> En Yeni OSCam çalıştırılmaya hazır"
echo ""
echo ":== DİKKAT ==>... DreamOSat camManager açın ve OSCam r$version çalıştırın..."
echo ""
else
echo "Üzgünüm cihazınıza uygun OSCam yok :("
fi
fi
rm -rf /tmp/DreamOSat > /dev/null;
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 2
exit 0
