#!/bin/bash    

rm /etc/enigma2/userbouquet.iptv.tv > /dev/null
#entferne alte Datei 
wget -q -O - http://127.0.0.1/web/servicelistreload?mode=2 > /dev/null 2>&1
echo "TEKZENMOD INT IPTV START YAPILDI "

curl -s http://destek.korax.com.tr/UYDUSIS/CLOUD.txt -o - | sed "1,2d" | sed -e '3{h;d}' -e '1G' | sed -En 's/^[[:space:].,]*//;s/^(.*),(http.*$)/#EXTINF:-1,\1\n\2/p;1 i\#EXTM3U' > /tmp/iptv.m3u

cat /tmp/iptv.m3u > /tmp/iptv.0
cat /tmp/iptv.0 > /tmp/iptv.00
sed '/#EXTINF:-1,/!s/:/%3a/g' /tmp/iptv.00 > /tmp/iptv.000
echo '#NAME INT IPTV' > /tmp/iptv.1
cat /tmp/iptv.000 >> /tmp/iptv.1
sed 's/#EXTINF:-1,/#DESCRIPTION: /g' /tmp/iptv.1 > /tmp/iptv.2
sed '/#SERVICE 4097:0:1:0:0:0:0:0:0:0:rt/!s/http%3a/#SERVICE 4097:0:1:0:0:0:0:0:0:0:http%3a/' /tmp/iptv.2 > /tmp/iptv.3
sed -n '/^#DES.*/h;/^#SER.*/{p;x;p};/^#NA.*/p' /tmp/iptv.3 > /tmp/userbouquet.iptv.tv
cp /tmp/userbouquet.iptv.tv /etc/enigma2/userbouquet.iptv.tv > /dev/null
rm /tmp/iptv.* > /dev/null
echo $LINE

echo 'DOWNLOAD TAMAMDIR'
if grep -qs 'userbouquet.iptv.tv' cat /etc/enigma2/bouquets.tv  ; then
    echo "YUKLEME YAPILMISTIR"
else 
	echo '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.iptv.tv" ORDER BY bouquet' >> /etc/enigma2/bouquets.tv
fi
rm /tmp/userbouquet.iptv.tv > /dev/null
echo $LINE


#now reload servicelist
wget -q -O - http://127.0.0.1/web/servicelistreload?mode=0 > /dev/null 2>&1
wget -q -O - http://127.0.0.1/web/servicelistreload?mode=2 > /dev/null 2>&1
echo "IYI SEYIRLER "
 

 

 
 
 
 
 

  
 
