#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."
URL="https://dreamosat-forum.com"
URL1="http://www.boss-cccam.com/Test.php"
URL2="http://www.cccamlux.com/Free-CCcam.php"
URL3="http://infosat.satunivers.tv/download1.php?file=srtx5.txt"
URL4="http://cccamgenerador.com/gratis/get2.php"
URL5="http://freeccamserver.com/free/get2.php"
URL6="http://cccamgood.com/free/get2.php"
URL7="http://cccamspot.com/spot/get.php"
URL8="http://cccammania.com/free4/get2.php"
URL9="http://cccam-free2.com/free2/get.php"
URL10="http://free-cccam.com/freecccam/get.php"
URL11="http://cccamia.com/NEW/new0.php"
URL12="http://powerfullcccam.com/powerfull/get.php"
URL13="http://free-cccam.com/freecccam/get.php"
URL14="http://cccam-free.com/NEW/new0.php"
URL15=""

EMU="/etc/CCcam.cfg"
EMU1="/usr/keys/CCcam.cfg"
EMU_CP="/etc/CCcam-1.cfg"

if grep -qs -i 'C: ' cat $EMU ; then
   cp -rd $EMU $EMU_CP > /dev/null 2>&1
   echo $FIN
   echo "ETC içerisinden, CCcam.cfg Yedek alındı..."
   echo "CCcam.cfg Backup taken ..."
   echo $FIN
else
   echo "ETC içerisinden, CCcam.cfg Yedek alınamadı..."
   echo "CCcam.cfg Failed to backup ..."
   echo $FIN
fi

rm -rf $EMU > /dev/null 2>&1
rm -rf $EMU1 > /dev/null 2>&1

cat > $EMU << EOF
#### "*******************************************"
#### "*          ..:: A U T H O R ::..          *"
#### "*             << audi06_19 >>             *"
#### "*  ..:: https://dreamosat-forum.com ::..  *"
#### "*******************************************"

EOF

chmod 755 $EMU $EMU1 > /dev/null 2>&1

wget -U "$URL" --quiet -O - $URL1 | grep -o -i 'C:[^<]*' >>$EMU
wget -U "$URL" --quiet -O - $URL2 | grep -o -i 'C:[^<]*' >>$EMU
wget -U "$URL" --quiet -O - $URL3 | grep -o -i 'C:[^<]*' >>$EMU
wget -U "$URL" --quiet -O - $URL4 | grep -o -i 'C:[^<]*' >>$EMU
wget -U "$URL" --quiet -O - $URL5 | grep -o -i 'C:[^<]*' >>$EMU
wget -U "$URL" --quiet -O - $URL6 | grep -o -i 'C:[^<]*' >>$EMU
wget -U "$URL" --quiet -O - $URL7 | grep -o -i 'C:[^<]*' >>$EMU
#wget -U "$URL" --quiet -O - $URL8 | grep -o -i 'C:[^<]*' >>$EMU
wget -U "$URL" --quiet -O - $URL9 | grep -o -i 'C:[^<]*' >>$EMU
wget -U "$URL" --quiet -O - $URL10 | grep -o -i 'C:[^<]*' >>$EMU
wget -U "$URL" --quiet -O - $URL11 | grep -o -i 'C:[^<]*' >>$EMU
wget -U "$URL" --quiet -O - $URL12 | grep -o -i 'C:[^<]*' >>$EMU
wget -U "$URL" --quiet -O - $URL13 | grep -o -i 'C:[^<]*' >>$EMU
wget -U "$URL" --quiet -O - $URL14 | grep -o -i 'C:[^<]*' >>$EMU
#wget -U "$URL" --quiet -O - $URL15 | grep -o -i 'C:[^<]*' >>$EMU

dos2unix $EMU $EMU1 > /dev/null 2>&1

if grep -qs 'C: ' cat $EMU ; then
echo $FIN
echo "C+Line server indirildi, etc, usr/keys içerisine yazıldı..."
echo "C+Line server downloaded, it was written in /etc, usr/keys ...";
echo "" >> $EMU
echo "######################################################" >> $EMU
echo "WEBINFO USERNAME :" >> $EMU
echo "WEBINFO PASSWORD :" >> $EMU
echo "ALLOW WEBINFO: yes" >> $EMU
echo "WEBINFO LISTEN PORT : 16001" >> $EMU
echo "CHANNELINFO FILE : /etc/CCcam.channelinfo" >> $EMU
echo "CAID PRIO FILE : /etc/CCcam.prio" >> $EMU
echo "PROVIDERINFO FILE : /etc/CCcam.providers" >> $EMU
echo "STATIC CW FILE : /usr/keys/constant.cw" >> $EMU
echo "SOFTKEY FILE : /usr/keys/SoftCam.Key" >> $EMU
echo "AUTOROLL FILE : /usr/keys/AutoRoll.Key" >> $EMU
cp -rd $EMU $EMU1
else
      if [ -f /etc/CCcam.cfg ] ; then
         cp -rd $EMU_CP $EMU
	 cp -rd $EMU_CP $EMU1
      else
         echo $FIN
      fi
   echo "Server Off, bağlantı kurulamadı..."
   echo "Server Off, unable to connect ...";
   echo $FIN
   echo "C+Line server Yedek geri yuklendi..."
   echo "C+Line server Backup uploaded back ..."
fi

echo $FIN
echo "DreamOSat camManager Restart Etmeyi Unutmayınız. iyi seyirler...";
echo "Do not forget to restart DreamOSat camManager. good looking ...";
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0

