#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com 15-10-2017
FIN="==================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."
rm -rf /tmp/DreamOSat
[ -d /tmp/DreamOSat ] || mkdir -p /tmp/DreamOSat > /dev/null;
[ -d /usr/share/enigma2/picon ] || mkdir -p /usr/share/enigma2/picon > /dev/null;
cd /tmp/DreamOSat
#https://drive.google.com/open?id=0Bwz6mBA7lUOKN19jQ2lnWGd4cE0
ggID='0Bwz6mBA7lUOKN19jQ2lnWGd4cE0'
ggURL='https://drive.google.com/uc?export=download'

echo $FIN
echo "curl kontrol ediliyor..."
echo "curl is being controlled ..."
if [ -f /usr/bin/curl ] ; then
   echo $FIN
   echo "curl dosyası yüklü, tekrar yüklenmesine gerek yok ..."
   echo "curl installed on your device, no need to re-install ..."
   echo $FIN
   echo "PAKET AÇILIYOR, İŞLEM DOSYA BOYUTUNE GÖRE UZUN SÜREBİLİR , SABIRLA BEKLEYİNİZ";
   echo "PACKAGE OPENED, OPERATION FILE SIZE DURING LONG, STILL WAIT WAIT";

curl -sc /tmp/DreamOSat/gcokie "${ggURL}&id=${ggID}" >/dev/null
getcode="$(awk '/_warning_/ {print $NF}' /tmp/DreamOSat/gcokie)"
curl -LOJb /tmp/DreamOSat/gcokie "${ggURL}&confirm=${getcode}&id=${ggID}"
#curl -Lbo -s "https://drive.google.com/uc?export=download&confirm=Uq6r&id=${ggID}" -o "picontranparent-220x132.7z"

#_picontransparent-220x132-45.0W-85.1E_by_chocholousek_(171224).7z
mv _picontransparent-220x132* picontranparent-220x132.7z
7za x picontranparent-220x132.7z -aoa -o/tmp/DreamOSat

else
   opkg install curl
     if [ -f /usr/bin/curl ] ; then
	echo "curl UPLOADED"
	echo $FIN
	echo "PAKET AÇILIYOR, İŞLEM DOSYA BOYUTUNE GÖRE UZUN SÜREBİLİR , SABIRLA BEKLEYİNİZ";
	echo "PACKAGE OPENED, OPERATION FILE SIZE DURING LONG, STILL WAIT WAIT";

curl -sc /tmp/DreamOSat/gcokie "${ggURL}&id=${ggID}" >/dev/null
getcode="$(awk '/_warning_/ {print $NF}' /tmp/DreamOSat/gcokie)"
curl -LOJb /tmp/DreamOSat/gcokie "${ggURL}&confirm=${getcode}&id=${ggID}"
#curl -Lbo -s "https://drive.google.com/uc?export=download&confirm=Uq6r&id=${ggID}" -o "picontranparent-220x132.7z"

#_picontransparent-220x132-45.0W-85.1E_by_chocholousek_(171224).7z
mv _picontransparent-220x132* picontranparent-220x132.7z
7za x picontranparent-220x132.7z -aoa -o/tmp/DreamOSat

sleep 1
echo $FIN

else
echo $FIN
echo "curl yüklenemedi.!!! Teknik Destek İçin (www.dreamosat-forum.com) Yardım Alınız ...";
echo "curl error.!!! For Technical Support (www.dreamosat-forum.com) Get Help ...";
fi
fi

cd /
rm -rf /tmp/DreamOSat
echo "";
echo "### Picons Thank you By. chocholousek J. ###";
echo "********************************************";
echo "           ..:: A U T H O R ::..            ";
echo "              << audi06_19 >>               ";
echo "   ..:: https://dreamosat-forum.com ::..    ";
echo "********************************************";
sleep 2;
exit 0

#7z x picontranparent-220x132.7z -o/usr/share/enigma2/picon
# /usr/bin/curl
#curl -sc /tmp/gcokie "${ggURL}&id=${ggID}" >/dev/null
#getcode="$(awk '/_warning_/ {print $NF}' /tmp/gcokie)"
#curl -LOJb /tmp/gcokie "${ggURL}&confirm=${getcode}&id=${ggID}"
# wget --no-check-certificate 'https://docs.google.com/uc?export=download&id=FILEID' -O FILENAME

