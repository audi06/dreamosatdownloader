#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com 2017
echo "";
echo "*     ..:: B E K L E Y İ N İ Z ::..       *"
echo "";
STOP1=$(ps -A | awk '/GCam*/{print $4}')
STOP2=$(ps -A | awk '/Gcam*/{print $4}')
STOP3=$(ps -A | awk '/gcam*/{print $4}')
sleep 1;
echo ":========> Yüklü GCamlar Aranıyor..."
echo ":========> GCam Dosya yolları..."
echo ""
find /usr/bin/ -iname gcam*
echo ""
echo ":========> Çalışan GCamlar..."
echo ""
sleep 1;
ps -A | awk '/GCam*/{print $4}'
ps -A | awk '/Gcam*/{print $4}'
ps -A | awk '/gcam*/{print $4}'
sleep 1;
echo ""
echo ":========> Stop"
killall /usr/bin/$STOP1 2>/dev/null
killall /usr/bin/$STOP2 2>/dev/null
killall /usr/bin/$STOP3 2>/dev/null
sleep 1;
##################################################################################################
echo ""
[ -d /tmp/DreamOSat ] || mkdir -p /tmp/DreamOSat > /dev/null;
[ -d /usr/camscript ] || mkdir -p /usr/camscript;
echo ":========> Cihazınızın işlemcisini kontrol ediyorum..."
echo ""
uname -m >> /tmp/DreamOSat/name.txt
sleep 1;
if grep -qs 'armv7l' cat /tmp/DreamOSat/name.txt ; then
	echo ":========> ARM işlemci kullandığınızı tespit ettim... :)"
	www="http://oscam.dreamosat.net/index.php?&direction=0&order=mod&directory=1.20_GCAM-EMU/arm_dm900-solo4k&"
	wget $www -q -O /tmp/gcam.info
	version=$(cat /tmp/gcam.info | grep -A 32 "archives" | grep "_emu_solo4k.zip"|sed 's/[ ][ ]*/'/g''|cut -b 31-33)
	LINK='http://oscam.dreamosat.net/index.php?action=downloadfile&filename=gcam-'$version'_emu_solo4k.zip&directory=1.20_GCAM-EMU/arm_dm900-solo4k&'
echo ""
echo ":========> Kopyalanıyor  GCam_r$version"
	wget $LINK -q -O /tmp/GcamUpdate-audi06_19.zip
	[ -e /tmp/gcam.info ] && rm /tmp/gcam.info
	unzip /tmp/GcamUpdate-audi06_19.zip -d /tmp/ > /dev/null;
#	[ -e /tmp/*-arm_dream-list_smargo ] && rm /tmp/*-arm_dream-list_smargo
	mv /tmp/gcam* /tmp/GCam_r$version
	[ -e /usr/bin/GCam_r* ] && rm -rf /usr/bin/GCam_r*
	[ -e /usr/camscript/GCam_r$version ] && rm -rf /usr/camscript/GCam_r$version
	echo ""
echo ":========> Kopyalandı ARM GCam_$version /usr/bin"
	cp -rf /tmp/GCam_r$version /usr/bin/GCam_r$version
#	[ -e /tmp/doc ] && rm -rf /tmp/doc 
#	[ -e /tmp/gcam.info ] && rm /tmp/gcam.info 
	[ -e /tmp/GcamUpdate-audi06_19.zip ] && rm /tmp/GcamUpdate-audi06_19.zip
	[ -e /tmp/GCam_r$version ] && rm /tmp/GCam_r$version
#	[ -e /tmp/CHANGES ] && rm /tmp/CHANGES
	[ -e /usr/camscript/GCam_r* ] && rm -rf /usr/camscript/GCam_r*
echo ""
dest="/usr/camscript/GCam_r$version.sh"
echo ":========> GCam_r$version için Script oluşturuluyor... "$dest
echo -e "#!/bin/sh" > $dest
echo -e "" >> $dest
echo -e "CAM=\0042GCam_r$version\0042" >> $dest
echo -e "OSD=\0042GCam r$version\0042" >> $dest
echo -e "PID=\0044CAM" >> $dest
echo -e "Action=\00441" >> $dest
echo -e "" >> $dest
echo -e "cam_clean () {" >> $dest
echo -e "		rm -rf /tmp/*.info*	/tmp/.oscam /tmp/*.pid" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "cam_handle () {" >> $dest
echo -e "		if test	-z \0042\0044{PID}\0042	; then" >> $dest
echo -e "				cam_up;" >> $dest
echo -e "		else" >> $dest
echo -e "				cam_down;" >> $dest
echo -e "		fi;" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "cam_down ()	{" >> $dest
echo -e "		killall	-9 \0044CAM 2>/dev/null" >> $dest
echo -e "		sleep 2" >> $dest
echo -e "		cam_clean" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "cam_up () {" >> $dest
echo -e "		/usr/bin/\0044CAM -c /etc/tuxbox/config &" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "if test	\0042\0044Action\0042 =	\0042cam_startup\0042 ;	then" >> $dest
echo -e "	if test	-z \0042\0044{PID}\0042 ; then" >> $dest
echo -e "		cam_down" >> $dest
echo -e "		cam_up" >> $dest
echo -e "	else" >> $dest
echo -e "		echo \0042\0044CAM already running, exiting...\0042" >> $dest
echo -e "	fi" >> $dest
echo -e "elif test	\0042\0044Action\0042 =	\0042cam_res\0042 ;	then" >> $dest
echo -e "		cam_down" >> $dest
echo -e "		cam_up" >> $dest
echo -e "elif test \0042\0044Action\0042	= \0042cam_down\0042 ; then" >> $dest
echo -e "		cam_down" >> $dest
echo -e "elif test \0042\0044Action\0042	= \0042cam_up\0042 ; then" >> $dest
echo -e "		cam_up" >> $dest
echo -e "else" >> $dest
echo -e "		cam_handle" >> $dest
echo -e "fi" >> $dest
echo -e "" >> $dest
echo -e "exit 0" >> $dest
sleep 1
chmod 755 $dest > /dev/null;
chmod 755 /usr/bin/GCam_r$version > /dev/null;
echo ""
echo ":========> Güncel GCam r$version indirildi"
echo ""
echo ":========> En Yeni GCam çalıştırılmaya hazır"
echo ""
echo ":== DİKKAT ==>... DreamOSat camManager açın ve GCam r$version çalıştırın..."
echo ""
else
uname -m >> /tmp/DreamOSat/name2.txt
sleep 1;
if grep -qs 'mips' cat /tmp/DreamOSat/name2.txt ; then
	echo ":========> Mips işlemci kullandığınızı tespit ettim... :)"
	www="http://oscam.dreamosat.net/index.php?&direction=0&order=mod&directory=1.20_GCAM-EMU/mips-tuxbox-oe2.0"
	wget $www -q -O /tmp/gcam.info
	version=$(cat /tmp/gcam.info | grep -A 32 "archives" | grep "_emu_mipsoe20.zip"|sed 's/[ ][ ]*/'/g''|cut -b 31-33)
	LINK='http://oscam.dreamosat.net/index.php?action=downloadfile&filename=gcam-'$version'_emu_mipsoe20.zip&directory=1.20_GCAM-EMU/mips-tuxbox-oe2.0&'
	echo ""
	echo ":========> Kopyalanıyor Mips GCam_r$version"
	wget $LINK -q -O /tmp/GcamUpdate-audi06_19.zip > /dev/null;
	[ -e /tmp/gcam.info ] && rm /tmp/gcam.info
	unzip /tmp/GcamUpdate-audi06_19.zip -d /tmp/ > /dev/null;
#	[ -e /tmp/*-arm_dream-list_smargo ] && rm /tmp/*-arm_dream-list_smargo
	mv /tmp/gcam* /tmp/GCam_r$version
	[ -e /usr/bin/GCam_r* ] && rm -rf /usr/bin/GCam_r*
	[ -e /usr/camscript/GCam_r$version ] && rm -rf /usr/camscript/GCam_r$version
	echo ""
echo ":========> Kopyalandı Mips GCam_$version /usr/bin"
	cp -rf /tmp/GCam_r$version /usr/bin/GCam_r$version
#	[ -e /tmp/doc ] && rm -rf /tmp/doc 
#	[ -e /tmp/gcam.info ] && rm /tmp/gcam.info 
	[ -e /tmp/GcamUpdate-audi06_19.zip ] && rm /tmp/GcamUpdate-audi06_19.zip
	[ -e /tmp/GCam_r$version ] && rm /tmp/GCam_r$version
#	[ -e /tmp/CHANGES ] && rm /tmp/CHANGES
	[ -e /usr/camscript/GCam_r* ] && rm -rf /usr/camscript/GCam_r*
echo ""
dest="/usr/camscript/GCam_r$version.sh"
echo ":========> GCam_r$version için Script oluşturuluyor... "$dest
echo -e "#!/bin/sh" > $dest
echo -e "" >> $dest
echo -e "CAM=\0042GCam_r$version\0042" >> $dest
echo -e "OSD=\0042GCam r$version\0042" >> $dest
echo -e "PID=\0044CAM" >> $dest
echo -e "Action=\00441" >> $dest
echo -e "" >> $dest
echo -e "cam_clean () {" >> $dest
echo -e "		rm -rf /tmp/*.info*	/tmp/.oscam /tmp/*.pid" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "cam_handle () {" >> $dest
echo -e "		if test	-z \0042\0044{PID}\0042	; then" >> $dest
echo -e "				cam_up;" >> $dest
echo -e "		else" >> $dest
echo -e "				cam_down;" >> $dest
echo -e "		fi;" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "cam_down ()	{" >> $dest
echo -e "		killall	-9 \0044CAM 2>/dev/null" >> $dest
echo -e "		sleep 2" >> $dest
echo -e "		cam_clean" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "cam_up () {" >> $dest
echo -e "		/usr/bin/\0044CAM -c /etc/tuxbox/config &" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "if test	\0042\0044Action\0042 =	\0042cam_startup\0042 ;	then" >> $dest
echo -e "	if test	-z \0042\0044{PID}\0042 ; then" >> $dest
echo -e "		cam_down" >> $dest
echo -e "		cam_up" >> $dest
echo -e "	else" >> $dest
echo -e "		echo \0042\0044CAM already running, exiting...\0042" >> $dest
echo -e "	fi" >> $dest
echo -e "elif test	\0042\0044Action\0042 =	\0042cam_res\0042 ;	then" >> $dest
echo -e "		cam_down" >> $dest
echo -e "		cam_up" >> $dest
echo -e "elif test \0042\0044Action\0042	= \0042cam_down\0042 ; then" >> $dest
echo -e "		cam_down" >> $dest
echo -e "elif test \0042\0044Action\0042	= \0042cam_up\0042 ; then" >> $dest
echo -e "		cam_up" >> $dest
echo -e "else" >> $dest
echo -e "		cam_handle" >> $dest
echo -e "fi" >> $dest
echo -e "" >> $dest
echo -e "exit 0" >> $dest
sleep 1
chmod 755 $dest > /dev/null;
chmod 755 /usr/bin/GCam_r$version > /dev/null;
echo ""
echo ":========> Güncel GCam r$version indirildi"
echo ""
echo ":========> En Yeni GCam çalıştırılmaya hazır"
echo ""
echo ":== DİKKAT ==>... DreamOSat camManager açın ve GCam r$version çalıştırın..."
echo ""
else
echo "Üzgünüm cihazınıza uygun GCam yok :("
fi
fi
rm -rf /tmp/DreamOSat > /dev/null;
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 2
exit 0
