###########################################################
#      Coded by pcd@i-have-a-dreambox, October 2010       #
#       modified by @dreamosat, januar 2017               #
###########################################################
from Screens.ChoiceBox import ChoiceBox
from Screens.Screen import Screen
from Components.ActionMap import ActionMap, NumberActionMap
from Components.MenuList import MenuList
from Components.Sources.List import List
from Components.FileList import FileList
from Screens.Console import Console
from Screens.MessageBox import MessageBox
from Plugins.Plugin import PluginDescriptor
from Components.Pixmap import Pixmap
from Tools import Notifications
from ServiceReference import ServiceReference
from Components.Button import Button
from Components.Label import Label
from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import SCOPE_SKIN_IMAGE, resolveFilename
import os
import urllib

from enigma import getDesktop
DESKHEIGHT = getDesktop(0).size().height()
skin_path = "/usr/lib/enigma2/python/Plugins/Extensions/DreamOSatcamManager/Skin/"

class Emumanager(Screen):

    def __init__(self, session, args = 0):
        self.session = session
        if DESKHEIGHT < 1000:		
            skin = skin_path + 'menuhd.xml'
        else:	
		     skin = skin_path + 'menufullhd.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()
        Screen.__init__(self, session)
        self.index = 0
        self.sclist = []
        self.namelist = []
        self.oldService = self.session.nav.getCurrentlyPlayingServiceReference()
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions'], {'ok': self.action,
         'cancel': self.close,
         'green': self.action,
         'red': self.stop}, -1)
        self['key_green'] = Button(_('Start/Restart'))
        self['key_red'] = Button(_('Stop'))
        self.lastCam = self.readCurrent()
        self.softcamlist = []
        self['info'] = Label()
        self['list'] = MenuList(self.softcamlist)
        self.readScripts()
	title = _("DreamOSat CamManager    5.5 - 13.10.2017")
        self.setTitle(title)
        self['pixmap'] = Pixmap()
        self.ecm()
        self.onShown.append(self.openTest)

    def openTest(self):
        pass

    def getLastIndex(self):
        a = 0
        if len(self.namelist) > 0:
            for x in self.namelist:
                if x == self.lastCam:
                    return a
                a += 1

        else:
            return -1
        return -1

    def action(self):
        self.session.nav.playService(None)
        last = self.getLastIndex()
        var = self['list'].getSelectionIndex()
        if last > -1:
            if last == var:
                self.cmd1 = '/usr/camscript/' + self.sclist[var] + ' cam_res &'
                os.system(self.cmd1)
                os.system('sleep 4')
            else:
                self.cmd1 = '/usr/camscript/' + self.sclist[last] + ' cam_down &'
                os.system(self.cmd1)
                os.system('sleep 4')
                self.cmd1 = '/usr/camscript/' + self.sclist[var] + ' cam_up &'
                os.system(self.cmd1)
        else:
            try:
                self.cmd1 = '/usr/camscript/' + self.sclist[var] + ' cam_up &'
                os.system(self.cmd1)
                os.system('sleep 4')
            except:
                self.close()

        if last != var:
            try:
                self.lastCam = self.softcamlist[var]
                self.writeFile()
            except:
                self.close()

        self.readScripts()
        self.session.nav.playService(self.oldService)
        self.close()
        return

    def writeFile(self):
        if self.lastCam is not None:
            clist = open('/etc/clist.list', 'w')
            clist.write(self.lastCam)
            clist.close()
        stcam = open('/etc/startcam.sh', 'w')
        stcam.write('#!/bin/sh\n' + self.cmd1)
        stcam.close()
        self.cmd2 = 'chmod 755 /etc/startcam.sh &'
        os.system(self.cmd2)
        return

    def stop(self):
        self.session.nav.playService(None)
        last = self.getLastIndex()
        if last > -1:
            self.cmd1 = '/usr/camscript/' + self.sclist[last] + ' cam_down &'
            os.system(self.cmd1)
        else:
            return
        self.lastCam = 'no'
        self.writeFile()
        os.system('sleep 4')
        self.readScripts()
        self['info'].setText(' ')
        self.session.nav.playService(self.oldService)
        return

    def readScripts(self):
        self.index = 0
        scriptliste = []
        pliste = []
        path = '/usr/camscript/'
        for root, dirs, files in os.walk(path):
            for name in files:
                scriptliste.append(name)

        self.sclist = scriptliste
        i = len(self.softcamlist)
        del self.softcamlist[0:i]
        for lines in scriptliste:
            dat = path + lines
            sfile = open(dat, 'r')
            for line in sfile:
                if line[0:3] == 'OSD':
                    nam = line[5:len(line) - 2]
                    print 'We are in Emumanager readScripts 2 nam = ', nam
                    if self.lastCam is not None:
                        if nam == self.lastCam:
                            self.softcamlist.append(nam + '\tActive')
                        else:
                            self.softcamlist.append(nam)
                        self.index += 1
                    else:
                        self.softcamlist.append(nam)
                        self.index += 1
                    pliste.append(nam)

            sfile.close()
            self['list'].setList(self.softcamlist)
            self.namelist = pliste

        return

    def readCurrent(self):
        try:
            clist = open('/etc/clist.list', 'r')
        except:
            return

        if clist is not None:
            for line in clist:
                lastcam = line

            clist.close()
        return lastcam

    def ecm(self):
        ecmf = ''
        if os.path.isfile('/tmp/ecm.info') is True:
            myfile = file('/tmp/ecm.info')
            ecmf = ''
            for line in myfile.readlines():
                print line
                ecmf = ecmf + line

            self['info'].setText(ecmf)
        else:
            self['info'].setText(ecmf)
            return

    def autocam(self):
        current = None
        try:
            clist = open('/etc/clist.list', 'r')
            print 'found list'
        except:
            return

        if clist is not None:
            for line in clist:
                current = line

            clist.close()
        print 'current =', current
        if os.path.isfile('/etc/autocam.txt') is False:
            alist = open('/etc/autocam.txt', 'w')
            alist.close()
        self.cleanauto()
        alist = open('/etc/autocam.txt', 'a')
        alist.write(self.oldService.toString() + '\n')
        last = self.getLastIndex()
        alist.write(current + '\n')
        alist.close()
        self.session.openWithCallback(self.callback, MessageBox, _('Autocam assigned to the current channel'), type=1, timeout=10)
        return

    def cleanauto(self):
        delemu = 'no'
        if os.path.isfile('/etc/autocam.txt') is False:
            return
        myfile = open('/etc/autocam.txt', 'r')
        myfile2 = open('/etc/autocam2.txt', 'w')
        icount = 0
        for line in myfile.readlines():
            print 'We are in Emumanager line, self.oldService.toString() =', line, self.oldService.toString()
            if line[:-1] == self.oldService.toString():
                delemu = 'yes'
                icount = icount + 1
                continue
            if delemu == 'yes':
                delemu = 'no'
                icount = icount + 1
                continue
            myfile2.write(line)
            icount = icount + 1

        myfile.close()
        myfile2.close()
        os.system('rm /etc/autocam.txt')
        os.system('cp /etc/autocam2.txt /etc/autocam.txt')


def startConfig(session, **kwargs):
    session.open(Emumanager)


def mainmenu(menuid):
    if menuid != 'mainmenu':
        return []
    else:
        return [(_('DreamOSat CamManager'),
          startConfig,
          'softcam',
          None)]
        return None


def autostart(reason, session = None, **kwargs):
    """called with reason=1 to during shutdown, with reason=0 at startup?"""
    print '[Softcam] Started'
    if reason == 0:
        try:
            os.system('mv /usr/bin/dccamd /usr/bin/dccamdOrig &')
            os.system('ln -sf /usr/bin /var/bin')
            os.system('ln -sf /usr/keys /var/keys')
            os.system('ln -sf /usr/scce /var/scce')
            os.system('ln -sf /usr/script /var/script')
            os.system('sleep 2')
            os.system('/etc/startcam.sh &')
        except:
            pass

#####################################################################

def Plugins(**kwargs):
    return [PluginDescriptor(name='DreamOSat CamManager', description='Emu Softcam Manager', icon='plugin.png', where=PluginDescriptor.WHERE_PLUGINMENU, fnc=startConfig), PluginDescriptor(name='DreamOSat CamManager', description='Emu Softcam Manager', icon='plugin.png', where=[PluginDescriptor.WHERE_AUTOSTART], fnc=autostart)]


