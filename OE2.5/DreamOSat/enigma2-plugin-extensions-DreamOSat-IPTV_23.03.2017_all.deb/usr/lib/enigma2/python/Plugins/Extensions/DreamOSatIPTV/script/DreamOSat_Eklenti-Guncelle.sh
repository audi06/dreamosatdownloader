#!/bin/sh
echo ""
wget http://www.lokumsat.esy.es/DreamOSat/IPTV/DostlarForumIPTV.ipk -qO /tmp/DostlarForumIPTV.ipk
opkg install --force-overwrite /tmp/DreamOSatIPTV*
rm -rf /tmp/DreamOSatIPTV*
echo ""
echo "*******************************************"
echo "*            ..:: I P T V ::..            *"
echo "*          ..:: A U T H O R ::..          *"
echo "*  ..:: D R E A M O S A T  F O R U M ::.. *"
echo "*******************************************"
echo ""
echo "*     ..:: G Ü N C E L L E N D İ ::..     *"
echo "*..:: UYDU ALICINIZI YENİDEN BAŞLATIN ::..*"
echo ""
sleep 2
exit 0
