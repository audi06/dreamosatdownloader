#!/bin/sh
echo "*            ..:: S P O R ::..            *"
echo "*******************************************"
echo "*   ..:: G Ü N C E L L E N İ Y O R ::..   *"
echo "*******************************************"
wget http://www.lokumsat.esy.es/DreamOSat/IPTV/bouquets/userbouquet.DreamOSatIPTV_spor.tv -qO /etc/enigma2/userbouquet.DreamOSatIPTV_spor.tv
wget -q -O - http://127.0.0.1/web/servicelistreload?mode=2
echo ""
echo "*          ..:: A U T H O R ::..          *"
echo "*  ..:: D R E A M O S A T  F O R U M ::.. *"
echo "*******************************************"
echo ""
sleep 2
exit 0
