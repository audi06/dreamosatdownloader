#!/bin/sh
echo "";
echo "   ..:: D R E A M O S A T  F O R U M ::..  ";
echo "-------------------------------------------";
echo "";
audi06_1="DreamOSatIPTV_Belgesel.sh";
audi06_2="DreamOSatIPTV_Ekle.sh";
audi06_3="DreamOSatIPTV_Genel.sh";
audi06_4="DreamOSatIPTV_Music.sh";
audi06_5="DreamOSatIPTV_Porn.sh";
audi06_6="DreamOSatIPTV_Spor.sh";
audi06_7="DreamOSatIPTV_Sinema.sh";
audi06_8="DreamOSat_Eklenti-Guncelle.sh"
echo "";
url1="http://depo.dreamosat.net/oZeL/DreamOSatIPTV/script/$audi06_1";
url2="http://depo.dreamosat.net/oZeL/DreamOSatIPTV/script/$audi06_2";
url3="http://depo.dreamosat.net/oZeL/DreamOSatIPTV/script/$audi06_3";
url4="http://depo.dreamosat.net/oZeL/DreamOSatIPTV/script/$audi06_4";
url5="http://depo.dreamosat.net/oZeL/DreamOSatIPTV/script/$audi06_5";
url6="http://depo.dreamosat.net/oZeL/DreamOSatIPTV/script/$audi06_6";
url7="http://depo.dreamosat.net/oZeL/DreamOSatIPTV/script/$audi06_7";
url8="http://depo.dreamosat.net/oZeL/DreamOSatIPTV/script/$audi06_8";
echo "";
yol="/usr/lib/enigma2/python/Plugins/Extensions/DreamOSatIPTV"
echo "";
wget http://depo.dreamosat.net/oZeL/DreamOSatIPTV/plugin.py -qO $yol/plugin.py;
wget http://depo.dreamosat.net/oZeL/DreamOSatIPTV/__init__.py -qO $yol/__init__.py;
wget http://depo.dreamosat.net/oZeL/DreamOSatIPTV/plugin.png -qO $yol/plugin.png;
echo "";
wget $url1 -qO $yol/script/$audi06_1 > /dev/null;
wget $url2 -qO $yol/script/$audi06_2 > /dev/null;
wget $url3 -qO $yol/script/$audi06_3 > /dev/null;
wget $url4 -qO $yol/script/$audi06_4 > /dev/null;
wget $url5 -qO $yol/script/$audi06_5 > /dev/null;
wget $url6 -qO $yol/script/$audi06_6 > /dev/null;
wget $url7 -qO $yol/script/$audi06_7 > /dev/null;
wget $url8 -qO $yol/script/$audi06_8 > /dev/null;
echo "";
chmod 0755 $yol/*.py -R;
chmod 0755 $yol/script/*.sh -R;
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
echo "";
echo "*     ..:: G Ü N C E L L E N D İ ::..     *";
echo "*..:: UYDU ALICINIZI YENİDEN BAŞLATIN ::..*";
echo ""
sleep 3;
killall -9 enigma2;
exit 0
