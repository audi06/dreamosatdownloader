#!/bin/sh
echo "";
echo "   ..:: D R E A M O S A T  F O R U M ::..  "
echo "-------------------------------------------"

bouquet1="DreamOSatIPTV_belgesel.tv";
bouquet2="DreamOSatIPTV_porn.tv";
bouquet3="DreamOSatIPTV_music.tv";
bouquet4="DreamOSatIPTV_sinema.tv";
bouquet5="DreamOSatIPTV_belgesel.tv";
bouquet6="DreamOSatIPTV_spor.tv";
bouquet7="DreamOSatIPTV_genel.tv";

url1="http://depo.dreamosat.net/oZeL/DreamOSatIPTV/bouquets/userbouquet.'$bouquet1'";
url2="http://depo.dreamosat.net/oZeL/DreamOSatIPTV/bouquets/userbouquet.'$bouquet2'";
url3="http://depo.dreamosat.net/oZeL/DreamOSatIPTV/bouquets/userbouquet.'$bouquet3'";
url4="http://depo.dreamosat.net/oZeL/DreamOSatIPTV/bouquets/userbouquet.'$bouquet4'";
url5="http://depo.dreamosat.net/oZeL/DreamOSatIPTV/bouquets/userbouquet.'$bouquet5'";
url6="http://depo.dreamosat.net/oZeL/DreamOSatIPTV/bouquets/userbouquet.'$bouquet6'";
url7="http://depo.dreamosat.net/oZeL/DreamOSatIPTV/bouquets/userbouquet.'$bouquet7'";

wget -qO /etc/enigma2/userbouquet."$bouquet1" $url1 > /dev/null;
if ! cat /etc/enigma2/bouquets.tv | grep -v grep | grep -c $bouquet1 > /dev/null;then echo "[+]Creating Folder for iptv and rehashing...";cat /etc/enigma2/bouquets.tv | sed -n 1p > /etc/enigma2/new_bouquets.tv;echo '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.'$bouquet1'" ORDER BY bouquet' >> /etc/enigma2/new_bouquets.tv;cat /etc/enigma2/bouquets.tv | sed -n '2,$p' >> /etc/enigma2/new_bouquets.tv;rm /etc/enigma2/bouquets.tv;mv /etc/enigma2/new_bouquets.tv /etc/enigma2/bouquets.tv;fi;
echo "";
wget -qO /etc/enigma2/userbouquet."$bouquet2" $url2 > /dev/null;
if ! cat /etc/enigma2/bouquets.tv | grep -v grep | grep -c $bouquet2 > /dev/null;then echo "[+]Creating Folder for iptv and rehashing...";cat /etc/enigma2/bouquets.tv | sed -n 1p > /etc/enigma2/new_bouquets.tv;echo '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.'$bouquet2'" ORDER BY bouquet' >> /etc/enigma2/new_bouquets.tv;cat /etc/enigma2/bouquets.tv | sed -n '2,$p' >> /etc/enigma2/new_bouquets.tv;rm /etc/enigma2/bouquets.tv;mv /etc/enigma2/new_bouquets.tv /etc/enigma2/bouquets.tv;fi;
echo "";
wget -qO /etc/enigma2/userbouquet."$bouquet3" $url3 > /dev/null;
if ! cat /etc/enigma2/bouquets.tv | grep -v grep | grep -c $bouquet3 > /dev/null;then echo "[+]Creating Folder for iptv and rehashing...";cat /etc/enigma2/bouquets.tv | sed -n 1p > /etc/enigma2/new_bouquets.tv;echo '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.'$bouquet3'" ORDER BY bouquet' >> /etc/enigma2/new_bouquets.tv;cat /etc/enigma2/bouquets.tv | sed -n '2,$p' >> /etc/enigma2/new_bouquets.tv;rm /etc/enigma2/bouquets.tv;mv /etc/enigma2/new_bouquets.tv /etc/enigma2/bouquets.tv;fi;
echo "";
wget -qO /etc/enigma2/userbouquet."$bouquet4" $url4 > /dev/null;
if ! cat /etc/enigma2/bouquets.tv | grep -v grep | grep -c $bouquet4 > /dev/null;then echo "[+]Creating Folder for iptv and rehashing...";cat /etc/enigma2/bouquets.tv | sed -n 1p > /etc/enigma2/new_bouquets.tv;echo '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.'$bouquet4'" ORDER BY bouquet' >> /etc/enigma2/new_bouquets.tv;cat /etc/enigma2/bouquets.tv | sed -n '2,$p' >> /etc/enigma2/new_bouquets.tv;rm /etc/enigma2/bouquets.tv;mv /etc/enigma2/new_bouquets.tv /etc/enigma2/bouquets.tv;fi;
echo "";
wget -qO /etc/enigma2/userbouquet."$bouquet5" $url5 > /dev/null;
if ! cat /etc/enigma2/bouquets.tv | grep -v grep | grep -c $bouquet5 > /dev/null;then echo "[+]Creating Folder for iptv and rehashing...";cat /etc/enigma2/bouquets.tv | sed -n 1p > /etc/enigma2/new_bouquets.tv;echo '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.'$bouquet5'" ORDER BY bouquet' >> /etc/enigma2/new_bouquets.tv;cat /etc/enigma2/bouquets.tv | sed -n '2,$p' >> /etc/enigma2/new_bouquets.tv;rm /etc/enigma2/bouquets.tv;mv /etc/enigma2/new_bouquets.tv /etc/enigma2/bouquets.tv;fi;
echo "";
wget -qO /etc/enigma2/userbouquet."$bouquet6" $url6 > /dev/null;
if ! cat /etc/enigma2/bouquets.tv | grep -v grep | grep -c $bouquet6 > /dev/null;then echo "[+]Creating Folder for iptv and rehashing...";cat /etc/enigma2/bouquets.tv | sed -n 1p > /etc/enigma2/new_bouquets.tv;echo '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.'$bouquet6'" ORDER BY bouquet' >> /etc/enigma2/new_bouquets.tv;cat /etc/enigma2/bouquets.tv | sed -n '2,$p' >> /etc/enigma2/new_bouquets.tv;rm /etc/enigma2/bouquets.tv;mv /etc/enigma2/new_bouquets.tv /etc/enigma2/bouquets.tv;fi;
echo "";
wget -qO /etc/enigma2/userbouquet."$bouquet7" $url7 > /dev/null;
if ! cat /etc/enigma2/bouquets.tv | grep -v grep | grep -c $bouquet7 > /dev/null;then echo "[+]Creating Folder for iptv and rehashing...";cat /etc/enigma2/bouquets.tv | sed -n 1p > /etc/enigma2/new_bouquets.tv;echo '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.'$bouquet7'" ORDER BY bouquet' >> /etc/enigma2/new_bouquets.tv;cat /etc/enigma2/bouquets.tv | sed -n '2,$p' >> /etc/enigma2/new_bouquets.tv;rm /etc/enigma2/bouquets.tv;mv /etc/enigma2/new_bouquets.tv /etc/enigma2/bouquets.tv;fi;
echo "";
wget -qO - http://127.0.0.1/web/servicelistreload?mode=0 > /dev/null;
wget -qO - http://127.0.0.1/web/servicelistreload?mode=1 > /dev/null;
wget -qO - http://127.0.0.1/web/servicelistreload?mode=2 > /dev/null;
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0
