#!/bin/sh
echo "*           ..:: G E N E L ::..           *";
echo "*******************************************";
echo "*   ..:: G Ü N C E L L E N İ Y O R ::..   *";
echo "*******************************************";
echo "";
audi06_1="userbouquet.DreamOSatIPTV_genel.tv"
echo "";
url1="http://depo.dreamosat.net/oZeL/DreamOSatIPTV/bouquets/$audi06_1";
echo "";
yol="/etc/enigma2/"
echo "";
wget $url1 -qO $yol$audi06_1 > /dev/null;
echo "";
wget -qO - http://127.0.0.1/web/servicelistreload?mode=0 > /dev/null;
wget -qO - http://127.0.0.1/web/servicelistreload?mode=1 > /dev/null;
wget -qO - http://127.0.0.1/web/servicelistreload?mode=2 > /dev/null;
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0
