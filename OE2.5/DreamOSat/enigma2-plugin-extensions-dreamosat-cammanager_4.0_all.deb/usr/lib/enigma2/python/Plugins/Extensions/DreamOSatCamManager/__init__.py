# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatCamManager/__init__.py
pass