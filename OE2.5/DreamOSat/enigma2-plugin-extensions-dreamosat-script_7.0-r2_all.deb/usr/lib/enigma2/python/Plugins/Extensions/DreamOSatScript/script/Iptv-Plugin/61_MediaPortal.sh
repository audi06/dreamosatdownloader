#!/bin/sh
# Coded by audi06_19 (c) (®) (©) 2017
# Support: www.dreamosat-forum.com
# E-Mail: admin@dreamosat-forum.com
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."

ping -q -c 1 -W 1 8.8.8.8 > /dev/null; 
if [ $? -eq 1 ]; 
then exit; 
fi;
sleep 1;

set -e
echo $FIN
cd /tmp
rm -rf *.txt
rm -rf *.deb
rm -rf *.ipk

KONTROL=$(opkg list-installed enigma2-plugin-extensions-mediaportal | awk '{ print $1 }')
curl -Lbo -s --max-time 10 http://dhwz.github.io/e2-mediaportal/version.txt | sed 4q >/tmp/version.txt
echo "MediaPortal VERSION"
cat /tmp/version.txt | sed 1q
echo "";
sleep 2;
MODEL=$(uname -n)
PORTALDEB=$(grep -i "deb" version.txt)
PORTALIPK=$(grep -i "ipk" version.txt)

if [ "$KONTROL" = "enigma2-plugin-extensions-mediaportal" ]; then
echo "MediaPortal yüklü, tekrar yüklenmesine gerek yok ..."
else

echo "MediaPortal ISNTALL EDILIYOR ..."
echo "Sistem Kontrol Ediliyor ..."

sleep 2;
if [ -f /etc/apt/apt.conf ] ; then
echo ":DREAMBOX OE2.5 IMAGES"
if grep -qs 'armhf' cat /etc/apt/apt.conf ; then
echo "${MODEL} ARMHF"
curl -Lbo -s --max-time 20 http://debfeed4.merlin.xyz/oe_2.5/deb/dm900/merlin4-plugins/ | grep -o 'python-merlin4[^<]*' >/tmp/python-merlin4.txt
sed -i -E 's|(.*>)(.*)|\2\n&|' /tmp/python-merlin4.txt
sed 1q /tmp/python-merlin4.txt >/tmp/merlin4.txt
merlin4=$(cat /tmp/merlin4.txt)
echo "merlin4-covercollection download";
curl -Lbo -s --max-time 20 http://debfeed4.merlin.xyz/oe_2.5/deb/dm900/merlin4-plugins/$merlin4 -o $merlin4
sleep 1;
echo "MediaPortal download";
curl -Lbo -s --max-time 20 $PORTALDEB -o/tmp/enigma2-plugin-extensions-mediaportal_all.deb
sleep 1;
echo "Sistem Update";
apt-get update > /dev/null;
sleep 1;
echo "merlin4-covercollection install";
echo "y" | dpkg --install --force-depends --force-overwrite python-merlin4-covercollection* > /dev/null;
sleep 1;
echo "MediaPortal install";
echo "y" | dpkg --install --force-depends --force-overwrite enigma2-plugin-extensions-mediaportal* > /dev/null;
sleep 1;
echo "y" | apt-get -f install > /dev/null;
############################################################################

if grep -qs 'mipsel' cat /etc/apt/apt.conf ; then
echo " ${MODEL} MIPSEL IMAGES"
curl -Lbo -s --max-time 20 http://debfeed4.merlin.xyz/oe_2.5/deb/merlin4-plugins/ | grep -o 'python-merlin4[^<]*' >/tmp/python-merlin4.txt
sed -i -E 's|(.*>)(.*)|\2\n&|' /tmp/python-merlin4.txt
sed 1q /tmp/python-merlin4.txt >/tmp/merlin4.txt
merlin4=$(cat /tmp/merlin4.txt)
curl -Lbo -s --max-time 20 http://debfeed4.merlin.xyz/oe_2.5/deb/merlin4-plugins/$merlin4 -o $merlin4
sleep 1;
echo "merlin4-covercollection download";
curl -Lbo -s --max-time 20 $PORTALDEB -o/tmp/enigma2-plugin-extensions-mediaportal_all.deb
sleep 1;
echo "MediaPortal download";
apt-get update > /dev/null;
sleep 1;
echo "Sistem Update";
echo "y" | dpkg --install --force-depends --force-overwrite python-merlin4-covercollection* > /dev/null;
sleep 1;
echo "merlin4-covercollection install";
echo $LINE
echo "y" | dpkg --install --force-depends --force-overwrite enigma2-plugin-extensions-mediaportal* > /dev/null;
echo $LINE
sleep 1;
echo "MediaPortal install";
echo "y" | apt-get -f install > /dev/null;
############################################################################
fi
fi
else

if [ -f /etc/opkg/opkg.conf ] ; then
echo "ALL ${MODEL} MIPSEL OE-2.0 IMAGES"
sleep 1;
echo "MediaPortal download";
wget -q 
curl -Lbo -s --max-time 20 $PORTALIPK -o/tmp/enigma2-plugin-extensions-mediaportal_all.ipk
sleep 1;
echo "Sistem Update";
opkg update > /dev/null;
sleep 1;
echo "MediaPortal install";
opkg install -force-overwrite enigma2-plugin-extensions-mediaportal* > /dev/null;

else
echo "MediaPortal error "
fi
fi
fi
set +e
rm -rf *.txt
rm -rf *.deb
rm -rf *.ipk
sync
echo "";
echo "MediaPortal INSTALLED SUCCESSFULLY"
echo "PLEASE RESTART YOUR STB"
echo "===========================================";
echo "           ..:: A U T H O R ::..           ";
echo "              << audi06_19 >>              ";
echo "   ..:: https://dreamosat-forum.com ::..   ";
echo "===========================================";
sleep 3;
exit 0 


