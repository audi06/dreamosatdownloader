#!/bin/sh
# Coded by audi06_19 (c) (®) (©) 2017
# Support: www.dreamosat-forum.com
# E-Mail: admin@dreamosat-forum.com
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."

curl -Lbo -s --max-time 10 http://dreamosat.net/depo/Settings/satellitesxml/satellites.xml -o/etc/tuxbox/satellites.xml
chmod 0755 /etc/tuxbox/satellites.xml -R;
echo $FIN
wget -qO - http://127.0.0.1/web/servicelistreload?mode=0 > /dev/null;
wget -qO - http://127.0.0.1/web/servicelistreload?mode=1 > /dev/null;
wget -qO - http://127.0.0.1/web/servicelistreload?mode=2 > /dev/null;
echo "Satellites.xlm güncellendi";
echo ""
echo "Uydu alıcınızı Restart Etmeyi Unutmayınız. iyi seyirler...";
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0
