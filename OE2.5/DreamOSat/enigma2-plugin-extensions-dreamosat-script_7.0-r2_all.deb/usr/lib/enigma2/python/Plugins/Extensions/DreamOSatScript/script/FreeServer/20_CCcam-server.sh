#!/bin/sh
# Coded by audi06_19 (c) (®) (©) 2017
# Support: www.dreamosat-forum.com
# E-Mail: admin@dreamosat-forum.com
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."

ping -q -c 1 -W 1 8.8.8.8 > /dev/null; 
if [ $? -eq 1 ]; 
then exit; 
fi;
sleep 1;

URL="https://dreamosat-forum.com"
URL1="http://cccamgenerators.com/generators/get.php"
URL2="http://cccamgood.com/free/get2.php"
URL3="http://cccam-free.com/NEW/new0.php"
URL4="http://www.boss-cccam.com/Test.php"
URL5="http://www.cccamlux.com/Free-CCcam.php"
URL6="http://cccamgate.com/cccam-test.php"
URL7="http://cccamspot.com/spot/get.php"
URL8="http://infosat.satunivers.tv/download1.php?file=srtx5.txt"
URL9="http://cccamgenerador.com/gratis/get2.php"
URL10="http://freeccamserver.com/free/get2.php"
URL11="http://cccammania.com/free4/get2.php"
URL12="http://cccam-free2.com/free2/get.php"
URL13="http://free-cccam.com/freecccam/get.php"
URL14="http://cccamia.com/NEW/new0.php"
URL15="http://powerfullcccam.com/powerfull/get.php"
URL16="http://free-cccam.com/freecccam/get.php"
URL17="http://cccampowerful.com/freepowerful/get.php"
URL18="http://cccamfreeserver.com/free/get.php"
URL19=""


EMU="/etc/CCcam.cfg"
EMU1="/usr/keys/CCcam.cfg"
EMU_CP="/etc/CCcam-1.cfg"

if grep -qs -i 'C: ' cat $EMU ; then
   cp -rd $EMU $EMU_CP > /dev/null 2>&1
   echo $FIN
   echo "ETC içerisinden, CCcam.cfg Yedek alındı..."
   echo "CCcam.cfg Backup taken ..."
   echo $FIN
else
   echo "ETC içerisinden, CCcam.cfg Yedek alınamadı..."
   echo "CCcam.cfg Failed to backup ..."
   echo $FIN
fi

rm -rf $EMU > /dev/null 2>&1
rm -rf $EMU1 > /dev/null 2>&1

cat > $EMU << EOF
#### "*******************************************"
#### "*          ..:: A U T H O R ::..          *"
#### "*             << audi06_19 >>             *"
#### "*  ..:: https://dreamosat-forum.com ::..  *"
#### "*******************************************"

EOF
chmod 755 $EMU $EMU1 > /dev/null 2>&1

echo "DATE server" $URL1
curl -Lbo -s --max-time 10 $URL1 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL2
curl -Lbo -s --max-time 10 $URL2 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL3
curl -Lbo -s --max-time 10 $URL3 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL4
curl -Lbo -s --max-time 10 $URL4 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL5
curl -Lbo -s --max-time 10 $URL5 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL6
curl -Lbo -s --max-time 10 $URL6 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL7
curl -Lbo -s --max-time 10 $URL7 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL8
curl -Lbo -s --max-time 10 $URL8 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL9
curl -Lbo -s --max-time 10 $URL9 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL10
curl -Lbo -s --max-time 10 $URL10 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL11
curl -Lbo -s --max-time 10 $URL11 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL12
curl -Lbo -s --max-time 10 $URL12 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL13
curl -Lbo -s --max-time 10 $URL13 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL14
curl -Lbo -s --max-time 10 $URL14 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL15
curl -Lbo -s --max-time 10 $URL15 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL16
curl -Lbo -s --max-time 10 $URL16 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL17
curl -Lbo -s --max-time 10 $URL17 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL18
curl -Lbo -s --max-time 10 $URL18 | grep -o -i 'C:[^<]*' >>$EMU

#echo "DATE server" $URL19
#curl -Lbo -s $URL19 | grep -o -i 'C:[^<]*' >>$EMU

dos2unix $EMU $EMU1 > /dev/null 2>&1

if grep -qs 'C: ' cat $EMU ; then
sed -i -e 's/port: //g' -e 's/user: //g' -e 's/pass: //g' -e 's/c: /C: /g' $EMU
echo $FIN
echo "C+Line server indirildi, etc, usr/keys içerisine yazıldı..."
echo "C+Line server downloaded, it was written in /etc, usr/keys ...";
echo "" >> $EMU
echo "######################################################" >> $EMU
echo "WEBINFO USERNAME :" >> $EMU
echo "WEBINFO PASSWORD :" >> $EMU
echo "ALLOW WEBINFO: yes" >> $EMU
echo "WEBINFO LISTEN PORT : 16001" >> $EMU
echo "CHANNELINFO FILE : /etc/CCcam.channelinfo" >> $EMU
echo "CAID PRIO FILE : /etc/CCcam.prio" >> $EMU
echo "PROVIDERINFO FILE : /etc/CCcam.providers" >> $EMU
echo "STATIC CW FILE : /usr/keys/constant.cw" >> $EMU
echo "SOFTKEY FILE : /usr/keys/SoftCam.Key" >> $EMU
echo "AUTOROLL FILE : /usr/keys/AutoRoll.Key" >> $EMU
cp -rd $EMU $EMU1
else
      if [ -f /etc/CCcam.cfg ] ; then
         cp -rd $EMU_CP $EMU
	 cp -rd $EMU_CP $EMU1
      else
         echo $FIN
      fi
   echo "Server Off, bağlantı kurulamadı..."
   echo "Server Off, unable to connect ...";
   echo $FIN
   echo "C+Line server Yedek geri yuklendi..."
   echo "C+Line server Backup uploaded back ..."
fi

echo $FIN
echo "DreamOSat camManager Restart Etmeyi Unutmayınız. iyi seyirler...";
echo "Do not forget to restart DreamOSat camManager. good looking ...";
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0

