#!/bin/sh
# Coded by audi06_19 (c) (®) (©) 2017
# Support: www.dreamosat-forum.com
# E-Mail: admin@dreamosat-forum.com
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."

ping -q -c 1 -W 1 8.8.8.8 > /dev/null; 
if [ $? -eq 1 ]; 
then exit; 
fi;
sleep 1;

rm -rf /tmp/DreamOSat
[ -d /tmp/DreamOSat ] || mkdir -p /tmp/DreamOSat > /dev/null;
[ -d /etc/tuxbox/config ] || mkdir -p /etc/tuxbox/config > /dev/null;
cd /tmp/DreamOSat
################################### FIND-OSCAM.SERVER ####################################
> /tmp/DreamOSat/Your-oscam.server-Location
find /usr/keys/ /var/keys/ /etc -iname oscam.server > /tmp/DreamOSat/Your-oscam.server-Location
        echo $FIN
        echo "Cihazınızda yüklü oscam.server dosyalarını arıyorum..."
	echo "I'am looking for your oscam.server file/s hold on a sec"
if [ -s /tmp/DreamOSat/Your-oscam.server-Location ]
then
        echo $FIN
        echo "Aşağıdaki konumda oscam.server dosyanızı buldum ;)"
        echo "Found oscam.server file/s in the following location/s ;)"
	echo "--------------------------------------------";
        cat /tmp/DreamOSat/Your-oscam.server-Location
	echo "--------------------------------------------";
	echo $FIN
else
        echo $FIN
        echo "Cihazınızda yüklü oscam.server dosyası yok ????"
        echo "I can't find your oscam.server file have you got one ????"
        echo $FIN
        echo "/etc/tuxbox/config/ içerisine oscam.server dosyası oluşturuyorum..."
        echo "I am creating an oscam.server file in /etc/tuxbox/config/ ..."
fi
######################################################################################
EMU="/tmp/DreamOSat/cline"
EMU1="/etc/tuxbox/config/oscam.server"

URL="https://dreamosat-forum.com"
URL1="http://www.mycccam24.com/chk1.php"
URL2="http://www.mycccam24.com/chk2.php"
URL3="http://www.mycccam24.com/chk3.php"
URL4="http://www.mycccam24.com/chk4.php"
URL5="http://www.mycccam24.com/chk5.php"
URL6="http://mecccam.com/free-cccam.php"
URL7="http://cccamgood.com/free/get2.php"
URL8="http://cccam-free.com/NEW/new0.php"
URL9="http://www.boss-cccam.com/Test.php"
URL10="http://cccamgenerators.com/generators/get.php"
URL11="http://cccamgate.com/cccam-test.php"
URL12="http://cccamspot.com/spot/get.php"
URL13="http://infosat.satunivers.tv/download1.php?file=srtx5.txt"
URL14="http://cccamgenerador.com/gratis/get2.php"
URL15="http://freeccamserver.com/free/get2.php"
URL16="http://cccammania.com/free4/get2.php"
URL17="http://cccam-free2.com/free2/get.php"
URL18="http://free-cccam.com/freecccam/get.php"
URL19="http://www.cccam24.de/free24/get.php"
URL20="http://powerfullcccam.com/powerfull/get.php"
URL21="http://free-cccam.com/freecccam/get.php"
URL22="http://cccampowerful.com/freepowerful/get.php"
URL23="http://cccamfreeserver.com/free/get.php"
URL24="http://uhdcccam.com/free/get.php"
URL25="http://mecccam.com/free-cccam.php"
URL26="http://www.cccamproviders.com/freeproviders/get.php"
URL27="http://cccamstrong.com/freestrong/get.php"
URL28="https://cccam-full.com/freecccam.php"
URL29="http://www.cccamlux.com/Free-CCcam.php"
URL30="http://cccam.ch/free/get.php"
URL31="http://mecccam.com/free-cccam.php"

echo "DATE server 1"
curl -Lbo -s --max-time 10 $URL1 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server 2"
curl -Lbo -s --max-time 10 $URL2 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server 3"
curl -Lbo -s --max-time 10 $URL3 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server 4"
curl -Lbo -s --max-time 10 $URL4 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server 5"
curl -Lbo -s --max-time 10 $URL5 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server 6"
curl -Lbo -s --max-time 10 $URL6 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server 7"
curl -Lbo -s --max-time 10 $URL7 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server 8"
curl -Lbo -s --max-time 10 $URL8 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server 9"
curl -Lbo -s --max-time 10 $URL9 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server 10"
curl -Lbo -s --max-time 10 $URL10 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server 11"
curl -Lbo -s --max-time 10 $URL11 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server 12"
curl -Lbo -s --max-time 10 $URL12 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server 13"
curl -Lbo -s --max-time 10 $URL13 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server 14"
curl -Lbo -s --max-time 10 $URL14 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server 15"
curl -Lbo -s --max-time 10 $URL15 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server 16"
curl -Lbo -s --max-time 10 $URL16 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server 17"
curl -Lbo -s --max-time 10 $URL17 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server 18"
curl -Lbo -s --max-time 10 $URL18 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server 19"
curl -Lbo -s --max-time 10 $URL19 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server 20"
curl -Lbo -s --max-time 10 $URL20 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server 21"
curl -Lbo -s --max-time 10 $URL21 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server 22"
curl -Lbo -s --max-time 10 $URL22 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server 23"
curl -Lbo -s --max-time 10 $URL23 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server 24"
curl -Lbo -s --max-time 10 $URL24 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server 25"
curl -Lbo -s --max-time 10 $URL25 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server 26"
curl -Lbo -s --max-time 10 $URL26 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server 27"
curl -Lbo -s --max-time 10 $URL27 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server 28"
curl -Lbo -s --max-time 10 $URL28 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server 29"
curl -Lbo -s --max-time 10 $URL29 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server 30"
curl -Lbo -s --max-time 10 $URL30 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server 31"
curl -Lbo -s --max-time 10 $URL31 | grep -o -i 'C:[^<]*' >>$EMU

sleep 1
if grep -qs 'C: ' cat $EMU ; then
sed -i -e 's/port: //g' -e 's/user: //g' -e 's/pass: //g' -e 's/c: /C: /g' $EMU

awk '{print "[reader]"}' cline >>reader
awk '{print "label                         = " $2 }' cline >>label
awk '{print "protocol                      = cccam" }' cline >>protocol
awk '{print "device                        = " $2 "," $3 }' cline >>device
awk '{print "user                          = " $4 }' cline >>user
awk '{print "password                      = " $5 }' cline >>password
awk '{print "inactivitytimeout             = 30" }' cline >>inactivitytimeout
awk '{print "group                         = 1" }' cline >>group
awk '{print "cccversion                    = 2.2.1" }' cline >>cccversion
awk '{print "cccmaxhops                    = 3" }' cline >>cccmaxhop
awk '{print "ccckeepalive                  = 1" }' cline >>ccckeepalive
awk '{print "audisabled                    = 1" }' cline >>audisabled
awk '{print "disablecrccws                 = 1" }' cline >>disablecrccws
sleep 1
echo "" >> oscam.server
sed -n '1,1p' reader >> oscam.server
sed -n '1,1p' label >> oscam.server
sed -n '1,1p' protocol >> oscam.server
sed -n '1,1p' device >> oscam.server
sed -n '1,1p' user >> oscam.server
sed -n '1,1p' password >> oscam.server
sed -n '1,1p' inactivitytimeout >> oscam.server
sed -n '1,1p' cccversion >> oscam.server
sed -n '1,1p' group >> oscam.server
sed -n '1,1p' cccmaxhop >> oscam.server
sed -n '1,1p' ccckeepalive >> oscam.server
sed -n '1,1p' audisabled >> oscam.server
sed -n '1,1p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '2,2p' reader >> oscam.server
sed -n '2,2p' label >> oscam.server
sed -n '2,2p' protocol >> oscam.server
sed -n '2,2p' device >> oscam.server
sed -n '2,2p' user >> oscam.server
sed -n '2,2p' password >> oscam.server
sed -n '2,2p' inactivitytimeout >> oscam.server
sed -n '2,2p' cccversion >> oscam.server
sed -n '2,2p' group >> oscam.server
sed -n '2,2p' cccmaxhop >> oscam.server
sed -n '2,2p' ccckeepalive >> oscam.server
sed -n '2,2p' audisabled >> oscam.server
sed -n '2,2p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '3,3p' reader >> oscam.server
sed -n '3,3p' label >> oscam.server
sed -n '3,3p' protocol >> oscam.server
sed -n '3,3p' device >> oscam.server
sed -n '3,3p' user >> oscam.server
sed -n '3,3p' password >> oscam.server
sed -n '3,3p' inactivitytimeout >> oscam.server
sed -n '3,3p' cccversion >> oscam.server
sed -n '3,3p' group >> oscam.server
sed -n '3,3p' cccmaxhop >> oscam.server
sed -n '3,3p' ccckeepalive >> oscam.server
sed -n '3,3p' audisabled >> oscam.server
sed -n '3,3p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '4,4p' reader >> oscam.server
sed -n '4,4p' label >> oscam.server
sed -n '4,4p' protocol >> oscam.server
sed -n '4,4p' device >> oscam.server
sed -n '4,4p' user >> oscam.server
sed -n '4,4p' password >> oscam.server
sed -n '4,4p' inactivitytimeout >> oscam.server
sed -n '4,4p' cccversion >> oscam.server
sed -n '4,4p' group >> oscam.server
sed -n '4,4p' cccmaxhop >> oscam.server
sed -n '4,4p' ccckeepalive >> oscam.server
sed -n '4,4p' audisabled >> oscam.server
sed -n '4,4p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '5,5p' reader >> oscam.server
sed -n '5,5p' label >> oscam.server
sed -n '5,5p' protocol >> oscam.server
sed -n '5,5p' device >> oscam.server
sed -n '5,5p' user >> oscam.server
sed -n '5,5p' password >> oscam.server
sed -n '5,5p' inactivitytimeout >> oscam.server
sed -n '5,5p' cccversion >> oscam.server
sed -n '5,5p' group >> oscam.server
sed -n '5,5p' cccmaxhop >> oscam.server
sed -n '5,5p' ccckeepalive >> oscam.server
sed -n '5,5p' audisabled >> oscam.server
sed -n '5,5p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '6,6p' reader >> oscam.server
sed -n '6,6p' label >> oscam.server
sed -n '6,6p' protocol >> oscam.server
sed -n '6,6p' device >> oscam.server
sed -n '6,6p' user >> oscam.server
sed -n '6,6p' password >> oscam.server
sed -n '6,6p' inactivitytimeout >> oscam.server
sed -n '6,6p' cccversion >> oscam.server
sed -n '6,6p' group >> oscam.server
sed -n '6,6p' cccmaxhop >> oscam.server
sed -n '6,6p' ccckeepalive >> oscam.server
sed -n '6,6p' audisabled >> oscam.server
sed -n '6,6p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '7,7p' reader >> oscam.server
sed -n '7,7p' label >> oscam.server
sed -n '7,7p' protocol >> oscam.server
sed -n '7,7p' device >> oscam.server
sed -n '7,7p' user >> oscam.server
sed -n '7,7p' password >> oscam.server
sed -n '7,7p' inactivitytimeout >> oscam.server
sed -n '7,7p' cccversion >> oscam.server
sed -n '7,7p' group >> oscam.server
sed -n '7,7p' cccmaxhop >> oscam.server
sed -n '7,7p' ccckeepalive >> oscam.server
sed -n '7,7p' audisabled >> oscam.server
sed -n '7,7p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '8,8p' reader >> oscam.server
sed -n '8,8p' label >> oscam.server
sed -n '8,8p' protocol >> oscam.server
sed -n '8,8p' device >> oscam.server
sed -n '8,8p' user >> oscam.server
sed -n '8,8p' password >> oscam.server
sed -n '8,8p' inactivitytimeout >> oscam.server
sed -n '8,8p' cccversion >> oscam.server
sed -n '8,8p' group >> oscam.server
sed -n '8,8p' cccmaxhop >> oscam.server
sed -n '8,8p' ccckeepalive >> oscam.server
sed -n '8,8p' audisabled >> oscam.server
sed -n '8,8p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '9,9p' reader >> oscam.server
sed -n '9,9p' label >> oscam.server
sed -n '9,9p' protocol >> oscam.server
sed -n '9,9p' device >> oscam.server
sed -n '9,9p' user >> oscam.server
sed -n '9,9p' password >> oscam.server
sed -n '9,9p' inactivitytimeout >> oscam.server
sed -n '9,9p' cccversion >> oscam.server
sed -n '9,9p' group >> oscam.server
sed -n '9,9p' cccmaxhop >> oscam.server
sed -n '9,9p' ccckeepalive >> oscam.server
sed -n '9,9p' audisabled >> oscam.server
sed -n '9,9p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '10,10p' reader >> oscam.server
sed -n '10,10p' label >> oscam.server
sed -n '10,10p' protocol >> oscam.server
sed -n '10,10p' device >> oscam.server
sed -n '10,10p' user >> oscam.server
sed -n '10,10p' password >> oscam.server
sed -n '10,10p' inactivitytimeout >> oscam.server
sed -n '10,10p' cccversion >> oscam.server
sed -n '10,10p' group >> oscam.server
sed -n '10,10p' cccmaxhop >> oscam.server
sed -n '10,10p' ccckeepalive >> oscam.server
sed -n '10,10p' audisabled >> oscam.server
sed -n '10,10p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '11,11p' reader >> oscam.server
sed -n '11,11p' label >> oscam.server
sed -n '11,11p' protocol >> oscam.server
sed -n '11,11p' device >> oscam.server
sed -n '11,11p' user >> oscam.server
sed -n '11,11p' password >> oscam.server
sed -n '11,11p' inactivitytimeout >> oscam.server
sed -n '11,11p' cccversion >> oscam.server
sed -n '11,11p' group >> oscam.server
sed -n '11,11p' cccmaxhop >> oscam.server
sed -n '11,11p' ccckeepalive >> oscam.server
sed -n '11,11p' audisabled >> oscam.server
sed -n '11,11p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '12,12p' reader >> oscam.server
sed -n '12,12p' label >> oscam.server
sed -n '12,12p' protocol >> oscam.server
sed -n '12,12p' device >> oscam.server
sed -n '12,12p' user >> oscam.server
sed -n '12,12p' password >> oscam.server
sed -n '12,12p' inactivitytimeout >> oscam.server
sed -n '12,12p' cccversion >> oscam.server
sed -n '12,12p' group >> oscam.server
sed -n '12,12p' cccmaxhop >> oscam.server
sed -n '12,12p' ccckeepalive >> oscam.server
sed -n '12,12p' audisabled >> oscam.server
sed -n '12,12p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '13,13p' reader >> oscam.server
sed -n '13,13p' label >> oscam.server
sed -n '13,13p' protocol >> oscam.server
sed -n '13,13p' device >> oscam.server
sed -n '13,13p' user >> oscam.server
sed -n '13,13p' password >> oscam.server
sed -n '13,13p' inactivitytimeout >> oscam.server
sed -n '13,13p' cccversion >> oscam.server
sed -n '13,13p' group >> oscam.server
sed -n '13,13p' cccmaxhop >> oscam.server
sed -n '13,13p' ccckeepalive >> oscam.server
sed -n '13,13p' audisabled >> oscam.server
sed -n '13,13p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '14,14p' reader >> oscam.server
sed -n '14,14p' label >> oscam.server
sed -n '14,14p' protocol >> oscam.server
sed -n '14,14p' device >> oscam.server
sed -n '14,14p' user >> oscam.server
sed -n '14,14p' password >> oscam.server
sed -n '14,14p' inactivitytimeout >> oscam.server
sed -n '14,14p' cccversion >> oscam.server
sed -n '14,14p' group >> oscam.server
sed -n '14,14p' cccmaxhop >> oscam.server
sed -n '14,14p' ccckeepalive >> oscam.server
sed -n '14,14p' audisabled >> oscam.server
sed -n '14,14p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '15,15p' reader >> oscam.server
sed -n '15,15p' label >> oscam.server
sed -n '15,15p' protocol >> oscam.server
sed -n '15,15p' device >> oscam.server
sed -n '15,15p' user >> oscam.server
sed -n '15,15p' password >> oscam.server
sed -n '15,15p' inactivitytimeout >> oscam.server
sed -n '15,15p' cccversion >> oscam.server
sed -n '15,15p' group >> oscam.server
sed -n '15,15p' cccmaxhop >> oscam.server
sed -n '15,15p' ccckeepalive >> oscam.server
sed -n '15,15p' audisabled >> oscam.server
sed -n '15,15p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '16,16p' reader >> oscam.server
sed -n '16,16p' label >> oscam.server
sed -n '16,16p' protocol >> oscam.server
sed -n '16,16p' device >> oscam.server
sed -n '16,16p' user >> oscam.server
sed -n '16,16p' password >> oscam.server
sed -n '16,16p' inactivitytimeout >> oscam.server
sed -n '16,16p' cccversion >> oscam.server
sed -n '16,16p' group >> oscam.server
sed -n '16,16p' cccmaxhop >> oscam.server
sed -n '16,16p' ccckeepalive >> oscam.server
sed -n '16,16p' audisabled >> oscam.server
sed -n '16,16p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '17,17p' reader >> oscam.server
sed -n '17,17p' label >> oscam.server
sed -n '17,17p' protocol >> oscam.server
sed -n '17,17p' device >> oscam.server
sed -n '17,17p' user >> oscam.server
sed -n '17,17p' password >> oscam.server
sed -n '17,17p' inactivitytimeout >> oscam.server
sed -n '17,17p' cccversion >> oscam.server
sed -n '17,17p' group >> oscam.server
sed -n '17,17p' cccmaxhop >> oscam.server
sed -n '17,17p' ccckeepalive >> oscam.server
sed -n '17,17p' audisabled >> oscam.server
sed -n '17,17p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '18,18p' reader >> oscam.server
sed -n '18,18p' label >> oscam.server
sed -n '18,18p' protocol >> oscam.server
sed -n '18,18p' device >> oscam.server
sed -n '18,18p' user >> oscam.server
sed -n '18,18p' password >> oscam.server
sed -n '18,18p' inactivitytimeout >> oscam.server
sed -n '18,18p' cccversion >> oscam.server
sed -n '18,18p' group >> oscam.server
sed -n '18,18p' cccmaxhop >> oscam.server
sed -n '18,18p' ccckeepalive >> oscam.server
sed -n '18,18p' audisabled >> oscam.server
sed -n '18,18p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '19,19p' reader >> oscam.server
sed -n '19,19p' label >> oscam.server
sed -n '19,19p' protocol >> oscam.server
sed -n '19,19p' device >> oscam.server
sed -n '19,19p' user >> oscam.server
sed -n '19,19p' password >> oscam.server
sed -n '19,19p' inactivitytimeout >> oscam.server
sed -n '19,19p' cccversion >> oscam.server
sed -n '19,19p' group >> oscam.server
sed -n '19,19p' cccmaxhop >> oscam.server
sed -n '19,19p' ccckeepalive >> oscam.server
sed -n '19,19p' audisabled >> oscam.server
sed -n '19,19p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '20,20p' reader >> oscam.server
sed -n '20,20p' label >> oscam.server
sed -n '20,20p' protocol >> oscam.server
sed -n '20,20p' device >> oscam.server
sed -n '20,20p' user >> oscam.server
sed -n '20,20p' password >> oscam.server
sed -n '20,20p' inactivitytimeout >> oscam.server
sed -n '20,20p' cccversion >> oscam.server
sed -n '20,20p' group >> oscam.server
sed -n '20,20p' cccmaxhop >> oscam.server
sed -n '20,20p' ccckeepalive >> oscam.server
sed -n '20,20p' audisabled >> oscam.server
sed -n '20,20p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '21,21p' reader >> oscam.server
sed -n '21,21p' label >> oscam.server
sed -n '21,21p' protocol >> oscam.server
sed -n '21,21p' device >> oscam.server
sed -n '21,21p' user >> oscam.server
sed -n '21,21p' password >> oscam.server
sed -n '21,21p' inactivitytimeout >> oscam.server
sed -n '21,21p' cccversion >> oscam.server
sed -n '21,21p' group >> oscam.server
sed -n '21,21p' cccmaxhop >> oscam.server
sed -n '21,21p' ccckeepalive >> oscam.server
sed -n '21,21p' audisabled >> oscam.server
sed -n '21,21p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '22,22p' reader >> oscam.server
sed -n '22,22p' label >> oscam.server
sed -n '22,22p' protocol >> oscam.server
sed -n '22,22p' device >> oscam.server
sed -n '22,22p' user >> oscam.server
sed -n '22,22p' password >> oscam.server
sed -n '22,22p' inactivitytimeout >> oscam.server
sed -n '22,22p' cccversion >> oscam.server
sed -n '22,22p' group >> oscam.server
sed -n '22,22p' cccmaxhop >> oscam.server
sed -n '22,22p' ccckeepalive >> oscam.server
sed -n '22,22p' audisabled >> oscam.server
sed -n '22,22p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '23,23p' reader >> oscam.server
sed -n '23,23p' label >> oscam.server
sed -n '23,23p' protocol >> oscam.server
sed -n '23,23p' device >> oscam.server
sed -n '23,23p' user >> oscam.server
sed -n '23,23p' password >> oscam.server
sed -n '23,23p' inactivitytimeout >> oscam.server
sed -n '23,23p' cccversion >> oscam.server
sed -n '23,23p' group >> oscam.server
sed -n '23,23p' cccmaxhop >> oscam.server
sed -n '23,23p' ccckeepalive >> oscam.server
sed -n '23,23p' audisabled >> oscam.server
sed -n '23,23p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '24,24p' reader >> oscam.server
sed -n '24,24p' label >> oscam.server
sed -n '24,24p' protocol >> oscam.server
sed -n '24,24p' device >> oscam.server
sed -n '24,24p' user >> oscam.server
sed -n '24,24p' password >> oscam.server
sed -n '24,24p' inactivitytimeout >> oscam.server
sed -n '24,24p' cccversion >> oscam.server
sed -n '24,24p' group >> oscam.server
sed -n '24,24p' cccmaxhop >> oscam.server
sed -n '24,24p' ccckeepalive >> oscam.server
sed -n '24,24p' audisabled >> oscam.server
sed -n '24,24p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '25,25p' reader >> oscam.server
sed -n '25,25p' label >> oscam.server
sed -n '25,25p' protocol >> oscam.server
sed -n '25,25p' device >> oscam.server
sed -n '25,25p' user >> oscam.server
sed -n '25,25p' password >> oscam.server
sed -n '25,25p' inactivitytimeout >> oscam.server
sed -n '25,25p' cccversion >> oscam.server
sed -n '25,25p' group >> oscam.server
sed -n '25,25p' cccmaxhop >> oscam.server
sed -n '25,25p' ccckeepalive >> oscam.server
sed -n '25,25p' audisabled >> oscam.server
sed -n '25,25p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '26,26p' reader >> oscam.server
sed -n '26,26p' label >> oscam.server
sed -n '26,26p' protocol >> oscam.server
sed -n '26,26p' device >> oscam.server
sed -n '26,26p' user >> oscam.server
sed -n '26,26p' password >> oscam.server
sed -n '26,26p' inactivitytimeout >> oscam.server
sed -n '26,26p' cccversion >> oscam.server
sed -n '26,26p' group >> oscam.server
sed -n '26,26p' cccmaxhop >> oscam.server
sed -n '26,26p' ccckeepalive >> oscam.server
sed -n '26,26p' audisabled >> oscam.server
sed -n '26,26p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '27,27p' reader >> oscam.server
sed -n '27,27p' label >> oscam.server
sed -n '27,27p' protocol >> oscam.server
sed -n '27,27p' device >> oscam.server
sed -n '27,27p' user >> oscam.server
sed -n '27,27p' password >> oscam.server
sed -n '27,27p' inactivitytimeout >> oscam.server
sed -n '27,27p' cccversion >> oscam.server
sed -n '27,27p' group >> oscam.server
sed -n '27,27p' cccmaxhop >> oscam.server
sed -n '27,27p' ccckeepalive >> oscam.server
sed -n '27,27p' audisabled >> oscam.server
sed -n '27,27p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '28,28p' reader >> oscam.server
sed -n '28,28p' label >> oscam.server
sed -n '28,28p' protocol >> oscam.server
sed -n '28,28p' device >> oscam.server
sed -n '28,28p' user >> oscam.server
sed -n '28,28p' password >> oscam.server
sed -n '28,28p' inactivitytimeout >> oscam.server
sed -n '28,28p' cccversion >> oscam.server
sed -n '28,28p' group >> oscam.server
sed -n '28,28p' cccmaxhop >> oscam.server
sed -n '28,28p' ccckeepalive >> oscam.server
sed -n '28,28p' audisabled >> oscam.server
sed -n '28,28p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '29,29p' reader >> oscam.server
sed -n '29,29p' label >> oscam.server
sed -n '29,29p' protocol >> oscam.server
sed -n '29,29p' device >> oscam.server
sed -n '29,29p' user >> oscam.server
sed -n '29,29p' password >> oscam.server
sed -n '29,29p' inactivitytimeout >> oscam.server
sed -n '29,29p' cccversion >> oscam.server
sed -n '29,29p' group >> oscam.server
sed -n '29,29p' cccmaxhop >> oscam.server
sed -n '29,29p' ccckeepalive >> oscam.server
sed -n '29,29p' audisabled >> oscam.server
sed -n '29,29p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '30,30p' reader >> oscam.server
sed -n '30,30p' label >> oscam.server
sed -n '30,30p' protocol >> oscam.server
sed -n '30,30p' device >> oscam.server
sed -n '30,30p' user >> oscam.server
sed -n '30,30p' password >> oscam.server
sed -n '30,30p' inactivitytimeout >> oscam.server
sed -n '30,30p' cccversion >> oscam.server
sed -n '30,30p' group >> oscam.server
sed -n '30,30p' cccmaxhop >> oscam.server
sed -n '30,30p' ccckeepalive >> oscam.server
sed -n '30,30p' audisabled >> oscam.server
sed -n '30,30p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '31,31p' reader >> oscam.server
sed -n '31,31p' label >> oscam.server
sed -n '31,31p' protocol >> oscam.server
sed -n '31,31p' device >> oscam.server
sed -n '31,31p' user >> oscam.server
sed -n '31,31p' password >> oscam.server
sed -n '31,31p' inactivitytimeout >> oscam.server
sed -n '31,31p' cccversion >> oscam.server
sed -n '31,31p' group >> oscam.server
sed -n '31,31p' cccmaxhop >> oscam.server
sed -n '31,31p' ccckeepalive >> oscam.server
sed -n '31,31p' audisabled >> oscam.server
sed -n '31,31p' disablecrccws >> oscam.server
echo "" >> oscam.server
sleep 3;

cat > cline1 << EOF
#### "*******************************************"
#### "*          ..:: A U T H O R ::..          *"
#### "*             << audi06_19 >>             *"
#### "*  ..:: https://dreamosat-forum.com ::..  *"
#### "*******************************************"
EOF
sleep 1
cat >> oscam.server << EOF
####################### Emulator ############################

[reader]
label                         = constant.cw
enable                        = 1
protocol                      = constcw
device                        = /etc/tuxbox/config/constant.cw
caid                          = 2600,0B00,0B02,0500,0963,06AD,0940
group                         = 1

[reader]
label                         = emulator
protocol                      = emu
device                        = emulator
caid                          = 090F,0500,1801,0604,2600,FFFF,0E00,4AE1,1010
detect                        = cd
ident                         = 090F:000000;0500:000000,023800,021110,007400,007800;1801:000000,007301,001101,002111;0604:000000;2600:000000;FFFF:000000;0E00:000000;4AE1:000011,000014,0000FE;1010:000000
group                         = 1
emmcache                      = 1,5,31,1
saveemm-u                     = 1
emu_auproviders               = 0604:010200;0E00:000000;4AE1:000011,000014,0000FE;1010:000000
emu_datecodedenabled          = 1

[reader]
label                         = AFN
description                   = AFN-EMU
protocol                      = emu
device                        = Emulator
cacheex                       = 1
cacheex_maxhop                = 1
cacheex_allow_request         = 1
caid                          = 0E00
ecmwhitelist                  = 0E00:91
detect                        = cd
group                         = 1
emmcache                      = 1,5,31,1
emu_auproviders               = 0E00:000000
auprovid                      = 000E00

EOF
sleep 2
cat oscam.server >> cline1

mv cline1 $EMU1
  echo $FIN
  echo "C+Line server indirildi, /etc/tuxbox/config/oscam.server içerisine yazıldı ...";
  echo "C+Line server downloaded, it was written in /etc/tuxbox/config/oscam.server ...";
  sleep 2;
  echo $FIN
  echo "DreamOSat camManager Restart Etmeyi Unutmayınız. iyi seyirler ...";
  echo "Do not forget to restart DreamOSat camManager. good looking ...";
else
  echo $FIN
  echo "Server Off, bağlantı kurulamadı ..."
  echo "Server Off, unable to connect ...";
  echo $FIN
  echo "Teknik Destek İçin (www.dreamosat-forum.com) Yardım Alınız ...";
  echo "For Technical Support (www.dreamosat-forum.com) Get Help ...";
fi

cd /
rm -rf /tmp/DreamOSat

echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 2;
exit 0

