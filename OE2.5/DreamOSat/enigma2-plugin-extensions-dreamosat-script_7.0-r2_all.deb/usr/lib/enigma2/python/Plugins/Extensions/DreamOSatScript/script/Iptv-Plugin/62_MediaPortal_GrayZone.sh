#!/bin/sh
# Coded by audi06_19 (c) (®) (©) 2017
# Support: www.dreamosat-forum.com
# E-Mail: admin@dreamosat-forum.com
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."

ping -q -c 1 -W 1 8.8.8.8 > /dev/null; 
if [ $? -eq 1 ]; 
then exit; 
fi;
sleep 1;

set -e
echo $FIN
cd /tmp
rm -rf *.txt
rm -rf *.deb
rm -rf *.ipk

KONTROL=$(opkg list-installed enigma2-plugin-extensions-mediaportal | awk '{ print $1 }')
KONTROL0=$(opkg list-installed enigma2-plugin-extensions-mpgz | awk '{ print $1 }')
wget --quiet -O - http://feed.newnigma2.to/mpgz/version.txt | sed 4q >/tmp/version.txt
echo "GrayZone VERSION"
cat version.txt | sed 1q
sleep 2;
MODEL=$(uname -n)
PORTALDEB=$(grep -i "deb" version.txt)
PORTALIPK=$(grep -i "ipk" version.txt)

if [ "$KONTROL" = "enigma2-plugin-extensions-mediaportal" ]; then
if [ "$KONTROL0" = "enigma2-plugin-extensions-mpgz" ]; then
echo $FIN
echo "GrayZone yüklü, tekrar yüklenmesine gerek yok ..."
else
echo $FIN
echo "GrayZone ISNTALL EDILIYOR ..."
echo $FIN
echo "Sistem Kontrol Ediliyor ..."

sleep 2;
if [ -f /etc/apt/apt.conf ]; then
echo $FIN
echo ":DREAMBOX ${MODEL} OE2.5 IMAGES"

sleep 1;
echo $FIN
echo "GrayZone download";
curl -Lbo -s --max-time 20 $PORTALDEB -o/tmp/enigma2-plugin-extensions-mpgz_all.deb
sleep 1;
echo $FIN
echo "Sistem Update";
apt-get update > /dev/null;
sleep 1;
echo $FIN
echo "GrayZone install";
echo "y" | dpkg --install --force-depends --force-overwrite enigma2-plugin-extensions-mpgz* > /dev/null;
sleep 1;
echo "y" | apt-get -f install > /dev/null;
############################################################################

############################################################################
else

if [ -f /etc/opkg/opkg.conf ] ; then
echo "ALL ${MODEL} MIPSEL OE-2.0 IMAGES"

sleep 1;
echo $FIN
echo "GrayZone download";
curl -Lbo -s --max-time 20 $PORTALIPK -o/tmp/enigma2-plugin-extensions-mpgz_all.ipk
sleep 1;
echo $FIN
echo "Sistem Update";
opkg update > /dev/null;
sleep 1;
echo $FIN
echo "GrayZone install";
opkg install --force-overwrite enigma2-plugin-extensions-mpgz* > /dev/null;

else
echo "GrayZone error "
fi
fi
fi
fi
set +e
rm -rf *.txt
rm -rf *.deb
rm -rf *.ipk
sync
echo "";
echo "MediaPortal INSTALLED SUCCESSFULLY"
echo "PLEASE RESTART YOUR STB"
echo "===========================================";
echo "           ..:: A U T H O R ::..           ";
echo "              << audi06_19 >>              ";
echo "   ..:: https://dreamosat-forum.com ::..   ";
echo "===========================================";
sleep 3;
exit 0 


