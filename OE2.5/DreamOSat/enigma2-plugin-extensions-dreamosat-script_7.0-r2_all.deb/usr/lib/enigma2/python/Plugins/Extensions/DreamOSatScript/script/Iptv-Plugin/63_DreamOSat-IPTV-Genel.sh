#!/bin/sh
# Coded by audi06_19 (c) (®) (©) 2017
# Support: www.dreamosat-forum.com
# E-Mail: admin@dreamosat-forum.com
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."

ping -q -c 1 -W 1 8.8.8.8 > /dev/null; 
if [ $? -eq 1 ]; 
then exit; 
fi;
sleep 1;
echo $FIN
echo "           ..:: G E N E L ::..           ";
echo $FIN
echo "   ..:: G Ü N C E L L E N İ Y O R ::..   ";
echo $FIN
echo "";

sed -i '/userbouquet.DreamOSatIPTV_genel.tv/d' /etc/enigma2/bouquets.tv
sleep 1;
rm -rf /etc/enigma2/userbouquet.DreamOSatIPTV_genel.tv

curl -Lbo -s --max-time 10 http://depo.dreamosat.net/oZeL/DreamOSatIPTV/bouquets/userbouquet.DreamOSatIPTV_genel.tv -o/etc/enigma2/userbouquet.DreamOSatIPTV_genel.tv > /dev/null
sleep 2;
echo '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.DreamOSatIPTV_genel.tv" ORDER BY bouquet' >> /etc/enigma2/bouquets.tv
sleep 1;
wget -q -O - http://127.0.0.1/web/servicelistreload?mode=0 > /dev/null
wget -q -O - http://127.0.0.1/web/servicelistreload?mode=2 > /dev/null

# if grep -qs 'userbouquet.DreamOSatIPTV_genel.tv' cat /etc/enigma2/bouquets.tv
# then
# echo "Lista esistente in Bouquet"
# else
# echo "[+]Install IPTV LIST DreamOSat Forum ..."
# echo '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.DreamOSatIPTV_genel.tv" ORDER BY bouquet' >> /etc/enigma2/bouquets.tv
# fi
echo "";
echo "###### Thank you By. dreamosat-forum.com";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0

