#! /bin/sh

if [ -d /usr/keys ]; then
   KPATHCCCAM=/usr/keys
elif [ -d /var/keys ]; then
   KPATHCCCAM=/var/keys
elif [ -d /etc/emud/emu/keys ]; then
   KPATHCCCAM=/etc/emud/emu/keys
else
   echo " Warning! No valid path found for CCcam/MGcam keys."
   echo ""
fi

if [ -d /etc/tuxbox/config ]; then
   KPATHOSCAM=/etc/tuxbox/config
elif [ -d /var/tuxbox/config ]; then
   KPATHOSCAM=/var/tuxbox/config
else
   echo " Warning! No valid path found for Oscam keys."
   echo ""
fi

if [ -s $KPATHCCCAM/Changelog_info.txt ]; then
   cat $KPATHCCCAM/Changelog_info.txt
   echo "_____________________________"
   echo ""
   echo "End"
   echo ""
elif [ -s $KPATHOSCAM/Changelog_info.txt ]; then
   cat $KPATHOSCAM/Changelog_info.txt
   echo "_____________________________"
   echo ""
   echo "End"
   echo ""
else
   echo " Download Keys first!"
   echo ""
   exit 1
fi

exit 0

