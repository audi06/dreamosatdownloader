#!/bin/sh
# Coded by audi06_19 (c) (®) (©) 2017
# Support: www.dreamosat-forum.com
# E-Mail: admin@dreamosat-forum.com
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."
sleep 1;
echo "";
echo "pAnDaSAT_ITALIA";

ping -q -c 1 -W 1 8.8.8.8 > /dev/null; 
if [ $? -eq 1 ];
then exit; 
fi;
sed -i '/userbouquet.pAnDaSAT_ITALIA.tv/d' /etc/enigma2/bouquets.tv
echo "";
rm -rf /etc/enigma2/userbouquet.pAnDaSAT_ITALIA.tv

curl -Lbo -s --max-time 10 http://www.pandasat.info/iptv/e2liste/userbouquet.pAnDaSAT_ITALIA.tv -o/etc/enigma2/userbouquet.pAnDaSAT_ITALIA.tv
echo "";
echo '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.pAnDaSAT_ITALIA.tv" ORDER BY bouquet' >> /etc/enigma2/bouquets.tv

wget -q -O - http://127.0.0.1/web/servicelistreload?mode=0 > /dev/null
wget -q -O - http://127.0.0.1/web/servicelistreload?mode=2 > /dev/null

echo "";
echo "###### Thank you By. pAnDaSAT TEAM";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0
