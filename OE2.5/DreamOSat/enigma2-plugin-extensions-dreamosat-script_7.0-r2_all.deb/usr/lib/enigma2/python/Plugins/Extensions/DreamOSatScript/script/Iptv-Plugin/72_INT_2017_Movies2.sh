#!/bin/sh
# Coded by audi06_19 (c) (®) (©) 2017
# Support: www.dreamosat-forum.com
# E-Mail: admin@dreamosat-forum.com
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."

ping -q -c 1 -W 1 8.8.8.8 > /dev/null; 
if [ $? -eq 1 ]; 
then exit; 
fi;
sleep 1;

cd /;
[ -d /tmp/IPTV ] || mkdir -p /tmp/IPTV;
cd /tmp/IPTV;
sleep 1;

curl -Lbo -s --max-time 10 http://archive.is/tqTJu | grep -o 'href="[^"]*' > tqt ;sed -i '1,21d' tqt ;sed -i '832,852d' tqt ;sed -i 's/href="https:\/\/archive.is\/o\/tqTJu\//http:\/\//g' tqt ;sed -i 'h;s@\([^/]*/\)\{5\}@@;p;x;' tqt ;sed -i '1i #NAME INT 2017 Movies 2' tqt ;sed -i 's/^/#EXTINF:-1,/' tqt ;sed 's/#EXTINF:-1,//;N' < tqt > 2017.m3u & rm -rf tqt
sleep 2;

sed '/#EXTINF:-1,/!s/:/%3a/g' 2017.m3u >0
sed 's/#EXTINF:-1,/#DESCRIPTION: /g' 0 >00
sed '/#SERVICE 4097:0:1:0:0:0:0:0:0:0:rt/!s/http%3a/#SERVICE 4097:0:1:0:0:0:0:0:0:0:http%3a/' 00 >000
sed -n '/^#DES.*/h;/^#SER.*/{p;x;p};/^#NA.*/p' 000 >userbouquet.INT_2017_Movies_2.tv

echo 'DOWNLOAD'
sleep 1;
cp /tmp/IPTV/userbouquet.INT_2017_Movies_2.tv /etc/enigma2/userbouquet.INT_2017_Movies_2.tv > /dev/null

echo $LINE


if grep -qs 'userbouquet.INT_2017_Movies_2.tv' cat /etc/enigma2/bouquets.tv  ; then
    echo "Lista esistente in Bouquet"
else 
	echo "[+]Install INT 2017 Movies_2 ..."
	echo '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.INT_2017_Movies_2.tv" ORDER BY bouquet' >> /etc/enigma2/bouquets.tv
fi
cd /;
rm -rf /tmp/IPTV > /dev/null 2>&1
echo $LINE


wget -q -O - http://127.0.0.1/web/servicelistreload?mode=0 > /dev/null 2>&1
wget -q -O - http://127.0.0.1/web/servicelistreload?mode=2 > /dev/null 2>&1

echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0



