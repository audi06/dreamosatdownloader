#!/bin/sh
# Coded by audi06_19 (c) (®) (©) 2017
# Support: www.dreamosat-forum.com
# E-Mail: admin@dreamosat-forum.com
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."
echo "";
echo "Drivers Informations"
opkg list | grep dvb-modules
echo "";
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0
