#!/bin/sh
# Coded by audi06_19 (c) (®) (©) 2017
# Support: www.dreamosat-forum.com
# E-Mail: admin@dreamosat-forum.com
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."

ping -q -c 1 -W 1 8.8.8.8 > /dev/null; 
if [ $? -eq 1 ]; 
then exit; 
fi;
sleep 1;

cd /;
[ -d /tmp/IPTV ] || mkdir -p /tmp/IPTV;
cd /tmp/IPTV;
sleep 1;
curl -Lbo -s --max-time 10 http://www.pandasat.info/iptv/pAnDaSAT_Free_IPTV.m3u -o/tmp/IPTV/pAnDaSAT_Free_IPTV.m3
sleep 2;
sed 's/#EXTM3U/#NAME pAnDaSAT Free IPTV/;N' pAnDaSAT_Free_IPTV.m3u >IPTV.m3u
#sed -i '1i #NAME pAnDaSAT_Free_IPTV'
sed '/#EXTINF:-1,/!s/:/%3a/g' IPTV.m3u >0
sed 's/#EXTINF:-1,/#DESCRIPTION: /g' 0 >00
sed '/#SERVICE 4097:0:1:0:0:0:0:0:0:0:rt/!s/http%3a/#SERVICE 4097:0:1:0:0:0:0:0:0:0:http%3a/' 00 >000
sed -n '/^#DES.*/h;/^#SER.*/{p;x;p};/^#NA.*/p' 000 >userbouquet.pAnDaSAT_Free_IPTV.tv

echo "";
echo 'DOWNLOAD pAnDaSAT Free IPTV'
sleep 1;
cp /tmp/IPTV/userbouquet.pAnDaSAT_Free_IPTV.tv /etc/enigma2/userbouquet.pAnDaSAT_Free_IPTV.tv > /dev/null

echo $LINE


if grep -qs 'userbouquet.pAnDaSAT_Free_IPTV.tv' cat /etc/enigma2/bouquets.tv  ; then
    echo "Lista esistente in Bouquet"
else 
	echo "[+]Install pAnDaSAT Free IPTV ..."
	echo '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.pAnDaSAT_Free_IPTV.tv" ORDER BY bouquet' >> /etc/enigma2/bouquets.tv
fi
cd /;
rm -rf /tmp/IPTV > /dev/null 2>&1
echo $LINE


wget -q -O - http://127.0.0.1/web/servicelistreload?mode=0 > /dev/null 2>&1
wget -q -O - http://127.0.0.1/web/servicelistreload?mode=2 > /dev/null 2>&1

echo "";
echo "###### Thank you By. pAnDaSAT TEAM";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0



