#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."
cd /;
[ -d /etc/tuxbox/config/oscampowervu ] || mkdir -p /etc/tuxbox/config/oscampowervu;
[ -d /usr/keys ] || mkdir -p /usr/keys;
[ -d /tmp/keyupdate ] || mkdir -p /tmp/keyupdate;
sleep 1;
curl -Lbo -s --max-time 10 http://enigma.satupdate.net/SoftCam.txt -o/tmp/keyupdate/SoftCam.Key
sleep 2;
chmod 0755 /tmp/keyupdate/ -R;
sleep 1;
dos2unix /tmp/keyupdate/*
sleep 1;
cd /tmp/keyupdate;
cp SoftCam.Key /etc/tuxbox/config/;
cp SoftCam.Key /usr/keys/;
echo "";
cd /;
rm -rf /tmp/keyupdate;
echo $FIN
echo "SoftCam.Key ve constant.cw güncellendi";
echo "SoftCam.Key and constant.cw updated";
sleep 1;
echo $FIN
echo "EMU Restart Etmeyi Unutmayınız. iyi seyirler...";
echo "Do not forget to restart the EMU. good looking ...";
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0
