#!/bin/sh
# Coded by audi06_19 (c) (®) (©) 2017
# Support: www.dreamosat-forum.com
# E-Mail: admin@dreamosat-forum.com
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."
echo $FIN
echo "ecm.info:"
echo $FIN
if [ -e /tmp/ecm.info ]; then
    cat /tmp/ecm.info
else
    echo "No ecm.info found."
fi
echo ""
echo $FIN
echo "ecm1.info:"
echo $FIN
if [ -e /tmp/ecm1.info ]; then
    cat /tmp/ecm1.info
else
    echo "No ecm1.info found."
fi
echo ""
echo $FIN
echo "emm.info:"
echo $FIN
if [ -e /tmp/emm.info ]; then
    cat /tmp/emm.info
else
    echo "No emm.info found."
fi
echo ""
echo $FIN
echo "pid.info:"
echo $FIN
if [ -e /tmp/pid.info ]; then
    cat /tmp/pid.info
else
    echo "No pid.info found."
fi
echo ""
echo $FIN
echo "";
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0
