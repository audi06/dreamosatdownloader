#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."
cd /;
echo $FIN
echo "Key Downloader for E2"
echo "Now update Keys..."
echo $FIN
#keys 
echo "SoftCam.Key Downloader"
curl -Lbo -s --max-time 20 http://www.softcam.org/deneme6.php?file=SoftCam.Key -o/tmp/SoftCam.Key
echo "AutoRoll.Key Downloader"
curl -Lbo -s --max-time 20 http://www.softcam.org/deneme6.php?file=AutoRoll.Key -o/tmp/AutoRoll.Key
echo "constant.cw Downloader"
curl -Lbo -s --max-time 20 http://www.softcam.org/deneme6.php?file=constant.cw -o/tmp/constant.cw

#find /tmp/SoftCam.Key
#find /tmp/AutoRoll.Key
sleep 1;
dos2unix /tmp/SoftCam.Key
dos2unix /tmp/AutoRoll.Key
dos2unix /tmp/constant.cw

chmod 644 /tmp/SoftCam.Key
chmod 644 /tmp/AutoRoll.Key
chmod 644 /tmp/constant.cw

cp /tmp/SoftCam.Key /usr/keys/
cp /tmp/AutoRoll.Key /usr/keys/
cp /tmp/constant.cw /usr/keys/
cp /tmp/SoftCam.Key /etc/tuxbox/config/
cp /tmp/constant.cw /etc/tuxbox/config/

rm -rf /tmp/SoftCam.Key
rm -rf /tmp/AutoRoll.Key
rm -rf /tmp/constant.cw

echo "Keys Downloaded"
echo " www.softcam.tv"
echo $FIN
echo "SoftCam.Key ve constant.cw güncellendi";
echo "SoftCam.Key and constant.cw updated";
echo $FIN
echo "EMU Restart Etmeyi Unutmayınız. iyi seyirler...";
echo "Do not forget to restart the EMU. good looking ...";
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0
