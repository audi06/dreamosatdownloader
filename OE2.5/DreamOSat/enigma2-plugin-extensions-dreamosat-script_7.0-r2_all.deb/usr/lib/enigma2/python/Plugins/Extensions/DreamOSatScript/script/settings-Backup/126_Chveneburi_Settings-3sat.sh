#!/bin/sh
# Coded by audi06_19 (c) (®) (©) 2017
# Support: www.dreamosat-forum.com
# E-Mail: admin@dreamosat-forum.com
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."

ping -q -c 1 -W 1 8.8.8.8 > /dev/null; 
if [ $? -eq 1 ]; 
then exit; 
fi;
sleep 1;

rm -rf /tmp/DreamOSat
[ -d /tmp/DreamOSat ] || mkdir -p /tmp/DreamOSat > /dev/null;
cd /tmp/DreamOSat
######################################################################################
SUPPORT="http://dreamosat.net/depo/Settings"
WGET1=$(wget -q "$SUPPORT/VERSION")
sleep 2
######################################################################################
if [ -e VERSION ]; then
source /tmp/DreamOSat/VERSION

HAZIRLAYAN_1=$(echo "$HAZIRLAYAN_1")
KANAL_SETTINGS_3=$(echo "$KANAL_SETTINGS_3")
TARGET_DATE_1=$(echo "$TARGET_DATE_1")
######################################################################################
WGET2=$(wget -q "$SUPPORT/$HAZIRLAYAN_1/enigma2-settings-$HAZIRLAYAN_1-$KANAL_SETTINGS_3-$TARGET_DATE_1.zip")
sleep 2
if [ -e enigma2-settings-$HAZIRLAYAN_1-$KANAL_SETTINGS_3-$TARGET_DATE_1.zip ]; then

echo $FIN
echo "$KANAL_SETTINGS_3-$TARGET_DATE_1 Settings Download";
echo $FIN
echo "extract archive"
unzip -qo enigma2-settings-$HAZIRLAYAN_1-$KANAL_SETTINGS_3-$TARGET_DATE_1.zip > /dev/null;
sleep 2
echo $FIN
echo "Delete archive /etc/enigma2/*"
rm -rf /etc/enigma2/*.tv
rm -rf /etc/enigma2/*.radio
rm -rf /etc/enigma2/blacklist
rm -rf /etc/enigma2/lamedb
rm -rf /etc/enigma2/satellites.xml
rm -rf /etc/enigma2/whitelist
rm -rf /etc/tuxbox/satellites.xml
sleep 2
echo $FIN
echo "Copy archive /etc/enigma2/*"
cp -rd enigma2-settings-*/* /etc/enigma2/
cp -rd /etc/enigma2/satellites.xml /etc/tuxbox/;

chmod 0755 /etc/tuxbox/satellites.xml -R;
rm -rf /etc/tuxbox/satellites.xml
echo "";
echo "### Settings Thank you By. $HAZIRLAYAN_1 (c)";

wget -qO - http://127.0.0.1/web/servicelistreload?mode=0 > /dev/null;
wget -qO - http://127.0.0.1/web/servicelistreload?mode=1 > /dev/null;
wget -qO - http://127.0.0.1/web/servicelistreload?mode=2 > /dev/null;

else
  echo $FIN
echo 'Üzgünüm, cihazınıza uygun SETTINGS yok :('
echo 'Sorry, your device does not have the proper SETTINGS :('
fi
else
  echo $FIN
  echo "Server Off, bağlantı kurulamadı ..."
  echo "Server Off, unable to connect ...";
  echo $FIN
  echo "Teknik Destek için (www.dreamosat-forum.com) Yardım Alınız ...";
  echo "For Technical Support (www.dreamosat-forum.com) Get Help ...";
fi
rm -rf /tmp/DreamOSat
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
exit 0

