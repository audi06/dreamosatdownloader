#!/bin/sh
# Coded by audi06_19 (c) (®) (©) 2017
# Support: www.dreamosat-forum.com
# E-Mail: admin@dreamosat-forum.com
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."

ping -q -c 1 -W 1 8.8.8.8 > /dev/null; 
if [ $? -eq 1 ]; 
then exit; 
fi;
sleep 1;

[ -d /usr/keys ] || mkdir -p /usr/keys > /dev/null;
######################################################################################
# http://dreamosat.net/depo/CaMs-EmU/FreeServer/cccam3.com_mgcamd.txt
WGET1="http://dreamosat.net/depo/CaMs-EmU/FreeServer/cccam3.com_mgcamd.txt"
#EMU="/usr/keys/newcamd.list"
#EMU1="/usr/keys/newcamd-2.list"
#EMU_CP="/usr/keys/newcamd-1.list"


curl -Lbo -s --max-time 10 $WGET1 -o/usr/keys/newcamd.list

#cd /
#rm -rf /tmp/DreamOSat

echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 2;
exit 0
