#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."
cd /;
[ -d /etc/tuxbox/config/oscampowervu ] || mkdir -p /etc/tuxbox/config/oscampowervu;
[ -d /usr/keys ] || mkdir -p /usr/keys;
[ -d /tmp/keyupdate ] || mkdir -p /tmp/keyupdate;
curl -Lbo -s --max-time 10 http://www.pandasat.info/Informed/scriptDoscam/SoftCam.Key -o/tmp/keyupdate/SoftCam.Key
sleep 2;
dos2unix /tmp/keyupdate/*
sleep 1;
chmod 0755 /tmp/keyupdate/* -R;
cd /tmp/keyupdate;
cp -rd SoftCam.Key /etc/tuxbox/config/;
cp -rd SoftCam.Key /usr/keys/;
echo "";
sleep 1;
cd /;
rm -rf /tmp/keyupdate;
echo "SoftCam.Key güncellendi";
echo "SoftCam.Key updated";
echo $FIN
sleep 1;
echo "EMU Restart Etmeyi Unutmayınız. iyi seyirler...";
echo "Do not forget to restart the EMU. good looking ...";
echo $FIN
echo "      PANDASAT TEAM          "
echo "Update Doskam Key by Informed"
echo $FIN
echo "             << audi06_19 >>             ";
echo "  ..:: https://dreamosat-forum.com ::..  ";
echo $FIN
sleep 1;
exit 0

