#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com
set -e
FIN="==================================================="
echo $FIN
cd /tmp
rm -rf *.txt
rm -rf *.deb
rm -rf *.ipk

KONTROL=$(opkg list-installed enigma2-plugin-extensions-mediaportal | awk '{ print $1 }')
wget --quiet -O - http://dhwz.github.io/e2-mediaportal/version.txt | sed 4q >/tmp/version.txt
echo "MediaPortal VERSION"
cat /tmp/version.txt | sed 1q
echo "";
sleep 2;
MODEL=$(uname -n)
PORTALDEB=$(grep -i "deb" version.txt)
PORTALIPK=$(grep -i "ipk" version.txt)

if [ "$KONTROL" = "enigma2-plugin-extensions-mediaportal" ]; then
echo "MediaPortal yüklü, tekrar yüklenmesine gerek yok ..."
else

echo "MediaPortal ISNTALL EDILIYOR ..."
echo "Sistem Kontrol Ediliyor ..."

sleep 2;
if [ -f /etc/apt/apt.conf ] ; then
echo ":DREAMBOX OE2.5 IMAGES"
if grep -qs 'armhf' cat /etc/apt/apt.conf ; then
echo "${MODEL} ARMHF"
wget --quiet -O - http://debfeed4.merlin.xyz/oe_2.5/deb/dm900/merlin4-plugins/ | grep -o 'python-merlin4[^<]*' >/tmp/python-merlin4.txt
sed -i -E 's|(.*>)(.*)|\2\n&|' /tmp/python-merlin4.txt
sed 1q /tmp/python-merlin4.txt >/tmp/merlin4.txt
merlin4=$(cat /tmp/merlin4.txt)
echo "merlin4-covercollection download";
wget -q http://debfeed4.merlin.xyz/oe_2.5/deb/dm900/merlin4-plugins/$merlin4
sleep 1;
echo "MediaPortal download";
wget -q $PORTALDEB
sleep 1;
echo "Sistem Update";
apt-get update > /dev/null;
sleep 1;
echo "merlin4-covercollection install";
echo "y" | dpkg --install --force-depends --force-overwrite python-merlin4-covercollection* > /dev/null;
sleep 1;
echo "MediaPortal install";
echo "y" | dpkg --install --force-depends --force-overwrite enigma2-plugin-extensions-mediaportal* > /dev/null;
sleep 1;
echo "y" | apt-get -f install > /dev/null;
############################################################################

if grep -qs 'mipsel' cat /etc/apt/apt.conf ; then
echo " ${MODEL} MIPSEL IMAGES"
wget --quiet -O - http://debfeed4.merlin.xyz/oe_2.5/deb/merlin4-plugins/ | grep -o 'python-merlin4[^<]*' >/tmp/python-merlin4.txt
sed -i -E 's|(.*>)(.*)|\2\n&|' /tmp/python-merlin4.txt
sed 1q /tmp/python-merlin4.txt >/tmp/merlin4.txt
merlin4=$(cat /tmp/merlin4.txt)
wget -q http://debfeed4.merlin.xyz/oe_2.5/deb/merlin4-plugins/$merlin4
sleep 1;
echo "merlin4-covercollection download";
wget -q $PORTALDEB
sleep 1;
echo "MediaPortal download";
apt-get update > /dev/null;
sleep 1;
echo "Sistem Update";
echo "y" | dpkg --install --force-depends --force-overwrite python-merlin4-covercollection* > /dev/null;
sleep 1;
echo "merlin4-covercollection install";
echo $LINE
echo "y" | dpkg --install --force-depends --force-overwrite enigma2-plugin-extensions-mediaportal* > /dev/null;
echo $LINE
sleep 1;
echo "MediaPortal install";
echo "y" | apt-get -f install > /dev/null;
############################################################################
fi
fi
else

if [ -f /etc/opkg/opkg.conf ] ; then
echo "ALL ${MODEL} MIPSEL OE-2.0 IMAGES"
wget -q $PORTALIPK
opkg update > /dev/null;
opkg install -force-overwrite enigma2-plugin-extensions-mediaportal* > /dev/null;

else
echo "MediaPortal error "
fi
fi
fi
set +e
rm -rf *.txt
rm -rf *.deb
rm -rf *.ipk
sync
echo "";
echo "MediaPortal INSTALLED SUCCESSFULLY"
echo "PLEASE RESTART YOUR STB"
echo "===========================================";
echo "           ..:: A U T H O R ::..           ";
echo "              << audi06_19 >>              ";
echo "   ..:: https://dreamosat-forum.com ::..   ";
echo "===========================================";
sleep 3;
exit 0 


