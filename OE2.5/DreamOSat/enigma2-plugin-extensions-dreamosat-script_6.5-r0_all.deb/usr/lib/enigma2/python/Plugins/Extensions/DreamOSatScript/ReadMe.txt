============================================
============ NEW VERSION 6.5-r0 ============
============================================
ADD 00.00.2018
- (3) pAnDaSaT bOaRd SotfCam Key Update by. Informed
- (5) OSCam Free Server ALL
- (53) INT 2017 Movies
- (54) INT 2017 Movies 2
- (55) pAnDaSaT Free IPTV
- (56) MediaPortal Install
- (yedek) TechSat Keys, Download Keys
- (yedek) TechSat Keys, Show Visible Channel
- (yedek) SotfCam.Key Update satupdate.net
- (yedek) SotfCam.Key, constant.cw, AutoRoll.Key softcam.tv

FIX 00.00.2018
- (0) DreamOSatScript info # bash dos2unix add,
- (2) PowerVU ALL Keys # "MTN Worldwide TV" edit,
- (2) PowerVU ALL Keys # "language" add,
- (4) CCcam Free Server # "URL" add,
- (52) INT IPTV # bash script edit,
- PowerVu/sids # "MTN Worldwide TV" edit,
- PowerVu/.au # "AFN AU Keys 9.0" EMM Key edit,
- (60) ALL PiconTranparent 220x132 45.0W-85.1E # p7zip edit,

DELETE 00.00.2018
- (3) OSCam Free Server Freecline.com delete,
- (6) N-Line Free Server Freecline.com delete,


============================================
============ NEW VERSION 6.4-r0 ============
============================================
ADD 12.01.2018
- (51) IPTVPlayer
- (19) Cccam TO OSCam Converter
- (40) OpenVPNbook.com Free Server #1: Euro1
- (41) OpenVPNbook.com Free Server #2: Euro2
- (42) OpenVPNbook.com Free Server #3: US1
- (43) OpenVPNbook.com Free Server #4: US2
- (44) OpenVPNbook.com Free Server #5: CA (Canada)
- (45) OpenVPNbook.com Free Server #6: DE (Germany)
- (46) OpenVPNbook.com Free Server #7: FR (France)

FIX 12.01.2018
- language add
- (3) OSCam Free Server Freecline.com
- (4) OSCam Free Server Testious.com
- (5) CCcam Free Server
- (30) OSCam EMU Updater ALL [mipsel,arm] OE2.0
- (31) OSCam EMU Updater dreambox_fpu OE2.0-OE2.5
- (32) OSCam EMU Updater mips-openpli40 OE2.0
- (33) OSCam EMU Updater [ARM] dreambox,vuplus,mutant,octagon,gigablue
- (34) OSCam EMU Updater dm900 LIBUSB OE2.5
- (35) OSCam Updater armV7 (download.oscam.cc) OE2.0
- (36) OSCam EMU Updater mips-tuxbox OE2.0
- (37) OSCam EMU Updater mips-tuxbox OE1.6
- (38) NCam EMU Updater ALL [mipsel,arm] OE2.0
- (39) GCam EMU Updater ALL [mipsel,arm] OE2.0
============================================
============ NEW VERSION 6.3-r2 ============
============================================
FIX 26.12.2017
- language add
- (83) picons 1.9E add
- (83) picons 3.0E remove
- (60) Picons ALL edit
- (65) Picons 23.5E edit
- (52) INT IPTV www.destek.korax.com
============================================
============ NEW VERSION 6.3-r0 ============
============================================
FIX 01.12.2017
- (150) Altin_Fiyatlari
- (151) Beinspor_Superlig_ve_1nci_Lig_Mac_Programi
- (152) Cccam_to_Oscam
- (153) Doviz_Kuru
- (154) Ekran_Resmi_Cek
- (155) Epg-Turkce_karakter_sorunu_cozumu
- (156) FTP_Sifresini_Sifirla
- (157) Google_DNS_Ayarla
- (158) Hdd_USB_Maunt
- (159) Ipk_ve _Tar_gz_Yukleme
- (160) Kanal_Ses_Dilini_TR_Yap
- (161) Kanal_Yedekleme_ve_Geri_Yukleme
- (162) M3u_to_Buket
- (163) Mynet_Spor_Haberleri
- (164) Satellites_xml_Guncelle - Copy
- (165) Son_Dakika_Ekonomi_Haberleri
- (166) Son_Dakika_Spor_Haberleri
- (167) Son_Depremler
- (168) Sozcu_com_tr_Haberleri - Copy
- (169) Turkiye_Super_Ligi_Mac_Sonuclari
- (170) Ucretli_Iptv_Guncelle
============================================

www.dreamosat-forum.com

İyi Seyirler...
