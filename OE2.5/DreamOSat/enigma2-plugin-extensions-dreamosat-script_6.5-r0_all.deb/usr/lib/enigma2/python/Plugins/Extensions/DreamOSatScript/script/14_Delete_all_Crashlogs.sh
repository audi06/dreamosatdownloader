#!/bin/sh
#DESCRIPTION=This script will delete all crash-logs from /media/hdd
echo ""
printf "Searching for crash logs, please wait... \n"
export crashfilename=`find / -name enigma2_crash*`
echo "."
echo ".."
rm -f $crashfilename
sleep 1
echo "..."
echo "done!"
echo " "
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0
