# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/__init__.py
pass