#! /bin/sh
#DESCRIPTION=This script Download Softcam by TeChSaT Team

umask 022

RETCCCAM=0
RETOSCAM=0

echo ""

if [ -d /usr/keys ]; then
   KPATHCCCAM=/usr/keys
elif [ -d /var/keys ]; then
   KPATHCCCAM=/var/keys
elif [ -d /etc/emud/emu ]; then
   if [ ! -d /etc/emud/emu/keys ]; then
      mkdir /etc/emud/emu/keys
   fi
   KPATHCCCAM=/etc/emud/emu/keys
else
   RETCCCAM=1
   echo " Warning! No valid path found for CCcam/MGcam keys."
   echo ""
fi

if [ -d /etc/tuxbox/config ]; then
   KPATHOSCAM=/etc/tuxbox/config
elif [ -d /var/tuxbox/config ]; then
   KPATHOSCAM=/var/tuxbox/config
else
   RETOSCAM=1
   echo " Warning! No valid path found for Oscam keys."
   echo ""
fi

if [ $RETCCCAM -eq 0 -o $RETOSCAM -eq 0 ]; then
   echo " Contacting server. Please wait..."
   echo ""
fi

if [ $RETCCCAM -eq 0 ]; then
   wget -t 40 http://satlab.techsat.info/Maker/CCcam/CCcamKeys.tgz  -O /tmp/CCcamKeys.tgz 2>/dev/null

   if [ $? -eq 0 -a -s /tmp/CCcamKeys.tgz ]; then
      echo " Softcam archive for CCcam/MGcam downloaded succesfully! Extracting..."
      echo ""
      tar zxf /tmp/CCcamKeys.tgz -C /tmp

      if [ $? -eq 0 -a -s /tmp/SoftCam.Key -a -s /tmp/constant.cw -a -s /tmp/TechSat.log ]; then
         echo " Softcam files for CCcam/MGcam extracted succesfully! Installing..."
         echo ""
#         mv -f /tmp/SoftCam.Key $KPATHCCCAM/SoftCam.Key
#         mv -f /tmp/constant.cw $KPATHCCCAM/constant.cw
#         mv -f /tmp/TechSat.log $KPATHCCCAM/Changelog_info.txt
	 cp -rd /tmp/SoftCam.Key $KPATHCCCAM/SoftCam.Key
#	 cp -rd /tmp/SoftCam.Key $KPATHOSCAM/SoftCam.Key
	 cp -rd /tmp/constant.cw $KPATHCCCAM/constant.cw
	 cp -rd /tmp/constant.cw $KPATHOSCAM/constant.cw
#	 mv -f /tmp/TechSat.log $KPATHCCCAM/Changelog_info.txt
	 cp -rd /tmp/TechSat.log $KPATHCCCAM/Changelog_info.txt

         rm -rf /tmp/CCcamKeys.tgz
         echo " Softcam files for CCcam/MGcam installed succesfully! Enjoy!"
         echo ""
      else
         echo " Extract softcam files for CCcam/MGcam failed! Try again."
         echo ""
         exit 1
      fi
   else
      echo " Download softcam archive for CCcam/MGcam failed! Try again."
      echo ""
      exit 1
   fi
fi

if [ $RETOSCAM -eq 0 ]; then
   wget -t 40 http://satlab.techsat.info/Maker/Oscam/Oscam.tgz  -O /tmp/Oscam.tgz 2>/dev/null

   if [ $? -eq 0 -a -s /tmp/Oscam.tgz ]; then
      echo " Softcam archive for Oscam downloaded succesfully! Extracting..."
      echo ""
      tar zxf /tmp/Oscam.tgz -C /tmp

      if [ $? -eq 0 -a -s /tmp/oscam.keys -a -s /tmp/TechSat.log ]; then
         echo " Softcam files for Oscam extracted succesfully! Installing..."
         echo ""
#         mv -f /tmp/oscam.keys $KPATHOSCAM/oscam.keys
	 cp -rd /tmp/oscam.keys $KPATHOSCAM/oscam.keys
	 cp -rd /tmp/oscam.keys $KPATHCCCAM/oscam.keys
	 cp -rd /tmp/oscam.keys $KPATHOSCAM/SoftCam.Key
#         mv -f /tmp/TechSat.log $KPATHOSCAM/Changelog_info.txt
	 cp -rd /tmp/TechSat.log $KPATHOSCAM/Changelog_info.txt

         rm -rf /tmp/Oscam.tgz
         rm -rf /tmp/SoftCam.Key
         rm -rf /tmp/oscam.keys
         rm -rf /tmp/TechSat.log
         rm -rf /tmp/constant.cw
         echo " Softcam files for Oscam installed succesfully! Enjoy!"
         echo ""
      else
         echo " Extract softcam files for Oscam failed! Try again."
         echo ""
         exit 1
      fi
   else
      echo " Download softcam archive for Oscam failed! Try again."
      echo ""
      exit 1
   fi
fi

if [ $RETCCCAM -eq 1 -a $RETOSCAM -eq 1 ]; then
   echo " Error! No valid path found for CCcam/MGcams or Oscam keys."
   echo ""
   exit 1
fi

exit 0

