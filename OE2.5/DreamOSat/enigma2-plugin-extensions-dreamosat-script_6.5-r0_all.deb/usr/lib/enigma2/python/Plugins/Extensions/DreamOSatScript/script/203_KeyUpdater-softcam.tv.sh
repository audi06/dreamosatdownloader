#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."
cd /;
echo $FIN
echo "Key Downloader for E2"
echo "Now update Keys..."
echo $FIN
#keys 
wget http://www.softcam.org/deneme6.php?file=SoftCam.Key -qO /tmp/SoftCam.Key
wget http://www.softcam.org/deneme6.php?file=AutoRoll.Key -qO /tmp/AutoRoll.Key
wget http://www.softcam.org/deneme6.php?file=constant.cw -qO /tmp/constant.cw

echo "______________________________"
#find /tmp/SoftCam.Key
#find /tmp/AutoRoll.Key
sleep 1;
dos2unix /tmp/SoftCam.Key
dos2unix /tmp/AutoRoll.Key
dos2unix /tmp/constant.cw

chmod 644 /tmp/SoftCam.Key
chmod 644 /tmp/AutoRoll.Key
chmod 644 /tmp/constant.cw

cp /tmp/SoftCam.Key /usr/keys/
cp /tmp/AutoRoll.Key /usr/keys/
cp /tmp/constant.cw /usr/keys/
cp /tmp/SoftCam.Key /etc/tuxbox/config/
cp /tmp/constant.cw /etc/tuxbox/config/

rm -rf /tmp/SoftCam.Key
rm -rf /tmp/AutoRoll.Key
rm -rf /tmp/constant.cw

echo "Keys Downloaded"
echo " www.softcam.tv"
echo $FIN
echo "SoftCam.Key ve constant.cw güncellendi";
echo "SoftCam.Key and constant.cw updated";
echo $FIN
echo "EMU Restart Etmeyi Unutmayınız. iyi seyirler...";
echo "Do not forget to restart the EMU. good looking ...";
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0
