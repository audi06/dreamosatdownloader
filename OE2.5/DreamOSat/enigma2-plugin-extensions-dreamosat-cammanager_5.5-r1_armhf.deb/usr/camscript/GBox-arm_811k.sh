#!/bin/sh
#### "*******************************************"
#### "*          ..:: A U T H O R ::..          *"
#### "*             << Audi06_19 >>             *"
#### "*  ..:: https://dreamosat-forum.com ::..  *"
#### "*******************************************"

CAM="GBox-arm_811k"
OSD="GBox-arm_811k"
PID=`pidof $CAM`
Action=$1

cam_clean () {
	[ -e /tmp/ecm.info ] && rm -rf /tmp/ecm.info
	[ -e /tmp/ecm1.info ] && rm -rf /tmp/ecm1.info
	[ -e /tmp/pid.info ] && rm -rf /tmp/pid.info
	[ -e /tmp/pid1.info ] && rm -rf /tmp/pid1.info
	[ -e /tmp/cardinfo ] && rm -rf /tmp/cardinfo
	[ -e /tmp/share.info ] && rm -rf /tmp/share.info
	[ -e /tmp/sc.info ] && rm -rf /tmp/sc.info
	[ -e /tmp/share.onl ] && rm -rf /tmp/share.onl
	[ -e /tmp/gbox.ver ] && rm -rf /tmp/gbox.ver
}

cam_handle () {
		if test	-z "${PID}"	; then
				cam_up;
		else
				cam_down;
		fi;
}

cam_down ()	{
		killall	-9 $CAM
		sleep 2
		cam_clean
}

cam_up () {
		/usr/bin/$CAM  > /dev/null 2>&1 &
}

if test	"$Action" =	"cam_startup" ;	then
	if test	-z "${PID}" ; then
		cam_down
		cam_up
	else
		echo "$CAM already running, exiting..."
	fi
elif test	"$Action" =	"cam_res" ;	then
		cam_down
		cam_up
elif test "$Action"	= "cam_down" ; then
		cam_down
elif test "$Action"	= "cam_up" ; then
		cam_up
else
		cam_handle
fi

exit 0
