#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com 15-10-2017
echo "*     ..:: B E K L E Y İ N İ Z ::..       *"
echo "*  ..:: USB MOUT İŞLEMİ BAŞLATILDI ::..   *"

[ -d /tmp/DreamOSat ] || mkdir -p /tmp/DreamOSat > /dev/null;
sleep 1
CONT=$(blkid | awk '/vfat/{print $2}')
CONT1=$(blkid | awk '/ntfs/{print $3}')
MOUT="/tmp/DreamOSat/usb-mount.txt"
echo "/dev/disk/by-uuid/$CONT	/media/usb	auto	auto,nofail	0	0" >> $MOUT
echo "/dev/disk/by-uuid/$CONT1	/media/usb	auto	auto,nofail	0	0" >> $MOUT
sleep 1
sed -i -e 's/"//g' $MOUT
sleep 1
sed -i -e 's/UUID=//g' $MOUT
sleep 1
if grep -qs '\/media\/usb' cat /etc/fstab ; then
  echo "";
  echo "USB Disk/Bellek daha önce Mount edilmiş. Tekrar Mount edilmesine gerek yoktur..."
  echo "";
else
  echo "" >> /etc/fstab
  awk 'NR==1' $MOUT >> /etc/fstab
	
	echo "";
	echo "Disk id numarası yazıldı. /media/usb/ olarak mount edildi...";
	echo "";
	[ -d /media/usb/backup ] || mkdir -p /media/usb/backup > /dev/null;
	echo "media/usb/backup/ klasörü oluşturuldu...";
	echo "";
	[ -d /media/usb/movie ] || mkdir -p /media/usb/movie > /dev/null;
	echo "media/usb/movie/ klasörü oluşturuldu...";
	echo "";
	echo "Uydu alıcınız YENİDEN başlatılıyor. iyi seyirler...";
	echo "";
	rm -rf /tmp/DreamOSat > /dev/null;
	echo "*******************************************";
	echo "*          ..:: A U T H O R ::..          *";
	echo "*             << audi06_19 >>             *";
	echo "*  ..:: https://dreamosat-forum.com ::..  *";
	echo "*******************************************";
	sleep 3;
	reboot
fi
rm -rf /tmp/DreamOSat > /dev/null;
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 3;
exit 0
