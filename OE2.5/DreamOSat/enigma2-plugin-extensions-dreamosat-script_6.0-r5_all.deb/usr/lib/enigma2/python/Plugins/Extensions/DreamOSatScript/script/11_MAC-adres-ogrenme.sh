#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com
echo "";
echo "MAC ADRESINIZ"
ifconfig | grep HWaddr
echo "";
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0
