from Screens.Screen import Screen
from Screens.Console import Console
from Components.MenuList import MenuList
from Components.ActionMap import ActionMap
from Plugins.Plugin import PluginDescriptor

from enigma import getDesktop

DESKHEIGHT = getDesktop(0).size().height()
skin_path = "/usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/Skin/"

class Myaudi06(Screen):

    def __init__(self, session, args = None):
        self.session = session
        if DESKHEIGHT < 1000:		
            skin = skin_path + 'menuhd.xml'
        else:	
		     skin = skin_path + 'menufullhd.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()

#    def __init__(self, session, args = 0):
#        self.session = session
        list = []
        list.append((' (0) DreamOSatScript info', 'com_0'))
        list.append((' (1) Key Updater ', 'com_1'))
        list.append((' (2) PowerVU ALL Keys ', 'com_2'))
        list.append((' (3) Key Updater yedek ', 'com_3'))
        list.append((' (4) OSCam Free Server ', 'com_4'))
        list.append((' (5) CCcam Free Server ', 'com_5'))
        list.append((' (6) N-Line Free Server Freecline.com ', 'com_6'))
        list.append((' (7) N-Line Free Server Testious.com ', 'com_7'))
        list.append((' (8) Key FreeColor 36.E ', 'com_8'))
        list.append((' (9) Key FreeColor 56.E ', 'com_9'))
        list.append(('(10) Ip Adress Ogrenme ', 'com_10'))
        list.append(('(11) MAC Adress Ogrenme ', 'com_11'))
        list.append(('(12) Free Space ', 'com_12'))
        list.append(('(13) Emu info ', 'com_13'))
        list.append(('(14) Delete all Crashlogs ', 'com_14'))
        list.append(('(15) Info All ', 'com_15'))
        list.append(('(16) Info Cpu ', 'com_16'))
        list.append(('(17) Info Drivers.sh ', 'com_17'))
        list.append(('(18) Info Internet Ping ', 'com_18'))
#        list.append(('(19)  ', 'com_19'))
        list.append(('(20) OE2.5 HDD Mount ', 'com_20'))
        list.append(('(21) OE2.5 USB Mount ', 'com_21'))
        list.append(('(22) OE2.5 Microcard Mount ', 'com_22'))
        list.append(('(23) OE2.5 Iptv guncelle ', 'com_23'))
        list.append(('(24) DreamOSat IPTV Genel ', 'com_24'))
        list.append(('(25) DreamOSat IPTV-Belgesel ', 'com_25'))
        list.append(('(26) DreamOSat IPTV Spor ', 'com_26'))
        list.append(('(27) DreamOSat IPTV Sinema ', 'com_27'))
        list.append(('(28) DreamOSat IPTV Music ', 'com_28'))
        list.append(('(29) DreamOSat IPTV Porn ', 'com_29'))
        list.append(('(30) OSCam Updater ALL [mipsel,arm] OE2.0', 'com_30'))
        list.append(('(31) OSCam Updater dreambox_fpu OE2.0-OE2.5', 'com_31'))
        list.append(('(32) OSCam Updater mips-openpli40 OE2.0', 'com_32'))
        list.append(('(33) OSCam Updater [ARM] dreambox,vuplus,mutant,octagon,gigablue', 'com_33'))
        list.append(('(34) OSCam Updater dm900 LIBUSB OE2.5 ', 'com_34'))
        list.append(('(35) OSCam Updater armV7 (download.oscam.cc)', 'com_35'))
        list.append(('(36) OSCam Updater mips-tuxbox OE2.0 ', 'com_36'))
        list.append(('(37) OSCam Updater mips-tuxbox OE1.6 ', 'com_37'))
        list.append(('(38) NCam Updater ALL [mipsel,arm] OE2.0 ', 'com_38'))
        list.append(('(39) ', 'com_39'))
        list.append(('(40) ', 'com_40'))
        list.append(('(41) ', 'com_41'))
        list.append(('(42) ', 'com_42'))
        list.append(('(43) ', 'com_43'))
        list.append(('(44) Satellites.xlm Guncelle  ', 'com_44'))
        list.append(('(45) Settings chveneburi  ', 'com_45'))
        list.append(('(46) Settings Yedek Al ', 'com_46'))
        list.append(('(47) Server Bilgilerimi Yedekle  ', 'com_47'))
        list.append(('(48) ALIEZ.ME CANLI YAYIN ', 'com_48'))
        list.append(('(49) Eklenti Yukleme USB/TMP .DEB .IPK .TAR.GZ ', 'com_49'))
        list.append(('(50) DreamOSat Script Update ', 'com_50'))
        list.append((_('Exit'), 'exit'))
        Screen.__init__(self, session)
        self['myMenu'] = MenuList(list)
        self['myActionMap'] = ActionMap(['SetupActions'], {'ok': self.go,
         'cancel': self.cancel}, -1)

    def go(self):
        returnValue = self['myMenu'].l.getCurrentSelection()[1]
        print '\n[Myaudi06] returnValue: ' + returnValue + '\n'
        if returnValue is not None:
            if returnValue is 'com_0':
                self.prombt('/bin/echo ; wget http://depo.dreamosat.net/CaMs-EmU/ReadMe.txt -qO /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/ReadMe.txt > /dev/null; cat /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/ReadMe.txt ; /bin/echo')
            elif returnValue is 'com_1':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/1_KeyUpdater.sh')
            elif returnValue is 'com_2':
                self.prombt('/bin/echo ; /bin/echo Watching Pay TV without a valid subscription is illegal ; cd /tmp ; /usr/bin/wget -q http://najmsat2018.com/powervu-keys/ --header="User-Agent: Mozilla/5.0 (Windows NT 5.1; rv:23.0) Gecko/20100101 Firefox/23.0" &> /dev/null ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/2_PowerVu-keys-all.sh')
            elif returnValue is 'com_3':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/3_KeyUpdater-3.sh')
            elif returnValue is 'com_4':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/4_OSCam-server.sh')
            elif returnValue is 'com_5':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/5_CCcam-server.sh')
            elif returnValue is 'com_6':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/6_N-Line_Server_Freecline.com.sh')
            elif returnValue is 'com_7':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/7_N-Line_Server_Testious.com.sh')
            elif returnValue is 'com_8':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/8_Key-FreeColor36e.sh')
            elif returnValue is 'com_9':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/9_Key-FreeColor56e.sh')
            elif returnValue is 'com_10':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/10_Ip-adres-ogrenme.sh')
            elif returnValue is 'com_11':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/11_MAC-adres-ogrenme.sh')
            elif returnValue is 'com_12':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/12_Free_Space.sh')
            elif returnValue is 'com_13':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/13_Emu_info.sh')
            elif returnValue is 'com_14':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/14_Delete_all_Crashlogs.sh')
            elif returnValue is 'com_15':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/15_Info_All.sh')
            elif returnValue is 'com_16':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/16_Info_Cpu.sh')
            elif returnValue is 'com_17':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/17_Info_Drivers.sh')
            elif returnValue is 'com_18':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/18_Info_Internet_Ping.sh')
#            elif returnValue is 'com_19':
#                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/')
            elif returnValue is 'com_20':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/20_OE2.5-HDD-Mount.sh')
            elif returnValue is 'com_21':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/21_OE2.5-USB-Mount.sh')
            elif returnValue is 'com_22':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/22_OE2.5-Microcard-Mount.sh')
            elif returnValue is 'com_23':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/23_OE2.5-Iptv-guncelle.sh')
            elif returnValue is 'com_24':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/24_DreamOSat-IPTV-Genel.sh')
            elif returnValue is 'com_25':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/25_DreamOSat-IPTV-Belgesel.sh')
            elif returnValue is 'com_26':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/26_DreamOSat-IPTV-Spor.sh')
            elif returnValue is 'com_27':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/27_DreamOSat-IPTV-Sinema.sh')
            elif returnValue is 'com_28':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/28_DreamOSat-IPTV-Music.sh')
            elif returnValue is 'com_29':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/29_DreamOSat-IPTV-Porn.sh')
            elif returnValue is 'com_30':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/30_OSCam_Updater_ALL.sh')
            elif returnValue is 'com_31':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/31_OSCam_Updater_dreambox_fpu.sh')
            elif returnValue is 'com_32':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/32_OSCam_Updater_mips-openpli40.sh')
            elif returnValue is 'com_33':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/33_OSCam_Updater_arm.sh')
            elif returnValue is 'com_34':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/34_OSCam_Updater_dm900-libusb.sh')
            elif returnValue is 'com_35':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/35_OSCam-svn_Updater_armV7.sh')
            elif returnValue is 'com_36':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/36_OSCam_Updater_mips-tuxbox-oe2.0.sh')
            elif returnValue is 'com_37':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/37_OSCam_Updater_mips-tuxbox-oe1.6.sh')
            elif returnValue is 'com_38':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/38_NCam_Updater_ALL.sh')
#            elif returnValue is 'com_39':
#                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/39_')
#            elif returnValue is 'com_40':
#                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/40_')
#            elif returnValue is 'com_41':
#                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/41_')
#            elif returnValue is 'com_42':
#                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/42_')
#            elif returnValue is 'com_43':
#                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/43_')
            elif returnValue is 'com_44':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/44_Satellites-guncelle.sh')
            elif returnValue is 'com_45':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/45_Settings-chveneburi.sh')
            elif returnValue is 'com_46':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/46_Settings-Yedek-Al.sh')
            elif returnValue is 'com_47':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/47_Server-Bilgilerimi-Yedekle.sh')
            elif returnValue is 'com_48':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/48_Aliez.me-canlitv.sh')
            elif returnValue is 'com_49':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/49_Eklenti-yukleme.sh')
            elif returnValue is 'com_50':
                self.prombt('/bin/echo ; /bin/echo By audi06_19@dreamosat-forum.com ; /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/50_DreamOSat-Script-update.sh')
            else:
                print '\n[Myaudi06] cancel\n'
                self.close(None)

    def prombt(self, com):
        self.session.open(Console, _('start shell com: %s') % com, ['%s' % com])

    def cancel(self):
        print '\n[Myaudi06] cancel\n'
        self.close(None)


def main(session, **kwargs):
    print '\n[Myaudi06] start\n'
    session.open(Myaudi06)


def Plugins(**kwargs):
    return [
	PluginDescriptor(name='DreamOSatScript', 
	description=_('www.dreamosat-forum.com'), 
	where=PluginDescriptor.WHERE_PLUGINMENU, icon='plugin.png', fnc=main), 

	PluginDescriptor(name='DreamOSatScript', 
	description=_('www.dreamosat-forum.com'), 
	where=PluginDescriptor.WHERE_EXTENSIONSMENU, icon='plugin.png', fnc=main)]






