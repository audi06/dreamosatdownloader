#!/bin/sh
#Created By endebar ustaya tesekkurler
cd /tmp
wget http://aliez.me/alllive/ -O /tmp/alive.txt > /dev/null;
sed '/<a class=\"big\" href=\"\/live\//!d' /tmp/alive.txt >> /tmp/alive1.txt
sed -i -e 's/					<a class="big\" href=\"/http:\/\/aliez.me/g' /tmp/alive1.txt
sed -i -e 's/\/">/ /g' /tmp/alive1.txt
sed 's/\s\+/\n/g' /tmp/alive1.txt >> /tmp/alive2.txt
sed '/http:\/\/aliez.me/!d' /tmp/alive2.txt >> /tmp/alive3.txt
echo "wget " >> /tmp/alive4.txt
awk 'NR==1' /tmp/alive3.txt >> /tmp/alive4.txt 
echo "-O /tmp/indir1.txt" >> /tmp/alive4.txt
echo "wget " >> /tmp/alive4.txt
awk 'NR==2' /tmp/alive3.txt >> /tmp/alive4.txt 
echo "-O /tmp/indir2.txt" >> /tmp/alive4.txt
echo "wget " >> /tmp/alive4.txt
awk 'NR==3' /tmp/alive3.txt >> /tmp/alive4.txt 
echo "-O /tmp/indir3.txt" >> /tmp/alive4.txt
echo "wget " >> /tmp/alive4.txt
awk 'NR==4' /tmp/alive3.txt >> /tmp/alive4.txt 
echo "-O /tmp/indir4.txt" >> /tmp/alive4.txt
echo "wget " >> /tmp/alive4.txt
awk 'NR==5' /tmp/alive3.txt >> /tmp/alive4.txt 
echo "-O /tmp/indir5.txt" >> /tmp/alive4.txt
echo "wget " >> /tmp/alive4.txt
awk 'NR==6' /tmp/alive3.txt >> /tmp/alive4.txt 
echo "-O /tmp/indir6.txt" >> /tmp/alive4.txt
echo "wget " >> /tmp/alive4.txt
awk 'NR==7' /tmp/alive3.txt >> /tmp/alive4.txt 
echo "-O /tmp/indir7.txt" >> /tmp/alive4.txt
echo "wget " >> /tmp/alive4.txt
awk 'NR==8' /tmp/alive3.txt >> /tmp/alive4.txt 
echo "-O /tmp/indir8.txt" >> /tmp/alive4.txt
echo "wget " >> /tmp/alive4.txt
awk 'NR==9' /tmp/alive3.txt >> /tmp/alive4.txt 
echo "-O /tmp/indir9.txt" >> /tmp/alive4.txt
echo "wget " >> /tmp/alive4.txt
awk 'NR==10' /tmp/alive3.txt >> /tmp/alive4.txt 
echo "-O /tmp/indir10.txt" >> /tmp/alive4.txt
while read line1; read line2; do read line3; echo "$line1 $line2 $line3"; done </tmp/alive4.txt>/tmp/alive5.txt
echo "#!/bin/sh" >> /tmp/aliez2.sh
sed '/wget http/!d' /tmp/alive5.txt >> /tmp/aliez2.sh
echo "exit 0" >> /tmp/aliez2.sh
dos2unix /tmp/aliez2.sh
chmod 0755 /tmp/aliez2.sh
sleep 3
bash /tmp/aliez2.sh > /dev/null;
rm -rf /tmp/alive*.txt
sed '/http:\/\/a3.aliez.me:8080\/hls\//!d' /tmp/indir1.txt >> /tmp/buket.txt
sed '/http:\/\/a3.aliez.me:8080\/hls\//!d' /tmp/indir2.txt >> /tmp/buket.txt
sed '/http:\/\/a3.aliez.me:8080\/hls\//!d' /tmp/indir3.txt >> /tmp/buket.txt
sed '/http:\/\/a3.aliez.me:8080\/hls\//!d' /tmp/indir4.txt >> /tmp/buket.txt
sed '/http:\/\/a3.aliez.me:8080\/hls\//!d' /tmp/indir5.txt >> /tmp/buket.txt
sed '/http:\/\/a3.aliez.me:8080\/hls\//!d' /tmp/indir6.txt >> /tmp/buket.txt
sed '/http:\/\/a3.aliez.me:8080\/hls\//!d' /tmp/indir7.txt >> /tmp/buket.txt
sed '/http:\/\/a3.aliez.me:8080\/hls\//!d' /tmp/indir8.txt >> /tmp/buket.txt
sed '/http:\/\/a3.aliez.me:8080\/hls\//!d' /tmp/indir9.txt >> /tmp/buket.txt
sed '/http:\/\/a3.aliez.me:8080\/hls\//!d' /tmp/indir10.txt >> /tmp/buket.txt
sleep 3
sed -i -e 's/															file:	'\''//g' /tmp/buket.txt
sed -i -e 's/:/%3A/g' /tmp/buket.txt
sed -i -e 's/'\''./:CANLI YAYIN /g' /tmp/buket.txt
echo "#SERVICE 4097:0:1:0:0:0:0:0:0:0:" >> /tmp/buket1.txt
awk 'NR==1' /tmp/buket.txt >> /tmp/buket1.txt
echo "#SERVICE 4097:0:1:0:0:0:0:0:0:0:" >> /tmp/buket1.txt
awk 'NR==3' /tmp/buket.txt >> /tmp/buket1.txt
echo "#SERVICE 4097:0:1:0:0:0:0:0:0:0:" >> /tmp/buket1.txt
awk 'NR==5' /tmp/buket.txt >> /tmp/buket1.txt
echo "#SERVICE 4097:0:1:0:0:0:0:0:0:0:" >> /tmp/buket1.txt
awk 'NR==7' /tmp/buket.txt >> /tmp/buket1.txt
echo "#SERVICE 4097:0:1:0:0:0:0:0:0:0:" >> /tmp/buket1.txt
awk 'NR==9' /tmp/buket.txt >> /tmp/buket1.txt
echo "#SERVICE 4097:0:1:0:0:0:0:0:0:0:" >> /tmp/buket1.txt
awk 'NR==11' /tmp/buket.txt >> /tmp/buket1.txt
echo "#SERVICE 4097:0:1:0:0:0:0:0:0:0:" >> /tmp/buket1.txt
awk 'NR==13' /tmp/buket.txt >> /tmp/buket1.txt
echo "#SERVICE 4097:0:1:0:0:0:0:0:0:0:" >> /tmp/buket1.txt
awk 'NR==15' /tmp/buket.txt >> /tmp/buket1.txt
echo "#SERVICE 4097:0:1:0:0:0:0:0:0:0:" >> /tmp/buket1.txt
awk 'NR==17' /tmp/buket.txt >> /tmp/buket1.txt
echo "#SERVICE 4097:0:1:0:0:0:0:0:0:0:" >> /tmp/buket1.txt
awk 'NR==19' /tmp/buket.txt >> /tmp/buket1.txt
while read line1; do read line2; echo "$line1 $line2"; done </tmp/buket1.txt>/tmp/buket2.txt
sed -i -e 's/#SERVICE 4097:0:1:0:0:0:0:0:0:0: h/#SERVICE 4097:0:1:0:0:0:0:0:0:0:h/g' /tmp/buket2.txt
sed '/#SERVICE 4097:0:1:0:0:0:0:0:0:0:http/!d' /tmp/buket2.txt >> /tmp/buket3.txt
echo "#NAME ALIEZ.ME CANLI YAYIN" >> /tmp/userbouquet.aliez.tv
awk 'NR==1' /tmp/buket3.txt >> /tmp/userbouquet.aliez.tv
awk 'NR==2' /tmp/buket3.txt >> /tmp/userbouquet.aliez.tv
awk 'NR==3' /tmp/buket3.txt >> /tmp/userbouquet.aliez.tv
awk 'NR==4' /tmp/buket3.txt >> /tmp/userbouquet.aliez.tv
awk 'NR==5' /tmp/buket3.txt >> /tmp/userbouquet.aliez.tv
awk 'NR==6' /tmp/buket3.txt >> /tmp/userbouquet.aliez.tv
awk 'NR==7' /tmp/buket3.txt >> /tmp/userbouquet.aliez.tv
awk 'NR==8' /tmp/buket3.txt >> /tmp/userbouquet.aliez.tv
awk 'NR==9' /tmp/buket3.txt >> /tmp/userbouquet.aliez.tv
awk 'NR==10' /tmp/buket3.txt >> /tmp/userbouquet.aliez.tv
rm -rf /tmp/buket*.txt
rm -rf /tmp/indir*.txt
rm -rf /tmp/aliez2.sh
dos2unix /tmp/userbouquet.aliez.tv
chmod 0755 /tmp/userbouquet.aliez.tv
rm -rf /etc/enigma2/userbouquet.aliez.tv
cp /tmp/userbouquet.aliez.tv /etc/enigma2/userbouquet.aliez.tv
if grep -qs 'userbouquet.aliez.tv' cat /etc/enigma2/bouquets.tv ; then
echo "Buket listesinde mevcut"
else
echo '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.aliez.tv" ORDER BY bouquet' >> /etc/enigma2/bouquets.tv
fi
wget -q -O - http://127.0.0.1/web/servicelistreload?mode=0
rm -rf /tmp/userbouquet.aliez.tv

echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*              << endebar >>              *";
echo "*..:: https://www.turk-dreamworld.com ::..*";
echo "*******************************************";

exit 0
