#!/bin/bash
#Created By audi06_19 @https://dreamosat.net
cd /;
rm -rf /tmp/keyupdate;
[ -d /usr/keys ] || mkdir -p /usr/keys;
[ -d /etc/tuxbox/config ] || mkdir -p /etc/tuxbox/config;
[ -d /etc/tuxbox/config/ncam ] || mkdir -p /etc/tuxbox/config/ncam;
[ -d /etc/tuxbox/config/oscamymod ] || mkdir -p /etc/tuxbox/config/oscamymod;
[ -d /etc/tuxbox/config/oscampowervu ] || mkdir -p /etc/tuxbox/config/oscampowervu;
[ -d /tmp/keyupdate ] || mkdir -p /tmp/keyupdate;
wget http://depo.dreamosat.net/CaMs-EmU/SoftCam-2.Key -qO /tmp/keyupdate/SoftCam.Key > /dev/null;
chmod 0755 /tmp/keyupdate/ -R;
cd /tmp/keyupdate;
cp -rd SoftCam.Key /usr/keys/ > /dev/null;
cp -rd SoftCam.Key /etc/tuxbox/config/ > /dev/null;
cp -rd SoftCam.Key /etc/tuxbox/config/ncam/ > /dev/null;
cp -rd SoftCam.Key /etc/tuxbox/config/oscamymod/ > /dev/null;
cp -rd SoftCam.Key /etc/tuxbox/config/oscampowervu/ > /dev/null;
cd /;
rm -rf /tmp/keyupdate;
################################################# FIND-SOFTCAM #################################################
> /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/Your-Softcam-Key-Location
find /usr /var/ /etc -iname Softcam.key > /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/Your-Softcam-Key-Location
        echo
        echo "I'am looking for your SoftCam.Key file/s hold on a sec"
        echo

if [ -s /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/Your-Softcam-Key-Location ]
then
        echo
        echo "Found SoftCam.Key file/s in the following location/s ;)"
        echo
        cat /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/Your-Softcam-Key-Location
	echo
else
        echo
        echo "I can't find your SoftCam.Key file have you got one ????"
        echo
fi
################################################################################################################
#################################################### AUKEYS ####################################################
if [ -s /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/Your-Softcam-Key-Location ]
then
        echo "I found your SoftCam.Key file ;) "
else
        echo
        echo "I can't find your SoftCam.Key please use option 15 of the menu first"
        echo
        exit 0
fi

while read line
do
sed -i '/AU KEYS/,/AU KEYS end/d' $line
echo "########################### AU KEYS #########################" >> $line
cat /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/.au >> $line
echo "########################### AU KEYS end #####################" >> $line
done < /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/Your-Softcam-Key-Location
echo
echo PLEASE RESTART OSCAM ALL AU KEYS UPDATED
echo
################################################################################################################
##################################################### AFN ######################################################
> new
> tosort
> SoftCam.Key.AFN
sed -e 's/<[^>]*>//g' /tmp/index.html > new
grep -A4 -i 003E7E84 new > tosort
grep -i "KEY0" tosort  | sed '/^$/d;s/[[:blank:]]//g' | cut -f 2 -d ':' | cut -f 1 -d '&' > 00
grep -i "KEY1" tosort  | sed '/^$/d;s/[[:blank:]]//g' | cut -f 2 -d ':' | cut -f 1 -d '&' > 01
while read line
do
cat 00 | sed "s/^/P $line 00 /g" >> SoftCam.Key.AFN.tmp
cat 01 | sed "s/^/P $line 01 /g" >> SoftCam.Key.AFN.tmp
done < /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/sids/P_AFN
rm tosort new 00 01 
echo "################# AFN KEYs added by POWERVU_KEY_UPDATER #################" >> SoftCam.Key.AFN
cat SoftCam.Key.AFN.tmp | grep ^P | cut -c 1-28 >> SoftCam.Key.AFN
echo "################# AFN KEYs end #################" >> SoftCam.Key.AFN
rm SoftCam.Key.AFN.tmp

while read line
do
sed -i '/AFN KEYs added/,/AFN KEYs end/d' $line
cat SoftCam.Key.AFN >> $line
done < /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/Your-Softcam-Key-Location
rm SoftCam.Key.AFN
echo
echo PLEASE RESTART OSCAM AFN KEYS UPDATED
echo
################################################################################################################
################################################# DISCOVERY-1W #################################################
> new
> tosort
> SoftCam.Key.Discovery-Networks
sed -e 's/<[^>]*>//g' /tmp/index.html > new
grep -B3 -i 00623910   new > tosort
sed -i 's/ECMKey1:  /ECMKey1: /g' tosort
sed -i 's/ ECMKey1: /ECMKey1: /g' tosort
sed -i 's/ECMKey0:  /ECMKey0: /g' tosort
sed -i 's/ ECMKey0: /ECMKey0: /g' tosort
grep -i "KEY0" tosort  | sed '/^$/d;s/[[:blank:]]//g' | cut -f 2 -d ':' | cut -f 1 -d '&' > 00
grep -i "KEY1" tosort  | sed '/^$/d;s/[[:blank:]]//g' | cut -f 2 -d ':' | cut -f 1 -d '&' > 01
while read line
do
cat 00 | sed "s/^/P $line 00 /g" >> SoftCam.Key.Discovery-Networks.tmp
cat 01 | sed "s/^/P $line 01 /g" >> SoftCam.Key.Discovery-Networks.tmp
done < /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/sids/P_Discovery-1W
sed -i 's/  / /g' SoftCam.Key.Discovery-Networks
rm tosort new 00 01
echo "################# Discovery-Networks KEYs added by POWERVU_KEY_UPDATER #################" >> SoftCam.Key.Discovery-Networks
cat SoftCam.Key.Discovery-Networks.tmp | grep ^P | cut -c 1-28 >> SoftCam.Key.Discovery-Networks
echo "################# Discovery-Networks KEYs end #################" >> SoftCam.Key.Discovery-Networks
rm SoftCam.Key.Discovery-Networks.tmp

while read line
do
sed -i '/Discovery-Networks KEYs added/,/Discovery-Networks KEYs end/d' $line
cat SoftCam.Key.Discovery-Networks >> $line
done < /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/Your-Softcam-Key-Location
rm SoftCam.Key.Discovery-Networks
echo
echo PLEASE RESTART OSCAM DISCOVERY KEYS UPDATED
echo
################################################################################################################
############################################### DISCOVERY-EUROPE ###############################################
> new
> tosort
> SoftCam.Key.Euro
sed -e 's/<[^>]*>//g' /tmp/index.html > new
echo "################# EURO KEYs added by POWERVU_KEY_UPDATER #################" >> SoftCam.Key.Euro
grep -A7 -i "DISCOVERY EUROPE" new > tosort
sed -i 's/ECMKey1:  /ECMKey1: /g' tosort
sed -i 's/ ECMKey1: /ECMKey1: /g' tosort
sed -i 's/ECMKey0:  /ECMKey0: /g' tosort
sed -i 's/ ECMKey0: /ECMKey0: /g' tosort
grep -i KEY0 tosort | cut -f 2 -d ':' | sed '/^$/d;s/[[:blank:]]//g' | sed -e 's/^\(.\{14\}\).*/\1/' > 00
grep -i KEY1 tosort | cut -f 2 -d ':' | sed '/^$/d;s/[[:blank:]]//g' | sed -e 's/^\(.\{14\}\).*/\1/' > 01
while read line
do
cat 00 | sed "s/^/P $line 00 /g" >> SoftCam.Key.Euro
cat 01 | sed "s/^/P $line 01 /g" >> SoftCam.Key.Euro
done < /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/sids/P_Discovery-Networks_Euro
echo "################# EURO KEYs end #################" >> SoftCam.Key.Euro
rm tosort new 00 01 

while read line
do
sed -i '/EURO KEYs added/,/EURO KEYs end/d' $line
cat SoftCam.Key.Euro >> $line
done < /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/Your-Softcam-Key-Location
rm SoftCam.Key.Euro
echo
echo PLEASE RESTART OSCAM EUROSPORT KEYS UPDATED
echo
################################################################################################################
#################################################### FIGHT #####################################################
> new
> tosort
> SoftCam.Key.FIGHT
sed -e 's/<[^>]*>//g' /tmp/index.html > new
echo "################# FIGHT KEYs added by POWERVU_KEY_UPDATER #################" >> SoftCam.Key.FIGHT
grep -A2 12707 new | grep -iv tele > tosort
sed -i 's/ECMKey1:  /ECMKey1: /g' tosort
sed -i 's/ ECMKey1: /ECMKey1: /g' tosort
sed -i 's/ECMKey0:  /ECMKey0: /g' tosort
sed -i 's/ ECMKey0: /ECMKey0: /g' tosort
grep -i Key0 tosort | cut -f 2 -d ':' | sed '/^$/d;s/[[:blank:]]//g' | sed -e 's/^\(.\{14\}\).*/\1/' > 00
grep -i 01  tosort | awk '{print $4}' > 01
cat 00 | sed "s/^/P 01FE 00 /g" >> SoftCam.Key.FIGHT
cat 01 | sed "s/^/P 01FE 01 /g" >> SoftCam.Key.FIGHT
echo "################# FIGHT KEYs end #################" >> SoftCam.Key.FIGHT
rm tosort new 00 01 

while read line
do
sed -i '/FIGHT KEYs added/,/FIGHT KEYs end/d' $line
cat SoftCam.Key.FIGHT >> $line
done < /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/Your-Softcam-Key-Location
rm SoftCam.Key.FIGHT
echo
echo PLEASE RESTART OSCAM FIGHT Network KEYS UPDATED
echo
################################################################################################################
###################################################### HBB #####################################################
> ne
> tosort
> SoftCam.Key.HBO
> 00
> 01
echo "################# HBO KEYs added by POWERVU_KEY_UPDATER #################" >> SoftCam.Key.HBO
sed -e 's/<[^>]*>//g' /tmp/index.html | grep -A7 -i "HBO/CineMax"  > tosort
grep -i "0000 00" tosort | awk '{print $4$5$6$7$8$9$10}' > 00
grep -i "0000 01" tosort | awk '{print $4$5$6$7$8$9$10}' > 01
grep -i KEY0 tosort | cut -f 2 -d ':' | sed '/^$/d;s/[[:blank:]]//g' | sed -e 's/^\(.\{14\}\).*/\1/' >> 00
grep -i KEY1 tosort | cut -f 2 -d ':' | sed '/^$/d;s/[[:blank:]]//g' | sed -e 's/^\(.\{14\}\).*/\1/' >> 01
while read line
do
cat 00 | sed "s/^/P $line 00 /g" >> SoftCam.Key.HBO
cat 01 | sed "s/^/P $line 01 /g" >> SoftCam.Key.HBO
done < /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/sids/P_HBO
echo "################# HBO KEYs end #################" >> SoftCam.Key.HBO
rm ne tosort 00 01

while read line
do
sed -i '/HBO KEYs added/,/HBO KEYs end/d' $line
cat SoftCam.Key.HBO >> $line
done < /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/Your-Softcam-Key-Location
rm SoftCam.Key.HBO
echo
echo PLEASE RESTART OSCAM HBO KEYS UPDATED
echo
################################################################################################################
###################################################### SIS #####################################################
> new
> tosort
> SoftCam.Key.SIS
sed -e 's/<[^>]*>//g' /tmp/index.html > new
echo "################# SIS KEYs added by POWERVU_KEY_UPDATER #################" >> SoftCam.Key.SIS
grep -A10 -i SIS-Live new > tosort
sed -i 's/Key1:  /Key1: /g' tosort
sed -i 's/ Key1: /Key1: /g' tosort
sed -i 's/Key0:  /Key0: /g' tosort
sed -i 's/ Key0: /Key0: /g' tosort
grep -i ^Key0 tosort | cut -f 2 -d ':' | sed '/^$/d;s/[[:blank:]]//g' | sed -e 's/^\(.\{14\}\).*/\1/' > 00
grep -i ^Key1 tosort | cut -f 2 -d ':' | sed '/^$/d;s/[[:blank:]]//g' | sed -e 's/^\(.\{14\}\).*/\1/' > 01
while read line
do
cat 00 | sed "s/^/P $line 00 /g" >> SoftCam.Key.SIS
cat 01 | sed "s/^/P $line 01 /g" >> SoftCam.Key.SIS
done < /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/sids/P_SIS
echo "################# SIS KEYs end #################" >> SoftCam.Key.SIS
rm tosort new 00 01 

while read line
do
sed -i '/SIS KEYs added/,/SIS KEYs end/d' $line
cat SoftCam.Key.SIS >> $line
done < /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/PowerVu/Your-Softcam-Key-Location
rm SoftCam.Key.SIS
echo
echo PLEASE RESTART OSCAM SIS KEYS UPDATED
echo
################################################################################################################

rm /tmp/index.html
