#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com
cd /;
[ -d /etc/tuxbox/config/oscampowervu ] || mkdir -p /etc/tuxbox/config/oscampowervu;
[ -d /usr/keys ] || mkdir -p /usr/keys;
[ -d /tmp/keyupdate ] || mkdir -p /tmp/keyupdate;
wget http://enigma.satupdate.net/SoftCam.txt -qO /tmp/keyupdate/SoftCam.Key > /dev/null;

chmod 0755 /tmp/keyupdate/ -R;
cd /tmp/keyupdate;
cp SoftCam.Key /etc/tuxbox/config/;
cp SoftCam.Key /usr/keys/;
echo "";
cd /;
rm -rf /tmp/keyupdate;
echo "SoftCam.Key güncellendi";
echo "";
echo "EMU Restart Etmeyi Unutmayınız. iyi seyirler...";
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 2;
exit 0
