#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com 2017
echo "";
echo "*     ..:: B E K L E Y İ N İ Z ::..       *"
echo "";
[ -d /usr/camscript ] || mkdir -p /usr/camscript;

oscam=/usr/bin
script=/usr/camscript

echo ":========> En yeni OSCam alınıyor"
	www="http://oscam.dreamosat.net/index.php?&direction=0&order=mod&directory=1.20_TRUNK/mips-openpli40&"
	wget $www -q -O /tmp/oscam.info
	version=$(cat /tmp/oscam.info | grep -A 32 "archives" | grep "openpli40-webif-oscam-emu-patched.tar.gz"|sed 's/[ ][ ]*/'/g''|cut -b 35-39)
	LINK='http://oscam.dreamosat.net/index.php?action=downloadfile&filename=oscam-svn'$version'-openpli40-webif-oscam-emu-patched.tar.gz&directory=1.20_TRUNK/mips-openpli40&'
echo ":========> Kopyalanıyor OSCam_r$version"
	wget $LINK -q -O /tmp/OscamUpdate-audi06_19.tar.gz
	tar -xzf /tmp/OscamUpdate-audi06_19.tar.gz -C /tmp/
	[ -e /tmp/*-arm_dream-list_smargo ] && rm /tmp/*-arm_dream-list_smargo
	mv /tmp/oscam-svn* /tmp/OSCam_r$version
	[ -e /usr/bin/OSCam_r$version ] && rm -rf /usr/bin/OSCam_r$version
	[ -e /usr/camscript/OSCam_r$version ] && rm -rf /usr/camscript/OSCam_r$version
echo ":========> Kopyalandı OSCam_r$version /usr/bin"
	cp -rf /tmp/OSCam_r$version /usr/bin/OSCam_r$version
	[ -e /tmp/doc ] && rm -rf /tmp/doc 
	[ -e /tmp/oscam.info ] && rm /tmp/oscam.info 
	[ -e /tmp/OscamUpdate-audi06_19.tar.gz ] && rm /tmp/OscamUpdate-audi06_19.tar.gz 
	[ -e /tmp/OSCam_r$version ] && rm /tmp/OSCam_r$version
	[ -e /tmp/CHANGES ] && rm /tmp/CHANGES 
	
	
dest="/usr/camscript/OSCam_r$version.sh"
echo ":========> OSCam_r$version için Script oluşturuluyor... "$dest
echo -e "#!/bin/sh" > $dest
echo -e "" >> $dest
echo -e "CAM=\0042OSCam_r$version\0042" >> $dest
echo -e "OSD=\0042OSCam r$version\0042" >> $dest
echo -e "PID=\0044CAM" >> $dest
echo -e "Action=\00441" >> $dest
echo -e "" >> $dest
echo -e "cam_clean () {" >> $dest
echo -e "		rm -rf /tmp/*.info*	/tmp/.oscam /tmp/*.pid" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "cam_handle () {" >> $dest
echo -e "		if test	-z \0042\0044{PID}\0042	; then" >> $dest
echo -e "				cam_up;" >> $dest
echo -e "		else" >> $dest
echo -e "				cam_down;" >> $dest
echo -e "		fi;" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "cam_down ()	{" >> $dest
echo -e "		killall	-9 \0044CAM 2>/dev/null" >> $dest
echo -e "		sleep 2" >> $dest
echo -e "		cam_clean" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "cam_up () {" >> $dest
echo -e "		/usr/bin/\0044CAM -c /etc/tuxbox/config/ &" >> $dest
echo -e "}" >> $dest
echo -e "" >> $dest
echo -e "if test	\0042\0044Action\0042 =	\0042cam_startup\0042 ;	then" >> $dest
echo -e "	if test	-z \0042\0044{PID}\0042 ; then" >> $dest
echo -e "		cam_down" >> $dest
echo -e "		cam_up" >> $dest
echo -e "	else" >> $dest
echo -e "		echo \0042\0044CAM already running, exiting...\0042" >> $dest
echo -e "	fi" >> $dest
echo -e "elif test	\0042\0044Action\0042 =	\0042cam_res\0042 ;	then" >> $dest
echo -e "		cam_down" >> $dest
echo -e "		cam_up" >> $dest
echo -e "elif test \0042\0044Action\0042	= \0042cam_down\0042 ; then" >> $dest
echo -e "		cam_down" >> $dest
echo -e "elif test \0042\0044Action\0042	= \0042cam_up\0042 ; then" >> $dest
echo -e "		cam_up" >> $dest
echo -e "else" >> $dest
echo -e "		cam_handle" >> $dest
echo -e "fi" >> $dest
echo -e "" >> $dest
echo -e "exit 0" >> $dest
chmod 755 $dest
sleep 1
echo ""
echo ":========> Güncel OSCam r$version indirildi"
echo ""
echo ":========> En Yeni OSCam çalıştırılmaya hazır"
echo ""
echo ":== DİKKAT ==>... DreamOSat camManager açın ve OSCam r$version çalıştırın..."
echo ""
rm -rf /tmp/DreamOSat
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 2
exit 0
