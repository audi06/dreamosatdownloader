#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com
echo "";
echo "FreeColor Key 36e Downloader for E2, DreamOS";
cd /;
[ -d /usr/keys ] || mkdir -p /usr/keys;
sleep 1;
[ -d /tmp/freecolor ] || mkdir -p /tmp/freecolor;
sleep 1;
wget http://freecolor.eu.org/sat/freecolor-keys.zip -qO /tmp/freecolor/freecolor-keys.zip > /dev/null;
sleep 1;
unzip -o /tmp/freecolor/freecolor-keys.zip -d /tmp/freecolor/ > /dev/null;
sleep 1;
#center
rm -rf /usr/keys/ee.bin;
rm -rf /usr/keys/iq.bin;
rm -rf /usr/keys/key.bin;
rm -rf /usr/keys/key.db;
rm -rf /usr/keys/keydata.bin;
rm -rf /usr/keys/keydata.tmp;
rm -rf /usr/keys/keydata.txt;
rm -rf /usr/keys/mcaskey.bin;
rm -rf /usr/keys/snippet.tbl91;
#keys
rm -rf /usr/keys/SoftCam.Key;
rm -rf /usr/keys/constant.cw;
rm -rf /usr/keys/dre.keys;
rm -rf /usr/keys/drecrypt.key;
rm -rf /usr/keys/drekeys.log;
rm -rf /usr/keys/gbox.key;
rm -rf /usr/keys/oscam.keys;
rm -rf /usr/keys/pobedit.key;
#copy
cp -rd /tmp/freecolor/center/ee.bin /usr/keys/;
cp -rd /tmp/freecolor/center/iq.bin /usr/keys/;
cp -rd /tmp/freecolor/center/key.bin /usr/keys/;
cp -rd /tmp/freecolor/center/key.db /usr/keys/;
cp -rd /tmp/freecolor/center/keydata.bin /usr/keys/;
cp -rd /tmp/freecolor/center/keydata.tmp /usr/keys/;
cp -rd /tmp/freecolor/center/keydata.txt /usr/keys/;
cp -rd /tmp/freecolor/center/mcaskey.bin /usr/keys/;
cp -rd /tmp/freecolor/center/snippet.tbl91 /usr/keys/;
#
cp -rd /tmp/freecolor/keys/SoftCam.Key /usr/keys/;
cp -rd /tmp/freecolor/keys/constant.cw /usr/keys/;
cp -rd /tmp/freecolor/keys/dre.keys /usr/keys/;
cp -rd /tmp/freecolor/keys/drecrypt.key /usr/keys/;
cp -rd /tmp/freecolor/keys/drekeys.log /usr/keys/;
cp -rd /tmp/freecolor/keys/gbox.key /usr/keys/;
cp -rd /tmp/freecolor/keys/oscam.keys /usr/keys/;
cp -rd /tmp/freecolor/keys/pobedit.key /usr/keys/;
#
rm -rf /tmp/freecolor;
echo "";
echo "FreeColor Key 36e güncellendi";
echo "";
echo "Wicard, Oscam-Ymod, Oscam Emu Restart Etmeyi Unutmayınız. iyi seyirler...";
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0

