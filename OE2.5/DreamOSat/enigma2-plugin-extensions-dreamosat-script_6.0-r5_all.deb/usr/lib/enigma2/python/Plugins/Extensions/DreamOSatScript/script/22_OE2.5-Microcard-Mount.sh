#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com 15-10-2017
echo "*     ..:: B E K L E Y İ N İ Z ::..       *"
echo "*  ..:: USB MOUT İŞLEMİ BAŞLATILDI ::..   *"

echo " YAKINDA EKLENECEK..."

rm -rf /tmp/DreamOSat > /dev/null;
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 3;
exit 0
