#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com
echo "";
echo "USB VEYA TMP KLASORUNE KOPYALADIGINIZ .DEB .IPK .TAR.GZ UZANTILI DOSYALARI BU SCRIPTLE YUKLEYEBILIRSINIZ";
echo "";
echo "";
sleep 1;
echo "DOSYALARINIZ YUKLENIYOR";
dpkg  -i --force-depends /tmp/*.deb > /dev/null
dpkg  -i --force-depends /media/usb/*.deb > /dev/null
opkg install --force-depends /tmp/*.ipk > /dev/null
opkg install --force-depends /media/usb/*.ipk > /dev/null
tar -zxvf /tmp/*.tar.gz -C / > /dev/null
tar -zxvf /media/usb/*.tar.gz -C / > /dev/null
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0
