#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com 15-10-2017
echo "";
echo "*     ..:: B E K L E Y İ N İ Z ::..       *"
rm -rf /tmp/DreamOSat
[ -d /tmp/DreamOSat ] || mkdir -p /tmp/DreamOSat > /dev/null;
cd /tmp/DreamOSat
################################### FIND-OSCAM.SERVER ####################################
> /tmp/DreamOSat/Your-oscam.server-Location
find /usr/keys/ /var/keys/ /etc -iname oscam.server > /tmp/DreamOSat/Your-oscam.server-Location
        echo
        echo "Cihazınızda yüklü oscam.server dosyalarını arıyorum..."
if [ -s /tmp/DreamOSat/Your-oscam.server-Location ]
then
        echo
        echo "Aşağıdaki konumda oscam.server dosyanızı buldum ;)"
	echo "--------------------------------------------";
        cat /tmp/DreamOSat/Your-oscam.server-Location
	echo "--------------------------------------------";
	echo
else
        echo
        echo "Cihazınızda yüklü oscam.server dosyası yok"
        echo
        echo "/etc/tuxbox/config/ içerisine oscam.server dosyası oluşturuyorum..."
fi
######################################################################################
WGET1="https://www.testious.com/free-cccam-servers"
EMU="/tmp/DreamOSat/oscam.server"
EMU1="/etc/tuxbox/config/oscam.server"
EMU2="/tmp/DreamOSat/cline"

wget -U "$WGET1" --quiet -O - $WGET1  | grep -o -i 'C: [^<]*' | awk '!_[$2]++' | awk '!_[$4]++' | awk '!_[$5]++' | awk '{ print $1, $2, $3, $4, $5 }' >>$EMU2
sleep 1
if grep -qs 'C: ' cat $EMU2 ; then
   echo "C + Line server (www.testious.com) indiriliyor...";
#sed -e '51,$d' cline1 >> cline

awk '{print "[reader]"}' cline >>reader
awk '{print "label                         = " $2 }' cline >>label
awk '{print "protocol                      = cccam" }' cline >>protocol
awk '{print "device                        = " $2 "," $3 }' cline >>device
awk '{print "user                          = " $4 }' cline >>user
awk '{print "password                      = " $5 }' cline >>password
awk '{print "inactivitytimeout             = 30" }' cline >>inactivitytimeout
awk '{print "group                         = 1" }' cline >>group
awk '{print "cccversion                    = 2.2.1" }' cline >>cccversion
awk '{print "cccmaxhops                    = 3" }' cline >>cccmaxhop
awk '{print "ccckeepalive                  = 1" }' cline >>ccckeepalive
sleep 1
echo "" >> oscam.server
sed -n '1,1p' reader >> oscam.server
sed -n '1,1p' label >> oscam.server
sed -n '1,1p' protocol >> oscam.server
sed -n '1,1p' device >> oscam.server
sed -n '1,1p' user >> oscam.server
sed -n '1,1p' password >> oscam.server
sed -n '1,1p' inactivitytimeout >> oscam.server
sed -n '1,1p' cccversion >> oscam.server
sed -n '1,1p' group >> oscam.server
sed -n '1,1p' cccmaxhop >> oscam.server
sed -n '1,1p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '2,2p' reader >> oscam.server
sed -n '2,2p' label >> oscam.server
sed -n '2,2p' protocol >> oscam.server
sed -n '2,2p' device >> oscam.server
sed -n '2,2p' user >> oscam.server
sed -n '2,2p' password >> oscam.server
sed -n '2,2p' inactivitytimeout >> oscam.server
sed -n '2,2p' cccversion >> oscam.server
sed -n '2,2p' group >> oscam.server
sed -n '2,2p' cccmaxhop >> oscam.server
sed -n '2,2p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '3,3p' reader >> oscam.server
sed -n '3,3p' label >> oscam.server
sed -n '3,3p' protocol >> oscam.server
sed -n '3,3p' device >> oscam.server
sed -n '3,3p' user >> oscam.server
sed -n '3,3p' password >> oscam.server
sed -n '3,3p' inactivitytimeout >> oscam.server
sed -n '3,3p' cccversion >> oscam.server
sed -n '3,3p' group >> oscam.server
sed -n '3,3p' cccmaxhop >> oscam.server
sed -n '3,3p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '4,4p' reader >> oscam.server
sed -n '4,4p' label >> oscam.server
sed -n '4,4p' protocol >> oscam.server
sed -n '4,4p' device >> oscam.server
sed -n '4,4p' user >> oscam.server
sed -n '4,4p' password >> oscam.server
sed -n '4,4p' inactivitytimeout >> oscam.server
sed -n '4,4p' cccversion >> oscam.server
sed -n '4,4p' group >> oscam.server
sed -n '4,4p' cccmaxhop >> oscam.server
sed -n '4,4p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '5,5p' reader >> oscam.server
sed -n '5,5p' label >> oscam.server
sed -n '5,5p' protocol >> oscam.server
sed -n '5,5p' device >> oscam.server
sed -n '5,5p' user >> oscam.server
sed -n '5,5p' password >> oscam.server
sed -n '5,5p' inactivitytimeout >> oscam.server
sed -n '5,5p' cccversion >> oscam.server
sed -n '5,5p' group >> oscam.server
sed -n '5,5p' cccmaxhop >> oscam.server
sed -n '5,5p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '6,6p' reader >> oscam.server
sed -n '6,6p' label >> oscam.server
sed -n '6,6p' protocol >> oscam.server
sed -n '6,6p' device >> oscam.server
sed -n '6,6p' user >> oscam.server
sed -n '6,6p' password >> oscam.server
sed -n '6,6p' inactivitytimeout >> oscam.server
sed -n '6,6p' cccversion >> oscam.server
sed -n '6,6p' group >> oscam.server
sed -n '6,6p' cccmaxhop >> oscam.server
sed -n '6,6p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '7,7p' reader >> oscam.server
sed -n '7,7p' label >> oscam.server
sed -n '7,7p' protocol >> oscam.server
sed -n '7,7p' device >> oscam.server
sed -n '7,7p' user >> oscam.server
sed -n '7,7p' password >> oscam.server
sed -n '7,7p' inactivitytimeout >> oscam.server
sed -n '7,7p' cccversion >> oscam.server
sed -n '7,7p' group >> oscam.server
sed -n '7,7p' cccmaxhop >> oscam.server
sed -n '7,7p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '8,8p' reader >> oscam.server
sed -n '8,8p' label >> oscam.server
sed -n '8,8p' protocol >> oscam.server
sed -n '8,8p' device >> oscam.server
sed -n '8,8p' user >> oscam.server
sed -n '8,8p' password >> oscam.server
sed -n '8,8p' inactivitytimeout >> oscam.server
sed -n '8,8p' cccversion >> oscam.server
sed -n '8,8p' group >> oscam.server
sed -n '8,8p' cccmaxhop >> oscam.server
sed -n '8,8p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '9,9p' reader >> oscam.server
sed -n '9,9p' label >> oscam.server
sed -n '9,9p' protocol >> oscam.server
sed -n '9,9p' device >> oscam.server
sed -n '9,9p' user >> oscam.server
sed -n '9,9p' password >> oscam.server
sed -n '9,9p' inactivitytimeout >> oscam.server
sed -n '9,9p' cccversion >> oscam.server
sed -n '9,9p' group >> oscam.server
sed -n '9,9p' cccmaxhop >> oscam.server
sed -n '9,9p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '10,10p' reader >> oscam.server
sed -n '10,10p' label >> oscam.server
sed -n '10,10p' protocol >> oscam.server
sed -n '10,10p' device >> oscam.server
sed -n '10,10p' user >> oscam.server
sed -n '10,10p' password >> oscam.server
sed -n '10,10p' inactivitytimeout >> oscam.server
sed -n '10,10p' cccversion >> oscam.server
sed -n '10,10p' group >> oscam.server
sed -n '10,10p' cccmaxhop >> oscam.server
sed -n '10,10p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '11,11p' reader >> oscam.server
sed -n '11,11p' label >> oscam.server
sed -n '11,11p' protocol >> oscam.server
sed -n '11,11p' device >> oscam.server
sed -n '11,11p' user >> oscam.server
sed -n '11,11p' password >> oscam.server
sed -n '11,11p' inactivitytimeout >> oscam.server
sed -n '11,11p' cccversion >> oscam.server
sed -n '11,11p' group >> oscam.server
sed -n '11,11p' cccmaxhop >> oscam.server
sed -n '11,11p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '12,12p' reader >> oscam.server
sed -n '12,12p' label >> oscam.server
sed -n '12,12p' protocol >> oscam.server
sed -n '12,12p' device >> oscam.server
sed -n '12,12p' user >> oscam.server
sed -n '12,12p' password >> oscam.server
sed -n '12,12p' inactivitytimeout >> oscam.server
sed -n '12,12p' cccversion >> oscam.server
sed -n '12,12p' group >> oscam.server
sed -n '12,12p' cccmaxhop >> oscam.server
sed -n '12,12p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '13,13p' reader >> oscam.server
sed -n '13,13p' label >> oscam.server
sed -n '13,13p' protocol >> oscam.server
sed -n '13,13p' device >> oscam.server
sed -n '13,13p' user >> oscam.server
sed -n '13,13p' password >> oscam.server
sed -n '13,13p' inactivitytimeout >> oscam.server
sed -n '13,13p' cccversion >> oscam.server
sed -n '13,13p' group >> oscam.server
sed -n '13,13p' cccmaxhop >> oscam.server
sed -n '13,13p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '14,14p' reader >> oscam.server
sed -n '14,14p' label >> oscam.server
sed -n '14,14p' protocol >> oscam.server
sed -n '14,14p' device >> oscam.server
sed -n '14,14p' user >> oscam.server
sed -n '14,14p' password >> oscam.server
sed -n '14,14p' inactivitytimeout >> oscam.server
sed -n '14,14p' cccversion >> oscam.server
sed -n '14,14p' group >> oscam.server
sed -n '14,14p' cccmaxhop >> oscam.server
sed -n '14,14p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '15,15p' reader >> oscam.server
sed -n '15,15p' label >> oscam.server
sed -n '15,15p' protocol >> oscam.server
sed -n '15,15p' device >> oscam.server
sed -n '15,15p' user >> oscam.server
sed -n '15,15p' password >> oscam.server
sed -n '15,15p' inactivitytimeout >> oscam.server
sed -n '15,15p' cccversion >> oscam.server
sed -n '15,15p' group >> oscam.server
sed -n '15,15p' cccmaxhop >> oscam.server
sed -n '15,15p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '16,16p' reader >> oscam.server
sed -n '16,16p' label >> oscam.server
sed -n '16,16p' protocol >> oscam.server
sed -n '16,16p' device >> oscam.server
sed -n '16,16p' user >> oscam.server
sed -n '16,16p' password >> oscam.server
sed -n '16,16p' inactivitytimeout >> oscam.server
sed -n '16,16p' cccversion >> oscam.server
sed -n '16,16p' group >> oscam.server
sed -n '16,16p' cccmaxhop >> oscam.server
sed -n '16,16p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '17,17p' reader >> oscam.server
sed -n '17,17p' label >> oscam.server
sed -n '17,17p' protocol >> oscam.server
sed -n '17,17p' device >> oscam.server
sed -n '17,17p' user >> oscam.server
sed -n '17,17p' password >> oscam.server
sed -n '17,17p' inactivitytimeout >> oscam.server
sed -n '17,17p' cccversion >> oscam.server
sed -n '17,17p' group >> oscam.server
sed -n '17,17p' cccmaxhop >> oscam.server
sed -n '17,17p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '18,18p' reader >> oscam.server
sed -n '18,18p' label >> oscam.server
sed -n '18,18p' protocol >> oscam.server
sed -n '18,18p' device >> oscam.server
sed -n '18,18p' user >> oscam.server
sed -n '18,18p' password >> oscam.server
sed -n '18,18p' inactivitytimeout >> oscam.server
sed -n '18,18p' cccversion >> oscam.server
sed -n '18,18p' group >> oscam.server
sed -n '18,18p' cccmaxhop >> oscam.server
sed -n '18,18p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '19,19p' reader >> oscam.server
sed -n '19,19p' label >> oscam.server
sed -n '19,19p' protocol >> oscam.server
sed -n '19,19p' device >> oscam.server
sed -n '19,19p' user >> oscam.server
sed -n '19,19p' password >> oscam.server
sed -n '19,19p' inactivitytimeout >> oscam.server
sed -n '19,19p' cccversion >> oscam.server
sed -n '19,19p' group >> oscam.server
sed -n '19,19p' cccmaxhop >> oscam.server
sed -n '19,19p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '20,20p' reader >> oscam.server
sed -n '20,20p' label >> oscam.server
sed -n '20,20p' protocol >> oscam.server
sed -n '20,20p' device >> oscam.server
sed -n '20,20p' user >> oscam.server
sed -n '20,20p' password >> oscam.server
sed -n '20,20p' inactivitytimeout >> oscam.server
sed -n '20,20p' cccversion >> oscam.server
sed -n '20,20p' group >> oscam.server
sed -n '20,20p' cccmaxhop >> oscam.server
sed -n '20,20p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '21,21p' reader >> oscam.server
sed -n '21,21p' label >> oscam.server
sed -n '21,21p' protocol >> oscam.server
sed -n '21,21p' device >> oscam.server
sed -n '21,21p' user >> oscam.server
sed -n '21,21p' password >> oscam.server
sed -n '21,21p' inactivitytimeout >> oscam.server
sed -n '21,21p' cccversion >> oscam.server
sed -n '21,21p' group >> oscam.server
sed -n '21,21p' cccmaxhop >> oscam.server
sed -n '21,21p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '22,22p' reader >> oscam.server
sed -n '22,22p' label >> oscam.server
sed -n '22,22p' protocol >> oscam.server
sed -n '22,22p' device >> oscam.server
sed -n '22,22p' user >> oscam.server
sed -n '22,22p' password >> oscam.server
sed -n '22,22p' inactivitytimeout >> oscam.server
sed -n '22,22p' cccversion >> oscam.server
sed -n '22,22p' group >> oscam.server
sed -n '22,22p' cccmaxhop >> oscam.server
sed -n '22,22p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '23,23p' reader >> oscam.server
sed -n '23,23p' label >> oscam.server
sed -n '23,23p' protocol >> oscam.server
sed -n '23,23p' device >> oscam.server
sed -n '23,23p' user >> oscam.server
sed -n '23,23p' password >> oscam.server
sed -n '23,23p' inactivitytimeout >> oscam.server
sed -n '23,23p' cccversion >> oscam.server
sed -n '23,23p' group >> oscam.server
sed -n '23,23p' cccmaxhop >> oscam.server
sed -n '23,23p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '24,24p' reader >> oscam.server
sed -n '24,24p' label >> oscam.server
sed -n '24,24p' protocol >> oscam.server
sed -n '24,24p' device >> oscam.server
sed -n '24,24p' user >> oscam.server
sed -n '24,24p' password >> oscam.server
sed -n '24,24p' inactivitytimeout >> oscam.server
sed -n '24,24p' cccversion >> oscam.server
sed -n '24,24p' group >> oscam.server
sed -n '24,24p' cccmaxhop >> oscam.server
sed -n '24,24p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '25,25p' reader >> oscam.server
sed -n '25,25p' label >> oscam.server
sed -n '25,25p' protocol >> oscam.server
sed -n '25,25p' device >> oscam.server
sed -n '25,25p' user >> oscam.server
sed -n '25,25p' password >> oscam.server
sed -n '25,25p' inactivitytimeout >> oscam.server
sed -n '25,25p' cccversion >> oscam.server
sed -n '25,25p' group >> oscam.server
sed -n '25,25p' cccmaxhop >> oscam.server
sed -n '25,25p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '26,26p' reader >> oscam.server
sed -n '26,26p' label >> oscam.server
sed -n '26,26p' protocol >> oscam.server
sed -n '26,26p' device >> oscam.server
sed -n '26,26p' user >> oscam.server
sed -n '26,26p' password >> oscam.server
sed -n '26,26p' inactivitytimeout >> oscam.server
sed -n '26,26p' cccversion >> oscam.server
sed -n '26,26p' group >> oscam.server
sed -n '26,26p' cccmaxhop >> oscam.server
sed -n '26,26p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '27,27p' reader >> oscam.server
sed -n '27,27p' label >> oscam.server
sed -n '27,27p' protocol >> oscam.server
sed -n '27,27p' device >> oscam.server
sed -n '27,27p' user >> oscam.server
sed -n '27,27p' password >> oscam.server
sed -n '27,27p' inactivitytimeout >> oscam.server
sed -n '27,27p' cccversion >> oscam.server
sed -n '27,27p' group >> oscam.server
sed -n '27,27p' cccmaxhop >> oscam.server
sed -n '27,27p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '28,28p' reader >> oscam.server
sed -n '28,28p' label >> oscam.server
sed -n '28,28p' protocol >> oscam.server
sed -n '28,28p' device >> oscam.server
sed -n '28,28p' user >> oscam.server
sed -n '28,28p' password >> oscam.server
sed -n '28,28p' inactivitytimeout >> oscam.server
sed -n '28,28p' cccversion >> oscam.server
sed -n '28,28p' group >> oscam.server
sed -n '28,28p' cccmaxhop >> oscam.server
sed -n '28,28p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '29,29p' reader >> oscam.server
sed -n '29,29p' label >> oscam.server
sed -n '29,29p' protocol >> oscam.server
sed -n '29,29p' device >> oscam.server
sed -n '29,29p' user >> oscam.server
sed -n '29,29p' password >> oscam.server
sed -n '29,29p' inactivitytimeout >> oscam.server
sed -n '29,29p' cccversion >> oscam.server
sed -n '29,29p' group >> oscam.server
sed -n '29,29p' cccmaxhop >> oscam.server
sed -n '29,29p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '30,30p' reader >> oscam.server
sed -n '30,30p' label >> oscam.server
sed -n '30,30p' protocol >> oscam.server
sed -n '30,30p' device >> oscam.server
sed -n '30,30p' user >> oscam.server
sed -n '30,30p' password >> oscam.server
sed -n '30,30p' inactivitytimeout >> oscam.server
sed -n '30,30p' cccversion >> oscam.server
sed -n '30,30p' group >> oscam.server
sed -n '30,30p' cccmaxhop >> oscam.server
sed -n '30,30p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '31,31p' reader >> oscam.server
sed -n '31,31p' label >> oscam.server
sed -n '31,31p' protocol >> oscam.server
sed -n '31,31p' device >> oscam.server
sed -n '31,31p' user >> oscam.server
sed -n '31,31p' password >> oscam.server
sed -n '31,31p' inactivitytimeout >> oscam.server
sed -n '31,31p' cccversion >> oscam.server
sed -n '31,31p' group >> oscam.server
sed -n '31,31p' cccmaxhop >> oscam.server
sed -n '31,31p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '32,32p' reader >> oscam.server
sed -n '32,32p' label >> oscam.server
sed -n '32,32p' protocol >> oscam.server
sed -n '32,32p' device >> oscam.server
sed -n '32,32p' user >> oscam.server
sed -n '32,32p' password >> oscam.server
sed -n '32,32p' inactivitytimeout >> oscam.server
sed -n '32,32p' cccversion >> oscam.server
sed -n '32,32p' group >> oscam.server
sed -n '32,32p' cccmaxhop >> oscam.server
sed -n '32,32p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '33,33p' reader >> oscam.server
sed -n '33,33p' label >> oscam.server
sed -n '33,33p' protocol >> oscam.server
sed -n '33,33p' device >> oscam.server
sed -n '33,33p' user >> oscam.server
sed -n '33,33p' password >> oscam.server
sed -n '33,33p' inactivitytimeout >> oscam.server
sed -n '33,33p' cccversion >> oscam.server
sed -n '33,33p' group >> oscam.server
sed -n '33,33p' cccmaxhop >> oscam.server
sed -n '33,33p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '34,34p' reader >> oscam.server
sed -n '34,34p' label >> oscam.server
sed -n '34,34p' protocol >> oscam.server
sed -n '34,34p' device >> oscam.server
sed -n '34,34p' user >> oscam.server
sed -n '34,34p' password >> oscam.server
sed -n '34,34p' inactivitytimeout >> oscam.server
sed -n '34,34p' cccversion >> oscam.server
sed -n '34,34p' group >> oscam.server
sed -n '34,34p' cccmaxhop >> oscam.server
sed -n '34,34p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '35,35p' reader >> oscam.server
sed -n '35,35p' label >> oscam.server
sed -n '35,35p' protocol >> oscam.server
sed -n '35,35p' device >> oscam.server
sed -n '35,35p' user >> oscam.server
sed -n '35,35p' password >> oscam.server
sed -n '35,35p' inactivitytimeout >> oscam.server
sed -n '35,35p' cccversion >> oscam.server
sed -n '35,35p' group >> oscam.server
sed -n '35,35p' cccmaxhop >> oscam.server
sed -n '35,35p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '36,36p' reader >> oscam.server
sed -n '36,36p' label >> oscam.server
sed -n '36,36p' protocol >> oscam.server
sed -n '36,36p' device >> oscam.server
sed -n '36,36p' user >> oscam.server
sed -n '36,36p' password >> oscam.server
sed -n '36,36p' inactivitytimeout >> oscam.server
sed -n '36,36p' cccversion >> oscam.server
sed -n '36,36p' group >> oscam.server
sed -n '36,36p' cccmaxhop >> oscam.server
sed -n '36,36p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '37,37p' reader >> oscam.server
sed -n '37,37p' label >> oscam.server
sed -n '37,37p' protocol >> oscam.server
sed -n '37,37p' device >> oscam.server
sed -n '37,37p' user >> oscam.server
sed -n '37,37p' password >> oscam.server
sed -n '37,37p' inactivitytimeout >> oscam.server
sed -n '37,37p' cccversion >> oscam.server
sed -n '37,37p' group >> oscam.server
sed -n '37,37p' cccmaxhop >> oscam.server
sed -n '37,37p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '38,38p' reader >> oscam.server
sed -n '38,38p' label >> oscam.server
sed -n '38,38p' protocol >> oscam.server
sed -n '38,38p' device >> oscam.server
sed -n '38,38p' user >> oscam.server
sed -n '38,38p' password >> oscam.server
sed -n '38,38p' inactivitytimeout >> oscam.server
sed -n '38,38p' cccversion >> oscam.server
sed -n '38,38p' group >> oscam.server
sed -n '38,38p' cccmaxhop >> oscam.server
sed -n '38,38p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '39,39p' reader >> oscam.server
sed -n '39,39p' label >> oscam.server
sed -n '39,39p' protocol >> oscam.server
sed -n '39,39p' device >> oscam.server
sed -n '39,39p' user >> oscam.server
sed -n '39,39p' password >> oscam.server
sed -n '39,39p' inactivitytimeout >> oscam.server
sed -n '39,39p' cccversion >> oscam.server
sed -n '39,39p' group >> oscam.server
sed -n '39,39p' cccmaxhop >> oscam.server
sed -n '39,39p' ccckeepalive >> oscam.server
echo "" >> oscam.server
sed -n '40,40p' reader >> oscam.server
sed -n '40,40p' label >> oscam.server
sed -n '40,40p' protocol >> oscam.server
sed -n '40,40p' device >> oscam.server
sed -n '40,40p' user >> oscam.server
sed -n '40,40p' password >> oscam.server
sed -n '40,40p' inactivitytimeout >> oscam.server
sed -n '40,40p' cccversion >> oscam.server
sed -n '40,40p' group >> oscam.server
sed -n '40,40p' cccmaxhop >> oscam.server
sed -n '40,40p' ccckeepalive >> oscam.server
echo "" >> oscam.server

sleep 3;

cat > cline1 << EOF
#### "*******************************************"
#### "*          ..:: A U T H O R ::..          *"
#### "*             << audi06_19 >>             *"
#### "*  ..:: https://dreamosat-forum.com ::..  *"
#### "*******************************************"
EOF
sleep 1
cat >> oscam.server << EOF
#####################################################################################

[reader]
label                         = constant.cw
enable                        = 1
protocol                      = constcw
device                        = /etc/tuxbox/config/constant.cw
caid                          = 2600,0B00,0B02,0500,0963,06AD,0940
ident                         = 2600:000000;0B00:000000;0B02:000000;0500:032830;0963:000000;06AD:000000;0940:000000
group                         = 1

[reader]
label                         = emulator
protocol                      = emu
device                        = emulator
caid                          = 090F,0500,1801,0604,2600,FFFF,0E00,4AE1,1010
detect                        = cd
ident                         = 090F:000000;0500:000000,023800,021110,007400,007800;1801:000000,007301,001101,002111;0604:000000;2600:000000;FFFF:000000;0E00:000000;4AE1:000011,000014,0000FE;1010:000000
group                         = 1
emmcache                      = 2,1,2,1
emu_auproviders               = 0604:010200;0E00:000000;4AE1:000011,000014,0000FE;1010:000000

EOF
sleep 2
#awk '{print $0}' cline >>reader
cat oscam.server >> cline1

mv cline1 $EMU1
  echo "";
  echo "C + Line server (www.testious.com) indirildi, etc/tuxbox/config/oscam.server içerisine yazıldı..."
  sleep 2;
  echo "";
  echo "DreamOSat camManager Restart Etmeyi Unutmayınız. iyi seyirler...";
else
  echo "Server Off, (www.testious.com) bağlantı kurulamadı..."
  echo "";
  echo "Teknik Destek İçin (www.dreamosat-forum.com) Yardım Alınız ...";
fi

cd /
rm -rf /tmp/DreamOSat
#cp -rd $EMU $EMU_CP > /dev/null 2>&1

echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 2;
exit 0

