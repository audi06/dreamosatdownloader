#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com 15-10-2017
echo "*     ..:: B E K L E Y İ N İ Z ::..       *"
echo "*  ..:: HDD MOUT İŞLEMİ BAŞLATILDI ::..   *"
[ -d /tmp/DreamOSat ] || mkdir -p /tmp/DreamOSat > /dev/null;
sleep 1
CONT=$(blkid | awk '/sda1/{print $2}')
MOUT="/tmp/DreamOSat/hdd-mount.txt"
echo "/dev/disk/by-uuid/$CONT	/media/hdd	auto	auto,nofail	0	0" >> $MOUT
sleep 1
sed -i -e 's/"//g' $MOUT
sleep 1
sed -i -e 's/UUID=//g' $MOUT
sleep 1
if grep -qs '\/media\/hdd' cat /etc/fstab ; then
  echo "";
  echo "HDD Disk daha önce Mount edilmiş. Tekrar Mount edilmesine gerek yoktur..."
  echo "";
else
  echo "" >> /etc/fstab
  awk 'NR==1' $MOUT >> /etc/fstab
	
	echo "";
	echo "Disk id numarası yazıldı. /media/hdd/ olarak mount edildi...";
	echo "";
	[ -d /media/hdd/backup ] || mkdir -p /media/hdd/backup > /dev/null;
	echo "media/hdd/backup/ klasörü oluşturuldu...";
	echo "";
	[ -d /media/hdd/movie ] || mkdir -p /media/hdd/movie > /dev/null;
	echo "media/hdd/movie/ klasörü oluşturuldu...";
	echo "";
	echo "Uydu alıcınız YENİDEN başlatılıyor. iyi seyirler...";
	echo "";
	rm -rf /tmp/DreamOSat > /dev/null;
	echo "*******************************************";
	echo "*          ..:: A U T H O R ::..          *";
	echo "*             << audi06_19 >>             *";
	echo "*  ..:: https://dreamosat-forum.com ::..  *";
	echo "*******************************************";
	sleep 3;
	reboot
fi
rm -rf /tmp/DreamOSat > /dev/null;
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 3;
exit 0
