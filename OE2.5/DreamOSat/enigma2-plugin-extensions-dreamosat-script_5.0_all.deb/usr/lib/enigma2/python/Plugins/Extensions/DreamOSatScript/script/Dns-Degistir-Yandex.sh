#!/bin/sh
echo "SERVIS SAGLAYICI TARAFINDAN YASAKLANAN SITELERE GIRMEK ICIN DNS ADRESINIZI YANDEX DNS OLARAK DEGISTIRIR";
echo "";
echo "";
if grep -qs 'nameserver 208.67.222.222' cat /etc/resolv.conf ; then
echo "DNS ADRESINIZ ZATEN GOOGLE DEGISTIRMEYE GEREK YOK"
else
rm -rf /etc/resolv.conf
touch /etc/resolv.conf | echo "nameserver 208.67.222.222" >> /etc/resolv.conf | echo "nameserver 208.67.220.220" >> /etc/resolv.conf
chmod 0755 /etc/resolv.conf
dos2unix /etc/resolv.conf
echo "DNS ADRESINIZ YANDEX DNS OLARAK DEĞİŞTİRİLDİ"
fi;
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0
