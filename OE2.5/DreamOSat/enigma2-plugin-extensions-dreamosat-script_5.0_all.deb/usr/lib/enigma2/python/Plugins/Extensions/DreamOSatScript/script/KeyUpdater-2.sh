#!/bin/sh
echo ""
echo "Key Downloader for E2"
echo "Now update Keys..."
cd /
#keys 
wget http://www.softcam.tv/deneme6.php?file=SoftCam.Key -qO /tmp/SoftCam.Key
wget http://www.softcam.tv/deneme6.php?file=AutoRoll.Key -qO /tmp/AutoRoll.Key
wget http://www.softcam.tv/deneme6.php?file=constant.cw -qO /tmp/constant.cw

echo "______________________________"
#find /tmp/SoftCam.Key
#find /tmp/AutoRoll.Key

chmod 644 /tmp/SoftCam.Key
chmod 644 /tmp/AutoRoll.Key
chmod 644 /tmp/constant.cw

cp /tmp/SoftCam.Key /usr/keys/
cp /tmp/AutoRoll.Key /usr/keys/
cp /tmp/constant.cw /usr/keys/
cp /tmp/SoftCam.Key /etc/tuxbox/config/
cp /tmp/constant.cw /etc/tuxbox/config/

rm -rf /tmp/SoftCam.Key
rm -rf /tmp/AutoRoll.Key
rm -rf /tmp/constant.cw

echo "Keys Downloaded"
echo " www.softcam.tv"

sleep 1
exit 0
