# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/plugin.py
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from os import listdir
from Plugins.Plugin import PluginDescriptor
from Screens.Console import Console
from Screens.Screen import Screen
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
from enigma import getDesktop
from enigma import eListbox, eTimer, eListboxPythonMultiContent, gFont, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, loadPNG, loadPic

DESKHEIGHT = getDesktop(0).size().height()
skin_path = "/usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/Skin/"

class DreamOSatScript(Screen):

    def __init__(self, session, args = None):
        self.session = session
        if DESKHEIGHT < 1000:		
            skin = skin_path + 'menuhd.xml'
        else:	
		     skin = skin_path + 'menufullhd.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()
        Screen.__init__(self, session)
        self['list'] = MenuList([])
        self['actions'] = ActionMap(['OkCancelActions'], {'ok': self.run,
         'cancel': self.close}, -1)
        self.onLayoutFinish.append(self.loadScriptList)

    def loadScriptList(self):
        try:
            list = listdir('/usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script')
            list = [ x[:-3] for x in list if x.endswith('.sh') ]
        except:
            list = []

        self['list'].setList(list)

    def run(self):
        try:
            script = self['list'].getCurrent()
        except:
            script = None

        if script is not None:
            title = script
            script = '/usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/%s.sh' % script
            self.session.open(Console, title, cmdlist=[script])
        return


def main(session, **kwargs):
    session.open(DreamOSatScript)


def menu(menuid, **kwargs):
    if menuid == 'camsetup':
        return [(_('Script...'),
          main,
          'DreamOSatScript',
          45)]
    return []

def Plugins(**kwargs):
    return [PluginDescriptor(name=_('DreamOSat Script'), description=_('www.dreamosat-forum.com'), where=PluginDescriptor.WHERE_PLUGINMENU, icon='plugin.png', fnc=main), PluginDescriptor(name=_('DreamOSat Script'), description=_('www.dreamosat-forum.com'), where=PluginDescriptor.WHERE_EXTENSIONSMENU, icon='plugin.png', fnc=main)]
