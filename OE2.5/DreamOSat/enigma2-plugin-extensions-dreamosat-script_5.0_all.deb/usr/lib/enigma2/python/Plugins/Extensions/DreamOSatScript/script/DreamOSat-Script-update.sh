#!/bin/sh
echo "---";

audi06_1="DreamOSat-Script-update.sh"
audi06_2="CCcam-server.sh"
audi06_3="Deb-Iptv-guncelle.sh"
# audi06_4="Dns-Degistir-Google.sh"
# audi06_5="Dns-Degistir-Yandex.sh"
audi06_6="Eklenti-yukleme.sh"
audi06_7="Ip-adres-ogrenme.sh"
audi06_8="Key-FreeColor36e.sh"
audi06_9="Key-FreeColor56e.sh"
audi06_10="KeyUpdater-2.sh"
audi06_11="KeyUpdater.sh"
audi06_12="OSCam-server.sh"
audi06_13="Satellites-guncelle.sh"
# audi06_14="Settings-chveneburi.sh"

#audi06_15="HDD-Mount.sh"
audi06_16="KeyUpdater-3.sh"
#audi06_17=""
#audi06_18=""
#audi06_19=""

audi06_20="OSCam-svn_Updater_armV7.sh"
audi06_21="OSCam_Updater_arm.sh"
audi06_22="OSCam_Updater_dm900-libusb.sh"
audi06_23="OSCam_Updater_dreambox_fpu.sh"
audi06_24="OSCam_Updater_mips-tuxbox-oe2.0.sh"
audi06_25="OSCam_Updater_mips-openpli40.sh"

#audi06_26=""
#audi06_27=""
#audi06_28=""
#audi06_29=""
#audi06_30=""

echo "------";
url="http://depo.dreamosat-forum.com/oZeL/DreamOSatScript";
echo "---------";
yol="/usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript"
echo "";
wget $url/__init__.py -qO $yol/__init__.py;
wget $url/__init__.pyo -qO $yol/__init__.pyo;
wget $url/plugin.py -qO $yol/plugin.py;
wget $url/plugin.pyo -qO $yol/plugin.pyo;

wget $url/plugin.png -qO $yol/plugin.png;
wget $url/logo.png -qO $yol/logo.png;
wget $url/logo2.png -qO $yol/logo2.png;

wget $url/Skin/menufullhd.xml -qO $yol/Skin/menufullhd.xml;
wget $url/Skin/menufullhd.xml -qO $yol/Skin/menufullhd.xml;

echo "------------";

wget $url/script/$audi06_1 -qO $yol/script/$audi06_1;
wget $url/script/$audi06_2 -qO $yol/script/$audi06_2;
wget $url/script/$audi06_3 -qO $yol/script/$audi06_3;
# wget $url/script/$audi06_4 -qO $yol/script/$audi06_4;
# wget $url/script/$audi06_5 -qO $yol/script/$audi06_5;
wget $url/script/$audi06_6 -qO $yol/script/$audi06_6;
wget $url/script/$audi06_7 -qO $yol/script/$audi06_7;
wget $url/script/$audi06_8 -qO $yol/script/$audi06_8;
wget $url/script/$audi06_9 -qO $yol/script/$audi06_9;
wget $url/script/$audi06_10 -qO $yol/script/$audi06_10;
wget $url/script/$audi06_11 -qO $yol/script/$audi06_11;
wget $url/script/$audi06_12 -qO $yol/script/$audi06_12;
wget $url/script/$audi06_13 -qO $yol/script/$audi06_13;
wget $url/script/$audi06_14 -qO $yol/script/$audi06_14;

wget $url/script/$audi06_15 -qO $yol/script/$audi06_15;
wget $url/script/$audi06_16 -qO $yol/script/$audi06_16;
# wget $url/script/$audi06_17 -qO $yol/script/$audi06_17;
# wget $url/script/$audi06_18 -qO $yol/script/$audi06_18;
# wget $url/script/$audi06_19 -qO $yol/script/$audi06_19;

wget $url/script/$audi06_20 -qO $yol/script/$audi06_20;
wget $url/script/$audi06_21 -qO $yol/script/$audi06_21;
wget $url/script/$audi06_22 -qO $yol/script/$audi06_22;
wget $url/script/$audi06_23 -qO $yol/script/$audi06_23;
wget $url/script/$audi06_24 -qO $yol/script/$audi06_24;
wget $url/script/$audi06_25 -qO $yol/script/$audi06_25;

# wget $url/script/$audi06_26 -qO $yol/script/$audi06_26;
# wget $url/script/$audi06_27 -qO $yol/script/$audi06_27;
# wget $url/script/$audi06_28 -qO $yol/script/$audi06_28;
# wget $url/script/$audi06_29 -qO $yol/script/$audi06_29;
# wget $url/script/$audi06_30 -qO $yol/script/$audi06_30;

echo "---------------";
chmod 0755 $yol/*.py -R;
chmod 0755 $yol/script/*.sh -R;
echo "------------------";
echo "DreamOSat Script güncellendi";
echo "---------------------";
echo "Uydu alıcınız Restart Ediliyor. iyi seyirler...";
echo "------------------------";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 3;
killall -9 enigma2;
exit 0
