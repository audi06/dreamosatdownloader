#!/bin/sh
wget http://www.lokumsat.esy.es/DEPO/Tools/satellites.xml -qO /etc/tuxbox/satellites.xml;
chmod 0755 /etc/tuxbox/satellites.xml -R;
echo ""
echo "Satellites.xlm güncellendi";
echo ""
echo "Uydu alıcınızı Restart Etmeyi Unutmayınız. iyi seyirler...";
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 3;
exit 0
