#!/bin/sh
wget http://www.lokumsat.esy.es/CaMs-EmU/OSCam/oscam.server -qO /etc/tuxbox/config/oscam.server;
rm -rf /usr/keys/oscam.server;
cp /etc/tuxbox/config/oscam.server /usr/keys/;
chmod 0755 /etc/tuxbox/config/oscam.server -R;
chmod 0755 /usr/keys/oscam.server -R;
echo "";
echo "OSCam Server güncellendi";
echo "";
echo "Uydu alıcınızı Restart Etmeyi Unutmayınız. iyi seyirler...";
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 3;
exit 0
