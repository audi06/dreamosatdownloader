#!/bin/sh
echo "DIS IP ADRESINIZ" >> /tmp/ipadres.txt;
wget -q -O - api.ipify.org|sed -e 's/.*Current IP Address: //' -e 's/<.*$//' >> /tmp/ipadres.txt;
echo "" >> /tmp/ipadres.txt;
echo "" >> /tmp/ipadres.txt;
echo "IC IP ADRESINIZ" >> /tmp/ipadres.txt;
ifconfig | grep 'inet addr:'| grep -v '127.0.0.1' | cut -d: -f2 | awk '{ print $1}' >> /tmp/ipadres.txt;
cat /tmp/ipadres.txt;
rm -rf /tmp/ipadres.txt;
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 3;
exit 0
