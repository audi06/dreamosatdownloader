from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from os import listdir
from Plugins.Plugin import PluginDescriptor
from Screens.Console import Console
from Screens.Screen import Screen

class DreamOSatScript(Screen):
    skin = '\n\t<screen position="150,100" size="420,400" title="DreamOSat Script" >\n\t\t<widget name="list" position="0,0" size="420,400" scrollbarMode="showOnDemand" />\n\t</screen>'

    def __init__(self, session, args = None):
        Screen.__init__(self, session)
        self.session = session
        self['list'] = MenuList([])
        self['actions'] = ActionMap(['OkCancelActions'], {'ok': self.run,
         'cancel': self.close}, -1)
        self.onLayoutFinish.append(self.loadScriptList)

    def loadScriptList(self):
        try:
            list = listdir('/usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script')
            list = [ x[:-3] for x in list if x.endswith('.sh') ]
        except:
            list = []

        self['list'].setList(list)

    def run(self):
        try:
            script = self['list'].getCurrent()
        except:
            script = None

        if script is not None:
            title = script
            script = '/usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript/script/%s.sh' % script
            self.session.open(Console, title, cmdlist=[script])
        return


def main(session, **kwargs):
    session.open(DreamOSatScript)


def menu(menuid, **kwargs):
    if menuid == 'camsetup':
        return [(_('Script...'),
          main,
          'DreamOSat Script',
          45)]
    return []


def Plugins(**kwargs):
    return [PluginDescriptor(name=_('DreamOSat Script'), description=_('www.dreamosat-forum.com'), where=PluginDescriptor.WHERE_PLUGINMENU, icon='plugin.png', fnc=main), PluginDescriptor(name=_('DreamOSat Script'), description=_('www.dreamosat-forum.com'), where=PluginDescriptor.WHERE_EXTENSIONSMENU, icon='plugin.png', fnc=main)]
