#!/bin/sh
cd /;
[ -d /etc/tuxbox/config/oscampowervu ] || mkdir -p /etc/tuxbox/config/oscampowervu;
[ -d /usr/keys ] || mkdir -p /usr/keys;
[ -d /tmp/keyupdate ] || mkdir -p /tmp/keyupdate;
wget http://www.lokumsat.esy.es/CaMs-EmU/SoftCam.Key -qO /tmp/keyupdate/SoftCam.Key;
wget http://www.lokumsat.esy.es/CaMs-EmU/constant.cw -qO /tmp/keyupdate/constant.cw;
chmod 0755 /tmp/keyupdate/ -R;
cd /tmp/keyupdate;
cp SoftCam.Key /etc/tuxbox/config/;
cp SoftCam.Key /usr/keys/;
cp constant.cw /etc/tuxbox/config/;
cp constant.cw /usr/keys/;
echo "";
cd /;
rm -rf /tmp/keyupdate;
echo "SoftCam.Key ve constant.cw güncellendi";
echo "";
echo "EMU Restart Etmeyi Unutmayınız. iyi seyirler...";
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 3;
exit 0
