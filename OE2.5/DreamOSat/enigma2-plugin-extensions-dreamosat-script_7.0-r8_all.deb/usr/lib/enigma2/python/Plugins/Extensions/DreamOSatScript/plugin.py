###########################################################
# Coded by audi06_19 (c) (R) 2017
# Support: www.dreamosat-forum.com
# E-Mail: admin@dreamosat-forum.com
###########################################################
from Plugins.Extensions.DreamOSatScript.scriptConsole import Myaudi06
from Plugins.Plugin import PluginDescriptor
from enigma import getDesktop

R_NAME = "By audi06_19 admin@dreamosat-forum.com"
R_VERSION = "7.0-r8 - 15.05.2018"

def main(session, **kwargs):
	session.open(Myaudi06)

def Plugins(**kwargs):
	screenwidth = getDesktop(0).size().width()
	if screenwidth and screenwidth == 1920:
		icon = "DreamOSat_FHD.png"
	else:
		icon = "DreamOSat_HD.png"
	return [PluginDescriptor(
		name = _('DreamOSat Script'),
		description = _('console bash shell script') + " (" + R_VERSION + ")",
		where = [
				PluginDescriptor.WHERE_PLUGINMENU,
				PluginDescriptor.WHERE_EXTENSIONSMENU
			],
		icon = icon,
		fnc = main
		)]

