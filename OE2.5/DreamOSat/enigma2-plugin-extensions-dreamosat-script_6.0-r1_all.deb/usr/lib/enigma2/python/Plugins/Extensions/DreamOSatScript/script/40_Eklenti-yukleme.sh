#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com
echo "";
echo "USB VEYA TMP KLASORUNE KOPYALADIGINIZ .DEB .IPK .TAR.GZ UZANTILI DOSYALARI BU SCRIPTLE YUKLEYEBILIRSINIZ";
echo "";
echo "";
sleep 1;
echo "DOSYALARINIZ YUKLENIYOR";
dpkg  -i --force-depends /tmp/*.deb;
dpkg  -i --force-depends /media/usb/*.deb;
opkg install --force-depends /tmp/*.ipk;
opkg install --force-depends /media/usb/*.ipk;
tar -zxvf /tmp/*.tar.gz -C /;
tar -zxvf /media/usb/*.tar.gz -C /;
echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0
