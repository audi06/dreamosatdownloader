#!/bin/sh
#Created By audi06_19 @https://dreamosat-forum.com
echo "---";
audi06_1="1_KeyUpdater.sh"
audi06_2="2_PowerVu-keys-all.sh"
audi06_3="3_KeyUpdater-3.sh"
audi06_4="4_OSCam-server.sh"
audi06_5="5_CCcam-server.sh"
audi06_6="6_N-Line_Server_Freecline.com.sh"
audi06_7="7_N-Line_Server_Testious.com.sh"
audi06_8="8_Key-FreeColor36e.sh"
audi06_9="9_Key-FreeColor56e.sh"
audi06_10="10_Ip-adres-ogrenme.sh"
audi06_11="11_MAC-adres-ogrenme.sh"
audi06_12="12_Free_Space.sh"
audi06_13="13_Emu_info.sh"
audi06_14="14_Delete_all_Crashlogs.sh"
audi06_15="15_Satellites-guncelle.sh"
audi06_16="16_Settings-chveneburi.sh"
audi06_17=""
audi06_18=""
audi06_19=""
audi06_20="20_OE2.5-HDD-Mount.sh"
audi06_21="21_OE2.5-USB-Mount.sh"
audi06_22="22_OE2.5-Microcard-Mount.sh"
audi06_23="23_OE2.5-Iptv-guncelle.sh"
audi06_24=""
audi06_25=""
audi06_26=""
audi06_27=""
audi06_28=""
audi06_29=""
audi06_30="30_OSCam_Updater_mips-tuxbox-oe2.0.sh"
audi06_31="31_OSCam_Updater_dreambox_fpu.sh"
audi06_32="32_OSCam_Updater_mips-openpli40.sh"
audi06_33="33_OSCam_Updater_arm.sh"
audi06_34="34_OSCam_Updater_dm900-libusb.sh"
audi06_35="35_OSCam-svn_Updater_armV7.sh"
audi06_36=""
audi06_37=""
audi06_38=""
audi06_39=""
audi06_40="40_Eklenti-yukleme.sh"
audi06_41="41_Dns-Degistir-Google.sh"
audi06_42="42_Dns-Degistir-Yandex.sh"
audi06_43=""
audi06_44=""
audi06_45=""
audi06_46=""
audi06_47=""
audi06_48=""
audi06_49=""
audi06_50="50_DreamOSat-Script-update.sh"

echo "------";
url="http://depo.dreamosat.net/oZeL/DreamOSatScript";
echo "---------";
yol="/usr/lib/enigma2/python/Plugins/Extensions/DreamOSatScript"
echo "";
wget $url/__init__.py -qO $yol/__init__.py;
wget $url/__init__.pyo -qO $yol/__init__.pyo;
wget $url/plugin.py -qO $yol/plugin.py;
wget $url/plugin.pyo -qO $yol/plugin.pyo;

wget $url/plugin.png -qO $yol/plugin.png;
wget $url/logo.png -qO $yol/logo.png;
wget $url/logo2.png -qO $yol/logo2.png;

wget $url/Skin/menufullhd.xml -qO $yol/Skin/menufullhd.xml;
wget $url/Skin/menufullhd.xml -qO $yol/Skin/menufullhd.xml;

echo "------------";

wget $url/script/$audi06_1 -qO $yol/script/$audi06_1;
wget $url/script/$audi06_2 -qO $yol/script/$audi06_2;
wget $url/script/$audi06_3 -qO $yol/script/$audi06_3;
wget $url/script/$audi06_4 -qO $yol/script/$audi06_4;
wget $url/script/$audi06_5 -qO $yol/script/$audi06_5;
wget $url/script/$audi06_6 -qO $yol/script/$audi06_6;
wget $url/script/$audi06_7 -qO $yol/script/$audi06_7;
wget $url/script/$audi06_8 -qO $yol/script/$audi06_8;
wget $url/script/$audi06_9 -qO $yol/script/$audi06_9;
wget $url/script/$audi06_10 -qO $yol/script/$audi06_10;
wget $url/script/$audi06_11 -qO $yol/script/$audi06_11;
wget $url/script/$audi06_12 -qO $yol/script/$audi06_12;
wget $url/script/$audi06_13 -qO $yol/script/$audi06_13;
wget $url/script/$audi06_14 -qO $yol/script/$audi06_14;
wget $url/script/$audi06_15 -qO $yol/script/$audi06_15;
wget $url/script/$audi06_16 -qO $yol/script/$audi06_16;
#wget $url/script/$audi06_17 -qO $yol/script/$audi06_17;
#wget $url/script/$audi06_18 -qO $yol/script/$audi06_18;
#wget $url/script/$audi06_19 -qO $yol/script/$audi06_19;
wget $url/script/$audi06_20 -qO $yol/script/$audi06_20;
wget $url/script/$audi06_21 -qO $yol/script/$audi06_21;
wget $url/script/$audi06_22 -qO $yol/script/$audi06_22;
wget $url/script/$audi06_23 -qO $yol/script/$audi06_23;
#wget $url/script/$audi06_24 -qO $yol/script/$audi06_24;
#wget $url/script/$audi06_25 -qO $yol/script/$audi06_25;
#wget $url/script/$audi06_26 -qO $yol/script/$audi06_26;
#wget $url/script/$audi06_27 -qO $yol/script/$audi06_27;
#wget $url/script/$audi06_28 -qO $yol/script/$audi06_28;
#wget $url/script/$audi06_29 -qO $yol/script/$audi06_29;
wget $url/script/$audi06_30 -qO $yol/script/$audi06_30;
wget $url/script/$audi06_31 -qO $yol/script/$audi06_31;
wget $url/script/$audi06_32 -qO $yol/script/$audi06_32;
wget $url/script/$audi06_33 -qO $yol/script/$audi06_33;
wget $url/script/$audi06_34 -qO $yol/script/$audi06_34;
wget $url/script/$audi06_35 -qO $yol/script/$audi06_35;
#wget $url/script/$audi06_36 -qO $yol/script/$audi06_36;
#wget $url/script/$audi06_37 -qO $yol/script/$audi06_37;
#wget $url/script/$audi06_38 -qO $yol/script/$audi06_38;
#wget $url/script/$audi06_39 -qO $yol/script/$audi06_39;
wget $url/script/$audi06_40 -qO $yol/script/$audi06_40;
#wget $url/script/$audi06_41 -qO $yol/script/$audi06_41;
#wget $url/script/$audi06_42 -qO $yol/script/$audi06_42;
#wget $url/script/$audi06_43 -qO $yol/script/$audi06_43;
#wget $url/script/$audi06_44 -qO $yol/script/$audi06_44;
#wget $url/script/$audi06_45 -qO $yol/script/$audi06_45;
#wget $url/script/$audi06_46 -qO $yol/script/$audi06_46;
#wget $url/script/$audi06_47 -qO $yol/script/$audi06_47;
#wget $url/script/$audi06_48 -qO $yol/script/$audi06_48;
#wget $url/script/$audi06_49 -qO $yol/script/$audi06_49;
wget $url/script/$audi06_50 -qO $yol/script/$audi06_50;

echo "---------------";
chmod 0755 $yol/*.py -R;
chmod 0777 $yol/script/*.sh -R;
echo "------------------";
echo "DreamOSat Script güncellendi";
echo "---------------------";
echo "Uydu alıcınız Restart Ediliyor. iyi seyirler...";
echo "------------------------";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 3;
killall -9 enigma2;
exit 0
