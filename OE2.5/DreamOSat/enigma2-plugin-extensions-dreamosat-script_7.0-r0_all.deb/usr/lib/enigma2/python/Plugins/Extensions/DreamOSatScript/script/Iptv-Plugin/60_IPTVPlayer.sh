#!/bin/sh
# Coded by audi06_19 (c) (®) (©) 2017
# Support: www.dreamosat-forum.com
# E-Mail: admin@dreamosat-forum.com
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."

ping -q -c 1 -W 1 8.8.8.8 > /dev/null; 
if [ $? -eq 1 ]; 
then exit; 
fi;
sleep 1;

rm -rf /tmp/DreamOSat
[ -d /tmp/DreamOSat ] || mkdir -p /tmp/DreamOSat > /dev/null;
cd /tmp/DreamOSat

echo $FIN

if [ ! -e /usr/lib/enigma2/python/Plugins/Extensions/IPTVPlayer ]; then
	wget http://iptvplayer.pl/iptvinstaller.sh -O - | /bin/sh
fi

echo $FIN

if [ ! -e /usr/lib/enigma2/python/Plugins/Extensions/IPTVPlayer/hosts/hostinfoversion.py ]; then
	curl -Lbo -s "https://gitlab.com/mosz_nowy/infoversion/repository/archive.zip?ref=master" -o "iptvplayer.zip"
	unzip -q iptvplayer.zip
	cp -rf infoversion-master*/* /usr/lib/enigma2/python/Plugins/Extensions/IPTVPlayer
fi

sync
rm -rf /tmp/DreamOSat
echo "";
echo "===========================================";
echo "           ..:: A U T H O R ::..           ";
echo "              << audi06_19 >>              ";
echo "   ..:: https://dreamosat-forum.com ::..   ";
echo "===========================================";
sleep 3;
exit 0

