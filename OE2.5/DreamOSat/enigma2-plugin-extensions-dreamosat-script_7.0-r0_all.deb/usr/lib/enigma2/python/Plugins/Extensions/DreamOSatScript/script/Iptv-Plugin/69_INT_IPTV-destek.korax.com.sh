#!/bin/sh
# Coded by audi06_19 (c) (®) (©) 2017
# Support: www.dreamosat-forum.com
# E-Mail: admin@dreamosat-forum.com
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."

ping -q -c 1 -W 1 8.8.8.8 > /dev/null; 
if [ $? -eq 1 ]; 
then exit; 
fi;
sleep 1;

cd /;
[ -d /tmp/IPTV ] || mkdir -p /tmp/IPTV;
cd /tmp/IPTV;
sleep 1;

wget --quiet -O - http://destek.korax.com.tr/UYDUSIS/CLOUD.txt | sed -En 's/^(.*),(.*$)/#EXTINF:-1,\1\n\2/p' >CLOUD.txt

sed '/#EXTINF:-1,/!s/:/%3a/g' CLOUD.txt >0
sed 's/#EXTINF:-1,/#DESCRIPTION: /g' 0 >00
sed '/#SERVICE 4097:0:1:0:0:0:0:0:0:0:rt/!s/http%3a/#SERVICE 4097:0:1:0:0:0:0:0:0:0:http%3a/' 00 >000
sed '/#SERVICE 4097:0:1:0:0:0:0:0:0:0:rt/!s/rtmp%3a/#SERVICE 4097:0:1:0:0:0:0:0:0:0:rtmp%3a/' 000 >0000
sed -i '1i #NAME INT IPTV korax.com' 0000
sed -n '/^#DES.*/h;/^#SER.*/{p;x;p};/^#NA.*/p' 0000 >userbouquet.INT_IPTV-korax.com.tv

sleep 1;
cp -rd /tmp/IPTV/userbouquet.INT_IPTV-korax.com.tv /etc/enigma2/userbouquet.INT_IPTV-korax.com.tv > /dev/null

if grep -qs 'userbouquet.INT_IPTV-korax.com.tv' cat /etc/enigma2/bouquets.tv  ; then
    echo "Lista esistente in Bouquet"
else 
	echo "[+]Install INT IPTV korax.com List ..."
	echo '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.INT_IPTV-korax.com.tv" ORDER BY bouquet' >> /etc/enigma2/bouquets.tv
fi
cd /;
rm -rf /tmp/IPTV > /dev/null 2>&1

wget -q -O - http://127.0.0.1/web/servicelistreload?mode=0 > /dev/null 2>&1
wget -q -O - http://127.0.0.1/web/servicelistreload?mode=2 > /dev/null 2>&1

echo "";
echo "###### Thank you By. korax.com";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0

