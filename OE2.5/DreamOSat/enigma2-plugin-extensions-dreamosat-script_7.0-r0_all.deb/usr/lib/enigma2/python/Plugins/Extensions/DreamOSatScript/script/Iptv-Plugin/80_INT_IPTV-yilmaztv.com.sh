#!/bin/sh
# Coded by audi06_19 (c) (®) (©) 2017
# Support: www.dreamosat-forum.com
# E-Mail: admin@dreamosat-forum.com
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."

ping -q -c 1 -W 1 8.8.8.8 > /dev/null; 
if [ $? -eq 1 ]; 
then exit; 
fi;
sleep 1;

cd /;
[ -d /tmp/IPTV ] || mkdir -p /tmp/IPTV;
cd /tmp/IPTV;
sleep 1;

wget -q http://www.yilmaztv.com/1.m3u
sed -i '1,4d' 1.m3u

sed -i 's/^#//' 1.m3u
awk NF 1.m3u >2.m3u

sed -i '1i #NAME INT YILMAZ TV' 2.m3u

sed -i 's/^EXTINF/#EXTINF:-1,/' 2.m3u
sed -i 's/^#EXTINF:-1,*.*,/#EXTINF:-1,/' 2.m3u

sed -i 's/ | YILMAZ06//' 2.m3u
sleep 2;

sed '/#EXTINF:-1,/!s/:/%3a/g' 2.m3u >0
sed 's/#EXTINF:-1,/#DESCRIPTION: /g' 0 >00
sed '/#SERVICE 4097:0:1:0:0:0:0:0:0:0:rt/!s/http%3a/#SERVICE 4097:0:1:0:0:0:0:0:0:0:http%3a/' 00 >000
sed -n '/^#DES.*/h;/^#SER.*/{p;x;p};/^#NA.*/p' 000 >userbouquet.INT_IPTV-yilmaztv.com.tv
echo "";
echo 'DOWNLOAD'
sleep 1;
cp -rd /tmp/IPTV/userbouquet.INT_IPTV-yilmaztv.com.tv /etc/enigma2/userbouquet.INT_IPTV-yilmaztv.com.tv > /dev/null

if grep -qs 'userbouquet.INT_IPTV-yilmaztv.com.tv' cat /etc/enigma2/bouquets.tv  ; then
    echo "Lista esistente in Bouquet"
else 
	echo "[+]Install INT 2017 Movies ..."
	echo '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "userbouquet.INT_IPTV-yilmaztv.com.tv" ORDER BY bouquet' >> /etc/enigma2/bouquets.tv
fi
cd /;
rm -rf /tmp/IPTV > /dev/null 2>&1

wget -q -O - http://127.0.0.1/web/servicelistreload?mode=0 > /dev/null 2>&1
wget -q -O - http://127.0.0.1/web/servicelistreload?mode=2 > /dev/null 2>&1

echo "";
echo "###### Thank you By. Yılmaz";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 1;
exit 0

