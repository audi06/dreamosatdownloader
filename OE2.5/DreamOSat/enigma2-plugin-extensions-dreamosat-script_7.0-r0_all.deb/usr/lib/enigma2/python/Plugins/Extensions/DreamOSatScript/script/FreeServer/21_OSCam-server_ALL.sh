#!/bin/sh
# Coded by audi06_19 (c) (®) (©) 2017
# Support: www.dreamosat-forum.com
# E-Mail: admin@dreamosat-forum.com
FIN="=================================================="
echo $FIN
echo ".....:: LÜTFEN BEKLEYİNİZ .... PLEASE WAIT ::....."

ping -q -c 1 -W 1 8.8.8.8 > /dev/null; 
if [ $? -eq 1 ]; 
then exit; 
fi;
sleep 1;

rm -rf /tmp/DreamOSat
[ -d /tmp/DreamOSat ] || mkdir -p /tmp/DreamOSat > /dev/null;
cd /tmp/DreamOSat
################################### FIND-OSCAM.SERVER ####################################
> /tmp/DreamOSat/Your-oscam.server-Location
find /usr/keys/ /var/keys/ /etc -iname oscam.server > /tmp/DreamOSat/Your-oscam.server-Location
        echo $FIN
        echo "Cihazınızda yüklü oscam.server dosyalarını arıyorum..."
	echo "I'am looking for your oscam.server file/s hold on a sec"
if [ -s /tmp/DreamOSat/Your-oscam.server-Location ]
then
        echo $FIN
        echo "Aşağıdaki konumda oscam.server dosyanızı buldum ;)"
        echo "Found oscam.server file/s in the following location/s ;)"
	echo "--------------------------------------------";
        cat /tmp/DreamOSat/Your-oscam.server-Location
	echo "--------------------------------------------";
	echo $FIN
else
        echo $FIN
        echo "Cihazınızda yüklü oscam.server dosyası yok ????"
        echo "I can't find your oscam.server file have you got one ????"
        echo $FIN
        echo "/etc/tuxbox/config/ içerisine oscam.server dosyası oluşturuyorum..."
        echo "I am creating an oscam.server file in /etc/tuxbox/config/ ..."
fi
######################################################################################
EMU="/tmp/DreamOSat/cline"
EMU1="/etc/tuxbox/config/oscam.server"

URL="https://dreamosat-forum.com"
URL1="http://cccamgenerators.com/generators/get.php"
URL2="http://cccamgood.com/free/get2.php"
URL3="http://cccam-free.com/NEW/new0.php"
URL4="http://www.boss-cccam.com/Test.php"
URL5="http://www.cccamlux.com/Free-CCcam.php"
URL6="http://cccamgate.com/cccam-test.php"
URL7="http://cccamspot.com/spot/get.php"
URL8="http://infosat.satunivers.tv/download1.php?file=srtx5.txt"
URL9="http://cccamgenerador.com/gratis/get2.php"
URL10="http://freeccamserver.com/free/get2.php"
URL11="http://cccammania.com/free4/get2.php"
URL12="http://cccam-free2.com/free2/get.php"
URL13="http://free-cccam.com/freecccam/get.php"
URL14="http://cccamia.com/NEW/new0.php"
URL15="http://powerfullcccam.com/powerfull/get.php"
URL16="http://free-cccam.com/freecccam/get.php"
URL17="http://cccampowerful.com/freepowerful/get.php"
URL18="http://cccamfreeserver.com/free/get.php"
URL19="http://uhdcccam.com/free/get.php"
URL20="http://mecccam.com/free-cccam.php"

echo "DATE server" $URL1
curl -Lbo -s --max-time 10 $URL1 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL2
curl -Lbo -s --max-time 10 $URL2 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL3
curl -Lbo -s --max-time 10 $URL3 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL4
curl -Lbo -s --max-time 10 $URL4 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL5
curl -Lbo -s --max-time 10 $URL5 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL6
curl -Lbo -s --max-time 10 $URL6 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL7
curl -Lbo -s --max-time 10 $URL7 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL8
curl -Lbo -s --max-time 10 $URL8 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL9
curl -Lbo -s --max-time 10 $URL9 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL10
curl -Lbo -s --max-time 10 $URL10 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL11
curl -Lbo -s --max-time 10 $URL11 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL12
curl -Lbo -s --max-time 10 $URL12 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL13
curl -Lbo -s --max-time 10 $URL13 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL14
curl -Lbo -s --max-time 10 $URL14 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL15
curl -Lbo -s --max-time 10 $URL15 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL16
curl -Lbo -s --max-time 10 $URL16 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL17
curl -Lbo -s --max-time 10 $URL17 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL18
curl -Lbo -s --max-time 10 $URL18 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL19
curl -Lbo -s --max-time 10 $URL19 | grep -o -i 'C:[^<]*' >>$EMU
echo "DATE server" $URL20
curl -Lbo -s --max-time 10 $URL20 | grep -o -i 'C:[^<]*' >>$EMU

sleep 1
if grep -qs 'C: ' cat $EMU ; then
sed -i -e 's/port: //g' -e 's/user: //g' -e 's/pass: //g' -e 's/c: /C: /g' $EMU

awk '{print "[reader]"}' cline >>reader
awk '{print "label                         = " $2 }' cline >>label
awk '{print "protocol                      = cccam" }' cline >>protocol
awk '{print "device                        = " $2 "," $3 }' cline >>device
awk '{print "user                          = " $4 }' cline >>user
awk '{print "password                      = " $5 }' cline >>password
awk '{print "inactivitytimeout             = 30" }' cline >>inactivitytimeout
awk '{print "group                         = 1" }' cline >>group
awk '{print "cccversion                    = 2.2.1" }' cline >>cccversion
awk '{print "cccmaxhops                    = 3" }' cline >>cccmaxhop
awk '{print "ccckeepalive                  = 1" }' cline >>ccckeepalive
awk '{print "audisabled                    = 1" }' cline >>audisabled
awk '{print "disablecrccws                 = 1" }' cline >>disablecrccws
sleep 1
echo "" >> oscam.server
sed -n '1,1p' reader >> oscam.server
sed -n '1,1p' label >> oscam.server
sed -n '1,1p' protocol >> oscam.server
sed -n '1,1p' device >> oscam.server
sed -n '1,1p' user >> oscam.server
sed -n '1,1p' password >> oscam.server
sed -n '1,1p' inactivitytimeout >> oscam.server
sed -n '1,1p' cccversion >> oscam.server
sed -n '1,1p' group >> oscam.server
sed -n '1,1p' cccmaxhop >> oscam.server
sed -n '1,1p' ccckeepalive >> oscam.server
sed -n '1,1p' audisabled >> oscam.server
sed -n '1,1p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '2,2p' reader >> oscam.server
sed -n '2,2p' label >> oscam.server
sed -n '2,2p' protocol >> oscam.server
sed -n '2,2p' device >> oscam.server
sed -n '2,2p' user >> oscam.server
sed -n '2,2p' password >> oscam.server
sed -n '2,2p' inactivitytimeout >> oscam.server
sed -n '2,2p' cccversion >> oscam.server
sed -n '2,2p' group >> oscam.server
sed -n '2,2p' cccmaxhop >> oscam.server
sed -n '2,2p' ccckeepalive >> oscam.server
sed -n '2,2p' audisabled >> oscam.server
sed -n '2,2p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '3,3p' reader >> oscam.server
sed -n '3,3p' label >> oscam.server
sed -n '3,3p' protocol >> oscam.server
sed -n '3,3p' device >> oscam.server
sed -n '3,3p' user >> oscam.server
sed -n '3,3p' password >> oscam.server
sed -n '3,3p' inactivitytimeout >> oscam.server
sed -n '3,3p' cccversion >> oscam.server
sed -n '3,3p' group >> oscam.server
sed -n '3,3p' cccmaxhop >> oscam.server
sed -n '3,3p' ccckeepalive >> oscam.server
sed -n '3,3p' audisabled >> oscam.server
sed -n '3,3p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '4,4p' reader >> oscam.server
sed -n '4,4p' label >> oscam.server
sed -n '4,4p' protocol >> oscam.server
sed -n '4,4p' device >> oscam.server
sed -n '4,4p' user >> oscam.server
sed -n '4,4p' password >> oscam.server
sed -n '4,4p' inactivitytimeout >> oscam.server
sed -n '4,4p' cccversion >> oscam.server
sed -n '4,4p' group >> oscam.server
sed -n '4,4p' cccmaxhop >> oscam.server
sed -n '4,4p' ccckeepalive >> oscam.server
sed -n '4,4p' audisabled >> oscam.server
sed -n '4,4p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '5,5p' reader >> oscam.server
sed -n '5,5p' label >> oscam.server
sed -n '5,5p' protocol >> oscam.server
sed -n '5,5p' device >> oscam.server
sed -n '5,5p' user >> oscam.server
sed -n '5,5p' password >> oscam.server
sed -n '5,5p' inactivitytimeout >> oscam.server
sed -n '5,5p' cccversion >> oscam.server
sed -n '5,5p' group >> oscam.server
sed -n '5,5p' cccmaxhop >> oscam.server
sed -n '5,5p' ccckeepalive >> oscam.server
sed -n '5,5p' audisabled >> oscam.server
sed -n '5,5p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '6,6p' reader >> oscam.server
sed -n '6,6p' label >> oscam.server
sed -n '6,6p' protocol >> oscam.server
sed -n '6,6p' device >> oscam.server
sed -n '6,6p' user >> oscam.server
sed -n '6,6p' password >> oscam.server
sed -n '6,6p' inactivitytimeout >> oscam.server
sed -n '6,6p' cccversion >> oscam.server
sed -n '6,6p' group >> oscam.server
sed -n '6,6p' cccmaxhop >> oscam.server
sed -n '6,6p' ccckeepalive >> oscam.server
sed -n '6,6p' audisabled >> oscam.server
sed -n '6,6p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '7,7p' reader >> oscam.server
sed -n '7,7p' label >> oscam.server
sed -n '7,7p' protocol >> oscam.server
sed -n '7,7p' device >> oscam.server
sed -n '7,7p' user >> oscam.server
sed -n '7,7p' password >> oscam.server
sed -n '7,7p' inactivitytimeout >> oscam.server
sed -n '7,7p' cccversion >> oscam.server
sed -n '7,7p' group >> oscam.server
sed -n '7,7p' cccmaxhop >> oscam.server
sed -n '7,7p' ccckeepalive >> oscam.server
sed -n '7,7p' audisabled >> oscam.server
sed -n '7,7p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '8,8p' reader >> oscam.server
sed -n '8,8p' label >> oscam.server
sed -n '8,8p' protocol >> oscam.server
sed -n '8,8p' device >> oscam.server
sed -n '8,8p' user >> oscam.server
sed -n '8,8p' password >> oscam.server
sed -n '8,8p' inactivitytimeout >> oscam.server
sed -n '8,8p' cccversion >> oscam.server
sed -n '8,8p' group >> oscam.server
sed -n '8,8p' cccmaxhop >> oscam.server
sed -n '8,8p' ccckeepalive >> oscam.server
sed -n '8,8p' audisabled >> oscam.server
sed -n '8,8p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '9,9p' reader >> oscam.server
sed -n '9,9p' label >> oscam.server
sed -n '9,9p' protocol >> oscam.server
sed -n '9,9p' device >> oscam.server
sed -n '9,9p' user >> oscam.server
sed -n '9,9p' password >> oscam.server
sed -n '9,9p' inactivitytimeout >> oscam.server
sed -n '9,9p' cccversion >> oscam.server
sed -n '9,9p' group >> oscam.server
sed -n '9,9p' cccmaxhop >> oscam.server
sed -n '9,9p' ccckeepalive >> oscam.server
sed -n '9,9p' audisabled >> oscam.server
sed -n '9,9p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '10,10p' reader >> oscam.server
sed -n '10,10p' label >> oscam.server
sed -n '10,10p' protocol >> oscam.server
sed -n '10,10p' device >> oscam.server
sed -n '10,10p' user >> oscam.server
sed -n '10,10p' password >> oscam.server
sed -n '10,10p' inactivitytimeout >> oscam.server
sed -n '10,10p' cccversion >> oscam.server
sed -n '10,10p' group >> oscam.server
sed -n '10,10p' cccmaxhop >> oscam.server
sed -n '10,10p' ccckeepalive >> oscam.server
sed -n '10,10p' audisabled >> oscam.server
sed -n '10,10p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '11,11p' reader >> oscam.server
sed -n '11,11p' label >> oscam.server
sed -n '11,11p' protocol >> oscam.server
sed -n '11,11p' device >> oscam.server
sed -n '11,11p' user >> oscam.server
sed -n '11,11p' password >> oscam.server
sed -n '11,11p' inactivitytimeout >> oscam.server
sed -n '11,11p' cccversion >> oscam.server
sed -n '11,11p' group >> oscam.server
sed -n '11,11p' cccmaxhop >> oscam.server
sed -n '11,11p' ccckeepalive >> oscam.server
sed -n '11,11p' audisabled >> oscam.server
sed -n '11,11p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '12,12p' reader >> oscam.server
sed -n '12,12p' label >> oscam.server
sed -n '12,12p' protocol >> oscam.server
sed -n '12,12p' device >> oscam.server
sed -n '12,12p' user >> oscam.server
sed -n '12,12p' password >> oscam.server
sed -n '12,12p' inactivitytimeout >> oscam.server
sed -n '12,12p' cccversion >> oscam.server
sed -n '12,12p' group >> oscam.server
sed -n '12,12p' cccmaxhop >> oscam.server
sed -n '12,12p' ccckeepalive >> oscam.server
sed -n '12,12p' audisabled >> oscam.server
sed -n '12,12p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '13,13p' reader >> oscam.server
sed -n '13,13p' label >> oscam.server
sed -n '13,13p' protocol >> oscam.server
sed -n '13,13p' device >> oscam.server
sed -n '13,13p' user >> oscam.server
sed -n '13,13p' password >> oscam.server
sed -n '13,13p' inactivitytimeout >> oscam.server
sed -n '13,13p' cccversion >> oscam.server
sed -n '13,13p' group >> oscam.server
sed -n '13,13p' cccmaxhop >> oscam.server
sed -n '13,13p' ccckeepalive >> oscam.server
sed -n '13,13p' audisabled >> oscam.server
sed -n '13,13p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '14,14p' reader >> oscam.server
sed -n '14,14p' label >> oscam.server
sed -n '14,14p' protocol >> oscam.server
sed -n '14,14p' device >> oscam.server
sed -n '14,14p' user >> oscam.server
sed -n '14,14p' password >> oscam.server
sed -n '14,14p' inactivitytimeout >> oscam.server
sed -n '14,14p' cccversion >> oscam.server
sed -n '14,14p' group >> oscam.server
sed -n '14,14p' cccmaxhop >> oscam.server
sed -n '14,14p' ccckeepalive >> oscam.server
sed -n '14,14p' audisabled >> oscam.server
sed -n '14,14p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '15,15p' reader >> oscam.server
sed -n '15,15p' label >> oscam.server
sed -n '15,15p' protocol >> oscam.server
sed -n '15,15p' device >> oscam.server
sed -n '15,15p' user >> oscam.server
sed -n '15,15p' password >> oscam.server
sed -n '15,15p' inactivitytimeout >> oscam.server
sed -n '15,15p' cccversion >> oscam.server
sed -n '15,15p' group >> oscam.server
sed -n '15,15p' cccmaxhop >> oscam.server
sed -n '15,15p' ccckeepalive >> oscam.server
sed -n '15,15p' audisabled >> oscam.server
sed -n '15,15p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '16,16p' reader >> oscam.server
sed -n '16,16p' label >> oscam.server
sed -n '16,16p' protocol >> oscam.server
sed -n '16,16p' device >> oscam.server
sed -n '16,16p' user >> oscam.server
sed -n '16,16p' password >> oscam.server
sed -n '16,16p' inactivitytimeout >> oscam.server
sed -n '16,16p' cccversion >> oscam.server
sed -n '16,16p' group >> oscam.server
sed -n '16,16p' cccmaxhop >> oscam.server
sed -n '16,16p' ccckeepalive >> oscam.server
sed -n '16,16p' audisabled >> oscam.server
sed -n '16,16p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '17,17p' reader >> oscam.server
sed -n '17,17p' label >> oscam.server
sed -n '17,17p' protocol >> oscam.server
sed -n '17,17p' device >> oscam.server
sed -n '17,17p' user >> oscam.server
sed -n '17,17p' password >> oscam.server
sed -n '17,17p' inactivitytimeout >> oscam.server
sed -n '17,17p' cccversion >> oscam.server
sed -n '17,17p' group >> oscam.server
sed -n '17,17p' cccmaxhop >> oscam.server
sed -n '17,17p' ccckeepalive >> oscam.server
sed -n '17,17p' audisabled >> oscam.server
sed -n '17,17p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '18,18p' reader >> oscam.server
sed -n '18,18p' label >> oscam.server
sed -n '18,18p' protocol >> oscam.server
sed -n '18,18p' device >> oscam.server
sed -n '18,18p' user >> oscam.server
sed -n '18,18p' password >> oscam.server
sed -n '18,18p' inactivitytimeout >> oscam.server
sed -n '18,18p' cccversion >> oscam.server
sed -n '18,18p' group >> oscam.server
sed -n '18,18p' cccmaxhop >> oscam.server
sed -n '18,18p' ccckeepalive >> oscam.server
sed -n '18,18p' audisabled >> oscam.server
sed -n '18,18p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '19,19p' reader >> oscam.server
sed -n '19,19p' label >> oscam.server
sed -n '19,19p' protocol >> oscam.server
sed -n '19,19p' device >> oscam.server
sed -n '19,19p' user >> oscam.server
sed -n '19,19p' password >> oscam.server
sed -n '19,19p' inactivitytimeout >> oscam.server
sed -n '19,19p' cccversion >> oscam.server
sed -n '19,19p' group >> oscam.server
sed -n '19,19p' cccmaxhop >> oscam.server
sed -n '19,19p' ccckeepalive >> oscam.server
sed -n '19,19p' audisabled >> oscam.server
sed -n '19,19p' disablecrccws >> oscam.server
echo "" >> oscam.server
sed -n '20,20p' reader >> oscam.server
sed -n '20,20p' label >> oscam.server
sed -n '20,20p' protocol >> oscam.server
sed -n '20,20p' device >> oscam.server
sed -n '20,20p' user >> oscam.server
sed -n '20,20p' password >> oscam.server
sed -n '20,20p' inactivitytimeout >> oscam.server
sed -n '20,20p' cccversion >> oscam.server
sed -n '20,20p' group >> oscam.server
sed -n '20,20p' cccmaxhop >> oscam.server
sed -n '20,20p' ccckeepalive >> oscam.server
sed -n '20,20p' audisabled >> oscam.server
sed -n '20,20p' disablecrccws >> oscam.server
echo "" >> oscam.server

sleep 3;

cat > cline1 << EOF
#### "*******************************************"
#### "*          ..:: A U T H O R ::..          *"
#### "*             << audi06_19 >>             *"
#### "*  ..:: https://dreamosat-forum.com ::..  *"
#### "*******************************************"
EOF
sleep 1
cat >> oscam.server << EOF
####################### Emulator ############################

[reader]
label                         = constant.cw
enable                        = 1
protocol                      = constcw
device                        = /etc/tuxbox/config/constant.cw
caid                          = 2600,0B00,0B02,0500,0963,06AD,0940
group                         = 1

[reader]
label                         = emulator
protocol                      = emu
device                        = emulator
caid                          = 090F,0500,1801,0604,2600,FFFF,0E00,4AE1,1010
detect                        = cd
ident                         = 090F:000000;0500:000000,023800,021110,007400,007800;1801:000000,007301,001101,002111;0604:000000;2600:000000;FFFF:000000;0E00:000000;4AE1:000011,000014,0000FE;1010:000000
group                         = 1
emmcache                      = 1,5,31,1
saveemm-u                     = 1
emu_auproviders               = 0604:010200;0E00:000000;4AE1:000011,000014,0000FE;1010:000000
emu_datecodedenabled          = 1

[reader]
label                         = AFN
description                   = AFN-EMU
protocol                      = emu
device                        = Emulator
cacheex                       = 1
cacheex_maxhop                = 1
cacheex_allow_request         = 1
caid                          = 0E00
ecmwhitelist                  = 0E00:91
detect                        = cd
group                         = 1
emmcache                      = 1,5,31,1
emu_auproviders               = 0E00:000000
auprovid                      = 000E00

EOF
sleep 2
cat oscam.server >> cline1

mv cline1 $EMU1
  echo $FIN
  echo "C+Line server indirildi, /etc/tuxbox/config/oscam.server içerisine yazıldı ...";
  echo "C+Line server downloaded, it was written in /etc/tuxbox/config/oscam.server ...";
  sleep 2;
  echo $FIN
  echo "DreamOSat camManager Restart Etmeyi Unutmayınız. iyi seyirler ...";
  echo "Do not forget to restart DreamOSat camManager. good looking ...";
else
  echo $FIN
  echo "Server Off, bağlantı kurulamadı ..."
  echo "Server Off, unable to connect ...";
  echo $FIN
  echo "Teknik Destek İçin (www.dreamosat-forum.com) Yardım Alınız ...";
  echo "For Technical Support (www.dreamosat-forum.com) Get Help ...";
fi

cd /
rm -rf /tmp/DreamOSat

echo "";
echo "*******************************************";
echo "*          ..:: A U T H O R ::..          *";
echo "*             << audi06_19 >>             *";
echo "*  ..:: https://dreamosat-forum.com ::..  *";
echo "*******************************************";
sleep 2;
exit 0

