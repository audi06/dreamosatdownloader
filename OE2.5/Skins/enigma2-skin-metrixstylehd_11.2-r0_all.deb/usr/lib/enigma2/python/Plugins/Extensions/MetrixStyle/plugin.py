#!/usr/bin/env python
# -*- coding: iso-8859-1 -*-
#######################################################################
#
#    MyMetrix
#    Coded by iMaxxx (c) 2013
#    Mod MetrixStyle for DreamOS by arki
#
#  This plugin is licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported License.
#  To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/
#  or send a letter to Creative Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#  Alternatively, this plugin may be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.
#
#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#
#######################################################################

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Screens.Console import Console
from Screens.Standby import TryQuitMainloop
from Components.ActionMap import NumberActionMap
from Components.AVSwitch import AVSwitch
from Components.config import config, configfile, ConfigYesNo, ConfigSubsection, getConfigListEntry, ConfigSelection, ConfigNumber, ConfigText, ConfigInteger
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Components.Language import language
from Components.Sources.StaticText import StaticText
from os import environ, listdir, remove, rename, system, path
from skin import parseColor
from Components.Pixmap import Pixmap
import urllib
import gettext
from enigma import ePicLoad
from Tools.Directories import fileExists, resolveFilename, SCOPE_LANGUAGE, SCOPE_PLUGINS

#############################################################

lang = language.getLanguage()
environ["LANGUAGE"] = lang[:2]
gettext.bindtextdomain("enigma2", resolveFilename(SCOPE_LANGUAGE))
gettext.textdomain("enigma2")
gettext.bindtextdomain("MetrixStyle", "%s%s" % (resolveFilename(SCOPE_PLUGINS), "Extensions/MetrixStyle/locale/"))

global metrix_firstrun
metrix_firstrun=True

def _(txt):
	t = gettext.dgettext("MetrixStyle", txt)
	if t == txt:
		t = gettext.gettext(txt)
	return t

def translateBlock(block):
	for x in TranslationHelper:
		if block.__contains__(x[0]):
			block = block.replace(x[0], x[1])
	return block

#######################################################################

def main(session, **kwargs):
	session.open(MetrixStyle,"/usr/lib/enigma2/python/Plugins/Extensions/MetrixStyle/images/metrixcolors.png")

def Plugins(**kwargs):
	return PluginDescriptor(name="MetrixStyle", description=_("Setup for Skin MetrixStyleHD"), where = PluginDescriptor.WHERE_PLUGINMENU, icon="plugin.png", fnc=main)

#######################################################################

class MetrixStyle(ConfigListScreen, Screen):
	skin = """
	<screen name="MetrixStyle" title="MetrixStyle Setup" position="40,40" size="1200,640" flags="wfNoBorder" backgroundColor="#25000000">
	<widget name="title" position="20,15" size="250,50" font="Regular; 40" valign="center" transparent="1" backgroundColor="#25000000" />
	<widget name="setup" position="350,18" size="200,50" font="Regular; 30" valign="center" backgroundColor="#25000000" transparent="1" halign="left" />
	<widget name="version" position="620,18" size="200,50" font="Regular;20" valign="center" backgroundColor="#25000000" transparent="1" halign="left" />
	<widget name="author" position="860,18" size="200,50" font="Regular; 30" valign="center" backgroundColor="#25000000" transparent="1" halign="left" />
	<widget name="config" position="20,100" scrollbarMode="showOnDemand" size="590,450" transparent="1" />	
	<eLabel text="Cancel" font="Regular; 20" backgroundColor="#25000000" valign="center" position="35,600" size="250,30" transparent="1" />
	<eLabel text="Save" font="Regular; 20" backgroundColor="#25000000" valign="center" position="335,600" size="250,30" transparent="1" />
	<eLabel text="Default" font="Regular; 20" backgroundColor="#25000000" valign="center" position="635,600" size="250,30" transparent="1" />
	<eLabel text="Info" font="Regular; 20" backgroundColor="#25000000" valign="center" position="935,600" size="250,30" transparent="1" />			
	<eLabel position="20,600" size="6,30" backgroundColor="#00ff0000" />
	<eLabel position="320,600" size="6,30" backgroundColor="#0000ff00" />	
	<eLabel position="620,600" size="6,30" backgroundColor="#00ffff00" />
	<eLabel position="920,600" size="6,30" backgroundColor="#000000ff" />	
	<widget name="helperimage" position="625,100" size="560,315" zPosition="1" />
	<eLabel text="Skin MetrixStyleHD" font="Regular;30" halign="center" valign="center" position="625,450" size="560,40" transparent="1" />		
	<eLabel text="modded for DreamOS" font="Regular;26" halign="center" valign="center" position="625,500" size="560,40" transparent="1" />
</screen>
"""
	def __init__(self, session, args = None, picPath = None):
		self.version = "11.2-r0"
		self.author = "arki"
		self.skin_lines = []
		Screen.__init__(self, session)
		self.session = session
                self["title"] = Label(_("MetrixStyle"))                       
                self["setup"] = Label(_("Setup"))                      
                self["version"] = Label(_("Version")+" "+self.version) 
                self["author"] = Label(_("by")+" "+_("arki")) 
		self.onShown.append(self.setWindowTitle)
		self.datei = "/usr/share/enigma2/MetrixStyleHD/skin.xml"
		self.dateiTMP = "/usr/share/enigma2/MetrixStyleHD/skin.xml.tmp"
		self.daten = "/usr/lib/enigma2/python/Plugins/Extensions/MetrixStyle/data/"		
		self.picPath = picPath
		self.Scale = AVSwitch().getFramebufferScale()
		self.PicLoad = ePicLoad()
		self["helperimage"] = Pixmap()
		self.ConfigDreamboxPluginDetection()
		list = []
		list.append(getConfigListEntry(_("Backgroundcolor"), config.plugins.MetrixStyle.SkinBackgroundColor))
		list.append(getConfigListEntry(_("... with corner radius"), config.plugins.MetrixStyle.SkinCornerRadius))		
		list.append(getConfigListEntry(_("Selection backgroundcolor"), config.plugins.MetrixStyle.SkinSelectedBackgroundColor))
		list.append(getConfigListEntry(_("... with line"), config.plugins.MetrixStyle.SkinSelectedLine))		
		list.append(getConfigListEntry(_("Selection textcolor"), config.plugins.MetrixStyle.SkinSelectedForegroundColor))				
		list.append(getConfigListEntry(_("font color"), config.plugins.MetrixStyle.SkinForegroundColor))
		list.append(getConfigListEntry(_("Helptext color"), config.plugins.MetrixStyle.SkinSelectedHelpTextColor))		
		list.append(getConfigListEntry(_("Date color"), config.plugins.MetrixStyle.SkinDateColor))
		list.append(getConfigListEntry(_("CAID color"), config.plugins.MetrixStyle.SkinCaidInfoColor))		
		list.append(getConfigListEntry(_("Health color"), config.plugins.MetrixStyle.SkinTunerInfoColor))	
		list.append(getConfigListEntry(_("Progressbar color"), config.plugins.MetrixStyle.SkinProgressbarColor))
		list.append(getConfigListEntry(_("Volume"), config.plugins.MetrixStyle.VolumeStyle))
		list.append(getConfigListEntry(_("Text subtitle presentation"), config.plugins.MetrixStyle.SubtitleSitzeStyle))		
		list.append(getConfigListEntry(_("Movielist"), config.plugins.MetrixStyle.MovieSelectionStyle))			
		list.append(getConfigListEntry(_("* * * ")+_("Plugins")+_(" * * *"), ))
		if self.has_gp4:
			list.append(getConfigListEntry(_("Gemini Project (GP4)"), config.plugins.MetrixStyle.GP4))			
		if self.has_ams:
			list.append(getConfigListEntry(_("AMS"), config.plugins.MetrixStyle.AMSStyle))		
		if self.has_emc:
			list.append(getConfigListEntry(_("EMC"), config.plugins.MetrixStyle.EMCStyle))
		if self.has_videodb:
			list.append(getConfigListEntry(_("Video DB"), config.plugins.MetrixStyle.VideoDBStyle))
		if self.has_merlinepgcenter:		
			list.append(getConfigListEntry(_("Merlin EPG Center"), config.plugins.MetrixStyle.MerlinEPGCenterStyle))			
		if self.has_valisepg:
			list.append(getConfigListEntry(_("Vali's EPG"), config.plugins.MetrixStyle.ValisEPGStyle))
		if self.has_pmclock:
			list.append(getConfigListEntry(_("- - - ")+_("PermanentClock")+_(" - - -"), ))		
			list.append(getConfigListEntry(_("... color"), config.plugins.MetrixStyle.PMclockColor))
			list.append(getConfigListEntry(_("... size"), config.plugins.MetrixStyle.PMclockSize))			
		list.append(getConfigListEntry(_("* * * Display * * *"), ))
		if self.boxtype == "dm7080" or self.boxtype == "dm820":
			list.append(getConfigListEntry(_("OLED-Display Infobar"), config.plugins.MetrixStyle.OledDisplayInfobarStyle))
		list.append(getConfigListEntry(_("Display Idle Mode"), config.plugins.MetrixStyle.DisplayIdleStyle))		
		if self.has_color:
			list.append(getConfigListEntry(_("LCD-Display")+" "+_("backgroundcolor"), config.plugins.MetrixStyle.SkinLCDbackgroundColor))				
			list.append(getConfigListEntry(_("LCD-Display foregroundcolor"), config.plugins.MetrixStyle.SkinLCDforegroundColor))
			list.append(getConfigListEntry(_("LCD-Display clock color"), config.plugins.MetrixStyle.SkinLCDclockColor))
			list.append(getConfigListEntry(_("LCD-Display")+" "+_("Channel Selection"), config.plugins.MetrixStyle.DisplayChannelselectionStyle))                		
			list.append(getConfigListEntry(_("LCD-Display Infobar"), config.plugins.MetrixStyle.DisplayInfobarStyle))
		list.append(getConfigListEntry(_("* * * ")+_("Mainmenu")+_(" * * *"), ))			
		list.append(getConfigListEntry(_("Style"), config.plugins.MetrixStyle.MainMenuStyle))	
		list.append(getConfigListEntry(_("backgrouncolor symbol"), config.plugins.MetrixStyle.MainMenuIconBackColor))			
		list.append(getConfigListEntry(_("* * * ")+_("Channel Selection")+_(" * * *"), ))		
		list.append(getConfigListEntry(_("Channellist Style"), config.plugins.MetrixStyle.ChannelselectionStyle))
		list.append(getConfigListEntry(_("Infopanel"), config.plugins.MetrixStyle.ChannelselectionInfo))
		list.append(getConfigListEntry(_("Picon on top"), config.plugins.MetrixStyle.ChannelselectionPicon))		
		list.append(getConfigListEntry(_("Description color"), config.plugins.MetrixStyle.Channeldescription))		
		list.append(getConfigListEntry(_("* * * InfoBar * * *"), ))		
		list.append(getConfigListEntry(_("Style"), config.plugins.MetrixStyle.InfobarStyle))
		list.append(getConfigListEntry(_("picon path"), config.plugins.MetrixStyle.InfobarPiconPath))		
		list.append(getConfigListEntry(_("Servicename and number"), config.plugins.MetrixStyle.InfobarShowChannelname))				
		list.append(getConfigListEntry(_("... color"), config.plugins.MetrixStyle.InfobarChannelnamecolor))
		list.append(getConfigListEntry(_("separator line"), config.plugins.MetrixStyle.InfobarSeparator))		
		list.append(getConfigListEntry(_("top left"), config.plugins.MetrixStyle.InfobarTopLeft))
		list.append(getConfigListEntry(_("top center"), config.plugins.MetrixStyle.InfobarTopCenter))		
		list.append(getConfigListEntry(_("top right"), config.plugins.MetrixStyle.InfobarTopRight))		
		list.append(getConfigListEntry(_("above the infobar"), config.plugins.MetrixStyle.InfobarHead))				
		list.append(getConfigListEntry(_("bottom left"), config.plugins.MetrixStyle.InfobarBottomLeft))
		list.append(getConfigListEntry(_("bottom center"), config.plugins.MetrixStyle.InfobarBottomCenter))		
		list.append(getConfigListEntry(_("bottom right"), config.plugins.MetrixStyle.InfobarBottomRight))
		list.append(getConfigListEntry(_("Show Record Icon"), config.plugins.MetrixStyle.InfobarRecordState))		
		if self.has_secondinfobarme or self.has_sib:
			list.append(getConfigListEntry(_("* * * SecondInfoBar * * *"), ))		
			list.append(getConfigListEntry(_("top left"), config.plugins.MetrixStyle.SecondInfobarTopLeft))
			list.append(getConfigListEntry(_("top center"), config.plugins.MetrixStyle.SecondInfobarTopCenter))		
			list.append(getConfigListEntry(_("top right"), config.plugins.MetrixStyle.SecondInfobarTopRight))						
			list.append(getConfigListEntry(_("Info Panel"), config.plugins.MetrixStyle.SecondInfobarEPGWidget))		
		
		ConfigListScreen.__init__(self, list)
		self["actions"] = NumberActionMap(["OkCancelActions","DirectionActions", "InputActions", "ColorActions", "MenuActions"], {"left": self.keyLeft, "down": self.keyDown, "up": self.keyUp, "right": self.keyRight, "red": self.exit, "0": self.resetAll, "blue": self.showInfo, "green": self.save, "cancel": self.exit, "yellow": self.resetConf}, -2)
		self.onLayoutFinish.append(self.UpdateComponents)
		
	def setWindowTitle(self):                                              
		self.setTitle(_("MetrixStyle")+" "+_("Setup")+" "+("Version")+" "+self.version+" "+_("by")+" "+self.author)		

	def ConfigDreamboxPluginDetection(self):
		# Boxtype
		self.boxtype="dm7080"                  
		if path.exists("/proc/stb/info/model"):
		        f=open("/proc/stb/info/model")   
		        self.boxtype=f.read()             
			f.close()                 
			self.boxtype=self.boxtype.replace("\n","").replace("\l","")
		self.has_tuners=0
		for name in listdir("/sys/class/dvb"):
		        if name.startswith("dvb0.frontend"):
        		        self.has_tuners+=1 
		print "[MetrixStyle] tuners ", self.has_tuners

		if self.boxtype.startswith("dm5"):
			self.has_lcd=False
		else:
			self.haslcd=True
			
		if self.boxtype.startswith("dm9"):
			self.has_color=True
			self.has_cputemp=True
		else:
			self.has_color=False
			self.has_cputemp=False
								
		self.has_moviename=False
		for name in listdir("/usr/lib/enigma2/python/Components/Converter"):
				if name.startswith("RefToMovieName"):
						self.has_moviename=True
						
		self.has_cover=False		
		for name in listdir("/usr/lib/enigma2/python/Components/Renderer"):
				if name.startswith("Cover"):
						self.has_cover=True
						
		self.has_minitv=False
		for name in listdir("/usr/lib/enigma2/python/Components/Renderer"):
				if name.startswith("MiniTV"):
						self.has_minitv=True
						
		self.has_minitvdisplay=False
		for name in listdir("/usr/lib/enigma2/python/Components/Converter"):
				if name.startswith("MiniTVDisplay"):
						self.has_minitvdisplay=True					
						
		self.has_ciplus=False
		for name in listdir("/usr/bin"):
				if name.startswith("dreamciplus-mipsel") or name.startswith("dreamciplus-arm"):
						self.has_ciplus=True							
		# Plugins
		if path.exists("/usr/lib/enigma2/python/Plugins/Extensions/ValisEPG"):
			self.has_valisepg=True
		else:
			self.has_valisepg=False
			
		if path.exists("/usr/lib/enigma2/python/Plugins/Extensions/MerlinEPGCenter"):
			self.has_merlinepgcenter=True
		else:		
			self.has_merlinepgcenter=False
			
		if path.exists("/usr/lib/enigma2/python/Plugins/Extensions/AdvancedMovieSelection"):
			self.has_ams=True
		else:
			self.has_ams=False
			
		if path.exists("/usr/lib/enigma2/python/Plugins/Extensions/EnhancedMovieCenter"):
			self.has_emc=True
		else:
			self.has_emc=False
			
		if path.exists("/usr/lib/enigma2/python/Plugins/Extensions/VideoDB"):
			self.has_videodb=True
		else:
			self.has_videodb=False
			
		if path.exists("/usr/lib/enigma2/python/Plugins/Extensions/PermanentClock"):
			self.has_pmclock=True
		else:
			self.has_pmclock=False			
			
		if path.exists("/usr/lib/enigma2/python/Plugins/Extensions/secondinfobarme"):
			self.has_secondinfobarme=True
		else:
			self.has_secondinfobarme=False
			
		if path.exists("/usr/lib/enigma2/python/Plugins/Extensions/2IB"):
			self.has_sib=True
		else:
			self.has_sib=False		

		if path.exists("/usr/lib/enigma2/python/Plugins/newnigma2"):
			self.has_nn2=True
		else:
			self.has_nn2=False
			
		if path.exists("/usr/lib/enigma2/python/Plugins/GP4"):
			self.has_gp4=True
		else:
			self.has_gp4=False

		if path.exists("/usr/lib/enigma2/python/Plugins/GP4/geminiwidgets"):
			self.has_sensorfield=True
		else:
			self.has_sensorfield=False			
		
		#Config
		config.plugins.MetrixStyle = ConfigSubsection()
		#General
		skinbackgroundcoloropt=[]		
		skinbackgroundcoloropt.append(("#00000000", _("black") ))
		skinbackgroundcoloropt.append(("#07000000", _("Metrix 7") ))		
		skinbackgroundcoloropt.append(("#15000000", _("Metrix 15") ))		
		skinbackgroundcoloropt.append(("#30000000", _("Metrix 30") ))		
		skinbackgroundcoloropt.append(("#40000000", _("Metrix 40") ))		
		skinbackgroundcoloropt.append(("#00111010", _("Anthrazit") ))
		skinbackgroundcoloropt.append(("#07111010", _("Anthrazit 7") ))
		skinbackgroundcoloropt.append(("#15111010", _("Anthrazit 15") ))
		skinbackgroundcoloropt.append(("#30111010", _("Anthrazit 30") ))
		skinbackgroundcoloropt.append(("#40111010", _("Anthrazit 40") ))
		skinbackgroundcoloropt.append(("#00353535", _("dark") ))
		skinbackgroundcoloropt.append(("#07353535", _("dark 7") ))
		skinbackgroundcoloropt.append(("#15353535", _("dark 15") ))
		skinbackgroundcoloropt.append(("#30353535", _("dark 30") ))
		skinbackgroundcoloropt.append(("#40353535", _("dark 40") ))
		skinbackgroundcoloropt.append(("#0500008b", _("darkblue") ))
		skinbackgroundcoloropt.append(("#00232d52", _("cobalt") ))
		skinbackgroundcoloropt.append(("#006A00FF", _("indigo") ))
		skinbackgroundcoloropt.append(("#006c0aab", _("violett") ))
		skinbackgroundcoloropt.append(("#15003c51", _("turquoise") ))
		skinbackgroundcoloropt.append(("#05770000", _("red") ))
		skinbackgroundcoloropt.append(("#05002900", _("pine green") ))				
		config.plugins.MetrixStyle.SkinBackgroundColor = ConfigSelection(default="#30000000", choices = skinbackgroundcoloropt)

		cornerradiusropt=[]				
		cornerradiusropt.append(("0012", _("yes") ))				
		cornerradiusropt.append(("0000", _("no") ))				
		config.plugins.MetrixStyle.SkinCornerRadius = ConfigSelection(default="0012", choices = cornerradiusropt)

		skinselectedbackgroundColoropt=[]		
		skinselectedbackgroundColoropt.append(("#0000cdcd", _("cyan") ))
		skinselectedbackgroundColoropt.append(("#001677d2", _("blueberry") ))		
		skinselectedbackgroundColoropt.append(("#0000008b", _("darkblue") ))		
		skinselectedbackgroundColoropt.append(("#00191970", _("midnightblue") ))		
		skinselectedbackgroundColoropt.append(("#00232d53", _("cobalt") ))
		skinselectedbackgroundColoropt.append(("#00003c51", _("turquoise") ))				
		skinselectedbackgroundColoropt.append(("#00647687", _("steel") ))		
		skinselectedbackgroundColoropt.append(("#00A4C400", _("lime green") ))				
		skinselectedbackgroundColoropt.append(("#0070ad11", _("green") ))
		skinselectedbackgroundColoropt.append(("#00008A00", _("emerald") ))
		skinselectedbackgroundColoropt.append(("#002e8b57", _("teal") ))
		skinselectedbackgroundColoropt.append(("#006D8764", _("oliv") ))		
		skinselectedbackgroundColoropt.append(("#0076608A", _("mauve") ))
		skinselectedbackgroundColoropt.append(("#006A00FF", _("indigo") ))		
		skinselectedbackgroundColoropt.append(("#006c0aab", _("violett") ))		
		skinselectedbackgroundColoropt.append(("#00F472D0", _("pink") ))
		skinselectedbackgroundColoropt.append(("#00a61d4d", _("magenta") ))
		skinselectedbackgroundColoropt.append(("#007A3B3F", _("siena") ))		
		skinselectedbackgroundColoropt.append(("#00E51400", _("blood red") ))
		skinselectedbackgroundColoropt.append(("#00911d10", _("crimson") ))
		skinselectedbackgroundColoropt.append(("#00c3461b", _("orange") ))		
		skinselectedbackgroundColoropt.append(("#00ffcc00", _("yellow") ))
		skinselectedbackgroundColoropt.append(("#00bf9217", _("gold") ))		
		skinselectedbackgroundColoropt.append(("#00F0A30A", _("amber") ))		
		skinselectedbackgroundColoropt.append(("#00cea66b", _("beige") ))
		skinselectedbackgroundColoropt.append(("#00825A2C", _("brown") ))		
		skinselectedbackgroundColoropt.append(("#00000000", _("black") ))
		skinselectedbackgroundColoropt.append(("#07000000", _("Metrix 7") ))
		skinselectedbackgroundColoropt.append(("#15000000", _("Metrix 15") ))
		skinselectedbackgroundColoropt.append(("#30000001", _("Metrix 30") ))
		skinselectedbackgroundColoropt.append(("#40000000", _("Metrix 40") ))
		skinselectedbackgroundColoropt.append(("#00111010", _("Anthrazit") ))
		skinselectedbackgroundColoropt.append(("#07111010", _("Anthrazit 7") ))
		skinselectedbackgroundColoropt.append(("#15111010", _("Anthrazit 15") ))
		skinselectedbackgroundColoropt.append(("#30111010", _("Anthrazit 30") ))
		skinselectedbackgroundColoropt.append(("#40111010", _("Anthrazit 40") ))
		skinselectedbackgroundColoropt.append(("#00353535", _("dark") ))
		skinselectedbackgroundColoropt.append(("#07353535", _("dark 7") ))
		skinselectedbackgroundColoropt.append(("#15353535", _("dark 15") ))
		skinselectedbackgroundColoropt.append(("#30353535", _("dark 30") ))
		skinselectedbackgroundColoropt.append(("#40353535", _("dark 40") ))
		skinselectedbackgroundColoropt.append(("#05770000", _("red") ))		
		skinselectedbackgroundColoropt.append(("#05002900", _("pine green") ))
		skinselectedbackgroundColoropt.append(("#000050ee", _("blue") ))		
		config.plugins.MetrixStyle.SkinSelectedBackgroundColor = ConfigSelection(default="#000050ee", choices = skinselectedbackgroundColoropt)
#		config.plugins.MetrixStyle.SkinSelectedForegroundColor.addNotifier(self.createSVGKlecks, initial_call = True)

		skinselectedlineopt=[]				
		skinselectedlineopt.append(("p_bar", _("white") ))
		skinselectedlineopt.append(("p_bar_grey", _("grey") ))
		skinselectedlineopt.append(("p_bar_cyan", _("cyan") ))
		skinselectedlineopt.append(("p_bar_blueberry", _("blueberry") ))
		skinselectedlineopt.append(("p_bar_blue", _("blue") ))
		skinselectedlineopt.append(("p_bar_cobalt", _("cobalt") ))		
		skinselectedlineopt.append(("p_bar_steel", _("steel") ))		
		skinselectedlineopt.append(("p_bar_lime", _("lime green") ))
		skinselectedlineopt.append(("p_bar_green", _("green") ))
		skinselectedlineopt.append(("p_bar_emerald", _("emerald") ))
		skinselectedlineopt.append(("p_bar_teal", _("teal") ))
		skinselectedlineopt.append(("p_bar_olive", _("oliv") ))		
		skinselectedlineopt.append(("p_bar_mauve", _("mauve") ))
		skinselectedlineopt.append(("p_bar_indigo", _("indigo") ))
		skinselectedlineopt.append(("p_bar_violet", _("violett") ))
		skinselectedlineopt.append(("p_bar_pink", _("pink") ))
		skinselectedlineopt.append(("p_bar_magenta", _("magenta") ))
		skinselectedlineopt.append(("p_bar_sienna", _("siena") ))
		skinselectedlineopt.append(("p_bar_red", _("blood red") ))
		skinselectedlineopt.append(("p_bar_crimson", _("crimson") ))
		skinselectedlineopt.append(("p_bar_orange", _("orange") ))		
		skinselectedlineopt.append(("p_bar_yellow", _("yellow") ))		
		skinselectedlineopt.append(("p_bar_gold", _("gold") ))
		skinselectedlineopt.append(("p_bar_amber", _("amber") ))		
		skinselectedlineopt.append(("p_bar_beige",_("beige") ))
		skinselectedlineopt.append(("p_bar_brown", _("brown") ))		
		skinselectedlineopt.append(("line-no", _("no") ))		
		config.plugins.MetrixStyle.SkinSelectedLine = ConfigSelection(default="line-no", choices = skinselectedlineopt)

		skinselectedforegroundcoloropt=[]		
		skinselectedforegroundcoloropt.append(("#0000cdcd", _("cyan") ))
		skinselectedforegroundcoloropt.append(("#001677d2", _("blueberry") ))		
		skinselectedforegroundcoloropt.append(("#000050ef", _("blue") ))		
		skinselectedforegroundcoloropt.append(("#00232d53", _("cobalt") ))				
		skinselectedforegroundcoloropt.append(("#00647687", _("steel") ))		
		skinselectedforegroundcoloropt.append(("#00A4C400", _("lime green") ))				
		skinselectedforegroundcoloropt.append(("#0070ad11", _("green") ))
		skinselectedforegroundcoloropt.append(("#00008A00", _("emerald") ))
		skinselectedforegroundcoloropt.append(("#002e8b57", _("teal") ))
		skinselectedforegroundcoloropt.append(("#006D8764", _("oliv") ))		
		skinselectedforegroundcoloropt.append(("#0076608A", _("mauve") ))
		skinselectedforegroundcoloropt.append(("#006A00FF", _("indigo") ))		
		skinselectedforegroundcoloropt.append(("#006c0aab", _("violett") ))		
		skinselectedforegroundcoloropt.append(("#00F472D0", _("pink") ))
		skinselectedforegroundcoloropt.append(("#00a61d4d", _("magenta") ))
		skinselectedforegroundcoloropt.append(("#007A3B3F", _("siena") ))		
		skinselectedforegroundcoloropt.append(("#00E51400", _("blood red") ))
		skinselectedforegroundcoloropt.append(("#00911d10", _("crimson") ))
		skinselectedforegroundcoloropt.append(("#00c3461b", _("orange") ))		
		skinselectedforegroundcoloropt.append(("#00ffcc00", _("yellow") ))
		skinselectedforegroundcoloropt.append(("#00bf9217", _("gold") ))		
		skinselectedforegroundcoloropt.append(("#00F0A30A", _("amber") ))		
		skinselectedforegroundcoloropt.append(("#00cea66b", _("beige") ))
		skinselectedforegroundcoloropt.append(("#00825A2C", _("brown") ))		
		skinselectedforegroundcoloropt.append(("#00000000", _("black") ))		
		skinselectedforegroundcoloropt.append(("#00fffffd", _("white") ))		
		config.plugins.MetrixStyle.SkinSelectedForegroundColor = ConfigSelection(default="#00fffffd", choices = skinselectedforegroundcoloropt)

		skinforegroundcoloropt=[]				
		skinforegroundcoloropt.append(("#00F0A30A", _("amber") ))				
		skinforegroundcoloropt.append(("#00825A2C", _("brown") ))		
		skinforegroundcoloropt.append(("#00bf9217", _("gold") ))
		skinforegroundcoloropt.append(("#001BA1E2", _("cyan") ))		
		skinforegroundcoloropt.append(("#00cea66b", _("beige") ))
		skinforegroundcoloropt.append(("#00fffffe", _("white") ))		
		config.plugins.MetrixStyle.SkinForegroundColor = ConfigSelection(default="#00fffffe", choices = skinforegroundcoloropt)
		
		selectedhelptextcolororopt=[]		
		selectedhelptextcolororopt.append(("#0000cdcd", _("cyan") ))
		selectedhelptextcolororopt.append(("#001677d2", _("blueberry") ))		
		selectedhelptextcolororopt.append(("#000050ef", _("blue") ))		
		selectedhelptextcolororopt.append(("#00232d53", _("cobalt") ))
		selectedhelptextcolororopt.append(("#00647687", _("steel") ))		
		selectedhelptextcolororopt.append(("#00A4C400", _("lime green") ))				
		selectedhelptextcolororopt.append(("#0070ad11", _("green") ))
		selectedhelptextcolororopt.append(("#00008A00", _("emerald") ))
		selectedhelptextcolororopt.append(("#002e8b57", _("teal") ))
		selectedhelptextcolororopt.append(("#006D8764", _("oliv") ))		
		selectedhelptextcolororopt.append(("#0076608A", _("mauve") ))
		selectedhelptextcolororopt.append(("#006A00FF", _("indigo") ))		
		selectedhelptextcolororopt.append(("#006c0aab", _("violett") ))		
		selectedhelptextcolororopt.append(("#00F472D0", _("pink") ))
		selectedhelptextcolororopt.append(("#00a61d4d", _("magenta") ))
		selectedhelptextcolororopt.append(("#007A3B3F", _("siena") ))		
		selectedhelptextcolororopt.append(("#00E51400", _("blood red") ))
		selectedhelptextcolororopt.append(("#00911d10", _("crimson") ))
		selectedhelptextcolororopt.append(("#00c3461b", _("orange") ))		
		selectedhelptextcolororopt.append(("#00ffcc00", _("yellow") ))
		selectedhelptextcolororopt.append(("#00bf9217", _("gold") ))		
		selectedhelptextcolororopt.append(("#00F0A30A", _("amber") ))		
		selectedhelptextcolororopt.append(("#00cea66b", _("beige") ))
		selectedhelptextcolororopt.append(("#00825A2C", _("brown") ))		
		selectedhelptextcolororopt.append(("#00fffffc", _("white") ))		
		config.plugins.MetrixStyle.SkinSelectedHelpTextColor = ConfigSelection(default="#00fffffc", choices = selectedhelptextcolororopt)		

		skindatecoloropt=[]		
		skindatecoloropt.append(("#0000cdcd", _("cyan") ))
		skindatecoloropt.append(("#001677d2", _("blueberry") ))		
		skindatecoloropt.append(("#000050ef", _("blue") ))
		skindatecoloropt.append(("#00232d53", _("cobalt") ))
		skindatecoloropt.append(("#00647687", _("steel") ))		
		skindatecoloropt.append(("#00A4C400", _("lime green") ))				
		skindatecoloropt.append(("#0070ad11", _("green") ))
		skindatecoloropt.append(("#00008A00", _("emerald") ))
		skindatecoloropt.append(("#002e8b57", _("teal") ))
		skindatecoloropt.append(("#006D8764", _("oliv") ))		
		skindatecoloropt.append(("#0076608A", _("mauve") ))
		skindatecoloropt.append(("#006A00FF", _("indigo") ))		
		skindatecoloropt.append(("#006c0aab", _("violett") ))		
		skindatecoloropt.append(("#00F472D0", _("pink") ))
		skindatecoloropt.append(("#00a61d4d", _("magenta") ))
		skindatecoloropt.append(("#007A3B3F", _("siena") ))		
		skindatecoloropt.append(("#00E51400", _("blood red") ))
		skindatecoloropt.append(("#00911d10", _("crimson") ))
		skindatecoloropt.append(("#00c3461b", _("orange") ))		
		skindatecoloropt.append(("#00ffcc00", _("yellow") ))
		skindatecoloropt.append(("#00bf9217", _("gold") ))		
		skindatecoloropt.append(("#00F0A30A", _("amber") ))		
		skindatecoloropt.append(("#00cea66b", _("beige") ))
		skindatecoloropt.append(("#00825A2C", _("brown") ))		
		skindatecoloropt.append(("#00dddddd", _("white") ))		
		config.plugins.MetrixStyle.SkinDateColor = ConfigSelection(default="#00dddddd", choices = skindatecoloropt)

		caidcoloropt=[]		
		caidcoloropt.append(("#0000cdcd", _("cyan") ))
		caidcoloropt.append(("#001677d2", _("blueberry") ))		
		caidcoloropt.append(("#000050ef", _("blue") ))
		caidcoloropt.append(("#00232d53", _("cobalt") ))				
		caidcoloropt.append(("#00647687", _("steel") ))		
		caidcoloropt.append(("#00A4C400", _("lime green") ))				
		caidcoloropt.append(("#0070ad11", _("green") ))
		caidcoloropt.append(("#00008A00", _("emerald") ))
		caidcoloropt.append(("#002e8b57", _("teal") ))
		caidcoloropt.append(("#006D8764", _("oliv") ))		
		caidcoloropt.append(("#0076608A", _("mauve") ))
		caidcoloropt.append(("#006A00FF", _("indigo") ))		
		caidcoloropt.append(("#006c0aab", _("violett") ))		
		caidcoloropt.append(("#00a61d4d", _("magenta") ))
		caidcoloropt.append(("#007A3B3F", _("siena") ))		
		caidcoloropt.append(("#00E51400", _("blood red") ))
		caidcoloropt.append(("#00911d10", _("crimson") ))
		caidcoloropt.append(("#00c3461b", _("orange") ))		
		caidcoloropt.append(("#00ffcc00", _("yellow") ))
		caidcoloropt.append(("#00bf9217", _("gold") ))		
		caidcoloropt.append(("#00F0A30A", _("amber") ))		
		caidcoloropt.append(("#00cea66b", _("beige") ))
		caidcoloropt.append(("#00825A2C", _("brown") ))		
		caidcoloropt.append(("#00ffffff", _("white") ))
		caidcoloropt.append(("#00F472D1", _("pink") ))		
		config.plugins.MetrixStyle.SkinCaidInfoColor = ConfigSelection(default="#00F472D1", choices = caidcoloropt)

		tunerinfocoloropt=[]				
		tunerinfocoloropt.append(("#00ffffff", _("white") ))
		tunerinfocoloropt.append(("#0070ad10", _("green") ))				
		config.plugins.MetrixStyle.SkinTunerInfoColor = ConfigSelection(default="#0070ad10", choices = tunerinfocoloropt)				

		progressbaropt=[]				
		progressbaropt.append(("p_bar_cyan", _("cyan") ))				
		progressbaropt.append(("p_bar_blueberry", _("blueberry") ))
		progressbaropt.append(("p_bar_blue", _("blue") ))		
		progressbaropt.append(("p_bar_darkblue", _("darkblue") ))		
		progressbaropt.append(("p_bar_midnightblue", _("midnightblue") ))
		progressbaropt.append(("p_bar_cobalt", _("cobalt") ))		
		progressbaropt.append(("p_bar_turquoise", _("turquoise") ))				
		progressbaropt.append(("p_bar_steel", _("steel") ))		
		progressbaropt.append(("p_bar_lime", _("lime green") ))
		progressbaropt.append(("p_bar_green", _("green") ))
		progressbaropt.append(("p_bar_emerald", _("emerald") ))
		progressbaropt.append(("p_bar_teal", _("teal") ))				
		progressbaropt.append(("p_bar_olive", _("oliv") ))		
		progressbaropt.append(("p_bar_mauve", _("mauve") ))
		progressbaropt.append(("p_bar_indigo", _("indigo") ))		
		progressbaropt.append(("p_bar_violet", _("violett") ))		
		progressbaropt.append(("p_bar_pink", _("pink") ))
		progressbaropt.append(("p_bar_magenta", _("magenta") ))		
		progressbaropt.append(("p_bar_red", _("blood red") ))
		progressbaropt.append(("p_bar_crimson", _("crimson") ))		
		progressbaropt.append(("p_bar_sienna", _("siena") ))
		progressbaropt.append(("p_bar_orange", _("orange") ))		
		progressbaropt.append(("p_bar_yellow", _("yellow") ))		
		progressbaropt.append(("p_bar_gold", _("gold") ))
		progressbaropt.append(("p_bar_amber", _("amber") ))	
		progressbaropt.append(("p_bar_beige",_("beige") ))
		progressbaropt.append(("p_bar_brown", _("brown") ))
		progressbaropt.append(("p_bar", _("white") ))		
		config.plugins.MetrixStyle.SkinProgressbarColor = ConfigSelection(default="p_bar", choices = progressbaropt)

		volumeopt=[]				
		volumeopt.append(("volume-classic", _("top left") ))
		volumeopt.append(("volume-classic-center", _("top center") ))
		volumeopt.append(("volume-classic-right", _("top right") ))
		volumeopt.append(("volume-new", _("big") ))		
		config.plugins.MetrixStyle.VolumeStyle = ConfigSelection(default="volume-classic-center", choices = volumeopt)

		subtitlesizeopt=[]				
		subtitlesizeopt.append(("subtitle-small", _("small") ))
		subtitlesizeopt.append(("subtitle-default", _("default") ))		
		subtitlesizeopt.append(("subtitle-big", _("big") ))		
		subtitlesizeopt.append(("subtitle-very_large", _("very large") ))				
		config.plugins.MetrixStyle.SubtitleSitzeStyle = ConfigSelection(default="subtitle-default", choices = subtitlesizeopt)
				
		movieselectionopt=[]		
		movieselectionopt.append(("movieselection-simple", _("default") ))
		if self.has_minitv and self.has_minitvdisplay and self.has_moviename and self.has_cover:		
			movieselectionopt.append(("movieselection-cover", _("... with Cover") ))
		if self.has_nn2:		
			movieselectionopt.append(("movieselection-cover-nn2", _("... with Cover") ))			
		config.plugins.MetrixStyle.MovieSelectionStyle = ConfigSelection(default="movieselection-simple", choices = movieselectionopt)				
		#Plugins
		plugingp4opt=[]				
		plugingp4opt.append(("no-widget", _("no") )) 
		plugingp4opt.append(("gp4", _("yes") )) 		
		config.plugins.MetrixStyle.GP4 = ConfigSelection(default="no-widget", choices = plugingp4opt)
				
		pluginamsopt=[]				
		pluginamsopt.append(("no-widget", _("no") )) 
		pluginamsopt.append(("ams-metrix", _("yes") )) 		
		config.plugins.MetrixStyle.AMSStyle = ConfigSelection(default="no-widget", choices = pluginamsopt)

		pluginemcopt=[]				
		pluginemcopt.append(("emc-metrix", _("Metrix") ))
		pluginemcopt.append(("emc-metrix-pic", _("Metrix PIG") ))
		pluginemcopt.append(("no-widget", _("no") ))		
		config.plugins.MetrixStyle.EMCStyle = ConfigSelection(default="emc-metrix", choices = pluginemcopt)
				
		pluginvideodbopt=[]
		pluginvideodbopt.append(("no-widget", _("no") ))
		pluginvideodbopt.append(("videodb", _("yes") ))		
		config.plugins.MetrixStyle.VideoDBStyle = ConfigSelection(default="no-widget", choices = pluginvideodbopt)
		
		merlinepgcenteropt=[]
		merlinepgcenteropt.append(("no-widget", _("no") ))		
		if self.has_minitv and self.has_minitvdisplay:		
			merlinepgcenteropt.append(("merlinepgcenter-me", _("Merlin") ))
		else:		
			merlinepgcenteropt.append(("merlinepgcenter", _("default") ))			
		config.plugins.MetrixStyle.MerlinEPGCenterStyle = ConfigSelection(default="no-widget", choices = merlinepgcenteropt)		

		pluginvalisepgopt=[]				
		pluginvalisepgopt.append(("vali-epg", _("Simple") ))
		pluginvalisepgopt.append(("vali-epg-extended", _("Extended") ))
		pluginvalisepgopt.append(("vali-epg-extended-pic", _("Extended")+" "+_("+")+" "+_("PIC") ))
		pluginvalisepgopt.append(("no-widget", _("no") ))		
		config.plugins.MetrixStyle.ValisEPGStyle = ConfigSelection(default="vali-epg", choices = pluginvalisepgopt)
		
		pluginpmclockcoloropt=[]
		pluginpmclockcoloropt.append(("#0000cdcd", _("cyan") ))
		pluginpmclockcoloropt.append(("#001677d2", _("blueberry") ))		
		pluginpmclockcoloropt.append(("#000050ef", _("blue") ))				
		pluginpmclockcoloropt.append(("#00A4C400", _("lime green") ))				
		pluginpmclockcoloropt.append(("#0070ad11", _("green") ))
		pluginpmclockcoloropt.append(("#00008A00", _("emerald") ))
		pluginpmclockcoloropt.append(("#002e8b57", _("teal") ))
		pluginpmclockcoloropt.append(("#006D8764", _("oliv") ))		
		pluginpmclockcoloropt.append(("#0076608A", _("mauve") ))
		pluginpmclockcoloropt.append(("#006A00FF", _("indigo") ))		
		pluginpmclockcoloropt.append(("#006c0aab", _("violett") ))		
		pluginpmclockcoloropt.append(("#00F472D0", _("pink") ))
		pluginpmclockcoloropt.append(("#00a61d4d", _("magenta") ))
		pluginpmclockcoloropt.append(("#007A3B3F", _("siena") ))		
		pluginpmclockcoloropt.append(("#00E51400", _("blood red") ))
		pluginpmclockcoloropt.append(("#00911d10", _("crimson") ))
		pluginpmclockcoloropt.append(("#00c3461b", _("orange") ))		
		pluginpmclockcoloropt.append(("#00ffcc00", _("yellow") ))
		pluginpmclockcoloropt.append(("#00bf9217", _("gold") ))		
		pluginpmclockcoloropt.append(("#00F0A30B", _("amber") ))				
		pluginpmclockcoloropt.append(("#00ffffff", _("white") ))		
		pluginpmclockcoloropt.append(("#00999999", _("grey") ))				
		config.plugins.MetrixStyle.PMclockColor = ConfigSelection(default="#00F0A30B", choices = pluginpmclockcoloropt)

		pluginpmclocksizeopt=[]				
		pluginpmclocksizeopt.append(("pmclock-small", _("small") ))
		pluginpmclocksizeopt.append(("pmclock-default", _("default") ))		
		pluginpmclocksizeopt.append(("pmclock-big", _("big") ))		
		pluginpmclocksizeopt.append(("pmclock-very_large", _("very large") ))				
		config.plugins.MetrixStyle.PMclockSize = ConfigSelection(default="pmclock-default", choices = pluginpmclocksizeopt)		
		#Display
		oledinfobaropt=[]			
		oledinfobaropt.append(("display-oled-default", _("default") ))
		oledinfobaropt.append(("display-oled-picon", _(" .../picon_oled") ))
		oledinfobaropt.append(("display-oled-clock", _("Clock") ))		
		oledinfobaropt.append(("display-oled-remaining", _("Clock")+_("/")+_("Remaining") ))		
		config.plugins.MetrixStyle.OledDisplayInfobarStyle = ConfigSelection(default="display-oled-default", choices = oledinfobaropt)
				
		displayidlemodestyleopt=[]				
		displayidlemodestyleopt.append(("display-idle-clock", _("Clock") ))
		displayidlemodestyleopt.append(("display-idle-clock-date", _("Clock")+_("/")+_("Date") ))		
		config.plugins.MetrixStyle.DisplayIdleStyle = ConfigSelection(default="display-idle-clock-date", choices = displayidlemodestyleopt)				

		lcdbackgroundcoloropt=[]				
		lcdbackgroundcoloropt.append(("#00000001", _("black") ))
		lcdbackgroundcoloropt.append(("#00191970", _("midnightblue") ))		
		lcdbackgroundcoloropt.append(("#007f007f", _("violett") ))		
		lcdbackgroundcoloropt.append(("#00007f00", _("green") ))				
		lcdbackgroundcoloropt.append(("#007f0000", _("crimson") ))				
		config.plugins.MetrixStyle.SkinLCDbackgroundColor = ConfigSelection(default="#00000001", choices = lcdbackgroundcoloropt)

		lcdforegroundcoloropt=[]
		lcdforegroundcoloropt.append(("#00ffffef", _("white") ))
		lcdforegroundcoloropt.append(("#00E51400", _("red") ))
		lcdforegroundcoloropt.append(("#00ffcc00", _("yellow") ))
		lcdforegroundcoloropt.append(("#00F0A30A", _("amber") ))
		lcdforegroundcoloropt.append(("#00cea66b", _("beige") ))
		lcdforegroundcoloropt.append(("#0070ad11", _("green") ))
		lcdforegroundcoloropt.append(("#00008A00", _("emerald") ))		
		lcdforegroundcoloropt.append(("#00F472D0", _("pink") ))		
		lcdforegroundcoloropt.append(("#00a61d4d", _("magenta") ))		
		lcdforegroundcoloropt.append(("#00647687", _("steel") ))		
		lcdforegroundcoloropt.append(("#002e8b57", _("teal") ))		
		lcdforegroundcoloropt.append(("#0000cdcd", _("cyan") ))		
		config.plugins.MetrixStyle.SkinLCDforegroundColor = ConfigSelection(default="#00ffffef", choices = lcdforegroundcoloropt)

		lcdclockcoloropt=[]				
		lcdclockcoloropt.append(("#00ffffdf", _("white") ))
		lcdclockcoloropt.append(("#00E51400", _("red") ))
		lcdclockcoloropt.append(("#00ffcc00", _("yellow") ))
		lcdclockcoloropt.append(("#00F0A30A", _("amber") ))
		lcdclockcoloropt.append(("#00cea66b", _("beige") ))
		lcdclockcoloropt.append(("#0070ad11", _("green") ))
		lcdclockcoloropt.append(("#00008A00", _("emerald") ))		
		lcdclockcoloropt.append(("#00F472D0", _("pink") ))		
		lcdclockcoloropt.append(("#00a61d4d", _("magenta") ))		
		lcdclockcoloropt.append(("#00647687", _("steel") ))		
		lcdclockcoloropt.append(("#002e8b57", _("teal") ))		
		lcdclockcoloropt.append(("#0000cdcd", _("cyan") ))				
		config.plugins.MetrixStyle.SkinLCDclockColor = ConfigSelection(default="#00ffffdf", choices = lcdclockcoloropt)
						
		lcdchannelselectionopt=[]				
		lcdchannelselectionopt.append(("display-channelselection-default", _("default") ))
		lcdchannelselectionopt.append(("display-channelselection-service-event", _("Service")+" "+_("+")+" "+_("Event") ))
		lcdchannelselectionopt.append(("display-channelselection-picon", _(".../picon") ))
		lcdchannelselectionopt.append(("display-channelselection-picon_2", _(".../picon + Event") ))
		lcdchannelselectionopt.append(("display-channelselection-picon_4", _(".../picon + Progressbar") ))
		lcdchannelselectionopt.append(("display-channelselection-picon_3", _(".../picon_400x170") ))
		lcdchannelselectionopt.append(("display-channelselection-clock", _("Clock") ))
		lcdchannelselectionopt.append(("display-channelselection-clock-date", _("Clock")+_(" / ")+_("Date") ))
		lcdchannelselectionopt.append(("display-channelselection-remaining", _("Clock")+_(" / ")+_("Remaining") ))		
		config.plugins.MetrixStyle.DisplayChannelselectionStyle = ConfigSelection(default="display-channelselection-default", choices = lcdchannelselectionopt)				

		lcdinfobaropt=[]				
		lcdinfobaropt.append(("display-default", _("default") ))
		lcdinfobaropt.append(("display-service-event", _("Service")+" "+_("+")+" "+_("Event") ))
		lcdinfobaropt.append(("display-picon", _(".../picon") ))
		lcdinfobaropt.append(("display-picon_2", _(".../picon + Event") ))
		lcdinfobaropt.append(("display-picon_4", _(".../picon + Progressbar") ))
		lcdinfobaropt.append(("display-picon_3", _(".../picon_400x170") ))
		lcdinfobaropt.append(("display-clock", _("Clock") ))
		lcdinfobaropt.append(("display-clock-date", _("Clock")+_(" / ")+_("Date") ))
		lcdinfobaropt.append(("display-remaining", _("Clock")+_(" / ")+_("Remaining") ))		
		config.plugins.MetrixStyle.DisplayInfobarStyle = ConfigSelection(default="display-default", choices = lcdinfobaropt)
		#Mainmenu		
		mainmenustyleopt=[]				
		mainmenustyleopt.append(("menu-center", _("Metrix centered") ))
		mainmenustyleopt.append(("menu-left", _("Metrix left justified") ))		
		mainmenustyleopt.append(("menu-center-untitled", _("MetrixStyle centered") ))		
		mainmenustyleopt.append(("menu-left-untitled", _("MetrixStyle left justified") ))		
		mainmenustyleopt.append(("menu-big", _("big centered") ))		
		mainmenustyleopt.append(("menu-big-left", _("big left justified") ))				
		config.plugins.MetrixStyle.MainMenuStyle = ConfigSelection(default="menu-center", choices = mainmenustyleopt)
								
		mainmenuiconbackcoloropt=[]				
		mainmenuiconbackcoloropt.append(("menu-icon-backcolor", _("Selection backgroundcolor") ))
		mainmenuiconbackcoloropt.append(("menu-icon", _("Backgroundcolor") ))				
		config.plugins.MetrixStyle.MainMenuIconBackColor = ConfigSelection(default="menu-icon-backcolor", choices = mainmenuiconbackcoloropt)		
		#Channelselection
		channelselectionstyleopt=[]
		channelselectionstyleopt.append(("channelselection-senior", _("10")+_(" ")+_("lines") ))
		channelselectionstyleopt.append(("channelselection-me12", _("12")+_(" ")+_("lines") ))
		channelselectionstyleopt.append(("channelselection-classic", _("15")+_(" ")+_("lines") ))
		channelselectionstyleopt.append(("channelselection-me16", _("16")+_(" ")+_("lines") ))
		channelselectionstyleopt.append(("channelselection-20z", _("20")+_(" ")+_("lines") ))
		channelselectionstyleopt.append(("channelselection-simple", _("12")+_(" ")+_("lines")+_(" / ")+_("complete width") ))		
		config.plugins.MetrixStyle.ChannelselectionStyle = ConfigSelection(default="channelselection-classic", choices = channelselectionstyleopt)

		channelselectioninfoopt=[]
		channelselectioninfoopt.append(("channelselection-style1a", _("Style 1a") ))
		channelselectioninfoopt.append(("channelselection-style1b", _("Style 1b") ))
		channelselectioninfoopt.append(("channelselection-style1c", _("Style 1c") ))
		channelselectioninfoopt.append(("channelselection-style2a", _("Style 2c") ))
		channelselectioninfoopt.append(("channelselection-me3ev", _("Style 2c") ))		
		channelselectioninfoopt.append(("channelselection-me1ev", _("Style 3a") ))
		channelselectioninfoopt.append(("channelselection-style6", _("Style 3b") ))
		channelselectioninfoopt.append(("channelselection-style8", _("Style 3c") ))		
		channelselectioninfoopt.append(("channelselection-pic-left", _("Style 4a / PIC") ))		
		channelselectioninfoopt.append(("channelselection-pic-right", _("Style 4b / PIC") ))
		if self.has_minitv and self.has_minitvdisplay:		
			channelselectioninfoopt.append(("channelselection-style4c", _("Style 4c / PIC+MiniTV") ))
		if self.has_minitv and self.has_minitvdisplay:		
			channelselectioninfoopt.append(("channelselection-style4d", _("Style 4d / PIC+MiniTV") ))
		if self.has_minitv and self.has_minitvdisplay:		
			channelselectioninfoopt.append(("channelselection-style4e", _("Style 4e / MiniTV") ))
		if self.has_minitv and self.has_minitvdisplay:	
			channelselectioninfoopt.append(("channelselection-style4f", _("Style 4f / MiniTV") ))			
		channelselectioninfoopt.append(("channelselection-style5", _("Style 5a") ))
		channelselectioninfoopt.append(("channelselection-style5b", _("Style 5b") ))		
		channelselectioninfoopt.append(("channelselection-style5c", _("Style 5c") ))		
		channelselectioninfoopt.append(("channelselection-style9", _("Style 6a") ))		
		channelselectioninfoopt.append(("channelselection-style10", _("Style 6b") ))		
		channelselectioninfoopt.append(("channelselection-style7", _("Style 7a") ))
		channelselectioninfoopt.append(("channelselection-style7b", _("Style 7b") ))
		channelselectioninfoopt.append(("channelselection-style7c", _("Style 7c") ))
		channelselectioninfoopt.append(("channelselection-style11", _("Style 11a") ))
		channelselectioninfoopt.append(("channelselection-style11b", _("Style 11b") ))
		channelselectioninfoopt.append(("channelselection-style11c", _("Style 11c") ))
		channelselectioninfoopt.append(("channelselection-style11d", _("Style 11d") ))		
		channelselectioninfoopt.append(("no-widget", _("blank") ))				
		config.plugins.MetrixStyle.ChannelselectionInfo = ConfigSelection(default="channelselection-style1a", choices = channelselectioninfoopt)
				
		channelselectionPiconopt=[]				
		channelselectionPiconopt.append(("channelselection-picon", _("yes") ))				
		channelselectionPiconopt.append(("channelselection-picon-no", _("no") ))				
		config.plugins.MetrixStyle.ChannelselectionPicon = ConfigSelection(default="channelselection-picon-no", choices = channelselectionPiconopt)

		channeldescriptionopt=[]		
		channeldescriptionopt.append(("#0000cdcd", _("cyan") ))
		channeldescriptionopt.append(("#001677d2", _("blueberry") ))		
		channeldescriptionopt.append(("#000050ef", _("blue") ))		
		channeldescriptionopt.append(("#00232d53", _("cobalt") ))				
		channeldescriptionopt.append(("#00647687", _("steel") ))		
		channeldescriptionopt.append(("#00A4C400", _("lime green") ))				
		channeldescriptionopt.append(("#0070ad11", _("green") ))
		channeldescriptionopt.append(("#00008A00", _("emerald") ))
		channeldescriptionopt.append(("#002e8b57", _("teal") ))
		channeldescriptionopt.append(("#006D8764", _("oliv") ))		
		channeldescriptionopt.append(("#0076608A", _("mauve") ))
		channeldescriptionopt.append(("#006A00FF", _("indigo") ))		
		channeldescriptionopt.append(("#006c0aab", _("violett") ))		
		channeldescriptionopt.append(("#00F472D0", _("pink") ))
		channeldescriptionopt.append(("#00a61d4d", _("magenta") ))
		channeldescriptionopt.append(("#007A3B3F", _("siena") ))		
		channeldescriptionopt.append(("#00E51400", _("blood red") ))
		channeldescriptionopt.append(("#00911d10", _("crimson") ))
		channeldescriptionopt.append(("#00c3461b", _("orange") ))		
		channeldescriptionopt.append(("#00ffcc00", _("yellow") ))
		channeldescriptionopt.append(("#00bf9217", _("gold") ))		
		channeldescriptionopt.append(("#00F0A30A", _("amber") ))		
		channeldescriptionopt.append(("#00cea66b", _("beige") ))
		channeldescriptionopt.append(("#00825A2C", _("brown") ))		
		channeldescriptionopt.append(("#00ffffff", _("white") ))		
		channeldescriptionopt.append(("#00999998", _("grey") ))		
		config.plugins.MetrixStyle.Channeldescription = ConfigSelection(default="#00999998", choices = channeldescriptionopt)					
		#InfoBar
		infobarstyleopt=[]		
		infobarstyleopt.append(("infobar-style-classic", _("Metrix") ))
		infobarstyleopt.append(("infobar-style-metrix1", _("MetrixStyle I") ))
		infobarstyleopt.append(("infobar-style-metrix2", _("MetrixStyle I (Ticker) ") ))
		infobarstyleopt.append(("infobar-style-metrix3", _("MetrixStyle II") ))
		infobarstyleopt.append(("infobar-style-metrix4", _("MetrixStyle II (Ticker)") ))		
		infobarstyleopt.append(("infobar-style-hc", _("HC") ))		
		infobarstyleopt.append(("infobar-style-hct", _("HC (Ticker)") ))				
		config.plugins.MetrixStyle.InfobarStyle = ConfigSelection(default="infobar-style-classic", choices = infobarstyleopt)

		infobarpiconpathopt=[]				
		infobarpiconpathopt.append(("infobar-picon", _(" .../picon") ))
		infobarpiconpathopt.append(("infobar-picon-220x132", _(".../picon_220x132") ))		
		infobarpiconpathopt.append(("infobar-picon-500x300", _(".../picon_500x300") ))
		infobarpiconpathopt.append(("infobar-picon-channelnumber", _("Show service numbers") ))
		infobarpiconpathopt.append(("no-widget", _("blank") ))				
		config.plugins.MetrixStyle.InfobarPiconPath = ConfigSelection(default="infobar-picon", choices = infobarpiconpathopt)			
				
		infobarshowchannelnameopt=[]				
		infobarshowchannelnameopt.append(("no-widget", _("no") ))
		infobarshowchannelnameopt.append(("infobar-channelname-number", _("center") ))		
		infobarshowchannelnameopt.append(("infobar-channelname", _("Channelename only, center") ))
		infobarshowchannelnameopt.append(("infobar-channelname-number-left", _("left justified") ))
		infobarshowchannelnameopt.append(("infobar-channelname-number-left-white", _("Channelename only, left justified") ))		
		config.plugins.MetrixStyle.InfobarShowChannelname = ConfigSelection(default="infobar-channelname-number", choices = infobarshowchannelnameopt)

		infobarchannelnamecoloropt=[]		
		infobarchannelnamecoloropt.append(("#0000cdcd", _("cyan") ))
		infobarchannelnamecoloropt.append(("#001677d2", _("blueberry") ))		
		infobarchannelnamecoloropt.append(("#000050ef", _("blue") ))
		infobarchannelnamecoloropt.append(("#0000008b", _("darkblue") ))		
		infobarchannelnamecoloropt.append(("#00191970", _("midnightblue") ))		
		infobarchannelnamecoloropt.append(("#00232d53", _("cobalt") ))
		infobarchannelnamecoloropt.append(("#00003c51", _("turquoise") ))				
		infobarchannelnamecoloropt.append(("#00647687", _("steel") ))		
		infobarchannelnamecoloropt.append(("#00A4C400", _("lime green") ))				
		infobarchannelnamecoloropt.append(("#0070ad11", _("green") ))
		infobarchannelnamecoloropt.append(("#00008A00", _("emerald") ))
		infobarchannelnamecoloropt.append(("#002e8b57", _("teal") ))
		infobarchannelnamecoloropt.append(("#006D8764", _("oliv") ))		
		infobarchannelnamecoloropt.append(("#0076608A", _("mauve") ))
		infobarchannelnamecoloropt.append(("#006A00FF", _("indigo") ))		
		infobarchannelnamecoloropt.append(("#006c0aab", _("violett") ))		
		infobarchannelnamecoloropt.append(("#00F472D0", _("pink") ))
		infobarchannelnamecoloropt.append(("#00a61d4d", _("magenta") ))
		infobarchannelnamecoloropt.append(("#007A3B3F", _("siena") ))		
		infobarchannelnamecoloropt.append(("#00E51400", _("blood red") ))
		infobarchannelnamecoloropt.append(("#00911d10", _("crimson") ))
		infobarchannelnamecoloropt.append(("#00c3461b", _("orange") ))		
		infobarchannelnamecoloropt.append(("#00ffcc00", _("yellow") ))
		infobarchannelnamecoloropt.append(("#00bf9217", _("gold") ))		
		infobarchannelnamecoloropt.append(("#00F0A30A", _("amber") ))		
		infobarchannelnamecoloropt.append(("#00cea66b", _("beige") ))
		infobarchannelnamecoloropt.append(("#00825A2C", _("brown") ))		
		infobarchannelnamecoloropt.append(("#00ffffff", _("white") ))
		infobarchannelnamecoloropt.append(("#00999996", _("grey") ))		
		config.plugins.MetrixStyle.InfobarChannelnamecolor = ConfigSelection(default="#00999996", choices = infobarchannelnamecoloropt)

		infobarseparatoropt=[]
		infobarseparatoropt.append(("infobar-separatorline", _("yes") ))		
		infobarseparatoropt.append(("infobar-separatorline-no", _("no") ))		
		config.plugins.MetrixStyle.InfobarSeparator = ConfigSelection(default="infobar-separatorline", choices = infobarseparatoropt)			

		infobartopleftopt=[]
		infobartopleftopt.append(("no-widget", _("nothing") ))
		infobartopleftopt.append(("infobar-top-left-clockdate", _("Clock")+_("/")+_("Date") ))
		infobartopleftopt.append(("infobar-top-left-clockdateextended", _("Clock")+_("/")+_("Date")+" "+_("Extended") ))				
		infobartopleftopt.append(("infobar-top-left-msnweather", _("Weather") ))				
		config.plugins.MetrixStyle.InfobarTopLeft = ConfigSelection(default="no-widget", choices = infobartopleftopt)

		infobartopcenteropt=[]
		infobartopcenteropt.append(("no-widget", _("nothing") ))		
		if self.has_minitv and self.has_minitvdisplay:		
			infobartopcenteropt.append(("infobar-top-center-cryptinfo-merlin", _("Cryptinfo Merlin") ))
		if self.has_nn2:		
			infobartopcenteropt.append(("infobar-top-center-cryptinfo-nn2", _("Cryptinfo NN2") ))			
		else:	
			infobartopcenteropt.append(("infobar-top-center-cryptinfo", _("Cryptinfo") ))			
		infobartopcenteropt.append(("infobar-top-center-serviceinfo",  _("Serviceinfo") ))
		infobartopcenteropt.append(("infobar-top-center-satinfo",  _("Serviceinfo") ))
		infobartopcenteropt.append(("infobar-top-center-tunerinfo", _("Tunerinfo (16 Tuner) ") ))				
		infobartopcenteropt.append(("infobar-top-center-syteminfo", _("Systeminfo") ))
		infobartopcenteropt.append(("infobar-top-center-weather-clockdate", _("Weather")+_(" / ")+_("Clock")+_("/")+_("Date")+_(" ")+_("(Letterbox)") ))
		if self.has_sensorfield:		
			infobartopcenteropt.append(("infobar-top-center-gp-sensor1-2", _("gp4-Sensor 1 u, 2") ))		
		config.plugins.MetrixStyle.InfobarTopCenter = ConfigSelection(default="no-widget", choices = infobartopcenteropt)

		infobartoprightopt=[]
		infobartoprightopt.append(("no-widget", _("nothing") ))
		infobartoprightopt.append(("infobar-top-right-clockdate", _("Clock")+_("/")+_("Date") ))
		infobartoprightopt.append(("infobar-top-right-clockdateextended", _("Clock")+_("/")+_("Date")+" "+_("Extended") ))				
		infobartoprightopt.append(( "infobar-top-right-msnweather", _("Weather") ))				
		config.plugins.MetrixStyle.InfobarTopRight = ConfigSelection(default="infobar-top-right-clockdate", choices = infobartoprightopt)
		
		infobarheadopt=[]		
		infobarheadopt.append(("no-widget", _("nothing") ))	
		if self.has_minitv and self.has_minitvdisplay:		
			infobarheadopt.append(("infobar-head-cryptinfo-merlin", _("Cryptinfo Merlin") ))
		if self.has_nn2:		
			infobarheadopt.append(("infobar-head-cryptinfo-nn2", _("Cryptinfo NN2") ))
		else:	
			infobarheadopt.append(("infobar-head-cryptinfo", _("Cryptinfo") ))			
		infobarheadopt.append(("infobar-head-serviceinfo", _("Serviceinfo") ))
		infobarheadopt.append(("infobar-head-serviceinfo-pid", _("PIDs/Sat/Transponder") ))
		infobarheadopt.append(("infobar-head-colorbuttonts", _("Show Colorbuttonts") ))
		infobarheadopt.append(("infobar-head-tunerinfofbc", _("Tunerinfo (16 Tuner)") ))
		if self.has_sensorfield:		
			infobarheadopt.append(("infobar-head-gp-sensor1-5", _("gp4-Sensor 1 - 5") ))		
		config.plugins.MetrixStyle.InfobarHead = ConfigSelection(default="no-widget", choices = infobarheadopt)

		infobarbottomleftopt=[]
		infobarbottomleftopt.append(("no-widget", _("nothing") ))
		infobarbottomleftopt.append(("infobar-bottom-left-caidsoftcam", _("CAID / CI+ / Signal") ))				
		infobarbottomleftopt.append(("infobar-bottom-left-resolution-provider", _("Resolution")+_(" / ")+_("Provider") ))				
		infobarbottomleftopt.append(("infobar-bottom-left-resolutionhealthpg", _("Resolution")+_(" / ")+_("Signal (Progress)") ))				
		infobarbottomleftopt.append(("infobar-bottom-left-resolutionhealth", _("Resolution")+_(" / ")+_("Signal") ))
		if self.has_ciplus:		
			infobarbottomleftopt.append(("infobar-bottom-left-resolution-ciplus-health", _("Resolution")+_(" / ")+_("CI+")+_(" / ")+_("Signal") ))				
		infobarbottomleftopt.append(("infobar-bottom-left-resolution-temp-health", _("Resolution")+_(" / ")+_("Fan")+_(" / ")+_("Signal") ))
		if self.has_cputemp:		
			infobarbottomleftopt.append(("infobar-bottom-left-resolution-cputemp-health", _("Resolution")+_(" / ")+_("CPU Temp.")+_(" / ")+_("Signal") ))				
		infobarbottomleftopt.append(("infobar-bottom-left-tuner-signal", _("Tunerinfo / Signal") ))
		if self.has_tuners > 5:
			infobarbottomleftopt.append(( "infobar-bottom-left-tunerfbc-signal", _("Tunerinfo (Slot-A FBC) / Signal") ))
		if self.has_sensorfield:		
			infobarbottomleftopt.append(("infobar-bottom-left-gp-sensor1-2", _("gp4-Sensor 1 u. 2") ))			
		config.plugins.MetrixStyle.InfobarBottomLeft = ConfigSelection(default="infobar-bottom-left-resolutionhealth", choices = infobarbottomleftopt)

		infobarbottomcenteropt=[]
		infobarbottomcenteropt.append(("infobar-tunerinfo-ab", _("2 Tuner") ))
		if self.has_tuners > 2:
			infobarbottomcenteropt.append(("infobar-tunerinfo-abc", _("3 Tuner") ))								
		if self.has_tuners > 3:
			infobarbottomcenteropt.append(("infobar-tunerinfo-abcd", _("4 Tuner") ))
		if self.has_tuners > 4:
			infobarbottomcenteropt.append(("infobar-tunerinfo-abd", _("5 Tuner") ))	
		if self.has_tuners > 5:
			infobarbottomcenteropt.append(("infobar-tunerinfo-8", _("8 Tuner") ))				
		infobarbottomcenteropt.append(("infobar-bottom-center-snr", _("Signal %") ))
		infobarbottomcenteropt.append(("infobar-bottom-center-snrdb", _("Signal dB") ))		
		infobarbottomcenteropt.append(("infobar-bottom-center-resolution", _("Resolution") ))
		if self.has_sensorfield:		
			infobarbottomcenteropt.append(("infobar-bottom-center-gp-sensor3", _("gp4-Sensor 3") ))		
		if self.has_cputemp:
			infobarbottomcenteropt.append(("infobar-bottom-center-cputemp", _("CPU Temperatur") ))			
		infobarbottomcenteropt.append(("no-widget", _("off") ))
		if self.has_tuners < 3:
			infobarbottomcenterdef="infobar-tunerinfo-ab"
		elif self.has_tuners == 3:
			infobarbottomcenterdef="infobar-tunerinfo-abc"
		elif self.has_tuners == 4:
			infobarbottomcenterdef="infobar-tunerinfo-abcd"
		elif self.has_tuners == 5:
			infobarbottomcenterdef="infobar-tunerinfo-abd"
		else:
			infobarbottomcenterdef="infobar-tunerinfo-8"
		config.plugins.MetrixStyle.InfobarBottomCenter = ConfigSelection(default=infobarbottomcenterdef, choices = infobarbottomcenteropt)
		
		infobarbottomrightopt=[]
		infobarbottomrightopt.append(("infobar-bottom-right-icons", _("Icons Metrix") ))
		infobarbottomrightopt.append(("infobar-bottom-right-icons_new", _("Icons MetrixStyle") ))		
		infobarbottomrightopt.append(("no-widget", _("nothing") ))		
		config.plugins.MetrixStyle.InfobarBottomRight = ConfigSelection(default="infobar-bottom-right-icons", choices = infobarbottomrightopt)
		
		infobarrecordstateopt=[]		
		infobarrecordstateopt.append(("no-widget", _("no") ))
		infobarrecordstateopt.append(("infobar-recordstate-red", _("yes") ))		
		config.plugins.MetrixStyle.InfobarRecordState = ConfigSelection(default="no-widget", choices = infobarrecordstateopt)				
		#SecondInfoBar
		secondinfobartopleftopt=[]		
		secondinfobartopleftopt.append(("no-widget", _("nothing") ))
		secondinfobartopleftopt.append(("infobar-top-left-clockdate", _("Clock")+_("/")+_("Date") ))
		secondinfobartopleftopt.append(("infobar-top-left-clockdateextended", _("Clock")+_("/")+_("Date")+" "+_("Extended") ))				
		secondinfobartopleftopt.append(("infobar-top-left-msnweather", _("Weather") ))				
		config.plugins.MetrixStyle.SecondInfobarTopLeft = ConfigSelection(default="no-widget", choices = secondinfobartopleftopt)

		secondinfobartopcenteropt=[]
		secondinfobartopcenteropt.append(("no-widget", _("nothing") ))
		if self.has_minitv and self.has_minitvdisplay:
			secondinfobartopcenteropt.append(("infobar-top-center-cryptinfo-merlin", _("Cryptinfo") ))
		if self.has_nn2:
			secondinfobartopcenteropt.append(("infobar-top-center-cryptinfo-nn2", _("Cryptinfo") ))
		else:		
			secondinfobartopcenteropt.append(("infobar-top-center-cryptinfo", _("Cryptinfo") ))
		secondinfobartopcenteropt.append(("infobar-top-center-serviceinfo",  _("Serviceinfo") ))
		secondinfobartopcenteropt.append(("infobar-top-center-satinfo",  _("Serviceinfo") ))
		if self.has_tuners > 5:
			secondinfobartopcenteropt.append(("infobar-top-center-tunerinfo", _("Tunerinfo(FBC)") ))				
		else:
			secondinfobartopcenteropt.append(("infobar-top-center-tunerinfo", _("Tunerinfo") ))				
		secondinfobartopcenteropt.append(("infobar-top-center-syteminfo", _("Systeminfo") ))
		secondinfobartopcenteropt.append(("infobar-top-center-weather-clockdate", _("Weather")+_(" / ")+_("Clock")+_("/")+_("Date")+_(" ")+_("(Letterbox)") ))		
		config.plugins.MetrixStyle.SecondInfobarTopCenter = ConfigSelection(default="no-widget", choices = secondinfobartopcenteropt)				

		secondinfobartoprightopt=[]		
		secondinfobartoprightopt.append(("no-widget", _("nothing") ))
		secondinfobartoprightopt.append(("infobar-top-right-clockdate", _("Clock")+_("/")+_("Date") ))
		secondinfobartoprightopt.append(("infobar-top-right-clockdateextended", _("Clock")+_("/")+_("Date")+" "+_("Extended") ))				
		secondinfobartoprightopt.append(("infobar-top-right-msnweather", _("Weather") ))				
		config.plugins.MetrixStyle.SecondInfobarTopRight = ConfigSelection(default="infobar-top-right-clockdate", choices = secondinfobartoprightopt)						

		secondinfobarepgwidgetopt=[]		
		secondinfobarepgwidgetopt.append(("secondinfobar-epgwidget", _("Now/Next description") ))
		secondinfobarepgwidgetopt.append(("secondinfobar-epgwidget-running", _("Now/Next description/running") ))
		if self.has_minitv and self.has_minitvdisplay:		
			secondinfobarepgwidgetopt.append(("secondinfobar-extendedinfo-merlin", _("Service extendedinfo") ))
		if self.has_nn2:
			secondinfobarepgwidgetopt.append(("secondinfobar-extendedinfo-nn2", _("Service extendedinfo") ))		
		else:		
			secondinfobarepgwidgetopt.append(("secondinfobar-extendedinfo", _("Service extendedinfo") ))		
		secondinfobarepgwidgetopt.append(("no-widget", _("off") ))				
		config.plugins.MetrixStyle.SecondInfobarEPGWidget = ConfigSelection(default="secondinfobar-epgwidget", choices = secondinfobarepgwidgetopt)
							
	def GetPicturePath(self):
# for debugging remove try:
#		try:
		if True:
			returnValue = self["config"].getCurrent()[1].value
			path=self.createSVGKlecks(returnValue)
			if path is not None:
				return path
			path = "/usr/lib/enigma2/python/Plugins/Extensions/MetrixStyle/images/" + returnValue + ".png"
			return path
#		except:
		else:
			return "/usr/lib/enigma2/python/Plugins/Extensions/MetrixStyle/images/no-widget.png"
			
	def createSVGKlecks(self, rgba):
		print ">>>>>>>>>>>>>>>>>", rgba
		length=len(rgba)
		svgpicon="/tmp/picon.svg"
		if rgba.startswith("#") and length == 9:
			alpha=int(rgba[1:3],16)
			opaq=1.0-float(alpha)/256.0
			red=int(rgba[3:5],16)
			green=int(rgba[5:7],16)
			blue=int(rgba[7:9],16)
			print "[MetrixStyle] createSVGAKlecks: l: %d r: %d g: %d b: %d a:%d o:%.2f" % (length,red,green,blue,alpha,opaq)
			picon=open(svgpicon,"w")
			picon.write("<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 200 200\"><style type=\"text/css\"> .st0{fill:rgb(%d,%d,%d);}</style><path class=\"st0\" d=\"M140 103c10.1-0.4 56.7-6.5 52 16 -3.8 18.3-47.4-1.5-57-5 -5.5-2-21.1-9-25-2 -4 7.3 7.3 14.4 12 18 13.2 9.9 47.3 22.6 34 46 -11.7 20.6-33.1-21.3-40-29 -2-2.3-10.1-12.7-13-11 -4.6 2.7 0.9 27.6-8 22 -4.5-2.8-3-18.4-9-19 -5.8-0.6-13.8 21.8-16 26 -4 7.9-8.3 21.2-15 27 -8.2 7.1-15.7 0.8-17-9 -3.1-22.3 22.9-31.2 31-48 11.6-24.2-35.4 4.9-37-3 -2.6-13 40.4-15.5 13-29C35.1 98.1 1.1 92.3 8 75c8.9-22.4 31.6 7.2 42 12 24.6 11.5-0.9-34.2 18-36 9-0.9 13.1 36.7 20 27 3.6-5.1 0.2-20.6 0-27 -0.4-12.4-5.6-29-2-41 4.2-14 14.5-6.9 18 4 2.9 8.9 0.9 18.1-1 27 -1.8 8.5-20 54.5 2.6 42.8 8.9-4.6 11.2-19.2 22.4-19.8 8.7-0.5 11.5 6.6 7 13 -4.3 6.1-24 10.8-24 20C111 105.9 133.7 102.7 140 103z\" opacity=\"%.2f\"/>\n/>/n</svg>" % (red,green,blue,opaq))
			picon.close()
			return svgpicon
		return None			
		
	def UpdatePicture(self):
		self.PicLoad_conn = self.PicLoad.PictureData.connect(self.DecodePicture)
		self.onLayoutFinish.append(self.ShowPicture)
	
	def ShowPicture(self):
		self.PicLoad.setPara([self["helperimage"].instance.size().width(),self["helperimage"].instance.size().height(),self.Scale[0],self.Scale[1],0,1,"#002C2C39"])
		self.PicLoad.startDecode(self.GetPicturePath())
		
	def DecodePicture(self, PicInfo = ""):
		ptr = self.PicLoad.getData()
		self["helperimage"].instance.setPixmap(ptr)	

	def UpdateComponents(self):
		self.UpdatePicture()

	def resetConf(self):	
		print self["config"].getCurrent()[1].value
		print self["config"].getCurrent()[1].default
		self["config"].getCurrent()[1].value=self["config"].getCurrent()[1].default
		self["config"].invalidateCurrent()
		self.ShowPicture()

	def resetAll(self,key):	
		metrix_settings="MetrixStyle"+" "+_("Settings")
		self.session.openWithCallback(self.resetAllConf, MessageBox, _("Do you really want to delete %s?") % metrix_settings)
	
	def resetAllConf(self, result):
		if not result:
			return
		for x in self["config"].list:
			if len(x) > 1:
        			x[1].value=x[1].default
			else:
       				pass

		lst = self["config"]                                          
                lst.list = self["config"].list                                           
                lst.l.setList(self["config"].list)      

	def keyLeft(self):	
		ConfigListScreen.keyLeft(self)	
		self.ShowPicture()

	def keyRight(self):
		ConfigListScreen.keyRight(self)
		self.ShowPicture()
	
	def keyDown(self):
		self["config"].instance.moveSelection(self["config"].instance.moveDown)
		self.ShowPicture()
		
	def keyUp(self):
		self["config"].instance.moveSelection(self["config"].instance.moveUp)
		self.ShowPicture()
		
	def showInfo(self):
		self.session.open(MessageBox, _("Skin MetrixStyle")+" "+("Version")+" "+self.version+"\n\n"+_("modded for DreamOS by")+" "+self.author+"\n\n"+_("support www.nachtfalke.biz"), MessageBox.TYPE_INFO)

	def save(self):
		for x in self["config"].list:
			if len(x) > 1:
        			x[1].save()
			else:
       				pass
					
		self.skin_lines = []       			
		###########READING DATA FILES
		try:
			self.appendSkinFile(self.daten + "header.xml")
			#SelectedLine
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.SkinSelectedLine.value +".xml")			
			###InfoBar
			self.appendSkinFile(self.daten + "infobar-header.xml")
			#Style
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.InfobarStyle.value + ".xml")
			#Picon			
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.InfobarPiconPath.value + ".xml")
			#Separator			
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.InfobarSeparator.value + ".xml")			
			#TopLeft			
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.InfobarTopLeft.value + ".xml")
			#TopCenter
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.InfobarTopCenter.value + ".xml")
			#TopRight
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.InfobarTopRight.value + ".xml")
			#InfobarHeadPanel
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.InfobarHead.value + ".xml")			
			#ChannelName
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.InfobarShowChannelname.value + ".xml")		
			#BottomLeft
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.InfobarBottomLeft.value + ".xml")
			#BottomCenter
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.InfobarBottomCenter.value + ".xml")			
			#BottomRight
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.InfobarBottomRight.value + ".xml")
			#RecordState
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.InfobarRecordState.value + ".xml")			
			#Footer
			self.appendSkinFile(self.daten + "infobar-footer.xml")			
			###SecondInfoBar
			self.appendSkinFile(self.daten + "secondinfobar-header.xml")
			#TopLeft
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.SecondInfobarTopLeft.value + ".xml")
			#TopCenter
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.SecondInfobarTopCenter.value + ".xml")
			#TopRight
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.SecondInfobarTopRight.value + ".xml")			
			#EPGWidget
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.SecondInfobarEPGWidget.value + ".xml")			
			#Footer
			self.appendSkinFile(self.daten + "secondinfobar-footer.xml")
			#Channelselection			
			self.appendSkinFile(self.daten + "channelselection-header.xml")
			#Channelselectionlist
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.ChannelselectionStyle.value + ".xml")
			#Channelselectioninfo
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.ChannelselectionInfo.value + ".xml")
			#Channelselection picon
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.ChannelselectionPicon.value + ".xml")			
			#Footer			
			self.appendSkinFile(self.daten + "channelselection-footer.xml")			
			#VOLUMESTYLE
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.VolumeStyle.value + ".xml")
			#SUBTITLESTYLE
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.SubtitleSitzeStyle.value + ".xml")			
			#MAINMENU
			self.appendSkinFile(self.daten + "menu-header.xml")
			#MENUSTYLE			
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.MainMenuStyle.value +".xml")
			#ICONSTYLE			
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.MainMenuIconBackColor.value +".xml")
			#Footer
			self.appendSkinFile(self.daten + "menu-footer.xml")
			#MOVIRLIST				
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.MovieSelectionStyle.value +".xml")
			#MERLINEPGCENTER								
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.MerlinEPGCenterStyle.value +".xml")
			#GP4
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.GP4.value +".xml")						
			#AMS
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.AMSStyle.value +".xml")			
			#EMC
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.EMCStyle.value +".xml")
			#VideoDB
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.VideoDBStyle.value +".xml")
			#Valis EPG
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.ValisEPGStyle.value +".xml")
			#Permanentclock
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.PMclockSize.value +".xml")			
			#Display OLED			
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.OledDisplayInfobarStyle.value +".xml")
			#Display Idle			
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.DisplayIdleStyle.value +".xml")			
			#Display LCD
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.DisplayChannelselectionStyle.value +".xml")
			#Display LCD
			self.appendSkinFile(self.daten + config.plugins.MetrixStyle.DisplayInfobarStyle.value +".xml")			
			###Main XML
			self.appendSkinFile(self.daten + "main.xml")
			### END			
			self.appendSkinFile(self.daten + "footer.xml")				
							
			xFile = open(self.dateiTMP, "w")
			for xx in self.skin_lines:
				xFile.writelines(xx)
			xFile.close()
			#Replaces <color name="metrixSelection" value="#000050ee" /> with SkinSelectedBackgroundColor.value
			o = open(self.datei,"w")
			for line in open(self.dateiTMP):
				
				line = line.replace("#000050ee", config.plugins.MetrixStyle.SkinSelectedBackgroundColor.value )				
				line = line.replace("#00fffffd", config.plugins.MetrixStyle.SkinSelectedForegroundColor.value )				
				line = line.replace("#30000000", config.plugins.MetrixStyle.SkinBackgroundColor.value )				
				line = line.replace("#00fffffe", config.plugins.MetrixStyle.SkinForegroundColor.value )
				line = line.replace("#00fffffc", config.plugins.MetrixStyle.SkinSelectedHelpTextColor.value )				
				line = line.replace("#00dddddd", config.plugins.MetrixStyle.SkinDateColor.value )
				line = line.replace("#00F472D1", config.plugins.MetrixStyle.SkinCaidInfoColor.value )				
				line = line.replace("#0070ad10", config.plugins.MetrixStyle.SkinTunerInfoColor.value )
				line = line.replace("#00F0A30B", config.plugins.MetrixStyle.PMclockColor.value )				
				line = line.replace("#00999998", config.plugins.MetrixStyle.Channeldescription.value )
				line = line.replace("#00999996", config.plugins.MetrixStyle.InfobarChannelnamecolor.value )				
				line = line.replace("p_bar", config.plugins.MetrixStyle.SkinProgressbarColor.value )
				line = line.replace("#00000001", config.plugins.MetrixStyle.SkinLCDbackgroundColor.value )				
				line = line.replace("#00ffffef", config.plugins.MetrixStyle.SkinLCDforegroundColor.value )				
				line = line.replace("#00ffffdf", config.plugins.MetrixStyle.SkinLCDclockColor.value )				
				line = line.replace("0012", config.plugins.MetrixStyle.SkinCornerRadius.value )				
				o.write(line)
			o.close()
			system('rm -rf ' + self.dateiTMP)

		except:
#		else:
			self.session.open(MessageBox, _("Error creating Skin!"), MessageBox.TYPE_ERROR)
		configfile.save()
		restartbox = self.session.openWithCallback(self.restartGUI,MessageBox,_("GUI needs a restart to apply a new skin\nDo you want to Restart the GUI now?"), MessageBox.TYPE_YESNO)
		restartbox.setTitle(_("Restart GUI"))

	def restartGUI(self, answer):
		if answer:
			self.session.open(TryQuitMainloop, 3)
			
	def appendSkinFile(self,appendFileName):
		if path.exists(appendFileName):
			skFile = open(appendFileName, "r")
			file_lines = skFile.readlines()
			skFile.close()	
			for x in file_lines:
				self.skin_lines.append(x)
		else:
			print "[MetrixStyle] %s not existing" % appendFileName
			
	def exit(self):
		for x in self["config"].list:
			if len(x) > 1:
					x[1].cancel()
			else:
       				pass
		del self.PicLoad
		self.close()
