# 2016.11.28 10:23:41 Jerusalem Standard Time
#Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/TSpanel/Stools/Moretools/ScreenGrabber/__init__.py
pass
# okay decompyling I:\TSpanel\7.5\oe2.0\1-final\TSpanel\Stools\Moretools\ScreenGrabber\__init__.pyo 
# decompiled 1 files: 1 okay, 0 failed, 0 verify failed
# 2016.11.28 10:23:41 Jerusalem Standard Time
