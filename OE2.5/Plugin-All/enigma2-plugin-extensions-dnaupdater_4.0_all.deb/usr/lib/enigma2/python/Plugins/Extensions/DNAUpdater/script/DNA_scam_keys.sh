#!/bin/sh
#DESCRIPTION=This script will update your image with DNA Scam Keys
echo "Scam KeyUpdate by DNA"
echo "erstelle Ordner..."
[ -d /var/keys ] || mkdir -p /var/keys
echo "lade Scam Keys herunter"

wget -q --timeout=3 --spider http://dark-network.eu/downloads/DNA-Updater/keys/scam_keys.tar.gz > /dev/null
if [ $? -eq 0 ]; then
        servernameip="dark-network.eu"
else
        servernameip="5.135.147.36"
fi

wget http://$servernameip/downloads/DNA-Updater/keys/scam_keys.tar.gz -O /tmp/scam_keys.tar.gz
wget http://$servernameip/downloads/DNA-Updater/keys/Keys_Changelog_info.txt -O /tmp/Keys_Changelog_info.txt

echo "Scam Keys werden installiert..."
tar -xzf /tmp/scam_keys.tar.gz -C /
chmod 644 /var/keys/constcw
chmod 644 /var/keys/constcw_older
chmod 644 /var/keys/cryptoworks
chmod 644 /var/keys/irdeto
chmod 644 /var/keys/irdeto2
chmod 644 /var/keys/nagra
chmod 644 /var/keys/nagra2
chmod 644 /var/keys/rsakeylist
chmod 644 /var/keys/seca
chmod 644 /var/keys/seca2
chmod 644 /var/keys/via
echo "Key-Update erfolgreich abgeschlossen."
echo ""
echo ""
echo ""
echo ""
more /tmp/Keys_Changelog_info.txt
echo "Loesche Installationsdatei...."
rm /tmp/scam_keys.tar.gz
rm /tmp/Keys_Changelog_info.txt
sleep 2
