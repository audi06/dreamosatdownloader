#!/bin/sh
#DESCRIPTION=This script will update your image with DNA oscam.keys
echo "Oscam Ymod KeyUpdate by DNA"
echo "erstelle Ordner..."
[ -d /var/tuxbox/config/keys ] || mkdir -p /var/tuxbox/config/keys
echo "lade Oscam Ymod Keys herunter"
rm -rf /var/tuxbox/config/oscam.keys

wget -q --timeout=3 --spider http://dark-network.eu/downloads/DNA-Updater/keys/oscam_keys.tar.gz > /dev/null
if [ $? -eq 0 ]; then
        servernameip="dark-network.eu"
else
        servernameip="5.135.147.36"
fi

wget http://$servernameip/downloads/DNA-Updater/keys/oscam_keys.tar.gz -O /tmp/oscam_keys.tar.gz
wget http://$servernameip/downloads/DNA-Updater/keys/Keys_Changelog_info.txt -O /tmp/Keys_Changelog_info.txt
                                  
tar -xzf /tmp/oscam_keys.tar.gz -C /
chmod 644 /var/tuxbox/config/oscam.keys
echo "Key-Update erfolgreich abgeschlossen."
echo ""
more /tmp/Keys_Changelog_info.txt
rm /tmp/oscam_keys.tar.gz                                                                  
rm /tmp/Keys_Changelog_info.txt
sleep 2
