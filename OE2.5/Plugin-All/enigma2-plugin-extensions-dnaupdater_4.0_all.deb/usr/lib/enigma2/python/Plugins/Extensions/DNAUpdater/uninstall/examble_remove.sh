#!/bin/sh


rm -rf /usr/bin/$dateiname
rm -rf /usr/script/bp-script/$dateiname
#$dateiname ist der datein name ist kein muss aber sicher ist sicher das dann auch alle datein bzw. ordner wech sind
opkg remove $paketname
#$paketname ist der name aus der contol  
exit 0

