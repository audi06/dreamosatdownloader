# PiconCleaner
#
# Coded by dre (c) 2014
# Support: www.dreambox-tools.info
# E-Mail: dre@dreambox-tools.info
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Multimedia GmbH.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Multimedia GmbH.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Multimedia GmbH.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.

from Components.ActionMap import ActionMap, HelpableActionMap
from Components.ConfigList import ConfigList, ConfigListScreen
from Components.config import config, ConfigSubsection, ConfigText, configfile, ConfigSelection, getConfigListEntry, ConfigYesNo
from Components.Label import Label
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaBlend
from Components.Pixmap import Pixmap
from Components.Sources.List import List
from Screens.MessageBox import MessageBox
from Plugins.Plugin import PluginDescriptor
from Screens.ChannelSelection import ChannelSelection
from Screens.Screen import Screen
from Screens.HelpMenu import HelpableScreen
from Tools.Directories import fileExists, SCOPE_SKIN_IMAGE, SCOPE_CURRENT_SKIN, resolveFilename, pathExists
from Tools.LoadPixmap import LoadPixmap

from os import listdir as os_listdir, system as os_system, path as os_path
from enigma import eServiceCenter, eServiceReference, gFont, loadPNG, eEnv, RT_HALIGN_RIGHT, eConsoleAppContainer

png_cache = {}

def PiconPixmap(picon, png_cache):
	png = png_cache.get(picon, None)
	if png is None: # no cached entry
		png = LoadPixmap(cached=True, path=picon)
		png_cache[picon] = png
	if png is None:
		png = png_cache.get("default", path=None)
		if png is None:
			png = LoadPixmap(cached=True, path=resolveFilename(SCOPE_SKIN_IMAGE, "skin_default/picon_default.png"))
			png_cache["default"] = png
	return png

def main(session,**kwargs):
	session.open(PiconCleaner)

def Plugins(**kwargs):

	list = []
	list.append(PluginDescriptor(name="PiconCleaner", description=_("Clean up unused picons"), where = [PluginDescriptor.WHERE_PLUGINMENU], icon="PiconCleaner.png", fnc=main))
	return list

class PiconCleaner(Screen, HelpableScreen):
	skin = """
		<screen position="center,center" size="600,475" title="PiconCleaner">
			<widget source="list" render="Listbox" position="0,0" size="600,400" scrollbarMode="showOnDemand">
				<convert type="TemplatedMultiContent">
					{"template": [
									MultiContentEntryPixmapAlphaBlend(pos=(0,0), size=(240,100), png=2), #index 2 is the picon png=loadPNG(picon)))
									MultiContentEntryText(pos=(250,20), size=(320,20), flags=RT_HALIGN_RIGHT, text=0), # index 0 is the path
									MultiContentEntryText(pos=(250,40), size=(320,20), flags=RT_HALIGN_RIGHT, text=1), # index 1 is the sref old: font=1, sref
					],
					"fonts": [gFont("Regular",18)],
					"itemHeight": 100
					}
				</convert>
			</widget>
			<widget name="ButtonRedtext" position="50,445" size="300,20" valign="center" halign="left" zPosition="10" font="Regular;18" transparent="1" />
			<widget name="ButtonRed" pixmap="skin_default/buttons/button_red.png" position="10,445" zPosition="10" size="16,16" transparent="1" alphatest="on" />
			<widget name="ButtonBluetext" position="50,415" size="250,20" valign="center" halign="left" zPosition="10" font="Regular;18" transparent="1" />
			<widget name="ButtonBlue" pixmap="skin_default/buttons/button_blue.png" position="10,415" zPosition="10" size="16,16" transparent="1" alphatest="on" />
			<widget name="ButtonGreentext" position="350,415" size="250,20" valign="center" halign="left" zPosition="10" font="Regular;18" transparent="1" />
			<widget name="ButtonGreen" pixmap="skin_default/buttons/button_green.png" position="310,415" zPosition="10" size="16,16" transparent="1" alphatest="on" />
		</screen>
		"""

	def __init__(self, session, args=0):
		self.skin = PiconCleaner.skin
		self.session = session
		Screen.__init__(self, session)
		HelpableScreen.__init__(self)
		
		self["OkCancelActions"] = HelpableActionMap(self, "OkCancelActions",
		{
			"cancel":	(self.close, _("Close")),
		}, -1)

		self["ColorActions"] = HelpableActionMap(self, "ColorActions",
		{
			"red":	(self.deleteSelectedPicon, _("Delete selected picon")),
			"blue": (self.deleteAllPicons, _("Delete all redundant picons")),
			"green": (self.assignNewServiceReference, _("Rename selected picon")),
		}, -1)		
		
		self["ButtonBlue"] = Pixmap()
		self["ButtonBluetext"] = Label(_("Delete all redundant picons"))
		
		self["ButtonRed"] = Pixmap()
		self["ButtonRedtext"] = Label(_("Delete selected picon"))

		self["ButtonGreen"] = Pixmap()
		self["ButtonGreentext"] = Label(_("Reassign selected picon"))
		
		self.list = []
		self["list"] = List(self.list)
		
		self.PiconEntryList = []
		self.allServicesList = []
		self.markerBouquetList = []
		self.stringServicesList = []
		self.cmdList = []
		self.run = 0
		self.errorcounter = 0
				
		self.container = eConsoleAppContainer()
		self.appClosed_conn = self.container.appClosed.connect(self.runFinished)
		self.dataAvail_conn = self.container.dataAvail.connect(self.dataAvail)
		
		self.piconpathlist = [eEnv.resolve("${datadir}/enigma2/")]
		
		dirList = os_listdir("/media")
		
		blockList =  ["hdd"]

		if fileExists("/proc/mounts"):
			mountsFile = open("/proc/mounts" ,"r")
			for line in mountsFile:
				entry = line.split()
				if entry[2] in ["nfs", "nfs4", "smbfs", "cifs"]:
					if entry[1].startswith("/media/"):
						print "[PiconCleaner] - found network drive. Exclude ", entry[1]
						blockList.append(entry[1][7:])
			mountsFile.close()
		
		for dir in dirList:
			if dir in blockList:
				continue
			if os_path.ismount("/media/%s" %(dir)) or (os_path.islink("/media/%s" %(dir)) and os_path.ismount(os_path.realpath("/media/%s" %(dir)))):
				self.piconpathlist.append("/media/%s/" %(dir))
			
		if os_path.ismount("/data"):
			self.piconpathlist.append("/data/")
		if os_path.ismount("/dreambox-data"):
			self.piconpathlist.append("/dreambox-data/")		
		
		self.onShown.append(self.buildScreen)
	
	def buildScreen(self):
		serviceslist = self.getBouquets()
		
		self.list = []
		
		for size in ['picon_50x30/','picon/','picon_220x132/','picon_320x240/','picon_400x170/','picon_500x300/','picon_oled/','picon_128x64/']:
			for piconpathentry in self.piconpathlist:
				path = piconpathentry + size

				if pathExists(path):
					for file in os_listdir(path):
						pos = file.find(".png")
						if pos != -1:
							filename = file[:pos]
						
							if not filename in serviceslist and not filename in self.markerBouquetList:
								piconpath = path+file
								
								png = png_cache.get(piconpath, None)
								if png is None:
									png = LoadPixmap(cached=True, path=piconpath)
									png_cache[piconpath] = png
									
								self.list.append(("%s" %(path), "%s" %(filename), png))
							
		self["list"].setList(self.list)	
		
	def deleteSelectedPicon(self):
		if len(self.list) > 0:
			self.index = self["list"].index
		
			file = "%s%s.png" %(self.list[self.index][0], self.list[self.index][1])
		
			file = file.replace("(", "\(").replace(")", "\)")
		
			self.cmdList.append("rm -f %s" %(file))
		
			self.container.execute(self.cmdList[self.run])
		
	def assignNewServiceReference(self):
		if len(self.list) > 0:
			self.index = self["list"].index
		
			file = "%s%s.png" %(self.list[self.index][0], self.list[self.index][1])
		
			self.session.open(ReassignPicon, file, self.allServicesList, self.markerBouquetList)

	def deleteAllPicons(self):
		if len(self.list) > 0:
			for entry in self.list:
				file = "%s%s.png" %(entry[0], entry[1])
			
				file = file.replace("(", "\(").replace(")", "\)")	
			
				self.cmdList.append("rm -f %s" %(file))
			
			self.container.execute(self.cmdList[self.run])
		

	def getBouquetServices(self, bouquetRoot):
		bouquets = []
		
		self.eServiceCenterInstance = eServiceCenter.getInstance()
		if config.usage.multibouquet.value:
			serviceList = self.eServiceCenterInstance.list(bouquetRoot)
			if serviceList:
				while True:
					service = serviceList.getNext()
					if not service.valid():
						break
					if service.flags & eServiceReference.isDirectory:
						info = self.eServiceCenterInstance.info(service)
						if info:
							bouquets.append(service)
							self.markerBouquetList.append(info.getName(service).replace(" ", "_"))
				return bouquets
		else:
			info = self.eServiceCenterInstance().info(bouquetRoot)
			if info:
				bouquets.append(bouquetRoot)
			return bouquets
	
	def getBouquets(self):		
		from Screens.ChannelSelection import service_types_tv, service_types_radio
		bouquetStringList = []
		if config.usage.multibouquet.value:
			bouquetStringList.append(service_types_tv + ' FROM BOUQUET "bouquets.tv"')
			bouquetStringList.append(service_types_radio + ' FROM BOUQUET "bouquets.radio"')
		else:
			bouquetStringList.append(service_types_tv + ' FROM BOUQUET "userbouquet.favourites.tv"')
			bouquetStringList.append(service_types_radio + ' FROM BOUQUET "userbouquet.favourites.radio"')
			
		for bouquetString in bouquetStringList:
			bouquetRoot = eServiceReference(bouquetString)
			bouquetServices = self.getBouquetServices(bouquetRoot)
			if bouquetServices is None:
				continue
				
			for service in bouquetServices:
				self.getDirectoryServices(service)
			
			for service in self.allServicesList:
				sRef = self.buildServiceRefString(service)

				if sRef is "":
					continue

				self.stringServicesList.append(sRef)	

		return self.stringServicesList				
				
	def getDirectoryServices(self, directory):
		serviceList = self.eServiceCenterInstance.list(directory)
		
		if serviceList:
			while True:
				service = serviceList.getNext()
				oldPath = ""
				if service.getPath() and not service.flags & eServiceReference.isGroup and not service.flags & eServiceReference.isMarker:
					oldPath = service.getPath()
					service.setPath("")
				if not service.valid():
					service.setPath(oldPath)
					break
				if service.flags & eServiceReference.isGroup:
					self.getDirectoryServices(service)
				elif service.flags & eServiceReference.isMarker:
					self.markerBouquetList.append(service.getName().replace(" ", "_"))
				else:
					self.allServicesList.append(service)
				service.setPath(oldPath)

	def buildServiceRefString(self,service):
		sRef = service.toString()
		if sRef is "":
			return sRef

		# strip all after last http (e.g. partnerbox-services)
		pos = sRef.rfind("http")
		if pos != -1:
			sRef = sRef[:pos]

		pos = sRef.rfind(':')
		if pos == -1:
			return ""

		sRef = sRef[:pos].rstrip(':').replace(':','_')
		return sRef

	def dataAvail(self, output):
		print "[Picon Cleaner] - Data available: %s" %(output)
		
	def runFinished(self, returnvalue):
		print "[Picon Cleaner] - Command executed: %d" %(returnvalue)
		if returnvalue != 0 and self.run>0:
			self.errorcounter += 1
			
		self.run += 1
		
		if self.run < len(self.cmdList):
			self.container.execute(self.cmdList[self.run])
		else:
			if self.errorcounter == 0:
				self.session.open(MessageBox, _("All files were deleted"), MessageBox.TYPE_INFO, timeout=5)
			else:
				self.session.open(MessageBox, _("%d/%d files were deleted\n%d files were not deleted due to an error") %(len(self.cmdList)-self.errorcounter, len(self.cmdList), self.errorcounter), MessageBox.TYPE_ERROR, timeout=5)
			
			self.errorcounter = 0
			self.run = 0
			self.cmdList = []
			
class ReassignPicon(Screen, HelpableScreen):
	skin = """
		<screen position="center,center" size="700,475" title="Reassign Picon">
			<widget source="picon" render="Listbox" position="0,0" size="220,100" scrollbarMode="showOnDemand" selectionDisabled="1">
				<convert type="TemplatedMultiContent">
					{"template": [
									MultiContentEntryPixmapAlphaBlend(pos=(0,0), size=(220,150), png=0) 
					],
					"fonts": [gFont("Regular",18)],
					"itemHeight": 150
					}
				</convert>
			</widget>
			<widget name="menulist" position="230,0" size="470,400" scrollbarMode="showOnDemand"/>
			<widget name="Description" position="50,415" size="250,20" valign="center" halign="left" zPosition="10" font="Regular;18" transparent="1" />
		</screen>
		"""
		
	def __init__(self, session, file, allServices, markerBouquet):
		self.skin = ReassignPicon.skin
		self.session = session
		self.file = file
		Screen.__init__(self, session, file)
		HelpableScreen.__init__(self)
		
		self["OkCancelActions"] = HelpableActionMap(self, "OkCancelActions",
		{
			"cancel":	(self.close, _("Close")),
			"ok":		(self.changePiconName, _("Change picon name")),
		}, -1)

		self["DirectionActions"] = HelpableActionMap(self, "DirectionActions",
		{
			"up":		(self.up, _("Move cursor up")),
			"down":		(self.down, _("Move cursor down")),
			"left":		(self.left, _("Change between menu and videos")),
			"right":	(self.right, _("Change between menu and videos")),
		}, -1)

		#self.png_cache = {}
		
		self["Description"] = Label(_("Press OK to reassign picon"))
		
		self.list = []
		self.referencelist = []
		self.piconlist = []
		self["menulist"] = MenuList([])	
		self["picon"] = List([])

		png = PiconPixmap(file, png_cache)
		self.piconlist.append((png,))
		
		self["picon"].setList(self.piconlist)

		eServiceCenterInstance = eServiceCenter.getInstance()	
		for entry in allServices:
			entry_str = ""
			info = eServiceCenterInstance.info(entry)
				
			name = info.getName(entry) #or ServiceReference(service).getServiceName() or ""
			name = name.replace('\xc2\x86', '').replace('\xc2\x87', '')
			entry_str = entry.toString()
			pos = 0
			pos = entry_str.rfind("http")
			if pos != -1:
				entry_str = entry_str[:pos]
			self.referencelist.append(entry_str)
						
			self.list.append(name)
			
		for entry in markerBouquet:
			self.referencelist.append(entry)
			
			self.list.append(entry.replace("_"," "))
			
		self["menulist"].setList(self.list)
		
		self["picon"].setSelectionEnabled(0)
		self["menulist"].selectionEnabled(1)
		
	def up(self):
		self["menulist"].up()
	
	def down(self):
		self["menulist"].down()
		
	def left(self):
		self["menulist"].pageUp()
		
	def right(self):
		self["menulist"].pageDown()
		
	def changePiconName(self):
		index = self["menulist"].getSelectedIndex()
		
		channel = self.referencelist[index]
		pos = 0
		pos = channel.rfind(":")
		if pos != -1:
			channel = channel[:pos]
		channel = channel.replace(":","_")
		
		pos = self.file.rfind("/")
		if pos != -1:
			path = self.file[:pos]
			
		print path
		
		if fileExists("%s/%s.png" %(path, channel)):
			self.session.open(MessageBox, _("Picon already exists!"), MessageBox.TYPE_ERROR, timeout=5)
		else:
			oldfile = self.file.replace("(", "\(").replace(")", "\)")
			channel = channel.replace("(", "\(").replace(")", "\)")
			result = os_system("mv %s %s/%s.png" %(oldfile, path, channel))
			
			if (int(result)/256)==0:
				self.session.open(MessageBox, _("Picon renamed"), MessageBox.TYPE_INFO, timeout=5)
				self.close()
			else:
				self.session.open(MessageBox, _("Picon could not be renamed"), MessageBox.TYPE_ERROR, timeout=5)
