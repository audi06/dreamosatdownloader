# -*- coding: utf-8 -*-
from enigma import quitMainloop, eActionMap
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.InfoBarGenerics import InfoBarAutoSleepTimer
from Screens.InputBox import InputBox
from Screens.ChoiceBox import ChoiceBox
from Components.ActionMap import ActionMap
from Components.Input import Input
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.MenuList import MenuList
from Screens.Console import Console
from Components.config import config, ConfigSubsection, ConfigText, ConfigBoolean, ConfigInteger, ConfigSelection, getConfigListEntry
from Components.ConfigList import ConfigListScreen, ConfigList
from Components.config import KEY_OK, KEY_NUMBERS
from Plugins.Plugin import PluginDescriptor
from enigma import eSize, eConsoleAppContainer, eTimer
from RecordTimer import RecordTimerEntry
import Screens.Standby
import os
import gettext

userscripts_version = "5.2.0"
userscripts_plugindir="/usr/lib/enigma2/python/Plugins/Extensions/UserScripts" 
userscripts_path = "/usr/script"
global userscripts_first
userscripts_first=True

os.environ['LANGUAGE']='en'
userscripts_language='en'

if os.path.exists("/etc/enigma2/settings") == True:
   f = open("/etc/enigma2/settings")
   line = f.readline()
   while (line):
	line = f.readline().replace("\n","")
	sp = line.split("=")
	if (sp[0] == "config.osd.language"):
	   sp2 = sp[1].split("_")
           userscripts_language = sp2[0]
           if os.path.exists("%s/locale/%s" % (userscripts_plugindir, userscripts_language)) == True:
              os.environ["LANGUAGE"] = sp[1]
           else:
              os.environ['LANGUAGE']='en'
   f.close

_=gettext.Catalog('userscripts', '%s/locale' % userscripts_plugindir).gettext

yes_no_descriptions = {False: _("no"), True: _("yes")}

config.plugins.userscripts = ConfigSubsection()                                                                                 
userscript_inactivity_options = []
userscript_inactivity_options.append(( "standby",_("Standby") ))
userscript_inactivity_options.append(( "idlemode",_("Idle Mode") ))
config.usage.inactivity_action = ConfigSelection(default = "standby", choices = userscript_inactivity_options)
config.plugins.userscripts.confirm = ConfigBoolean(default = False, descriptions=yes_no_descriptions)
config.plugins.userscripts.scriptsave = ConfigBoolean(default = False, descriptions=yes_no_descriptions)
userscriptlist_options = []
userscriptlist_options.append(( "none",_("none") ))
userscriptlist_options.append(( "execute",_("Execute") ))
userscriptlist_options.append(( "install",_("Install") ))
userscriptlist_options.append(( "both",_("Execute")+" & "+_("Install") ))
config.plugins.userscripts.list = ConfigSelection(default = "none", choices = userscriptlist_options)
userscriptshow_options = []
userscriptshow_options.append(( "plugin",_("Pluginlist") ))
userscriptshow_options.append(( "extension",_("Extension") ))
userscriptshow_options.append(( "both",_("Pluginlist")+" & "+_("Extension") ))
config.plugins.userscripts.show = ConfigSelection(default = "both", choices = userscriptshow_options)
config.plugins.userscripts.startupdelay = ConfigInteger(default = 2, limits = (0, 60))

def shutdown_userscripts(self, aborted):                                            
        print "[InfoBarAutoSleepTimer].shutdown"                        
        if aborted or Screens.Standby.inTryQuitMainloop:                
                print "aborted"                                  
                self.keypress(None, 1) #restart the timer               
                return                                           
                                                                        
        if Screens.Standby.inStandby != None:                           
		if config.usage.inactivity_action.value == "standby":
  	              print "RecordTimer.TryQuitMainloop"                     
  	              RecordTimerEntry.TryQuitMainloop(True)                  
		else:
	              print "already Screens.Standby.Standby"                 
        else:                                                           
		if config.usage.inactivity_action.value == "idlemode":
	              print "Screens.Standby.TryQuitMainloop"                 
	              self.session.open(Screens.Standby.Standby)  
		else:
	              print "Screens.Standby.Standby"                 
	              self.session.open(Screens.Standby.TryQuitMainloop, 1)  

Screens.InfoBarGenerics.InfoBarAutoSleepTimer.shutdown=shutdown_userscripts

class UserScriptsStartup(Screen):
    skin = """
        <screen position="center,center" size="400,300" title="User Scripts Startup" >
        </screen>"""
    def __init__(self,session):
        self.skin = UserScriptsStartup.skin
	self.session = session
	Screen.__init__(self,session)
        if config.plugins.userscripts.startupdelay.value > 0:
	        print "[USERSCRIPTS] doing autostart"
	        self.TimerUserScriptsDoStartup = eTimer()
	        self.TimerUserScriptsDoStartup.stop()
	        self.TimerUserScriptsDoStartup_conn=self.TimerUserScriptsDoStartup.timeout.connect(self.UserScriptsExecuteStartup)
	        self.TimerUserScriptsDoStartup.start(config.plugins.userscripts.startupdelay.value*1000,True) 
	else:
	        print "[USERSCRIPTS] autostart disabled"

    def UserScriptsExecuteStartup(self):
        self.UserStartupScripts=[]
	if os.path.exists("/usr/script"):
	        for script in os.listdir("/usr/script"):
        		if script.startswith("S"):
                		self.UserStartupScripts.append("/usr/script/%s start" % script)
          	self.UserStartupScripts.sort()
        if len(self.UserStartupScripts) > 0:
	        print "[USERSCRIPTS] starting %s" % self.UserStartupScripts
	        self.TimerUserScriptsDoStartup.stop()
		self.container = eConsoleAppContainer()
        	self.container_appClosed_conn = self.container.appClosed.connect(self.runNext)
        	print "[USERSCRIPT] is executing %s" % self.UserStartupScripts[0]
        	self.container.execute(self.UserStartupScripts[0].rstrip())
	else:
                print "[USERSCRIPT] no startup execution found" 
        
    def runNext(self, retval):
        if len(self.UserStartupScripts) > 1:
		self.UserStartupScripts.remove(self.UserStartupScripts[0])
                print "[USERSCRIPT] is executing %s" % self.UserStartupScripts[0]
	        self.container.execute(self.UserStartupScripts[0].rstrip())
	else:
                print "[USERSCRIPT] startup execution finished" 

def main(session,**kwargs):
    session.open(UserScriptsPlugin)

def autostart(reason,**kwargs):
    if kwargs.has_key("session") and reason == 0:                               
        session = kwargs["session"]                                             
        session.open(UserScriptsStartup)       

def Plugins(**kwargs):
    if config.plugins.userscripts.show.value=="plugin":
	    return [PluginDescriptor(where = [PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART], fnc = autostart),
	    	    PluginDescriptor(name=_("User Scripts"), description=_("OoZooN's User Script Plugin"), where = PluginDescriptor.WHERE_PLUGINMENU, icon="userscripts.png", fnc=main)]
    elif config.plugins.userscripts.show.value=="extension":
	    return [PluginDescriptor(where = [PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART], fnc = autostart),
	            PluginDescriptor(name=_("User Scripts"), description=_("OoZooN's User Script Plugin"), where = PluginDescriptor.WHERE_EXTENSIONSMENU, icon="userscripts.png", fnc=main)]
    elif config.plugins.userscripts.show.value=="both":
	    return [PluginDescriptor(where = [PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART], fnc = autostart),
	            PluginDescriptor(name=_("User Scripts"), description=_("OoZooN's User Script Plugin"), where = PluginDescriptor.WHERE_PLUGINMENU, icon="userscripts.png", fnc=main),
		    PluginDescriptor(name=_("User Scripts"), description=_("OoZooN's User Script Plugin"), where = PluginDescriptor.WHERE_EXTENSIONSMENU, icon="userscripts.png", fnc=main)]

class UserScriptsPlugin(Screen, ConfigListScreen):
	skin = """
		<screen position="center,center" size="720,200" title="OoZooN's User Script Plugin">
		<widget name="config" position="10,60" size="700,130" scrollbarMode="showOnDemand" />
		<widget name="logo" position="10,10" size="100,40" transparent="1" alphatest="on" />
		<widget name="buttonred" position="120,10" size="140,40" backgroundColor="red" valign="center" halign="center" zPosition="2"  foregroundColor="black" font="Regular;18"/>
		<widget name="buttongreen" position="270,10" size="140,40" backgroundColor="green" valign="center" halign="center" zPosition="2"  foregroundColor="black" font="Regular;18"/>
		<widget name="buttonyellow" position="420,10" size="140,40" backgroundColor="yellow" valign="center" halign="center" zPosition="2"  foregroundColor="black" font="Regular;18"/>
		<widget name="buttonblue" position="570,10" size="140,40" backgroundColor="blue" valign="center" halign="center" zPosition="2"  foregroundColor="black" font="Regular;18"/>
		</screen>"""

	def __init__(self, session):
		self.skin = UserScriptsPlugin.skin
        	self.setup_title=(_("OoZooN's User Script Plugin"))
		Screen.__init__(self, session)
		global userscripts_first
		if not userscripts_first and config.plugins.userscripts.scriptsave.value:
			print "[USERSCRIPTS] using previous save value"
			oldscript=config.plugins.userscripts.script.value
			oldoption=config.plugins.userscripts.option.value
		else:
			oldscript="none"
			oldoption="none"
			if config.plugins.userscripts.scriptsave.value:
				# let's check settings too
				if os.path.exists("/etc/enigma2/settings") == True:
			   		f = open("/etc/enigma2/settings")
			   		line = f.readline()
			   		while (line):
						line = f.readline().replace("\n","")
						sp = line.split("=")
						if (sp[0] == "config.plugins.userscripts.script"):
							oldscript=sp[1]
						if (sp[0] == "config.plugins.userscripts.option"):
							oldoption=sp[1]
					f.close()
			userscripts_first=False
		config.plugins.userscripts.script = ConfigSelection(default = "none", choices = self.getscripts(True))
		config.plugins.userscripts.option = ConfigSelection(default = "none", choices = self.getscriptoptions(True))
		config.plugins.userscripts.kit = ConfigSelection(default = "none", choices = self.getkits(True))
		config.plugins.userscripts.script.value=oldscript
		config.plugins.userscripts.option.value=oldoption

                self.list = []
		ConfigListScreen.__init__(self, self.list, session = self.session, on_change = self.changedEntry)
        	self.createSetup()    
	        self.onShown.append(self.setWindowTitle)                                                            
           	self.onLayoutFinish.append(self.byLayoutEnd)
	        self.OK=False
        	# explizit check on every entry                                                                     
        	self.onChangedEntry = []                                                                            
		self.onConfigEntryChanged = []
		self["buttonred"] = Label(_("Exit"))
		self["buttongreen"] = Label(_("Execute"))
		self["buttonyellow"] = Label(_("Install"))
		self["buttonblue"] = Label(_("Setup"))
		self["logo"] = Pixmap()

		self["actions"] = ActionMap(["WizardActions", "ColorActions"], {"red": self.cancel, "green": self.script, "yellow": self.install, "blue": self.config, "back": self.cancel }, -1) 

	def createSetup(self):                                                                                        
                self.list = []
		if config.plugins.userscripts.list.value != "both":
			if config.plugins.userscripts.list.value != "execute" and config.plugins.userscripts.list.value != "both":
        	        	self.list.append(getConfigListEntry(_("select User Script"), config.plugins.userscripts.script))
 	        		self.list.append(getConfigListEntry(_("select User Script option"), config.plugins.userscripts.option))
			if config.plugins.userscripts.list.value != "install" and config.plugins.userscripts.list.value != "both":
        	        	self.list.append(getConfigListEntry(_("select deb kit"), config.plugins.userscripts.kit))
	        self["config"].list = self.list                                         
        	self["config"].l.setList(self.list)                                     
                                                                                
    	def changedEntry(self):                                                     
		self.createSetup()                

	def rcKeyPressed(self, key, flag):                                                                                        
		if (key == 352 or key == 28) and flag == 1 and self.OK:
	        	print "[USERSCRIPTS] key %i flag %i" % (key,flag)                                                                                           
			self.script()
		return 0

	def setWindowTitle(self):                                                                               
		self.addOK(True)
       		self["logo"].instance.setPixmapFromFile("%s/userscripts.png" % userscripts_plugindir)
        	self.setTitle(_("OoZooN's User Script Plugin"))

        def byLayoutEnd(self,status=None): 
		w=720
		if config.plugins.userscripts.list.value == "execute":
			h=100
		elif config.plugins.userscripts.list.value == "install":
			h=130
		elif config.plugins.userscripts.list.value == "none":
			h=200
		else:
			h=60
		self.instance.resize(eSize(*(w, h)))
		self.createSetup()

	def getscriptoptions(self,order):                                                                               
		userscripts_options = []
		if order:
			userscripts_options.append(( "none",_("none") ))
			userscripts_options.append(( "start",_("start") ))
			userscripts_options.append(( "stop",_("stop") ))
			userscripts_options.append(( "restart",_("restart") ))
			userscripts_options.append(( "info",_("info") ))
			userscripts_options.append(( "enable",_("enable autostart") ))
			userscripts_options.append(( "disable",_("disable autostart") ))	
			userscripts_options.append(( "enable & start",_("enable autostart")+" & "+_("start") ))
			userscripts_options.append(( "stop & disable",_("stop")+" & "+_("disable autostart") ))	
			userscripts_options.append(( "userdefined",_("userdefined:") ))
			# add further option here
			# userscripts_options.append(( "dummy",_("dummy") ))
		else:
			userscripts_options.append(( _("none"),"none" ))
			userscripts_options.append(( _("start"), "start" ))
			userscripts_options.append(( _("stop"), "stop" ))
			userscripts_options.append(( _("restart"), "restart" ))
			userscripts_options.append(( _("info"), "info" ))
			userscripts_options.append(( _("enable autostart"), "enable" ))
			userscripts_options.append(( _("disable autostart"), "disable" ))	
			userscripts_options.append(( _("start")+" & "+_("enable autostart"), "start & enable" ))
			userscripts_options.append(( _("stop")+" & "+_("disable autostart"), "stop & disable" ))	
			userscripts_options.append(( _("userdefined:"), "userefined" ))
			# add further option here
			# userscripts_options.append(( _("dummy"), "dummy" ))
		return userscripts_options

	def getlistoptions(self,order):                                                                               
		userscriptlist_options = []
		if order:
			userscriptlist_options.append(( "none",_("none") ))
			userscriptlist_options.append(( "execute",_("Execute") ))
			userscriptlist_options.append(( "install",_("Install") ))
			userscriptlist_options.append(( "both",_("Execute")+" & "+_("Install") ))
		else:
			userscriptlist_options.append(( _("none"), "none" ))
			userscriptlist_options.append(( _("Execute"), "execute" ))
			userscriptlist_options.append(( _("Install"), "install" ))
			userscriptlist_options.append(( _("Execute")+" & "+_("Install"), "both" ))
		return userscriptlist_options

	def getscripts(self,order):                                                                               
		userscripts = []
		if order:
			userscripts.append(( "none", _("none")))
		else:
			userscripts.append((  _("none"), "none" ))
		if os.path.exists(userscripts_path) is True:
			for script in os.listdir(userscripts_path):
				if script.endswith(".sh") and not script.startswith("."): 
					if order:
						userscripts.append(( "%s/%s" % (userscripts_path,script), script.replace(".sh","") ))
					else:
						userscripts.append(( script.replace(".sh",""), "%s/%s" % (userscripts_path,script) ))
		if os.path.exists("/media/ba/script") is True:
			for script in os.listdir("/media/ba/script"):
				if script.endswith(".sh") and not script.startswith("."): 
					if order:
						userscripts.append(( "/media/ba/script/%s" % script, script.replace(".sh","") ))
					else:
						userscripts.append(( script.replace(".sh",""), "/media/ba/script/%s" % script))
		return userscripts

	def getkits(self,order):                                                                               
		userkits = []
                if order:                                                       
                        userkits.append(( "none",_("none") ))                   
                        userkits.append(( "/tmp/*.deb",_("/tmp") ))             
                else:                                                           
                        userkits.append(( _("none"), "none" ))                  
                        userkits.append(( _("/tmp"), "/tmp/*.deb" ))        
		for kitfile in os.listdir("/tmp"):
			if kitfile.endswith(".deb") is True: 
				if order:
					userkits.append(( "/tmp/%s" % kitfile, kitfile ))
				else:
					userkits.append(( kitfile, "/tmp/%s" % kitfile ))
		if os.path.exists("/media/hdd") is True:
			for kitfile in os.listdir("/media/hdd"):
				if kitfile.endswith(".deb") is True: 
					if order:
						userkits.append(( "/media/hdd/%s" % kitfile, kitfile))
					else:
						userkits.append(( kitfile, "/media/hdd/%s" % kitfile))
	
		if os.path.exists("/media/hdd/backup") is True:
			for kitfile in os.listdir("/media/hdd/backup"):
				if kitfile.endswith(".deb") is True: 
					if order:
						userkits.append(( "/media/hdd/backup/%s" % kitfile, kitfile))
					else:
						userkits.append(( kitfile, "/media/hdd/backup/%s" % kitfile))

		if os.path.exists("/media/ba/backup") is True:
			for kitfile in os.listdir("/media/ba/backup"):
				if kitfile.endswith(".deb") is True: 
					if order:
						userkits.append(( "/media/ba/backup/%s" % kitfile, kitfile))
					else:
						userkits.append(( kitfile, "/media/ba/backup/%s" % kitfile))
		return userkits

        def leave(self):
	      config.plugins.userscripts.script.save()
	      config.plugins.userscripts.option.save()
	      # doesn't make sense to save last kit and have it in the settings
	      config.plugins.userscripts.kit.value="none"
	      config.plugins.userscripts.kit.save()
	      self.removeOK()
              self.close(True)                                                                                              
                                                                        
    	def cancel(self):
    	      config.plugins.userscripts.script.cancel()
    	      config.plugins.userscripts.option.cancel()
	      self.removeOK()
              self.close(False)       
                                                                         
        def config(self):
	      self.removeOK()
              self.session.openWithCallback(self.byLayoutEnd,UserScriptsConfiguration)
	      self.OK=False

	def connectHighPrioAction(self):
		self.highPrioActionSlot = eActionMap.getInstance().bindAction('', -0x7FFFFFFF, self.rcKeyPressed)

	def disconnectHighPrioAction(self):
		self.highPrioAction = None

    	def addOK(self,status):
	      # thanks Dr. Best !         
              print "[USERSCRIPTS] add OK"                                                                                  
	      if not self.OK:
		self.OK=True
                self.onShow.append(self.connectHighPrioAction)                  
                self.onHide.append(self.disconnectHighPrioAction)     

    	def removeOK(self):
	      # thanks Dr. Best !         
              print "[USERSCRIPTS] remove OK"                                                                                  
	      if self.OK:
		 self.OK=False

        def script(self):
		self.removeOK()
		if config.plugins.userscripts.list.value == "execute" or config.plugins.userscripts.list.value == "both":
			options=self.getscripts(False)
			select=0
			i=0
			for option in options:
				print option
				if option[1]==config.plugins.userscripts.script.value:
					select=i
				i=i+1
			self.session.openWithCallback(self.doscript,ChoiceBox,_("select User Script"), options, None, select)
		else:
			self.doscript2(config.plugins.userscripts.script.value)

        def doscript(self,scriptname):
   	        self.removeOK()
        	if scriptname is None or scriptname[0] == "none" or scriptname[1] == "none":
			self.skipscript(_("script is none"))
        	else:
            		self.scriptname = scriptname[1]
			options=self.getscriptoptions(False)
			select=0
			i=0
			for option in options:
				print option
				if option[1]==config.plugins.userscripts.option.value:
					select=i
				i=i+1
			self.session.openWithCallback(self.dooption,ChoiceBox,_("select User Script option"), options, None, select)

        def dooption(self,scriptoption):
   	        self.removeOK()
		if scriptoption == None:
			self.skipscript(_("option is none"))
	        else:
			if scriptoption == "none":
				self.option=""
			else:
				self.option=scriptoption[1]
			if self.option == "userdefined":
				self.option="restart"
	       			self.session.openWithCallback(self.enteroption,InputBox, title=_("Please enter option for %s") % self.scriptname, text="%s                              " % self.option, maxSize=35, type=Input.TEXT)
    	   		else:
				if config.plugins.userscripts.confirm.value:
       					self.session.openWithCallback(self.execute,MessageBox,_("are you sure to %s %s ?") %(self.scriptname,self.option), MessageBox.TYPE_YESNO)
				else:
					self.execute(True)

        def doscript2(self,scriptname):
   	        self.removeOK()
		if scriptname == "none":
			self.skipscript(_("no user script selected"))
		else:
			self.scriptname=scriptname
			self.option=config.plugins.userscripts.option.value
			if self.option == "none":
				self.option=""
				if config.plugins.userscripts.confirm.value:
               				self.session.openWithCallback(self.execute,MessageBox,_("are you sure to %s %s ?") %(self.scriptname,self.option), MessageBox.TYPE_YESNO)
				else:
               				self.execute(True)
			elif self.option == "userdefined":
				self.option="restart"
		       		self.session.openWithCallback(self.enteroption,InputBox, title=_("Please enter option for %s") % self.scriptname, text="%s                              " % self.option, maxSize=35, type=Input.TEXT)
            		else:
				if config.plugins.userscripts.confirm.value:
               				self.session.openWithCallback(self.execute,MessageBox,_("are you sure to %s %s ?") %(self.scriptname,self.option), MessageBox.TYPE_YESNO)
				else:
					self.execute(True)

        def enteroption(self,option):
   	        self.removeOK()
        	if option is None:
			self.skipscript(_("option is none"))
        	else:
            		self.option = option.rstrip()
			if config.plugins.userscripts.confirm.value:
            			self.session.openWithCallback(self.execute,MessageBox,_("are you sure to %s %s ?") % (self.scriptname, self.option), MessageBox.TYPE_YESNO)
			else:
               			self.execute(True)
            
        def execute(self,answer):
   	        self.removeOK()
	        if answer is None:
	        	self.skipscript(_("answer is None"))
       		elif answer is False:
            		self.skipscript(_("you were not confirming"))
        	else:
            		title = _("executing User Script %s %s" %(self.scriptname,self.option))
			if self.option.find("&") is not -1:
				options=[]
				options=self.option.split("&")
				print options[0].rstrip().lstrip()
				print options[1].rstrip().lstrip()
            			cmd = "%s %s; %s %s"  % (self.scriptname,options[0],self.scriptname,options[1])
			else:
            			cmd = "%s %s"  % (self.scriptname,self.option)
			print "[USERSCRIPT] command %s" % cmd
			if config.plugins.userscripts.scriptsave.value:
				config.plugins.userscripts.script.value=self.scriptname
				config.plugins.userscripts.option.value=self.option
	            		self.session.openWithCallback(self.leave,Console,_(title),[cmd])
			else:
	            		self.session.openWithCallback(self.cancel,Console,_(title),[cmd])

	def skipscript(self,reason):
		self.removeOK()
		self.session.open(MessageBox,_("User Script was canceled, because %s") % reason, MessageBox.TYPE_ERROR)

	def install(self):
		self.removeOK()
		if config.plugins.userscripts.list.value == "install" or config.plugins.userscripts.list.value == "both":
			options=self.getkits(False)
			self.session.openWithCallback(self.doinstall,ChoiceBox,_("select deb kit"), options)
		else:
			self.doinstall2(config.plugins.userscripts.kit.value)

	def doinstall(self,userscriptkit):
   	        self.removeOK()
		if userscriptkit is None or userscriptkit[0] == "none" or userscriptkit[1] == "none":
			self.skipinstall(_("no kit selected"))
		else:
			self.kit=userscriptkit[1]
			if config.plugins.userscripts.confirm.value:
				self.session.openWithCallback(self.debinstall,MessageBox,_("install %s ?") % self.kit,MessageBox.TYPE_YESNO)
			else:
               			self.debinstall(True)

	def doinstall2(self,userscriptkit):
   	        self.removeOK()
		if userscriptkit == "none":
			self.skipinstall(_("no kit selected"))
		else:
			self.kit=userscriptkit
			if config.plugins.userscripts.confirm.value:
				self.session.openWithCallback(self.debinstall,MessageBox,_("install %s ?") % self.kit,MessageBox.TYPE_YESNO)
			else:
               			self.debinstall(True)

	def skipinstall(self,reason):
		self.removeOK()
        	self.session.open(MessageBox,_("deb install was canceled, because %s") % reason, MessageBox.TYPE_ERROR)
            
	def debinstall(self,answer):
   	        self.removeOK()
	        if answer is None:
	        	self.skipinstall(_("answer is None"))
        	elif answer is False:
            		self.skipinstall(_("you were not confirming"))
        	else:
			title = _("installing %s" %(self.kit))
			cmd = "apt-get update; dpkg -i %s; apt-get install -f -y --force-yes"  % (self.kit)
            		self.session.open(Console,_(title),[cmd])

class UserScriptsConfiguration(Screen, ConfigListScreen):
	skin = """
		<screen position="center,center" size="720,280" title="OoZooN's User Script Plugin">
		<widget name="config" position="10,60" size="700,210" scrollbarMode="showOnDemand" />
		<widget name="logo" position="10,10" size="100,40" transparent="1" alphatest="on" />
		<widget name="buttonred" position="120,10" size="140,40" backgroundColor="red" valign="center" halign="center" zPosition="2"  foregroundColor="black" font="Regular;18"/>
		<widget name="buttongreen" position="270,10" size="140,40" backgroundColor="green" valign="center" halign="center" zPosition="2"  foregroundColor="black" font="Regular;18"/>
		<widget name="buttonyellow" position="420,10" size="140,40" backgroundColor="yellow" valign="center" halign="center" zPosition="2"  foregroundColor="black" font="Regular;18"/>
		<widget name="buttonblue" position="570,10" size="140,40" backgroundColor="blue" valign="center" halign="center" zPosition="2"  foregroundColor="black" font="Regular;18"/>
		</screen>"""

	def __init__(self, session):
		self.skin = UserScriptsConfiguration.skin
		Screen.__init__(self, session)
                self.list = []
                self.list.append(getConfigListEntry(_("select from list"), config.plugins.userscripts.list))
                self.list.append(getConfigListEntry(_("save script and option"), config.plugins.userscripts.scriptsave))
                self.list.append(getConfigListEntry(_("show plugin"), config.plugins.userscripts.show))
		self.list.append(getConfigListEntry(_("confirm"), config.plugins.userscripts.confirm))
		self.list.append(getConfigListEntry(_("Inactive"), config.usage.inactivity_action))
		self.list.append(getConfigListEntry(_("Delay")+" [0 = "+_("disabled")+"]", config.plugins.userscripts.startupdelay))
		self.list.append(getConfigListEntry(_("Recordings"), config.misc.recording_allowed))
	        self.onShown.append(self.setWindowTitle)                                                            
		self.oldlist=config.plugins.userscripts.list.value
		self.oldshow=config.plugins.userscripts.show.value
		ConfigListScreen.__init__(self, self.list)
	        self.OK=False
        	# explizit check on every entry                                                                     
        	self.onChangedEntry = []                                                                            
		self["buttonred"] = Label(_("Exit"))
		self["buttongreen"] = Label(_("Save"))
		self["buttonyellow"] = Label(_("Cleanup"))
		self["buttonblue"] = Label(_("About"))
		self["logo"] = Pixmap()
		self["actions"] = ActionMap(["WizardActions", "ColorActions"], {"red": self.cancel, "green": self.leave, "blue": self.about, "yellow": self.clean, "back": self.cancel  }, -1) 

	def setWindowTitle(self):                                                                               
		self.addOK()
       		self["logo"].instance.setPixmapFromFile("%s/userscripts.png" % userscripts_plugindir)
        	self.setTitle(_("OoZooN's User Script Plugin")+" "+_("Configuration"))

	def rcKeyPressed(self, key, flag):                                                                                        
		if (key == 352 or key == 28) and flag == 1:
	        	print "[USERSCRIPTS] config key %i flag %i" % (key,flag)                                                                                           
			self.leave()
		return 0

        def leave(self):
		self.removeOK()
		config.plugins.userscripts.confirm.save()
		config.plugins.userscripts.list.save()
		config.plugins.userscripts.scriptsave.save()
		config.plugins.userscripts.show.save()
		config.plugins.userscripts.startupdelay.save()
		config.usage.inactivity_action.save()
		config.misc.recording_allowed.save()
		self.close(True)

	def connectHighPrioAction(self):
		self.highPrioActionSlot = eActionMap.getInstance().bindAction('', -0x7FFFFFFF, self.rcKeyPressed)

	def disconnectHighPrioAction(self):
		self.highPrioAction = None

    	def addOK(self):
	      # thanks Dr. Best !         
              print "[USERSCRIPTS] add config OK"                                                                                  
	      if not self.OK:
	        self.OK=True
                self.onShow.append(self.connectHighPrioAction)                  
                self.onHide.append(self.disconnectHighPrioAction)     

    	def removeOK(self):
	      # thanks Dr. Best !         
              print "[USERSCRIPTS] remove config OK"                                                                                  
	      if self.OK:
		 self.OK=False

    	def cancel(self):                                                                                                         
	      config.plugins.userscripts.confirm.cancel()
	      config.plugins.userscripts.list.cancel()
	      config.plugins.userscripts.scriptsave.cancel()
	      config.plugins.userscripts.show.cancel()
	      self.removeOK()
              self.close(False)       
                                                                         
        def about(self):
	      self.removeOK()
              title=_("User Scripts Plugin %s from OoZooN\npowered by gutemine") % (userscripts_version)
              self.session.open(MessageBox, title,  MessageBox.TYPE_INFO)

        def clean(self):
	      self.removeOK()
              self.container = eConsoleAppContainer()
              clean_cmd="apt-get clean"
              self.container.execute(clean_cmd)
              message=_("apt-get")+" "+_("cache")+" "+_("cleaned")
              self.session.open(MessageBox, message,  MessageBox.TYPE_INFO)
