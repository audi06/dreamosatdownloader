from os import chmod as os_chmod, system as os_system, path as os_path
from Plugins.Plugin import PluginDescriptor

def main(session, **kwargs):
	os_system("systemctl start doit")

def Plugins(**kwargs):
 	return PluginDescriptor(
		name="08/15 Do it (kodi)",
		description="just do it...",
		where = PluginDescriptor.WHERE_PLUGINMENU,
		icon=None,
		fnc=main)
