#######################################################################
#
#  SkinInfo
#  SkinInfo for Dreambox/Enigma-2
#  Coded by marthom (c)2012 - 2014
#
#  Support: www.dreambox-tools.info
#  E-Mail: marthom@dreambox-tools.info
#
#  This plugin is open source but it is NOT free software.
#
#  This plugin may only be distributed to and executed on hardware which
#  is licensed by Dream Multimedia GmbH.
#  In other words:
#  It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
#  to hardware which is NOT licensed by Dream Multimedia GmbH.
#  It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
#  on hardware which is NOT licensed by Dream Multimedia GmbH.
#
#  If you want to use or modify the code or parts of it,
#  you have to keep MY license and inform me about the modifications by mail.
#
#######################################################################

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.HelpMenu import HelpableScreen
from Screens.MessageBox import MessageBox
from Screens.Standby import TryQuitMainloop
from Screens.ChoiceBox import ChoiceBox
from Screens.Console import Console

from skin import parseColor, TemplatedListFonts, componentSizes

from Components.ActionMap import ActionMap, HelpableActionMap
from Components.Button import Button
from Components.Label import Label
from Components.Sources.List import List
from Components.MenuList import MenuList
from Components.config import config, ConfigYesNo, ConfigSubsection, getConfigListEntry, ConfigSelection, ConfigText, ConfigInteger
from Components.ConfigList import ConfigListScreen

from enigma import eListbox, eListboxPythonMultiContent, gFont, RT_HALIGN_LEFT, RT_VALIGN_CENTER

from Tools.Directories import resolveFilename, SCOPE_CURRENT_SKIN, fileExists
from Tools.LoadPixmap import LoadPixmap
from Tools.Notifications import AddPopup

import xml.etree.cElementTree as Tree

import socket
import struct
import base64
import os


skinxml = config.skin.primary_skin.value
skindir = "/usr/share/enigma2/"
skinfile = skindir + skinxml
skinname = skinxml[0:skinxml.find("/")]

class MerlinSkinInfo(Screen, HelpableScreen):
	skin = """
		<screen position="center,center" size="1200,620" title="%s" >
			<widget name="titleColors" position="5,5" size="200,30" font="Regular;20" valign="center" halign="left"/>
			<widget name="titleScreens" position="5,5" size="200,30" font="Regular;20" valign="center" halign="left"/>
			
			<widget name="TestLabel" position="5,45" size="140,30" font="Regular;20" valign="center" halign="center" />
			
			<widget name="TestLabel123" position="220,5" size="250,30" font="Regular;20" valign="center" halign="center" />
			<widget name="TestLabel456" position="220,45" size="250,30" font="Regular;20" valign="center" halign="center" />
			
			<widget name="TestLabel1" position="515,5" size="120,30" font="Regular;20" valign="center" halign="center" />
			<widget name="TestLabel2" position="645,5" size="120,30" font="Regular;20" valign="center" halign="center" />
			<widget name="TestLabel3" position="775,5" size="120,30" font="Regular;20" valign="center" halign="center" />
			
			<widget name="TestLabel4" position="515,45" size="120,30" font="Regular;20" valign="center" halign="center" />
			<widget name="TestLabel5" position="645,45" size="120,30" font="Regular;20" valign="center" halign="center" />
			<widget name="TestLabel6" position="775,45" size="120,30" font="Regular;20" valign="center" halign="center" />
			
			<widget name="SkinListLabel" position="5,93" size="210,20" font="Regular;15" valign="center" halign="left" />
			<widget name="skinlist" position="5,120" size="210,488" scrollbarMode="showOnDemand" zPosition="1" />

			<widget name="ColorListLabel" position="220,93" size="320,20" font="Regular;15" valign="center" halign="left" />
			<widget name="colorlist" position="220,120" size="320,488" scrollbarMode="showOnDemand" zPosition="1" />

			<widget name="ScreenListLabel" position="550,93" size="320,20" font="Regular;15" valign="center" halign="left" />
			<widget name="screenlist" position="550,120" size="320,488" scrollbarMode="showOnDemand" zPosition="1" />
			
			<widget name="xmlLabel" position="880,85" size="308,36" font="Regular;15" valign="center" halign="left" />
			<widget name="xmlText" position="880,125" size="308,493" font="Regular;10" valign="top" halign="left" />
		</screen>"""% _("MerlinSkinInfo")

	def __init__(self, session):
		self.session = session
		Screen.__init__(self, session)
		HelpableScreen.__init__(self)
		
		self.setTitle("MerlinSkinInfo - Skin: " + skinname)
		
		self.curList = "skinlist"
		
		self["TestLabel"] = Label(_("Test"))

		self["TestLabel123"] = Label(_("als Hindergrundfarbe"))
		self["TestLabel456"] = Label(_("als Vordergrundfarbe"))

		self["TestLabel1"] = Label(_("Test1"))
		self["TestLabel2"] = Label(_("Test2"))
		self["TestLabel3"] = Label(_("Test3"))
		self["TestLabel4"] = Label(_("Test4"))
		self["TestLabel5"] = Label(_("Test5"))
		self["TestLabel6"] = Label(_("Test6"))

		self["SkinListLabel"] = Label(_("Skins"))
		self["ColorListLabel"] = Label(_("Colors"))
		self["ScreenListLabel"] = Label(_("Screens"))
		
		self["xmlLabel"] = Label(_("XML Vorschau"))
		self["xmlText"] = Label(_(""))
		
		self["titleColors"] = Label("Colors")
		self["titleScreens"] = Label("Screens")

		self["skinlist"] = GetSkinList([])
		self["colorlist"] = GetColorList([])
		self["screenlist"] = GetScreenList([])

		self.onSelectionChanged = [ ]

		self["EPGSelectActions"] = HelpableActionMap(self, "EPGSelectActions",
		{
			"prevBouquet": self.listleft,
			"nextBouquet": self.listright,
		}, -2)

		self["DirectionActions"] = HelpableActionMap(self, "DirectionActions",
		{
			"up":		(self.up, _("Move cursor up")),
			"down":		(self.down, _("Move cursor down")),
			"left":		(self.listleft, _("Change between skins, colors and screens")),
			"right":	(self.listright, _("Change between skins, colors and screens")),
		}, -1)

		self["OkCancelActions"] = HelpableActionMap(self, "OkCancelActions",
		{
			#"ok":		(self.exit, _("Close plugin")),
			"cancel":	(self.exit, _("Close plugin")),
		}, -1)

		self.updateSkinList()
		self.updateColorList()
		self.updateScreenList()
		
		self.onLayoutFinish.append(self.startRun) # Shaderman

	# Shaderman
	def startRun(self):
		print '[MerlinSkinInfo] running'
		self["colorlist"].onSelectionChanged.append(self.changedColor)
		self["screenlist"].onSelectionChanged.append(self.changedScreen)
		self["skinlist"].onSelectionChanged.append(self.changedSkin)
		self["skinlist"].moveToIndex(1)
		self["skinlist"].moveToIndex(0)
		self["colorlist"].selectionEnabled(0)
		self["screenlist"].selectionEnabled(0)

	def up(self):
		if len(self.curList) > 1:
			self[self.curList].up()
	
	def down(self):
		if len(self.curList) > 1:
			self[self.curList].down()

	def changedScreen(self):
		index = self["screenlist"].getSelectionIndex()
		sel = self["screenlist"].list[index]
		curScreen = sel[1][7]

		self["xmlLabel"].setText("XML Vorschau - " + curScreen)
		
		global skinfile

		fo = open(skinfile, "r+")
		str = fo.read()
		
		pos1 = str.find('name="' + curScreen)
		pos2 = str.find("</screen>", pos1)
		pos3 = str.rfind("<screen", 0, pos1)
		
		#self["xmlText"].setText(curScreen + " - " + str[pos3:pos2] + " - %s - %s - %s - " % (pos1, pos2, pos3))	
		self["xmlText"].setText(str[pos3:pos2] + "</screen>")	
		
	def changedSkin(self):
		index = (self["skinlist"].getSelectionIndex()) 
		sel = self["skinlist"].list[index]
		
		global skinfile
		skinfile = skindir + sel[1][7] + "/skin.xml"
		
		self.setTitle("SkinInfo - Skin: " + sel[1][7] + " (" + skinfile + ")")

		self.updateColorList()
		self.updateScreenList()
		self["colorlist"].selectionEnabled(1)
		self["colorlist"].moveToIndex(1)
		self["colorlist"].moveToIndex(0)

		self["skinlist"].selectionEnabled(1)
		self["colorlist"].selectionEnabled(0)
		self["screenlist"].selectionEnabled(0)
		
	def changedColor(self):
		index = self["colorlist"].getSelectionIndex()
		sel = self["colorlist"].list[index]
		curColor = sel[2][7]
		
		self["titleColors"].setText(sel[1][7])
		
		self["TestLabel"].setText(sel[2][7])
		self["TestLabel"].instance.setBackgroundColor(parseColor("#808080"))
		
		self["TestLabel1"].instance.setBackgroundColor(parseColor(curColor))
		self["TestLabel1"].instance.setForegroundColor(parseColor("#ffffff"))
		self["TestLabel1"].hide()
		self["TestLabel1"].show()
		
		self["TestLabel2"].instance.setBackgroundColor(parseColor(curColor))
		self["TestLabel2"].instance.setForegroundColor(parseColor("#808080"))
		self["TestLabel2"].hide()
		self["TestLabel2"].show()

		self["TestLabel3"].instance.setBackgroundColor(parseColor(curColor))
		self["TestLabel3"].instance.setForegroundColor(parseColor("#000000"))
		self["TestLabel3"].hide()
		self["TestLabel3"].show()

		self["TestLabel4"].instance.setBackgroundColor(parseColor("#ffffff"))
		self["TestLabel4"].instance.setForegroundColor(parseColor(curColor))
		self["TestLabel4"].hide()
		self["TestLabel4"].show()
	
		self["TestLabel5"].instance.setBackgroundColor(parseColor("#808080"))
		self["TestLabel5"].instance.setForegroundColor(parseColor(curColor))
		self["TestLabel5"].hide()
		self["TestLabel5"].show()
	
		self["TestLabel6"].instance.setBackgroundColor(parseColor("#000000"))
		self["TestLabel6"].instance.setForegroundColor(parseColor(curColor))
		self["TestLabel6"].hide()
		self["TestLabel6"].show()
	
	def updateSkinList(self):
		self["skinlist"].buildList()

	def updateColorList(self):
		self["colorlist"].buildList()

	def updateScreenList(self):
		self["screenlist"].buildList()
		
	def listright(self):
		if self.curList == "skinlist":
			self["skinlist"].selectionEnabled(0)
			self["screenlist"].selectionEnabled(0)
			self["colorlist"].selectionEnabled(1)
			
			self.curList = "colorlist"

		elif self.curList == "colorlist":
			self["skinlist"].selectionEnabled(0)
			self["colorlist"].selectionEnabled(0)
			self["screenlist"].selectionEnabled(1)
			
			self.curList = "screenlist"

		elif self.curList == "screenlist":
			self["skinlist"].selectionEnabled(1)
			self["colorlist"].selectionEnabled(0)
			self["screenlist"].selectionEnabled(0)
			
			self.curList = "skinlist"

	def listleft(self):
		if self.curList == "skinlist":
			self["skinlist"].selectionEnabled(0)
			self["screenlist"].selectionEnabled(1)
			self["colorlist"].selectionEnabled(0)
			
			self.curList = "screenlist"

		elif self.curList == "colorlist":
			self["skinlist"].selectionEnabled(1)
			self["colorlist"].selectionEnabled(0)
			self["screenlist"].selectionEnabled(0)
			
			self.curList = "skinlist"

		elif self.curList == "screenlist":
			self["skinlist"].selectionEnabled(0)
			self["colorlist"].selectionEnabled(1)
			self["screenlist"].selectionEnabled(0)
			
			self.curList = "colorlist"

	def restartGUI(self, answer):
		if answer is True:
			self.session.open(TryQuitMainloop, 3)
		else:
			self.close()
	
	def exit(self):
		print "[MerlinSkinInfo] closing"
		self["skinlist"].onSelectionChanged.remove(self.changedSkin) # Shaderman
		self["colorlist"].onSelectionChanged.remove(self.changedColor) # Shaderman
		self["screenlist"].onSelectionChanged.remove(self.changedScreen) # Shaderman
		self.close()

def main(session, **kwargs):
	session.open(MerlinSkinInfo)

def Plugins(path,**kwargs):
	list = [PluginDescriptor(name = "MerlinSkinInfo", description = "MerlinSkinInfo", where = PluginDescriptor.WHERE_PLUGINMENU, icon = "plugin.png", fnc = main)]
	return list		

# =================================================================================================

class GetSkinList(MenuList):
	SKIN_COMPONENT_KEY = "MerlinSkinThemesList"
	SKIN_COMPONENT_SKINNAME_WIDTH = "skinnameWidth"
	SKIN_COMPONENT_LINE_HEIGHT = "lineHeight"
	
	def __init__(self, list, enableWrapAround = True):
		MenuList.__init__(self, list, enableWrapAround, eListboxPythonMultiContent)
		tlf = TemplatedListFonts()
		self.l.setFont(0, gFont(tlf.face(tlf.SMALLER), tlf.size(tlf.SMALLER)))
		sizes = componentSizes[GetSkinList.SKIN_COMPONENT_KEY]		
		lineHeight = sizes.get(GetSkinList.SKIN_COMPONENT_LINE_HEIGHT, 18)
		self.l.setItemHeight(lineHeight)
		
	def buildList(self):
		list = []
		
		sizes = componentSizes[GetSkinList.SKIN_COMPONENT_KEY]
		skinnameWidth = sizes.get(GetSkinList.SKIN_COMPONENT_SKINNAME_WIDTH, 200)
		lineHeight = sizes.get(GetSkinList.SKIN_COMPONENT_LINE_HEIGHT, 18)		

		dirs = os.listdir(skindir)
		for dir in dirs:
			if os.path.isdir(skindir + dir) is True:
				if os.path.exists(skindir + dir + "/skin.xml") is True:
					res = [
						dir,
						(eListboxPythonMultiContent.TYPE_TEXT, 5, 0, skinnameWidth, lineHeight, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, dir),
					]
					list.append(res)

		self.list = list
		self.l.setList(list)

# =================================================================================================

class GetColorList(MenuList):
	SKIN_COMPONENT_KEY = "MerlinSkinThemesList"
	SKIN_COMPONENT_COLORNAME_WIDTH = "colornameWidth"
	SKIN_COMPONENT_VALUE_WIDTH = "valueWidth"
	SKIN_COMPONENT_LINE_HEIGHT = "lineHeight"	

	def __init__(self, list, enableWrapAround = True):
		MenuList.__init__(self, list, enableWrapAround, eListboxPythonMultiContent)
		tlf = TemplatedListFonts()
		self.l.setFont(0, gFont(tlf.face(tlf.SMALLER), tlf.size(tlf.SMALLER)))
		sizes = componentSizes[GetColorList.SKIN_COMPONENT_KEY]
		lineHeight = sizes.get(GetColorList.SKIN_COMPONENT_LINE_HEIGHT, 18)
		self.l.setItemHeight(lineHeight)
		
	def buildList(self):
		list = []
		
		sizes = componentSizes[GetColorList.SKIN_COMPONENT_KEY]
		colornameWidth = sizes.get(GetColorList.SKIN_COMPONENT_COLORNAME_WIDTH, 200)
		valueWidth = sizes.get(GetColorList.SKIN_COMPONENT_VALUE_WIDTH, 80)	
		lineHeight = sizes.get(GetSkinList.SKIN_COMPONENT_LINE_HEIGHT, 18)	

		SkinFile = open(skinfile, "r")
		curTree = Tree.parse(SkinFile)
	
		for colors in curTree.findall("colors/color"):
			res = [
				colors,
				(eListboxPythonMultiContent.TYPE_TEXT, 5, 0, colornameWidth, lineHeight, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, colors.attrib["name"]),
				(eListboxPythonMultiContent.TYPE_TEXT, 5+colornameWidth, 0, valueWidth, lineHeight, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, colors.attrib["value"]),
			]
			list.append(res)

		SkinFile.close()
		
		self.list = list
		self.l.setList(list)

# =================================================================================================

class GetScreenList(MenuList):
	SKIN_COMPONENT_KEY = "MerlinSkinThemesList"
	SKIN_COMPONENT_SCREENNAME_WIDTH = "screennameWidth"
	SKIN_COMPONENT_LINE_HEIGHT = "lineHeight"	
	
	def __init__(self, list, enableWrapAround = True):
		MenuList.__init__(self, list, enableWrapAround, eListboxPythonMultiContent)
		tlf = TemplatedListFonts()
		self.l.setFont(0, gFont(tlf.face(tlf.SMALLER), tlf.size(tlf.SMALLER)))
		sizes = componentSizes[GetScreenList.SKIN_COMPONENT_KEY]
		lineHeight = sizes.get(GetScreenList.SKIN_COMPONENT_LINE_HEIGHT, 18)
		self.l.setItemHeight(lineHeight)
		
	def buildList(self):
		list = []
		
		sizes = componentSizes[GetScreenList.SKIN_COMPONENT_KEY]
		screennameWidth = sizes.get(GetScreenList.SKIN_COMPONENT_SCREENNAME_WIDTH, 320)	
		lineHeight = sizes.get(GetSkinList.SKIN_COMPONENT_LINE_HEIGHT, 18)			

		SkinFile = open(skinfile, "r")
		curTree = Tree.parse(SkinFile)
	
		for screens in curTree.findall("screen"):
			res = [
				screens,
				(eListboxPythonMultiContent.TYPE_TEXT, 5, 0, screennameWidth, lineHeight, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, screens.attrib["name"]),
			]
			list.append(res)

		SkinFile.close()
		
		self.list = list
		self.l.setList(list)

