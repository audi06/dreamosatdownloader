#######################################################################
#
#  MerlinSkinThemes for Dreambox/Enigma-2
#  Modul PreviewScreen
#  Coded by marthom (c)2012 - 2014
#
#  Support: www.dreambox-tools.info
#  E-Mail: marthom@dreambox-tools.info
#
#  This plugin is open source but it is NOT free software.
#
#  This plugin may only be distributed to and executed on hardware which
#  is licensed by Dream Multimedia GmbH.
#  In other words:
#  It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
#  to hardware which is NOT licensed by Dream Multimedia GmbH.
#  It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
#  on hardware which is NOT licensed by Dream Multimedia GmbH.
#
#  If you want to use or modify the code or parts of it,
#  you have to keep MY license and inform me about the modifications by mail.
#
#######################################################################

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen

from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.config import config, ConfigYesNo, ConfigSubsection, getConfigListEntry, ConfigSelection, ConfigText, ConfigInteger
from Components.Sources.ServiceEvent import ServiceEvent

from enigma import addFont

from Tools.Directories import resolveFilename, SCOPE_SKIN, SCOPE_SKIN_IMAGE, SCOPE_FONTS, SCOPE_CURRENT_SKIN, SCOPE_CONFIG, fileExists

import xml.etree.cElementTree as Tree

SourceList = ["HbbtvApplication", "Service", "ServiceEvent", "ServiceEventReference", "RecordingPossible", "ShowRecordOnRed", "TimeshiftPossible", "ShowTimeshiftOnYellow", "ShowAudioOnYellow", "ExtensionsAvailable"]
#SourceList = ["HbbtvApplication", "RecordingPossible", "ShowRecordOnRed", "TimeshiftPossible", "ShowTimeshiftOnYellow", "ShowAudioOnYellow", "ExtensionsAvailable"]
NameList = ["key_red", "key_green", "key_yellow", "key_blue", "list", "waitingtext", "freeDiskSpace", "DescriptionBorder", "chapterLabel"]

SkinXML = config.skin.primary_skin.value
SkinDir = "/usr/share/enigma2/"
SkinFile = SkinDir + SkinXML
SkinName = SkinXML[0:SkinXML.find("/")]
ThemeFile = SkinDir + SkinName + "/themes.xml"

selSkinFile = SkinDir + config.plugins.MerlinSkinThemes.Skin.value + "/skin.xml"
selThemeFile = SkinDir + config.plugins.MerlinSkinThemes.Skin.value + "/themes.xml"
selColorTheme = config.plugins.MerlinSkinThemes.ColorTheme.value
selFontTheme = config.plugins.MerlinSkinThemes.FontTheme.value
selBorderSetTheme = config.plugins.MerlinSkinThemes.BorderSetTheme.value
selInfoBar = config.plugins.MerlinSkinThemes.InfoBar.value
selChannelSelection = config.plugins.MerlinSkinThemes.ChannelSelection.value
selMovieSelection = config.plugins.MerlinSkinThemes.MovieSelection.value
selSecondInfoBar = config.plugins.MerlinSkinThemes.SecondInfoBar.value
selMessageBox = config.plugins.MerlinSkinThemes.MessageBox.value
selInputBox = config.plugins.MerlinSkinThemes.InputBox.value
selPreviewScreen = config.plugins.MerlinSkinThemes.PreviewScreen.value

class MerlinPreviewScreen(Screen):
	skin = """
	<screen position="130,150" size="460,150" title="Preview">
		<widget name="myLabel" position="10,60" size="200,40" font="Regular;20" />
	</screen>"""

	if fileExists(selThemeFile):
		curTree = Tree.parse(selThemeFile)
		screenthemes = curTree.find("screenthemes")
		if screenthemes is not None:
			for screens in screenthemes.findall("screens"):
				if screens.get("name") == selPreviewScreen:
					for screentheme in screens.findall("screentheme"):
						if selPreviewScreen == "InfoBar":
							if screentheme.get("name") == selInfoBar:
								screen = screentheme.find("screen")
							
						if selPreviewScreen == "ChannelSelection":
							if screentheme.get("name") == selChannelSelection:
								screen = screentheme.find("screen")
					
						if selPreviewScreen == "MovieSelection":
							if screentheme.get("name") == selMovieSelection:
								screen = screentheme.find("screen")
					
						if selPreviewScreen == "SecondInfoBar":
							if screentheme.get("name") == selSecondInfoBar:
								screen = screentheme.find("screen")
								
					# remove unresolved widget
					foundPicon = False
					piconpos = None
					piconsize = None
					
					if screen is not None:
						for widget in screen.findall("widget"):
							# delete unresolved Elements
							if "source" in widget.attrib:
								# Picon
								if (widget.attrib["source"] == "ServiceEvent" or widget.attrib["source"] == "session.CurrentService") and widget.attrib["render"] == "Picon":
									print "[MSTPV] Picon found"
									foundPicon = True
									piconpos = widget.get("position")
									piconsize = widget.get("size")

								if widget.attrib["source"] in SourceList:
									screen.remove(widget)

							if "name" in widget.attrib:
								if widget.attrib["name"] in NameList:
									screen.remove(widget)
									
						for element in screen.iter():
							if "backgroundColor" in element.attrib:
								colorname = element.get("backgroundColor")
								
								curTree = Tree.parse(selThemeFile)
								root = curTree.getroot()
								if root.find("colortheme") is not None:
									for theme in root.findall("colortheme"):
										if theme.get("name") == selColorTheme:
											SkinColors = theme.find("colors")
											for color in SkinColors.findall("color"):
												if color.get("name") == colorname:
													element.set("backgroundColor", color.get("value"))
									
							if "foregroundColor" in element.attrib:
								colorname = element.get("foregroundColor")
								
								curTree = Tree.parse(selThemeFile)
								root = curTree.getroot()
								if root.find("colortheme") is not None:
									for theme in root.findall("colortheme"):
										if theme.get("name") == selColorTheme:
											SkinColors = theme.find("colors")
											for color in SkinColors.findall("color"):
												if color.get("name") == colorname:
													element.set("foregroundColor", color.get("value"))

							if "borderColor" in element.attrib:
								colorname = element.get("borderColor")
								
								curTree = Tree.parse(selThemeFile)
								root = curTree.getroot()
								if root.find("colortheme") is not None:
									for theme in root.findall("colortheme"):
										if theme.get("name") == selColorTheme:
											SkinColors = theme.find("colors")
											for color in SkinColors.findall("color"):
												if color.get("name") == colorname:
													element.set("borderColor", color.get("value"))

							if "emmColor" in element.attrib:
								colorname = element.get("emmColor")
								
								curTree = Tree.parse(selThemeFile)
								root = curTree.getroot()
								if root.find("colortheme") is not None:
									for theme in root.findall("colortheme"):
										if theme.get("name") == selColorTheme:
											SkinColors = theme.find("colors")
											for color in SkinColors.findall("color"):
												if color.get("name") == colorname:
													element.set("emmColor", color.get("value"))

					curTree = Tree.parse(selThemeFile)
					root = curTree.getroot()
					if root.find("fonttheme") is not None:
						for theme in root.findall("fonttheme"):
							if theme.get("name") == selFontTheme:									
								for c in theme.findall("fonts"):
									for font in c.findall("font"):
										get_attr = font.attrib.get
										filename = get_attr("filename", "<NONAME>")
										name = get_attr("name", "Regular")
										scale = get_attr("scale")
										if scale:
											scale = int(scale)
										else:
											scale = 100
										is_replacement = get_attr("replacement") and True or False
										resolved_font = resolveFilename(SCOPE_FONTS, filename, path_prefix=None)
										if not fileExists(resolved_font):
											skin_path = resolveFilename(SCOPE_CURRENT_SKIN, filename)
											if fileExists(skin_path):
												resolved_font = skin_path
										addFont(resolved_font, name, scale, is_replacement)
											
					if screen is not None:						
						#for widget in screen.findall("widget[@render='Picon']"):
						#	piconpos = widget.get("position")
						#	piconsize = widget.get("size")
						#	#piconzpos = widget.get("zPosition")
						#	# replace
						#	screen.remove(widget)

						#	Tree.SubElement(screen, "widget", {"name": "picon", "pixmap": "/usr/lib/enigma2/python/Plugins/Extensions/MerlinSkinThemes/picon_default.png", "position": piconpos, "size": piconsize, "zPosition": "-1"})
												
						if foundPicon:
							Tree.SubElement(screen, "widget", {"name": "picon", "pixmap": "/usr/lib/enigma2/python/Plugins/Extensions/MerlinSkinThemes/picon_default.png", "position": piconpos, "size": piconsize, "zPosition": "0"})
						
					skin = Tree.tostring(screen)
					
					#print "[MSTPRV] SKIN: " + skin
					
	def __init__(self, session, args=None):
		#print "[MSTPRV] running... SKIN: " + selSkinFile
		self.session = session
		self.currentService = self.session.nav.getCurrentlyPlayingServiceReference()
		Screen.__init__(self, session)
		self["myActionMap"] = ActionMap(["SetupActions"],{
			"ok": self.resettheme,
			"cancel": self.resettheme,
		}, -1)
		self["myLabel"] = Label("DummyScreen")
		self["picon"] = Pixmap()
		
		
	def resettheme(self):
		curTree = Tree.parse(SkinFile)
		for c in curTree.findall("fonts"):
			for font in c.findall("font"):
				get_attr = font.attrib.get
				filename = get_attr("filename", "<NONAME>")
				name = get_attr("name", "Regular")
				scale = get_attr("scale")
				if scale:
					scale = int(scale)
				else:
					scale = 100
				is_replacement = get_attr("replacement") and True or False
				resolved_font = resolveFilename(SCOPE_FONTS, filename, path_prefix=None)
				if not fileExists(resolved_font):
					skin_path = resolveFilename(SCOPE_CURRENT_SKIN, filename)
					if fileExists(skin_path):
						resolved_font = skin_path
				addFont(resolved_font, name, scale, is_replacement)
		self.close()

def main(session,**kwargs):
	session.open(MerlinPreviewScreen)
	
def Plugins(**kwargs):
	return PluginDescriptor(name="MerlinPreviewScreen", description="MerlinPreviewScreen", where = PluginDescriptor.WHERE_PLUGINMENU, icon = "plugin.png", fnc = main)

