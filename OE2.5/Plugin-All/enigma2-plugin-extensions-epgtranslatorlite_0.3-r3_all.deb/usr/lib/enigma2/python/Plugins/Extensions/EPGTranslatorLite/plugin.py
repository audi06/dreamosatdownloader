# -*- coding: utf-8 -*-
#
# EPG Translator Plugin Lite
#
epgtranslatelite_version="0.3-r3"
#
from Components.ActionMap import ActionMap, NumberActionMap
from Components.config import config, configfile, ConfigSubsection, ConfigSelection, ConfigInteger, getConfigListEntry
from Components.ConfigList import ConfigListScreen
from Components.Input import Input
from Components.Label import Label
from Components.Language import language
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from Components.Pixmap import Pixmap, MovingPixmap
from Components.ScrollLabel import ScrollLabel
from Components.Slider import Slider
from enigma import eConsoleAppContainer, eListboxPythonMultiContent, eTimer, eEPGCache, eServiceReference, gFont, loadPic, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_WRAP
from Plugins.Plugin import PluginDescriptor
from re import findall, match, search, split, sub
from Screens.EventView import EventViewBase
from Screens.EpgSelection import EPGSelection
from Screens.InfoBar import InfoBar, MoviePlayer
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.Standby import TryQuitMainloop
from Screens.VirtualKeyBoard import VirtualKeyBoard
from string import find
from Tools.Directories import fileExists
from twisted.web import client, error
from twisted.web.client import getPage, downloadPage
import os
import re
import socket
import sys
import time
import urllib
from os import path

import ssl
try:
    _create_unverified_https_context = ssl._create_unverified_context
except AttributeError:
    # Legacy Python that doesn't verify HTTPS certificates by default
    pass
else:
    # Handle target environment that doesn't support HTTPS verification
    ssl._create_default_https_context = _create_unverified_https_context
from urllib import unquote_plus
from urllib2 import Request, urlopen, URLError, HTTPError
from urlparse import parse_qs
config.plugins.translator = ConfigSubsection()
config.plugins.translator.source = ConfigSelection(default='auto', choices=[('auto', 'Detect Language'),
 ('af', 'Afrikaans'),
 ('sq', 'Albanian'),
 ('ar', 'Arabic'),
 ('az', 'Azerbaijani'),
 ('eu', 'Basque'),
 ('be', 'Belarusian'),
 ('bs', 'Bosnian'),
 ('bg', 'Bulgarian'),
 ('ca', 'Catalan'),
 ('ceb', 'Cebuano'),
 ('hr', 'Croatian'),
 ('cs', 'Czech'),
 ('da', 'Danish'),
 ('nl', 'Dutch'),
 ('en', 'English'),
 ('et', 'Estonian'),
 ('tl', 'Filipino'),
 ('fi', 'Finnish'),
 ('fr', 'French'),
 ('gl', 'Galician'),
 ('de', 'German'),
 ('el', 'Greek'),
 ('ht', 'Haitian Creole'),
 ('hu', 'Hungarian'),
 ('is', 'Icelandic'),
 ('id', 'Indonesian'),
 ('ga', 'Irish'),
 ('it', 'Italian'),
 ('jw', 'Javanese'),
 ('lv', 'Latvian'),
 ('lt', 'Lithuanian'),
 ('mk', 'Macedonian'),
 ('ms', 'Malay'),
 ('mt', 'Maltese'),
 ('no', 'Norwegian'),
 ('fa', 'Persian'),
 ('pl', 'Polish'),
 ('pt', 'Portuguese'),
 ('ro', 'Romanian'),
 ('ru', 'Russian'),
 ('sr', 'Serbian'),
 ('sk', 'Slovak'),
 ('sl', 'Slovenian'),
 ('es', 'Spanish'),
 ('sw', 'Swahili'),
 ('sv', 'Swedish'),
 ('tr', 'Turkish'),
 ('uk', 'Ukrainian'),
 ('ur', 'Urdu'),
 ('vi', 'Vietnamese'),
 ('cy', 'Welsh')])
config.plugins.translator.destination = ConfigSelection(default='en', choices=[('af', 'Afrikaans'),
 ('sq', 'Albanian'),
 ('ar', 'Arabic'),
 ('az', 'Azerbaijani'),
 ('eu', 'Basque'),
 ('be', 'Belarusian'),
 ('bs', 'Bosnian'),
 ('bg', 'Bulgarian'),
 ('ca', 'Catalan'),
 ('ceb', 'Cebuano'),
 ('hr', 'Croatian'),
 ('cs', 'Czech'),
 ('da', 'Danish'),
 ('nl', 'Dutch'),
 ('en', 'English'),
 ('et', 'Estonian'),
 ('tl', 'Filipino'),
 ('fi', 'Finnish'),
 ('fr', 'French'),
 ('gl', 'Galician'),
 ('de', 'German'),
 ('el', 'Greek'),
 ('ht', 'Haitian Creole'),
 ('hu', 'Hungarian'),
 ('is', 'Icelandic'),
 ('id', 'Indonesian'),
 ('ga', 'Irish'),
 ('it', 'Italian'),
 ('jw', 'Javanese'),
 ('lv', 'Latvian'),
 ('lt', 'Lithuanian'),
 ('mk', 'Macedonian'),
 ('ms', 'Malay'),
 ('mt', 'Maltese'),
 ('no', 'Norwegian'),
 ('fa', 'Persian'),
 ('pl', 'Polish'),
 ('pt', 'Portuguese'),
 ('ro', 'Romanian'),
 ('ru', 'Russian'),
 ('sr', 'Serbian'),
 ('sk', 'Slovak'),
 ('sl', 'Slovenian'),
 ('es', 'Spanish'),
 ('sw', 'Swahili'),
 ('sv', 'Swedish'),
 ('tr', 'Turkish'),
 ('uk', 'Ukrainian'),
 ('ur', 'Urdu'),
 ('vi', 'Vietnamese'),
 ('cy', 'Welsh')])
config.plugins.translator.maxevents = ConfigInteger(20, (1, 99))
config.plugins.translator.showsource = ConfigSelection(default='yes', choices=[('yes', 'Yes'), ('no', 'No')])

def applySkinVars(skin, dict):
    for key in dict.keys():
        try:
            skin = skin.replace('{' + key + '}', dict[key])
        except Exception as e:
            print e,
            print '@key=',
            print key

    return skin

def transHTML(text):
    text = text.replace('&nbsp;', ' ').replace('&szlig;', 'ss').replace('&quot;', '"').replace('&ndash;', '-').replace('&Oslash;', '').replace('&bdquo;', '"').replace('&ldquo;', '"').replace('&rsquo;', "'").replace('&gt;', '>').replace('&lt;', '<').replace('&shy;', '').replace('&copy;.*', ' ').replace('&amp;', '&').replace('&eacute;', '\xc3\xa9').replace('&hellip;', '...').replace('&egrave;', '\xc3\xa8').replace('&agrave;', '\xc3\xa0')
    text = text.replace('&#034;', '"').replace('&#039;', "'").replace('&#34;', '"').replace('&#38;', 'und').replace('&#39;', "'").replace('&#133;', '...')
    text = text.replace('\xc3\x83 \xe2\x80\x9e ', '\xc3\x84').replace('\xc3\x83 - ', '\xc3\x96').replace('\xc3\x83 \xc5\x93 ', '\xc3\x9c').replace('\xc3\x83 \xc5\xb8 ', '\xc3\x9f').replace('\xc3\x83 \xc2\xa4 ', '\xc3\xa4').replace('\xc3\x83 \xc2\xb6 ', '\xc3\xb6').replace('\xc3\x83 \xc2\xbc ', '\xc3\xbc')
    text = text.replace('\xc3\x83 \xe2\x80\x9e', '\xc3\x84').replace('\xc3\x83 -', '\xc3\x96').replace('\xc3\x83 \xc5\x93', '\xc3\x9c').replace('\xc3\x83 \xc5\xb8', '\xc3\x9f').replace('\xc3\x83 \xc2\xa4', '\xc3\xa4').replace('\xc3\x83 \xc2\xb6', '\xc3\xb6').replace('\xc3\x83 \xc2\xbc', '\xc3\xbc')
    text = text.replace('\xc3\x83\xe2\x80\x9e', '\xc3\x84').replace('\xc3\x83\xe2\x80\x93', '\xc3\x96').replace('\xc3\x83\xc5\x93', '\xc3\x9c').replace('\xc3\x83\xc5\xb8', '\xc3\x9f').replace('\xc3\x83\xc2\xa4', '\xc3\xa4').replace('\xc3\x83\xc2\xb6', '\xc3\xb6').replace('\xc3\x83\xc2\xbc', '\xc3\xbc').replace('\xc3\x82\xc5\xa0', '\n').replace('\xc3\x82', '\n').replace('\xc3\x83 ', '').replace('AS', '').replace('\xc2\xb6 ', '').replace('\xc2\xb6', '').replace('\xc2\xbc ', '').replace('\xc2\xbc', '').replace('\xc2\xa4 ', '').replace('\xc2\xa4', '')
    return text

class translatorConfig(ConfigListScreen, Screen):
    skin = """  
	<screen position="center,center" size="620,300" title="EPG Translator Lite Setup">
	<ePixmap pixmap="skin_default/buttons/red.png" position="10,5" size="200,40" alphatest="on" />
	<ePixmap pixmap="skin_default/buttons/green.png" position="210,5" size="200,40" alphatest="on" />
	<eLabel text="Cancel" position="10,5" size="200,40" zPosition="5" valign="center" halign="center" backgroundColor="#9f1313" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
	<eLabel text="Save" position="210,5" size="200,40" zPosition="5" valign="center" halign="center" backgroundColor="#1f771f" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
	<eLabel position="10,50" size="600,1" backgroundColor="grey" />
	<widget name="config" position="10,60" size="600,210" enableWrapAround="1" scrollbarMode="showOnDemand" />
	<widget name="flag" position="550,0" size="50,50" alphatest="on" />
    </screen>"""  

    def __init__(self, session):
        Screen.__init__(self, session)
        self['flag'] = Pixmap()
        list = []
        list.append(getConfigListEntry('Source Language:', config.plugins.translator.source))
        list.append(getConfigListEntry('Destination Language:', config.plugins.translator.destination))
        list.append(getConfigListEntry('Maximum EPG Events:', config.plugins.translator.maxevents))
        list.append(getConfigListEntry('Show Source EPG:', config.plugins.translator.showsource))
        ConfigListScreen.__init__(self, list, on_change=self.UpdateComponents)
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions'], {'ok': self.save,
         'cancel': self.cancel,
         'red': self.cancel,
         'green': self.save}, -1)
        self.onLayoutFinish.append(self.UpdateComponents)
        self.onShown.append(self.setWindowTitle)      
                                                                                      
    def setWindowTitle(self):              
        self.setTitle(_("EPG Translator Lite")+" "+_("Setup"))

    def UpdateComponents(self):
        png = '/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslatorLite/flag/' + str(config.plugins.translator.destination.value) + '.png'
        if fileExists(png):
            self['flag'].instance.setPixmapFromFile(png)

    def save(self):
        for x in self['config'].list:
            x[1].save()
            configfile.save()
        self.exit()

    def cancel(self):
        for x in self['config'].list:
            x[1].cancel()
        self.exit()

    def exit(self):
        self.session.openWithCallback(self.close, translatorMain, None)

class translatorMain(Screen):
    skin = """  
    	<screen position="center,80" size="1200,610" title="EPG Translator Lite">
    	<ePixmap pixmap="skin_default/buttons/red.png" position="10,5" size="200,40" alphatest="on" />
	<ePixmap pixmap="skin_default/buttons/green.png" position="220,5" size="200,40" alphatest="on" />
	<ePixmap pixmap="skin_default/buttons/yellow.png" position="430,5" size="200,40" alphatest="on" />
	<ePixmap pixmap="skin_default/buttons/blue.png" position="640,5" size="200,40" alphatest="on" />
	<widget name="now" position="10,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#18188b" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
	<widget name="help" position="220,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#18188b" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
	<widget name="label" position="430,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#18188b" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
	<widget name="configure" position="640,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#18188b" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
        <widget source="global.CurrentTime" render="Label" position="1130,12" size="60,25" font="Regular;22" halign="right" backgroundColor="background" shadowColor="black" shadowOffset="-2,-2" transparent="1">
	<convert type="ClockToText">Default</convert>
	</widget>
	<widget source="global.CurrentTime" render="Label" position="820,12" size="300,25" font="Regular;22" halign="right" backgroundColor="background" shadowColor="black" shadowOffset="-2,-2" transparent="1">
	<convert type="ClockToText">Format:%A %d. %B</convert>
	</widget>
	<eLabel position="10,50" size="1180,1" backgroundColor="grey" />
	<widget name="flag1" position="10,55" size="100,100" alphatest="on" />
	<widget name="text1" position="120,60" size="1070,260" font="Regular;22" />
	<widget name="flag2" position="10,340" size="100,100" alphatest="on" />	    
        <widget name="text2" position="120,345" size="1070,260" font="Regular;22" />
        <widget name="text3" position="120,60" size="1070,540" font="Regular;22" />
    </screen>"""  

    def __init__(self, session, text):
        self.showsource = config.plugins.translator.showsource.value
        self.session = session
        Screen.__init__(self, session)
        self.source = str(config.plugins.translator.source.value)
        self.destination = str(config.plugins.translator.destination.value)
        self.text = text
        self.hideflag = True
        self.refresh = False
        self.max = 1
        self.count = 0
        self.list = []
        self.eventName = ''
        self['flag1'] = Pixmap()
        self['flag2'] = Pixmap()
        self['text1'] = ScrollLabel('')
        self['text2'] = ScrollLabel('')
        self['text3'] = ScrollLabel('')
        self['now'] = Label(_("EPG")+" "+_("Load"))
        self['help'] = Label(_("Help"))
        self['label'] = Label(_("Hide"))
        self['configure'] = Label(_("Setup"))
        self['actions'] = ActionMap(['OkCancelActions',
         'DirectionActions',
         'ChannelSelectBaseActions',
         'ColorActions',
         'MoviePlayerActions',
         'NumberActions',
         'MovieSelectionActions',
         'HelpActions'], {'ok': self.ok,
         'cancel': self.exit,
         'right': self.rightDown,
         'left': self.leftUp,
         'down': self.down,
         'up': self.up,
         '0': self.zero,
         'nextBouquet': self.zapDown,
         'prevBouquet': self.zapUp,
         'red': self.getEPG,
         'green': self.showHelp,
         'yellow': self.hideScreen,
         'blue': self.config,
         'contextMenu': self.config,
         'showEventInfo': self.infoScreen,
         'displayHelp': self.showHelp}, -1)
        self.onLayoutFinish.append(self.onLayoutFinished)

    def onLayoutFinished(self):
        source = '/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslatorLite/flag/' + self.source + '.png'
        destination = '/usr/lib/enigma2/python/Plugins/Extensions/EPGTranslatorLite/flag/' + self.destination + '.png'
        if self.showsource == 'yes':
            if fileExists(source):
                self['flag1'].instance.setPixmapFromFile(source)
            if fileExists(destination):
                self['flag2'].instance.setPixmapFromFile(destination)
        elif fileExists(destination):
            self['flag1'].instance.setPixmapFromFile(destination)
        if self.text is None:
            self.getEPG()
        else:
            self.translateEPG(self.text)

    def ok(self):
        self.session.openWithCallback(self.translateText, VirtualKeyBoard, title='Text Translator:', text='')

    def translateText(self, text):
        if text and text != '':
            self.setTitle('Text Translator')
            if self.showsource == 'yes':
                self['text1'].setText(text)
            text = sub(' ', '%20', text)
            text = sub('&', '%20', text)
            text = sub('#', '', text)
            if len(text) > 2000:
                text = text[0:2000]
	    print "GOOGLE TEXT TRANSLATE:", text
            url = 'http://translate.google.com/m?hl=%s&sl=%s&q=%s' % (self.destination, self.source, text)
            agents = {'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6'}
            before_trans = 'class="t0">'
            request = Request(url, headers=agents)
            try:
                output = urlopen(request, timeout=20).read()
                data = output[(output.find(before_trans) + len(before_trans)):]
                newtext = data.split('<')[0]
                newtext = transHTML(newtext)
                if self.showsource == 'yes':
                    self['text2'].setText(newtext)
                    self['text3'].hide()
                else:
                    self['text3'].setText(newtext)
                    self['text1'].hide()
                    self['text2'].hide()
            except URLError as e:
                error = 'URL Error: ' + str(e.reason)
                if self.showsource == 'yes':
                    self['text2'].setText(error)
                    self['text3'].hide()
                else:
                    self['text3'].setText(error)
                    self['text1'].hide()
                    self['text2'].hide()
            except HTTPError as e:
                error = 'HTTP Error: ' + str(e.code)
                if self.showsource == 'yes':
                    self['text2'].setText(error)
                    self['text3'].hide()
                else:
                    self['text3'].setText(error)
                    self['text1'].hide()
                    self['text2'].hide()
            except socket.error as e:
                error = 'Socket Error: ' + str(e)
                if self.showsource == 'yes':
                    self['text2'].setText(error)
                    self['text3'].hide()
                else:
                    self['text3'].setText(error)
                    self['text1'].hide()
                    self['text2'].hide()

    def translateEPG(self, text):
        if text and text != '':
            self.setTitle('EPG Translator Lite')
	    try:
		channel=self.event[1]
		begin=time.strftime('%Y-%m-%d %H:%M', time.localtime(int(self.event[4])))
	        duration = "%d min" % (int(self.event[5]) / 60)
            except:
		channel = ''
		begin = ''
		duration = ''
            if self.showsource == 'yes':
                if self.refresh == False:
                    self['text1'].setText(channel + '\t' + begin +'\n\n' + text + '\n\n' + duration)
                else:
                    self['text1'].setText(text)
            text = sub('\n\n', ' 7515 ', text)
            text = sub('\n', ' 7514 ', text)
            text = sub(' ', '%20', text)
            text = sub('&', '%20', text)
            text = sub('#', '', text)
            if len(text) > 2000:
                text = text[0:2000]
	    print "GOOGLE EPG TRANSLATE:", text
            url = 'http://translate.google.com/m?hl=%s&sl=%s&q=%s' % (self.destination, self.source, text)
            agents = {'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6'}
            before_trans = 'class="t0">'
            request = Request(url, headers=agents)
            try:
                output = urlopen(request, timeout=20).read()
                data = output[(output.find(before_trans) + len(before_trans)):]
                newtext = data.split('<')[0]
                newtext = sub('7515', '\n\n', newtext)
                newtext = sub('7514', '\n', newtext)
                newtext = sub('\n ', '\n', newtext)
                newtext = transHTML(newtext)
                if self.refresh == False:
                    newtext = channel + '\t' + begin + '\n\n' + newtext + '\n\n' + duration
                    newtext = sub('\n\n\n\n', '\n\n', newtext)
                if self.showsource == 'yes':
                    self['text2'].setText(newtext)
                    self['text3'].hide()
                else:
                    self['text3'].setText(newtext)
                    self['text1'].hide()
                    self['text2'].hide()
            except URLError as e:
                error = 'URL Error: ' + str(e.reason)
                if self.showsource == 'yes':
                    self['text2'].setText(error)
                    self['text3'].hide()
                else:
                    self['text3'].setText(error)
                    self['text1'].hide()
                    self['text2'].hide()
            except HTTPError as e:
                error = 'HTTP Error: ' + str(e.code)
                if self.showsource == 'yes':
                    self['text2'].setText(error)
                    self['text3'].hide()
                else:
                    self['text3'].setText(error)
                    self['text1'].hide()
                    self['text2'].hide()
            except socket.error as e:
                error = 'Socket Error: ' + str(e)
                if self.showsource == 'yes':
                    self['text2'].setText(error)
                    self['text3'].hide()
                else:
                    self['text3'].setText(error)
                    self['text1'].hide()
                    self['text2'].hide()

    def queryEPG(self, list, buildFunc=None):
	if self.epgcache is not None:
		if buildFunc is not None:
			return self.epgcache.lookupEvent(list, buildFunc)
		else:
			return self.epgcache.lookupEvent(list)
	return [ ]

    def getEPG(self):
        self.max = 1
        self.count = 0
        self.list = []
        self.epgcache = eEPGCache.getInstance()
        ref = self.session.nav.getCurrentlyPlayingServiceReference()
        service = self.session.nav.getCurrentService()
        info = service.info()
        curEvent = info.getEvent(0)
        if curEvent:
	    # let us get the full EPG data ...
	    stime=-1
	    self.time_base = int(stime)
	    self.time_epoch=20160 # 14 days
	    test = [ (ref.toString(), 0, self.time_base, self.time_epoch) ]
	    test.insert(0, 'XRnITBDSE')
	    epg_data = self.queryEPG(test)
	    i=0
	    for x in epg_data:
                if i <= int(config.plugins.translator.maxevents.value):          
			self.list.append(x)
			i=i+1
            self.max = len(self.list)
        self.showEPG()

    def showEPG(self):
        try:
            self.event = self.list[self.count]
	    text=self.event[3]
	    short=self.event[6]
	    ext=self.event[7]
            self.refresh = False
        except:
            text = 'Press red button to refresh EPG'
            short = ''
            ext = ''
            self.refresh = True
        if short and short != text:
            text += '\n\n' + short
        if ext:
            if text:
                text += '\n\n'
            text += ext
        self.translateEPG(str(text))

    def leftUp(self):
        self.count -= 1
        if self.count == -1:
            self.count = 0
        self.showEPG()

    def rightDown(self):
        self.count += 1
        if self.count > self.max:
            self.count = self.max
        self.showEPG()

    def zero(self):
        self.count = 0
        self.showEPG()

    def up(self):
        self['text1'].pageUp()
        self['text2'].pageUp()
        self['text3'].pageUp()

    def down(self):
        self['text1'].pageDown()
        self['text2'].pageDown()
        self['text3'].pageDown()

    def zapUp(self):
        if InfoBar and InfoBar.instance:
            InfoBar.zapUp(InfoBar.instance)
            self.getEPG()

    def zapDown(self):
        if InfoBar and InfoBar.instance:
            InfoBar.zapDown(InfoBar.instance)
            self.getEPG()

    def showHelp(self):
        lang = language.getLanguage()[:2]
        if lang == 'de':
            self.session.open(MessageBox, '%s' % 'Translator Plugin:\nLinks <-> Rechts : +- EPG Ereignis\nOk : Text \xc3\xbcbersetzen\nBouquet : +- Zap\nBlau : Einstellungen', MessageBox.TYPE_INFO, close_on_any_key=True)
        else:
            self.session.open(MessageBox, '%s' % 'Inside Plugin:\nLeft <-> Right : <-> +- EPG Event\nOk : translate Text\nBouquet : +- Zap\nBlue : Setup', MessageBox.TYPE_INFO, close_on_any_key=True)

    def config(self):
        self.session.openWithCallback(self.exit, translatorConfig)

    def infoScreen(self):
        self.session.open(MessageBox,_("EPG Translator Lite Version %s\nbased on Plugin from kashmir - Thanks!") % epgtranslatelite_version,MessageBox.TYPE_INFO, close_on_any_key=True)

    def hideScreen(self):
        if self.hideflag == True:
            self.hideflag = False
            count = 40
            while count > 0:
                count -= 1
                f = open('/proc/stb/video/alpha', 'w')
                f.write('%i' % (config.av.osd_alpha.value * count / 40))
                f.close()
        else:
            self.hideflag = True
            count = 0
            while count < 40:
                count += 1
                f = open('/proc/stb/video/alpha', 'w')
                f.write('%i' % (config.av.osd_alpha.value * count / 40))
                f.close()

    def exit(self):
        if self.hideflag == False:
            f = open('/proc/stb/video/alpha', 'w')
            f.write('%i' % config.av.osd_alpha.value)
            f.close()
        self.close()

def main(session, **kwargs):
    session.open(translatorMain, None)

def Plugins(**kwargs):
    return [PluginDescriptor(name='EPG Translator Lite', description='Translate your EPG', where=[PluginDescriptor.WHERE_PLUGINMENU], icon='plugin.png', fnc=main),
     PluginDescriptor(name='EPG Translator Lite', description='Translate your EPG', where=[PluginDescriptor.WHERE_EXTENSIONSMENU], fnc=main),
     PluginDescriptor(name='EPG Translator Lite', description='Translate your EPG', where=[PluginDescriptor.WHERE_EVENTINFO], fnc=main)]
