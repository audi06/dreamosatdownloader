# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/JediMakerXtream/plugin.py
from Components.config import *
from enigma import getDesktop, addFont, eTimer
from Plugins.Plugin import PluginDescriptor
import time
import os
import socket

#lululla
BRAND = '/usr/lib/enigma2/python/boxbranding.so'
BRANDP = '/usr/lib/enigma2/python/Plugins/PLi/__init__.pyo'
BRANDPLI ='/usr/lib/enigma2/python/Tools/StbHardware.pyo'


autoStartTimer = None
screenwidth = getDesktop(0).size()
skin_path = '/usr/lib/enigma2/python/Plugins/Extensions/JediMakerXtream/skin/hd/default/'
if screenwidth.width() > 1280:
    skin_path = '/usr/lib/enigma2/python/Plugins/Extensions/JediMakerXtream/skin/fhd/default/'
if not os.path.exists('/etc/enigma2/jediplaylists/'):
    os.makedirs('/etc/enigma2/jediplaylists/')
config.plugins.JediMakerXtream = ConfigSubsection()
cfg = config.plugins.JediMakerXtream
cfg.extensions = ConfigYesNo(default=False)
cfg.location = ConfigDirectory(default='/etc/enigma2/jediplaylists/')
cfg.m3ulocation = ConfigDirectory(default='/etc/enigma2/jediplaylists/')
cfg.main = ConfigYesNo(default=True)
cfg.unique = ConfigNumber()
cfg.usershow = ConfigSelection(default='domain', choices=[('domain', _('Domain')), ('domainconn', _('Domain | Connections'))])
cfg.enabled = ConfigEnableDisable(default=False)
cfg.wakeup = ConfigClock(default=25740)

def add_skin_font():
    # fontpath = '/usr/share/fonts/' #lululla error
    
    fontpath = '/usr/lib/enigma2/python/Plugins/Extensions/JediMakerXtream/fonts/'   
    
    addFont(fontpath + 'SourceSansPro-Regular.otf', 'jediregular', 100, 1)


def main(session, **kwargs):
    import menu
    session.open(menu.JediMakerXtream_Menu)


def mainmenu(menuid, **kwargs):
    if menuid == 'mainmenu':
        return [(_('Jedi Maker Xtream'),
          main,
          'JediMakerXtream',
          4)]
    else:
        return []


def extensionsmenu(session, **kwargs):
    import playlists
    session.open(playlists.JediMakerXtream_Playlist)


class AutoStartTimer:

    def __init__(self, session):
        self.session = session
        self.timer = eTimer()

        if fileExists(BRAND)or fileExists(BRANDP):
            self.timer.callback.append(self.onTimer) #pli
        else:
            self.timer_conn = self.timer.timeout.connect(self.onTimer) #cvs            
        
        
        # try:
            # self.timer_conn = self.timer.timeout.connect(self.onTimer)
        # except:
            # self.timer.callback.append(self.onTimer)
        self.update()

    def getWakeTime(self):
        if cfg.enabled.value:
            clock = cfg.wakeup.value
            nowt = time.time()
            now = time.localtime(nowt)
            return int(time.mktime((now.tm_year,
             now.tm_mon,
             now.tm_mday,
             clock[0],
             clock[1],
             0,
             now.tm_wday,
             now.tm_yday,
             now.tm_isdst)))
        else:
            return -1

    def update(self, atLeast = 0):
        self.timer.stop()
        wake = self.getWakeTime()
        now = int(time.time())
        if wake > 0:
            if wake < now + atLeast:
                wake += 86400
            next = wake - now
            if next > 3600:
                next = 3600
            if next <= 0:
                next = 60
            self.timer.startLongTimer(next)
        else:
            wake = -1
        return wake

    def onTimer(self):
        self.timer.stop()
        now = int(time.time())
        wake = self.getWakeTime()
        atLeast = 0
        if abs(wake - now) < 60:
            self.runUpdate()
            atLeast = 60
        self.update(atLeast)

    def runUpdate(self):
        print '\n *********** Updating Jedi Bouquets************ \n'
        import update
        self.session.open(update.JediMakerXtream_Update, 'auto')


def autostart(reason, session = None, **kwargs):
    global autoStartTimer
    if reason == 0:
        if session is not None:
            if autoStartTimer is None:
                autoStartTimer = AutoStartTimer(session)
    return


def Plugins(**kwargs):
    add_skin_font()
    iconFile = 'icons/JediMakerXtream.png'
    if screenwidth.width() > 1280:
        iconFile = 'icons/JediMakerXtreamFHD.png'
    description = _('IPTV Bouquets Creator')
    name = _('JediMakerXtream')
    main_menu = PluginDescriptor(name=_('JediMakerXtream'), description=description, where=PluginDescriptor.WHERE_MENU, fnc=mainmenu, needsRestart=True)
    extensions_menu = PluginDescriptor(name=_('JediMakerXtream'), description=description, where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=extensionsmenu, needsRestart=True)
    result = [PluginDescriptor(name=name, description=description, where=[PluginDescriptor.WHERE_AUTOSTART, PluginDescriptor.WHERE_SESSIONSTART], fnc=autostart), PluginDescriptor(name=name, description=description, where=PluginDescriptor.WHERE_PLUGINMENU, icon=iconFile, fnc=main)]
    if cfg.main.getValue():
        result.append(main_menu)
    if cfg.extensions.getValue():
        result.append(extensions_menu)
    return result