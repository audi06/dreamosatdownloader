# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/JediMakerXtream/info.py
from Screens.Screen import Screen
from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.Sources.StaticText import StaticText
import datetime
from plugin import skin_path

class JediMakerXtream_UserInfo(Screen):

    def __init__(self, session, file_info):
        self.session = session
        skin = skin_path + 'jmx_userinfo.xml'
        with open(skin, 'r') as f:
            self.skin = f.read()
        self.setup_title = _('User Information')
        Screen.__init__(self, session)
        self['actions'] = ActionMap(['SetupActions'], {'ok': self.quit,
         'cancel': self.quit,
         'menu': self.quit}, -2)
        self['userinfo'] = Label('')
        self['description'] = Label('')
        self['key_red'] = StaticText(_('Close'))
        self.file_info = file_info
        self.createUserSetup()
        self.onLayoutFinish.append(self.__layoutFinished)

    def __layoutFinished(self):
        self.setTitle(self.setup_title)

    def createUserSetup(self):
        protocol = str(self.file_info['local_info']['protocol'])
        domain = str(self.file_info['server_info']['url'])
        port = str(self.file_info['server_info']['port'])
        username = str(self.file_info['user_info']['username'])
        password = str(self.file_info['user_info']['password'])
        utype = 'm3u_plus'
        if 'ts' in self.file_info['user_info']['allowed_output_formats']:
            output = 'ts'
        elif 'm3u8' in self.file_info['user_info']['allowed_output_formats']:
            output = 'ts'
        else:
            output = str(self.file_info['user_info']['allowed_output_formats'][0])
        self.urltext = str(protocol) + str(domain) + ':' + str(port) + '/get.php?username=' + str(username) + '&password=' + str(password) + '&type=' + str(utype) + '&output=' + str(output)
        self['description'].setText(self.urltext)
        self.usertext = ''
        for entry in self.file_info['user_info']:
            if entry != 'message':
                if entry == 'allowed_output_formats':
                    formatslist = []
                    for formats in self.file_info['user_info'][entry]:
                        formatslist.append(formats.encode('ascii'))

                    self.usertext += str(entry) + ':\t' + str(formatslist) + '\n'
                elif entry == 'exp_date' or entry == 'created_at':
                    if self.file_info['user_info'][entry]:
                        self.usertext += str(entry) + ':\t\t' + str(datetime.datetime.fromtimestamp(int(self.file_info['user_info'][entry])).strftime('%d-%m-%Y  %H:%M:%S')) + '\n'
                    else:
                        self.usertext += str(entry) + ':\t\t' + str(self.file_info['user_info'][entry]) + '\n'
                else:
                    self.usertext += str(entry) + ':\t\t' + str(self.file_info['user_info'][entry]) + '\n'

        self['userinfo'].setText(self.usertext)
        self.usertext += '\n'
        for entry in self.file_info['server_info']:
            self.usertext += str(entry) + ':\t\t' + str(self.file_info['server_info'][entry]) + '\n'

        self['userinfo'].setText(self.usertext)

    def quit(self):
        self.close()