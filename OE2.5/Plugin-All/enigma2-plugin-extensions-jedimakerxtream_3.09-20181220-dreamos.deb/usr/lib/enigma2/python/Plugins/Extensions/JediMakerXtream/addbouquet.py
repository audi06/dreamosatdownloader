# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/JediMakerXtream/addbouquet.py
from collections import OrderedDict
from Components.ActionMap import ActionMap, NumberActionMap
from Components.config import *
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from Components.MenuList import MenuList
from enigma import eDVBDB, eTimer
from plugin import skin_path, cfg
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.VirtualKeyBoard import VirtualKeyBoard
from xml.dom import minidom
from xml.dom.minidom import parse, parseString
import xml.etree.cElementTree as ET
import re
import json
import urllib2
import os
from datetime import datetime
import socket
from Components.ProgressBar import ProgressBar
from Components.SelectionList import SelectionList, SelectionEntryComponent
from twisted.web.client import downloadPage

#lululla
BRAND = '/usr/lib/enigma2/python/boxbranding.so'
BRANDP = '/usr/lib/enigma2/python/Plugins/PLi/__init__.pyo'
BRANDPLI ='/usr/lib/enigma2/python/Tools/StbHardware.pyo'

class mem():
    pass


try:
    import lzma
    print 'lzma success'
    mem.haslzma = True
except ImportError:
    try:
        from backports import lzma
        print 'backports lzma success'
        mem.haslzma = True
    except ImportError:
        mem.haslzma = False
        print 'lzma failed'

class JediMakerXtream_Bouquets(ConfigListScreen, Screen):

    def __init__(self, session, file_info):
        self.session = session
        skin = skin_path + 'jmx_settings.xml'
        with open(skin, 'r') as f:
            self.skin = f.read()
        self.setup_title = _('Bouquets Settings')
        Screen.__init__(self, session)
        self['setupActions'] = ActionMap(['SetupActions'], {'save': self.save,
         'cancel': self.cancel}, -1)
        self['VirtualKB'] = NumberActionMap(['VirtualKeyboardActions'], {'showVirtualKeyboard': self.KeyText}, -2)
        self['VirtualKB'].setEnabled(False)
        self['key_red'] = StaticText(_('Cancel'))
        self['key_green'] = StaticText(_('OK'))
        self['description'] = Label('')
        self['VirtualKB'].setEnabled(False)
        self['HelpWindow'] = Pixmap()
        self['VKeyIcon'] = Pixmap()
        self['HelpWindow'].hide()
        self['VKeyIcon'].hide()
        mem.currentPlaylist = []
        mem.currentPlaylist = file_info
        mem.address = mem.currentPlaylist['local_info']['address']
        mem.alias = ''
        mem.live_type = '1'
        mem.vod_type = '4097'
        mem.xmltv = ''
        if mem.currentPlaylist['local_info']['playlisttype'] != 'local':
            mem.protocol = mem.currentPlaylist['local_info']['protocol']
        if mem.currentPlaylist['local_info']['playlisttype'] == 'xtream':
            mem.domain = mem.currentPlaylist['local_info']['domain']
            mem.port = str(mem.currentPlaylist['local_info']['port'])
            mem.username = mem.currentPlaylist['local_info']['username']
            mem.password = mem.currentPlaylist['local_info']['password']
            mem.output = mem.currentPlaylist['local_info']['output']
            mem.host = str(mem.protocol) + str(mem.domain) + ':' + str(mem.port) + '/'
            mem.player_api = str(mem.host) + 'player_api.php?username=' + str(mem.username) + '&password=' + str(mem.password)
            mem.panel_api = str(mem.host) + 'panel_api.php?username=' + str(mem.username) + '&password=' + str(mem.password)
            mem.get_api = str(mem.host) + 'get.php?username=' + str(mem.username) + '&password=' + str(mem.password) + '&type=m3u_plus'
            mem.LiveCategoriesUrl = mem.player_api + '&action=get_live_categories'
            mem.LiveStreamsUrl = mem.player_api + '&action=get_live_streams'
            mem.VodCategoriesUrl = mem.player_api + '&action=get_vod_categories'
            mem.VodStreamsUrl = mem.player_api + '&action=get_vod_streams'
            mem.SeriesCategoriesUrl = mem.player_api + '&action=get_series_categories'
            mem.SeriesUrl = mem.player_api + '&action=get_series'
            mem.alias = mem.domain
            mem.xmltv = str(mem.protocol) + str(mem.domain) + ':' + str(mem.port) + '/' + 'xmltv.php?username=' + str(mem.username) + '&password=' + str(mem.password)
        else:
            mem.alias = mem.address
            mem.domain = mem.currentPlaylist['local_info']['domain']
            mem.live_type = '1'
            mem.vod_type = '4097'
        mem.hdr = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
         'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'}
        self.bouquetfile = '/etc/enigma2/jediplaylists/bouquet_info_v2.json'
        self.onChangedEntry = []
        self.list = []
        ConfigListScreen.__init__(self, self.list, session=self.session, on_change=self.changedEntry)
        mem.live = True
        mem.vod = False
        mem.series = False
        mem.haslive = False
        mem.hasvod = False
        mem.hasseries = False
        mem.categories = []
        if mem.currentPlaylist['local_info']['playlisttype'] == 'xtream':
            self.downloadcategories()
        self.readbouquetfile()
        self.createConfig()
        self.createSetup()
        self.onLayoutFinish.append(self.__layoutFinished)

    def __layoutFinished(self):
        self.setTitle(self.setup_title)

    def downloadpanel(self):
        response = ''
        req = urllib2.Request(mem.panel_api)
        try:
            response = urllib2.urlopen(req)
            mem.panel = json.load(response)
        except urllib2.URLError as e:
            print e
        except socket.timeout as e:
            print e

        if mem.panel:
            if 'categories' in mem.panel:
                if 'live' in mem.panel['categories']:
                    mem.haslive = True
                if 'movie' in mem.panel['categories']:
                    mem.hasvod = True
                if 'series' in mem.panel['categories']:
                    mem.hasseries = True

    def downloadcategories(self):
        mem.livecategories = []
        mem.vodcategories = []
        mem.seriescategories = []
        req = urllib2.Request(mem.LiveCategoriesUrl, headers=mem.hdr)
        try:
            response1 = urllib2.urlopen(req)
            mem.livecategories = json.load(response1, object_pairs_hook=OrderedDict)
        except urllib2.URLError as e:
            pass
        except socket.timeout as e:
            print e

        if response1:
            mem.haslive = True
        req = urllib2.Request(mem.VodCategoriesUrl, headers=mem.hdr)
        try:
            response2 = urllib2.urlopen(req)
            mem.vodcategories = json.load(response2, object_pairs_hook=OrderedDict)
        except urllib2.URLError as e:
            pass
        except socket.timeout as e:
            print e

        if response2:
            mem.hasvod = True
        req = urllib2.Request(mem.SeriesCategoriesUrl, headers=mem.hdr)
        try:
            response3 = urllib2.urlopen(req)
            mem.seriescategories = json.load(response3, object_pairs_hook=OrderedDict)
        except urllib2.URLError as e:
            print e
        except socket.timeout as e:
            print e

        if response3:
            mem.hasseries = True

    def readbouquetfile(self):
        mem.bouquets_exists = False
        mem.bouquetdata = []
        if os.path.isfile(self.bouquetfile):
            if os.stat(self.bouquetfile).st_size > 0:
                with open(self.bouquetfile) as f:
                    mem.bouquetdata = json.load(f, object_pairs_hook=OrderedDict)
                bouquetinfo = []
                for b in range(len(mem.bouquetdata)):
                    if mem.currentPlaylist['local_info']['address'] == mem.bouquetdata[b]['address']:
                        mem.alias = mem.bouquetdata[b]['bouquet_name']
                        mem.live = mem.bouquetdata[b]['live']
                        if mem.live == 'true':
                            mem.live = True
                        else:
                            mem.live = False
                        mem.vod = mem.bouquetdata[b]['vod']
                        if mem.vod == 'true':
                            mem.vod = True
                        else:
                            mem.vod = False
                        mem.series = mem.bouquetdata[b]['series']
                        if mem.series == 'true':
                            mem.series = True
                        else:
                            mem.series = False
                        mem.live_type = mem.bouquetdata[b]['live_type']
                        mem.vod_type = mem.bouquetdata[b]['vod_type']
                        mem.xmltv = mem.bouquetdata[b]['xmltv']
                        mem.currentbouquet = b
                        mem.bouquets_exists = True
                        break

    def createConfig(self):
        mem.bouquetNameCfg = NoSave(ConfigText(default=mem.alias, fixed_size=False))
        mem.bouquetLiveCategoriesCfg = NoSave(ConfigYesNo(default=mem.live))
        mem.bouquetVodCategoriesCfg = NoSave(ConfigYesNo(default=mem.vod))
        mem.bouquetSeriesCategoriesCfg = NoSave(ConfigYesNo(default=mem.series))
        mem.bouquetXmltvCfg = NoSave(ConfigText(default=mem.xmltv, fixed_size=False))
        if os.path.isdir('/usr/lib/enigma2/python/Plugins/SystemPlugins/ServiceApp'):
            mem.bouquetLiveTypeCfg = NoSave(ConfigSelection(default=mem.live_type, choices=[('1', _('DVB(1)')),
             ('4097', _('IPTV(4097)')),
             ('5001', _('GStreamer(5001)')),
             ('5002', 'ExtPlayer(5002)')]))
            mem.bouquetVodTypeCfg = NoSave(ConfigSelection(default=mem.vod_type, choices=[('1', _('DVB(1)')),
             ('4097', _('IPTV(4097)')),
             ('5001', _('GStreamer(5001)')),
             ('5002', 'ExtPlayer(5002)')]))
        else:
            mem.bouquetLiveTypeCfg = NoSave(ConfigSelection(default=mem.live_type, choices=[('1', _('DVB(1)')), ('4097', _('IPTV(4097)'))]))
            mem.bouquetVodTypeCfg = NoSave(ConfigSelection(default=mem.vod_type, choices=[('1', _('DVB(1)')), ('4097', _('IPTV(4097)'))]))

    def createSetup(self):
        self.list = []
        self.list.append(getConfigListEntry(_('Bouquet name (Alias)'), mem.bouquetNameCfg, _('\nEnter bouquet prefix name')))
        if mem.currentPlaylist['local_info']['playlisttype'] == 'xtream':
            if mem.haslive:
                self.list.append(getConfigListEntry(_('Live categories'), mem.bouquetLiveCategoriesCfg, _('\nInclude LIVE categories in your bouquets.')))
            if mem.hasvod:
                self.list.append(getConfigListEntry(_('VOD categories'), mem.bouquetVodCategoriesCfg, _('\nInclude VOD categories in your bouquets.')))
            if mem.hasseries:
                self.list.append(getConfigListEntry(_('Series categories'), mem.bouquetSeriesCategoriesCfg, _('\nInclude SERIES categories in your bouquets. \n** Note: Selecting Series can be slow to populate the lists.**')))
            if mem.bouquetLiveCategoriesCfg.value == True:
                self.list.append(getConfigListEntry(_('Stream type for Live'), mem.bouquetLiveTypeCfg, _('\nThis setting allows you to choose which player E2 will use for your live streams.\nIf your live streams do not play try changing this setting.')))
            if mem.bouquetVodCategoriesCfg.value == True or mem.bouquetSeriesCategoriesCfg.value == True:
                self.list.append(getConfigListEntry(_('Stream type for VOD/SERIES'), mem.bouquetVodTypeCfg, _('\nThis setting allows you to choose which player E2 will use for your VOD/Series streams.\nIf your VOD streams do not play try changing this setting.')))
            if mem.bouquetLiveCategoriesCfg.value == True:
                self.list.append(getConfigListEntry(_('EPG url'), mem.bouquetXmltvCfg, _('Enter the EPG url for your playlist. If unknown leave blank')))
        else:
            self.list.append(getConfigListEntry(_('Live Categories'), mem.bouquetLiveCategoriesCfg, _('\nInclude LIVE categories in your bouquets if available.')))
            self.list.append(getConfigListEntry(_('Vod Categories'), mem.bouquetVodCategoriesCfg, _('\nInclude VOD categories in your bouquets if available.')))
            self.list.append(getConfigListEntry(_('Series categories'), mem.bouquetSeriesCategoriesCfg, _('\nInclude SERIES categories in your bouquets. \n** Note: Selecting Series can be slow to populate the lists.**')))
            if mem.bouquetLiveCategoriesCfg.value == True:
                self.list.append(getConfigListEntry(_('Stream type for Live'), mem.bouquetLiveTypeCfg, _('\nThis setting allows you to choose which player E2 will use for your live streams.')))
            if mem.bouquetVodCategoriesCfg.value == True or mem.bouquetSeriesCategoriesCfg.value == True:
                self.list.append(getConfigListEntry(_('Stream type for VOD/SERIES'), mem.bouquetVodTypeCfg, _('\nThis setting allows you to choose which player E2 will use for your VOD/Series streams.')))
            if mem.bouquetLiveCategoriesCfg.value == True:
                self.list.append(getConfigListEntry(_('EPG url'), mem.bouquetXmltvCfg, _('Enter the EPG url for your playlist. If unknown leave as default.')))
        self['config'].list = self.list
        self['config'].l.setList(self.list)
        self.handleInputHelpers()

    def handleInputHelpers(self):
        if self['config'].getCurrent() is not None:
            if isinstance(self['config'].getCurrent()[1], ConfigText) or isinstance(self['config'].getCurrent()[1], ConfigPassword):
                if 'VKeyIcon' in self:
                    self['VirtualKB'].setEnabled(True)
                    self['VKeyIcon'].show()
            elif 'VKeyIcon' in self:
                self['VirtualKB'].setEnabled(False)
                self['VKeyIcon'].hide()
        elif 'VKeyIcon' in self:
            self['VirtualKB'].setEnabled(False)
            self['VKeyIcon'].hide()
        return

    def KeyText(self):
        self.currentConfigIndex = self['config'].getCurrentIndex()
        self['HelpWindow'].hide()
        self.session.openWithCallback(self.VirtualKeyBoardCallback, VirtualKeyBoard, title=self['config'].getCurrent()[0], text=self['config'].getCurrent()[1].value)

    def VirtualKeyBoardCallback(self, callback = None):
        if callback is not None and len(callback):
            self['config'].instance.moveSelectionTo(self.currentConfigIndex)
            self['config'].setCurrentIndex(self.currentConfigIndex)
            self['config'].getCurrent()[1].setValue(callback)
            self['config'].invalidate(self['config'].getCurrent())
        return

    def save(self):
        if self['config'].isChanged():
            for x in self['config'].list:
                x[1].save()

        self['config'].instance.moveSelectionTo(1)
        self.session.openWithCallback(self.cancel, JediMakerXtream_ChooseBouquets)

    def cancel(self):
        self.close()
        # return

    def changedEntry(self):
        self.item = self['config'].getCurrent()
        for x in self.onChangedEntry:
            x()

        try:
            if isinstance(self['config'].getCurrent()[1], ConfigYesNo):
                self.createSetup()
        except:
            pass


class JediMakerXtream_ChooseBouquets(Screen):

    def __init__(self, session):
        self.session = session
        skin = skin_path + 'jmx_bouquets.xml'
        with open(skin, 'r') as f:
            self.skin = f.read()
        self.setup_title = _('Choose Bouquets')
        Screen.__init__(self, session)
        cat_list = ''
        self.currentSelection = 0
        self['key_red'] = StaticText('')
        self['key_green'] = StaticText('')
        self['key_yellow'] = StaticText('')
        self['key_blue'] = StaticText('')
        self['key_info'] = StaticText('')
        self['description'] = Label('')
        if mem.currentPlaylist['local_info']['playlisttype'] == 'xtream':
            mem.live = mem.bouquetLiveCategoriesCfg.getValue()
            mem.vod = mem.bouquetVodCategoriesCfg.getValue()
            mem.series = mem.bouquetSeriesCategoriesCfg.getValue()
            self.downloadstreams()
            self.checkcategories()
            self.SelectedCategories()
            self.cat_list = [ SelectionEntryComponent(x[0], x[1], x[2], x[3]) for x in mem.categories ]
            self['list'] = SelectionList(self.cat_list, enableWrapAround=True)
            self['setupActions'] = ActionMap(['ColorActions', 'SetupActions', 'ChannelSelectEPGActions'], {'red': self.keyCancel,
             'green': self.keyGreen,
              'blue': self.clearAll,
             'save': self.keyGreen,
             'cancel': self.keyCancel,
             'ok': self['list'].toggleSelection,
             'info': self.viewChannels,
             'showEPGList': self.viewChannels}, -2)
            self['key_red'] = StaticText(_('Cancel'))
            self['key_green'] = StaticText(_('Create'))
            self['key_yellow'] = StaticText(_('Toggle All'))
            self['key_blue'] = StaticText(_('Clear All'))
            self['key_info'] = StaticText(_('Show Channels'))
            self['description'] = Label(_('Select the playlist categories you wish to create bouquets for. \nPress OK to toggle the selection. \nPress INFO to show the channels in this category.'))
            self['list'].onSelectionChanged.append(self.getCurrentEntry)
        else:
            self.onFirstExecBegin.append(self.m3uStart)
        self.onLayoutFinish.append(self.__layoutFinished)

    def getCurrentEntry(self):
        self.currentSelection = self['list'].getSelectionIndex()

    def viewChannels(self):
        self.session.open(JediMakerXtream_ViewChannels, self.cat_list[self.currentSelection][0])

    def m3uStart(self):
        self.getM3uCategories()
        self.session.open(JediMakerXtream_BuildBouquets, self.getm3ustreams)
        # self.close()
        return

    def __layoutFinished(self):
        self.setTitle(self.setup_title)

    def clearAll(self):
        for idx, item in enumerate(self.cat_list):
            item = self.cat_list[idx][0]
            self.cat_list[idx] = SelectionEntryComponent(item[0], item[1], item[2], 0)
            self['list'].setList(self.cat_list)

    def keyCancel(self):
        self.close()

    def keyGreen(self):
        for selected in self['list'].getSelectionsList():
            if selected[1] == 'Live':
                mem.live = True
                continue
            if selected[1] == 'VOD':
                mem.vod = True
                continue
            if selected[1] == 'Series':
                mem.series = True
                continue
            if mem.live and mem.vod and mem.series:
                break
                
        self.session.open(JediMakerXtream_BuildBouquets, self['list'].getSelectionsList())
        self.close()
        
    def downloadstreams(self):
        mem.livestreams = []
        mem.vodstreams = []
        mem.seriesstreams = []
        if mem.live:
            req = urllib2.Request(mem.LiveStreamsUrl, headers=mem.hdr)
            try:
                response = urllib2.urlopen(req)
                mem.livestreams = json.load(response, object_pairs_hook=OrderedDict)
            except urllib2.URLError as e:
                print e
            except socket.timeout as e:
                print e

        if mem.vod:
            req = urllib2.Request(mem.VodStreamsUrl, headers=mem.hdr)
            try:
                response = urllib2.urlopen(req)
                mem.vodstreams = json.load(response, object_pairs_hook=OrderedDict)
            except urllib2.URLError as e:
                print e
            except socket.timeout as e:
                print e

        if mem.series:
            req = urllib2.Request(mem.SeriesUrl, headers=mem.hdr)
            try:
                response = urllib2.urlopen(req)
                mem.seriesstreams = json.load(response, object_pairs_hook=OrderedDict)
            except urllib2.URLError as e:
                print e
            except socket.timeout as e:
                print e

    def checkcategories(self):
        if mem.live and mem.livecategories and mem.livestreams and isinstance(mem.livecategories, list) and isinstance(mem.livestreams, list):
            for c in range(len(mem.livecategories)):
                for s in range(len(mem.livestreams)):
                    if 'category_id' in mem.livecategories[c] and 'category_id' in mem.livestreams[s]:
                        if mem.livecategories[c]['category_id'] == mem.livestreams[s]['category_id']:
                            categoryValues = [str(mem.livecategories[c]['category_name']),
                             'Live',
                             int(mem.livecategories[c]['category_id']),
                             False]
                            mem.categories.append(categoryValues)
                            break

        if mem.vod and mem.vodcategories and mem.vodstreams and isinstance(mem.vodcategories, list) and isinstance(mem.vodstreams, list):
            for c in range(len(mem.vodcategories)):
                for s in range(len(mem.vodstreams)):
                    if 'category_id' in mem.vodcategories[c] and 'category_id' in mem.vodstreams[s]:
                        if mem.vodcategories[c]['category_id'] == mem.vodstreams[s]['category_id']:
                            categoryValues = [str(mem.vodcategories[c]['category_name']),
                             'VOD',
                             int(mem.vodcategories[c]['category_id']),
                             False]
                            mem.categories.append(categoryValues)
                            break

        if mem.series and mem.seriescategories and mem.seriesstreams and isinstance(mem.seriescategories, list) and isinstance(mem.seriesstreams, list):
            for c in range(len(mem.seriescategories)):
                for s in range(len(mem.seriesstreams)):
                    if 'category_id' in mem.seriescategories[c] and 'category_id' in mem.seriesstreams[s]:
                        if mem.seriescategories[c]['category_id'] == mem.seriesstreams[s]['category_id']:
                            categoryValues = [str(mem.seriescategories[c]['category_name']),
                             'Series',
                             int(mem.seriescategories[c]['category_id']),
                             False]
                            mem.categories.append(categoryValues)
                            break

    def SelectedCategories(self):
        if mem.bouquets_exists:
            live_bouquet_categories = []
            vod_bouquet_categories = []
            series_bouquet_categories = []
            live_bouquet_categories = mem.bouquetdata[mem.currentbouquet]['live_categories']
            vod_bouquet_categories = mem.bouquetdata[mem.currentbouquet]['vod_categories']
            series_bouquet_categories = mem.bouquetdata[mem.currentbouquet]['series_categories']
            for x in mem.categories:
                if mem.live:
                    for name in live_bouquet_categories:
                        if x[0] == name and x[1] == 'Live':
                            x[3] = True
                            break

                if mem.vod:
                    for name in vod_bouquet_categories:
                        if x[0] == name and x[1] == 'VOD':
                            x[3] = True
                            break

                if mem.series:
                    for name in series_bouquet_categories:
                        if x[0] == name and x[1] == 'Series':
                            x[3] = True
                            break

    def getM3uCategories(self):
        lines = []
        mem.live = mem.bouquetLiveCategoriesCfg.getValue()
        mem.vod = mem.bouquetVodCategoriesCfg.getValue()
        mem.series = False
        myfile = []
        if mem.currentPlaylist['local_info']['playlisttype'] == 'external':
            req = urllib2.Request(mem.currentPlaylist['local_info']['address'], headers=mem.hdr)
            try:
                response = urllib2.urlopen(req, timeout=3)
                myfile = response.read()
                lines = myfile.splitlines(True)
            except urllib2.URLError as e:
                print e
            except socket.timeout as e:
                print e

        elif mem.currentPlaylist['local_info']['playlisttype'] == 'local':
            with open(cfg.m3ulocation.value + mem.currentPlaylist['local_info']['address']) as f:
                lines = f.readlines()
        prevline = ''
        channelnum = 0
        self.getm3ustreams = []
        for line in lines:
            self.group_title = ''
            self.epg_name = ''
            self.name = ''
            self.source = ''
            if prevline != '':
                if prevline.upper().startswith('#EXTINF') and line.startswith('http'):
                    if re.search('(?<=group-title=")[^"]+', prevline) is not None:
                        self.group_title = re.search('(?<=group-title=")[^"]+', prevline).group()
                    if re.search('(?<=tvg-id=")[^"]+', prevline) is not None:
                        self.epg_name = re.search('(?<=tvg-id=")[^"]+', prevline).group()
                    if re.search('((?<=",).*$|(?<=1,).*$)', prevline) is not None:
                        self.name = re.search('((?<=",).*$|(?<=1,).*$)', prevline).group().strip()
                    if self.name == '':
                        channelnum += 1
                        self.name = 'Channel ' + str(channelnum)
                    self.source = line.rstrip()
                    if mem.live:
                        if '.ts' in self.source or '.m3u8' in self.source:
                            if self.group_title == '':
                                self.group_title = 'Uncategorised Live'
                            self.getm3ustreams.append([self.group_title,
                             self.epg_name,
                             self.name,
                             self.source,
                             'live'])
                    if mem.vod:
                        if '.ts' not in self.source and '.m3u8' not in self.source:
                            if self.group_title == '':
                                self.group_title = 'Uncategorised VOD'
                            self.getm3ustreams.append([self.group_title,
                             self.epg_name,
                             self.name,
                             self.source,
                             'vod'])
            prevline = line

        return


class JediMakerXtream_BuildBouquets(Screen):

    def __init__(self, session, getSelectionsList):
        Screen.__init__(self, session)
        self.session = session
        skin = skin_path + 'jmx_progress.xml'
        with open(skin, 'r') as f:
            self.skin = f.read()
        Screen.setTitle(self, _('Building Bouquets'))
        self.selectedCategories = getSelectionsList
        self.getm3ustreams = getSelectionsList
        self.bouquetfile = '/etc/enigma2/jediplaylists/bouquet_info_v2.json'
        self['action'] = Label(_('Building Bouquets...'))
        self['status'] = Label('')
        self['progress'] = ProgressBar()
        self['actions'] = ActionMap(['SetupActions'], {'cancel': self.keyCancel}, -2)
        self.timerlength = 100
        self.index = 0
        self.job_current = 0
        self.job_type = ''
        self.job_category_name = ''
        if mem.currentPlaylist['local_info']['playlisttype'] == 'xtream':
            self.job_total = len(self.selectedCategories)
        else:
            self.job_total = len(self.getm3ustreams)
        self.machine = socket.gethostname()
        self.firstrun = True
        self.x = 0
        self.downloadrytec()
        self.onFirstExecBegin.append(self.start)

    def showError(self, message):
        question = self.session.open(MessageBox, message, MessageBox.TYPE_ERROR)
        question.setTitle(_('Create Bouquets'))
        self.close()

    def keyCancel(self):
        self.close()

    def downloadgetfile(self):
        download = True
        req = urllib2.Request(mem.get_api)
        try:
            response = urllib2.urlopen(req)
            download = True
        except urllib2.URLError as e:
            print e
            download = False
        except socket.timeout as e:
            print e
            download = False

        channelnum = 0
        mem.m3uValues = {}
        if download:
            for line in response:
                series_group_title = ''
                series_name = ''
                series_container_extension = ''
                series_url = ''
                if not line.startswith('#EXTINF') and not line.startswith('http'):
                    continue
                if line.startswith('#EXTINF'):
                    if re.search('(?<=group-title=")[^"]+', line) is not None:
                        series_group_title = re.search('(?<=group-title=")[^"]+', line).group()
                    if re.search('((?<=",).*$|(?<=1,).*$)', line) is not None:
                        series_name = re.search('((?<=",).*$|(?<=1,).*$)', line).group().strip()
                    if series_name == '':
                        channelnum += 1
                        series_name = 'Channel ' + str(channelnum)
                    if series_group_title == '':
                        series_group_title = 'Uncategorised'
                    nextline = response.next()
                    if nextline.startswith('http'):
                        series_url = nextline.strip()
                if series_url != '' and '/series/' in series_url:
                    if series_group_title not in mem.m3uValues:
                        mem.m3uValues[series_group_title] = [{'name': series_name,
                          'url': series_url}]
                    else:
                        mem.m3uValues[series_group_title].append({'name': series_name,
                         'url': series_url})
                         
                         
            
        self.timer1 = eTimer()
        self.timer1.start(self.timerlength, 1)
        self.progresscurrent += 1
        self['progress'].setValue(self.progresscurrent)
        
        if fileExists(BRAND)or fileExists(BRANDP):
            self.timer1.callback.append(self.deleteBouquets) #pli
        else:
            self.timer1_conn = self.timer1.timeout.connect(self.deleteBouquets) #cvs
        
        # try:
            # self.timer1_conn = self.timer1.timeout.connect(self.deleteBouquets)
        # except:
            # self.timer1.callback.append(self.deleteBouquets)
        # return

    def downloadrytec(self):
        rytecfile = '/etc/enigma2/jediplaylists/rytec.channels.xml.xz'
        downloadPage('http://www.xmltvepg.nl/rytec.channels.xml.xz', rytecfile)
        self.epgnames2 = []
        if os.path.isfile(rytecfile):
            if os.stat(rytecfile).st_size > 0:
                if mem.haslzma:
                    with lzma.open(rytecfile, 'rb') as fd:
                        with open('/etc/enigma2/jediplaylists/28.2e.txt', 'w') as outfile:
                            for line in fd:
                                if '28.2E' in line:
                                    outfile.write(line)

                with open('/etc/enigma2/jediplaylists/28.2e.txt', 'r') as outfile:
                    self.rytecchannels = outfile.readlines()
                if os.path.isfile('/etc/enigma2/jediplaylists/alias.txt'):
                    if os.stat('/etc/enigma2/jediplaylists/alias.txt').st_size > 0:
                        with open('/etc/enigma2/jediplaylists/alias.txt') as f:
                            self.epgnames2 = json.load(f)

    def start(self):
        if mem.currentPlaylist['local_info']['playlisttype'] == 'xtream':
            if len(self.selectedCategories) > 0:
                self['action'].setText(_('Starting...'))
                if mem.series:
                    self.progresscount = int(len(self.selectedCategories) + 5)
                else:
                    self.progresscount = int(len(self.selectedCategories) + 4)
                self.progresscurrent = 0
                self['progress'].setRange((0, self.progresscount))
                self['progress'].setValue(self.progresscurrent)
                self.timer = eTimer()
                if mem.series:
                    self['action'].setText(_('Downloading Series Data...'))

                    
                    if fileExists(BRAND)or fileExists(BRANDP):
                        self.timer.callback.append(self.downloadgetfile) #pli
                    else:
                        self.timer_conn = self.timer.timeout.connect(self.downloadgetfile) #cvs
            
                    # try:
                        # self.timer_conn = self.timer.timeout.connect(self.downloadgetfile)
                    # except:
                        # self.timer.callback.append(self.downloadgetfile)
                        #added
                    self.timer.start(1000, 1)   

                    
                else:
                    self['action'].setText(_('Deleting Existing Bouquets...'))

                    if fileExists(BRAND)or fileExists(BRANDP):
                        self.timer.callback.append(self.deleteBouquets) #pli
                    else:
                        self.timer_conn = self.timer.timeout.connect(self.deleteBouquets) #cvs

                    # try:
                        # self.timer_conn = self.timer.timeout.connect(self.deleteBouquets)
                    # except:
                        # self.timer.callback.append(self.deleteBouquets)
                        
                        
                    self.timer.start(1000, 1)
            else:
                self.showError(_('No categories selected.'))
        elif len(self.getm3ustreams) > 0:
            self['action'].setText(_('Starting...'))
            self.progresscount = 5
            self.progresscurrent = 0
            self['progress'].setRange((0, self.progresscount))
            self['progress'].setValue(self.progresscurrent)
            self.timer = eTimer()

            if fileExists(BRAND)or fileExists(BRANDP):
                self.timer.callback.append(self.deleteBouquets) #pli
            else:
                self.timer_conn = self.timer.timeout.connect(self.deleteBouquets) #cvs            
            
            
            # try:
                # self.timer_conn = self.timer.timeout.connect(self.deleteBouquets)
            # except:
                # self.timer.callback.append(self.deleteBouquets)
            self.timer.start(1000, 1)
        else:
            self.showError(_('No valid M3U streams in file.'))

    def done(self, answer = None):
        self.close()

    def deleteBouquets(self):
        bouquet_name = mem.bouquetNameCfg.value
        cleanName = re.sub('[^a-zA-Z0-9_\\.]', '_', str(bouquet_name))
        cleanName = re.sub('_+', '_', cleanName)
        if mem.alias != '':
            with open('/etc/enigma2/bouquets.tv', 'r+') as f:
                new_f = f.readlines()
                f.seek(0)
                for line in new_f:
                    if mem.live and 'jmx_live_' + str(mem.alias) in line:
                        continue
                    if mem.vod and 'jmx_vod_' + str(mem.alias) in line:
                        continue
                    if mem.series and 'jmx_series_' + str(mem.alias) in line:
                        continue
                    f.write(line)

                f.truncate()
            if mem.live:
                self.purge('/etc/enigma2', 'jmx_live_' + str(mem.alias))
                if os.path.isdir('/etc/epgimport/'):
                    self.purge('/etc/epgimport', 'jmx.' + str(mem.alias))
            if mem.vod:
                self.purge('/etc/enigma2', 'jmx_vod_' + str(mem.alias))
            if mem.series:
                self.purge('/etc/enigma2', 'jmx_series_' + str(mem.alias))
        with open('/etc/enigma2/bouquets.tv', 'r+') as f:
            new_f = f.readlines()
            f.seek(0)
            for line in new_f:
                if mem.live and 'jmx_live_' + str(cleanName) in line:
                    continue
                if mem.vod and 'jmx_vod_' + str(cleanName) in line:
                    continue
                if mem.series and 'jmx_series_' + str(cleanName) in line:
                    continue
                f.write(line)

            f.truncate()
        if mem.live:
            self.purge('/etc/enigma2', 'jmx_live_' + str(cleanName))
            if os.path.isdir('/etc/epgimport/'):
                self.purge('/etc/epgimport', 'jmx.' + str(cleanName))
            if os.path.isfile(self.bouquetfile):
                if os.stat(self.bouquetfile).st_size > 0:
                    with open(self.bouquetfile) as f:
                        self.bouquetdata = json.load(f, object_pairs_hook=OrderedDict)
                        if len(self.bouquetdata) == 0:
                            cfg.unique.value = 1000
                            cfg.unique.save()
        if mem.vod:
            self.purge('/etc/enigma2', 'jmx_vod_' + str(cleanName))
        if mem.series:
            self.purge('/etc/enigma2', 'jmx_series_' + str(cleanName))
        self.progresscurrent += 1
        self['progress'].setValue(self.progresscurrent)
        self.timer1 = eTimer()
        self.timer1.start(self.timerlength, 1)
        self['action'].setText(_('Saving Bouquet Data...'))

        if fileExists(BRAND)or fileExists(BRANDP):
            self.timer1.callback.append(self.makeBouquetJsonFile) #pli
        else:
            self.timer1_conn = self.timer1.timeout.connect(self.makeBouquetJsonFile) #cvs        
        
        # try:
            # self.timer1_conn = self.timer1.timeout.connect(self.makeBouquetJsonFile)
        # except:
            # self.timer1.callback.append(self.makeBouquetJsonFile)

    def purge(self, dir, pattern):
        for f in os.listdir(dir):
            file_path = os.path.join(dir, f)
            if os.path.isfile(file_path):
                if re.search(pattern, f):
                    os.remove(file_path)

    def makeBouquetJsonFile(self):
        bouquet_values = {}
        if mem.currentPlaylist['local_info']['playlisttype'] == 'xtream':
            bouquet_values = {'address': mem.address,
             'bouquet_name': mem.bouquetNameCfg.value,
             'domain': mem.domain,
             'port': mem.port,
             'username': mem.username,
             'password': mem.password,
             'live': str(mem.live).lower(),
             'vod': str(mem.vod).lower(),
             'series': str(mem.series).lower(),
             'live_type': mem.bouquetLiveTypeCfg.value,
             'vod_type': mem.bouquetVodTypeCfg.value,
             'playlisttype': mem.currentPlaylist['local_info']['playlisttype'],
             'xmltv': mem.bouquetXmltvCfg.value,
             'protocol': mem.protocol,
             'liveupdate': '',
             'vodupdate': '',
             'seriesupdate': '',
             'live_categories': [],
             'vod_categories': [],
             'series_categories': []}
            if mem.bouquets_exists:
                if 'live_categories' in mem.bouquetdata[mem.currentbouquet]:
                    if mem.bouquetdata[mem.currentbouquet]['live_categories'] != []:
                        bouquet_values['live_categories'] = mem.bouquetdata[mem.currentbouquet]['live_categories']
                        bouquet_values['live'] = 'true'
                if 'vod_categories' in mem.bouquetdata[mem.currentbouquet]:
                    if mem.bouquetdata[mem.currentbouquet]['vod_categories'] != []:
                        bouquet_values['vod_categories'] = mem.bouquetdata[mem.currentbouquet]['vod_categories']
                        bouquet_values['vod'] = 'true'
                if 'series_categories' in mem.bouquetdata[mem.currentbouquet]:
                    if mem.bouquetdata[mem.currentbouquet]['series_categories'] != []:
                        bouquet_values['series_categories'] = mem.bouquetdata[mem.currentbouquet]['series_categories']
                        bouquet_values['series'] = 'true'
                if 'liveupdate' in mem.bouquetdata[mem.currentbouquet]:
                    if mem.bouquetdata[mem.currentbouquet]['liveupdate'] != '':
                        bouquet_values['liveupdate'] = mem.bouquetdata[mem.currentbouquet]['liveupdate']
                if 'vodupdate' in mem.bouquetdata[mem.currentbouquet]:
                    if mem.bouquetdata[mem.currentbouquet]['vodupdate'] != '':
                        bouquet_values['vodupdate'] = mem.bouquetdata[mem.currentbouquet]['vodupdate']
                if 'seriesupdate' in mem.bouquetdata[mem.currentbouquet]:
                    if mem.bouquetdata[mem.currentbouquet]['seriesupdate'] != '':
                        bouquet_values['seriesupdate'] = mem.bouquetdata[mem.currentbouquet]['seriesupdate']
            if mem.live:
                bouquet_values['live_categories'] = []
                bouquet_values['liveupdate'] = datetime.now().strftime('%c')
            if mem.vod:
                bouquet_values['vod_categories'] = []
                bouquet_values['vodupdate'] = datetime.now().strftime('%c')
            if mem.series:
                bouquet_values['series_categories'] = []
                bouquet_values['seriesupdate'] = datetime.now().strftime('%c')
            for category in self.selectedCategories:
                if category[1] == 'Live':
                    bouquet_values['live_categories'].append(category[0])
                elif category[1] == 'Series':
                    bouquet_values['series_categories'].append(category[0])
                elif category[1] == 'VOD':
                    bouquet_values['vod_categories'].append(category[0])

        elif mem.currentPlaylist['local_info']['playlisttype'] == 'external':
            bouquet_values = {'address': mem.address,
             'bouquet_name': mem.bouquetNameCfg.value,
             'domain': mem.domain,
             'live': str(mem.live).lower(),
             'vod': str(mem.vod).lower(),
             'series': str(mem.series).lower(),
             'live_type': mem.bouquetLiveTypeCfg.value,
             'vod_type': mem.bouquetVodTypeCfg.value,
             'playlisttype': mem.currentPlaylist['local_info']['playlisttype'],
             'xmltv': mem.bouquetXmltvCfg.value,
             'liveupdate': '',
             'vodupdate': '',
             'seriesupdate': '',
             'live_categories': [],
             'vod_categories': [],
             'series_categories': []}
            if mem.bouquets_exists:
                if 'live_categories' in mem.bouquetdata[mem.currentbouquet]:
                    if mem.bouquetdata[mem.currentbouquet]['live_categories'] != []:
                        bouquet_values['live_categories'] = mem.bouquetdata[mem.currentbouquet]['live_categories']
                        bouquet_values['live'] = 'true'
                if 'vod_categories' in mem.bouquetdata[mem.currentbouquet]:
                    if mem.bouquetdata[mem.currentbouquet]['vod_categories'] != []:
                        bouquet_values['vod_categories'] = mem.bouquetdata[mem.currentbouquet]['vod_categories']
                        bouquet_values['vod'] = 'true'
                if 'series_categories' in mem.bouquetdata[mem.currentbouquet]:
                    if mem.bouquetdata[mem.currentbouquet]['series_categories'] != []:
                        bouquet_values['series_categories'] = mem.bouquetdata[mem.currentbouquet]['series_categories']
                        bouquet_values['series'] = 'true'
                if 'liveupdate' in mem.bouquetdata[mem.currentbouquet]:
                    if mem.bouquetdata[mem.currentbouquet]['liveupdate'] != '':
                        bouquet_values['liveupdate'] = mem.bouquetdata[mem.currentbouquet]['liveupdate']
                if 'vodupdate' in mem.bouquetdata[mem.currentbouquet]:
                    if mem.bouquetdata[mem.currentbouquet]['vodupdate'] != '':
                        bouquet_values['vodupdate'] = mem.bouquetdata[mem.currentbouquet]['vodupdate']
                if 'seriesupdate' in mem.bouquetdata[mem.currentbouquet]:
                    if mem.bouquetdata[mem.currentbouquet]['seriesupdate'] != '':
                        bouquet_values['seriesupdate'] = mem.bouquetdata[mem.currentbouquet]['seriesupdate']
            if mem.live:
                bouquet_values['live_categories'] = []
                bouquet_values['liveupdate'] = datetime.now().strftime('%c')
            if mem.vod:
                bouquet_values['vod_categories'] = []
                bouquet_values['vodupdate'] = datetime.now().strftime('%c')
            if mem.series:
                bouquet_values['series_categories'] = []
                bouquet_values['seriesupdate'] = datetime.now().strftime('%c')
            for category in self.getm3ustreams:
                if category[4] == 'live':
                    bouquet_values['live_categories'].append(category[0])
                elif category[4] == 'vod':
                    bouquet_values['vod_categories'].append(category[0])

        elif mem.currentPlaylist['local_info']['playlisttype'] == 'local':
            bouquet_values = {'address': mem.address,
             'bouquet_name': mem.bouquetNameCfg.value,
             'live': str(mem.live).lower(),
             'vod': str(mem.vod).lower(),
             'series': str(mem.series).lower(),
             'live_type': mem.bouquetLiveTypeCfg.value,
             'vod_type': mem.bouquetVodTypeCfg.value,
             'playlisttype': mem.currentPlaylist['local_info']['playlisttype'],
             'xmltv': mem.bouquetXmltvCfg.value,
             'liveupdate': '',
             'vodupdate': '',
             'seriesupdate': '',
             'live_categories': [],
             'vod_categories': [],
             'series_categories': []}
            if mem.bouquets_exists:
                if 'live_categories' in mem.bouquetdata[mem.currentbouquet]:
                    if mem.bouquetdata[mem.currentbouquet]['live_categories'] != []:
                        bouquet_values['live_categories'] = mem.bouquetdata[mem.currentbouquet]['live_categories']
                        bouquet_values['live'] = 'true'
                if 'vod_categories' in mem.bouquetdata[mem.currentbouquet]:
                    if mem.bouquetdata[mem.currentbouquet]['vod_categories'] != []:
                        bouquet_values['vod_categories'] = mem.bouquetdata[mem.currentbouquet]['vod_categories']
                        bouquet_values['vod'] = 'true'
                if 'series_categories' in mem.bouquetdata[mem.currentbouquet]:
                    if mem.bouquetdata[mem.currentbouquet]['series_categories'] != []:
                        bouquet_values['series_categories'] = mem.bouquetdata[mem.currentbouquet]['series_categories']
                        bouquet_values['series'] = 'true'
                if 'liveupdate' in mem.bouquetdata[mem.currentbouquet]:
                    if mem.bouquetdata[mem.currentbouquet]['liveupdate'] != '':
                        bouquet_values['liveupdate'] = mem.bouquetdata[mem.currentbouquet]['liveupdate']
                if 'vodupdate' in mem.bouquetdata[mem.currentbouquet]:
                    if mem.bouquetdata[mem.currentbouquet]['vodupdate'] != '':
                        bouquet_values['vodupdate'] = mem.bouquetdata[mem.currentbouquet]['vodupdate']
                if 'seriesupdate' in mem.bouquetdata[mem.currentbouquet]:
                    if mem.bouquetdata[mem.currentbouquet]['seriesupdate'] != '':
                        bouquet_values['seriesupdate'] = mem.bouquetdata[mem.currentbouquet]['seriesupdate']
            if mem.live:
                bouquet_values['live_categories'] = []
                bouquet_values['liveupdate'] = datetime.now().strftime('%c')
            if mem.vod:
                bouquet_values['vod_categories'] = []
                bouquet_values['vodupdate'] = datetime.now().strftime('%c')
            if mem.series:
                bouquet_values['series_categories'] = []
                bouquet_values['seriesupdate'] = datetime.now().strftime('%c')
            for category in self.getm3ustreams:
                if category[4] == 'live':
                    bouquet_values['live_categories'].append(category[0])
                elif category[4] == 'vod':
                    bouquet_values['vod_categories'].append(category[0])

        if mem.bouquets_exists:
            for i in range(len(mem.bouquetdata)):
                if bouquet_values['address'] == mem.bouquetdata[i]['address']:
                    mem.bouquetdata[i] = bouquet_values
                    break

        else:
            mem.bouquetdata.append(bouquet_values)
        filename = '/etc/enigma2/jediplaylists/bouquet_info_v2.json'
        with open(filename, 'w') as f:
            json.dump(mem.bouquetdata, f)
        self.progresscurrent += 1
        self['progress'].setValue(self.progresscurrent)
        if mem.currentPlaylist['local_info']['playlisttype'] == 'xtream':
            self.timer3 = eTimer()
            self.timer3.start(self.timerlength, 1)

            if fileExists(BRAND)or fileExists(BRANDP):
                self.timer3.callback.append(self.buildBouquets) #pli
            else:
                self.timer3_conn = self.timer3.timeout.connect(self.buildBouquets) #cvs   
            
            
            # try:
                # self.timer3_conn = self.timer3.timeout.connect(self.buildBouquets)
            # except:
                # self.timer3.callback.append(self.buildBouquets)
            
        else:
            self.timer3 = eTimer()
            self.timer3.start(self.timerlength, 1)
            self['action'].setText(_('Building Bouquets from M3U File'))

            if fileExists(BRAND)or fileExists(BRANDP):
                self.timer3.callback.append(self.buildM3uBouquets) #pli
            else:
                self.timer3_conn = self.timer3.timeout.connect(self.buildM3uBouquets) #cvs               
            
            
            # try:
                # self.timer3_conn = self.timer3.timeout.connect(self.buildM3uBouquets)
            # except:
                # self.timer3.callback.append(self.buildM3uBouquets)
            
            self.timer3.start(10, 1)    

    def buildM3uBouquets(self):
        if self.firstrun == True:
            if cfg.unique.value:
                self.unique_ref = cfg.unique.value
            else:
                self.unique_ref = 1000
            self.epg_name_list = []
        self.firstrun = False
        self.service_type = 1
        for x in self.getm3ustreams:
            if x[0] != '':
                if [x[0], x[4]] not in mem.categories:
                    mem.categories.append([x[0], x[4]])

        if len(mem.categories) <= 1:
            self['status'].setText(_("Building 'General' Bouquet"))
        else:
            self['status'].setText(_('Building Categories'))
        if self.x < len(mem.categories):
            self.m3ucatloop()
        else:
            self.progresscurrent += 1
            self['progress'].setValue(self.progresscurrent)
            if mem.live and os.path.isdir('/usr/lib/enigma2/python/Plugins/Extensions/EPGImport') and os.path.isdir('/etc/epgimport/'):
                self.buildXMLTVChannelFile()
                self.buildXMLTVSourceFile()
            self.reloadBouquet()
            self.session.openWithCallback(self.done, MessageBox, str(len(mem.categories)) + ' IPTV Bouquets Created', MessageBox.TYPE_INFO, timeout=30)

    def m3ucatloop(self):
        c = mem.categories[self.x][0]
        self.bouquetTitle = str(mem.bouquetNameCfg.value) + ' - ' + str(c)
        self.bouquetString = '#NAME ' + str(self.bouquetTitle) + '\n'
        self.streamvaluesgroup = []
        self.streamvalues = []
        if mem.categories[self.x][1] == 'live':
            self.streamvalues = [ stream for stream in self.getm3ustreams if str(mem.categories[self.x][0]) == str(stream[0]) and str(mem.categories[self.x][1]) == str(stream[4]) ]
            self.streamvaluesgroup += self.streamvalues
            for m3u in self.streamvaluesgroup:
                group_title = m3u[0]
                epg_name = m3u[1]
                name = m3u[2]
                source = m3u[3]
                cat = m3u[4]
                source = source.replace(':', '%3a')
                player_type = mem.bouquetLiveTypeCfg.value
                custom_sid = ':0:' + str(self.service_type) + ':' + '666' + ':' + str(self.unique_ref) + ':0:0:0:0:0:'
                self.unique_ref += 1
                cfg.unique.value = self.unique_ref
                cfg.unique.save()
                source_epg = '1' + str(custom_sid) + source
                if epg_name:
                    self.epg_name_list.append([epg_name, source_epg])
                self.bouquetString += '#SERVICE ' + str(player_type) + str(custom_sid) + str(source) + ':' + str(name) + '\n'
                self.bouquetString += '#DESCRIPTION ' + str(name) + '\n'

            self.createBouquetXmlFile('live')
            self.addBouquetsTV('live')
        elif mem.categories[self.x][1] == 'vod':
            self.streamvalues = [ stream for stream in self.getm3ustreams if str(mem.categories[self.x][0]) == str(stream[0]) and str(mem.categories[self.x][1]) == str(stream[4]) ]
            self.streamvaluesgroup += self.streamvalues
            for m3u in self.streamvaluesgroup:
                group_title = m3u[0]
                epg_name = m3u[1]
                name = m3u[2]
                source = m3u[3]
                cat = m3u[4]
                source = source.replace(':', '%3a')
                player_type = mem.bouquetVodTypeCfg.value
                custom_sid = ':0:1:0:0:0:0:0:0:0:'
                self.bouquetString += '#SERVICE ' + str(player_type) + str(custom_sid) + str(source) + ':' + str(name) + '\n'
                self.bouquetString += '#DESCRIPTION ' + str(name) + '\n'

            self.createBouquetXmlFile('vod')
            self.addBouquetsTV('vod')
        self.x += 1
        self.timer5 = eTimer()

        if fileExists(BRAND)or fileExists(BRANDP):
            self.timer5.callback.append(self.buildM3uBouquets) #pli
        else:
            self.timer5_conn = self.timer5.timeout.connect(self.buildM3uBouquets) #cvs          
        
        
        # try:
            # self.timer5_conn = self.timer5.timeout.connect(self.buildM3uBouquets)
        # except:
            # self.timer5.callback.append(self.buildM3uBouquets)
        self.timer5.start(10, 1)

    def buildBouquets(self):
        self['progress'].setValue(self.progresscurrent)
        self['action'].setText(_('Building Categories %d of %d') % (self.job_current, self.job_total))
        self['status'].setText(_('%s: %s') % (self.job_type, self.job_category_name))
        if self.firstrun == True:
            if cfg.unique.value:
                self.unique_ref = cfg.unique.value
            else:
                self.unique_ref = 1000
            self.epg_name_list = []
        self.firstrun = False
        if self.x < len(self.selectedCategories):
            self.catloop()
        else:
            if mem.live and os.path.isdir('/usr/lib/enigma2/python/Plugins/Extensions/EPGImport') and os.path.isdir('/etc/epgimport/'):
                self.buildXMLTVChannelFile()
                self.buildXMLTVSourceFile()
            self.reloadBouquet()
            self.session.openWithCallback(self.done, MessageBox, str(len(self.selectedCategories)) + ' IPTV Bouquets Created', MessageBox.TYPE_INFO, timeout=30)

    def replace_all(self, text, dic):
        for i, j in dic.iteritems():
            text = text.replace(i, j)

        return text

    def catloop(self):
        cat_name = self.selectedCategories[self.x][0]
        cat = self.selectedCategories[self.x][1]
        cat_id = self.selectedCategories[self.x][2]
        self.streamvaluesgroup = []
        self.streamvalues = []
        self.bouquetTitle = str(mem.bouquetNameCfg.value) + ' - ' + str(cat_name)
        self.bouquetString = '#NAME ' + str(self.bouquetTitle) + '\n'
        service_type = 1
        domain = str(mem.currentPlaylist['local_info']['domain'])
        port = str(mem.currentPlaylist['local_info']['port'])
        username = str(mem.currentPlaylist['local_info']['username'])
        password = str(mem.currentPlaylist['local_info']['password'])
        protocol = str(mem.currentPlaylist['local_info']['protocol']).replace(':', '%3a')
        if cat == 'Live':
            player_type = mem.bouquetLiveTypeCfg.value
            self.streamvalues = [ stream for stream in mem.livestreams if str(cat_id) == str(stream['category_id']) ]
            self.streamvaluesgroup += self.streamvalues
            stream_type = 'live'
            if str(mem.output) in mem.currentPlaylist['user_info']['allowed_output_formats']:
                output = mem.output
            else:
                output = str(mem.currentPlaylist['user_info']['allowed_output_formats'][0])
            replacements = {'e !': 'e!',
             'granda': 'granada',
             'sly': 'sky',
             's3y': 'sky'}
            for i in range(len(self.streamvaluesgroup)):
                listOfKeys = []
                epgid = False
                tempname = str(self.streamvaluesgroup[i]['name']).strip().lower()
                tempname = self.replace_all(tempname, replacements)
                tempname = re.sub('\\|.+\\|', '', tempname)
                tempname = re.sub('\\(.+\\)', '', tempname)
                tempname = re.sub('(fhd|full hd|1080p|1080|4k|uhd|\xca\x9c\xe1\xb4\x85)', 'hd ', tempname)
                tempname = re.sub('[^a-zA-Z0-9\\u00C0-\\u00FF \\/\\_\\.\\:\\!\\+\\-\\(\\)\\|\\&]', '', tempname)
                tempname = re.sub('(uk[^A-Za-z0-9]+|uki[^A-Za-z0-9]+|ir[^A-Za-z0-9]+|ire[^A-Za-z0-9]+|sd|720p|720|local|british|backup|ppv|vip|pdc|\\||\\-|\\*|\\_|)', '', tempname)
                tempname = tempname.strip('.').strip()
                words = tempname.split()
                tempname = ' '.join(sorted(set(words), key=words.index))
                found = False
                self.reference = ''
                for line in self.epgnames2:
                    for item in line:
                        if tempname == item:
                            self.reference = str(line[0])
                            found = True
                            break

                    if found:
                        break

                channelname = ''
                serviceref = ''
                for line in self.rytecchannels:
                    channelname = re.search('(?<=<\\/channel><!-- ).*(?= --)', line).group()
                    serviceref = re.search('(?<=">1).*(?=<\\/)', line).group()
                    if channelname != '' and serviceref != '' and self.reference.lower() == channelname.lower():
                        if re.search('(?<=id=")[a-zA-Z0-9\\.]+', line) is not None:
                            epg_channel_id = re.search('(?<=id=")[a-zA-Z0-9\\.]+', line).group()
                        else:
                            epg_channel_id = ''
                        epgid = True
                        break

                if epgid:
                    custom_sid = serviceref
                    print 'channel name ' + str(channelname) + '\n'
                    print 'serviceref ' + str(serviceref) + '\n'
                    print 'epg_channel_id ' + str(epg_channel_id) + '\n'
                elif re.match(':\\d+:\\d+:[a-zA-Z0-9]+:[a-zA-Z0-9]+:[a-zA-Z0-9]+:[a-zA-Z0-9]+:0:0:0:', str(self.streamvaluesgroup[i]['custom_sid'])):
                    custom_sid = self.streamvaluesgroup[i]['custom_sid']
                elif re.match(':\\d+:\\d+:[a-zA-Z0-9]+:[a-zA-Z0-9]+:[a-zA-Z0-9]+:[a-zA-Z0-9]+:0:0:', str(self.streamvaluesgroup[i]['custom_sid'])):
                    custom_sid = str(self.streamvaluesgroup[i]['custom_sid']) + str('0:')
                else:
                    custom_sid = ':0:' + str(service_type) + ':' + '666' + ':' + str(self.unique_ref) + ':0:0:0:0:0:'
                    self.unique_ref += 1
                stream_id = self.streamvaluesgroup[i]['stream_id']
                source = str(player_type) + str(custom_sid) + str(protocol) + str(domain) + '%3a' + str(port) + '/' + str(stream_type) + '/' + str(username) + '/' + str(password) + '/' + str(stream_id) + '.' + str(output)
                source_epg = '1' + str(custom_sid) + str(protocol) + str(domain) + '%3a' + str(port) + '/' + str(stream_type) + '/' + str(username) + '/' + str(password) + '/' + str(stream_id) + '.' + str(output)
                if epgid:
                    self.epg_name_list.append([str(epg_channel_id), source_epg])
                elif self.streamvaluesgroup[i]['epg_channel_id']:
                    self.epg_name_list.append([str(self.streamvaluesgroup[i]['epg_channel_id']), source_epg])
                name = self.streamvaluesgroup[i]['name']
                self.bouquetString += '#SERVICE ' + source + ':' + str(name) + '\n'
                self.bouquetString += '#DESCRIPTION ' + str(name) + '\n'

            self.createBouquetXmlFile('live')
            self.addBouquetsTV('live')
        elif cat == 'VOD':
            player_type = mem.bouquetVodTypeCfg.value
            self.streamvalues = [ stream for stream in mem.vodstreams if str(cat_id) == str(stream['category_id']) ]
            self.streamvalues = sorted(self.streamvalues, key=lambda s: s['name'])
            self.streamvaluesgroup += self.streamvalues
            stream_type = 'movie'
            custom_sid = ':0:1:0:0:0:0:0:0:0:'
            for i in range(len(self.streamvaluesgroup)):
                stream_id = self.streamvaluesgroup[i]['stream_id']
                output = str(self.streamvaluesgroup[i]['container_extension'])
                source = str(player_type) + str(custom_sid) + str(protocol) + str(domain) + '%3a' + str(port) + '/' + str(stream_type) + '/' + str(username) + '/' + str(password) + '/' + str(stream_id) + '.' + str(output)
                source_epg = '1' + str(custom_sid) + str(protocol) + str(domain) + '%3a' + str(port) + '/' + str(stream_type) + '/' + str(username) + '/' + str(password) + '/' + str(stream_id) + '.' + str(output)
                name = self.streamvaluesgroup[i]['name']
                self.bouquetString += '#SERVICE ' + source + ':' + str(name) + '\n'
                self.bouquetString += '#DESCRIPTION ' + str(name) + '\n'

            self.createBouquetXmlFile('vod')
            self.addBouquetsTV('vod')
        elif cat == 'Series':
            player_type = mem.bouquetVodTypeCfg.value
            self.streamvalues = [ stream for stream in mem.seriesstreams if str(cat_id) == str(stream['category_id']) ]
            self.streamvalues = sorted(self.streamvalues, key=lambda s: s['name'])
            self.streamvaluesgroup += self.streamvalues
            stream_type = 'series'
            custom_sid = ':0:1:0:0:0:0:0:0:0:'
            for i in range(len(self.streamvaluesgroup)):
                name = self.streamvaluesgroup[i]['name']
                if cat_name in mem.m3uValues:
                    for channel in mem.m3uValues[cat_name]:
                        source = str(player_type) + str(custom_sid) + channel['url'].replace(':', '%3a')
                        self.bouquetString += '#SERVICE ' + source + ':' + channel['name'] + '\n'
                        self.bouquetString += '#DESCRIPTION ' + channel['name'] + '\n'

                    break

            self.createBouquetXmlFile('series')
            self.addBouquetsTV('series')
        self.job_current = self.x
        self.job_type = cat
        self.job_category_name = cat_name
        self.progresscurrent += 1
        self.x += 1
        self.timer5 = eTimer()

        
        if fileExists(BRAND)or fileExists(BRANDP):
            self.timer5.callback.append(self.buildBouquets) #pli
        else:
            self.timer5_conn = self.timer5.timeout.connect(self.buildBouquets) #cvs          
        
        # try:
            # self.timer5_conn = self.timer5.timeout.connect(self.buildBouquets)
        # except:
            # self.timer5.callback.append(self.buildBouquets)
            
        self.timer5.start(10, 1)
        return

    def createBouquetXmlFile(self, streamtype):
        cleanTitle = re.sub('[^a-zA-Z0-9_\\.]', '_', self.bouquetTitle)
        cleanTitle = re.sub('_+', '_', cleanTitle)
        filepath = '/etc/enigma2/'
        filename = 'userbouquet.jmx_' + str(streamtype) + '_' + str(cleanTitle) + '.tv'
        fullpath = filepath + filename
        with open(fullpath, 'w+') as f:
            f.write(self.bouquetString)

    def addBouquetsTV(self, streamtype):
        cleanTitle = re.sub('[^a-zA-Z0-9_\\.]', '_', self.bouquetTitle)
        cleanTitle = re.sub('_+', '_', cleanTitle)
        filename = 'userbouquet.jmx_' + str(streamtype) + '_' + str(cleanTitle) + '.tv'
        with open('/etc/enigma2/bouquets.tv', 'a+') as f:
            bouquetTvString = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "' + filename + '" ORDER BY bouquet\r\n'
            if bouquetTvString not in f:
                f.write(bouquetTvString)

    def buildXMLTVChannelFile(self):
        self.xmltv_api = str(mem.bouquetXmltvCfg.value)
        if mem.currentPlaylist['local_info']['playlisttype'] == 'xtream':
            host = str(mem.protocol) + str(mem.domain) + ':' + str(mem.port) + '/'
            if mem.bouquetXmltvCfg.value == '':
                self.xmltv_api = str(host) + 'xmltv.php?username=' + str(mem.username) + '&password=' + str(mem.password)
            else:
                self.xmltv_api = mem.bouquetXmltvCfg.value
        if self.xmltv_api != '':
            if os.path.isdir('/etc/epgimport/'):
                self.purge('/etc/epgimport', 'jmx.' + str(mem.alias) + '.channels.xml')
                self.purge('/etc/epgimport', 'jmx.' + str(mem.alias) + '.sources.xml')
            cleanName = re.sub('[^a-zA-Z0-9_\\.]', '_', str(mem.bouquetNameCfg.value))
            cleanName = re.sub('_+', '_', cleanName)
            epgfilepath = '/etc/epgimport/'
            epgfilename = 'jmx.' + str(cleanName) + '.channels.xml'
            self.channelpath = epgfilepath + epgfilename
            bouquetfilepath = '/etc/enigma2/'
            root = ET.Element('channels')
            if not os.path.isfile(self.channelpath):
                open(self.channelpath, 'a').close()
                for i in range(len(self.epg_name_list)):
                    newchannel = ET.SubElement(root, 'channel')
                    newchannel.set('id', self.epg_name_list[i][0])
                    newchannel.text = self.epg_name_list[i][1]

                xml_str = str(ET.tostring(root, 'utf-8'))
                doc = minidom.parseString(xml_str)
                xml_output = doc.toprettyxml(encoding='utf-8', indent='')
                xml_output = os.linesep.join([ s for s in xml_output.splitlines() if s.strip() ])
                with open(self.channelpath, 'w') as f:
                    f.write(xml_output)
            else:
                tree = ET.parse(self.channelpath)
                root = tree.getroot()
                e = str(ET.tostring(root, 'utf-8'))
                for channel in root.findall('channel'):
                    root.remove(channel)

                for i in range(len(self.epg_name_list)):
                    newchannel = ET.SubElement(root, 'channel')
                    newchannel.set('id', self.epg_name_list[i][0])
                    newchannel.text = self.epg_name_list[i][1]

                xml_str = str(ET.tostring(root, 'utf-8'))
                doc = minidom.parseString(xml_str)
                xml_output = doc.toprettyxml(encoding='utf-8', indent='')
                xml_output = os.linesep.join([ s for s in xml_output.splitlines() if s.strip() ])
                with open(self.channelpath, 'w') as f:
                    f.write(xml_output)

    def buildXMLTVSourceFile(self):
        self.xmltv_api = str(mem.bouquetXmltvCfg.value)
        if mem.currentPlaylist['local_info']['playlisttype'] == 'xtream':
            host = str(mem.protocol) + str(mem.domain) + ':' + str(mem.port) + '/'
            if mem.bouquetXmltvCfg.value == '':
                self.xmltv_api = str(host) + 'xmltv.php?username=' + str(mem.username) + '&password=' + str(mem.password)
            else:
                self.xmltv_api = mem.bouquetXmltvCfg.value
        if self.xmltv_api != '':
            cleanName = re.sub('[^a-zA-Z0-9_\\.]', '_', str(mem.bouquetNameCfg.value))
            cleanName = re.sub('_+', '_', cleanName)
            filepath = '/etc/epgimport/'
            filename = 'jmx.' + str(cleanName) + '.sources.xml'
            self.sourcepath = filepath + filename
            with open(self.sourcepath, 'w') as f:
                xml_str = '<?xml version="1.0" encoding="utf-8"?>\n'
                xml_str += '<sources>\n'
                xml_str += '<sourcecat sourcecatname="IPTV ' + str(cleanName) + '">\n'
                xml_str += '<source type="gen_xmltv" nocheck="1" channels="' + self.channelpath + '">\n'
                xml_str += '<description>' + str(cleanName) + '</description>\n'
                xml_str += '<url><![CDATA[' + str(self.xmltv_api) + ']]></url>\n'
                xml_str += '</source>\n'
                xml_str += '</sourcecat>\n'
                xml_str += '</sources>\n'
                f.write(xml_str)

    def reloadBouquet(self):
        self['action'].setText(_('Refreshing Bouquets...'))
        eDVBDB.getInstance().reloadServicelist()
        eDVBDB.getInstance().reloadBouquets()
        configfile.save()


class JediMakerXtream_ViewChannels(Screen):

    def __init__(self, session, current):
        self.session = session
        skin = skin_path + 'jmx_channels.xml'
        with open(skin, 'r') as f:
            self.skin = f.read()
        self.setup_title = _('Channel List')
        Screen.__init__(self, session)
        self.current = current
        self.channellist = []
        self['list'] = MenuList(self.channellist)
        self['actions'] = ActionMap(['SetupActions'], {'ok': self.quit,
         'cancel': self.quit,
         'menu': self.quit,
         'up': self['list'].up,
         'down': self['list'].down,
         'right': self['list'].pageDown,
         'left': self['list'].pageUp,
         'moveUp': self.gotoFirstPage,
         'moveDown': self.gotoLastPage}, -2)
        self['key_red'] = StaticText(_('Close'))
        self.getchannels()
        self.onLayoutFinish.append(self.__layoutFinished)

    def __layoutFinished(self):
        self.setTitle(self.setup_title)

    def quit(self):
        self.close()

    def gotoFirstPage(self):
        self['list'].moveToIndex(0)

    def gotoLastPage(self):
        self['list'].moveToIndex(len(self.channellist) - 1)

    def getchannels(self):
        if self.current[1] == 'Live':
            for channel in mem.livestreams:
                if str(channel['category_id']) == str(self.current[2]):
                    self.channellist.append(str(channel['name']).strip())

        if self.current[1] == 'VOD':
            for channel in mem.vodstreams:
                if str(channel['category_id']) == str(self.current[2]):
                    self.channellist.append(str(channel['name']).strip())

        if self.current[1] == 'Series':
            for channel in mem.seriesstreams:
                if str(channel['category_id']) == str(self.current[2]):
                    self.channellist.append(str(channel['name']).strip())

        self.channellist.sort()