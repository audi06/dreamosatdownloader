# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/JediMakerXtream/update.py
from collections import OrderedDict
from Components.ActionMap import ActionMap
from Components.config import *
from Components.Label import Label
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from enigma import eDVBDB, eTimer
from plugin import skin_path, cfg
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from xml.dom import Node, minidom
from xml.dom.minidom import parse, parseString
import xml.etree.cElementTree as ET
import re
import json
import urllib2
import os
from datetime import datetime
import socket
from Components.ProgressBar import ProgressBar
from twisted.web.client import downloadPage

#lululla
BRAND = '/usr/lib/enigma2/python/boxbranding.so'
BRANDP = '/usr/lib/enigma2/python/Plugins/PLi/__init__.pyo'
BRANDPLI ='/usr/lib/enigma2/python/Tools/StbHardware.pyo'


class mem:
    pass


try:
    import lzma
    print 'lmza success'
    mem.haslzma = True
except ImportError:
    try:
        from backports import lzma
        print 'backports success'
        mem.haslzma = True
    except ImportError:
        mem.haslzma = False
        print 'lmza failed'

class JediMakerXtream_Update(Screen):

    def __init__(self, session, runtype):
        Screen.__init__(self, session)
        self.session = session
        self.runtype = runtype
        if self.runtype == 'manual':
            skin = skin_path + 'jmx_progress.xml'
            with open(skin, 'r') as f:
                self.skin = f.read()
        Screen.setTitle(self, _('Updating Bouquets'))
        self['action'] = Label('')
        self['status'] = Label('')
        self['progress'] = ProgressBar()
        self['actions'] = ActionMap(['SetupActions'], {'cancel': self.keyCancel}, -2)
        self.timerlength = 100
        self.index = 0
        self.hdr = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
         'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'}
        self.bouquetfile = '/etc/enigma2/jediplaylists/bouquet_info_v2.json'
        self.bouquetdata = []
        self.unique_ref = 1000
        if os.path.isfile(self.bouquetfile):
            if os.stat(self.bouquetfile).st_size > 0:
                with open(self.bouquetfile) as f:
                    self.bouquetdata = json.load(f, object_pairs_hook=OrderedDict)
        self.job_bouquet_name = ''
        self.machine = socket.gethostname()
        self.firstrun = True
        self.x = 0
        self.downloadrytec()
        self.start()

    def keyCancel(self):
        self.close()

    def downloadgetfile(self):
        response = ''
        req = urllib2.Request(self.get_api)
        try:
            response = urllib2.urlopen(req)
        except urllib2.URLError as e:
            print e
        except socket.timeout as e:
            print e

        channelnum = 0
        self.m3uValues = {}
        if response != '':
            for line in response:
                series_group_title = ''
                series_name = ''
                series_container_extension = ''
                series_url = ''
                if not line.startswith('#EXTINF') and not line.startswith('http'):
                    continue
                if line.startswith('#EXTINF'):
                    if re.search('(?<=group-title=")[^"]+', line) is not None:
                        series_group_title = re.search('(?<=group-title=")[^"]+', line).group()
                    if re.search('((?<=",).*$|(?<=1,).*$)', line) is not None:
                        series_name = re.search('((?<=",).*$|(?<=1,).*$)', line).group().strip()
                    if series_name == '':
                        channelnum += 1
                        series_name = 'Channel ' + str(channelnum)
                    if series_group_title == '':
                        series_group_title = 'Uncategorised'
                    nextline = response.next()
                    if nextline.startswith('http'):
                        series_url = nextline.strip()
                if series_url != '' and '/series/' in series_url:
                    if series_group_title not in self.m3uValues:
                        self.m3uValues[series_group_title] = [{'name': series_name,
                          'url': series_url}]
                    else:
                        self.m3uValues[series_group_title].append({'name': series_name,
                         'url': series_url})

            return
        else:
            return

    def downloadrytec(self):
        rytecfile = '/etc/enigma2/jediplaylists/rytec.channels.xml.xz'
        downloadPage('http://www.xmltvepg.nl/rytec.channels.xml.xz', rytecfile)
        self.epgnames2 = []
        if os.path.isfile(rytecfile):
            if os.stat(rytecfile).st_size > 0:
                if mem.haslzma:
                    with lzma.open(rytecfile, 'rb') as fd:
                        with open('/etc/enigma2/jediplaylists/28.2e.txt', 'w') as outfile:
                            for line in fd:
                                if '28.2E' in line:
                                    outfile.write(line)

                with open('/etc/enigma2/jediplaylists/28.2e.txt', 'r') as outfile:
                    self.rytecchannels = outfile.readlines()
                if os.path.isfile('/etc/enigma2/jediplaylists/alias.txt'):
                    if os.stat('/etc/enigma2/jediplaylists/alias.txt').st_size > 0:
                        with open('/etc/enigma2/jediplaylists/alias.txt') as f:
                            self.epgnames2 = json.load(f)

    def start(self):
        self['action'].setText(_('Starting Update...'))
        self.progresscount = len(self.bouquetdata)
        self.progresscurrent = 0
        self['progress'].setRange((0, self.progresscount))
        self['progress'].setValue(self.progresscurrent)
        self.timer = eTimer()

       
        if fileExists(BRAND)or fileExists(BRANDP):
            self.timer.callback.append(self.loopPlaylists) #pli
        else:
            self.timer_conn = self.timer.timeout.connect(self.loopPlaylists) #cvs
                        
        # try:
            # self.timer_conn = self.timer.timeout.connect(self.loopPlaylists)
        # except:
            # self.timer.callback.append(self.loopPlaylists)
        self.timer.start(self.timerlength, 1)

    def loopPlaylists(self):
        if self.x < len(self.bouquetdata):
            self.catloop()
        else:
            self.reloadBouquet()
            cfg.unique.value = self.unique_ref
            cfg.unique.save()
            configfile.save()
            if self.runtype == 'manual':
                self.session.openWithCallback(self.done, MessageBox, str(len(self.bouquetdata)) + ' IPTV Bouquets Updated', MessageBox.TYPE_INFO, timeout=30)
            else:
                self.close()

    def catloop(self):
        self.job_bouquet_name = self.bouquetdata[self.x]['bouquet_name']
        self['progress'].setValue(self.progresscurrent)
        self['progress'].setRange((0, self.progresscount))
        self['action'].setText(_('Updating Playlist %d of %d') % (self.progresscurrent, self.progresscount))
        self['status'].setText(_('Playlist: %s') % str(self.job_bouquet_name))
        self.bouquet_name = self.bouquetdata[self.x]['bouquet_name']
        self.live = self.bouquetdata[self.x]['live']
        if self.live == 'true':
            self.live = True
        else:
            self.live = False
        self.vod = self.bouquetdata[self.x]['vod']
        if self.vod == 'true':
            self.vod = True
        else:
            self.vod = False
        self.series = self.bouquetdata[self.x]['series']
        if self.series == 'true':
            self.series = True
        else:
            self.series = False
        self.address = self.bouquetdata[self.x]['address']
        self.xmltv = self.bouquetdata[self.x]['xmltv']
        self.playlisttype = self.bouquetdata[self.x]['playlisttype']
        self.live_type = self.bouquetdata[self.x]['live_type']
        self.vod_type = self.bouquetdata[self.x]['vod_type']
        self.categories = []
        if self.playlisttype == 'xtream':
            self.protocol = self.bouquetdata[self.x]['protocol']
            self.domain = self.bouquetdata[self.x]['domain']
            self.port = self.bouquetdata[self.x]['port']
            self.username = self.bouquetdata[self.x]['username']
            self.password = self.bouquetdata[self.x]['password']
            self.protocol = self.bouquetdata[self.x]['protocol']
            self.live_categories = self.bouquetdata[self.x]['live_categories']
            self.vod_categories = self.bouquetdata[self.x]['vod_categories']
            self.series_categories = self.bouquetdata[self.x]['series_categories']
            self.host = str(self.protocol) + str(self.domain) + ':' + str(self.port) + '/'
            self.player_api = str(self.host) + 'player_api.php?username=' + str(self.username) + '&password=' + str(self.password)
            self.panel_api = str(self.host) + 'panel_api.php?username=' + str(self.username) + '&password=' + str(self.password)
            self.get_api = str(self.host) + 'get.php?username=' + str(self.username) + '&password=' + str(self.password) + '&type=m3u_plus'
            self.LiveCategoriesUrl = self.player_api + '&action=get_live_categories'
            self.LiveStreamsUrl = self.player_api + '&action=get_live_streams'
            self.VodCategoriesUrl = self.player_api + '&action=get_vod_categories'
            self.VodStreamsUrl = self.player_api + '&action=get_vod_streams'
            self.SeriesCategoriesUrl = self.player_api + '&action=get_series_categories'
            self.SeriesUrl = self.player_api + '&action=get_series'
            if self.series:
                self.downloadgetfile()
            self.downloadcategories()
            self.downloadstreams()
            self.getCategories()
            self.buildBouquets()
        if self.playlisttype == 'external':
            self.domain = self.bouquetdata[self.x]['domain']
        if self.playlisttype == 'external' or self.playlisttype == 'local':
            self.getM3uCategories()
            self.buildM3uBouquets()
        self.progresscurrent += 1
        self.x += 1
        self.timer = eTimer()

        
        if fileExists(BRAND)or fileExists(BRANDP):
            self.timer.callback.append(self.loopPlaylists) #pli
        else:
            self.timer_conn = self.timer.timeout.connect(self.loopPlaylists) #cvs        
        
        # try:
            # self.timer_conn = self.timer.timeout.connect(self.loopPlaylists)
        # except:
            # self.timer.callback.append(self.loopPlaylists)
        self.timer.start(self.timerlength, 1)

    def downloadcategories(self):
        self.livecategories = []
        self.vodcategories = []
        self.seriescategories = []
        if self.live:
            req = urllib2.Request(self.LiveCategoriesUrl, headers=self.hdr)
            try:
                response1 = urllib2.urlopen(req)
                self.livecategories = json.load(response1, object_pairs_hook=OrderedDict)
            except urllib2.URLError as e:
                pass
            except socket.timeout as e:
                print e

        if self.vod:
            req = urllib2.Request(self.VodCategoriesUrl, headers=self.hdr)
            try:
                response2 = urllib2.urlopen(req)
                self.vodcategories = json.load(response2, object_pairs_hook=OrderedDict)
            except urllib2.URLError as e:
                pass
            except socket.timeout as e:
                print e

        if self.series:
            req = urllib2.Request(self.SeriesCategoriesUrl, headers=self.hdr)
            try:
                response3 = urllib2.urlopen(req)
                self.seriescategories = json.load(response3, object_pairs_hook=OrderedDict)
            except urllib2.URLError as e:
                print e
            except socket.timeout as e:
                print e

    def downloadstreams(self):
        self.livestreams = []
        self.vodstreams = []
        self.seriesstreams = []
        if self.live:
            req = urllib2.Request(self.LiveStreamsUrl, headers=self.hdr)
            try:
                response = urllib2.urlopen(req)
                self.livestreams = json.load(response, object_pairs_hook=OrderedDict)
            except urllib2.URLError as e:
                pass
            except socket.timeout as e:
                print e

        if self.vod:
            req = urllib2.Request(self.VodStreamsUrl, headers=self.hdr)
            try:
                response = urllib2.urlopen(req)
                self.vodstreams = json.load(response, object_pairs_hook=OrderedDict)
            except urllib2.URLError as e:
                pass
            except socket.timeout as e:
                print e

        if self.series:
            req = urllib2.Request(self.SeriesUrl, headers=self.hdr)
            try:
                response = urllib2.urlopen(req)
                self.seriesstreams = json.load(response, object_pairs_hook=OrderedDict)
            except urllib2.URLError as e:
                print e
            except socket.timeout as e:
                print e

    def getCategories(self):
        if self.live and self.livecategories:
            for c in range(len(self.livecategories)):
                if 'category_id' in self.livecategories[c]:
                    if self.livecategories[c]['category_name'] in self.live_categories:
                        categoryValues = [str(self.livecategories[c]['category_name']),
                         'Live',
                         int(self.livecategories[c]['category_id']),
                         True]
                        self.categories.append(categoryValues)

        if self.vod and self.vodcategories and isinstance(self.vodcategories, list):
            for c in range(len(self.vodcategories)):
                if 'category_id' in self.vodcategories[c]:
                    if self.vodcategories[c]['category_name'] in self.vod_categories:
                        categoryValues = [str(self.vodcategories[c]['category_name']),
                         'VOD',
                         int(self.vodcategories[c]['category_id']),
                         True]
                        self.categories.append(categoryValues)

        if self.series and self.seriescategories and isinstance(self.seriescategories, list):
            for c in range(len(self.seriescategories)):
                if 'category_id' in self.seriescategories[c]:
                    if self.seriescategories[c]['category_name'] in self.series_categories:
                        categoryValues = [str(self.seriescategories[c]['category_name']),
                         'Series',
                         int(self.seriescategories[c]['category_id']),
                         True]
                        self.categories.append(categoryValues)

    def getM3uCategories(self):
        lines = []
        myfile = []
        if self.playlisttype == 'external':
            req = urllib2.Request(self.address, headers=self.hdr)
            try:
                response = urllib2.urlopen(req, timeout=3)
                myfile = response.read()
                lines = myfile.splitlines(True)
            except urllib2.URLError as e:
                print e
            except socket.timeout as e:
                print e

        elif self.playlisttype == 'local':
            with open(cfg.m3ulocation.value + self.address) as f:
                lines = f.readlines()
        prevline = ''
        channelnum = 0
        self.getm3ustreams = []
        for line in lines:
            self.group_title = ''
            self.epg_name = ''
            self.name = ''
            self.source = ''
            if prevline != '':
                if prevline.upper().startswith('#EXTINF') and line.startswith('http'):
                    if re.search('(?<=group-title=")[^"]+', prevline) is not None:
                        self.group_title = re.search('(?<=group-title=")[^"]+', prevline).group()
                    if re.search('(?<=tvg-id=")[^"]+', prevline) is not None:
                        self.epg_name = re.search('(?<=tvg-id=")[^"]+', prevline).group()
                    if re.search('((?<=",).*$|(?<=1,).*$)', prevline) is not None:
                        self.name = re.search('((?<=",).*$|(?<=1,).*$)', prevline).group().strip()
                    if self.name == '':
                        channelnum += 1
                        self.name = 'Channel ' + str(channelnum)
                    self.source = line.rstrip()
                    if self.live:
                        if '.ts' in self.source or '.m3u8' in self.source:
                            if self.group_title == '':
                                self.group_title = 'Uncategorised Live'
                            self.getm3ustreams.append([self.group_title,
                             self.epg_name,
                             self.name,
                             self.source,
                             'live'])
                    if self.vod:
                        if '.ts' not in self.source and '.m3u8' not in self.source:
                            if self.group_title == '':
                                self.group_title = 'Uncategorised VOD'
                            self.getm3ustreams.append([self.group_title,
                             self.epg_name,
                             self.name,
                             self.source,
                             'vod'])
            prevline = line

        return

    def done(self, answer = None):
        self.close()

    def deleteBouquets(self):
        bouquet_name = self.bouquet_name
        cleanName = re.sub('[^a-zA-Z0-9_\\.]', '_', str(bouquet_name))
        cleanName = re.sub('_+', '_', cleanName)
        with open('/etc/enigma2/bouquets.tv', 'r+') as f:
            new_f = f.readlines()
            f.seek(0)
            for line in new_f:
                if self.live and 'jmx_live_' + str(cleanName) in line:
                    continue
                if self.vod and 'jmx_vod_' + str(cleanName) in line:
                    continue
                if self.series and 'jmx_series_' + str(cleanName) in line:
                    continue
                f.write(line)

            f.truncate()
        if self.live:
            self.purge('/etc/enigma2', 'jmx_live_' + str(cleanName))
            if os.path.isdir('/etc/epgimport/'):
                self.purge('/etc/epgimport', 'jmx_' + str(cleanName))
            if os.path.isfile(self.bouquetfile):
                if os.stat(self.bouquetfile).st_size > 0:
                    with open(self.bouquetfile) as f:
                        self.bouquetdata = json.load(f, object_pairs_hook=OrderedDict)
                        if len(self.bouquetdata) == 0:
                            cfg.unique.value = 1000
                            cfg.unique.save()
        if self.vod:
            self.purge('/etc/enigma2', 'jmx_vod_' + str(cleanName))
        if self.series:
            self.purge('/etc/enigma2', 'jmx_series_' + str(cleanName))

    def updateBouquetJsonFile(self):
        self.selectedCategories = self.categories
        bouquet_values = {}
        bouquet_values['live_categories'] = []
        bouquet_values['vod_categories'] = []
        bouquet_values['series_categories'] = []
        if self.playlisttype == 'xtream':
            for category in self.selectedCategories:
                if category[1] == 'Live':
                    bouquet_values['live_categories'].append(category[0])
                elif category[1] == 'VOD':
                    bouquet_values['vod_categories'].append(category[0])
                elif category[1] == 'Series':
                    bouquet_values['series_categories'].append(category[0])

        else:
            for category in self.getm3ustreams:
                if category[4] == 'live':
                    bouquet_values['live_categories'].append(category[0])
                elif category[4] == 'vod':
                    bouquet_values['vod_categories'].append(category[0])

        if self.live:
            self.bouquetdata[self.x]['live_categories'] = bouquet_values['live_categories']
            self.bouquetdata[self.x]['liveupdate'] = datetime.now().strftime('%c')
        if self.vod:
            self.bouquetdata[self.x]['vod_categories'] = bouquet_values['vod_categories']
            self.bouquetdata[self.x]['vodupdate'] = datetime.now().strftime('%c')
        if self.series:
            self.bouquetdata[self.x]['series_categories'] = bouquet_values['series_categories']
            self.bouquetdata[self.x]['seriesupdate'] = datetime.now().strftime('%c')
        filename = '/etc/enigma2/jediplaylists/bouquet_info_v2.json'
        with open(filename, 'w') as f:
            json.dump(self.bouquetdata, f)

    def purge(self, dir, pattern):
        for f in os.listdir(dir):
            file_path = os.path.join(dir, f)
            if os.path.isfile(file_path):
                if re.search(pattern, f):
                    os.remove(file_path)

    def replace_all(self, text, dic):
        for i, j in dic.iteritems():
            text = text.replace(i, j)

        return text

    def buildBouquets(self):
        self.deleteBouquets()
        self.updateBouquetJsonFile()
        self.selectedCategories = self.categories
        self.epg_name_list = []
        for x in self.selectedCategories:
            cat_name = x[0]
            cat = x[1]
            cat_id = x[2]
            self.streamvaluesgroup = []
            self.streamvalues = []
            self.bouquetTitle = self.bouquet_name + ' - ' + str(cat_name)
            self.bouquetString = '#NAME ' + str(self.bouquetTitle) + '\n'
            service_type = 1
            domain = self.domain
            port = self.port
            username = self.username
            password = self.password
            protocol = self.protocol.replace(':', '%3a')
            if cat == 'Live':
                player_type = self.live_type
                self.streamvalues = [ stream for stream in self.livestreams if str(cat_id) == str(stream['category_id']) ]
                self.streamvaluesgroup += self.streamvalues
                stream_type = 'live'
                output = 'ts'
                replacements = {'e !': 'e!',
                 'granda': 'granada',
                 'sly': 'sky',
                 's3y': 'sky'}
                for i in range(len(self.streamvaluesgroup)):
                    listOfKeys = []
                    epgid = False
                    tempname = str(self.streamvaluesgroup[i]['name']).strip().lower()
                    tempname = self.replace_all(tempname, replacements)
                    tempname = re.sub('\\|.+\\|', '', tempname)
                    tempname = re.sub('\\(.+\\)', '', tempname)
                    tempname = re.sub('(fhd|full hd|1080p|1080|4k|uhd|\xca\x9c\xe1\xb4\x85)', 'hd ', tempname)
                    tempname = re.sub('[^a-zA-Z0-9\\u00C0-\\u00FF \\/\\_\\.\\:\\!\\+\\-\\(\\)\\|\\&]', '', tempname)
                    tempname = re.sub('(uk[^A-Za-z0-9]+|uki[^A-Za-z0-9]+|ir[^A-Za-z0-9]+|ire[^A-Za-z0-9]+|sd|720p|720|local|british|backup|ppv|vip|pdc|\\||\\-|\\*|\\_|)', '', tempname)
                    tempname = tempname.strip('.').strip()
                    words = tempname.split()
                    tempname = ' '.join(sorted(set(words), key=words.index))
                    found = False
                    self.reference = ''
                    for line in self.epgnames2:
                        for item in line:
                            if tempname == item:
                                self.reference = str(line[0])
                                found = True
                                break

                        if found:
                            break

                    channelname = ''
                    serviceref = ''
                    for line in self.rytecchannels:
                        channelname = re.search('(?<=<\\/channel><!-- ).*(?= --)', line).group()
                        serviceref = re.search('(?<=">1).*(?=<\\/)', line).group()
                        if channelname != '' and serviceref != '' and self.reference.lower() == channelname.lower():
                            if re.search('(?<=id=")[a-zA-Z0-9\\.]+', line) is not None:
                                epg_channel_id = re.search('(?<=id=")[a-zA-Z0-9\\.]+', line).group()
                            else:
                                epg_channel_id = ''
                            epgid = True
                            break

                    if epgid:
                        custom_sid = serviceref
                        print 'channel name ' + str(channelname) + '\n'
                        print 'serviceref ' + str(serviceref) + '\n'
                        print 'epg_channel_id ' + str(epg_channel_id) + '\n'
                    elif re.match(':\\d+:\\d+:[a-zA-Z0-9]+:[a-zA-Z0-9]+:[a-zA-Z0-9]+:[a-zA-Z0-9]+:0:0:0:', str(self.streamvaluesgroup[i]['custom_sid'])):
                        custom_sid = self.streamvaluesgroup[i]['custom_sid']
                    elif re.match(':\\d+:\\d+:[a-zA-Z0-9]+:[a-zA-Z0-9]+:[a-zA-Z0-9]+:[a-zA-Z0-9]+:0:0:', str(self.streamvaluesgroup[i]['custom_sid'])):
                        custom_sid = str(self.streamvaluesgroup[i]['custom_sid']) + str('0:')
                    else:
                        custom_sid = ':0:' + str(service_type) + ':' + '666' + ':' + str(self.unique_ref) + ':0:0:0:0:0:'
                        self.unique_ref += 1
                        cfg.unique.value = self.unique_ref
                        cfg.unique.save()
                    stream_id = self.streamvaluesgroup[i]['stream_id']
                    source = str(player_type) + str(custom_sid) + str(protocol) + str(domain) + '%3a' + str(port) + '/' + str(stream_type) + '/' + str(username) + '/' + str(password) + '/' + str(stream_id) + '.' + str(output)
                    source_epg = '1' + str(custom_sid) + str(protocol) + str(domain) + '%3a' + str(port) + '/' + str(stream_type) + '/' + str(username) + '/' + str(password) + '/' + str(stream_id) + '.' + str(output)
                    if epgid:
                        self.epg_name_list.append([str(epg_channel_id), source_epg])
                    elif self.streamvaluesgroup[i]['epg_channel_id']:
                        self.epg_name_list.append([str(self.streamvaluesgroup[i]['epg_channel_id']), source_epg])
                    name = self.streamvaluesgroup[i]['name']
                    self.bouquetString += '#SERVICE ' + source + ':' + str(name) + '\n'
                    self.bouquetString += '#DESCRIPTION ' + str(name) + '\n'

                self.createBouquetXmlFile('live')
                self.addBouquetsTV('live')
            elif cat == 'VOD':
                player_type = self.vod_type
                self.streamvalues = [ stream for stream in self.vodstreams if str(cat_id) == str(stream['category_id']) ]
                self.streamvalues = sorted(self.streamvalues, key=lambda s: s['name'])
                self.streamvaluesgroup += self.streamvalues
                stream_type = 'movie'
                custom_sid = ':0:1:0:0:0:0:0:0:0:'
                for i in range(len(self.streamvaluesgroup)):
                    stream_id = self.streamvaluesgroup[i]['stream_id']
                    output = str(self.streamvaluesgroup[i]['container_extension'])
                    source = str(player_type) + str(custom_sid) + str(protocol) + str(domain) + '%3a' + str(port) + '/' + str(stream_type) + '/' + str(username) + '/' + str(password) + '/' + str(stream_id) + '.' + str(output)
                    source_epg = '1' + str(custom_sid) + str(protocol) + str(domain) + '%3a' + str(port) + '/' + str(stream_type) + '/' + str(username) + '/' + str(password) + '/' + str(stream_id) + '.' + str(output)
                    name = self.streamvaluesgroup[i]['name']
                    self.bouquetString += '#SERVICE ' + source + ':' + str(name) + '\n'
                    self.bouquetString += '#DESCRIPTION ' + str(name) + '\n'

                self.createBouquetXmlFile('vod')
                self.addBouquetsTV('vod')
            elif cat == 'Series':
                player_type = self.vod_type
                self.streamvalues = [ stream for stream in self.seriesstreams if str(cat_id) == str(stream['category_id']) ]
                self.streamvalues = sorted(self.streamvalues, key=lambda s: s['name'])
                self.streamvaluesgroup += self.streamvalues
                stream_type = 'series'
                custom_sid = ':0:1:0:0:0:0:0:0:0:'
                for i in range(len(self.streamvaluesgroup)):
                    name = self.streamvaluesgroup[i]['name']
                    if cat_name in self.m3uValues:
                        for channel in self.m3uValues[cat_name]:
                            source = str(player_type) + str(custom_sid) + channel['url'].replace(':', '%3a')
                            self.bouquetString += '#SERVICE ' + source + ':' + channel['name'] + '\n'
                            self.bouquetString += '#DESCRIPTION ' + channel['name'] + '\n'

                        break

                self.createBouquetXmlFile('series')
                self.addBouquetsTV('series')

        if self.live and os.path.isdir('/usr/lib/enigma2/python/Plugins/Extensions/EPGImport') and os.path.isdir('/etc/epgimport/'):
            self.buildXMLTVChannelFile()
            self.buildXMLTVSourceFile()
        return

    def createBouquetXmlFile(self, streamtype):
        cleanTitle = re.sub('[^a-zA-Z0-9_\\.]', '_', self.bouquetTitle)
        cleanTitle = re.sub('_+', '_', cleanTitle)
        filepath = '/etc/enigma2/'
        filename = 'userbouquet.jmx_' + str(streamtype) + '_' + str(cleanTitle) + '.tv'
        fullpath = filepath + filename
        with open(fullpath, 'w+') as f:
            f.write(self.bouquetString)

    def addBouquetsTV(self, streamtype):
        cleanTitle = re.sub('[^a-zA-Z0-9_\\.]', '_', self.bouquetTitle)
        cleanTitle = re.sub('_+', '_', cleanTitle)
        filename = 'userbouquet.jmx_' + str(streamtype) + '_' + str(cleanTitle) + '.tv'
        with open('/etc/enigma2/bouquets.tv', 'a+') as f:
            bouquetTvString = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "' + filename + '" ORDER BY bouquet\r\n'
            if bouquetTvString not in f:
                f.write(bouquetTvString)

    def reloadBouquet(self):
        eDVBDB.getInstance().reloadServicelist()
        eDVBDB.getInstance().reloadBouquets()

    def buildXMLTVChannelFile(self):
        cleanName = re.sub('[^a-zA-Z0-9_\\.]', '_', str(self.bouquet_name))
        cleanName = re.sub('_+', '_', cleanName)
        epgfilepath = '/etc/epgimport/'
        epgfilename = 'jmx.' + str(cleanName) + '.channels.xml'
        self.channelpath = epgfilepath + epgfilename
        bouquetfilepath = '/etc/enigma2/'
        root = ET.Element('channels')
        if not os.path.isfile(self.channelpath):
            open(self.channelpath, 'a').close()
            for i in range(len(self.epg_name_list)):
                newchannel = ET.SubElement(root, 'channel')
                newchannel.set('id', self.epg_name_list[i][0])
                newchannel.text = self.epg_name_list[i][1]

            xml_str = str(ET.tostring(root, 'utf-8'))
            doc = minidom.parseString(xml_str)
            xml_output = doc.toprettyxml(encoding='utf-8', indent='')
            xml_output = os.linesep.join([ s for s in xml_output.splitlines() if s.strip() ])
            with open(self.channelpath, 'w') as f:
                f.write(xml_output)
        else:
            tree = ET.parse(self.channelpath)
            root = tree.getroot()
            e = str(ET.tostring(root, 'utf-8'))
            for channel in root.findall('channel'):
                root.remove(channel)

            for i in range(len(self.epg_name_list)):
                newchannel = ET.SubElement(root, 'channel')
                newchannel.set('id', self.epg_name_list[i][0])
                newchannel.text = self.epg_name_list[i][1]

            xml_str = str(ET.tostring(root, 'utf-8'))
            doc = minidom.parseString(xml_str)
            xml_output = doc.toprettyxml(encoding='utf-8', indent='')
            xml_output = os.linesep.join([ s for s in xml_output.splitlines() if s.strip() ])
            with open(self.channelpath, 'w') as f:
                f.write(xml_output)

    def buildXMLTVSourceFile(self):
        if self.xmltv != '':
            cleanName = re.sub('[^a-zA-Z0-9_\\.]', '_', str(self.bouquet_name))
            cleanName = re.sub('_+', '_', cleanName)
            filepath = '/etc/epgimport/'
            filename = 'jmx.' + str(cleanName) + '.sources.xml'
            self.sourcepath = filepath + filename
            with open(self.sourcepath, 'w') as f:
                xml_str = '<?xml version="1.0" encoding="utf-8"?>\n'
                xml_str += '<sources>\n'
                xml_str += '<sourcecat sourcecatname="IPTV ' + str(cleanName) + '">\n'
                xml_str += '<source type="gen_xmltv" nocheck="1" channels="' + self.channelpath + '">\n'
                xml_str += '<description>' + str(cleanName) + '</description>\n'
                xml_str += '<url><![CDATA[' + str(self.xmltv) + ']]></url>\n'
                xml_str += '</source>\n'
                xml_str += '</sourcecat>\n'
                xml_str += '</sources>\n'
                f.write(xml_str)

    def buildM3uBouquets(self):
        self.deleteBouquets()
        self.updateBouquetJsonFile()
        self.epg_name_list = []
        self.service_type = 1
        mem.categories = []
        for x in self.getm3ustreams:
            if [x[0], x[4]] not in mem.categories:
                mem.categories.append([x[0], x[4]])

        for z in mem.categories:
            c = z[0]
            self.bouquetTitle = str(self.bouquet_name) + ' - ' + str(c)
            self.bouquetString = '#NAME ' + str(self.bouquetTitle) + '\n'
            self.streamvaluesgroup = []
            self.streamvalues = []
            if z[1] == 'live':
                self.streamvalues = [ stream for stream in self.getm3ustreams if str(z[0]) == str(stream[0]) and str(z[1]) == str(stream[4]) ]
                self.streamvaluesgroup += self.streamvalues
                for m3u in self.streamvaluesgroup:
                    group_title = m3u[0]
                    epg_name = m3u[1]
                    name = m3u[2]
                    source = m3u[3]
                    cat = m3u[4]
                    source = source.replace(':', '%3a')
                    player_type = self.live_type
                    custom_sid = ':0:' + str(self.service_type) + ':' + '666' + ':' + str(self.unique_ref) + ':0:0:0:0:0:'
                    self.unique_ref += 1
                    cfg.unique.value = self.unique_ref
                    cfg.unique.save()
                    source_epg = '1' + str(custom_sid) + source
                    if epg_name:
                        self.epg_name_list.append([epg_name, source_epg])
                    self.bouquetString += '#SERVICE ' + str(player_type) + str(custom_sid) + str(source) + ':' + str(name) + '\n'
                    self.bouquetString += '#DESCRIPTION ' + str(name) + '\n'

                self.createBouquetXmlFile('live')
                self.addBouquetsTV('live')
            elif z[1] == 'vod':
                self.streamvalues = [ stream for stream in self.getm3ustreams if str(z[0]) == str(stream[0]) and str(z[1]) == str(stream[4]) ]
                self.streamvaluesgroup += self.streamvalues
                for m3u in self.streamvaluesgroup:
                    group_title = m3u[0]
                    epg_name = m3u[1]
                    name = m3u[2]
                    source = m3u[3]
                    cat = m3u[4]
                    source = source.replace(':', '%3a')
                    player_type = self.vod_type
                    custom_sid = ':0:1:0:0:0:0:0:0:0:'
                    self.bouquetString += '#SERVICE ' + str(player_type) + str(custom_sid) + str(source) + ':' + str(name) + '\n'
                    self.bouquetString += '#DESCRIPTION ' + str(name) + '\n'

                self.createBouquetXmlFile('vod')
                self.addBouquetsTV('vod')

        if self.live and os.path.isdir('/usr/lib/enigma2/python/Plugins/Extensions/EPGImport') and os.path.isdir('/etc/epgimport/'):
            if self.xmltv != '':
                self.buildXMLTVChannelFile()
                self.buildXMLTVSourceFile()