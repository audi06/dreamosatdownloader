# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/JediMakerXtream/deletebouquets.py
from collections import OrderedDict
from Components.ActionMap import ActionMap
from Components.config import *
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Components.Sources.StaticText import StaticText
from enigma import eDVBDB
from plugin import skin_path, cfg
from Screens.Screen import Screen
import os, json, re
from JediSelectionList import SelectionList, SelectionEntryComponent

class mem:
    pass


class JediMakerXtream_DeleteBouquets(Screen):

    def __init__(self, session):
        self.session = session
        skin = skin_path + 'jmx_bouquets.xml'
        with open(skin, 'r') as f:
            self.skin = f.read()
        self.setup_title = _('Delete Bouquets')
        Screen.__init__(self, session)
        self['key_red'] = StaticText(_('Cancel'))
        self['key_green'] = StaticText(_('Delete'))
        self['key_yellow'] = StaticText(_('Toggle All'))
        self['key_blue'] = StaticText('')
        self['description'] = Label(_('Select all the iptv bouquets you wish to delete. \nPress OK to toggle the selection'))
        self.bouquetfile = '/etc/enigma2/jediplaylists/bouquet_info_v2.json'
        self.bouquets = []
        self.getBouquets()
        self.bouquet_list = [ SelectionEntryComponent(x[0], x[1], x[2], x[3]) for x in self.bouquets ]
        self['list'] = SelectionList(self.bouquet_list, enableWrapAround=True)
        self.onLayoutFinish.append(self.__layoutFinished)
        self['setupActions'] = ActionMap(['SetupActions', 'ColorActions'], {'red': self.keyCancel,
         'green': self.deleteBouquets,
         'yellow': self['list'].toggleAllSelection,
         'save': self.deleteBouquets,
         'cancel': self.keyCancel,
         'ok': self['list'].toggleSelection}, -2)

    def __layoutFinished(self):
        self.setTitle(self.setup_title)

    def ok(self):
        index = self['list'].getIndex()
        self['list'].setIndex(index)

    def keyCancel(self):
        self.close()

    def getBouquets(self):
        if os.path.isfile(self.bouquetfile):
            if os.stat(self.bouquetfile).st_size > 0:
                with open(self.bouquetfile) as f:
                    mem.bouquetdata = json.load(f, object_pairs_hook=OrderedDict)
                    for b in mem.bouquetdata:
                        bouquetValues = [str(b['bouquet_name']),
                         b,
                         '',
                         False]
                        self.bouquets.append(bouquetValues)

    def deleteBouquets(self):
        selectedBouquetList = self['list'].getSelectionsList()
        for x in selectedBouquetList:
            bouquet_name = x[0]
            cleanName = re.sub('[^a-zA-Z0-9_\\.]', '_', str(bouquet_name))
            cleanName = re.sub('_+', '_', cleanName)

        with open('/etc/enigma2/bouquets.tv', 'r+') as f:
            new_f = f.readlines()
            f.seek(0)
            for line in new_f:
                if 'jmx_live_' + str(cleanName) in line:
                    continue
                if 'jmx_vod_' + str(cleanName) in line:
                    continue
                if 'jmx_series_' + str(cleanName) in line:
                    continue
                f.write(line)

            f.truncate()
            self.purge('/etc/enigma2', 'jmx_live_' + str(cleanName))
            self.purge('/etc/enigma2', 'jmx_vod_' + str(cleanName))
            self.purge('/etc/enigma2', 'jmx_series_' + str(cleanName))
            if os.path.isdir('/etc/epgimport/'):
                self.purge('/etc/epgimport', 'jmx.' + str(cleanName))
        eDVBDB.getInstance().reloadServicelist()
        eDVBDB.getInstance().reloadBouquets()
        self.deleteBouquetFile(bouquet_name)
        if len(mem.bouquetdata) == 0:
            cfg.unique.value = 1000
            cfg.unique.save()
            configfile.save()
        self.close()

    def purge(self, dir, pattern):
        for f in os.listdir(dir):
            file_path = os.path.join(dir, f)
            if os.path.isfile(file_path):
                if re.search(pattern, f):
                    os.remove(file_path)

    def deleteBouquetFile(self, bouquet_name):
        bouquetinfo = []
        for b in range(len(mem.bouquetdata)):
            if bouquet_name == mem.bouquetdata[b]['bouquet_name']:
                del mem.bouquetdata[b]
                if mem.bouquetdata == []:
                    try:
                        os.remove(self.bouquetfile)
                    except OSError:
                        pass

                else:
                    with open(self.bouquetfile, 'w') as f:
                        json.dump(mem.bouquetdata, f)
                    break