# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/JediMakerXtream/playlists.py
from collections import OrderedDict
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaBlend
from Components.Sources.StaticText import StaticText
from enigma import getDesktop, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_VALIGN_CENTER, eListboxPythonMultiContent, gFont
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Tools.LoadPixmap import LoadPixmap
from plugin import skin_path, cfg
import re
import json
import urllib2
import os
import addplaylist, info, addbouquet
import socket
screenwidth = getDesktop(0).size()
try:
    os.remove('/etc/enigma2/jediplaylists/file_info.json')
except OSError:
    pass

def PlaylistEntryComponent(index, status, name, extra):
    res = [index]
    if status == 'Active':
        png = LoadPixmap(skin_path + 'images/active.png')
    if status == 'Invalid':
        png = LoadPixmap(skin_path + 'images/invalid.png')
    if status == 'ValidExternal':
        png = LoadPixmap(skin_path + 'images/external.png')
    if status == 'Unknown':
        png = LoadPixmap(skin_path + 'images/blank.png')
    if screenwidth.width() > 1280:
        res.append(MultiContentEntryPixmapAlphaBlend(pos=(18, 13), size=(30, 30), png=png))
        res.append(MultiContentEntryText(pos=(70, 0), size=(840, 56), font=0, flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=name))
        res.append(MultiContentEntryText(pos=(910, 0), size=(431, 56), font=0, flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=extra))
    else:
        res.append(MultiContentEntryPixmapAlphaBlend(pos=(12, 5), size=(20, 20), png=png))
        res.append(MultiContentEntryText(pos=(47, 0), size=(561, 37), font=0, flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=name))
        res.append(MultiContentEntryText(pos=(607, 0), size=(288, 37), font=0, flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=extra))
    return res


class Playlist(MenuList):

    def __init__(self, list):
        MenuList.__init__(self, list, True, eListboxPythonMultiContent)
        if screenwidth.width() > 1280:
            self.l.setFont(0, gFont('jediregular', 36))
            self.l.setItemHeight(56)
        else:
            self.l.setFont(0, gFont('jediregular', 24))
            self.l.setItemHeight(37)


class JediMakerXtream_Playlist(Screen):

    def __init__(self, session):
        self.session = session
        skin = skin_path + 'jmx_playlist.xml'
        with open(skin, 'r') as f:
            self.skin = f.read()
        self.setup_title = _('Playlists')
        Screen.__init__(self, session)
        self['setupActions'] = ActionMap(['ColorActions', 'OkCancelActions'], {'red': self.quit,
         'green': self.addPlaylist,
         'cancel': self.quit}, -2)
        self['key_red'] = StaticText(_('Back'))
        self['key_green'] = StaticText(_('Add Playlist'))
        self['key_yellow'] = StaticText('')
        self['key_blue'] = StaticText('')
        self['key_channelup'] = StaticText('')
        self['key_info'] = StaticText('')
        self['liveupdate'] = Label('')
        self['vodupdate'] = Label('')
        self['seriesupdate'] = Label('')
        self.currentSelection = 0
        self.playlistpath = cfg.location.text + '/playlists.txt'
        self.list = []
        self['playlists'] = Playlist(self.list)
        self.loadPlaylist()
        self.onLayoutFinish.append(self.__layoutFinished)

    def __layoutFinished(self):
        self.setTitle(self.setup_title)

    def loadPlaylist(self):
        if os.path.isfile(self.playlistpath):
            if os.stat(self.playlistpath).st_size > 0:
                self['setupActions'] = ActionMap(['ColorActions',
                 'SetupActions',
                 'TvRadioActions',
                 'ChannelSelectEPGActions'], {'red': self.quit,
                 'green': self.addPlaylist,
                 'yellow': self.editPlaylist,
                 'blue': self.deletePlaylist,
                 'info': self.openUserInfo,
                 'showEPGList': self.openUserInfo,
                 'keyTV': self.createBouquet,
                 'ok': self.createBouquet,
                 'cancel': self.quit}, -2)
                self['key_yellow'] = StaticText(_('Edit Playlist'))
                self['key_blue'] = StaticText(_('Delete Playlist'))
                self['key_info'] = StaticText(_('User Info'))
                self['description'] = Label(_('Press OK to create bouquets. \nView your bouquets by exiting the Jedi plugin and then press the TV button. \nGo into EPG Importer plugin settings, select your playlist in sources... Save... Manually download sources.'))
                self['liveupdate'] = Label(_('Live: ---'))
                self['vodupdate'] = Label(_('Vod: ---'))
                self['seriesupdate'] = Label(_('Series: ---'))
                self.removeBlanks()
                self.checkFile()
                self.getFileValues()
                self.createSetup()
        else:
            open(self.playlistpath, 'a').close()

    def removeBlanks(self):
        with open(self.playlistpath, 'r+') as f:
            lines = f.readlines()
            f.seek(0)
            f.writelines((line.strip(' ') for line in lines if line.strip()))
            f.truncate()

    def checkFile(self):
        print 'checking file'
        if os.path.isfile(self.playlistpath):
            if os.stat(self.playlistpath).st_size > 0:
                with open(self.playlistpath, 'r+') as f:
                    new_f = f.readlines()
                    f.seek(0)
                    for line in new_f:
                        if not line.startswith('http://') and not line.startswith('https://'):
                            line = 'http://' + line
                        f.write(line)

                    f.truncate()

    def getFileValues(self):
        self.file_info = []
        with open(self.playlistpath) as f:
            lines = f.readlines()
            self.index = 0
            for line in lines:
                line = line.rstrip()
                valid = False
                file_info_values = {}
                self.protocol = 'http://'
                self.domain = ''
                self.port = 80
                self.username = ''
                self.password = ''
                self.type = 'm3u_plus'
                self.output = 'ts'
                host = ''
                panel_api = ''
                player_api = ''
                output_format = ''
                filename = ''
                if line.startswith('http://'):
                    self.protocol = 'http://'
                elif line.startswith('https://'):
                    self.protocol = 'https://'
                if re.search('(?<=http:\\/\\/)[a-zA-Z0-9._\\-]+', line) is not None:
                    self.domain = re.search('(?<=http:\\/\\/)[a-zA-Z0-9._\\-]+', line).group()
                if re.search('(?<=https:\\/\\/)[a-zA-Z0-9._\\-]+', line) is not None:
                    self.domain = re.search('(?<=https:\\/\\/)[a-zA-Z0-9._\\-]+', line).group()
                if re.search('(?<=:)(\\d+)(?=\\/)', line) is not None:
                    self.port = int(re.search('(?<=:)(\\d+)(?=\\/)', line).group())
                if re.search('(?<=username=)[ :@.#a-zA-Z0-9_\\-]+', line) is not None:
                    self.username = re.search('(?<=username=)[ :@.#a-zA-Z0-9_\\-]+', line).group()
                if re.search('(?<=password=)[ :@.#a-zA-Z0-9_\\-]+', line) is not None:
                    self.password = re.search('(?<=password=)[ :@.#a-zA-Z0-9_\\-]+', line).group()
                if re.search('(?<=type=)\\w+', line) is not None:
                    self.type = re.search('(?<=type=)[ :@.#a-zA-Z0-9_\\-]+', line).group()
                if re.search('(?<=output=)\\w+', line) is not None:
                    self.output = re.search('(?<=output=)[ :@.#a-zA-Z0-9_\\-]+', line).group()
                host = str(self.protocol) + str(self.domain) + ':' + str(self.port) + '/'
                player_api = str(host) + 'player_api.php?username=' + str(self.username) + '&password=' + str(self.password)
                hdr = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
                 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'}
                req = urllib2.Request(player_api, headers=hdr)
                if 'get.php' in line:
                    if self.domain != '' and self.username != '' and self.password != '':
                        try:
                            response = urllib2.urlopen(req, timeout=3)
                            valid = True
                            try:
                                file_info_values = json.load(response, object_pairs_hook=OrderedDict)
                                if 'message' in file_info_values['user_info']:
                                    del file_info_values['user_info']['message']
                            except:
                                valid = False

                        except urllib2.URLError as e:
                            valid = False
                            print e
                        except socket.timeout as e:
                            valid = False
                            print e

                        file_info_values['local_info'] = {'protocol': self.protocol,
                         'domain': self.domain,
                         'port': self.port,
                         'username': self.username,
                         'password': self.password,
                         'type': self.type,
                         'output': self.output,
                         'address': line,
                         'index': self.index,
                         'playlisttype': 'xtream'}
                elif 'http' in line:
                    try:
                        req = urllib2.Request(line, headers=hdr)
                        response = urllib2.urlopen(req, None, 5)
                        if 'EXTINF' in response.read():
                            valid = True
                        else:
                            valid = False
                    except urllib2.URLError as e:
                        Valid = False
                        print e
                    except socket.timeout as e:
                        print e

                    file_info_values['local_info'] = {'protocol': self.protocol,
                     'address': line,
                     'domain': self.domain,
                     'index': self.index,
                     'playlisttype': 'external'}
                if valid == True:
                    file_info_values['local_info']['valid'] = True
                else:
                    file_info_values['local_info']['valid'] = False
                self.file_info.append(file_info_values)
                self.index += 1

        for filename in os.listdir(cfg.m3ulocation.value):
            valid = False
            file_info_values = {}
            if filename.endswith('.m3u') or filename.endswith('.m3u8'):
                file_info_values['local_info'] = {'address': filename,
                 'domain': '',
                 'index': self.index,
                 'playlisttype': 'local',
                 'valid': True}
                self.file_info.append(file_info_values)
                self.index += 1

        filename = '/etc/enigma2/jediplaylists/file_info.json'
        with open(filename, 'w') as f:
            json.dump(self.file_info, f)
        return

    def createSetup(self):
        self.list = []
        self.bouquetdata = []
        self.bouquetfile = '/etc/enigma2/jediplaylists/bouquet_info_v2.json'
        if os.path.isfile(self.bouquetfile):
            if os.stat(self.bouquetfile).st_size > 0:
                with open(self.bouquetfile) as f:
                    self.bouquetdata = json.load(f)
        for playlist in self.file_info:
            playlisttext = ''
            validstate = 'Invalid'
            if playlist != {}:
                if playlist['local_info']['playlisttype'] == 'xtream':
                    alias = str(playlist['local_info']['domain'])
                else:
                    alias = playlist['local_info']['address']
                for i in range(len(self.bouquetdata)):
                    if self.bouquetdata[i]['address'] == playlist['local_info']['address']:
                        if 'bouquet_name' in self.bouquetdata[i]:
                            alias = self.bouquetdata[i]['bouquet_name']
                        break

                if 'user_info' in playlist:
                    if playlist['user_info']['auth'] == 1:
                        if playlist['user_info']['status'] == 'Active':
                            validstate = 'Active'
                            playlisttext = 'Active: ' + str(playlist['user_info']['active_cons']) + '  Max: ' + str(playlist['user_info']['max_connections'])
                        elif playlist['user_info']['status'] == 'Banned':
                            validstate = 'Invalid'
                            playlisttext = 'Banned'
                        elif playlist['user_info']['status'] == 'Disabled':
                            validstate = 'Invalid'
                            playlisttext = 'Disabled'
                else:
                    if playlist['local_info']['playlisttype'] == 'external' and playlist['local_info']['valid'] == True and playlist['local_info']['domain'] != '':
                        validstate = 'ValidExternal'
                    if playlist['local_info']['playlisttype'] == 'local':
                        validstate = 'Unknown'
                self.list.append(PlaylistEntryComponent(playlist['local_info']['index'], validstate, str(alias), playlisttext))

        self['playlists'].onSelectionChanged.append(self.getCurrentEntry)
        self['playlists'].l.setList(self.list)

    def getCurrentEntry(self):
        self.currentSelection = self['playlists'].getSelectionIndex()
        if os.path.isfile(self.playlistpath):
            if os.stat(self.playlistpath).st_size > 0:
                self['liveupdate'].setText(_('Live: ---'))
                self['vodupdate'].setText(_('Vod: ---'))
                self['seriesupdate'].setText(_('Series: ---'))
                if self.bouquetdata:
                    for b in self.bouquetdata:
                        if b['address'] == self.file_info[self.currentSelection]['local_info']['address']:
                            self['liveupdate'].setText(_(str('Live: ' + b['liveupdate'])))
                            self['vodupdate'].setText(_(str('Vod: ' + b['vodupdate'])))
                            self['seriesupdate'].setText(_(str('Series: ' + b['seriesupdate'])))

    def quit(self):
        self.close()

    def openUserInfo(self):
        if 'user_info' in self.file_info[self.currentSelection]:
            if self.file_info[self.currentSelection]['user_info']['auth'] == 1:
                self.session.open(info.JediMakerXtream_UserInfo, self.file_info[self.currentSelection])
            else:
                self.session.open(MessageBox, _('User no longer authorised!'), MessageBox.TYPE_ERROR, timeout=5)
        else:
            if self.file_info[self.currentSelection]['local_info']['playlisttype'] == 'xtream' and self.file_info[self.currentSelection]['local_info']['valid'] == False:
                self.session.open(MessageBox, _('Url is invalid or playlist/user no longer authorised!'), MessageBox.TYPE_ERROR, timeout=5)
            if self.file_info[self.currentSelection]['local_info']['playlisttype'] == 'external':
                self.session.open(MessageBox, _('User Info not avalable for this playlist\n' + self.file_info[self.currentSelection]['local_info']['address']), MessageBox.TYPE_ERROR, timeout=5)
            if self.file_info[self.currentSelection]['local_info']['playlisttype'] == 'local':
                self.session.open(MessageBox, _('User Info not avalable for this playlist\n' + cfg.m3ulocation.value + self.file_info[self.currentSelection]['local_info']['address']), MessageBox.TYPE_ERROR, timeout=5)

    def refresh(self):
        self.removeBlanks()
        self.getFileValues()
        self.createSetup()

    def addPlaylist(self):
        self.session.openWithCallback(self.refresh, addplaylist.JediMakerXtream_AddPlaylist, False, None)
        return

    def editPlaylist(self):
        if self.file_info[self.currentSelection]['local_info']['playlisttype'] != 'local':
            self.session.openWithCallback(self.refresh, addplaylist.JediMakerXtream_AddPlaylist, True, self.file_info[self.currentSelection])
        else:
            self.session.open(MessageBox, _('Edit unavailable for local M3Us.\nManually Delete/Amend M3U files in folder.\n' + cfg.m3ulocation.value), MessageBox.TYPE_ERROR, timeout=5)

    def deletePlaylist(self, answer = None):
        if self.file_info[self.currentSelection]['local_info']['playlisttype'] != 'local':
            if answer is None:
                self.session.openWithCallback(self.deletePlaylist, MessageBox, _('Permanently delete selected playlist?'))
            elif answer:
                with open(self.playlistpath, 'r+') as f:
                    lines = f.readlines()
                    del lines[self.currentSelection]
                    f.seek(0)
                    for line in lines:
                        f.write(line)

                    f.truncate()
                    f.close()
                self.refresh()
        else:
            self.session.open(MessageBox, _('Delete unavailable for local M3Us.\nManually Delete/Amend M3U files in folder.\n' + cfg.m3ulocation.value), MessageBox.TYPE_ERROR, timeout=5)
        return

    def createBouquet(self):
        if 'user_info' in self.file_info[self.currentSelection]:
            if self.file_info[self.currentSelection]['user_info']['auth'] == 1:
                if self.file_info[self.currentSelection]['user_info']['status'] == 'Active':
                    self.session.openWithCallback(self.refresh, addbouquet.JediMakerXtream_Bouquets, self.file_info[self.currentSelection])
                else:
                    self.session.open(MessageBox, _('Playlist is ' + str(self.file_info[self.currentSelection]['user_info']['status'])), MessageBox.TYPE_ERROR, timeout=10)
            else:
                self.session.open(MessageBox, _('User no longer authorised!'), MessageBox.TYPE_ERROR, timeout=5)
        elif 'local_info' in self.file_info[self.currentSelection]:
            if self.file_info[self.currentSelection]['local_info']['valid'] == True:
                self.session.openWithCallback(self.refresh, addbouquet.JediMakerXtream_Bouquets, self.file_info[self.currentSelection])
            else:
                self.session.open(MessageBox, _('Url is invalid or playlist/user no longer authorised!'), MessageBox.TYPE_ERROR, timeout=5)