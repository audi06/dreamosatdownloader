# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/JediMakerXtream/menu.py
from Components.ActionMap import ActionMap
from Components.config import *
from Components.MenuList import MenuList
from Components.Sources.StaticText import StaticText
from enigma import eDVBDB
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from plugin import skin_path, cfg
import os
import re
import json
from collections import OrderedDict
import deletebouquets, playlists, settings, about, update

class JediMakerXtream_Menu(Screen):

    def __init__(self, session):
        self.session = session
        skin = skin_path + 'jmx_mainmenu.xml'
        with open(skin, 'r') as f:
            self.skin = f.read()
        self.setup_title = _('Main Menu')
        Screen.__init__(self, session)
        self['actions'] = ActionMap(['ColorActions', 'OkCancelActions', 'MenuActions'], {'ok': self.openSelected,
         'cancel': self.quit,
         'red': self.quit,
         'menu': self.quit})
        self['key_red'] = StaticText(_('Close'))
        self.currentSelection = 0
        self.list = []
        self['menu'] = MenuList(self.list)
        self.bouquetfile = '/etc/enigma2/jediplaylists/bouquet_info_v2.json'
        self.createSetup()
        self.onLayoutFinish.append(self.__layoutFinished)

    def __layoutFinished(self):
        self.setTitle(self.setup_title)

    def createSetup(self):
        self.list = []
        self.list.append((_('Playlists'), 'm_playlists'))
        self.list.append((_('Settings'), 'm_settings'))
        if os.path.isfile(self.bouquetfile):
            if os.stat(self.bouquetfile).st_size > 0:
                with open(self.bouquetfile) as f:
                    self.bouquetdata = json.load(f, object_pairs_hook=OrderedDict)
                if len(self.bouquetdata) > 0:
                    self.list.append((_('Update Bouquets'), 'm_update'))
                    self.list.append((_('Delete Individual Bouquets'), 'm_delete_set'))
                    self.list.append((_('Delete All Jedi IPTV Bouquets'), 'm_delete'))
        self.list.append((_('About'), 'm_about'))
        self['menu'].l.setList(self.list)
        self['menu'].onSelectionChanged.append(self.getCurrentEntry)

    def openSelected(self):
        returnValue = self['menu'].getCurrent()[1]
        returnsSelectedIndex = self['menu'].getSelectedIndex()
        returnsSelectionIndex = self['menu'].getSelectionIndex()
        if returnValue is not None:
            if returnValue is 'm_settings':
                self.session.open(settings.JediMakerXtream_Settings)
                return
            if returnValue is 'm_playlists':
                self.session.openWithCallback(self.refresh, playlists.JediMakerXtream_Playlist)
                return
            if returnValue is 'm_delete':
                self.deleteBouquets()
                return
            if returnValue is 'm_delete_set':
                self.session.openWithCallback(self.refresh, deletebouquets.JediMakerXtream_DeleteBouquets)
                return
            if returnValue is 'm_about':
                self.session.openWithCallback(self.refresh, about.JediMakerXtream_About)
                return
            if returnValue is 'm_update':
                self.session.openWithCallback(self.refresh, update.JediMakerXtream_Update, 'manual')
                self.close()
                return
            return
        else:
            return

    def getCurrentEntry(self):
        self.currentSelection = self['menu'].getSelectionIndex()

    def quit(self):
        self.close(False)

    def deleteBouquets(self, answer = None):
        if answer is None:
            self.session.openWithCallback(self.deleteBouquets, MessageBox, _('Permanently delete all Jedi created bouquets?'))
        elif answer:
            with open('/etc/enigma2/bouquets.tv', 'r+') as f:
                new_f = f.readlines()
                f.seek(0)
                for line in new_f:
                    if 'jmx' not in line:
                        f.write(line)

                f.truncate()
            cfg.unique.value = 1000
            cfg.unique.save()
            configfile.save()
            self.purge('/etc/enigma2', 'jmx')
            if os.path.isdir('/etc/epgimport/'):
                self.purge('/etc/epgimport', 'jmx')
            try:
                os.remove('/etc/enigma2/jediplaylists/bouquet_info_v2.json')
            except OSError:
                pass

            eDVBDB.getInstance().reloadServicelist()
            eDVBDB.getInstance().reloadBouquets()
            self.refresh()
        return

    def purge(self, dir, pattern):
        for f in os.listdir(dir):
            file_path = os.path.join(dir, f)
            if os.path.isfile(file_path):
                if re.search(pattern, f):
                    os.remove(file_path)

    def refresh(self):
        self.createSetup()