# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/JediMakerXtream/addplaylist.py
from collections import OrderedDict
from Components.ActionMap import ActionMap, NumberActionMap
from Components.config import *
from Components.ConfigList import ConfigListScreen, ConfigList
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.Sources.StaticText import StaticText
from Components.Sources.List import List
from Components.Sources.Boolean import Boolean
from plugin import skin_path, cfg
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.VirtualKeyBoard import VirtualKeyBoard
import json
import os

class JediMakerXtream_AddPlaylist(ConfigListScreen, Screen):

    def __init__(self, session, editmode, file_info):
        self.session = session
        skin = skin_path + 'jmx_settings.xml'
        with open(skin, 'r') as f:
            self.skin = f.read()
        self.setup_title = _('Add Playlist')
        self.editmode = editmode
        if self.editmode:
            self.setup_title = _('Edit Playlist')
        Screen.__init__(self, session)
        self.xmltv = ''
        self.alias = ''
        self.paylisttype = ''
        self.address = 'http://'
        self.bouquetdata = []
        self.bouquetfile = '/etc/enigma2/jediplaylists/bouquet_info_v2.json'
        self.file_info = file_info
        self.type = 'm3u'
        self.output = 'ts'
        if os.path.isfile(self.bouquetfile):
            if os.stat(self.bouquetfile).st_size > 0:
                with open(self.bouquetfile) as f:
                    self.bouquetdata = json.load(f, object_pairs_hook=OrderedDict)
        if self.editmode:
            if self.bouquetdata:
                for self.currentbouquet in range(len(self.bouquetdata)):
                    if self.file_info['local_info']['address'] == self.bouquetdata[self.currentbouquet]['address']:
                        self.alias = self.bouquetdata[self.currentbouquet]['bouquet_name']
                        self.xmltv = self.bouquetdata[self.currentbouquet]['xmltv']

            if self.file_info['local_info']['playlisttype'] == 'xtream':
                self.protocol = self.file_info['local_info']['protocol']
                self.domain = self.file_info['local_info']['domain']
                self.port = str(self.file_info['local_info']['port'])
                self.username = self.file_info['local_info']['username']
                self.password = self.file_info['local_info']['password']
                self.type = self.file_info['local_info']['type']
                self.output = self.file_info['local_info']['output']
            else:
                self.address = self.file_info['local_info']['address']
        self['actions'] = NumberActionMap(['SetupActions', 'MenuActions', 'OkCancelActions'], {'red': self.cancel,
         'green': self.save,
         'save': self.save,
         'cancel': self.cancel,
         'menu': self.cancel}, -1)
        self['VirtualKB'] = NumberActionMap(['VirtualKeyboardActions'], {'showVirtualKeyboard': self.KeyText}, -2)
        self['VirtualKB'].setEnabled(False)
        self['key_red'] = StaticText(_('Cancel'))
        self['key_green'] = StaticText(_('Save'))
        self['description'] = Label('')
        self['VirtualKB'].setEnabled(False)
        self['HelpWindow'] = Pixmap()
        self['VKeyIcon'] = Pixmap()
        self['HelpWindow'].hide()
        self['VKeyIcon'].hide()
        self.onChangedEntry = []
        self.list = []
        ConfigListScreen.__init__(self, self.list, session=self.session, on_change=self.changedEntry)
        self.createConfig()
        self.createSetup()
        self.onLayoutFinish.append(self.__layoutFinished)

    def __layoutFinished(self):
        self.setTitle(self.setup_title)

    def createConfig(self):
        if self.editmode:
            if self.file_info['local_info']['playlisttype'] == 'xtream':
                self.protocolCfg = NoSave(ConfigSelection(default=self.protocol, choices=[('http://', _('http://')), ('https://', _('https://'))]))
                self.playlisttypeCfg = NoSave(ConfigSelection(default='standard', choices=[('standard', _('Standard Playlist')), ('m3u', _('M3U File'))]))
                self.serverCfg = NoSave(ConfigText(default=self.domain, fixed_size=False))
                self.portCfg = NoSave(ConfigText(default=self.port, fixed_size=False))
                self.usernameCfg = NoSave(ConfigText(default=self.username, fixed_size=False))
                self.passwordCfg = NoSave(ConfigText(default=self.password, fixed_size=False))
                self.outputCfg = NoSave(ConfigSelection(default=self.output, choices=[('ts', _('ts')), ('m3u8', _('m3u8'))]))
            else:
                self.playlisttypeCfg = NoSave(ConfigSelection(default='m3u', choices=[('standard', _('Standard Playlist')), ('m3u', _('M3U File'))]))
                self.addressCfg = NoSave(ConfigText(default=self.address, fixed_size=False))
        else:
            self.playlisttypeCfg = NoSave(ConfigSelection(default='standard', choices=[('standard', _('Standard Playlist')), ('m3u', _('M3U File'))]))
            self.protocolCfg = NoSave(ConfigSelection(default='http://', choices=[('http', _('http://')), ('https', _('https://'))]))
            self.serverCfg = NoSave(ConfigText(default='domain.xyz', fixed_size=False))
            self.portCfg = NoSave(ConfigText(default='80', fixed_size=False))
            self.usernameCfg = NoSave(ConfigText(default='username', fixed_size=False))
            self.passwordCfg = NoSave(ConfigText(default='password', fixed_size=False))
            self.outputCfg = NoSave(ConfigSelection(default=self.output, choices=[('ts', _('ts')), ('m3u8', _('m3u8'))]))
            self.addressCfg = NoSave(ConfigText(default=self.address, fixed_size=False))

    def createSetup(self):
        self.list = []
        if not self.editmode:
            self.list.append(getConfigListEntry(_('Select playlist type'), self.playlisttypeCfg, _('\nSelect the type of playlist to add. Standard playlist or external M3U file.\nTry M3U File for non standard playlists that use custom urls.')))
            if self.playlisttypeCfg.value == 'standard':
                self.list.append(getConfigListEntry(_('Protocol'), self.protocolCfg, _('\nSelect the protocol for your playlists url.')))
                self.list.append(getConfigListEntry(_('Server URL'), self.serverCfg, _('\nEnter playlist url without protocol http:// \ne.g. domain.xyz')))
                self.list.append(getConfigListEntry(_('Port'), self.portCfg, _('\nEnter Port Number without colon : \ne.g. 25461')))
                self.list.append(getConfigListEntry(_('Username'), self.usernameCfg, _('\nEnter username.')))
                self.list.append(getConfigListEntry(_('Password'), self.passwordCfg, _('\nEnter password.')))
                self.list.append(getConfigListEntry(_('Output Type'), self.outputCfg, _('\nEnter stream output type.')))
            else:
                self.list.append(getConfigListEntry(_('M3U external location'), self.addressCfg, _('\nEnter M3U list url including protocol. \neg. http://www.domain.xyz')))
        elif self.file_info['local_info']['playlisttype'] == 'xtream':
            self.list.append(getConfigListEntry(_('Protocol'), self.protocolCfg, _('\nSelect the protocol for your playlists url.')))
            self.list.append(getConfigListEntry(_('Server URL'), self.serverCfg, _('\nEnter playlist url without protocol http:// \ne.g. domain.xyz')))
            self.list.append(getConfigListEntry(_('Port'), self.portCfg, _('\nEnter Port Number without colon : \ne.g. 25461')))
            self.list.append(getConfigListEntry(_('Username'), self.usernameCfg, _('\nEnter username.')))
            self.list.append(getConfigListEntry(_('Password'), self.passwordCfg, _('\nEnter password.')))
            self.list.append(getConfigListEntry(_('Output Type'), self.outputCfg, _('\nEnter stream output type.')))
        else:
            self.list.append(getConfigListEntry(_('M3U external location'), self.addressCfg, _('\nEnter M3U list url including protocol. \neg. http://www.domain.xyz')))
        self['config'].list = self.list
        self['config'].l.setList(self.list)
        self.handleInputHelpers()

    def handleInputHelpers(self):
        if self['config'].getCurrent() is not None:
            if isinstance(self['config'].getCurrent()[1], ConfigText) or isinstance(self['config'].getCurrent()[1], ConfigPassword):
                if 'VKeyIcon' in self:
                    self['VirtualKB'].setEnabled(True)
                    self['VKeyIcon'].show()
            elif 'VKeyIcon' in self:
                self['VirtualKB'].setEnabled(False)
                self['VKeyIcon'].hide()
        elif 'VKeyIcon' in self:
            self['VirtualKB'].setEnabled(False)
            self['VKeyIcon'].hide()
        return

    def KeyText(self):
        self.currentConfigIndex = self['config'].getCurrentIndex()
        self['HelpWindow'].hide()
        self.session.openWithCallback(self.VirtualKeyBoardCallback, VirtualKeyBoard, title=self['config'].getCurrent()[0], text=self['config'].getCurrent()[1].value)

    def changedEntry(self):
        self.item = self['config'].getCurrent()
        for x in self.onChangedEntry:
            x()

        try:
            if isinstance(self['config'].getCurrent()[1], ConfigSelection):
                self.createSetup()
        except:
            pass

    def save(self):
        if self['config'].isChanged():
            for x in self['config'].list:
                x[1].save()

        if self.playlisttypeCfg.value == 'standard':
            if self.serverCfg.value.startswith('http://'):
                self.serverCfg.value = self.serverCfg.value.replace('http://', '')
            if self.serverCfg.value.startswith('https://'):
                self.serverCfg.value = self.serverCfg.value.replace('https://', '')
            if self.portCfg.value.startswith(':'):
                self.portCfg.value = self.portCfg.value.replace(':', '')
            self.serverCfg.value = self.serverCfg.value.strip()
            self.portCfg.value = self.portCfg.value.strip()
            self.usernameCfg.value = self.usernameCfg.value.strip()
            self.passwordCfg.value = self.passwordCfg.value.strip()
            self.outputCfg.value = self.outputCfg.value.strip()
        elif self.addressCfg.value != 'http://' or self.addressCfg.value != '':
            self.addressCfg.value = self.addressCfg.value.strip()
        if self.editmode:
            self.editEntry()
        else:
            self.createNewEntry()
        configfile.save()
        self.close()

    def cancel(self, answer = None):
        if answer is None:
            if self['config'].isChanged():
                self.session.openWithCallback(self.cancel, MessageBox, _('Really close without saving settings?'))
            else:
                self.close()
        elif answer:
            for x in self['config'].list:
                x[1].cancel()

            self.close()
        return

    def createNewEntry(self):
        playlistfile = 'playlists.txt'
        playlistpath = cfg.location.text + '/' + playlistfile
        if self.playlisttypeCfg.value == 'standard':
            self.newEntry = '\n' + str(self.protocolCfg.value) + str(self.serverCfg.value) + ':' + str(self.portCfg.value) + '/get.php?username=' + str(self.usernameCfg.value) + '&password=' + str(self.passwordCfg.value) + '&type=' + self.type + '&output=' + str(self.outputCfg.value) + '\n'
        else:
            self.newEntry = '\n' + str(self.addressCfg.value)
        with open(playlistpath, 'a') as f:
            f.write(self.newEntry)
            f.close()

    def editEntry(self):
        playlistfile = 'playlists.txt'
        playlistpath = cfg.location.text + '/' + playlistfile
        if self.playlisttypeCfg.value == 'standard':
            oldEntry = str(self.protocol) + str(self.domain) + ':' + str(self.port) + '/get.php?username=' + str(self.username) + '&password=' + str(self.password) + '&type=' + str(self.type) + '&output=' + str(self.output)
            self.editEntry = '\n' + str(self.protocolCfg.value) + str(self.serverCfg.value) + ':' + str(self.portCfg.value) + '/get.php?username=' + str(self.usernameCfg.value) + '&password=' + str(self.passwordCfg.value) + '&type=' + str(self.type) + '&output=' + str(self.outputCfg.value)
        else:
            oldEntry = self.address
            self.editEntry = '\n' + str(self.addressCfg.value)
        with open(playlistpath, 'r+') as f:
            new_f = f.readlines()
            f.seek(0)
            for line in new_f:
                if line.startswith(oldEntry):
                    line = self.editEntry
                f.write(line)

            f.truncate()