# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/JediMakerXtream/__init__.py
pass