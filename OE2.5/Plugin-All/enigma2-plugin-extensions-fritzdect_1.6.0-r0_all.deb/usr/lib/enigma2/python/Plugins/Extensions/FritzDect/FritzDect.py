#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#######################################################################
#
# FritzDect for VU+ by schomi (c)2016
# www.vuplus-support.org
# adapted for DreamOS by gutemine
#
# This plugin is licensed under the Creative Commons
# Attribution-NonCommercial-ShareAlike 3.0 Unported License.
# To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/
# or send a letter to Creative Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#
# This plugin is NOT free software. It is open source, you are allowed to
# modify it (if you keep the license), but it may not be commercially
# distributed other than under the conditions noted above.
#
####################################################################### 
pname = _("FritzDect")
pdesc = _("Switch Fritz Dect Adapters")
pversion = "v1.6"
pdate = "20170211"

from Components.ActionMap import ActionMap, HelpableActionMap
from Components.AVSwitch import AVSwitch
from Components.Button import Button
from Components.config import config, configfile, ConfigSelection, ConfigPassword, ConfigSubsection, ConfigText, ConfigYesNo, getConfigListEntry
from Components.ConfigList import ConfigList, ConfigListScreen
from Components.Label import Label
from Components.Sources.List import List
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest, MultiContentEntryPixmapAlphaBlend
from Components.Pixmap import Pixmap
from Components.Sources.StaticText import StaticText
from enigma import eTimer, eRect, loadPNG, eListboxPythonMultiContent, gFont, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, RT_VALIGN_CENTER, RT_VALIGN_TOP, RT_WRAP, getDesktop
from Plugins.Plugin import PluginDescriptor
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.HelpMenu import HelpableScreen
from Tools.Directories import SCOPE_CURRENT_SKIN, SCOPE_CURRENT_PLUGIN, SCOPE_PLUGINS, resolveFilename, fileExists
from Tools.LoadPixmap import LoadPixmap

from logging import NOTSET, DEBUG, INFO, WARNING, ERROR, CRITICAL
import logging

from twisted.web.client import getPage
from xml.dom.minidom import parse, parseString
from urllib import quote, quote_plus, unquote, unquote_plus, urlencode

import time, hashlib
import xml.etree.ElementTree as ET

import base64
import os
from uuid import getnode as get_mac
mac = str(get_mac())
maclen=len(mac)

screensize = getDesktop(0).size().height()

from __init__ import _

config.plugins.FritzDect = ConfigSubsection()
config.plugins.FritzDect.hostname = ConfigText(default="fritz.box", fixed_size=False)
config.plugins.FritzDect.username = ConfigText(default="", fixed_size=False)
config.plugins.FritzDect.password = ConfigPassword(default="", fixed_size=False)
config.plugins.FritzDect.realpassword = ConfigYesNo(default=True)
config.plugins.FritzDect.extended = ConfigYesNo(default=False)
config.plugins.FritzDect.details = ConfigYesNo(default=False)
config.plugins.FritzDect.debug = ConfigYesNo(default=False)
config.plugins.FritzDect.extensionmenu = ConfigYesNo(default=True)
config.plugins.FritzDect.ok = ConfigYesNo(default=True)
config.plugins.FritzDect.groups = ConfigYesNo(default=True)

logger = logging.getLogger("FritzDect")

# Level = NOTSET,DEBUG, INFO, WARNING, ERROR, CRITICAL

if config.plugins.FritzDect.debug.value:
	logger.setLevel(DEBUG)
else:
	logger.setLevel(NOTSET)
fileHandler = logging.FileHandler('/tmp/FritzDect.log', mode = 'w')
fileHandler.setFormatter(logging.Formatter('%(asctime)s %(levelname)-8s %(name)-12s %(funcName)-35s %(message)-15s', '%Y-%m-%d %H:%M:%S'))
logger.addHandler(fileHandler)

debug = logger.debug
#info = logger.info
#warn = logger.warn
#error = logger.error
#exception = logger.exception

# Switches
fbSwitch = ["2944","896"]
fbPowerline = ["640"]
fbRepeater = ["1280"]
fbSwitchGroups = ["6784", "4736"]
fbSwitches = fbSwitch + fbPowerline + fbRepeater + fbSwitchGroups

# Heaters
fbHeater =["320"]
fbHeaterGroups =["4160"]
fbHeaters = fbHeater + fbHeaterGroups
	
def AdapaterEntryComponent(manufacturer, productname, fwversion, device_id, functionbitmask, name, ain, state, present, param0, param1, param2, param3, param4):
	res = ()
	text = ""
	status_img = None
	group_img = None
	battery_img = None
	divpng = LoadPixmap(resolveFilename(SCOPE_CURRENT_SKIN, "skin_default/div-h.png"))
	
	# Switches
	if functionbitmask in fbSwitches:
		if state == "1":
			if fileExists(resolveFilename(SCOPE_CURRENT_PLUGIN,"extensions/FritzDect/images/fritzdect_on.png")):
				status_img = LoadPixmap(resolveFilename(SCOPE_CURRENT_PLUGIN,"extensions/FritzDect/images/fritzdect_on.png"))
			else:
				status_img = LoadPixmap(resolveFilename(SCOPE_PLUGINS,"Extensions/FritzDect/images/fritzdect_on.png"))
		else:
			if fileExists(resolveFilename(SCOPE_CURRENT_PLUGIN,"extensions/FritzDect/images/fritzdect_off.png")):
				status_img = LoadPixmap(resolveFilename(SCOPE_CURRENT_PLUGIN,"extensions/FritzDect/images/fritzdect_off.png"))
			else:
				status_img = LoadPixmap(resolveFilename(SCOPE_PLUGINS,"Extensions/FritzDect/images/fritzdect_off.png"))
	# Heaters
	if functionbitmask in fbHeaters:	
		if state == "1":
			if fileExists(resolveFilename(SCOPE_CURRENT_PLUGIN,"extensions/FritzDect/images/comet_on.png")):
				status_img = LoadPixmap(resolveFilename(SCOPE_CURRENT_PLUGIN,"extensions/FritzDect/images/comet_on.png"))
			else:
				status_img = LoadPixmap(resolveFilename(SCOPE_PLUGINS,"Extensions/FritzDect/images/comet_on.png"))
		elif state =="2":
			if fileExists(resolveFilename(SCOPE_CURRENT_PLUGIN,"extensions/FritzDect/images/comet_heat.png")):
				status_img = LoadPixmap(resolveFilename(SCOPE_CURRENT_PLUGIN,"extensions/FritzDect/images/comet_heat.png"))
			else:
				status_img = LoadPixmap(resolveFilename(SCOPE_PLUGINS,"Extensions/FritzDect/images/comet_heat.png"))

		elif state =="3":
			if fileExists(resolveFilename(SCOPE_CURRENT_PLUGIN,"extensions/FritzDect/images/comet_off.png")):
				status_img = LoadPixmap(resolveFilename(SCOPE_CURRENT_PLUGIN,"extensions/FritzDect/images/comet_off.png"))
			else:
				status_img = LoadPixmap(resolveFilename(SCOPE_PLUGINS,"Extensions/FritzDect/images/comet_off.png"))				

		else:
			if fileExists(resolveFilename(SCOPE_CURRENT_PLUGIN,"extensions/FritzDect/images/comet_save.png")):
				status_img = LoadPixmap(resolveFilename(SCOPE_CURRENT_PLUGIN,"extensions/FritzDect/images/comet_save.png"))
			else:
				status_img = LoadPixmap(resolveFilename(SCOPE_PLUGINS,"Extensions/FritzDect/images/comet_save.png"))
	# Groups
	if functionbitmask in fbHeaterGroups or functionbitmask in fbSwitchGroups:	
		if fileExists(resolveFilename(SCOPE_CURRENT_PLUGIN,"extensions/FritzDect/images/fritzdect_group.png")):
			group_img = LoadPixmap(resolveFilename(SCOPE_CURRENT_PLUGIN,"extensions/FritzDect/images/fritzdect_group.png"))
		else:
			group_img = LoadPixmap(resolveFilename(SCOPE_PLUGINS,"Extensions/FritzDect/images/fritzdect_group.png"))				

	# Battery
	if functionbitmask in fbHeaters:
		if param4 == "1": # Battery low
			if fileExists(resolveFilename(SCOPE_CURRENT_PLUGIN,"extensions/FritzDect/images/battery.png")):
				battery_img = LoadPixmap(resolveFilename(SCOPE_CURRENT_PLUGIN,"extensions/FritzDect/images/battery.png"))
			else:
				battery_img = LoadPixmap(resolveFilename(SCOPE_PLUGINS,"Extensions/FritzDect/images/battery.png"))			
			
	if config.plugins.FritzDect.extended.value == True:
		# Switches
		if functionbitmask in fbSwitch:
			temp = float(param0)/10
			energy = float(param1)/1000
			power = float(param2)/1000
			text = " (%.1f�C, %.1fW, %.1fkWh)" % (temp, power, energy)
		
		# Group Dect
		if functionbitmask in fbSwitchGroups:
			#temp = float(param0)/10
			energy = float(param1)/1000
			power = float(param2)/1000
			text = " (%.1fW, %.1fkWh)" % (power, energy)

		# Heater2
		if functionbitmask in fbHeater:
			temp = float(param0)/2
			tempsoll = float(param1)/2
			tempist = float(param2)/2
			text = " (%.1f�C <= %.1f�C)" % (temp,tempsoll)			

		# Heater
		if functionbitmask in fbHeaterGroups:
			temp = float(param0)/2
			tempsoll = float(param1)/2
			tempist = float(param2)/2
			text = " (%.1f�C <= %.1f�C)" % (temp,tempsoll)		
			
		# Powerline
		if functionbitmask in fbPowerline:
			#temp = float(param0)/10
			energy = float(param1)/1000
			power = float(param2)/1000
			text = " (%.1fW, %.1fkWh)" % (power, energy)
			
		# Repeater
		if functionbitmask in fbRepeater:
			temp = float(param0)/10
			#energy = float(param1)/1000
			#power = float(param2)/1000
			text = " (%.1f�C)" % (temp)			
		
	res = (manufacturer, productname, fwversion, device_id, functionbitmask, name, ain, state, present, param0, param1, param2, param3, status_img, group_img, text, divpng, battery_img)
	debug("Adapter Entry: %s", res)
	return res
	
### Main

class FritzDectMain(Screen, HelpableScreen):
	debug("Infos: %s, %s, %s", pname, pversion, pdate)
	if screensize <= 720:
		skin = """
		<screen position="20,60" size="1240,600" title="FritzDect" backgroundColor ="#ffffffff" flags="wfNoBorder">
			<widget source="adapterlist" render="Listbox" position="0,0" size="720,660" transparent="1" scrollbarMode="showNever" enableWrapAround="1">
				<convert type="TemplatedMultiContent">
				{"templates":
					{"default": (60,[
						MultiContentEntryPixmapAlphaBlend(pos = (5, 5), size = (50, 50), png = 13), # index 13 is the status PNG
						MultiContentEntryPixmapAlphaBlend(pos = (35, 35), size = (20, 20), png = 14), # index 14 is the group PNG
						MultiContentEntryPixmapAlphaBlend(pos = (35, 5), size = (20, 20), png = 17), # index 17 is the battery PNG
						MultiContentEntryText(pos = (60, 0), size = (630, 60), font=0, flags = RT_HALIGN_LEFT | RT_VALIGN_CENTER, text = 5), # index 5 is the ainname
						MultiContentEntryPixmapAlphaTest(pos = (0, 58), size = (0, 0), png = 16), # index 16 is the div pixmap
						]),
					"extend": (60,[
						MultiContentEntryText(pos = (0, 0), size = (720, 60), font=0, flags = RT_HALIGN_LEFT | RT_VALIGN_CENTER, backcolor = 0x586d88), # is the background
						MultiContentEntryPixmapAlphaBlend(pos = (5, 5), size = (50, 50), png = 13), # index 13 is the status PNG
						MultiContentEntryPixmapAlphaBlend(pos = (35, 35), size = (20, 20), png = 14), # index 14 is the group PNG
						MultiContentEntryPixmapAlphaBlend(pos = (35, 5), size = (20, 20), png = 17), # index 17 is the battery PNG
						MultiContentEntryText(pos = (60, 0), size = (240, 60), font=0, flags = RT_HALIGN_LEFT | RT_VALIGN_CENTER, text = 5), # index 5 is the ainname
						MultiContentEntryText(pos = (295, 0), size = (400, 60), font=1, flags = RT_HALIGN_RIGHT | RT_VALIGN_CENTER, text = 15), # index 15 is the combined description
						MultiContentEntryPixmapAlphaTest(pos = (0, 58), size = (720, 2), png = 16), # index 16 is the div pixmap
				])
					},
					"fonts": [gFont("Regular", 26),gFont("Regular", 24)],
					"itemHeight": 60
				}
				</convert>
			</widget>
			<widget name="info" position="720,0" zPosition="1" size="520,600" font="Regular;24" backgroundColor = "#00586d88" />
		</screen>"""	
	else:	
		skin = """
		<screen position="20,60" size="720,1080" title="FritzDect" backgroundColor ="#ffffffff">
			<widget source="adapterlist" render="Listbox" position="0,0" size="720,440" transparent="1" foregroundColor="#00ffffff" backgroundColor="#00586d88" foregroundColorSelected="#00ffffff" backgroundColorSelected="#00666666" scrollbarMode="showNever" enableWrapAround="1">
				<convert type="TemplatedMultiContent">
				{"templates":
					{"default": (60,[
						MultiContentEntryPixmapAlphaBlend(pos = (5, 5), size = (50, 50), png = 13), # index 13 is the status PNG
						MultiContentEntryPixmapAlphaBlend(pos = (35, 35), size = (20, 20), png = 14), # index 14 is the group PNG
						MultiContentEntryPixmapAlphaBlend(pos = (35, 5), size = (20, 20), png = 17), # index 17 is the battery PNG
						MultiContentEntryText(pos = (60, 0), size = (630, 60), font=0, flags = RT_HALIGN_LEFT | RT_VALIGN_CENTER, text = 5), # index 5 is the ainname
						MultiContentEntryPixmapAlphaTest(pos = (0, 58), size = (0, 0), png = 16), # index 16 is the div pixmap
						]),
					"extend": (60,[
						MultiContentEntryText(pos = (0, 0), size = (720, 60), font=0, flags = RT_HALIGN_LEFT | RT_VALIGN_CENTER, backcolor = 0x586d88), # is the background
						MultiContentEntryPixmapAlphaBlend(pos = (5, 5), size = (50, 50), png = 13), # index 13 is the status PNG
						MultiContentEntryPixmapAlphaBlend(pos = (35, 35), size = (20, 20), png = 14), # index 14 is the group PNG
						MultiContentEntryPixmapAlphaBlend(pos = (35, 5), size = (20, 20), png = 17), # index 17 is the battery PNG						
						MultiContentEntryText(pos = (60, 0), size = (240, 60), font=0, flags = RT_HALIGN_LEFT | RT_VALIGN_CENTER, text = 5), # index 5 is the ainname
						MultiContentEntryText(pos = (295, 0), size = (400, 60), font=1, flags = RT_HALIGN_RIGHT | RT_VALIGN_CENTER, text = 15), # index 15 is the combined description
						MultiContentEntryPixmapAlphaTest(pos = (0, 58), size = (720, 2), png = 16), # index 16 is the div pixmap
				])
					},
					"fonts": [gFont("Regular", 24),gFont("Regular", 22)],
					"itemHeight": 60
				}
				</convert>
			</widget>
			<widget name="info" position="0,460" zPosition="1" size="720,540" font="Regular;24" foregroundColor="#00ffffff" backgroundColor="#00586d88" />
		</screen>"""
	
	def __init__(self, session):
		Screen.__init__(self, session)
		
		self.session = session
		HelpableScreen.__init__(self)

		if config.plugins.FritzDect.ok.value:
			self["Actions"] = HelpableActionMap(self,"FritzDectActions",
			{
				"ok": (self.switch, _("Switch Adapter")),
				"red": (self.close, _("Exit")),
				"green": (self.switchclose, _("Switch Adapter and Close")),
				"cancel": (self.close, _("Exit")),			
				"menu": (self.settingsMenu, _("Settings")),
				"eventview": (self.adapterinfoSwitch, _("Toogle Adapter Information")),
				"right": (self.tempplus, _("Temperature +")),
				"left": (self.tempminus, _("Temperature -")),	
			}, -1)	
		else:			
			self["Actions"] = HelpableActionMap(self,"FritzDectActions",
			{
				"ok": (self.switchclose, _("Switch Adapter and Close")),
				"red": (self.close, _("Exit")),
				"green": (self.switch, _("Switch Adapter")),
				"cancel": (self.close, _("Exit")),			
				"menu": (self.settingsMenu, _("Settings")),
				"eventview": (self.adapterinfoSwitch, _("Toogle Adapter Information")),
				"right": (self.tempplus, _("Temperature +")),
				"left": (self.tempminus, _("Temperature -")),	
			}, -1)
		
		self.login = False
		self.fbSessionId = None
		self.fbChallengeId = None
		self.fbTriedLogin = False
		self.switchandclose = False
		
		self.adapterlist = []
		
		self["adapterlist"] = List()
		self["adapterlist"].setList(self.adapterlist)
		self["adapterlist"].onSelectionChanged.append(self.adapterinfo)
		
		self["info"] = Label("")
		if config.plugins.FritzDect.details.value:
			self.infoOn = 1				
		else:
			self["info"].hide()
			self.infoOn = 0		
		
		self.RefreshTimer = eTimer()
		if os.path.exists("/var/lib/dpkg/status"):                          
			self.RefreshTimer_conn=self.RefreshTimer.timeout.connect(self.getAdapter)
		else:
		    self.RefreshTimer.callback.append(self.getAdapter)
		self.onLayoutFinish.append(self.fblogin)

	def adapterinfoSwitch(self):
		if self.infoOn == 0:	
			self['info'].show()
			self.infoOn = 1
		else:
			self['info'].hide()
			self.infoOn = 0
				
	def adapterinfo(self):
		if not self.adapterlist == []:
			selectedAdapter = self["adapterlist"].getCurrent()
			functionbitmask = selectedAdapter[4]
			debug("Selected Adapter: %s", selectedAdapter)
			# Switches
			if functionbitmask in fbSwitch:
				self["info"].setText(" %s\n %s\n Version: %s\n Device-ID: %s\n Functionbitmask: %s\n Name: %s\n AIN: %s\n Status: %s\n Present: %s\n\n Temp: %.1f�C\n Energy: %.3f kWh\n Power: %.2f W" % (selectedAdapter[0], selectedAdapter[1], selectedAdapter[2], selectedAdapter[3], selectedAdapter[4], selectedAdapter[5], selectedAdapter[6], selectedAdapter[7], selectedAdapter[8], float(selectedAdapter[9])/10, float(selectedAdapter[10])/1000, float(selectedAdapter[11])/1000))					
			
			# Heater and Heater Groups
			if functionbitmask in fbHeaters:
				self["info"].setText(" %s\n %s\n Version: %s\n Device-ID: %s\n Functionbitmask: %s\n Name: %s\n AIN: %s\n Status: %s\n Present: %s\n\n Temp (ist): %.1f �C\n Temp (soll): %.1f �C\n Temp (min.): %.1f �C\n Temp (max.): %.1f �C" % (selectedAdapter[0], selectedAdapter[1], selectedAdapter[2], selectedAdapter[3], selectedAdapter[4], selectedAdapter[5], selectedAdapter[6], selectedAdapter[7], selectedAdapter[8], float(selectedAdapter[9])/2, float(selectedAdapter[10])/2, float(selectedAdapter[11])/2, float(selectedAdapter[12])/2))
			
			# Group Dect and Powerline
			if functionbitmask in (fbSwitchGroups + fbPowerline):
				self["info"].setText(" %s\n %s\n Version: %s\n Device-ID: %s\n Functionbitmask: %s\n Name: %s\n AIN: %s\n Status: %s\n Present: %s\n\n Energy: %.3f kWh\n Power: %.2f W" % (selectedAdapter[0], selectedAdapter[1], selectedAdapter[2], selectedAdapter[3], selectedAdapter[4], selectedAdapter[5], selectedAdapter[6], selectedAdapter[7], selectedAdapter[8], float(selectedAdapter[10])/1000, float(selectedAdapter[11])/1000))
				
			# Repeater
			if functionbitmask in fbRepeater:
				self["info"].setText(" %s\n %s\n Version: %s\n Device-ID: %s\n Functionbitmask: %s\n Name: %s\n AIN: %s\n Status: %s\n Present: %s\n\n Temp: %.1f�C" % (selectedAdapter[0], selectedAdapter[1], selectedAdapter[2], selectedAdapter[3], selectedAdapter[4], selectedAdapter[5], selectedAdapter[6], selectedAdapter[7], selectedAdapter[8], float(selectedAdapter[9])/10))

				
	def fblogin(self):
		self.setTitle(pname + " - " + _("Press Menu for Settings!"))
		self.adapterlist = []
		self.fbTriedLogin = False
		getPage("http://" + config.plugins.FritzDect.hostname.value + "/login_sid.lua", method="GET").addCallback(lambda x: self.fblogin_callback(x))

	def fblogin_password(self):
		self.fbTriedLogin = True
		def buildResponse(challenge, text):
			text = (challenge + '-' + text).decode('utf-8','ignore').encode('utf-16-le')
			for i in range(len(text)):
				if ord(text[i]) > 255:
					text[i] = '.'
			md5 = hashlib.md5()
			md5.update(text)
			debug("Challenge: %s", challenge + '-' + md5.hexdigest())
			return challenge + '-' + md5.hexdigest()
		
		parms = urlencode({
						'username': config.plugins.FritzDect.username.value,
						'response': buildResponse(self.fbChallengeId, base64.b64decode(config.plugins.FritzDect.password.value)[:-maclen]),
						})
						
		getPage("http://" + config.plugins.FritzDect.hostname.value + "/login_sid.lua?sid=" + self.fbSessionId, method="POST", headers={'Content-Type': "application/x-www-form-urlencoded", 'Content-Length': str(len(parms))}, postdata=parms).addCallback(lambda x: self.fblogin_callback(x))
		
	def fblogin_callback(self, sidXml):
		sidX = ET.fromstring(sidXml)
		self.fbSessionId = sidX.find("SID").text
		self.fbChallengeId = sidX.find("Challenge").text
		
		if self.fbSessionId != "0000000000000000":
			self.getAdapter()
		elif self.fbChallengeId and not self.fbTriedLogin:
			self.fblogin_password()
			self.login = True
			self.setTitle(pname + _(" - Connected!"))
		else:
			self.showError("Unexpected login error (maybe username or password incorrect?")
			self.login = False
			self.setTitle(pname + _(" - Not Connected!"))

	def getAdapter(self):
		if self.login == True:
			url = "http://" + config.plugins.FritzDect.hostname.value + "/webservices/homeautoswitch.lua?&switchcmd=getdevicelistinfos&sid=" + self.fbSessionId
			getPage(url, method="GET").addCallback(self.gotAdapter).addErrback(self.showError)
			
	def gotAdapter(self, data=""):
		debug("Devices XML: %s", data)
		self.adapterlist = []
		
		if config.plugins.FritzDect.extended.value == True:
			self["adapterlist"].style = "extend"
		else:
			self["adapterlist"].style = "default"

		xml = ET.fromstring(data)

		if config.plugins.FritzDect.groups.value:
			
			### Adapter Groups
			for group in xml.findall('group'):
				manufacturer=group.attrib['manufacturer']
				productname=group.attrib['productname']
				fwversion=group.attrib['fwversion']
				device_id=group.attrib['id']
				ain=group.attrib['identifier']
				functionbitmask=group.attrib['functionbitmask']

				for node in group.getiterator("present"):
					present=node.text
				if present=="1":
				
					# Group Switches
					if functionbitmask in fbSwitchGroups:
						for node in group.getiterator("name"):
							name=str(node.text)
						#for node in group.getiterator("celsius"):
						#	temp=node.text
						for node in group.getiterator("state"):
							state=node.text
						for node in group.getiterator("energy"):
							energy=node.text
						for node in group.getiterator("power"):
							power=node.text

						debug("Adapterinfos: %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s", manufacturer, "Group Switches", fwversion, device_id, functionbitmask, name, ain, state, present, "NV", energy, power, "NV", "NV")

						self.adapterlist.append(AdapaterEntryComponent(manufacturer, "Group Switches", fwversion, device_id, functionbitmask, name, ain, state, present, 0, energy, power, 0, 0))

					# Group Heaters
					if functionbitmask in fbHeaterGroups:
						for node in group.getiterator("name"):
							name=str(node.text)
						for node in group.getiterator("tist"):
							tist=node.text
						for node in group.getiterator("tsoll"):
							tsoll=node.text
						for node in group.getiterator("absenk"):
							absenk=node.text
						for node in group.getiterator("komfort"):
							komfort=node.text
						for node in group.getiterator("batterylow"):
							batterylow=node.text
							
						# Calculate state
						if int(tist) < int(tsoll):
							state="2"
						elif int(tsoll) == int(absenk):
							state="0"
						else:
							state="1"
						# Check if set to Off
						if int(tsoll) == 253:
							state="3"
							tsoll="0"
						# Check if set to On
						if int(tsoll) == 254:
							tsoll ="56"
						if int(komfort) == 254:
							komfort ="56"

						debug("Adapterinfos: %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s", manufacturer, "Group Heaters", fwversion, device_id, functionbitmask, name, ain, state, present, tist, tsoll, absenk, komfort, batterylow)
							
						self.adapterlist.append(AdapaterEntryComponent(manufacturer, "Group Heaters", fwversion, device_id, functionbitmask, name, ain, state, present, tist, tsoll, absenk, komfort, batterylow))

						
		### Adapters
		for device in xml.findall('device'):
			manufacturer=device.attrib['manufacturer']
			productname=device.attrib['productname']
			fwversion=device.attrib['fwversion']
			device_id=device.attrib['id']
			ain=device.attrib['identifier']
			functionbitmask=device.attrib['functionbitmask']

			for node in device.getiterator("present"):
				present=node.text
			if present=="1":
						
				# Comet DECT, FRITZ!DECT 300
				if functionbitmask in fbHeater:
					for node in device.getiterator("name"):
						name=str(node.text)
					for node in device.getiterator("tist"):
						tist=node.text
					for node in device.getiterator("tsoll"):
						tsoll=node.text
					for node in device.getiterator("absenk"):
						absenk=node.text
					for node in device.getiterator("komfort"):
						komfort=node.text
					for node in device.getiterator("batterylow"):
						batterylow=node.text						
											
					# Calculate state
					if int(tist) < int(tsoll):
						state="2"
					elif int(tsoll) == int(absenk):
						state="0"
					else:
						state="1"
					# Check if set to Off
					if int(tsoll) == 253:
						state="3"
						tsoll="0"
					# Check if set to On
					if int(tsoll) == 254:
						tsoll ="56"
					if int(komfort) == 254:
						komfort ="56"

					debug("Adapterinfos: %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s",  manufacturer, productname, fwversion, device_id, functionbitmask, name, ain, state, present, tist, tsoll, absenk, komfort, batterylow)

					self.adapterlist.append(AdapaterEntryComponent(manufacturer, productname, fwversion, device_id, functionbitmask, name, ain, state, present, tist, tsoll, absenk, komfort, batterylow))
			
				# FRITZ!DECT 200, FRITZ!DECT 210			
				if functionbitmask in fbSwitch:
					for node in device.getiterator("name"):
						name=str(node.text)
					for node in device.getiterator("celsius"):
						temp=node.text
					for node in device.getiterator("state"):
						state=node.text
					for node in device.getiterator("energy"):
						energy=node.text
					for node in device.getiterator("power"):
						power=node.text

					debug("Adapterinfos: %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s", manufacturer, productname, fwversion, device_id, functionbitmask, name, ain, state, present, temp, energy, power, "NV", "NV")

					self.adapterlist.append(AdapaterEntryComponent(manufacturer, productname, fwversion, device_id, functionbitmask, name, ain, state, present, temp, energy, power, 0, 0))
					
				# FRITZ!Powerline 546E		
				if functionbitmask in fbPowerline:
					for node in device.getiterator("name"):
						name=str(node.text)
					#for node in device.getiterator("celsius"):
					#	temp=node.text
					for node in device.getiterator("state"):
						state=node.text
					for node in device.getiterator("energy"):
						energy=node.text
					for node in device.getiterator("power"):
						power=node.text

					debug("Adapterinfos: %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s", manufacturer, productname, fwversion, device_id, functionbitmask, name, ain, state, present, "NV", energy, power, "NV", "NV")

					self.adapterlist.append(AdapaterEntryComponent(manufacturer, productname, fwversion, device_id, functionbitmask, name, ain, state, present, 0, energy, power, 0, 0))						
						
				# FRITZ!DECT Repeater 100		
				if functionbitmask in fbRepeater:
					for node in device.getiterator("name"):
						name=str(node.text)
					for node in device.getiterator("celsius"):
						temp=node.text
					#for node in device.getiterator("state"):
					#	state=node.text
					#for node in device.getiterator("energy"):
					#	energy=node.text
					#for node in device.getiterator("power"):
					#	power=node.text

					debug("Adapterinfos: %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s", manufacturer, productname, fwversion, device_id, functionbitmask, name, ain, "1", present, temp, "NV", "NV", "NV", "NV")

					self.adapterlist.append(AdapaterEntryComponent(manufacturer, productname, fwversion, device_id, functionbitmask, name, ain, "1", present, temp, 0, 0, 0, 0))
						
		#Activate next line for test issues
		#self.adapterlist=[]
		if self.adapterlist==[]:
			self.setTitle(pname + " - " + _("No Adapter found, Test Modus!"))
			self.adapterlist.append(AdapaterEntryComponent("AVM", "Group Switches", "1.0", "901", "6784", "Group Dect 200", "01234 1234565", "1", "1", "0", "6029", "11870", "0", "0"))
			self.adapterlist.append(AdapaterEntryComponent("AVM", "Group Switches 1", "1.0", "901", "4736", "Group Dect 210", "01234 1234566", "0", "1", "0", "3039", "5860", "0", "0"))
			self.adapterlist.append(AdapaterEntryComponent("AVM", "Group Heaters", "1.0", "900", "4160", "Group Heaters", "01234 1234567", "1", "1", "45", "44", "36", "44", "1"))
			self.adapterlist.append(AdapaterEntryComponent("AVM", "Comet DECT", "03.50", "21", "320", "Comet", "01234 1234567", "1", "1", "45", "44", "36", "44", "0"))
			self.adapterlist.append(AdapaterEntryComponent("AVM", "FRITZ!DECT 300", "03.50", "22", "320", "Dect 300", "01234 1234568", "0", "1", "40", "42", "36", "46", "1"))
			self.adapterlist.append(AdapaterEntryComponent("AVM", "FRITZ!DECT 200", "03.59", "17", "896", "Dect 200", "01234 1234565", "1", "1", "215", "6029", "11870", "0", "0"))
			self.adapterlist.append(AdapaterEntryComponent("AVM", "FRITZ!DECT 200", "03.83", "17", "2944", "Dect 200", "01234 1234565", "1", "1", "215", "2030", "13660", "0", "0"))
			self.adapterlist.append(AdapaterEntryComponent("AVM", "FRITZ!DECT 210", "03.83", "18", "2944", "Dect 210", "01234 1234566", "0", "1", "200", "3000", "0", "0", "0"))
			self.adapterlist.append(AdapaterEntryComponent("AVM", "FRITZ!DECT 100", "03.86", "17", "1280", "Repeater 100", "01234 1234565", "1", "1", "220", "0", "0", "0", "0"))
			self.adapterlist.append(AdapaterEntryComponent("AVM", "FRITZ!Powerline 546E", "03.59", "18", "640", "Powerline 546E", "01234 1234566", "1", "0", "0", "200", "3000", "0", "0"))
	
		else:
			self.setTitle(pname + _(" - Connected!"))
		
		debug("Adapterlist: %s" , self.adapterlist)
		self["adapterlist"].updateList(self.adapterlist)
		self.adapterinfo()
		self.RefreshTimer.start(10000, True)


	def resetAdapterList(self):
		self.adapterlist = []

	def switchclose(self):
		self.switchandclose = True
		self.switch()
	
	def switch(self):
		if self.login == True:
			if self.adapterlist is not None:
				selectedAdapter = self["adapterlist"].getCurrent()
				self.selectedAdapter = selectedAdapter[6]
				functionbitmask = selectedAdapter[4]
				if functionbitmask in fbHeaters:				
					#http://fritz.box/webservices/homeautoswitch.lua?ain=1234567890&switchcmd=sethkrtsoll&param=40&sid=0123456789900
					# Check if off, or night modus
					if selectedAdapter[10] == "0":
						tempvalue = selectedAdapter[11]
					elif selectedAdapter[10]==selectedAdapter[11]:
						tempvalue = selectedAdapter[12]
					else:
						tempvalue = 253
					self.adapterAction("switchcmd=sethkrtsoll;param="+ str(tempvalue))
				
				elif functionbitmask in fbSwitches:	
					#"http://webservices/homeautoswitch.lua?ain=0123456789900&switchcmd=setswitchtoggle&sid=0123456789900
					self.adapterAction("switchcmd=setswitchtoggle")
				else:
					return
			else:
				return
				
	def tempplus(self):
		if self.login == True:
			if self.adapterlist is not None:
				selectedAdapter = self["adapterlist"].getCurrent()
				self.selectedAdapter = selectedAdapter[6]				
				tempvalue = int(selectedAdapter[10])			
				tempvalue += 1
				if tempvalue > 56:
					tempvalue = 56			
				self.adapterAction("switchcmd=sethkrtsoll;param="+ str(tempvalue))
			else:
				return

	def tempminus(self):
		if self.login == True:
			if self.adapterlist is not None:
				selectedAdapter = self["adapterlist"].getCurrent()
				self.selectedAdapter = selectedAdapter[6]
				tempvalue = int(selectedAdapter[10])
				tempvalue -= 1
				if tempvalue <= 32:
					tempvalue = 0
				self.adapterAction("switchcmd=sethkrtsoll;param="+ str(tempvalue))
			else:
				return
				
	def adapterAction(self, action):
		url = "http://" + config.plugins.FritzDect.hostname.value + "/webservices/homeautoswitch.lua?ain="+ self.selectedAdapter + "&" + action +"&sid=" + self.fbSessionId
		debug("Adapter to modify: %s", self.selectedAdapter)
		debug("Adapter URL: %s", url)
		getPage(url, method="GET").addCallback(self.adapterSwitched).addErrback(self.showError)

	def adapterSwitched(self, html=""):
		if self.switchandclose == True:
			debug("Adapter switched and closed!")
			self.close()
		else:
			self.getAdapter()
			time.sleep(1)
			debug("Adapter switched!")
		
	def showError(self, error=""):
		debug("Error %s", str(error))
		
	def settingsMenu(self):
		self.session.openWithCallback(self.fblogin, FritzDectSettings)

### Settings

class FritzDectSettings(Screen, ConfigListScreen):
	skin = """
		<screen name="FritzDectSettings" position="20,60" size="720,420" title="FritzDect - Settings" backgroundColor = "#00586d88">
			<widget name="config" position="10,10" size="700,600" itemHeight="40" foregroundColor="#00ffffff" backgroundColor="#00586d88" foregroundColorSelected="#00ffffff" backgroundColorSelected="#00666666" scrollbarMode="showOnDemand" enableWrapAround="1" transparent = "1"/>
		</screen>"""

	def __init__(self, session):
		Screen.__init__(self, session)

		self["actions"] = ActionMap(["SetupActions", "ColorActions"],
		{
			"ok": self.keySave,
			"green": self.keySave,
			"red": self.keyCancel,
			"cancel": self.keyCancel
		}, -2)

		if config.plugins.FritzDect.realpassword.value:
			try:
				config.plugins.FritzDect.password.value = base64.b64decode(config.plugins.FritzDect.password.value)[:-maclen]
			except:
				debug("Password %s is not decryptable, set to Empty!" , config.plugins.FritzDect.password.value)
				config.plugins.FritzDect.password.value = ""

		self.cfglist = []
		self.cfglist.append(getConfigListEntry(_("FritzBox Hostname/IP"), config.plugins.FritzDect.hostname))
		self.cfglist.append(getConfigListEntry(_("FritzBox Username"), config.plugins.FritzDect.username))
		self.cfglist.append(getConfigListEntry(_("FritzBox Password"), config.plugins.FritzDect.password))
		self.cfglist.append(getConfigListEntry(_("FritzBox Show Password"), config.plugins.FritzDect.realpassword))
		self.cfglist.append(getConfigListEntry(_("FritzDect Extended"), config.plugins.FritzDect.extended))
		self.cfglist.append(getConfigListEntry(_("FritzDect Show Groups"), config.plugins.FritzDect.groups))
		self.cfglist.append(getConfigListEntry(_("FritzDect Details"), config.plugins.FritzDect.details))
		self.cfglist.append(getConfigListEntry(_("FritzDect Debug"), config.plugins.FritzDect.debug))
		self.cfglist.append(getConfigListEntry(_("Add plugin to Extensionmenu"), config.plugins.FritzDect.extensionmenu))
		self.cfglist.append(getConfigListEntry(_("Switch Ok and Green Button"), config.plugins.FritzDect.ok))
		ConfigListScreen.__init__(self, self.cfglist, session)

		self.onLayoutFinish.append(self.onLayout)

	def onLayout(self):
		self.setTitle(pname+" ("+pversion+") - "+_("Settings"))
		
	def keySave(self):
		if config.plugins.FritzDect.realpassword.value or config.plugins.FritzDect.password.isChanged():
			config.plugins.FritzDect.password.value = base64.b64encode(config.plugins.FritzDect.password.value+mac)
		config.plugins.FritzDect.save()
		configfile.save()
		self.close()

	def keyCancel(self):
		for item in self.cfglist:
			item[1].cancel()
		self.close()
