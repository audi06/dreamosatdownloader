#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#######################################################################
#
# FritzDect for VU+ by schomi (c)2016
# www.vuplus-support.org
# adapted for DreamOS by gutemine
#
# This plugin is licensed under the Creative Commons
# Attribution-NonCommercial-ShareAlike 3.0 Unported License.
# To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/
# or send a letter to Creative Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#
# This plugin is NOT free software. It is open source, you are allowed to
# modify it (if you keep the license), but it may not be commercially
# distributed other than under the conditions noted above.
#
####################################################################### 
pname = _("FritzDect")
pdesc = _("Switch Fritz Dect Adapters")
pversion = "v1.6"
pdate = "20170211"

from Components.config import config, configfile, ConfigSelection, ConfigPassword, ConfigSubsection, ConfigText, ConfigYesNo, getConfigListEntry
from Plugins.Plugin import PluginDescriptor
import FritzDect

from __init__ import _

def main(session, **kwargs):
	reload(FritzDect)
	try:
		session.open(FritzDect.FritzDectMain)
	except:
		import traceback
		traceback.print_exc()

def Plugins(**kwargs):
	desc_mainmenu  = PluginDescriptor(name=pname, description=pdesc, where = PluginDescriptor.WHERE_MENU, fnc = main)
	desc_pluginmenu = PluginDescriptor(name=pname, description=pdesc, where = PluginDescriptor.WHERE_PLUGINMENU, icon="plugin.png", fnc = main)
	desc_extensionmenu = PluginDescriptor(name=pname, description=pdesc, where = PluginDescriptor.WHERE_EXTENSIONSMENU, fnc = main)
	list = []
	list.append(desc_pluginmenu)
	if config.plugins.FritzDect.extensionmenu.value:
		list.append(desc_extensionmenu)
	return list