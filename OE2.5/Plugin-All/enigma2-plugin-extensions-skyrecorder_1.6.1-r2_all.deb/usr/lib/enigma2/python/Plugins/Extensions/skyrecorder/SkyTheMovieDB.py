#-*- coding: utf-8 -*-
import sys, urllib, re, shutil
import socket
from urllib2 import Request, urlopen, URLError

from StringIO import StringIO
USE_GZIP = True
try:
	import gzip
except Exception:
	sys.exc_clear()
	USE_GZIP = False

class SkyTheMovieDB(object):
	
	def __init__(self,timeout=10):
		self.alternate_lang = "en"
		self.timeout = timeout
		if USE_GZIP:
			self.headers1 = {
			'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:19.0) Gecko/20100101 Firefox/19.0',
			'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
			'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			'Cache-Control': 'max-age=3',
			'Accept-Encoding': 'gzip, deflate',
			'Accept-Language': 'de-de,de;q=0.8,en-us;q=0.5,en;q=0.3'}
		else:
			self.headers1 = {
			'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:19.0) Gecko/20100101 Firefox/19.0',
			'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
			'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
			'Cache-Control': 'max-age=3',
			'Accept-Language': 'de-de,de;q=0.8,en-us;q=0.5,en;q=0.3'}
	
	def cleanName(self,text):
		#text1 = text.decode("iso-8859-1")
		#text = text1.encode("utf-8")
		text = text.replace('&amp;','&')
		text = text.replace('/','')
		text = text.replace(':','_') # for enigma2 getRecordingFilename
		text = text.replace('–','-')
		# finally kill the rest
		text = re.sub('-+',"-",text)
		return text
	
	def prepareSearchString(self,text):
		#text1 = text.decode("iso-8859-1")
		#text = text1.encode("utf-8")
		
		# FIXME: some hacks
		text = re.sub("[Mm]arvel's ","",text)
		text = re.sub("[?]","",text)
		text = urllib.quote_plus(text)
		return text
		
		text = text.replace('&auml;','ae').replace('&Auml;','Ae').replace('&ouml;','oe').replace('&ouml;','Oe').replace('&uuml;','ue')
		text = text.replace('&Uuml;','Ue').replace('&szlig;','ss').replace('&amp;','&').replace('&quot;','\"').replace('&gt;','\'')
		text = text.replace('&#228;','ae').replace('&#246;','oe').replace('&#252;','ue').replace('&#223;','ss').replace('&#8230;','...')
		text = text.replace('\u00c4','Ae').replace('\u00e4;',"ae").replace('\u00d6',"Oe").replace('\u00f6','oe')
		text = text.replace('\u00dc','Ue').replace('\u00fc',"ue").replace('\u00df',"ss")
		text = text.replace('&#196;','Ae').replace('&#228;',"ae").replace('&#214;',"Oe").replace('&#246;',"oe").replace('&#220;',"Ue").replace('&#252;',"ue")
		text = text.replace('ö','oe').replace('ü','ue').replace('ä','ae').replace('Ã','ss')
		text = text.replace('Ö','Oe').replace('Ü','Ue').replace('Ä','Ae')
		text = text.replace('–','-')
		text = text.replace('/','-')
		text = text.replace(' ','-')
		# finally kill the rest
		text = re.sub("[^a-zA-Z0-9-]","",text)
		text = re.sub('-+',"-",text)
		return text
	
	
	def getListFor(self,searchStr,split=False,language="de"):
		if not searchStr or len(searchStr) < 1:
			return False
		
		if split:
			searchStr = searchStr.split("-")[0].strip()
			#searchStr = searchStr.split(":")[0].strip()
		
		searchstring = self.prepareSearchString(searchStr)
		url = "http://www.themoviedb.org/search/movie?query={0}&language={1}".format(searchstring,language)

		data = None
		socket.setdefaulttimeout(self.timeout)
		req = Request(url,None,self.headers1)
		try:
			response = urlopen(req)
			url = response.geturl()
			print url
			req = Request(url,None,self.headers1)
			response = urlopen(req)
		except URLError as e:
			if hasattr(e, 'reason'):
				print 'We failed to reach a server.'
				print 'Reason: ', e.reason
			elif hasattr(e, 'code'):
				print 'The server couldn\'t fulfill the request.'
				print 'Error code: ', e.code
			return False
		else:
			# everything is fine?
			try:
				if USE_GZIP:
					if response.info().get('Content-Encoding') == 'gzip':
					    buf = StringIO(response.read())
					    f = gzip.GzipFile(fileobj=buf)
					    data = f.read()
				else:
					data = response.read()
			except Exception:
				return False
		
		if not data or len(data) < 1:
			print "nothing found"
			return False
		
		# store our results
		resultList = None
		resultList = []
		
		m_base = re.findall('<ul class="search_results movie">(.*?)</ul>', data, re.I|re.S)
		try:
			m_list_raw = str(m_base[0]).replace("</li>", "").split("<li>")
		except Exception:
			return False
		
		for m_result in m_list_raw:
			
			res = re.findall('<div class="poster">.*?<a href=".*?" title="(.*?)"><img.*?src="(.*?)".*?></a>.*?</div>', m_result, re.I|re.S)
			if not res:
				continue
			m_poster_url = str(res[0][1])			
			m_title_org = str(res[0][0])
			
			res = re.findall('<div class="info">.*?<a href="(.*?)\?.*?" title=".*?">(.*?)</a>.*?<span>\((.*?)\)</span>.*?</div>', m_result, re.I|re.S)
			if not res:
				continue
			
			m_movie_url = "http://www.themoviedb.org{0}".format(res[0][0])
			m_title = str(res[0][1])
			m_date = str(res[0][2])
			
			try:
				m_id_movie = re.search("/.*?/([0-9]+)-.*?",m_movie_url).group(1)
			except Exception:
				m_id_movie = 0
			
			resultList.append({
								"m_movie_url":m_movie_url,
								"m_title_org":m_title_org,
								"m_title":m_title,
								"m_poster_url":m_poster_url,
								"m_date":m_date,
								"m_id_movie":m_id_movie
							})
		# return resultlist
		return resultList
		
	
	def getInfoFor(self,movieURL="",movieTitle="",idMovie="",language="de",lastlang=-1):
		lang = ('de','en','es','fr')
		max_lang = len(lang) - 1
		if movieURL and len(movieURL) > 1:
			# default
			if lastlang and int(lastlang) > -1 and int(lastlang) in range(0,max_lang+1):
				language = lang[lastlang]
			if not language or language not in lang:
				language = "de"
			url = "{0}?language={1}".format(movieURL,language)
			
			lastlang = lang.index(language)
			print url
		else:
			return False
		
		data = None
		socket.setdefaulttimeout(self.timeout)
		req = Request(url,None,self.headers1)
		try:
			response = urlopen(req)
		except URLError as e:
			if hasattr(e, 'reason'):
				print 'We failed to reach a server.'
				print 'Reason: ', e.reason
			elif hasattr(e, 'code'):
				print 'The server couldn\'t fulfill the request.'
				print 'Error code: ', e.code
			return False
		else:
			# everything is fine?
			try:
				if USE_GZIP:
					if response.info().get('Content-Encoding') == 'gzip':
					    buf = StringIO(response.read())
					    f = gzip.GzipFile(fileobj=buf)
					    data = f.read()
				else:
					data = response.read()
			except Exception:
				return False
		
		if not data or len(data) < 1:
			print "nothing found"
			#lastlang += 1
			#if lastlang > max_lang:
			#	return False
			#else:
			#	print "next language {0}".format(lang[lastlang])
			#	self.getInfoFor(movieURL=movieURL,movieTitle="",idMovie="",language="de",lastlang=lastlang)
			return False
		
				
		resultList = None
		resultList = []
		
		res = re.findall('<div id="mainCol">.*?<div class="title">.*?<h2 id="title"><a href=".*?" itemprop="url"><span itemprop="name">(.*?)</span></a></h2>.*?<h3 id="year">\((.*?)\)</h3>.*?</div>', data, re.I|re.S)
		if not res:
			return False
		
		m_name = str(res[0][0])			
		m_year = str(res[0][1])

		res = re.findall('<div class="rating">.*?<span id="rating_hint" itemprop="ratingValue">(.*?)</span>.*?</div>', data, re.I|re.S)
		#res = re.findall('<input type="hidden" name="score" value="(.*?)" readonly="readonly">', data, re.I|re.S)
		#<span id="rating_hint" itemprop="ratingValue">2.8</span>
		if not res:
			m_rating = 0
		else:
			m_rating = str(res[0])
			
		res = re.findall('<p id="overview" itemprop="description">(.*?)</p>', data, re.I|re.S)
		if not res:
			m_description = ""
		else:
			m_description = str(res[0])
		
		res = re.findall('<h3>Original Title</h3>.*?<p>(.*?)</p>', data, re.I|re.S)
		if not res:
			m_title_org = ""
		else:
			m_title_org = str(res[0])
		
		
		res = re.findall('<meta property="og:image" content="(.*?)" />', data, re.I)
		if not res:
			m_posters = []
		else:
			m_posters = list(res)
		
		if not idMovie or idMovie == "":
			try:
				m_id_movie = re.search("/.*?/([0-9]+)-.*?",movieURL).group(1)
			except Exception:
				m_id_movie = 0
		else:
			m_id_movie = idMovie
		
		m_genre = []
		res = re.findall('<span id="genres">.*?<ul.*?>(.*?)<div.*?></div>.*?</ul>.*?</span>', data, re.I|re.S)
		if res:
			res_2 = re.findall('<li><a href=".*?" alt=".*?"><span itemprop="genre">(.*?)</span></a></li>', str(res), re.I)
			for li_res in res_2:
				m_genre.append(str(li_res))
				
		resultList.append({
							"m_name":m_name,
							"m_year":m_year,
							"m_title_org":m_title_org,
							"m_rating":m_rating,
							"m_description":m_description,
							"m_posters":m_posters,
							"m_id_movie":m_id_movie,
							"m_genre":m_genre
						})
							
		# return result
		return resultList
			
