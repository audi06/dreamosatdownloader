#!/usr/bin/python
# -*- coding: utf-8 -*- 
#  Netatmo for Dreambox-Enigma2
#
#  Coded by cmikula (c)2013
#  Support: www.i-have-a-dreambox.com
#
#  This plugin is licensed under the Creative Commons 
#  Attribution-NonCommercial-ShareAlike 3.0 Unported 
#  License. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#  Alternatively, this plugin may be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.
#
#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially 
#  distributed other than under the conditions noted above.
#
from Components.Converter.Poll import Poll
from Components.Converter.Converter import Converter
from Plugins.Extensions.Netatmo.NetatmoCore import NetatmoUnit, Sensor, getDirection
from Plugins.Extensions.Netatmo import _
from Plugins.Extensions.Netatmo.NetatmoCore import Station as NetatmoStation

TRANSLATE = "$"

class Netatmo(Poll, Converter, object):
	def __init__(self, type):  # @ReservedAssignment
		Poll.__init__(self)
		Converter.__init__(self, type)
		self.type = type
		if not type.startswith(TRANSLATE):
			self.poll_enabled = True
		# check user format eg: temperature?temp [min / max]
		self.format = "{0} {1}"
		try:
			idx = self.type.find('?')
			if idx > 0:
				x = self.type[idx + 1:]
				x = x.replace("temp", "{0}").replace("min", "{2}").replace("max", "{3}")
				x = x.replace("rain", "{0}").replace("sum1", "{2}").replace("sum24", "{3}")
				x = x.replace("unit", "{1}").replace("value", "{0}").replace("direction", "{2}")
				self.format = x
		except Exception, ex:
			print ex
	
	def getNumberFormat(self, f):
		return f.replace("{0}", "{0:0.1f}").replace("{2}", "{2:0.1f}").replace("{3}", "{3:0.1f}")
	
	def getText(self):
		try:
			# check translation
			if self.type.startswith(TRANSLATE):
				if self.type[-1] == ":":
					return _(self.type[len(TRANSLATE):-1]) + ":"
				return _(self.type[len(TRANSLATE):])
			
			if not isinstance(self.source, NetatmoStation):
				from Plugins.Extensions.Netatmo.Netatmo import netatmo
				self.source = netatmo
			
			netatmo = self.source
			if len(netatmo.stations) == 0:
				if self.type == "last_refresh" and netatmo.error is not None:
					return netatmo.error
				return "N/A"

			if self.type == "last_refresh":
				return netatmo.last_refresh
			
			f = self.format
			station = netatmo.getStation()
			if self.type == "station.name":
				return station.name.encode('utf8')
			if self.type == "station.firmware":
				return str(station.firmware)
			if self.type == "place.location":
				return str(station.location)
			if self.type == "place.timezone":
				return str(station.timezone)
			if self.type == "place.area":
				return str(station.area)
			
			if self.type == "station.when":
				return str(station.measure.when)
			
			# wifi status
			if self.type == "station.wifi_status":
				return str(station.wifi_status)

			if self.type.startswith("rainfall"):
				rainfall = station.findRainModule()
				if not rainfall:
					return ""
				if "rainfall$" in self.type:
					return _(self.type[len("rainfall$"):])
				if "name" in self.type:
					return str(rainfall.module_name)
				if "rainfall.battery_percent" in self.type:
					return f.format(rainfall.battery_percent, "%")
				if "rainfall.rf_status" in self.type:
					return f.format(rainfall.rf_status, "%")
				if self.type == "rainfall.firmware":
					return str(rainfall.firmware)
				measure = rainfall.measure
				return f.format(measure.getSensor(Sensor.Rain), netatmo.getUint(NetatmoUnit.MM), measure.getSensor(Sensor.Rain1), measure.getSensor(Sensor.Rain24))

			if self.type.startswith("windgauge"):
				windgauge = station.findWindModule()
				if not windgauge:
					return ""
				if self.type.endswith("name"):
					return str(windgauge.module_name)
				
				if "windgauge$" in self.type:
					return _(self.type[len("windgauge$"):])
				if "windgauge.wind_strength" in self.type:
					return f.format(windgauge.measure.wind_strength, netatmo.getUint(NetatmoUnit.WIND), getDirection(windgauge.measure.wind_angle))
				if "windgauge.gust_strength" in self.type:
					return f.format(windgauge.measure.gust_strength, netatmo.getUint(NetatmoUnit.WIND), getDirection(windgauge.measure.gust_angle))
				if "windgauge.wind_angle" in self.type:
					return f.format(windgauge.measure.wind_angle, "°", getDirection(windgauge.measure.wind_angle))
				if "windgauge.gust_angle" in self.type:
					return f.format(windgauge.measure.gust_angle, "°", getDirection(windgauge.measure.gust_angle))
				if "windgauge.battery_percent" in self.type:
					return f.format(windgauge.battery_percent, "%")
				if "windgauge.rf_status" in self.type:
					return f.format(windgauge.rf_status, "%")
				if self.type == "windgauge.firmware":
					return str(windgauge.firmware)
			
			module = station.getMainModule()
			if module is not None:
				if self.type == "station.module_name":
					return module.module_name.encode('utf8')

				measure = module.measure
				if self.type.startswith("station.temperature"):
					if not measure.has_temperature: return ""
					if measure.temperature_min == "":
						f = "{0} {1}"
					f = self.getNumberFormat(f)
					return f.format(measure.temperature, netatmo.getUint(NetatmoUnit.TEMPERATURE), measure.temperature_min, measure.temperature_max)
				if "station.humidity" in self.type:
					if not measure.has_humidity: return ""
					return f.format(measure.humidity, netatmo.getUint(NetatmoUnit.HUMIDITY))
				if "station.pressure" in self.type:
					if not measure.has_pressure: return ""
					return f.format(measure.pressure, netatmo.getUint(NetatmoUnit.PRESSURE))
				if "station.noise" in self.type:
					if not measure.has_noise: return ""
					return f.format(measure.noise, netatmo.getUint(NetatmoUnit.NOISE))
				if "station.co2" in self.type:
					if not measure.has_co2: return ""
					return f.format(measure.co2, netatmo.getUint(NetatmoUnit.CO2))
			
			module = station.getModule()
			if module is not None:
				if self.type == "module.module_name":
					return module.module_name.encode('utf8')
				if "module.battery_percent" in self.type:
					return f.format(module.battery_percent, "%")
				if "module.battery" in self.type:
					return f.format((module.battery_vp / 1000.0), "V")
				if self.type == "module.firmware":
					return str(module.firmware)
				if "module.rf_status" in self.type:
					return f.format(module.rf_status, "%")
				
				measure = module.measure
				if self.type == "module.when":
					return str(measure.when)
				if self.type.startswith("module.temperature"):
					if not measure.has_temperature: return ""
					if measure.temperature_min == "":
						f = "{0} {1}"
					f = self.getNumberFormat(f)
					return f.format(measure.temperature, netatmo.getUint(NetatmoUnit.TEMPERATURE), measure.temperature_min, measure.temperature_max)
				
				if "module.humidity" in self.type:
					return f.format(measure.humidity, netatmo.getUint(NetatmoUnit.HUMIDITY))
				if "module.co2" in self.type:
					if not measure.has_co2:
						return ""
					return f.format(measure.co2, netatmo.getUint(NetatmoUnit.CO2))

			# measure class
			if self.type == "station.comfort_class":
				return station.measure.comf_class
			if self.type == "station.temperature_idx":
				return str(station.measure.idx_temp)
			if self.type == "station.humidity_idx":
				return str(station.measure.idx_humidity)
			if self.type == "station.noise_idx":
				return str(station.measure.idx_noise)
			if self.type == "station.co2_idx":
				return str(station.measure.idx_co2)
	
			return "N/A"
		except:
			import sys, traceback
			print "--- [Netatmo] STACK TRACE ---"
			traceback.print_exc(file=sys.stdout)
			print '-----------------------------'
			return "Error"
		
		
	text = property(getText)
