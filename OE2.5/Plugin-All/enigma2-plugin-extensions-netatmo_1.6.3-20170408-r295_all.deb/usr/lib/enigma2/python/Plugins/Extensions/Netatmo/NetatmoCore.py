#!/usr/bin/python
# -*- coding: utf-8 -*-
#  Netatmo for Dreambox-Enigma2
#
#  Coded by cmikula (c)2013
#  Support: www.i-have-a-dreambox.com
#
#  This plugin is licensed under the Creative Commons 
#  Attribution-NonCommercial-ShareAlike 3.0 Unported 
#  License. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#  Alternatively, this plugin may be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.
#
#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially 
#  distributed other than under the conditions noted above.
#

### DO NOT IMPORT CLASSES FROM ENIGMA2 ###
from __init__ import _
from NetatmoAPI import ClientAuth, DeviceList, MeasureData
from GoogleMapsApi import retrieveGeoLocation
from datetime import datetime
from urllib2 import HTTPError
import time, base64
### DO NOT IMPORT CLASSES FROM ENIGMA2 ###

UNITS_TEMPERATURE = (u"°C", u"°F")
UNITS_PRESSURE = ("mbar", "inHg", "mmHg")
UNITS_MM = ("mm", "in")
UNITS_WIND = (_("kph"), _("mph"), _("ms"), _("beaufort"), _("knot"))
WIND_ANGLE = (_("N"), _("NE"), _("E"), _("SE"), _("S"), _("SW"), _("W"), _("NW"))

def getAngleIndex(angle, res=16):
    distribution = 360 / res
    offset = distribution / 2.0
    index = ((angle + offset) % 360) / distribution
    #print str.format("{0}\t{1:0.1f}\t{2}", angle, index, WIND_ANGLE[int(index)])
    return int(index)

def getDirection(angle):
    return WIND_ANGLE[getAngleIndex(angle, len(WIND_ANGLE))]

def printStackTrace():
    import sys, traceback
    print "--- [Netatmo] STACK TRACE ---"
    traceback.print_exc(file=sys.stdout)
    print '-----------------------------'


class DataParser():
    def __init__(self, data, def_str="N/A", def_int=0):
        self.data = data
        self.def_str = def_str
        self.def_int = def_int
    
    def getNumberX(self, key):
        try:
            result = self.data.has_key(key)
            if not result:
                return False, 0
            val = self.data[key]
            if isinstance(val, int):
                return result, int(val)
            if isinstance(val, float):
                return result, round(float(val), 1)
            if isinstance(val, str):
                return result, str(val)
            return result, self.def_int
        except:
            print self.data
            printStackTrace()
            return False, self.def_int

    def getNumber(self, key):
        return self.getNumberX(key)[1]
        
    def getString(self, key, default=None):
        try:
            return unicode(self.data[key])
        except:
            printStackTrace()
            return default or self.def_str
        
    def getItem(self, key):
        try:
            return self.data[key]
        except:
            printStackTrace()
            return None
        

class UserData():
    def __init__(self, raw):
        data = raw["administrative"]
        p = DataParser(data)
        self.lang = p.getString("lang")
        self.reg_locale = p.getString("reg_locale")
        self.country = p.getString("country")
        self.unit = p.getNumber("unit")
        self.pressureunit = p.getNumber("pressureunit")
        self.windunit = p.getNumber("windunit")
        self.feel_like_algo = p.getNumber("feel_like_algo")


class MeteoAlarm():
    def __init__(self, raw):
        p = DataParser(raw)
        self.status = p.getString("status")
        self.max_level = p.getNumber("max level")
        self.begin = timeConverter(p.getNumber("begin"))
        self.end = timeConverter(p.getNumber("end"))
        self.time_generated = timeConverter(p.getNumber("time_generated"))
        self.descr = p.getString("descr")
        self.area = p.getString("area")
        self.alarm_id = p.getNumber("alarm_id")
        self.text_field = p.getString("text_field")
        self.type = p.getString("type")
        self.origin = p.getString("origin")
        self.level = p.getNumber("level")


class NetatmoUnit:
    TEMPERATURE = 0
    HUMIDITY = 1
    PRESSURE = 2
    NOISE = 3
    CO2 = 4
    MM = 5
    WIND = 6


class Sensor:
    When = 'time_utc'
    Temperature = 'Temperature'
    TemperatureMin = 'min_temp'
    TemperatureMax = 'max_temp'
    Co2 = 'CO2'
    Humidity = 'Humidity'
    Noise = 'Noise'
    Pressure = 'Pressure'
    Rain = 'Rain'
    Rain1 = 'sum_rain_1'
    Rain24 = 'sum_rain_24'
    WindStrength = 'WindStrength'
    GustStrength = 'GustStrength'
    WindAngle = 'WindAngle'
    GustAngle = 'GustAngle'


class Stations():
    APPLICATION_ID = "ENIGMA2-NETATMO-V2"
    CLIENT_ID = "NTY3N2VlMGZlOGVkZTExZjRhNmY2Mjc5"
    CLIENT_SECRET = "TDdqR0hnbno5V0haM3FnRW1JSGF5VnozamhyT2E0V3FuenNWdnF6TWE="
    SIMULATE = False
    def __init__(self, accessToken="", refreshToken=""):
        self.user = None
        self.stations = []
        self.error = None
        self.last_refresh = "N/A"
        self.current_index = 0
        self.auth = ClientAuth(accessToken, refreshToken, base64.b64decode(Stations.CLIENT_ID), base64.b64decode(Stations.CLIENT_SECRET))
    
    def updateTimestamp(self):
        self.last_refresh = _("Last refresh:") + ' ' + datetime.now().strftime("%d.%m.%Y %H:%M:%S")
    
    def needAuthorization(self):
        return not self.auth.access_token or not self.auth.refresh_token
    
    def authorize(self, username, password):
        self.auth.authorize(username, password)
    
    def logOff(self):
        print "[Netatmo] logoff"
        self.auth.access_token = ""
        self.auth.refresh_token = ""
        self.stations = []
    
    def retrieveData(self, get_favorites=True):
        print "[Netatmo] begin update"
        start = time.time()
        try:
            new_station = []
            fav_station = []
            deviceList = DeviceList(get_favorites)

            if self.SIMULATE:
                DebugRawData.loadSimulationData()
                deviceList.raw = DebugRawData.device_list
            else:
                deviceList.request(self.auth)
            self.user = UserData(deviceList.raw['user'])
            for x in deviceList.listDevices():
                station = Station(x)
                if False and not station.favorite and not self.SIMULATE:
                    self.__requestHumidityMinMax(station)
                if not station.favorite:
                    new_station.append(station)
                else:
                    fav_station.append(station)
            # sort stations
            new_station.sort(key=lambda x: x.name.lower(), reverse=False)
            fav_station.sort(key=lambda x: x.name.lower(), reverse=False)
            new_station.extend(fav_station)
            # set old module index
            if len(self.stations) == len(new_station):
                for index, s in enumerate(self.stations):
                    new_station[index].module_index1 = s.module_index1
                    new_station[index].module_index2 = s.module_index2

            self.updateTimestamp()
            self.error = None
            self.stations = new_station
            
            # request geo location from google
            for station in self.stations:
                if not station.location:
                    continue
                area = retrieveGeoLocation(station.location[1], station.location[0])
                station.area = area and area or _("No Google Geocoding possible!") 

        except HTTPError, e:
            printStackTrace()
            if e.code == 400:
                self.logOff()
                self.error = str(e)
        except Exception, e:
            self.error = str(e)
            printStackTrace()
        print "[Netatmo] update took {0} sec".format(time.time() - start)
    
    def __requestHumidityMinMax(self, station):
        try:
            measure = MeasureData()
            for module in station.modules:
                if not module.measure.has_humidity:
                    continue
                print "{0} {1} {2}".format(station.name, station.id, module.id)
                measure.request(self.auth, station.id, "1day", "min_hum,date_min_hum,max_hum,date_max_hum", module_id=module.id, date_end="last")
                for v in measure.raw:
                    for x in v['value']:
                        module.measure.humidity_minmax_date = time.strftime("%d.%m.%Y", time.localtime(x[1]))
                        module.measure.humidity_min = str(x[0])
                        module.measure.humidity_max = str(x[2])
                        module.measure.humidity_min_time = time.strftime("%H:%M", time.localtime(x[1]))
                        module.measure.humidity_max_time = time.strftime("%H:%M", time.localtime(x[3]))
        except:
            printStackTrace()
    
    def getUint(self, unit):
        if self.user is None:
            return ""
        try:
            if unit == NetatmoUnit.TEMPERATURE:
                return UNITS_TEMPERATURE[self.user.unit].encode('utf8')
            if unit == NetatmoUnit.PRESSURE:
                return UNITS_PRESSURE[self.user.pressureunit]
            if unit == NetatmoUnit.HUMIDITY:
                return "%"
            if unit == NetatmoUnit.NOISE:
                return "db"
            if unit == NetatmoUnit.CO2:
                return "ppm"
            if unit == NetatmoUnit.MM:
                return UNITS_MM[self.user.unit]
            if unit == NetatmoUnit.WIND:
                return UNITS_WIND[self.user.windunit]
        except:
            printStackTrace()
        return ""
    
    def moduleIndex1(self, what):
        try:
            if len(self.stations) == 0:
                return
            if what > 0:
                self.getStation().nextIndex1()
            else:
                self.getStation().prevIndex1()
        except:
            printStackTrace()
    
    def moduleIndex2(self, what):
        try:
            if len(self.stations) == 0:
                return
            if what > 0:
                self.getStation().nextIndex2()
            else:
                self.getStation().prevIndex2()
        except:
            printStackTrace()
    
    def getStation(self):
        if len(self.stations) == 0:
            return None
        return self.stations[self.current_index]
    
    def select(self, station, module1, module2):
        for index, s in enumerate(self.stations):
            if s.id == station:
                self.current_index = index
                break
        s = self.getStation()
        if s:
            for index, m in enumerate(s.modules):
                if m.id == module1:
                    s.module_index1 = index
                if m.id == module2:
                    s.module_index2 = index


class Station():
    def __init__(self, data):
        self.area = ""
        self.module_count = 0
        self.modules = []
        self.module_index1 = -1
        self.module_index2 = 0
        p = DataParser(data)
        self.favorite = data.has_key("favorite")
        self.name = p.getString("station_name")
        self.id = p.getString("_id")
        self.module_name = data.has_key('module_name') and data['module_name'] or self.name
        self.firmware = 0
        self.wifi_status = 0
        if not self.favorite:
            self.module_name = p.getString("module_name")
            self.firmware = p.getNumber("firmware")
            self.wifi_status = p.getNumber("wifi_status")
        
        if False:  # TODO: meteo alarms disabled...
            self.meteo_alarms = []
            if data.has_key("meteo_alarms"):
                for alarm in data["meteo_alarms"]:
                    self.meteo_alarms.append(MeteoAlarm(alarm))

        p.data = data["place"]
        self.timezone = p.getString("timezone")
        self.location = p.getItem("location")  # location = [longitude,latitude]
        # self.longitude, self.latitude = p.getString("location").encode("utf-8").replace("[", "").replace("]", "").strip().split(",")
        # self.area = p.getString("geoip_city").encode("utf-8")
        # self.area = p.getString("meteoalarm_area").encode("utf-8")
        
        # "NAMain" : for the base station
        self.measure = StationMeasure(data)
        rain_modules = []
        wind_modules = []
        for m in data['modules']:
            mod_type = m['type']
            module = None
            
            if not m.has_key('dashboard_data'):
                print "[Netatmo] cancel module '{0}' no dashboard_data".format(mod_type)
                continue
            
            # "NAModule1" : for the measure module
            # "NAModule4" : for the additional indoor module
            if mod_type in ('NAModule1', 'NAModule4'):
                module = Module(m, self.name)
                module.measure = ModuleMeasure(m, self.name)
                self.modules.insert(0, module)
                self.module_count += 1
            # "NAModule2" : for the wind module
            elif mod_type == 'NAModule2':
                module = Module(m, self.name)
                module.measure = NAModule2(m, self.name)
                wind_modules.append(module)
            # "NAModule3" : for the rain gauge module
            elif mod_type == 'NAModule3':
                module = Module(m, self.name)
                module.measure = NAModule3(m, self.name)
                rain_modules.append(module)
            # "NAPlug" : for the thermostat plug
            elif mod_type == 'NAPlug':
                print "[Netatmo] not implemented"
                print mod_type
                print m
                # TODO: implement
                pass
            # "NATherm1" : for the thermostat module
            elif mod_type == 'NATherm1':
                print "[Netatmo] not implemented"
                print mod_type
                print m
                # TODO: implement
                pass
            else:
                print "[Netatmo] unsupported module"
                print "Type: %s; Station: %s; Module: %s" % (mod_type, self.name, self.module_name)
                print m
            
        self.modules.sort(key=lambda x: x.module_name.lower(), reverse=False)
        rain_modules.sort(key=lambda x: x.module_name.lower(), reverse=False)
        wind_modules.sort(key=lambda x: x.module_name.lower(), reverse=False)
        self.modules.extend(rain_modules)
        self.modules.extend(wind_modules)

    def getMeasure(self):
        return self.measure
    
    def nextIndex1(self):
        if len(self.modules) <= 1:
            self.module_index1 = -1
            return
        if self.module_index1 + 1 >= len(self.modules):
            self.module_index1 = -1
        else:
            self.module_index1 += 1
        print self.module_index1

    def prevIndex1(self):
        if len(self.modules) <= 1:
            self.module_index1 = -1
            return
        if self.module_index1 - 1 < -1:
            self.module_index1 = len(self.modules) - 1
        else:
            self.module_index1 -= 1
        print self.module_index1

    def nextIndex2(self):
        if self.module_index2 + 1 >= len(self.modules):
            self.module_index2 = 0
        else:
            self.module_index2 += 1
        print self.module_index2

    def prevIndex2(self):
        if self.module_index2 - 1 < 0:
            self.module_index2 = len(self.modules) - 1
        else:
            self.module_index2 -= 1
        print self.module_index2

    def getMainModule(self):
        if len(self.modules) == 0 or self.module_index1 == -1:
            return self
        return self.modules[self.module_index1]

    def getModule(self):
        if len(self.modules) == 0:
            return None
        return self.modules[self.module_index2]
    
    def findRainModule(self):
        for module in self.modules:
            if isinstance(module.measure, NAModule3):
                return module

    def findWindModule(self):
        for module in self.modules:
            if isinstance(module.measure, NAModule2):
                return module


class Module():
    def __init__(self, data, base_name):
        self.measure = None
        p = DataParser(data)
        self.id = p.getString("_id")
        self.module_type = p.getString("type")
        self.module_name = data.has_key('module_name') and data['module_name'] or base_name
        self.firmware = p.getNumber("firmware")
        self.battery_vp = p.getNumber("battery_vp")
        self.battery_percent = p.getNumber("battery_percent")
        self.rf_status = p.getNumber("rf_status")

    def getMeasure(self):
        return self.measure


def timeConverter(time_value):
    return time.strftime("%d.%m.%Y %H:%M", time.localtime(time_value))


class Measure():
    def __init__(self):
        self.name = ""
        self.has_co2 = False
        self.has_noise = False
        self.has_humidity = False
        self.has_pressure = False
        self.has_temperature = False
        self.has_rainfall = False
        self.has_windgauge = False
        self.co2 = 0
        self.noise = 0
        self.humidity = 0
        self.pressure = 0
        self.temperature = 0
        self.temperature_min = ""
        self.temperature_max = ""
    
    def parse(self, data):
        self.data_type = data.has_key('data_type') and data['data_type'] or ''
        if data.has_key('dashboard_data'):
            p = DataParser(data['dashboard_data'])
            self.p = p
            self.has_temperature, self.temperature = p.getNumberX(Sensor.Temperature)
            self.has_co2, self.co2 = p.getNumberX(Sensor.Co2)
            self.has_humidity, self.humidity = p.getNumberX(Sensor.Humidity)
            self.has_noise, self.noise = p.getNumberX(Sensor.Noise)
            self.has_pressure, self.pressure = p.getNumberX(Sensor.Pressure)
            self.has_temperature_min, self.temperature_min = p.getNumberX(Sensor.TemperatureMin)
            self.has_temperature_max, self.temperature_max = p.getNumberX(Sensor.TemperatureMax)
            self.when = _("Last measurement:") + ' ' + timeConverter(p.getNumber(Sensor.When))


class StationMeasure(Measure):
    def __init__(self, data):
        Measure.__init__(self)
        self.module_type = data['type']
        self.module_name = data.has_key('module_name') and data['module_name'] or data['station_name']
        self.parse(data)

        import Comfort
        self.humidex = Comfort.humidex(self.temperature, self.humidity)    
        self.idx_temp = Comfort.comfort_temp(self.humidex)
        self.idx_co2 = Comfort.comfort_co2(self.co2)
        self.idx_noise = Comfort.comfort_noise(self.noise)
        self.idx_humidity = Comfort.comfort_humidity(self.humidity)
        self.idx_total = Comfort.comfort_fusion(self.idx_co2, self.idx_temp, self.idx_noise, self.idx_humidity)
        self.comf_class = Comfort.comfort_class(self.idx_total)
        if self.idx_total >= 50.0:
            self.dis_reason = Comfort.discomfort_reason(self.idx_co2, self.idx_temp, self.idx_noise, self.idx_humidity, self.humidex, self.humidity)
        else:
            self.dis_reason = ""

        if self.dis_reason:
            self.comf_class += " - " + self.dis_reason
        
        
class ModuleMeasure(Measure):
    def __init__(self, data, base_name):
        Measure.__init__(self)
        self.module_type = data['type']
        self.module_name = data.has_key('module_name') and data['module_name'] or base_name
        self.parse(data)
    
    def getSensor(self, sensor):
        return self.p.getNumber(sensor)
    

class NAModule2(ModuleMeasure):
    def __init__(self, data, base_name):
        ModuleMeasure.__init__(self, data, base_name)
        self.has_windgauge = True
        m = data['dashboard_data']
        p = DataParser(m)
        self.wind_strength = p.getNumber(Sensor.WindStrength)
        self.gust_strength = p.getNumber(Sensor.GustStrength)
        self.wind_angle = p.getNumber(Sensor.WindAngle)
        self.gust_angle = p.getNumber(Sensor.GustAngle)


class NAModule3(ModuleMeasure):
    def __init__(self, data, base_name):
        ModuleMeasure.__init__(self, data, base_name)
        self.has_rainfall = True


class DebugRawData():
    # simulation file
    SIM_FILE = 'simulation.json'
    device_list = \
    {
        u'user': {u'mail': u'xyz@gmail.com', u'administrative': {u'lang': u'de-AT', u'windunit': 0, u'feel_like_algo': 0, u'pressureunit': 0, u'country': u'AT', u'reg_locale': u'de-AT', u'unit': 0}},
        u'devices':
        [
            {u'read_only': True, u'data_type': [u'Temperature', u'CO2', u'Humidity', u'Noise', u'Pressure'], u'last_upgrade': 1439971305, u'firmware': 102,
            u'modules': 
            [
             {u'rf_status': 66, u'data_type': [u'Temperature', u'Humidity'], u'last_message': 1443791385, u'firmware': 43, u'dashboard_data': {u'date_min_temp': 1443765988, u'Temperature': 18.5, u'time_utc': 1443791366, u'Humidity': 46, u'min_temp': 9.8, u'date_max_temp': 1443791366, u'max_temp': 18.5}, u'module_name': u'Netatmo HQ', u'battery_vp': 6058, u'_id': u'02:00:00:00:02:a0', u'type': u'NAModule1', u'last_seen': 1443791366},
             {u'rf_status': 75, u'data_type': [u'Temperature', u'CO2', u'Humidity'], u'last_message': 1443791386, u'firmware': 43, u'dashboard_data': {u'CO2': 931, u'Temperature': 23.5, u'time_utc': 1443791353, u'Humidity': 37, u'date_min_temp': 1443760835, u'min_temp': 22.3, u'date_max_temp': 1443790738, u'max_temp': 23.5}, u'module_name': u'Coffee Machine', u'battery_vp': 6073, u'_id': u'03:00:00:00:1c:24', u'type': u'NAModule4', u'last_seen': 1443791353},
             {u'rf_status': 55, u'data_type': [u'Temperature', u'CO2', u'Humidity'], u'last_message': 1443791386, u'firmware': 43, u'dashboard_data': {u'CO2': 1615, u'Temperature': 20.5, u'time_utc': 1443791341, u'Humidity': 44, u'date_min_temp': 1443762373, u'min_temp': 18.4, u'date_max_temp': 1443791033, u'max_temp': 20.5}, u'module_name': u'Meeting Room', u'battery_vp': 5696, u'_id': u'03:00:00:00:9f:1e', u'type': u'NAModule4', u'last_seen': 1443791341},
             {u'rf_status': 38, u'data_type': [u'Rain'], u'last_message': 1443791386, u'firmware': 8, u'dashboard_data': {u'time_utc': 1443791373, u'sum_rain_24': 0, u'sum_rain_1': 0, u'Rain': 0}, u'module_name': u'Rain Gauge', u'battery_vp': 5162, u'_id': u'05:00:00:00:0f:98', u'type': u'NAModule3', u'last_seen': 1443791386}
            ],
            u'co2_calibrating': False, u'last_status_store': 1443791390, u'wifi_status': 49, u'place': {u'city': u'Paris', u'improveLocProposed': True, u'geoip_city': u'Boulogne-billancourt', u'country': u'FR', u'altitude': 34, u'location': [2.2377964258194, 48.829050912211], u'timezone': u'Europe/Paris'}, u'dashboard_data': {u'Noise': 41, u'Temperature': 23.3, u'time_utc': 1443791377, u'Humidity': 43, u'Pressure': 1016.3, u'CO2': 1703, u'AbsolutePressure': 1012.3, u'min_temp': 20.7, u'date_max_temp': 1443780208, u'date_min_temp': 1443767519, u'max_temp': 23.4}, u'cipher_id': u'enc:16:IQwThK9q3StlEUopv05xV5nVgXwG9gOMqf7n1nAuBzpSBz5NiU1vDdh6zo8d9WHi', u'module_name': u"Boss's Office", u'station_name': u'Office in Paris', u'_id': u'70:ee:50:00:02:20', u'type': u'NAMain', u'invitation_disable': False}
        ]
    }
    
    def readDeviceList(self, file_name):
        f = open(file_name)
        data = "".join(f.readlines())
        f.close()
        return eval(data)

    @staticmethod
    def storeSimulationFile(username, password, file_name, refresh_token=""):
        authorization = ClientAuth("", refresh_token, base64.b64decode(Stations.CLIENT_ID), base64.b64decode(Stations.CLIENT_SECRET))
        if not refresh_token:
            authorization.authorize(username, password)
        deviceList = DeviceList()
        deviceList.request(authorization)
        devices_raw = deviceList.raw
        # print user_raw
        # print devices_raw
        f = open(file_name, 'w')
        f.write(str(devices_raw))
        f.close()
    
    @staticmethod
    def loadSimulationData():
        import os
        try:
            from Tools.Directories import resolveFilename, SCOPE_PLUGINS
            file_name = resolveFilename(SCOPE_PLUGINS, "Extensions/Netatmo/" + DebugRawData.SIM_FILE)
        except:
            file_name = DebugRawData.SIM_FILE
        if not os.path.exists(file_name):
            return
            DebugRawData.storeSimulationFile("user", "pass", file_name)
        print "[Netatmo] load simulation from {0}".format(file_name)
        debug = DebugRawData()
        DebugRawData.device_list = debug.readDeviceList(file_name)


if __name__ == "__main__":
    for angle in range(0, 720):
        print str.format("{0}° {1}", angle, getAngleIndex(angle))
    for angle in range(0, 361):
        print str.format("{0}° {1}", angle, getDirection(angle))

    def printNetatmo(netatmo):
        for station in netatmo.stations:
            print station
            print station.module_name
            print station.measure
            for module in station.modules:
                print module.name
                print module.module_name
                print module.measure
    
    # DebugRawData.storeSimulationFile("user", "pass", "simulation.json", "")
    netatmo = Stations("", "")
    # netatmo.SIMULATE = True
    # netatmo.authorize("user", "pass")
    netatmo.retrieveData()
    station = netatmo.getStation()
    if station:
        module = station.getModule()
        measure = MeasureData()
        measure.request(netatmo.auth, station.id, "1day", "min_hum,date_min_hum,max_hum,date_max_hum", module.id, date_end="last")  # , date_begin, date_end, limit, optimize, real_time)
        for v in measure.raw:
            for x in v['value']:
                date = time.strftime("%d.%m.%Y", time.localtime(x[1]))
                tmin = time.strftime("%H:%M", time.localtime(x[1]))
                tmax = time.strftime("%H:%M", time.localtime(x[3]))
                print "{0} min: {1} {2} max: {3} {4}".format(date, tmin, x[0], tmax, x[2])

    
    if netatmo.auth.tokenChanged:
        netatmo.auth.tokenChanged = False
        print netatmo.auth.access_token
        print netatmo.auth.refresh_token
    printNetatmo(netatmo)
