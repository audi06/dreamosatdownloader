#!/usr/bin/python
# -*- coding: utf-8 -*-
#  Netatmo for Dreambox-Enigma2
#
#  Coded by cmikula (c)2014
#  Support: www.i-have-a-dreambox.com
#
#  This plugin is licensed under the Creative Commons 
#  Attribution-NonCommercial-ShareAlike 3.0 Unported 
#  License. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#  Alternatively, this plugin may be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.
#
#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially 
#  distributed other than under the conditions noted above.
#
from Screens.InfoBar import InfoBar, MoviePlayer
from Screens.Screen import Screen
from Components.config import config


class NetatmoBar(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skinName = "NetatmoBar_V5"
    

NetatmoBarInstance = None
def initNetatmoBar():
    def showNetatmoInfoBar(self):
        if NetatmoBarInstance is not None and config.Netatmo.show_netatmobar.value:
            NetatmoBarInstance.show()

    def showNetatmoMovieBar(self):
        if NetatmoBarInstance is not None and config.Netatmo.show_moviebar.value:
            NetatmoBarInstance.show()
    
    def hideNetatmoBar(self):
        if NetatmoBarInstance is not None:
            NetatmoBarInstance.hide()
    
    def InfoBar__init__(self, *args, **kwargs):
        eInfoBar__init__(self, *args, **kwargs)
        global NetatmoBarInstance
        if NetatmoBarInstance is None:
            NetatmoBarInstance = args[0].instantiateDialog(NetatmoBar)
        self.onShow.append(self.showNetatmoBar)
        self.onHide.append(self.hideNetatmoBar)

    def MoviePlayer__init__(self, *args, **kwargs):
        eMoviePlayer__init__(self, *args, **kwargs)
        self.onShow.append(self.showNetatmoBar)
        self.onHide.append(self.hideNetatmoBar)
    
    InfoBar.showNetatmoBar = showNetatmoInfoBar
    InfoBar.hideNetatmoBar = hideNetatmoBar
    eInfoBar__init__ = InfoBar.__init__
    InfoBar.__init__ = InfoBar__init__
    
    MoviePlayer.showNetatmoBar = showNetatmoMovieBar
    MoviePlayer.hideNetatmoBar = hideNetatmoBar
    eMoviePlayer__init__ = MoviePlayer.__init__
    MoviePlayer.__init__ = MoviePlayer__init__
