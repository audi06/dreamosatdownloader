#!/usr/bin/python
# -*- coding: utf-8 -*-
#  Netatmo for Dreambox-Enigma2
#
#  Coded by cmikula (c)2013
#  Support: www.i-have-a-dreambox.com
#
#  This plugin is licensed under the Creative Commons 
#  Attribution-NonCommercial-ShareAlike 3.0 Unported 
#  License. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#  Alternatively, this plugin may be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.
#
#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially 
#  distributed other than under the conditions noted above.
#
try:
    from Components.Language import language
    from Tools.Directories import resolveFilename, SCOPE_PLUGINS, SCOPE_LANGUAGE
    from os import environ
    import gettext
    from enigma import getDesktop
    from skin import loadSkin
    
    def skinInit():
        try:
            sz_w = getDesktop(0).size().width()
        except:
            sz_w = 1280
        if sz_w == 720:
            loadSkin(resolveFilename(SCOPE_PLUGINS) + "Extensions/Netatmo/skin/720.xml")
        else:
            loadSkin(resolveFilename(SCOPE_PLUGINS) + "Extensions/Netatmo/skin/1280.xml")
    
    def localeInit():
        lang = language.getLanguage()
        environ["LANGUAGE"] = lang[:2]
        gettext.bindtextdomain("enigma2", resolveFilename(SCOPE_LANGUAGE))
        gettext.textdomain("enigma2")
        gettext.bindtextdomain("Netatmo", "%s%s" % (resolveFilename(SCOPE_PLUGINS), "Extensions/Netatmo/locale/"))
    
    def _(txt):
        t = gettext.dgettext("Netatmo", txt)
        if t == txt:
            t = gettext.gettext(txt)
        return t
    
    localeInit()
    skinInit()
    language.addCallback(localeInit)
except:
    def _(x):
        return x
