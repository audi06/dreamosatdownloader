# -* coding: utf-8 -*-
#
# Streaming Admin Plugin by gutemine
#
streamadmin_version="0.1-r1"
#
from Components.ActionMap import ActionMap, HelpableActionMap, NumberActionMap
from Components.Label import Label, MultiColorLabel
from Components.ConfigList import ConfigListScreen, ConfigList
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from Tools import Notifications
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox 
from Screens.InputBox import InputBox
from Components.Input import Input
from Screens.ChoiceBox import ChoiceBox
from Components.SystemInfo import SystemInfo
from Screens.Console import Console                                                                           
from Components.MenuList import MenuList       
from Screens.ChannelSelection import service_types_radio, service_types_tv, ChannelSelection, ChannelSelectionBase
from Components.Sources.StaticText import StaticText
from Components.config import config, configfile, ConfigSubsection, ConfigSelection, ConfigSet, ConfigBoolean, ConfigYesNo, ConfigInteger,ConfigText,  ConfigSubList, getConfigListEntry, KEY_LEFT, KEY_RIGHT, KEY_0, ConfigNothing, ConfigPIN
from Components.ServiceEventTracker import ServiceEventTracker
from Components.Sources.Source import Source
from Components.Element import cached
from enigma import quitMainloop, ePoint, eConsoleAppContainer, getDesktop, eServiceCenter, eDVBServicePMTHandler, iServiceInformation,  iPlayableService, eServiceReference, eEPGCache, eActionMap
from enigma import iServiceInformation, eServiceCenter, iDVBFrontend 
from timer import TimerEntry
from Screens.Standby import Standby, inStandby                 
from Screens.PictureInPicture import PictureInPicture
from Plugins.Plugin import PluginDescriptor
from Screens.InfoBarGenerics import InfoBarInstantRecord
from RecordTimer import parseEvent, RecordTimerEntry, AFTEREVENT
from Components.UsageConfig import preferredInstantRecordPath
from Screens.HelpMenu import HelpableScreen
import NavigationInstance
from ServiceReference import ServiceReference
import os, stat, pwd, re, glob, socket

if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/AutoPin"):
	from Plugins.Extensions.AutoPin.plugin import StreamServiceAutoPin as StreamService
else:
	from Components.Sources.StreamService import StreamService

stateIdle = iDVBFrontend.stateIdle                                              
stateFailed = iDVBFrontend.stateFailed                                          
stateTuning = iDVBFrontend.stateTuning                                          
stateLock = iDVBFrontend.stateLock                                              
stateLostLock = iDVBFrontend.stateLostLock  

yes_no_descriptions = {False: _("no"), True: _("yes")}

from enigma import eTimer, eDVBCI_UI, eDVBCIInterfaces, eEnv, eServiceReference, eServiceCenter

config.streaming = ConfigSubsection()
config.streaming.asktozap = ConfigYesNo(default = True)
config.plugins.streamadmin = ConfigSubsection()
streamadmin_zapto = []                                                     
streamadmin_zapto.append(( "inactive",_("no") ))                             
streamadmin_zapto.append(( "active",_("yes") ))                             
streamadmin_zapto.append(( "auto",_("auto") ))                             
config.plugins.streamadmin.zapto = ConfigSelection(default="inactive", choices = streamadmin_zapto)
config.plugins.streamadmin.blocking = ConfigYesNo(default = False)
config.plugins.streamadmin.blacklist = ConfigText(default = "")

streamadmin_skin=config.skin.primary_skin.value.replace("/skin.xml","")

PROC_TCP = "/proc/net/tcp6"
STATE = {
        '01':'ESTABLISHED',
        '02':'SYN_SENT',
        '03':'SYN_RECV',
        '04':'FIN_WAIT1',
        '05':'FIN_WAIT2',
        '06':'TIME_WAIT',
        '07':'CLOSE',
        '08':'CLOSE_WAIT',
        '09':'LAST_ACK',
        '0A':'LISTEN',
        '0B':'CLOSING'
        }

def _load():
    # Read the table of tcp connections & remove header 
    with open(PROC_TCP,'r') as f:
        content = f.readlines()
        content.pop(0)
    return content

def _hex2dec(s):
    return str(int(s,16))

def _ip(s):
    ip = [(_hex2dec(s[30:32])),(_hex2dec(s[28:30])),(_hex2dec(s[26:28])),(_hex2dec(s[24:26]))]
    return '.'.join(ip)

def _remove_empty(array):
    return [x for x in array if x !='']

def _convert_ip_port(array):
    host,port = array.split(':')
    return _ip(host),_hex2dec(port)

def _whois(address):               
    try:                                 
    	data = socket.gethostbyaddr(address)[0]
    except Exception, ex:                         
#       data = ex                                 
	data="                                         "
    return data    

def netstat(port, binary, client):
    content=_load()
    result = []
    dead_client=True
    for line in content:
        line_array = _remove_empty(line.split(' '))     # Split lines and remove empty spaces.
        l_host,l_port = _convert_ip_port(line_array[1]) # Convert ipaddress and port from hex to decimal.
        r_host,r_port = _convert_ip_port(line_array[2]) 
        tcp_id = line_array[0]
        state = STATE[line_array[3]]
        uid = pwd.getpwuid(int(line_array[7]))[0]       # Get user from UID.
        inode = line_array[9]                           # Need the inode to get process pid.
        pid = _get_pid_of_inode(inode)                  # Get pid prom inode.
        try:                                            # try read the process name.
            exe = os.readlink('/proc/'+pid+'/exe')
        except:
            exe = None

        remote_client=r_host+':'+r_port
        nline = [tcp_id, uid, l_host+':'+l_port, r_host+':'+r_port, state, pid, exe]
	if l_port==port and exe==binary:
        	result.append(nline)
		if client == remote_client:
#			print "[NETSTAT] found %s" % client
			dead_client=False
    if len(client) > 0:
#	if dead_client:
#		print "[NETSTAT] dead"
#	else:
#		print "[NETSTAT] alive"
	return dead_client
    else:
#	print "[NETSTAT]", result
    	return result

def _get_pid_of_inode(inode):

    # To retrieve the process pid, check every running process 
    # and look for one using the given inode.

    result=None
    for item in glob.glob('/proc/[0-9]*/fd/[0-9]*'):
        try:
            if re.search(inode,os.readlink(item)):
                result=item.split('/')[2]
        except:
            pass
    return result

# list of all streaming connections
global streamadmincon
streamadmincon=[]

# rememeber original StreamAdmin
StreamService.execBeginOri = StreamService.execBegin
StreamService.execEndOri = StreamService.execEnd

def StreamAdminExecBegin(self):
	if config.plugins.streamadmin.blocking.value:
		print "[STREAMADMIN] IS BLOCKED"
		return
	print "[STREAMADMIN] ------------------------------------------"
	StreamService.execBeginOri(self)
	print "[STREAMADMIN] ------------------------------------------"
	global streamadmincon
	service=self.ref.toString()
	channel=ServiceReference(self.ref).getServiceName()
	sockinf=netstat("8001","/usr/bin/streamproxy", "")
	rem_ip=""
	status="UNKNOWN"
	pid=""
	length=len(sockinf)
	if length > 0:
		rem_ip=sockinf[length-1][3]
		status=sockinf[length-1][4]
		pid=sockinf[length-1][5]
	adress=rem_ip.split(":")
	streamadminblack=config.plugins.streamadmin.blacklist.value.split(",")
	black=len(streamadminblack)
	i=0
	blacklisted=False
	while i < black:
		if streamadminblack[i]==adress[0]:
			blacklisted=True
		i+=1
	if not blacklisted:
		streamadmincon.append((self.ref, service, channel, rem_ip, status, pid))
		# create streaming file if doesn't exist yet
		if not os.path.exists("/tmp/stream.%s" % self.ref.toString().replace("/","_")):
			s=open("/tmp/stream.%s" % self.ref.toString().replace("/","_"),"w")
			s.write(self.ref.toString())
			s.close()
	else:
		print "[STREAMADMIN] DISABLED %s" % (adress[0])
		self.navcore.record_event.remove(self.recordEvent)
		self.navcore.stopRecordService(self.__service)
		self.__service = None

def StreamAdminExecEnd(self):
	if self.ref is None:
		print "[STREAMADMIN] StreamService has no service ref"
		return
	print "[STREAMADMIN] ------------------------------------------"
	StreamService.execEndOri(self)
	print "[STREAMADMIN] ------------------------------------------"
	service=self.ref.toString()
	channel=ServiceReference(self.ref).getServiceName()
	global streamadmincon
	streams=len(streamadmincon)
	i=0
	while i < streams:
		try:
			dead=netstat("8001","/usr/bin/streamproxy", streamadmincon[i][3])
			if dead:
				streamadmincon.remove((streamadmincon[i]))
			i+=1
		except:
			i=streams
			pass
	# remove streaming file if still exists
	if os.path.exists("/tmp/stream.%s" % self.ref.toString().replace("/","_")):
		os.remove("/tmp/stream.%s" % self.ref.toString().replace("/","_"))

# rename original StreamAdmin on startup in any case
StreamService.execBegin = StreamAdminExecBegin
StreamService.execEnd = StreamAdminExecEnd

streamadmin_title=_("Streaming Admin by gutemine")+" V%s " % streamadmin_version

class StreamAdmin(Screen, HelpableScreen, ConfigListScreen, Source):
	skin = """
	<screen position="center,60" size="820,620" title="Streaming Admin" >
	<ePixmap pixmap="skin_default/buttons/red.png" position="10,5" size="200,40" alphatest="on" />
	<ePixmap pixmap="skin_default/buttons/green.png" position="210,5" size="200,40" alphatest="on" />
	<ePixmap pixmap="skin_default/buttons/yellow.png" position="410,5" size="200,40" alphatest="on" />
	<ePixmap pixmap="skin_default/buttons/blue.png" position="610,5" size="200,40" alphatest="on" />
	<widget name="buttonred" position="10,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#9f1313" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
	<widget name="buttongreen" position="210,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#1f771f" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
	<widget name="buttonyellow" position="410,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#a08500" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
	<widget name="buttonblue" position="610,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#18188b" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
	<eLabel position="10,50" size="800,1" backgroundColor="grey" />
	<widget name="config" position="10,60" size="800,330" enableWrapAround="1" scrollbarMode="showOnDemand" />
	<eLabel position="10,570" size="800,1" backgroundColor="grey" />
	<widget name="info"  position="10,580" size="60,30" alphatest="on" />
 	<widget name="rewind"  position="210,590" size="16,16" alphatest="on" />
        <widget name="play"    position="310,590" size="16,16" alphatest="on" />
        <widget name="pause"   position="310,590" size="16,16" alphatest="on" />
        <widget name="stop"    position="410,590" size="16,16" alphatest="on" />
        <widget name="forward" position="510,590" size="16,16" alphatest="on" />
        <widget name="record"  position="610,590" size="14,14" alphatest="on" />
        <widget name="menu"  position="750,580" size="60,30" alphatest="on" />
	</screen>"""

	def __init__(self, session, args = 0):
		Screen.__init__(self, session)
		HelpableScreen.__init__(self)
     		self.skin = StreamAdmin.skin 
                import Navigation as Nav                          
                navcore=Nav.navcore     


		self.list = []                                                  
		ConfigListScreen.__init__(self, self.list, session = self.session)
		self.createSetup()       
		self.addedKeys=False
                self.onShown.append(self.setWindowTitle)

		self["buttonred"] = Label(_("Exit"))
		self["buttongreen"] = Label(_("Save"))
		self["buttonyellow"] = Label(_("blacklist"))
		self["buttonblue"] = Label(_("Setup"))
		self["info"] = Pixmap()                                       
                self["menu"] = Pixmap()                                      
		self["rewind"] = Pixmap()                                       
                self["forward"] = Pixmap()                                      
                self["stop"] = Pixmap()                                         
                self["play"] = Pixmap()                                         
                self["pause"] = Pixmap()                                        
                self["record"] = Pixmap()           

                self.onLayoutFinish.append(self.refreshLayout)

		self["EPGSelectActions"] = HelpableActionMap(self,"EPGSelectActions",
			{
				"info":			(self.info,_("Show Info")),
			}, -3)
   		self["InfobarInstantRecord"] = HelpableActionMap(self,"InfobarInstantRecord",
   			{                                                                            
           			"instantRecord":        (self.playPressed,_("blacklist")+" "+_("Stream")),                     
   			}, -3)   
		self["MediaPlayerSeekActions"] = HelpableActionMap(self,"MediaPlayerSeekActions",
			{
				"seekBack": 		(self.previousPressed,_("disable")+" "+_("Stream")),
				"seekFwd": 		(self.nextPressed,_("enable")+" "+_("Stream")),
			}, -3)

		self["MediaPlayerActions"] = HelpableActionMap(self,"MediaPlayerActions",
			{
				"pause": 		(self.playPressed,_("blacklist")+" "+_("Stream")),
				"stop": 		(self.stopPressed,_("Stop")+" "+_("Stream")),
				"menu":			(self.setup,_("Setup")),
				"subtitles": 		(self.about,_("About")),
			}, -3)
		self["SetupActions"] = HelpableActionMap(self,"SetupActions",
			{
				"save": 		(self.save,_("Save")+" "+_("Settings")),
				"cancel":		(self.cancel,_("Exit")),
				"ok": 			(self.okPressed, _("Show Info")),
			}, -6)
		self["ColorActions"] = HelpableActionMap(self,"ColorActions",
			{
				"green":		(self.save, _("Save")+" "+_("Settings")),
				"red":			(self.cancel,_("Exit")),
				"yellow":		(self.blacklist,_("Exit")),
				"blue":			(self.setup,_("Setup")),
			}, -4)

	def createSetup(self):                                                  
		# init only on first run
		self.refreshLayout(True)

	def playPressed(self):
		cur_idx = self["config"].getCurrentIndex()
		if config.plugins.streamadmin.blocking.value:
			print "[STREAMADMIN] ENABLED %d" % cur_idx
	                self["pause"].hide()  
	                self["play"].show()              
	                self["record"].hide()              
			config.plugins.streamadmin.blocking.value=False 
		else:
			print "[STREAMADMIN] DISABLED %d" % cur_idx
                        self["pause"].show()  
                        self["play"].hide()              
	                self["record"].show()              
			config.plugins.streamadmin.blocking.value=True

	def stopPressed(self):
		cur_idx = self["config"].getCurrentIndex()
		print "[STREAMADMIN] STOP %d" % cur_idx
		global streamadmincon
		length=len(streamadmincon)
		if cur_idx < length:
			ref=streamadmincon[cur_idx][0]
			serv=streamadmincon[cur_idx][1]
			channel=streamadmincon[cur_idx][2]
			rem_ip=streamadmincon[cur_idx][3]
			status=streamadmincon[cur_idx][4]
			pid=streamadmincon[cur_idx][5]
			print "[STREAMADMIN] STOP %d %s %s %s %s %s" % (cur_idx, ref, channel, rem_ip, status, pid)
			from Components.Sources.StreamService import StreamService
	                import Navigation as Nav                          
                	navcore=Nav.navcore     
			__service = navcore.recordService(ref)
			navcore.stopRecordService(__service)
			cmd="kill -9 %s" % (pid)
			print "[STREAMADMIN] KILLS %s" % (pid)
			self.container = eConsoleAppContainer() 
                        self.container.execute(cmd)     
			global streamadmincon
			streams=len(streamadmincon)
			i=0
			while i < streams:
				try:
					dead=netstat("8001","/usr/bin/streamproxy", streamadmincon[i][3])
					if dead:
						streamadmincon.remove((streamadmincon[i]))
					i+=1
				except:
					i=streams
					pass
			# remove streaming file
			if os.path.exists("/tmp/stream.%s" % ref.toString().replace("/","_")):
				os.remove("/tmp/stream.%s" % ref.toString().replace("/","_"))
		else:
			self.session.open(MessageBox, _("no stream selected"), MessageBox.TYPE_ERROR)

	def previousPressed(self):
		cur_idx = self["config"].getCurrentIndex()
		print "[STREAMADMIN] DISABLE %d" % cur_idx
		global streamadmincon
		length=len(streamadmincon)
		if cur_idx < length:
			ref=streamadmincon[cur_idx][0]
			serv=streamadmincon[cur_idx][1]
			channel=streamadmincon[cur_idx][2]
			rem_ip=streamadmincon[cur_idx][3]
			status=streamadmincon[cur_idx][4]
			pid=streamadmincon[cur_idx][5]
			adress=rem_ip.split(":")
			print ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
			print  config.plugins.streamadmin.blacklist.value
			streamadminblack=config.plugins.streamadmin.blacklist.value.split(",")
			print streamadminblack
			print ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
			black=len(streamadminblack)
			i=0
			blacklisted=False
			while i < black:
				if streamadminblack[i]==adress[0]:
					blacklisted=True
				i+=1
			if not blacklisted:
				streamadminblack.append(adress[0])
				config.plugins.streamadmin.blacklist.value=','.join(streamadminblack).lstrip(',')
				
				print "[STREAMADMIN] DISABLED %s" % (adress[0])
			else:
				print "[STREAMADMIN] WAS DISABLED %s" % (adress[0])
		else:
			self.session.open(MessageBox, _("no stream selected"), MessageBox.TYPE_ERROR)

	def nextPressed(self):
		cur_idx = self["config"].getCurrentIndex()
		print "[STREAMADMIN] ENABLE %d" % cur_idx
		global streamadmincon
		length=len(streamadmincon)
		if cur_idx < length:
			ref=streamadmincon[cur_idx][0]
			serv=streamadmincon[cur_idx][1]
			channel=streamadmincon[cur_idx][2]
			rem_ip=streamadmincon[cur_idx][3]
			status=streamadmincon[cur_idx][4]
			pid=streamadmincon[cur_idx][5]
			adress=rem_ip.split(":")
			streamadminblack=config.plugins.streamadmin.blacklist.value.split(",")
			black=len(streamadminblack)
			i=0
			blacklisted=False
			while i < black:
				if streamadminblack[i]==adress[0]:
					blacklisted=True
				i+=1
			if blacklisted:
				print "[STREAMADMIN] ENABLED %s" % (adress[0])
				streamadminblack.remove(adress[0])
				config.plugins.streamadmin.blacklist.value=','.join(streamadminblack).lstrip(',') 
			else:
				print "[STREAMADMIN] WAS ENABLED %s" % (adress[0])
		else:
			self.session.open(MessageBox, _("no stream selected"), MessageBox.TYPE_ERROR)


	def okPressed(self, action=None):
		cur_idx = self["config"].getCurrentIndex()
		print "[STREAMADMIN] OK %d" % cur_idx

	def getPiconPath(self,name):
		if os.path.exists("/usr/share/enigma2/%s/skin_default/icons/%s.svg" % (streamadmin_skin,name)):
#			print "[STREAMADMIN] found %s.svg in skin ..." % name
			return "/usr/share/enigma2/%s/skin_default/icons/%s.svg" % (streamadmin_skin,name)
		elif os.path.exists("/usr/share/enigma2/%s/skin_default/icons/%s.png" % (streamadmin_skin,name)):
#			print "[STREAMADMIN] found %s.png in skin ..." % name
			return "/usr/share/enigma2/%s/skin_default/icons/%s.png" % (streamadmin_skin,name)
		elif os.path.exists("/usr/share/enigma2/skin_default/icons/%s.svg" % (name)):
#			print "[STREAMADMIN] found %s.svg in default skin ..." % name
			return "/usr/share/enigma2/skin_default/icons/%s.svg" % (name)
		else:
#			print "[STREAMADMIN] found %s.png in default skin ..." % name
			return "/usr/share/enigma2/skin_default/icons/%s.png" % (name)


	def setWindowTitle(self):
		self["info"].instance.setPixmapFromFile(self.getPiconPath("info"))  
		self["menu"].instance.setPixmapFromFile(self.getPiconPath("menu"))  
		self["rewind"].instance.setPixmapFromFile(self.getPiconPath("ico_mp_rewind"))  
		self["forward"].instance.setPixmapFromFile(self.getPiconPath("ico_mp_forward"))
		self["stop"].instance.setPixmapFromFile(self.getPiconPath("ico_mp_stop"))      
		self["play"].instance.setPixmapFromFile(self.getPiconPath("ico_mp_play"))      
		self["pause"].instance.setPixmapFromFile(self.getPiconPath("ico_mp_pause"))    
		self["record"].instance.setPixmapFromFile(self.getPiconPath("record"))         
		self.setTitle(_("Streaming Admin"))

	def runFinished(self, retval):    
		pass

	def refreshLayout(self,first=False):
#		print "[STREAMADMIN] updating status"
		if first:
			self.menuList = ConfigList(self.list)                           
	                self.menuList.list = self.list                                  
	                self.menuList.l.setList(self.list)                              
	                self["config"] = self.menuList        
		else:
			del self.list
			self.list = []                                                  
			if config.plugins.streamadmin.blocking.value:
	                        self["pause"].hide()  
	                        self["play"].show()              
		                self["record"].hide()              
			else:
	                        self["pause"].show()  
	                        self["play"].hide()              
		                self["record"].show()              
		global streamadmincon
		streams=len(streamadmincon)
		i=0
		while i < streams:
			channel=streamadmincon[i][2]
			rem_ip=streamadmincon[i][3]
			status=streamadmincon[i][4]
			pid=streamadmincon[i][5]
			address=rem_ip.split(":")
			whois = _whois(address[0])  
#			print "[STREAMADMIN] whois: %s" % (whois)
			stream_line=" %s %s %s" % (rem_ip, whois, channel)
#			print "[STREAMADMIN] Streaming: %s" % (stream_line)
			self.list.append((stream_line, ConfigNothing(), i))
			i+=1
                self.menuList.l.setList(self.list)                              
		self.StreamAdminRefreshTimer = eTimer()
		self.StreamAdminRefreshTimer_conn = self.StreamAdminRefreshTimer.timeout.connect(self.refreshLayout)
		self.StreamAdminRefreshTimer.start(500, True)

	def save(self):
		self.StreamAdminRefreshTimer.stop()
#		for x in self["config"].list:
#			x[1].save()
		config.plugins.streamadmin.blocking.save()
		config.plugins.streamadmin.blacklist.save()
		self.close(True)

	def cancel(self):
		self.StreamAdminRefreshTimer.stop()
#		for x in self["config"].list:
#			x[1].cancel()
		config.plugins.streamadmin.blocking.cancel()
		config.plugins.streamadmin.blacklist.cancel()
		self.close(False)

	def setup(self):
		self.session.open(StreamAdminConfigure)

	def blacklist(self):
		self.session.open(StreamAdminBlacklist)

	def info(self):
		cur_idx = self["config"].getCurrentIndex()
		print "[STREAMADMIN] INFO %d" % cur_idx
		global streamadmincon
		streams=len(streamadmincon)
		if streams > 0:
			ref=streamadmincon[cur_idx][0]
			service=streamadmincon[cur_idx][1]
			channel=streamadmincon[cur_idx][2]
			rem_ip=streamadmincon[cur_idx][3]
			rem_part=[]
			rem_part=rem_ip.split(":")
			status=streamadmincon[cur_idx][4]
			pid=streamadmincon[cur_idx][5]
			text="%s: %s\n%s: %s\n%s: %s\n%s: %s\n%s: %s\n%s: %s" % (_("Name"),channel, _("Service"), service, _("IP Address"), rem_part[0], _("Port"), rem_part[1], _("Status"), status, _("PID"), pid)
			self.session.open(MessageBox, text , MessageBox.TYPE_INFO)
		else:
			self.session.open(MessageBox, _("no stream selected"), MessageBox.TYPE_ERROR)

	def about(self):
		self.session.open(MessageBox, streamadmin_title , MessageBox.TYPE_INFO)

class StreamAdminConfigure(Screen, ConfigListScreen):
	skin = """
	<screen position="center,60" size="820,620" title="Streaming Admin Setup" >
	<ePixmap pixmap="skin_default/buttons/red.png" position="10,5" size="200,40" alphatest="on" />
	<ePixmap pixmap="skin_default/buttons/green.png" position="210,5" size="200,40" alphatest="on" />
	<ePixmap pixmap="skin_default/buttons/yellow.png" position="410,5" size="200,40" alphatest="on" />
	<ePixmap pixmap="skin_default/buttons/blue.png" position="610,5" size="200,40" alphatest="on" />
	<widget name="buttonred" position="10,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#9f1313" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
	<widget name="buttongreen" position="210,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#1f771f" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
	<widget name="buttonyellow" position="410,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#a08500" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
	<widget name="buttonblue" position="610,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#18188b" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
	<eLabel position="10,50" size="800,1" backgroundColor="grey" />
	<widget name="config" position="10,60" size="800,550" enableWrapAround="1" scrollbarMode="showOnDemand" />
	</screen>"""

	def __init__(self, session):
		Screen.__init__(self, session)
     		self.skin = StreamAdminConfigure.skin 
		self.list = []                                                  

		ConfigListScreen.__init__(self, self.list, session = self.session)
		self.createSetup()       
	        self.onShown.append(self.setWindowTitle)                                                            
#               self.onLayoutFinish.append(self.refreshLayout)
        	# explizit check on every entry                                                                     
        	self.onChangedEntry = []                                                                            
		self["buttonred"] = Label(_("Exit"))
		self["buttongreen"] = Label(_("Save"))
		self["buttonyellow"] = Label(_("---"))
		self["buttonblue"] = Label(_("About"))
		self["actions"] = ActionMap(["WizardActions", "ColorActions", "MenuActions"], {"red": self.cancel, "green": self.leave, "blue": self.about, "yellow": self.cancel, "back": self.cancel, "menu": self.cancel, "cancel": self.cancel  }, -1) 

	def setWindowTitle(self):                                                                               
        	self.setTitle(_("Streaming Admin")+" "+_("Setup"))

	def createSetup(self):                                                  
		# init only on first run
		self.refreshLayout(True)

	def refreshLayout(self,first=False):
		if first:
			self.menuList = ConfigList(self.list)                           
		        self.menuList.list = self.list                                  
		        self.menuList.l.setList(self.list)                              
		        self["config"] = self.menuList        
                self.list.append(getConfigListEntry(_("No to all")+" "+_("Streaming"), config.plugins.streamadmin.blocking))
                self.menuList.l.setList(self.list)                              

        def leave(self):
		for x in self["config"].list:
			x[1].save()
		self.close(True)

    	def cancel(self):                                                                                                         
		for x in self["config"].list:
			x[1].cancel()
        	self.close(False)       

        def about(self):
		self.session.open(MessageBox, streamadmin_title, MessageBox.TYPE_INFO)

class StreamAdminBlacklist(Screen, ConfigListScreen):
	skin = """
	<screen position="center,60" size="820,620" title="Streaming Admin Blacklist" >
	<ePixmap pixmap="skin_default/buttons/red.png" position="10,5" size="200,40" alphatest="on" />
	<ePixmap pixmap="skin_default/buttons/green.png" position="210,5" size="200,40" alphatest="on" />
	<ePixmap pixmap="skin_default/buttons/yellow.png" position="410,5" size="200,40" alphatest="on" />
	<ePixmap pixmap="skin_default/buttons/blue.png" position="610,5" size="200,40" alphatest="on" />
	<widget name="buttonred" position="10,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#9f1313" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
	<widget name="buttongreen" position="210,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#1f771f" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
	<widget name="buttonyellow" position="410,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#a08500" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
	<widget name="buttonblue" position="610,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#18188b" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
	<eLabel position="10,50" size="800,1" backgroundColor="grey" />
	<widget name="config" position="10,60" size="800,550" enableWrapAround="1" scrollbarMode="showOnDemand" />
	</screen>"""

	def __init__(self, session):
		Screen.__init__(self, session)
     		self.skin = StreamAdminBlacklist.skin 
		self.list = []                                                  

		ConfigListScreen.__init__(self, self.list, session = self.session)
		self.createSetup()       
	        self.onShown.append(self.setWindowTitle)                                                            
                self.onLayoutFinish.append(self.refreshLayout)
        	# explizit check on every entry                                                                     
        	self.onChangedEntry = []                                                                            
		self["buttonred"] = Label(_("Exit"))
		self["buttongreen"] = Label(_("Add")+" (+)")
		self["buttonyellow"] = Label(_("Remove")+" (-)")
		self["buttonblue"] = Label(_("About"))
		self["actions"] = ActionMap(["WizardActions", "ColorActions", "MenuActions"], {"red": self.cancel, "green": self.add_ip, "blue": self.about, "yellow": self.whitelist, "back": self.cancel, "menu": self.cancel  }, -1) 

	def setWindowTitle(self):                                                                               
        	self.setTitle(_("Streaming Admin")+" "+_("IP Address")+" "+_("blacklist"))

	def createSetup(self):                                                  
		# init only on first run
		self.refreshLayout(True)

	def refreshLayout(self,first=False):
		if first:
			self.menuList = ConfigList(self.list)                           
        	        self.menuList.list = self.list                                  
        	        self.menuList.l.setList(self.list)                              
        	        self["config"] = self.menuList        
		print ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
		print  config.plugins.streamadmin.blacklist.value
		streamadminblack=config.plugins.streamadmin.blacklist.value.split(",")
		print streamadminblack
		print ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
		black=len(streamadminblack)
		del self.list
		self.list = []                                                  
		if black > 0:
#			print "[STREAMADMIN] updating blacklist"
			i=0
			while i < black:
				self.list.append((streamadminblack[i], ConfigNothing(), i))
				i+=1
                self.menuList.l.setList(self.list)                              
		self.StreamAdminBlacklistRefreshTimer = eTimer()
		self.StreamAdminBlacklistRefreshTimer_conn = self.StreamAdminBlacklistRefreshTimer.timeout.connect(self.refreshLayout)
		self.StreamAdminBlacklistRefreshTimer.start(500, True)

        def leave(self):
		self.close()

    	def cancel(self):                                                                                                         
        	self.close()       

    	def add_ip(self):                                                                                                         
		print "[STREAMADMIN] ADD IPs"
                self.session.openWithCallback(self.askForBlacklist,ChoiceBox,_("Add"), self.getIPList())

	def getIPList(self):                                                   
		streamadminblack=config.plugins.streamadmin.blacklist.value.split(",")
		black=len(streamadminblack)
	        arpip = []                                                          
		f=open("/proc/net/arp")
		f.readline()
		lines=f.readlines()
		f.close()
		length=len(lines)
		i=0
		arp_ips=[]
		ll=[]
		while i < length:
			ll=lines[i].split()
			candidate=ll[0].lstrip().rstrip()
#			print ll[0]
			j=0
			blacklisted=False
			while j < black:
				if streamadminblack[j]==candidate:
					blacklisted=True
				j+=1
			if not blacklisted:
				arp_ips.append((ll[0], ll[0]))
			i+=1
		arp_ips.sort()
		return arp_ips
        
	def askForBlacklist(self,black):
        	if black is None:
        		return
        	else:
        		new=black[1].rstrip().lstrip()
			streamadminblack=config.plugins.streamadmin.blacklist.value.split(",")
			black=len(streamadminblack)
			i=0
			blacklisted=False
			while i < black:
				if streamadminblack[i]==new:
					blacklisted=True
				i+=1
			if not blacklisted:
				print "[STREAMADMIN] ADDING %s" % new
				streamadminblack.append(new)
				config.plugins.streamadmin.blacklist.value=','.join(streamadminblack).lstrip(',') 

    	def whitelist(self):                                                                                                         
		cur_idx = self["config"].getCurrentIndex()
		streamadminblack=config.plugins.streamadmin.blacklist.value.split(",")
		black=len(streamadminblack)
		if black > 0:
			print "[STREAMADMIN] whitelist %d %s" % (cur_idx, streamadminblack[cur_idx])
			streamadminblack.remove(streamadminblack[cur_idx])
			config.plugins.streamadmin.blacklist.value=','.join(streamadminblack).lstrip(',') 
			self.refreshLayout()

        def about(self):
		self.session.open(MessageBox, streamadmin_title, MessageBox.TYPE_INFO)

def startStreamAdmin(session, **kwargs):
	session.open(StreamAdmin)    

def Plugins(**kwargs):
	return [PluginDescriptor(name=_("Streaming Admin"), description=_("administrate streaming connections"), where = PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=startStreamAdmin),
		PluginDescriptor(name=_("Streaming Admin"), description=_("administrate streaming connections"), where=PluginDescriptor.WHERE_MENU, fnc=mainconf)]

def mainconf(menuid):
	if menuid != "network":                                                  
		return [ ]                                                     
	return [(_("Streaming Admin"), startStreamAdmin, "streamadmin", None)]  
