#######################
# -*- coding: utf-8 -*-
#
from enigma import *
from Components.ActionMap import ActionMap, HelpableActionMap
from Components.AVSwitch import AVSwitch
from Components.Button import Button
from Components.ConfigList import ConfigList, ConfigListScreen
from Components.config import config, configfile, ConfigText, ConfigInteger, ConfigSelection, ConfigSubList, ConfigSubsection, ConfigPassword, ConfigYesNo, getConfigListEntry
from Components.config import ConfigEnableDisable, ConfigClock, ConfigNumber, ConfigSubDict, NoSave, ConfigSelectionNumber
from Components.config import KEY_LEFT, KEY_RIGHT, KEY_HOME, KEY_END, KEY_0, KEY_DELETE, KEY_BACKSPACE, KEY_OK, KEY_TOGGLEOW, KEY_ASCII, KEY_TIMEOUT, KEY_NUMBERS
from Components.Console import Console as iConsole
from Components.Converter.StringList import StringList
from Components.FileList import FileList   
from Components.Input import Input
from Components.Label import Label
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
from Components.Pixmap import Pixmap
from Components.PluginComponent import plugins
from Components.ServiceEventTracker import ServiceEventTracker, InfoBarBase
from Components.ServiceList import ServiceList
from Components.Sources.List import List
from Components.Sources.Progress import Progress
from Components.Sources.Source import Source
from Components.Sources.StaticText import StaticText
from Components.Task import Task, Job, job_manager as JobManager, Condition
from Plugins.Plugin import PluginDescriptor
from Screens.Console import Console
from Screens.InfoBar import MoviePlayer, InfoBar
from Screens.InfoBarGenerics import *
# from Screens.InfoBarGenerics import InfoBarNotifications, InfoBarServiceNotifications, InfoBarTimeshiftState, InfoBarTimeshift, InfoBarNumberZap
# from Screens.InfoBarGenerics import InfoBarShowHide, NumberZap, InfoBarSeek, InfoBarAudioSelection, InfoBarSubtitleSupport, InfoBarEPG 
from Screens.InputBox import InputBox
from Screens.MessageBox import MessageBox
from Screens.MovieSelection import MovieSelection
from Screens.Screen import Screen
from Screens.Standby import TryQuitMainloop, Standby
from Screens.TaskView import JobView
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Tools import Notifications, ASCIItranslit
from Tools.BoundFunction import boundFunction
from Tools.Directories import fileExists, copyfile, pathExists
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from Tools.Downloader import downloadWithProgress
from Tools.LoadPixmap import LoadPixmap
#from Tools.NumericalTextInput import NumericalTextInput
from datetime import datetime
from operator import itemgetter
from os import environ as SetValue, getenv as ReturnValue
from os import environ, listdir, path, readlink, system, rename
from os import remove, mkdir, chmod 
# from time import time
from twisted.web.client import downloadPage, getPage, http
from urllib import quote_plus
from xml.dom import Node, minidom
from xml.etree.cElementTree import fromstring, ElementTree
import xml.etree.cElementTree
import base64
import hashlib
import os, re, glob
import shutil 
import socket
import gettext
import sys
import urllib
# import urllib as ul
import urllib2 #, cookielib
import time
from Tools.Notifications import AddPopup
#!/usr/bin/env python


namefolder='XCplugin'

# VERSION
version=" 5.0"
currversion = '5.0'
lstvrs = []
lnktxt = 'aHR0cDovL3d3dy5jb3J2b25lLmNvbS9jb3J2b25lLmNvbS9wbHVnaW4veGNwbHVnaW4vdXBkYXRlWGNQbHVnaW4udHh0' #for update plugin

varlnktxt = base64.b64decode(lnktxt)
chckvr = urllib.urlopen(varlnktxt)
chckvrs = chckvr.read()
lstvrs = chckvrs
lnkpth = 'aHR0cDovL2x1bHVsbGEuYWx0ZXJ2aXN0YS5vcmcvdXBsb2FkL2ZpbGVzLw=='
varlnkpth = base64.b64decode(lnkpth)

# SETTINGS
PLUGIN_PATH = '/usr/lib/enigma2/python/Plugins/Extensions/XCplugin'


SKIN_PATH = PLUGIN_PATH
HD = getDesktop(0).size()
BRAND = '/usr/lib/enigma2/python/boxbranding.so'
BRANDP = '/usr/lib/enigma2/python/Plugins/PLi/__init__.pyo'
BRANDPLI ='/usr/lib/enigma2/python/Tools/StbHardware.pyo'
VIDEO_FMT_PRIORITY_MAP = {'38': 1, '37': 2, '22': 3, '18': 4, '35': 5, '34': 6}
NTIMEOUT = 30
socket.setdefaulttimeout(NTIMEOUT)

# SCREEN PATH SETTING
if HD.width() > 1280:
   CHANNEL_NUMBER = [3, 7, 60, 50, 0]
   CHANNEL_NAME = [70, 7, 1500, 50, 1]
   FONT_0 = ('Regular', 32)
   FONT_1 = ('Regular', 32)
   BLOCK_H = 50
   SKIN_PATH = PLUGIN_PATH + '/skin/fhd'

else:
   CHANNEL_NUMBER = [3, 5, 40, 40, 0]
   CHANNEL_NAME = [55, 5, 900, 40, 1]
   FONT_0 = ('Regular', 20)
   FONT_1 = ('Regular', 20)
   BLOCK_H = 30
   SKIN_PATH = PLUGIN_PATH + '/skin/hd'


global piclogo, pictmp, xmlname
piclogo = SKIN_PATH + '/iptvlogo.jpg'
pictmp =  '/tmp/poster.jpg'

xmlname = ''


#
def ReloadBouquet():
    eDVBDB.getInstance().reloadServicelist()
    eDVBDB.getInstance().reloadBouquets() 
    # from Tools.Notifications import AddPopup
    # messageText = _('XcPlugin\n\nReload list in progress...\n\nwait please...')
    # AddPopup(messageText, MessageBox.TYPE_INFO, timeout=3)
# #
def isExtEplayer3Available():
    return os.path.isfile(eEnv.resolve('$bindir/exteplayer3'))

def isGstPlayerAvailable():
    return os.path.isfile(eEnv.resolve('$bindir/gst-launch-1.0'))

##################################################################################
from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS, SCOPE_LANGUAGE
#import gettext
PluginLanguageDomain = "XCplugin"
PluginLanguagePath = '/usr/lib/enigma2/python/Plugins/Extensions/XCplugin/locale'

def localeInit():
    lang = language.getLanguage()[:2]
    os.environ['LANGUAGE'] = lang
    gettext.bindtextdomain(PluginLanguageDomain, PluginLanguagePath)
    gettext.bindtextdomain('enigma2', resolveFilename(SCOPE_LANGUAGE, ''))


def _(txt):
    t = gettext.dgettext(PluginLanguageDomain, txt)
    if t == txt:
        t = gettext.dgettext('enigma2', txt)
    return t

localeInit()
language.addCallback(localeInit)



def OnclearMem():
        system("sync")
        system("echo 3 > /proc/sys/vm/drop_caches")


def clear_img():
    if fileExists('/tmp/poster.jpg'):
        debug('DELETE .JPG')
        path = '/tmp'

        cmd = 'rm -f %s/*.jpg' % path
        debug(cmd, 'CMD')
        try:
            status = os.popen(cmd).read()
            debug(status, 'delete 1')
            system("cd / && cp -f " + piclogo + ' /tmp/poster.jpg')        
        except Exception as ex:
            print ex
            print 'ex delete 1'
            try:
                result = commands.getoutput(cmd)
                debug(result, 'delete 2')
            except Exception as ex:
                print ex
                print 'ex delete 2'


def remove_line(filename, what):
    if os.path.isfile(filename):
        file_read = open(filename).readlines()
        file_write = open(filename, 'w')
        for line in file_read:
            if what not in line:
                file_write.write(line)

        file_write.close()

try:
	import servicewebts
	print 'OK servicewebts'
except Exception as ex:
	print ex
	print 'ERROR servicewebts'


def mount_movie():
    pthmovie = []
    if os.path.isfile('/proc/mounts'):
        for line in open('/proc/mounts'):
#x nas suspend  if '/dev/sd' in line or '/dev/disk/by-uuid/' in line or '/dev/mmc' in line or '/dev/mtdblock' in line:
            if '/dev/sd' in line or '/dev/disk/by-uuid/' in line or '/dev/mmc' in line or '/dev/mtdblock' in line:
                drive = line.split()[1].replace('\\040', ' ') + '/'

                if drive== "/media/hdd/" :

                    if not os.path.exists('/media/hdd/movie'):
                        system('mkdir /media/hdd/movie')

                if drive== "/media/usb/" :

                    if not os.path.exists('/media/usb/movie'):
                        system('mkdir /media/usb/movie')                    

                if not drive in pthmovie: 
                    pthmovie.append(drive)
    system('mkdir /tmp/movie')
    pthmovie.append('/tmp/')
    return pthmovie    


# CONFIG
config.plugins.XCplugin = ConfigSubsection()
config.plugins.XCplugin.configured = ConfigYesNo(default = False)
config.plugins.XCplugin.hostaddress = ConfigText(default = "exampleserver.com:8888")

config.plugins.XCplugin.user = ConfigText(default = "Enter Username", visible_width = 50, fixed_size = False)
config.plugins.XCplugin.passw = ConfigPassword(default = "******", fixed_size = False, censor = '*')
if os.path.exists ('/usr/lib/enigma2/python/Plugins/SystemPlugins/ServiceApp') and isExtEplayer3Available :
    config.plugins.XCplugin.services = ConfigSelection(default='Gstreamer', choices=['Gstreamer', 'Exteplayer3' ])
else:
    config.plugins.XCplugin.services = ConfigSelection(default='Gstreamer', choices=[('Gstreamer')])
config.plugins.XCplugin.bouquettop = ConfigSelection(default='Bottom', choices=['Bottom', 'Top'])

config.plugins.XCplugin.pthmovie = ConfigSelection(choices = mount_movie())
config.plugins.XCplugin.pthxmlfile = ConfigSelection(default='/etc/enigma2/xc', choices=['/etc/enigma2/xc', '/media/hdd/xc', '/media/usb/xc'])

# config.plugins.XCplugin.pthxmlfile = ConfigSelection(default='/etc/enigma2/xc/', choices=['/etc/enigma2/xc/', '/media/hdd/xc/', '/media/usb/xc/'])

if not os.path.exists(config.plugins.XCplugin.pthxmlfile.value):
    system('mkdir ' + config.plugins.XCplugin.pthxmlfile.value)
if not fileExists(config.plugins.XCplugin.pthxmlfile.value + '/' + 'xc_e2_plugin.xml'):
    # dest = config.plugins.XCplugin.pthxmlfile.value
    # shutil.copy2('/usr/lib/enigma2/python/Plugins/Extensions/XCplugin/cfg/xc_e2_plugin.xml', dest )  

    filesave = 'xc_e2_plugin.xml' 
    # f5 = open(config.plugins.XCplugin.pthxmlfile.value + '/' + filesave, "w") 
    pth= config.plugins.XCplugin.pthxmlfile.value + '/'
    print 'pth:', pth                
    f5 = open(pth + filesave, "w") 
    f5.write(str('<?xml version="1.0" encoding="UTF-8" ?>\n' + '<items>\n' + '<plugin_version>' + currversion + '</plugin_version>\n' +'<xtream_e2portal_url><![CDATA[http://exampleserver.com:8888/enigma2.php]]></xtream_e2portal_url>\n' + '<username>Enter Username</username>\n' + '<password>Enter Password</password>\n'+ '</items>'))
    f5.close()
                    

# if not fileExists(config.plugins.XCplugin.pthxmlfile.value + 'xc_e2_plugin.xml'):
    # dest = config.plugins.XCplugin.pthxmlfile.value
    # shutil.copy2('/usr/lib/enigma2/python/Plugins/Extensions/XCplugin/cfg/xc_e2_plugin.xml', dest )  

config.plugins.XCplugin.typem3utv = ConfigSelection(default = "MPEGTS to TV", choices = ["M3U to TV","MPEGTS to TV"])
config.plugins.XCplugin.autoupd = ConfigYesNo(default=True)
config.plugins.XCplugin.VNetSpeedInfo = ConfigYesNo(default=False)
config.plugins.XCplugin.strtmain = ConfigYesNo(default=True)
config.plugins.XCplugin.LivePlayer = ConfigYesNo(default=True)

#not tested autotimer
config.plugins.XCplugin.autobouquetupdate = ConfigYesNo(default=False)
config.plugins.XCplugin.updateinterval = ConfigSelectionNumber(default=24, min=1, max=48, stepwidth=1)
config.plugins.XCplugin.last_update = ConfigText(default = "none") 
Path_Movies = config.plugins.XCplugin.pthmovie.value+'movie/'
Path_XML = config.plugins.XCplugin.pthxmlfile.value +'/'

system("cd / && cp -f " + piclogo + ' /tmp/poster.jpg')


# CONFIG XC
class xc_config(Screen, ConfigListScreen):
        def __init__(self, session):
                self.session = session
                if fileExists(BRAND) or fileExists(BRANDP):
                   skin = SKIN_PATH + '/xc_config_open.xml'
                else:
                   skin = SKIN_PATH + '/xc_config.xml'
                f = open(skin, 'r')
                self.skin = f.read()
                f.close()        
                Screen.__init__(self, session)
                self.setup_title = _("XtreamCode-Config")
                self.onChangedEntry = [ ]
                self.list = []
                ConfigListScreen.__init__(self, self.list, session = self.session, on_change = self.changedEntry)
                self.createSetup()
                self['key_blu'] = Label(_("Import infos server"))#ADDADDADDADDADD
                self['key_blu'].hide()#ADDADDADDADDADD
                info = ''
                self['info2'] = Label(info)

                self['srvcsval'] = Label()#ADDADDADDADDADD
                self['VNetSpeedInfo'] = Label()#ADDADDADDADDADD
                self['LivePlayer'] = Label()#ADDADDADDADDADD
                self['ptchxzz'] = Label()#ADDADDADDADDADD
                self['ptchmovie'] = Label()#ADDADDADDADDADD
                self['typem3utv'] = Label()#ADDADDADDADDADD
                
                self['statusbar'] = Label()

                self.createSetup()  
                self.update_status()  
                self.showhide()#ADDADDADDADDADD                
                self.downloading = False                  

                self.ConfigText()#ADDADDADDADDADD               
                self['version'] = Label(_(' V. %s' % version))
                self["key_red"] = Label(_("Close"))
                self["key_green"] = Label(_("Save"))
                self['key_yellow'] = Label(_("Update"))
                self['progress'] = Progress()
                self['progresstext'] = StaticText()
                self.xtimer = eTimer()
                try:
                    self.xtimer.callback.append(self.plugupdt)
                except:
                    self.xtimer_conn = self.xtimer.timeout.connect(self.plugupdt)
                self.xtimer.start(3000, 1)
                self["setupActions"] = ActionMap(['OkCancelActions', 'DirectionActions', 'ColorActions', 'VirtualKeyboardActions', 'ActiveCodeActions'],
                {
                        "red": self.extnok,
                        "cancel": self.extnok,
                        'yellow': self.plugupdt,
                        'blue': self.ImportInfosServer,#ADD
                        "green": self.cfgok,
                        'showVirtualKeyboard': self.KeyText,
                        "ok": self.Ok_edit

                }, -1)
                self.onLayoutFinish.append(self.layoutFinished)

        def update_status(self):
            if config.plugins.XCplugin.autobouquetupdate:
            # if config.plugins.XCplugin.last_update:
                self['statusbar'].setText('Last channel update: %s' % config.plugins.XCplugin.last_update.value)
        def layoutFinished(self):
            self.setTitle(self.setup_title)
                

        def createSetup(self):
            global xmlname
            self.editListEntry = None
            self.list = []

            xmlname = ''
            self.list.append(getConfigListEntry(_("Enable Local Server"), config.plugins.XCplugin.configured))
            if config.plugins.XCplugin.configured.value:
                self.list.append(getConfigListEntry(_('Server URL'), config.plugins.XCplugin.hostaddress)) 
                self.list.append(getConfigListEntry(_('Server Username'), config.plugins.XCplugin.user)) 
                self.list.append(getConfigListEntry(_('Server Password'), config.plugins.XCplugin.passw)) 
                xmlname = config.plugins.XCplugin.hostaddress.value
            
            self.list.append(getConfigListEntry(_('Automatic bouquet update (schedule):'), config.plugins.XCplugin.autobouquetupdate))
            if config.plugins.XCplugin.autobouquetupdate.value:
                self.list.append(getConfigListEntry(_('Update interval (hours):'), config.plugins.XCplugin.updateinterval))
                # self.list.append(getConfigListEntry(_('Update interval (minutes):'), config.plugins.XCplugin.updateinterval))                                                                               
            
            self.list.append(getConfigListEntry(_("Services Type"), config.plugins.XCplugin.services))
            self.list.append(getConfigListEntry(_("LivePlayer Active "), config.plugins.XCplugin.LivePlayer))               
            self.list.append(getConfigListEntry(_("NetSpeed in Player "), config.plugins.XCplugin.VNetSpeedInfo))
            self.list.append(getConfigListEntry(_("Folder file xml"), config.plugins.XCplugin.pthxmlfile))
            self.list.append(getConfigListEntry(_("Folder Movie "), config.plugins.XCplugin.pthmovie)) 
            self.list.append(getConfigListEntry(_("Conversion type List "), config.plugins.XCplugin.typem3utv))
            self.list.append(getConfigListEntry(_("Place IPTV bouquets at "), config.plugins.XCplugin.bouquettop))            
            self.list.append(getConfigListEntry(_('Auto Update Plugin:'), config.plugins.XCplugin.autoupd))
            self.list.append(getConfigListEntry(_("Link in Main Menu  "), config.plugins.XCplugin.strtmain))
            self["config"].list = self.list
            self["config"].setList(self.list)


        def changedEntry(self):
            for x in self.onChangedEntry:
                    x()        

        def getCurrentEntry(self):
            return self["config"].getCurrent()[0]


        #
        def showhide(self):
            if config.plugins.XCplugin.configured.value:
                self['key_blu'].show()
                self['info2'].setText('you can import information from the server from /tmp/xc.txt')
            else:
                self['key_blu'].hide()
                self['info2'].setText('')

        def getCurrentValue(self):
            return str(self["config"].getCurrent()[1].getText())

        def createSummary(self):
            from Screens.Setup import SetupSummary
            return SetupSummary


        def keyLeft(self):
            ConfigListScreen.keyLeft(self)
            print "current selection:", self["config"].l.getCurrentSelection()
            self.createSetup()
            self.showhide()#ADDADDADDADDADD

        def keyRight(self):
            ConfigListScreen.keyRight(self)
            print "current selection:", self["config"].l.getCurrentSelection()
            self.createSetup()
            self.showhide()#ADDADDADDADDADD

        def Ok_edit(self):    
            ConfigListScreen.keyRight(self)
            print "current selection:", self["config"].l.getCurrentSelection()
            self.createSetup()

        def plugupdt(self):
            global lstvrs
            if float(lstvrs) > float(currversion):
                self.session.openWithCallback(self.runupdate, MessageBox, (_('New update available!!\n\n Do you want update plugin ?')), MessageBox.TYPE_YESNO, timeout = 15, default = False)   
            elif float(lstvrs) == float(currversion):
                self['info2'].setText(_('\nXcPlugin is Last version!'))
            else:
                self['info2'].setText('\nXcPlugin Server Off!')


        def extrstrt1(self, result):
            if result:
                epgpath = '/media/hdd/epg.dat'
                epgbakpath = '/media/hdd/epg.dat.bak'
                if os.path.exists(epgbakpath):
                    os.remove(epgbakpath)
                if os.path.exists(epgpath):
                    copyfile(epgpath, epgbakpath)
                self.session.open(TryQuitMainloop, 3)
            else:
                self.close()
                
        def runupdate(self, result):
            if result:
                com = varlnkpth + 'enigma2-plugin-extensions-xcplugin-iptv-mod-lululla_' + lstvrs + '_all.ipk'
                self['info2'] = StaticText()
                self['info2'].text = (_('Updates available!'))
                dom = 'New Version'
                system('mkdir -p /tmp/xc')            
                self.dlfile = '/tmp/xc/tmp.ipk'
                self.updateurl = varlnkpth + 'enigma2-plugin-extensions-xcplugin-iptv-mod-lululla_' + lstvrs + '_all.ipk'
                self.download = downloadWithProgress(self.updateurl, self.dlfile)
                self.download.addProgress(self.downloadProgress)
                self.download.start().addCallback(self.downloadFinished).addErrback(self.downloadFailed)                 
            else:
                self['info2'].setText(_('Updates available!'))
            return                
                
        def downloadFinished(self, string=""):
            self["info2"].setText(_("Install update..."))
            from Screens.Ipkg import Ipkg
            from Components.Ipkg import IpkgComponent
            #system("opkg remove enigma2-plugin-extensions-xcplugin-iptv-mod-lululla")
            self.cmdList = [(IpkgComponent.CMD_INSTALL, {'package': self.dlfile})]
            self.session.openWithCallback(self.installFinished, Ipkg, cmdList=self.cmdList)

        def installFinished(self, string=""):
            self['info2'].setText(_('Restart Interface Please!'))         
            self['progresstext'].text = ''
            self.session.openWithCallback(self.extrstrt1, MessageBox, _('Execution finished.\n') + _('Do you want to restart GUI ?'))
        
        def downloadFailed(self, failure_instance = None, error_message = ''):
            text = _('Error while downloading files!')
            if error_message == '' and failure_instance is not None:
                error_message = failure_instance.getErrorMessage()
                text += ': ' + error_message
            self['info2'].setText(text)
            return

        def downloadProgress(self, recvbytes, totalbytes):
            self['progress'].value = int(100 * recvbytes / float(totalbytes))
            self['progresstext'].text = '%d of %d kBytes (%.2f%%)' % (recvbytes / 1024, totalbytes / 1024, 100 * recvbytes / float(totalbytes))   


        def cfgok(self):
            # self['ptchxzz'] = Label(_('Folder file xml %s' % config.plugins.XCplugin.pthxmlfile.value ))
            if config.plugins.XCplugin.pthxmlfile.value == '/media/hdd/xc' :
                if not os.path.exists('/media/hdd'):
                    self.mbox = self.session.open(MessageBox, _('/media/hdd NOT DETECTED!'), MessageBox.TYPE_INFO, timeout=4)
                    return
            if config.plugins.XCplugin.pthxmlfile.value == '/media/usb/xc' :
                if not os.path.exists('/media/usb'):
                    self.mbox = self.session.open(MessageBox, _('/media/usb NOT DETECTED!'), MessageBox.TYPE_INFO, timeout=4)
                    return

            # if not os.path.exists(config.plugins.XCplugin.pthxmlfile.value):
                # system('mkdir ' + config.plugins.XCplugin.pthxmlfile.value)
            # if not fileExists(config.plugins.XCplugin.pthxmlfile.value + '/' + 'xc_e2_plugin.xml'):
                # dest = config.plugins.XCplugin.pthxmlfile.value
                # shutil.copy2('/usr/lib/enigma2/python/Plugins/Extensions/XCplugin/cfg/xc_e2_plugin.xml', dest )
            # # if not fileExists(config.plugins.XCplugin.pthxmlfile.value + 'xc_e2_plugin.xml'):
                # # dest = config.plugins.XCplugin.pthxmlfile.value
                # # shutil.copy2('/usr/lib/enigma2/python/Plugins/Extensions/XCplugin/cfg/xc_e2_plugin.xml', dest )
            self.save()


        def save(self):
            if self['config'].isChanged():
                OnclearMem()
                config.plugins.XCplugin.hostaddress.save()
                config.plugins.XCplugin.user.save()
                config.plugins.XCplugin.passw.save()

                for x in self['config'].list:
                    x[1].save()
                # plugins.clearPluginList()
                # plugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
                configfile.save()
                self.mbox = self.session.open(MessageBox, _('Settings saved successfully !'), MessageBox.TYPE_INFO, timeout=5)

                self.close()
                # self.session.openWithCallback(self.close,xc_Main)  
            else:
                self.close()
                # self.session.openWithCallback(self.close,xc_Main)  


        def KeyText(self):
            sel = self['config'].getCurrent()
            if sel:
                self.session.openWithCallback(self.VirtualKeyBoardCallback, VirtualKeyBoard, title=self['config'].getCurrent()[0], text=self['config'].getCurrent()[1].value)

        def VirtualKeyBoardCallback(self, callback = None):
            if callback is not None and len(callback):
                self['config'].getCurrent()[1].value = callback
                self['config'].invalidate(self['config'].getCurrent())
            return                


        def cancelConfirm(self, result):
            if not result:
                return
            for x in self['config'].list:
                x[1].cancel()
            # self.close()
            self.session.openWithCallback(self.close,OpenServer)  
            



        def extnok(self):
            if self['config'].isChanged():
                self.session.openWithCallback(self.cancelConfirm, MessageBox, _('Really close without saving settings?'))
            else:
                # self.close()
                self.session.openWithCallback(self.close,OpenServer)  
                
        def ImportInfosServer(self):#ADDADDADDADDADD
            if config.plugins.XCplugin.configured.value:
                if fileExists('/tmp/xc.txt'):
                    f = file('/tmp/xc.txt',"r")
                    chaine = f.readlines()
                    f.close()
                    url = chaine[0].replace('\n','').replace('\t','').replace('\r','')
                    user = chaine[1].replace('\n','').replace('\t','').replace('\r','')
                    pswrd = chaine[2].replace('\n','').replace('\t','').replace('\r','')
                    filesave = 'xc_' + user + '.xml' 
                    # f5 = open(config.plugins.XCplugin.pthxmlfile.value + '/' + filesave, "w") 
                    pth= config.plugins.XCplugin.pthxmlfile.value + '/'
                    print 'pth:', pth                
                    f5 = open(pth + filesave, "w") 
                    f5.write(str('<?xml version="1.0" encoding="UTF-8" ?>\n' + '<items>\n' + '<plugin_version>' + currversion + '</plugin_version>\n' +'<xtream_e2portal_url><![CDATA[http://'+ url + '/enigma2.php]]></xtream_e2portal_url>\n' + '<username>' + user + '</username>\n' + '<password>' + pswrd + '</password>\n'+ '</items>'))
                    f5.close()
                    config.plugins.XCplugin.hostaddress.value = url
                    config.plugins.XCplugin.user.value = user
                    config.plugins.XCplugin.passw.value = pswrd  
                    self.mbox = self.session.open(MessageBox, _('File saved to %s !' % filesave ), MessageBox.TYPE_INFO, timeout=5)                    
                    self.cfgok()
            else:
                self.mbox = self.session.open(MessageBox, _('No Team Local Configured in config!'), MessageBox.TYPE_INFO, timeout=5)

        def ConfigText(self):#ADDADDADDADDADD
            self['srvcsval'].setText('Type Services %s' % config.plugins.XCplugin.services.value)
            self['VNetSpeedInfo'].setText('VNetSpeedInfo Active in Player %s\n' % config.plugins.XCplugin.VNetSpeedInfo.value)
            self['LivePlayer'].setText('LivePlayer Active %s\n' % config.plugins.XCplugin.LivePlayer.value)
            self['ptchxzz'].setText('Folder file xml %s' % config.plugins.XCplugin.pthxmlfile.value)
            self['ptchmovie'].setText('Movie Folder %s' % config.plugins.XCplugin.pthmovie.value+'movie/')    
            self['typem3utv'].setText('Conversion type List %s' % config.plugins.XCplugin.typem3utv.value)
            


# STREAM IPTV 
class iptv_streamse():

    def __init__(self):
        global MODUL
        self.iptv_list = []
        self.plugin_version = ''
        self.list_index = 0
        self.iptv_list_tmp = []
        self.list_index_tmp = 0
        self.playlistname_tmp = ''
        self.video_status = False
        self.server_oki = True
        self.playlistname = ''
        self.next_page_url = ''
        self.next_page_text = ''
        self.prev_page_url = ''
        self.prev_page_text = ''
        self.url = ''
        self.xtream_e2portal_url = ''
        self.username = ''
        self.password = '' 
        # self.timer = eTimer()
        # try:
            # self.timer.callback.append(self.ckint)
        # except:
            # self.timer_conn = self.timer.timeout.connect(self.ckint)
        # self.timer.start(50, 1)

        if config.plugins.XCplugin.configured.value:
            self.xtream_e2portal_url = 'http://' + config.plugins.XCplugin.hostaddress.value + '/enigma2.php'   #con config.value
            self.username = config.plugins.XCplugin.user.value  #con config.value
            self.password = config.plugins.XCplugin.passw.value  #con config.value
        # self.trial = ''
        # self.trial_time = 30

        self.use_rtmpw = False
        if config.plugins.XCplugin.services.value == 'Gstreamer':
            esr_id = '4097'
        else:
            esr_id = '5002'          
        self.esr_id = esr_id    
        self.play_vod = False
        self.play_iptv = False
        self.xml_error = ''
        self.ar_id_start = 3
        self.ar_id_player = 3
        self.ar_id_end = 3
        self.iptv_list_history = []
        self.ar_start = True
        self.clear_url = ''
        self.img_loader = False
        self.images_tmp_path = '/tmp'
        self.moviefolder = config.plugins.XCplugin.pthmovie.value + 'movie/'
        self.trial = ''
        self.banned_text = ''
        self.trial_time = 30
        self.timeout_time = 10
        self.cont_play = True
        self.systems = ''
        self.playhack = ''
        self.url_tmp = ''
        self.next_page_url_tmp = ''
        self.next_page_text_tmp = ''
        self.prev_page_url_tmp = ''
        self.prev_page_text_tmp = ''
        self.disable_audioselector = False
        MODUL = html_parser_moduls()


    def MoviesFolde(self):
        return self.moviefolder




    def getValue(self, definitions, default):
        ret = ''
        Len = len(definitions)
        return Len > 0 and definitions[Len - 1].text or default


#
    def read_config(self):
        try:
            # fileinhost = config.plugins.XCplugin.hostaddress.value

            xtream_e2portal_url = config.plugins.XCplugin.hostaddress.value
            tree = ElementTree()
            if config.plugins.XCplugin.configured.value:
                # if xtream_e2portal_url and xtream_e2portal_url == 'exampleserver.com:8888' or xtream_e2portal_url == '':
                    # message = (_('Please enter correct parameters in Config\nHOST-USER-PASSWORD')) # %s % fileinhost))
                    # web_info(message)  
                # else:
                xtream_e2portal_url = 'http://' + config.plugins.XCplugin.hostaddress.value + '/enigma2.php'            
                self.xtream_e2portal_url = xtream_e2portal_url
                self.url = self.xtream_e2portal_url

                username = config.plugins.XCplugin.user.value
                if username and username != '':
                    self.username = username
                password = config.plugins.XCplugin.passw.value
                if password and password != '':
                    self.password = password
                xmlname = config.plugins.XCplugin.hostaddress.value
                self['Text'].setText(xmlname)
                SetValue['MyServer'] = STREAMS.playlistname
                self['playlist'].setText(STREAMS.playlistname)    

            else:

                tree = ElementTree()
                server = open(PLUGIN_PATH + '/cfg/server.txt', 'r').readline().rstrip()
                xml = tree.parse(server)
                xtream_e2portal_url = xml.findtext('xtream_e2portal_url')
                # if xtream_e2portal_url and xtream_e2portal_url == 'http://mypanel.dyndns.tv:8000/enigma2.php' or xtream_e2portal_url == '':
                    # message = (_('Please enter correct parameters in\n%s !' % server))
                    # web_info(message)
                # else:
                    # if xtream_e2portal_url and xtream_e2portal_url != '' or xtream_e2portal_url != 'http://mypanel.dyndns.tv:8000/enigma2.php' :
                self.xtream_e2portal_url = xtream_e2portal_url
                self.url = self.xtream_e2portal_url
                username = xml.findtext('username')
                if username and username != '':
                    self.username = username
                    password = xml.findtext('password')
                if password and password != '':
                    self.password = password
                self['Text'].setText(server)
                SetValue['MyServer'] = STREAMS.playlistname
                self['playlist'].setText(STREAMS.playlistname) 
            plugin_version = xml.findtext('plugin_version')
            if plugin_version and plugin_version != '':
                self.plugin_version = plugin_version
            self.img_loader = self.getValue(xml.findall('images_tmp'), False)
            self.images_tmp_path = self.getValue(xml.findall('images_tmp_path'), self.images_tmp_path)
            # self.disable_audioselector = self.getValue(xml.findall('disable_audioselector'), self.disable_audioselector)
            print '-----------CONFIG NEW START--------'

            print 'XCplugin E2 Plugin V. %s' % version
            print 'XCplugin Version config .xml V. %s' % STREAMS.plugin_version

            print 'xtream_e2portal_url     %s' % self.xtream_e2portal_url
            print '-----------CONFIG NEW END----------'

        except Exception as ex:
            print '++++++++++ERROR READ CONFIG+++++++++++++'
            print ex

    def reset_buttons(self):
        self.next_page_url = None
        self.next_page_text = ''
        self.prev_page_url = None
        self.prev_page_text = ''
        return


    # def ckint(self):
        # url3 = 'http://www.google.com'
        # getPage(url3).addCallback(self.ConnOK).addErrback(self.ConnNOK)
        
    # def ConnOK(self, data):
        # pass

    # def ConnNOK(self, error):
        # message = 'No Connection!'
        # web_info(message)
        # self.close()



    def get_list(self, url = None):
        self.xml_error = ''
        self.url = url
        self.clear_url = url
        self.list_index = 0
        iptv_list_temp = []
        xml = None
        self.next_request = 0
        try:
            print '!!!!!!!!-------------------- URL %s' % url
            if url.find('username') > -1:
                self.next_request = 1
            if any([url.find('.ts') > -1, url.find('.mp4') > -1]):
                self.next_request = 2
            xml = self._request(url)
            ## STREAMS.url ==  xtream_e2portal_url == http://host:porta/enigma2.php
            #ex saveinfo e userinfo 
            if xml:
                self.next_page_url = ''
                self.next_page_text = ''
                self.prev_page_url = ''
                self.prev_page_text = ''
                self.playlistname = xml.findtext('playlist_name').encode('utf-8')
                self.next_page_url = xml.findtext('next_page_url')
                next_page_text_element = xml.findall('next_page_url')
                if next_page_text_element:
                    self.next_page_text = next_page_text_element[0].attrib.get('text').encode('utf-8')
                self.prev_page_url = xml.findtext('prev_page_url')
                prev_page_text_element = xml.findall('prev_page_url')
                if prev_page_text_element:
                    self.prev_page_text = prev_page_text_element[0].attrib.get('text').encode('utf-8')
                chan_counter = 0
                for channel in xml.findall('channel'):
                    chan_counter = chan_counter + 1
                    name = channel.findtext('title').encode('utf-8')
                    name = base64.b64decode(name)
                    piconname = channel.findtext('logo')
                    description = channel.findtext('description')
                    desc_image = channel.findtext('desc_image')
                    img_src = ''
                    if description != None:
                        description = description.encode('utf-8')
                        if desc_image:
                            img_src = desc_image
                        description = base64.b64decode(description)
                        description = description.replace('<br>', '\n')
                        description = description.replace('<br/>', '\n')
                        description = description.replace('</h1>', '</h1>\n')
                        description = description.replace('</h2>', '</h2>\n')
                        description = description.replace('&nbsp;', ' ')
                        description4playlist_html = description
                        text = re.compile('<[\\/\\!]*?[^<>]*?>')
                        description = text.sub('', description)
                    stream_url = channel.findtext('stream_url')
                    playlist_url = channel.findtext('playlist_url')
                    category_id = channel.findtext('category_id')
                    ts_stream = channel.findtext('ts_stream')
                    chan_tulpe = (chan_counter,
                     name,
                     description,
                     piconname,
                     stream_url,
                     playlist_url,
                     category_id,
                     img_src,
                     description4playlist_html,
                     ts_stream,)

                    iptv_list_temp.append(chan_tulpe)


        except Exception as ex:
            print ex
            self.xml_error = ex
            print '!!!!!!!!!!!!!!!!!! ERROR: XML to LISTE'

        if len(iptv_list_temp):
            self.iptv_list = iptv_list_temp
        else:
            print 'ERROR IPTV_LIST_LEN = %s' % len(iptv_list_temp)
        return





    def _request(self, url):
        url = url.strip(' \t\n\r')
        if self.next_request == 1:
            url = url


        elif self.next_request == 0:
            url = url + '?' + 'username=' + self.username + '&password=' + self.password


            saveurl = self.url 
            saveurl = saveurl.replace('enigma2.php', 'get.php')                 
            if fileExists('/tmp/saveurl.txt'):
                os.remove('/tmp/saveurl.txt')

            a = open("/tmp/saveurl.txt", "w")
            a.write(str(saveurl + '?' + 'username=' + self.username + '&password=' + self.password))
            a.close()

            if fileExists('/tmp/userinfo.txt'):
                os.remove('/tmp/userinfo.txt')
            infourl = self.url
            infourl = infourl.replace('http://', '').replace(':', '###').replace('/enigma2.php', '')
            b = open("/tmp/userinfo.txt", "w")
            b.write(str(infourl + '###' + self.username + '###' + self.password + '###'))
            b.close()
            c = open(PLUGIN_PATH + "/cfg/userinfo.txt", "w")
            c.write(str(infourl + '###' + self.username + '###' + self.password + '###'))
            c.close()

        else:
            url = url


        print url

        try:
            req = urllib2.Request(url, None, {'User-agent': 'Xtream-Codes Enigma2 Plugin',
             'Connection': 'Close'})
            if self.server_oki == True:
                xmlstream = urllib2.urlopen(req, timeout=NTIMEOUT).read()
            res = fromstring(xmlstream)
        except Exception as ex:
            print ex
            print 'REQUEST Exception'
            res = None
            self.xml_error = ex

        return res
        
try:
    from Tools.Directories import fileExists, pathExists
    from Components.Network import iNetwork
except Exception as ex:
    print ex
    print 'IMPORT ERROR'

try:
    import commands
except Exception as ex:
    print ex


    




class IPTVInfoBarShowHide():
    """ InfoBar show/hide control, accepts toggleShow and hide actions, might start
    fancy animations. """
    STATE_HIDDEN = 0
    STATE_HIDING = 1
    STATE_SHOWING = 2
    STATE_SHOWN = 3

    def __init__(self):
        self['ShowHideActions'] = ActionMap(['InfobarShowHideActions'], {'toggleShow': self.toggleShow,
         'hide': self.hide}, 0)
        self.__event_tracker = ServiceEventTracker(screen=self, eventmap={iPlayableService.evStart: self.serviceStarted})
        self.__state = self.STATE_SHOWN
        self.__locked = 0
        self.hideTimer = eTimer()
        try:
            self.hideTimer_conn = self.hideTimer.timeout.connect(self.doTimerHide)
        except:
            self.hideTimer.callback.append(self.doTimerHide)

        self.hideTimer.start(5000, True)
        self.onShow.append(self.__onShow)
        self.onHide.append(self.__onHide)




    def serviceStarted(self):
        if self.execing:
            if config.usage.show_infobar_on_zap.value:
                self.doShow()



    def __onShow(self):
        self.__state = self.STATE_SHOWN
        self.startHideTimer()



    def startHideTimer(self):
        if self.__state == self.STATE_SHOWN and not self.__locked:
            idx = config.usage.infobar_timeout.index
            if idx:
                self.hideTimer.start(idx * 1500, True)



    def __onHide(self):
        self.__state = self.STATE_HIDDEN




    def doShow(self):
        self.show()
        self.startHideTimer()



    def doTimerHide(self):
        self.hideTimer.stop()
        if self.__state == self.STATE_SHOWN:
            self.hide()




    def toggleShow(self):
        if self.__state == self.STATE_SHOWN:
            self.hide()
            self.hideTimer.stop()
        elif self.__state == self.STATE_HIDDEN:
            self.show()




    def lockShow(self):
        self.__locked = self.__locked + 1
        if self.execing:
            self.show()
            self.hideTimer.stop()




    def unlockShow(self):
        self.__locked = self.__locked - 1
        if self.execing:
            self.startHideTimer()






    def debug(obj, text = ''):
        # print datetime.fromtimestamp(time()).strftime('[%H:%M:%S]')
        print text + ' %s\n' % obj






class downloadJob(Job):

    def __init__(self, toolbox, cmdline, filename, filetitle):
        Job.__init__(self, 'Download: %s' % filetitle)
        self.filename = filename
        self.toolbox = toolbox
        self.retrycount = 0
        downloadTask(self, cmdline, filename)

    def retry(self):
        self.retrycount += 1
        self.restart()

    def cancel(self):
        self.abort()






class downloadTask(Task):
    ERROR_CORRUPT_FILE, ERROR_RTMP_ReadPacket, ERROR_SEGFAULT, ERROR_SERVER, ERROR_UNKNOWN = range(5)



    def __init__(self, job, cmdline, filename):
        Task.__init__(self, job, _('Downloading ...'))
        self.postconditions.append(downloadTaskPostcondition())
        self.setCmdline(cmdline)
        self.filename = filename
        self.toolbox = job.toolbox
        self.error = None
        self.lasterrormsg = None
        return



    def processOutput(self, data):
        try:
            if data.endswith('%)'):
                startpos = data.rfind('sec (') + 5
                if startpos and startpos != -1:
                    self.progress = int(float(data[startpos:-4]))
            elif data.find('%') != -1:
                tmpvalue = data[:data.find('%')]
                tmpvalue = tmpvalue[tmpvalue.rfind(' '):].strip()
                tmpvalue = tmpvalue[tmpvalue.rfind('(') + 1:].strip()
                self.progress = int(float(tmpvalue))
            else:
                Task.processOutput(self, data)
        except Exception as errormsg:
            print 'Error processOutput: ' + str(errormsg)
            Task.processOutput(self, data)



    def processOutputLine(self, line):
        line = line[:-1]
        self.lasterrormsg = line
        if line.startswith('ERROR:'):
            if line.find('RTMP_ReadPacket') != -1:
                self.error = self.ERROR_RTMP_ReadPacket
            elif line.find('corrupt file!') != -1:
                self.error = self.ERROR_CORRUPT_FILE
                system('rm -f %s' % self.filename)
            else:
                self.error = self.ERROR_UNKNOWN
        elif line.startswith('wget:'):
            if line.find('server returned error') != -1:
                self.error = self.ERROR_SERVER
        elif line.find('Segmentation fault') != -1:
            self.error = self.ERROR_SEGFAULT



    def afterRun(self):
        if self.getProgress() == 0 or self.getProgress() == 100:
            message = 'Movie successfully transfered to your HDD!' + '\n' + self.filename
            web_info(message)




class downloadTaskPostcondition(Condition):
    RECOVERABLE = True




    def check(self, task):
        if task.returncode == 0 or task.error is None:
            return True
        else:
            return False
            return



    def getErrorMessage(self, task):
        return {task.ERROR_CORRUPT_FILE: _('Video Download Failed!\n\nCorrupted Download File:\n%s' % task.lasterrormsg),
         task.ERROR_RTMP_ReadPacket: _('Video Download Failed!\n\nCould not read RTMP-Packet:\n%s' % task.lasterrormsg),
         task.ERROR_SEGFAULT: _('Video Download Failed!\n\nSegmentation fault:\n%s' % task.lasterrormsg),
         task.ERROR_SERVER: _('Video Download Failed!\n\nServer returned error:\n%s' % task.lasterrormsg),
         task.ERROR_UNKNOWN: _('Video Download Failed!\n\nUnknown Error:\n%s' % task.lasterrormsg)}[task.error]


         
VIDEO_ASPECT_RATIO_MAP = {0: '4:3 Letterbox',
 1: '4:3 PanScan',
 2: '16:9',
 3: '16:9 Always',
 4: '16:10 Letterbox',
 5: '16:10 PanScan',
 6: '16:9 Letterbox'}
 


def nextAR():
    try:

        STREAMS.ar_id_player += 3
        if STREAMS.ar_id_player > 6:
            STREAMS.ar_id_player = 3          

        eAVSwitch.getInstance().setAspectRatio(STREAMS.ar_id_player)
        print 'STREAMS.ar_id_player NEXT %s' % VIDEO_ASPECT_RATIO_MAP[STREAMS.ar_id_player]
        return VIDEO_ASPECT_RATIO_MAP[STREAMS.ar_id_player]
    except Exception as ex:
        print ex
        return 'nextAR ERROR %s' % ex



def prevAR():
    try:
        STREAMS.ar_id_player -= 3
        if STREAMS.ar_id_player == -1:
            STREAMS.ar_id_player = 3

        eAVSwitch.getInstance().setAspectRatio(STREAMS.ar_id_player)
        print 'STREAMS.ar_id_player PREV %s' % VIDEO_ASPECT_RATIO_MAP[STREAMS.ar_id_player]
        return VIDEO_ASPECT_RATIO_MAP[STREAMS.ar_id_player]
    except Exception as ex:
        print ex
        return 'prevAR ERROR %s' % ex



def web_info(message):
    try:
        message = quote_plus(str(message))
        cmd = "wget -qO - 'http://127.0.0.1/web/message?type=2&timeout=10&text=%s' 2>/dev/null &" % message
        debug(cmd, 'CMD -> Console -> WEBIF')
        os.popen(cmd)
    except:
        print 'web_info ERROR'



def channelEntryIPTVplaylist(entry):
    menu_entry = [entry, (eListboxPythonMultiContent.TYPE_TEXT,
      CHANNEL_NUMBER[0],
      CHANNEL_NUMBER[1],
      CHANNEL_NUMBER[2],
      CHANNEL_NUMBER[3],
      CHANNEL_NUMBER[4],
      RT_HALIGN_CENTER,
      '%s' % entry[0]), (eListboxPythonMultiContent.TYPE_TEXT,
      CHANNEL_NAME[0],
      CHANNEL_NAME[1],
      CHANNEL_NAME[2],
      CHANNEL_NAME[3],
      CHANNEL_NAME[4],
      RT_HALIGN_LEFT,
      entry[1])]
    return menu_entry







class xc_Main(Screen):

    def __init__(self, session):
        global STREAMS
        # STREAMS = iptv_streamse()
        self.session = session
        skin = SKIN_PATH + '/xc_Main.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()        
        Screen.__init__(self, session)    
        self.channel_list = STREAMS.iptv_list
        self.index = STREAMS.list_index
        # OnclearMem()
        self.banned = False
        self.banned_text = ''
        self.mlist = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self.mlist.l.setFont(0, gFont(FONT_0[0], FONT_0[1]))
        self.mlist.l.setFont(1, gFont(FONT_1[0], FONT_1[1]))
        self.mlist.l.setItemHeight(BLOCK_H)
        self.go()        
        self['InfoEx'] = Label(_("Info"))
        self['Extra'] = Label(_("Info"))
        self['InfoEpg'] = Label(_("Epg"))
        self['Epg'] = Label(_("Info Epg")) 
        self['Helplab'] = Label(_("Help"))        
        self['info'] = Label()   
        self['playlist'] = Label()
        self['description'] = Label()        
        self['RecDows'] = Label(_("Rec"))
        self['DownVOD'] = Label(_("Download VOD"))
        self['state'] = Label('') 
        self['Pvr'] = Label(_("Pvr/9"))
        self['RecordF'] = Label(_("Records Folder "))
        self['zero'] = Label(_("0"))        
        self['SaveXml'] = Label(_("Save Team "))
        self['Tv'] = Label(_("Tv"))
        self['Refresh'] = Label(_("Reload List "))          
        self['version'] = Label(_(' V. %s' % version)) 
        self['srvcsval'] = Label(_('Type Services %s' % config.plugins.XCplugin.services.value))
        self['VNetSpeedInfo'] = Label(_('VNetSpeedInfo Active in Player %s' % config.plugins.XCplugin.VNetSpeedInfo.value))
        self['LivePlayer'] = Label(_('LivePlayer Active %s' % config.plugins.XCplugin.LivePlayer.value))        
        self['ptchxzz'] = Label(_('Folder file xml %s' % config.plugins.XCplugin.pthxmlfile.value))
        self['ptchmovie'] = Label(_('Movie Folder %s' % config.plugins.XCplugin.pthmovie.value + 'movie/'))  
        self['typem3utv'] = Label(_('Conversion type List %s' % config.plugins.XCplugin.typem3utv.value))
        self['key_red'] = Label(_("Close"))
        self["key_green"] = Label(_("Team/Config"))        
        self["key_yellow"] = Label(_("Add Iptv Bouquets"))
        self["key_blu"] = Label(_("M3u Loader"))
        self.onShown.append(self.show_all)
        self['poster'] = Pixmap()
        self.picload = ePicLoad()
        self.picfile = ''
        self['Text'] = Label('')
        self.update_desc = True
        self.pass_ok = False
        self.oldService = self.session.nav.getCurrentlyPlayingServiceReference()
        self['actions'] = HelpableActionMap(self, 'nStreamPlayerPlaylist', {'homePlaylist': self.start_portal,
         'ok': self.ok,
         'check_download_vod' : self.check_download_vod,
         # 'startIPTV': self.play_iptv,
         'taskManager': self.taskManager,
         'xcPlay': self.xcPlay,
         'showMediaPlayer' : self.showMediaPlayer,
         'showMovies' : self.showMovies,
         'help': self.help,
         'listUpdate' : self.update_list,#tv
         'save_list': self.msg_save_tv_old, #yellow         
         'savexml': self.savexml,
         'exitPlugin': self.exitY,
         'exit_box': self.exitY,
         # 'exitPlugin': self.exit_box,
         # 'exit_box': self.exit_box,         
         'moreInfo': self.show_more_info,
         'infoInfo': self.show_about,
         'Team': self.Team,
         'menu': self.config,
         'power': self.power}, -1)
        self.temp_index = 0
        self.temp_channel_list = None
        self.temp_playlistname = None
        self.url_tmp = None
        self.video_back = False
        self.passwd_ok = False
        if config.plugins.XCplugin.configured.value:
            #xmlname = 'Local'
            xmlname = config.plugins.XCplugin.hostaddress.value
            self['Text'].setText(xmlname)
            SetValue['MyServer'] = STREAMS.playlistname
            self['playlist'].setText(STREAMS.playlistname)

        else:
            server = open(PLUGIN_PATH + '/cfg/server.txt', 'r').readline().rstrip()
            pth = config.plugins.XCplugin.pthxmlfile.value + '/'
            print 'pth', pth
            ren = pth #+ '/'
            self['Text'].setText(server.replace('xc_', '').replace('.xml', '').replace(ren, ''))
            SetValue['MyServer'] = server
            self['playlist'].setText(STREAMS.playlistname)

        # self.onShown.append(self.update_list)
        # return 

    def config(self):
        self.session.open(xc_config)
        self.onShown.append(self.update_list)    


    def Team(self):
        clear_img()

        # OnclearMem()
        system("cd / && cp -f " + piclogo + ' /tmp/poster.jpg')
        self['poster'].hide()
        self.picload = ePicLoad()
        self.picfile = piclogo #SKIN_PATH + '/iptvlogo.jpg'           
        self['poster'].instance.setPixmapFromFile(piclogo) #(SKIN_PATH + '/iptvlogo.jpg')
        self.decodeImage()
        self.session.open(OpenServer)        
        self['poster'].show()
        self.onShown.append(self.update_list) 


    #
    def savexml(self):
        if config.plugins.XCplugin.configured.value:
            savefile = 'xc_' + config.plugins.XCplugin.user.value + '.xml'
            # f5 = open(config.plugins.XCplugin.pthxmlfile.value + '/' + savefile, "w")
            pth= config.plugins.XCplugin.pthxmlfile.value + '/'
            print 'pth:', pth                
            f5 = open(pth + filesave, "w")            
            f5.write(str('<?xml version="1.0" encoding="UTF-8" ?>\n' + '<items>\n' + '<plugin_version>' + currversion + '</plugin_version>\n' +'<xtream_e2portal_url><![CDATA[http://'+ config.plugins.XCplugin.hostaddress.value + '/enigma2.php]]></xtream_e2portal_url>\n' + '<username>' + config.plugins.XCplugin.user.value + '</username>\n' + '<password>' + config.plugins.XCplugin.passw.value + '</password>\n'+ '</items>'))

            f5.close            
            self.mbox = self.session.open(MessageBox, _('File saved to xc_save.xml!'), MessageBox.TYPE_INFO, timeout=5)
        else:
            self.mbox = self.session.open(MessageBox, _('No Team Local Configured in config!'), MessageBox.TYPE_INFO, timeout=5)

    #
    def exit_box(self):
        self.session.openWithCallback(self.exit, MessageBox, _('Exit Plugin?'), type=MessageBox.TYPE_YESNO)
        
    #
    def exit(self, message = None):
        if message:
            if fileExists('/tmp/poster.jpg'):
                os.remove('/tmp/poster.jpg')        
            if fileExists('/tmp/saveurl.txt'):
                os.remove('/tmp/saveurl.txt')
            # if fileExists('/tmp/userinfo.txt'):
                # os.remove('/tmp/userinfo.txt')   
            if os.path.exists('/tmp/e2m3u2bouquet.py'):
                os.remove('/tmp/e2m3u2bouquet.py')
            if STREAMS.playhack == '':
                self.session.nav.stopService()
                STREAMS.play_vod = False
                self.session.nav.playService(self.oldService)                

            print 'STREAMS.ar_id_end %i' % STREAMS.ar_id_end
            # if STREAMS.ar_start:
                # test = eAVSwitch.getInstance().setAspectRatio(STREAMS.ar_id_end)
                # print 'eAVSwitch.getInstance().setAspectRatio %s' % test
            # else:
                # print 'SET A-RATIO OFF'
            OnclearMem()
            self.close()   
        
    #
    def exitY(self):
            clear_img()
            OnclearMem()      
            if fileExists('/tmp/saveurl.txt'):
                os.remove('/tmp/saveurl.txt')
            if os.path.exists('/tmp/e2m3u2bouquet.py'):
                os.remove('/tmp/e2m3u2bouquet.py')
            if os.path.exists('/tmp/e2m3u2bouquet.pyo'):
                os.remove('/tmp/e2m3u2bouquet.pyo')                
            if STREAMS.playhack == '':
                self.session.nav.stopService()
                STREAMS.play_vod = False
                self.session.nav.playService(self.oldService)                
            print 'STREAMS.ar_id_end %i' % STREAMS.ar_id_end

            self.close()   
            
    #

    def go(self):
        self.mlist.setList(map(channelEntryIPTVplaylist, self.channel_list))
        self.mlist.onSelectionChanged.append(self.update_description)
        self['feedlist'] = self.mlist



    def showMediaPlayer(self):
            try:
                from Plugins.Extensions.MediaPlayer.plugin import MediaPlayer
                self.session.open(MediaPlayer)
                no_plugin = False
            except Exception, e:
                self.session.open(MessageBox, _("The MediaPlayer plugin is not installed!\nPlease install it."), type = MessageBox.TYPE_INFO,timeout = 10 )

    # Show Lists Download
    def showMovies(self):  #shows list downloaded
            try:
                self.session.open(MovieSelection)
            except:
                pass


    def show_about(self):
        about = ('\nXCplugin E2 Plugin - v. %s\n\nby Lululla Info: lululla.altervista.org \n\nSkin By: MMARK Info e2skin.blogspot.it \n\n*** Please report any bugs you find ***\n\nThanks to Corvone.com - linuxsat-support.com \nTo:  MMark, Pcd, aime_jeux, Bliner_Key\nTo: M2boom, Pauldb\nand all those i forgot to mention.') % version
        self.session.open(MessageBox, about, type=MessageBox.TYPE_INFO)
        
    def help(self):
        self.session.open(xc_help)

    #
    def update_list(self):
            global STREAMS
            STREAMS = iptv_streamse()
            STREAMS.read_config()
            print '\n\n\n\n'
            print '######################################################################'
            print '#######--------- XCplugin E2 Plugin v. %s -------#######' % version
            print '######################################################################'
            # if STREAMS.ar_start:
                # testme = eAVSwitch.getInstance().setAspectRatio(STREAMS.ar_id_start)
                # print '!!!!!!!!!!!!!!!!!eAVSwitch.getInstance().setAspectRatio %s' % testme
            STREAMS.get_list(STREAMS.xtream_e2portal_url)
            self.update_channellist()



    #
    def taskManager(self): #shows list list downloaded
        self.session.open(xc_StreamTasks)

    #
    def xcPlay(self):
        self.session.open(xc_Play) 
        


    #
    def show_more_info(self):
        try:
            if config.plugins.XCplugin.configured.value or STREAMS.xtream_e2portal_url and STREAMS.xtream_e2portal_url != '' or 'exampleserver.com:8888' :
                selected_channel = self.channel_list[self.mlist.getSelectionIndex()]
                if selected_channel[2] != None:
                    text = re.compile('<[\\/\\!]*?[^<>]*?>')
                    text_clear = ''
                    text_clear = text.sub('', selected_channel[2])
                    self.session.open(xc_Epg, text_clear)
                else:
                    message = (_('No valid list '))
                    web_info(message) 
            else:
                message = (_('Please enter correct parameters in Config\n no valid list '))
                web_info(message) 

                
        except Exception as ex:
            print ex
            print 'ERROR show_more_info'
            
 

  
#key REC in test 

    def check_download_vod(self):
    

        self.vod_entry = STREAMS.iptv_list[self.index]
        if self.temp_index > -1:
            self.index = self.temp_index
        self.vod_entry = STREAMS.iptv_list[self.index]    
        selected_channel = STREAMS.iptv_list[self.index]
        stream_url = selected_channel[4]
        playlist_url = selected_channel[5]    
        self.title = selected_channel[1]
        if playlist_url != None:
            message = (_('No Video to Download!!\nplaylist_url != None'))
            web_info(message) 





            #pass
        elif stream_url != None:
            self.vod_url = stream_url
            if self.vod_url.split('.')[-1].lower() != 'ts': 
                self.session.openWithCallback(self.download_vod, MessageBox, _('DOWNLOAD VIDEO?\n%s' % self.title) , type=MessageBox.TYPE_YESNO, timeout = 15, default = False)
            else:
                message = (_('Only Play'))
                web_info(message)    

        else:
            message = (_('No Video to Download\Record!!'))
            web_info(message)     

    #
    def download_vod(self, result):
        if result:

            try:

                movie = config.plugins.XCplugin.pthmovie.value + 'movie/'            
                self['state'].setText('Download VOD')
                useragent = "--header='User-Agent: QuickTime/7.6.2 (qtver=7.6.2;os=Windows NT 5.1Service Pack 3)'"
                ende = 'mp4'
                if self.vod_url.split('.')[-1].lower() == 'flv':
                    ende = 'flv'                
                title_translit = cyr2lat(self.title)
                filename = ASCIItranslit.legacyEncode(title_translit + '.') + ende
                filename = filename.replace('(', '_')
                filename = filename.replace(')', '_')
                filename = filename.replace('#', '')
                filename = filename.replace('+', '_')
                filename = filename.encode('utf-8')
                cmd = "wget %s -c '%s' -O '%s%s'" % (useragent, self.vod_url, movie, filename)
                JobManager.AddJob(downloadJob(self, cmd, movie + filename, self.title))
                self.createMetaFile(filename)
                self.LastJobView()
                self.mbox = self.session.open(MessageBox, _('[DOWNLOAD] ' + self.title), MessageBox.TYPE_INFO, timeout=10)

            except Exception as ex:
                print ex
                print 'ERROR download_vod'
        return 






    def LastJobView(self):
        currentjob = None
        for job in JobManager.getPendingJobs():
            currentjob = job

        if currentjob is not None:
            self.session.open(JobView, currentjob)
        return





    def createMetaFile(self, filename):
        try:
            movie = config.plugins.XCplugin.pthmovie.value + 'movie/'
            text = re.compile('<[\\/\\!]*?[^<>]*?>')
            text_clear = ''
            if self.vod_entry[2] != None:
                text_clear = text.sub('', self.vod_entry[2])
            serviceref = eServiceReference(4097, 0, movie + filename)
            metafile = open('%s%s.meta' % (movie, filename), 'w') 
            metafile.write('%s\n%s\n%s\n%i\n' % (serviceref.toString(),
             self.title.replace('\n', ''),
             text_clear.replace('\n', ''),
             time()))
            metafile.close()
        except Exception as ex:
            print ex
            print 'ERROR metaFile'

        return        





    def button_updater(self):
        self['srvcsval'].setText(_('Type Services %s' % config.plugins.XCplugin.services.value))
        self['VNetSpeedInfo'].setText(_('VNetSpeedInfo Active in Player %s' % config.plugins.XCplugin.VNetSpeedInfo.value))
        self['LivePlayer'].setText(_('LivePlayer Active %s' % config.plugins.XCplugin.LivePlayer.value))        
        self['ptchxzz'].setText(_('Folder file xml %s' % config.plugins.XCplugin.pthxmlfile.value))
        self['ptchmovie'].setText(_('Movie Folder %s' % config.plugins.XCplugin.pthmovie.value+'movie/'))#ADDDDDDDD    
        self['typem3utv'].setText(_('Conversion type List %s' % config.plugins.XCplugin.typem3utv.value))

        if config.plugins.XCplugin.configured.value:
            #xmlname = 'Local'
            xmlname = config.plugins.XCplugin.hostaddress.value
            self['Text'].setText(xmlname)
            SetValue['MyServer'] = STREAMS.playlistname
            self['playlist'].setText(STREAMS.playlistname)



        else:
            server = open(PLUGIN_PATH + '/cfg/server.txt', 'r').readline().rstrip()
            pth = config.plugins.XCplugin.pthxmlfile.value + '/'
            print 'pth', pth
            ren = pth #+ '/'
            self['Text'].setText(server.replace('xc_', '').replace('.xml', '').replace(ren, ''))
            SetValue['MyServer'] = server
            self['playlist'].setText(STREAMS.playlistname)


        return 


        
    # Switch PicView PLI/CVS         
    def decodeImage(self):
        try:
            x = self['poster'].instance.size().width()
            y = self['poster'].instance.size().height()
            picture = self.picfile
            picload = self.picload
            sc = AVSwitch().getFramebufferScale()
            self.picload.setPara((x, y, sc[0], sc[1], 0, 0, '#00000000'))
            if fileExists(BRAND)or fileExists(BRANDP):
                self.picload.PictureData.get().append(boundFunction(self.showImage)) ## OPEN
            else:
                self.picload_conn = self.picload.PictureData.connect(self.showImage) ## CVS
            self.picload.startDecode(self.picfile)
        except Exception as ex:
            print ex
            print 'ERROR decodeImage'
              
    # Switch PicView PLI/CVS
    def showImage(self, picInfo = None):
        self['poster'].show()
        try:
            ptr = self.picload.getData()
            if ptr:
                if fileExists(BRAND) or fileExists(BRANDP):
                    self['poster'].instance.setPixmap(ptr.__deref__())  ### OPEN
                else:
                    self['poster'].instance.setPixmap(ptr)                ### CVS
        except Exception as ex:
            print ex
            print 'ERROR showImage'
    #        
    def image_downloaded(self, id):
        self.decodeImage()


    def downloadError(self, raw):
        try:

            system("cd / && cp -f " + piclogo + ' %s/poster.jpg' % STREAMS.images_tmp_path)
            self.decodeImage()
        except Exception as ex:
            print ex
            print 'exe downloadError'

    #
    def update_description(self):
        self.index = self.mlist.getSelectionIndex()
        if self.update_desc:
            try:
                self['info'].setText('')
                self['description'].setText('')
                system("cd / && cp -f " + piclogo + ' %s/poster.jpg' % STREAMS.images_tmp_path)
                selected_channel = self.channel_list[self.index]
                if selected_channel[7] != '':
                    if selected_channel[7].find('http') == -1:
                        self.picfile = selected_channel[7]

                        self.decodeImage()
                        print 'LOCAL DESCR IMG'
                    else:
                        if STREAMS.img_loader == False:
                            self.picfile = '%s/poster.jpg' % STREAMS.images_tmp_path
                        else:
                            m = hashlib.md5()
                            m.update(selected_channel[7])
                            cover_md5 = m.hexdigest()
                            self.picfile = '%s/%s.jpg' % (STREAMS.images_tmp_path, cover_md5)

                        if os.path.exists(self.picfile) == False or STREAMS.img_loader == False:
                            downloadPage(selected_channel[7], self.picfile).addCallback(self.image_downloaded).addErrback(self.downloadError)

                        else:
                            self.decodeImage()

                if selected_channel[2] != None:
                    description = selected_channel[2]
                    description_2 = description.split(' #-# ')
                    if description_2:
                        self['description'].setText(description_2[0])
                        if len(description_2) > 1:
                            self['info'].setText(description_2[1])
                    else:
                        self['description'].setText(description)


            except Exception as ex:
                print ex
                print 'exe update_description'

        return

       

    #        
    def start_portal(self):
        if STREAMS.playhack == '':
            self.session.nav.stopService()
            self.session.nav.playService(self.oldService)
        self.index = 0
        # OnclearMem()
        # clear_img()
        system("cd / && cp -f " + piclogo + ' %s/poster.jpg' % STREAMS.images_tmp_path)        
        self['poster'].hide()
        self.picload = ePicLoad()
        self.picfile = piclogo #SKIN_PATH + '/iptvlogo.jpg'           
        self['poster'].instance.setPixmapFromFile(piclogo) #(SKIN_PATH + '/iptvlogo.jpg')
        self.decodeImage()
        self['poster'].show()
        self['state'].setText('')
        self.update_list()



    #
    def update_channellist(self):
        print '--------------------- UPDATE CHANNEL LIST ----------------------------------------'
        if STREAMS.xml_error != '':
            print '### update_channellist ######URL#############'
            print STREAMS.clear_url
            # error_text = 'PLAYLIST ERROR:\n%s\n\nURL:\n%s' % (STREAMS.xml_error, STREAMS.clear_url.encode('utf-8'))
            # self.session.open(MessageBox, error_text, type=MessageBox.TYPE_ERROR, timeout=20)
        self.channel_list = STREAMS.iptv_list
        self.update_desc = False
        self.mlist.setList(map(channelEntryIPTVplaylist, self.channel_list))
        self.mlist.moveToIndex(0)
        self.update_desc = True
        self.update_description() 
        self.button_updater()


    def show_all(self):
        try:
            if self.passwd_ok == False:
                self.channel_list = STREAMS.iptv_list
                self.mlist.moveToIndex(self.index)
                self.mlist.setList(map(channelEntryIPTVplaylist, self.channel_list))
                self.mlist.selectionEnabled(1)
                self.button_updater()
            self.passwd_ok = False
        except Exception as ex:
            print ex
            print 'EXX showall'




    # def play_iptv(self):
        # if self.banned == True:
            # self.session.open(MessageBox, self.banned_text, type=MessageBox.TYPE_ERROR, timeout=5)
        # else:
            # self.set_tmp_list()
            # selected_channel = self.channel_list[self.index]
            # stream_url = selected_channel[4]
            # if stream_url != None:
                # STREAMS.video_status = True
                # #STREAMS.play_iptv = False
                # self.session.openWithCallback(self.check_standby, nIPTVplayer)
        # return


    def ok(self):
        if STREAMS.xml_error != '':
            self.index_tmp = self.mlist.getSelectionIndex()
        else:
            selected_channel = self.channel_list[self.mlist.getSelectionIndex()]
            STREAMS.list_index = self.mlist.getSelectionIndex()
            title = selected_channel[1]
            if selected_channel[0] != '[H]':
                # title = datetime.fromtimestamp(time()).strftime('[%H:%M:%S %d/%m]   ') + selected_channel[1]
                title = ('[-]   ') + selected_channel[1]
            selected_channel_history = ('[H]',
             title,
             selected_channel[2],
             selected_channel[3],
             selected_channel[4],
             selected_channel[5],
             selected_channel[6],
             selected_channel[7],
             selected_channel[8],
             selected_channel[9])
            STREAMS.iptv_list_history.append(selected_channel_history)
            self.temp_index = -1
            if selected_channel[9] != None:
                self.temp_index = self.index
                #self.myPassInput()
            else:
                self.ok_checked()
        # return

    def ok_checked(self):
        try:
            if self.temp_index > -1:
                self.index = self.temp_index
            selected_channel = STREAMS.iptv_list[self.index]
            stream_url = selected_channel[4]
            playlist_url = selected_channel[5]
            if playlist_url != None:
                STREAMS.get_list(playlist_url)
                self.update_channellist()
            elif stream_url != None:
                if stream_url.find('.ts') > 0:
                    self.set_tmp_list()
                    STREAMS.video_status = True
                    STREAMS.play_vod = False
                    print '------------------------ LIVE ------------------'
                    if config.plugins.XCplugin.LivePlayer.value == False :
                        self.session.openWithCallback(self.check_standby, xc_Player)
                    else:
                        self.session.openWithCallback(self.check_standby, nIPTVplayer)
                else:
                    self.set_tmp_list()
                    STREAMS.video_status = True
                    STREAMS.play_vod = True
                    print '----------------------- MOVIE ------------------'
                    self.session.openWithCallback(self.check_standby, xc_Player)
        except Exception as ex:
            print ex
            print 'ok_checked'


        # return

    #
    def check_standby(self, myparam = None):
        debug(myparam, 'check_standby')
        if myparam:
            self.power()

    #
    def power(self):
        self.session.nav.stopService()
        self.session.open(Standby)

    #
    def set_tmp_list(self):
        self.index = self.mlist.getSelectionIndex()
        STREAMS.list_index = self.index
        STREAMS.list_index_tmp = STREAMS.list_index
        STREAMS.iptv_list_tmp = STREAMS.iptv_list
        STREAMS.playlistname_tmp = STREAMS.playlistname
        STREAMS.url_tmp = STREAMS.url
        STREAMS.next_page_url_tmp = STREAMS.next_page_url
        STREAMS.next_page_text_tmp = STREAMS.next_page_text
        STREAMS.prev_page_url_tmp = STREAMS.prev_page_url
        STREAMS.prev_page_text_tmp = STREAMS.prev_page_text
        
    #
    def load_from_tmp(self):
        debug('load_from_tmp')
        STREAMS.iptv_list = STREAMS.iptv_list_tmp
        STREAMS.list_index = STREAMS.list_index_tmp
        STREAMS.playlistname = STREAMS.playlistname_tmp
        STREAMS.url = STREAMS.url_tmp
        STREAMS.next_page_url = STREAMS.next_page_url_tmp
        STREAMS.next_page_text = STREAMS.next_page_text_tmp
        STREAMS.prev_page_url = STREAMS.prev_page_url_tmp
        STREAMS.prev_page_text = STREAMS.prev_page_text_tmp
        self.index = STREAMS.list_index

    def msg_save_tv_old(self):
            dom = (_('SINGLE FAVORITES LIST'))        
            self.session.openWithCallback(self.save_tv,MessageBox,_("CONVERT TEAM TO %s ?")% dom, MessageBox.TYPE_YESNO, timeout = 7, default = False) 
            
    def save_tv(self, result):
        if result:
            self.save_old()


    def save_old(self):
        if not fileExists("/tmp/saveurl.txt"):
            return
        if config.plugins.XCplugin.typem3utv.value == 'MPEGTS to TV':
            pthTv = '/etc/enigma2/'
            xc1 = STREAMS.playlistname
            namebouquet = xc1
            namebouquet = namebouquet.encode('utf-8') 
            f1=open("/tmp/saveurl.txt","r")
            xc12 = f1.readline()
            xc12 = xc12.strip()                
            xc2 = '&type=dreambox&output=mpegts'                
            if os.path.isfile('%suserbouquet.%s__tv_.tv' % (pthTv, namebouquet)):
                os.remove('%suserbouquet.%s__tv_.tv' % (pthTv, namebouquet)) 
            try:
                urlX = xc12 + xc2   
                webFile = urllib.urlopen(urlX)
                localFile = open(('%suserbouquet.%s__tv_.tv' % (pthTv, namebouquet)), 'w') 
                localFile.write(webFile.read())
                webFile.close()
                system('sleep 3')
            except Exception as ex:
                print ex
                print 'exe save_tv'
            in_bouquets = 0
            xcname = 'userbouquet.%s__tv_.tv' % namebouquet
            if os.path.isfile('/etc/enigma2/bouquets.tv'):
                for line in open('/etc/enigma2/bouquets.tv'):
                    if xcname in line:
                        in_bouquets = 1
                if in_bouquets is 0:
                #####
                    new_bouquet = open('/etc/enigma2/new_bouquets.tv', 'w')
                    file_read = open('/etc/enigma2/bouquets.tv' ).readlines()                
                    if config.plugins.XCplugin.bouquettop.value == 'Top': #and config.plugins.XCplugin.bouquettop.value == 'Top':
                        #top  
                        new_bouquet.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\r\n' % xcname)  
                        for line in file_read:
                            new_bouquet.write(line)
                        new_bouquet.close()
                    else: #if config.plugins.XCplugin.bouquettop.value and config.plugins.XCplugin.bouquettop.value == 'Bottom':
                        for line in file_read:
                            new_bouquet.write(line)                        
                        #bottom                          
                        new_bouquet.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\r\n' % xcname)  
                        new_bouquet.close()
                    system('cp -rf /etc/enigma2/bouquets.tv /etc/enigma2/backup_bouquets.tv')
                    system('mv -f /etc/enigma2/new_bouquets.tv /etc/enigma2/bouquets.tv')
                    chmod(("/etc/enigma2/%s" % xcname), 0644)                           
                        
            self.mbox = self.session.open(MessageBox, _('Reload list in progress...') + '\n\n\n' + _('wait please...'), MessageBox.TYPE_INFO, timeout=8)
            ReloadBouquet()
            return

        else:
            pthMovie = config.plugins.XCplugin.pthmovie.value + 'movie/'#'%s' % config.plugins.XCplugin.pthmovie.value
            xc1 = STREAMS.playlistname
            namebouquet = xc1
            namebouquet = namebouquet.encode('utf-8') 
            f1=open("/tmp/saveurl.txt","r")
            xc12 = f1.readline()
            xc12 = xc12.strip()  
            xc2 = '&type=m3u_plus&output=ts'
            if os.path.isfile(pthMovie + namebouquet + ".m3u"):
                os.remove(pthMovie + namebouquet + ".m3u")    
            try:            
                urlX = xc12 + xc2   
                webFile = urllib.urlopen(urlX)
                localFile = open(('%s%s.m3u' % (pthMovie, namebouquet)), 'w') 
                localFile.write(webFile.read())
                system('sleep 5')                    
                webFile.close()
            except Exception as ex:
                print ex
                print 'exe save_tv'
            f1.close()                    
            pth2 = pthMovie
            namebouquet = pth2 + '%s.m3u' % namebouquet.encode('utf-8')
            name = namebouquet.replace('.m3u', '').replace(pth2, '')
            pth =  config.plugins.XCplugin.pthmovie.value + 'movie/' #'%s' % config.plugins.XCplugin.pthmovie.value
            xcname = 'userbouquet.%s__tv_.tv' % name
            self.iConsole = iConsole()
            desk_tmp = hls_opt = ''
            in_bouquets = 0
            
            if os.path.isfile('/etc/enigma2/%s' % xcname):
                os.remove('/etc/enigma2/%s' % xcname)
            with open('/etc/enigma2/%s' % xcname, 'w') as outfile:
                outfile.write('#NAME %s\r\n' % name.capitalize())
                for line in open(pth + '%s.m3u' % name.encode('utf-8')):
                    if line.startswith('http://'):
                        outfile.write('#SERVICE 4097:0:1:1:0:0:0:0:0:0:%s' % line.replace(':', '%3a'))
                        outfile.write('#DESCRIPTION %s' % desk_tmp)
                    elif line.startswith('#EXTINF'):
                        desk_tmp = '%s' % line.split(',')[-1]
                    elif '<stream_url><![CDATA' in line:
                        outfile.write('#SERVICE 4097:0:1:1:0:0:0:0:0:0:%s\r\n' % line.split('[')[-1].split(']')[0].replace(':', '%3a'))
                        outfile.write('#DESCRIPTION %s\r\n' % desk_tmp)
                    elif '<title>' in line:
                        if '<![CDATA[' in line:
                            desk_tmp = '%s\r\n' % line.split('[')[-1].split(']')[0]
                        else:
                            desk_tmp = '%s\r\n' % line.split('<')[1].split('>')[1]
                outfile.close()
                self.mbox = self.session.open(MessageBox, _('Check on favorites lists...'), MessageBox.TYPE_INFO, timeout=5)

            if os.path.isfile('/etc/enigma2/bouquets.tv'):
                for line in open('/etc/enigma2/bouquets.tv'):
                    if xcname in line:
                        in_bouquets = 1
                if in_bouquets is 0:
                #####
                    new_bouquet = open('/etc/enigma2/new_bouquets.tv', 'w')
                    file_read = open('/etc/enigma2/bouquets.tv' ).readlines()                 
                    if config.plugins.XCplugin.bouquettop.value == 'Top': #and config.plugins.XCplugin.bouquettop.value == 'Top':
                        # new_bouquet = open('/etc/enigma2/new_bouquets.tv', 'w')
                            #top  
                        new_bouquet.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\r\n' % xcname)  
                        for line in file_read:
                            new_bouquet.write(line)
                        new_bouquet.close()
                    else: #if config.plugins.XCplugin.bouquettop.value and config.plugins.XCplugin.bouquettop.value == 'Bottom':
                        for line in file_read:
                            new_bouquet.write(line)                        
                        #bottom                          
                        new_bouquet.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\r\n' % xcname)  
                        new_bouquet.close()
                    system('cp -rf /etc/enigma2/bouquets.tv /etc/enigma2/backup_bouquets.tv')
                    system('mv -f /etc/enigma2/new_bouquets.tv /etc/enigma2/bouquets.tv')
                    chmod(("/etc/enigma2/%s" % xcname), 0644)                           
            self.mbox = self.session.open(MessageBox, _('Reload list in progress...') + '\n\n\n' + _('wait please...'), MessageBox.TYPE_INFO, timeout=8)
            ReloadBouquet()                      
            return
        return
            
# XC PLAYER
class xc_Player(Screen, InfoBarBase, IPTVInfoBarShowHide, InfoBarSeek, InfoBarAudioSelection, InfoBarSubtitleSupport):
    STATE_IDLE = 0
    STATE_PLAYING = 1
    STATE_PAUSED = 2
    ENABLE_RESUME_SUPPORT = True
    ALLOW_SUSPEND = True
    
    def __init__(self, session, recorder_sref = None):
        self.session = session
        self.recorder_sref = None
        if config.plugins.XCplugin.VNetSpeedInfo.value == True:

            if fileExists(BRAND) or fileExists(BRANDP):            
                skin = SKIN_PATH + '/xc_Player.xml'    
            else:            
                skin = SKIN_PATH + '/xc_PlayerTs.xml'
        else:
            if fileExists(BRAND) or fileExists(BRANDP):            
                skin = SKIN_PATH + '/xc_Player_nowifi.xml'    
            else:            
                skin = SKIN_PATH + '/xc_Player_nowifiTs.xml'
        #    skin = SKIN_PATH + '/xc_Player_nowifi.xml'

        f = open(skin, 'r')
        self.skin = f.read()
        f.close()        
        Screen.__init__(self, session) 
        InfoBarBase.__init__(self, steal_current_service=True)
        IPTVInfoBarShowHide.__init__(self)
        InfoBarSeek.__init__(self, actionmap='InfobarSeekActions')
        if STREAMS.disable_audioselector == False:
            InfoBarAudioSelection.__init__(self)
        InfoBarSubtitleSupport.__init__(self)
        self.InfoBar_NabDialog = Label()
        self.service = None
        self['state'] = Label('')
        self['cont_play'] = Label('')
        self['key_record'] = Label('Record')
        self.cont_play = STREAMS.cont_play
        self['cover'] = Pixmap()
        if fileExists(BRAND) or fileExists(BRANDP):
            self.picload = ePicLoad()
        #self.picload = ePicLoad()
        self.picfile = ''
        if recorder_sref:
            self.recorder_sref = recorder_sref
            self.session.nav.playService(recorder_sref)
        else:
            self.vod_entry = STREAMS.iptv_list[STREAMS.list_index]
            self.vod_url = self.vod_entry[4]
            self.title = self.vod_entry[1]
            self.descr = self.vod_entry[2]
            self.cover = self.vod_entry[3]
        self.TrialTimer = eTimer()
        try:
            self.TrialTimer_conn = self.TrialTimer.timeout.connect(self.trialWarning)
        except:
            self.TrialTimer.callback.append(self.trialWarning)
        print 'evEOF=%d' % iPlayableService.evEOF
        self.__event_tracker = ServiceEventTracker(screen=self, eventmap={iPlayableService.evSeekableStatusChanged: self.__seekableStatusChanged,
         iPlayableService.evStart: self.__serviceStarted,
         iPlayableService.evEOF: self.__evEOF})
        self['actions'] = HelpableActionMap(self, 'nStreamPlayerVOD', {'exitVOD': self.exit,

         'moreInfo': self.show_more_info,
         'nextAR': self.nextAR,
         'prevAR': self.prevAR,
         'record': self.record, #rec
         'stopVOD': self.stopnew,
         'autoplay': self.timeshift_autoplay,
         'restartVideo': self.restartVideo,#Auto Reconnect mod         
         'prevVideo': self.prevVideo,
         'nextVideo': self.nextVideo,
         'help': self.help,
         'power': self.power_off}, -1)

        self.oldService = self.session.nav.getCurrentlyPlayingServiceReference()
        self.onFirstExecBegin.append(self.play_vod)
        self.onShown.append(self.setCover)  
        self.onPlayStateChanged.append(self.__playStateChanged)
        self.StateTimer = eTimer()
        try:
            self.StateTimer_conn = self.StateTimer.timeout.connect(self.trialWarning)
        except:
            self.StateTimer.callback.append(self.trialWarning)
        if STREAMS.trial != '':
            self.StateTimer.start(STREAMS.trial_time * 1000, True)
        self.state = self.STATE_PLAYING
        self.timeshift_url = None
        self.timeshift_title = None
        self.onShown.append(self.show_info)
        self.error_message = ''
        # return



    def setCover(self):
        try:
            vod_entry = STREAMS.iptv_list[STREAMS.list_index]
            self['cover'].instance.setPixmapFromFile(piclogo)
            if self.vod_entry[7] != '':
                if vod_entry[7].find('http') == -1:
                    self.picfile = PLUGIN_PATH + '/img/playlist/' + vod_entry[7]
                    self.decodeImage()
                    print 'LOCAL IMG VOD'
                else:
                    if STREAMS.img_loader == False:
                        self.picfile = '%s/poster.jpg' % STREAMS.images_tmp_path
                    else:
                        m = hashlib.md5()
                        m.update(self.vod_entry[7])
                        cover_md5 = m.hexdigest()
                        self.picfile = '%s/%s.jpg' % (STREAMS.images_tmp_path, cover_md5)
                    if os.path.exists(self.picfile) == False or STREAMS.img_loader == False:
                        downloadPage(self.vod_entry[7], self.picfile).addCallback(self.image_downloaded).addErrback(self.image_error)
                    else:
                        self.decodeImage()
        except Exception as ex:
            print ex
            print 'update COVER'
            


    def decodeImage(self):
        try:
            x = self['cover'].instance.size().width()
            y = self['cover'].instance.size().height()
            picture = self.picfile
            picload = self.picload
            sc = AVSwitch().getFramebufferScale()
            self.picload.setPara((x, y, sc[0], sc[1], 0, 0, '#00000000'))
            if fileExists(BRAND)or fileExists(BRANDP):
                self.picload.PictureData.get().append(boundFunction(self.showImage)) ## OPEN
            else:
                self.picload_conn = self.picload.PictureData.connect(self.showImage) ## CVS
            self.picload.startDecode(self.picfile)
        except Exception as ex:
            print ex
            print 'ERROR decodeImage'



    def showImage(self, picInfo = None):
        self['cover'].show()
        try:
            ptr = self.picload.getData()
            if ptr:
                if fileExists(BRAND) or fileExists(BRANDP):
                    self['cover'].instance.setPixmap(ptr.__deref__())  ### OPEN

                else:
                    self['cover'].instance.setPixmap(ptr)              ### CVS
        except Exception as ex:
            print ex
            print 'ERROR showImage'


    def image_downloaded(self, id):
        self.decodeImage()
        


    def downloadError(self, raw):
        try:
            system("cd / && cp -f " + piclogo + ' %s/poster.jpg' % STREAMS.images_tmp_path)

            #self.decodeImage()

        except Exception as ex:
            print ex
            print 'exe downloadError'


    def showAfterSeek(self):
        if isinstance(self, IPTVInfoBarShowHide):
            self.doShow()

#key 2

    def timeshift_autoplay(self):
        if self.timeshift_url:
            try:
                self.reference = eServiceReference(4097, 0, self.timeshift_url)
                self.reference.setName(self.timeshift_title)
                self.session.nav.playService(self.reference)
            except Exception as ex:
                print ex
                print 'EXC timeshift 1'

        else:
            if self.cont_play:
                self.cont_play = False
                self['cont_play'].setText('Auto Play OFF')

            else:
                self.cont_play = True
                self['cont_play'].setText('Auto Play ON')

            STREAMS.cont_play = self.cont_play



#key red  
    def timeshift(self):
        if self.timeshift_url:
            try:
                self.reference = eServiceReference(4097, 0, self.timeshift_url)
                self.reference.setName(self.timeshift_title)
                self.session.nav.playService(self.reference)
            except Exception as ex:
                print ex
                print 'EXC timeshift 2'

#key    



    def autoplay(self):
        if self.cont_play:
            self.cont_play = False
            self['cont_play'].setText('Auto Play OFF')
            self.session.open(MessageBox, 'Auto Play OFF', type=MessageBox.TYPE_INFO, timeout=3)
        else:
            self.cont_play = True
            self['cont_play'].setText('Auto Play ON')
            self.session.open(MessageBox, 'Auto Play ON', type=MessageBox.TYPE_INFO, timeout=3)
        STREAMS.cont_play = self.cont_play



    def show_info(self):
        if STREAMS.play_vod == True:
            self['state'].setText(' PLAY     >')
        self.hideTimer.start(5000, True)
        if self.cont_play:
            self['cont_play'].setText('Auto Play ON')
        else:
            self['cont_play'].setText('Auto Play OFF')



    def help(self):
        self.session.open(xc_help)
        # return
            

    # def back_to_video(self):
        # try:
            # if STREAMS.video_status:
                # self.video_back = False
                # self.load_from_tmp()
                # self.channel_list = STREAMS.iptv_list
                # if STREAMS.play_iptv == True:
                    # self.session.open(nIPTVplayer)
                # elif STREAMS.play_vod == True:
                    # self.session.open(nVODplayer)
        # except Exception as ex:
            # print ex
            # print 'EXC back_to_video'        
        
#2 - Auto Reconnect mod	
    def restartVideo(self):
        try:
            index = STREAMS.list_index
            video_counter = len(STREAMS.iptv_list)
            if index < video_counter:
                if STREAMS.iptv_list[index][4] != None:
                    STREAMS.list_index = index
                    self.player_helper()
        except Exception as ex:
            print ex
            print 'EXC restartVideo'
        return     



    def nextVideo(self):
        try:
            index = STREAMS.list_index + 1
            video_counter = len(STREAMS.iptv_list)
            if index < video_counter:
                if STREAMS.iptv_list[index][4] != None:
                    STREAMS.list_index = index
                    self.player_helper()
        except Exception as ex:
            print ex
            print 'EXC nextVideo'
        return




    def prevVideo(self):
        try:
            index = STREAMS.list_index - 1
            if index > -1:
                if STREAMS.iptv_list[index][4] != None:
                    STREAMS.list_index = index
                    self.player_helper()
        except Exception as ex:
            print ex
            print 'EXC prevVideo'

        return



    def player_helper(self):
        self.show_info()
        if self.vod_entry:
            self.vod_entry = STREAMS.iptv_list[STREAMS.list_index]
            self.vod_url = self.vod_entry[4]
            self.title = self.vod_entry[1]
            self.descr = self.vod_entry[2]
        STREAMS.play_vod = False
        STREAMS.list_index_tmp = STREAMS.list_index
        self.setCover()
        self.play_vod()

    #key rec    



    def record(self):
        try:
            if STREAMS.trial != '':
                self.session.open(MessageBox, 'Trialversion dont support this function', type=MessageBox.TYPE_INFO, timeout=10)
            else:
                movie = config.plugins.XCplugin.pthmovie.value + 'movie/'
                self.vod_entry = STREAMS.iptv_list[STREAMS.list_index]
                self.vod_url = self.vod_entry[4]
                self.title = self.vod_entry[1]
                self.descr = self.vod_entry[2]
                self.session.open(MessageBox, (_('BLUE = START PLAY RECORDED VIDEO')), type=MessageBox.TYPE_INFO, timeout=5)
                self.session.nav.stopService()
                self['state'].setText('RECORD')
                useragent = "--header='User-Agent: QuickTime/7.6.2 (qtver=7.6.2;os=Windows NT 5.1Service Pack 3)'"
                ende = 'mp4'
                if self.vod_entry[4].split('.')[-1].lower() == 'flv' or self.vod_url.split('.')[-1].lower() == 'flv':
                    ende = 'flv'
                title_translit = cyr2lat(self.title)
                filename = ASCIItranslit.legacyEncode(title_translit + '.') + ende
                #replace caratteri unicode
                filename = filename.replace('(', '_')
                filename = filename.replace(')', '_')
                filename = filename.replace('#', '')
                filename = filename.replace('+', '_')
                filename = filename.encode('utf-8') 
                cmd = "wget %s -c '%s' -O '%s/%s'" % (useragent, self.vod_url, movie, filename)
                JobManager.AddJob(downloadJob(self, cmd, movie + filename, self.title))
                self.createMetaFile(filename)
                self.LastJobView()
                self.timeshift_url = movie + filename 
                self.timeshift_title = '[REC] ' + self.title 
        except Exception as ex:
            print ex
            print 'ERROR record'




    def LastJobView(self):
        currentjob = None
        for job in JobManager.getPendingJobs():
            currentjob = job
        if currentjob is not None:
            self.session.open(JobView, currentjob)
        return



    def createMetaFile(self, filename):
        try:
            movie = config.plugins.XCplugin.pthmovie.value + 'movie/'
            text = re.compile('<[\\/\\!]*?[^<>]*?>')
            text_clear = ''
            if self.vod_entry[2] != None:
                text_clear = text.sub('', self.vod_entry[2])
            serviceref = eServiceReference(4097, 0, movie + filename)
            metafile = open('%s%s.meta' % (movie, filename), 'w')   
            metafile.write('%s\n%s\n%s\n%i\n' % (serviceref.toString(),
             self.title.replace('\n', ''),
             text_clear.replace('\n', ''),
             time()))
            metafile.close()
        except Exception as ex:
            print ex
            print 'ERROR metaFile'

        return



    def __evEOF(self):
        if self.cont_play:
            self.restartVideo()


    def __seekableStatusChanged(self):
        print 'seekable status changed!'



    def __serviceStarted(self):
        self['state'].setText(' PLAY     >')
        self['cont_play'].setText('Auto Play OFF')
        self.state = self.STATE_PLAYING



    def doEofInternal(self, playing):
        if not self.execing:
            return
        if not playing:
            return
        print 'doEofInternal EXIT OR NEXT'


    def stopnew(self):
        if STREAMS.playhack == '':
            self.exit()


    def power_off(self):
        self.close(1)



    def exit(self):
        if STREAMS.playhack == '':
            self.session.nav.stopService()
            STREAMS.play_vod = False
            self.session.nav.playService(self.oldService)            
        OnclearMem()
        self.close()



    def nextAR(self):
        message = nextAR()
        self.session.open(MessageBox, message, type=MessageBox.TYPE_INFO, timeout=3)



    def prevAR(self):
        message = prevAR()
        self.session.open(MessageBox, message, type=MessageBox.TYPE_INFO, timeout=3)





    def trialWarning(self):
        self.StateTimer.start(STREAMS.trial_time * 1000, True)
        self.session.open(MessageBox, STREAMS.trial, type=MessageBox.TYPE_INFO, timeout=STREAMS.trial_time)


    def show_more_info(self):
        #self.session.open(MessageBox, self.vod_url, type=MessageBox.TYPE_INFO)
        try:
            if self.vod_entry[2] != None:
                self.descr = self.vod_entry
                text = re.compile('<[\\/\\!]*?[^<>]*?>')
                text_clear = ''
                text_clear = text.sub('', self.descr[2])
                self.session.open(xc_Epg, text_clear)
                return

            else:
                return

        except Exception as ex:
            print ex
            print 'ERROR show_more_info'






    def __playStateChanged(self, state):
        self.hideTimer.start(5000, True)
        print 'self.seekstate[3] ' + self.seekstate[3]
        text = ' ' + self.seekstate[3]
        if self.seekstate[3] == '>':
            text = ' PLAY     >'
        if self.seekstate[3] == '||':
            text = 'PAUSE   ||'
        if self.seekstate[3] == '>> 2x':
            text = '    x2     >>'
        if self.seekstate[3] == '>> 4x':
            text = '    x4     >>'
        if self.seekstate[3] == '>> 8x':
            text = '    x8     >>'
        self['state'].setText(text)

        
    # def play_vod(self):
        # try:
            # if self.vod_url != '' and self.vod_url != None and len(self.vod_url) > 5:
                # if self.vod_url.find('.ts') > 0:
                    # print '------------------------ LIVE ------------------'
                    # self.session.nav.stopService()
                    # self.reference = eServiceReference(1, 0, self.vod_url)
                    # print self.reference
                    # self.reference.setName(self.title)
                    # self.session.nav.playService(self.reference)
                # else:
                    # print '------------------------ movie ------------------'
                    # self.session.nav.stopService()

                    # if config.plugins.XCplugin.services.value == 'Gstreamer':
                         # self.reference = eServiceReference(4097, 0, self.vod_url)
                    # else:
                         # self.reference = eServiceReference(5002, 0, self.vod_url) 
                         # self.reference.setName(self.title)
                         # self.session.nav.playService(self.reference)
            # else:

                # if self.error_message:
                        # self.session.open(MessageBox, self.error_message.encode('utf-8'), type=MessageBox.TYPE_ERROR)
                # else:
                    # self.session.open(MessageBox, 'NO VIDEOSTREAM FOUND'.encode('utf-8'), type=MessageBox.TYPE_ERROR)
                    # self.close()

                
        # except Exception as ex:
            # print 'vod play error 2'

            # print ex       
        


    def play_vod(self):
        try:
            if self.vod_url != '' and self.vod_url != None and len(self.vod_url) > 5:
                    print '------------------------ MOVIE ------------------'
                    self.session.nav.stopService()
                    if config.plugins.XCplugin.services.value == 'Gstreamer':
                        self.reference = eServiceReference(4097, 0, self.vod_url)

                    else:
                        self.reference = eServiceReference(5002, 0, self.vod_url)                 

                    self.reference.setName(self.title)
                    self.session.nav.playService(self.reference)
            else:
                if self.error_message:
                    self.session.open(MessageBox, self.error_message.encode('utf-8'), type=MessageBox.TYPE_ERROR)
                else:
                    self.session.open(MessageBox, 'NO VIDEOSTREAM FOUND'.encode('utf-8'), type=MessageBox.TYPE_ERROR)

                # self.close()
        except Exception as ex:

            print 'vod play error 2'
            print ex



    def parse_url(self):
        if STREAMS.playhack != '':
            self.vod_url = STREAMS.playhack
        print '++++++++++parse_url+++++++++++'
        try:
            url = self.vod_url
        except Exception as ex:
            print 'ERROR+++++++++++++++++parse_url++++++++++++++++++++++ERROR'
            print ex




class xc_StreamTasks(Screen):

    def __init__(self, session):
        self.session = session
        skin = SKIN_PATH + '/xc_StreamTasks.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()
        Screen.__init__(self, session) 
        self['shortcuts'] = ActionMap(['OkCancelActions', 'ColorActions'], {'ok': self.keyOK,
         'esc' : self.keyClose,
         'exit' : self.keyClose,
         'green': self.message1,
         'red': self.keyClose,
         'cancel': self.keyClose}, -1)
        self['movielist'] = List([])
        self['version'] = Label(_(' V. %s' % version))         
        
        self["key_green"] = Label(_("Remove"))
        self["key_red"] = Label(_("Close"))
        self.oldService = self.session.nav.getCurrentlyPlayingServiceReference()
        self.Timer = eTimer()
        try:
            self.Timer_conn = self.Timer.timeout.connect(self.TimerFire)
        except:
            self.Timer.callback.append(self.TimerFire)
        self.onLayoutFinish.append(self.layoutFinished)
        self.onClose.append(self.__onClose)


    def __onClose(self):
        del self.Timer



    def layoutFinished(self):
        self.Timer.startLongTimer(2)


    def TimerFire(self):
        self.Timer.stop()
        self.rebuildMovieList()


    def rebuildMovieList(self):
        self.movielist = []
        self.getTaskList()
        self.getMovieList()
        self['movielist'].setList(self.movielist)
        self['movielist'].updateList(self.movielist)



    def getTaskList(self):
        for job in JobManager.getPendingJobs():
            self.movielist.append((job,
             job.name,
             job.getStatustext(),
             int(100 * job.progress / float(job.end)),
             str(100 * job.progress / float(job.end)) + '%'))

        if len(self.movielist) >= 1:
            self.Timer.startLongTimer(10)


    def getMovieList(self):
        movie = config.plugins.XCplugin.pthmovie.value + 'movie/'
        filelist = listdir(movie)

        if filelist is not None:
            filelist.sort()
            for filename in filelist:
                if path.isfile(movie + filename) and filename.endswith('.meta') is False:            
                    if '.m3u' in filename:
                        continue
                    self.movielist.append(('movie', filename, _('Finished'), 100, '100%'))
        return


    def keyOK(self):
        movie = config.plugins.XCplugin.pthmovie.value + 'movie/'
        current = self['movielist'].getCurrent()
        if current:
            if current[0] == 'movie':
                sref = eServiceReference(4097, 0, movie + current[1])            
                sref.setName(current[1])
                self.session.open(xc_Player, sref)
            else:
                job = current[0]
                self.session.openWithCallback(self.JobViewCB, JobView, job)


    def JobViewCB(self, why):
        pass


    def keyClose(self):
        if STREAMS.playhack == '':
            self.session.nav.stopService()
            STREAMS.play_vod = False
        self.close()


    def message1(self):
        movie = config.plugins.XCplugin.pthmovie.value + 'movie/'
        current = self['movielist'].getCurrent()
        sel = movie + current[1]
        dom = sel
        self.session.openWithCallback(self.callMyMsg1,MessageBox,_("Do you want to remove %s ?")% dom, MessageBox.TYPE_YESNO, timeout = 15, default = False)       

    def callMyMsg1(self, result):
        if result:
            movie = config.plugins.XCplugin.pthmovie.value + 'movie/'
            current = self['movielist'].getCurrent()
            sel = movie + current[1]
            os.remove(sel)
            self.session.open(MessageBox, sel + '   has been successfully deleted\nwait time to refresh the list...', MessageBox.TYPE_INFO, timeout=5)            
            self.onShown.append(self.rebuildMovieList)         


class html_parser_moduls():

    def __init__(self):
        self.next_page_url = ''
        self.next_page_text = ''
        self.prev_page_url = ''
        self.prev_page_text = ''
        self.playlistname = ''
        self.error = ''



    def reset_buttons(self):
        self.next_page_url = None
        self.next_page_text = ''
        self.prev_page_url = None
        self.prev_page_text = ''
        return

    def get_list(self, url):
        debug(url, 'MODUL URL: ')
        self.reset_buttons()



def xcm3ulistEntry(download):
    res = [download]
    white = 16777215
    blue = 79488
    col = 16777215
    backcol = 1.9232323
    res.append(MultiContentEntryText(pos=(0, 0), size=(1200, 40), text=download, color=col, color_sel=white, backcolor=backcol, backcolor_sel=blue))
    return res




def m3ulistxc(data, list):
    icount = 0
    mlist = []
    for line in data:
        name = data[icount]
        mlist.append(xcm3ulistEntry(name))
        icount = icount + 1
    list.setList(mlist)



class xcM3UList(MenuList):
    def __init__(self, list):
        MenuList.__init__(self, list, True, eListboxPythonMultiContent)
        if HD > 1280:
            self.l.setItemHeight(45)
            textfont = int(32)
            self.l.setFont(0, gFont('Regular', textfont))
        else:
            self.l.setItemHeight(22)
            textfont = int(16)
            self.l.setFont(0, gFont('Regular', textfont))
            
class xc_Play(Screen):
    def __init__(self, session):
        self.session = session
        skin = SKIN_PATH + '/xc_M3uLoader.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()
        Screen.__init__(self, session) 
        self.list = []
        self['list'] = xcM3UList([])
        self.initialservice = self.session.nav.getCurrentlyPlayingServiceReference()
        OnclearMem()
        movie = config.plugins.XCplugin.pthmovie.value + 'movie/'
        self.name = movie
        self['path'] = Label(_('Put .m3u Files in Folder %s') % movie)
        self['version'] = Label(_(' V. %s' % version))
        self["key_red"] = Label(_("Close"))
        self["key_green"] = Label(_("Remove"))
        self["key_yellow"] = Label(_("Convert"))      
        self['setupActions'] = ActionMap(['SetupActions', 'ColorActions', 'MenuActions', 'TimerEditActions'], {
         'red': self.cancel,
         'green': self.message1,
         'yellow': self.message2,
         'cancel': self.cancel,
         'ok': self.runList}, -2)
        self.onLayoutFinish.append(self.openList)
    #
    def openList(self):
        self.names = []
        self.Movies = []
        path = config.plugins.XCplugin.pthmovie.value + 'movie/'        
        # path = self.name
        AA = ['.mkv','.mp4','.avi','.m3u']
        for root, dirs, files in os.walk(path):
            for name in files:
                for x in AA:
                    if not x in name:
                        continue
                        pass
                    self.names.append(name)
                    self.Movies.append(root +'/'+ name)
        pass
        m3ulistxc(self.names, self['list'])
        
    def runList(self):
        idx = self['list'].getSelectionIndex()
        path = self.Movies[idx]#config.plugins.XCplugin.pthmovie.value# + 'movie/'
        if idx == -1 or None:
            return
        else:
            name = path# + self.names[idx]
            if '.m3u' in name : 
                self.session.open(xc_M3uPlay, name)
                return
            else:
                name = self.names[idx]            
                sref = eServiceReference(4097, 0, path)
                sref.setName(name)
                self.session.openWithCallback(self.backToIntialService,xc_Player, sref)       
                return
                
    def backToIntialService(self, ret = None):
        self.session.nav.stopService()
        self.session.nav.playService(self.initialservice)
    #
    def cancel(self):
        self.close()
        
    #
    def message1(self):
        idx = self['list'].getSelectionIndex()
        if idx == -1 or None:
            return
        else:
            idx = self['list'].getSelectionIndex()
            dom = self.name + self.names[idx]
            self.session.openWithCallback(self.callMyMsg1,MessageBox,_("Do you want to remove: %s ?")% dom, MessageBox.TYPE_YESNO, timeout = 15, default = False)       
    #
    def callMyMsg1(self, result):
        if result:
            idx = self['list'].getSelectionIndex()
            dom = self.name + self.names[idx]
            if fileExists(dom):
                os.remove(dom)
                self.session.open(MessageBox, dom +'   has been successfully deleted\nwait time to refresh the list...', MessageBox.TYPE_INFO, timeout=5)
                del self.names[idx]
                m3ulistxc(self.names, self['list'])
            else:
                self.session.open(MessageBox, dom +'   not exist!', MessageBox.TYPE_INFO, timeout=5)
    #
    def message2(self):
        idx = self['list'].getSelectionIndex()
        if idx == -1 or None:
            return
        else:
            idx = self['list'].getSelectionIndex()
            dom = self.names[idx]
            self.session.openWithCallback(self.convert,MessageBox,_("Do you want to Convert %s to favorite .tv ?")% dom, MessageBox.TYPE_YESNO, timeout = 15, default = False)  
    #
    def convert(self, result):
        idx = self['list'].getSelectionIndex()
        if result:        
            name = self.names[idx]
            self.convert_bouquet()
            return           
        else:
            return
    #
    def convert_bouquet(self):
        idx = self['list'].getSelectionIndex()
        if idx == -1 or None:
            return
        else:
            path = config.plugins.XCplugin.pthmovie.value + 'movie/'
            name = path + self.names[idx]
            namel = self.names[idx]
            # pth = self.name
            xcname = 'userbouquet.%s.tv' % namel.replace('.m3u', '').replace(' ', '')
            self.iConsole = iConsole()
            desk_tmp = hls_opt = ''
            in_bouquets = 0
            if os.path.isfile('/etc/enigma2/%s' % xcname):
                os.remove('/etc/enigma2/%s' % xcname)
            with open('/etc/enigma2/%s' % xcname, 'w') as outfile:
                outfile.write('#NAME %s\r\n' % namel.replace('.m3u', '').replace(' ', '').capitalize())            
                for line in open('%s' % name.encode('utf-8')):
                    if line.startswith('http://'):
                        outfile.write('#SERVICE 4097:0:1:1:0:0:0:0:0:0:%s' % line.replace(':', '%3a'))
                        outfile.write('#DESCRIPTION %s' % desk_tmp)
                    elif line.startswith('#EXTINF'):
                        desk_tmp = '%s' % line.split(',')[-1]
                    elif '<stream_url><![CDATA' in line:
                        outfile.write('#SERVICE 4097:0:1:1:0:0:0:0:0:0:%s\r\n' % line.split('[')[-1].split(']')[0].replace(':', '%3a'))
                        outfile.write('#DESCRIPTION %s\r\n' % desk_tmp)
                    elif '<title>' in line:
                        if '<![CDATA[' in line:
                            desk_tmp = '%s\r\n' % line.split('[')[-1].split(']')[0]
                        else:
                            desk_tmp = '%s\r\n' % line.split('<')[1].split('>')[1]
                outfile.close()
                self.mbox = self.session.open(MessageBox, _('Check on favorites lists...'), MessageBox.TYPE_INFO, timeout=5)
            if os.path.isfile('/etc/enigma2/bouquets.tv'):
                for line in open('/etc/enigma2/bouquets.tv'):
                    if xcname in line:
                        in_bouquets = 1
                if in_bouquets is 0:
                    if os.path.isfile('/etc/enigma2/%s' % xcname) and os.path.isfile('/etc/enigma2/bouquets.tv'):
                        remove_line('/etc/enigma2/bouquets.tv', xcname)
                        with open('/etc/enigma2/bouquets.tv', 'a') as outfile:
                            outfile.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\r\n' % xcname)
                outfile.close()
            self.mbox = self.session.open(MessageBox, _('Reload list in progress...') + '\n\n\n' + _('wait please...'), MessageBox.TYPE_INFO, timeout=8)
            ReloadBouquet()
            return

            


class xc_M3uPlay(Screen):
    def __init__(self, session, name):
        self.session = session
        skin = SKIN_PATH + '/xc_M3uPlay.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()  
        Screen.__init__(self, session) 
        self.list = []
        self['list'] = xcM3UList([])
        self['version'] = Label(_(' V. %s' % version))
        self["key_red"] = Label(_("Close"))
        self["key_green"] = Label(_("Play"))
        self['setupActions'] = ActionMap(['SetupActions', 'ColorActions', 'TimerEditActions'], {'red': self.close,
         'green': self.runChannel,
         'cancel': self.cancel,
         'ok': self.runChannel}, -2)
        self['live'] = Label('')
        self['live'].setText('')
        path = config.plugins.XCplugin.pthmovie.value + 'movie/'
        self.name = name
        self.onLayoutFinish.append(self.playList)




    def playList(self):
        self.names = []
        self.urls = []            
        try:
            if fileExists(self.name):
                f1 = open(self.name, 'r+')
                fpage = f1.read()
                regexcat = 'EXTINF.*?,(.*?)\\n(.*?)\\n'
                match = re.compile(regexcat, re.DOTALL).findall(fpage)
                for name, url in match:
                    url = url.replace(' ', '')
                    url = url.replace('\\n', '')
                    self.names.append(name)
                    self.urls.append(url)
                m3ulistxc(self.names, self['list'])
                self['live'].setText(str(len(self.names)) + ' Stream')
        except Exception as ex:
            print ex
            print 'ex playList'           

    def runChannel(self):
        idx = self['list'].getSelectionIndex()
        if idx == -1 or None:
            return
        else:
            name = self.names[idx]
            url = self.urls[idx]
            self.session.open(M3uPlay2, name, url)
            return



    def cancel(self):
        Screen.close(self, False)


class M3uPlay2(Screen, InfoBarMenu, InfoBarBase, InfoBarSeek, InfoBarNotifications, InfoBarShowHide, InfoBarAudioSelection, InfoBarSubtitleSupport):

    def __init__(self, session, name, url):
        Screen.__init__(self, session)
        self.skinName = 'MoviePlayer'
        title = 'Play Stream'
        self['list'] = MenuList([])
        OnclearMem()
        if STREAMS.disable_audioselector == False:
            InfoBarAudioSelection.__init__(self)
        InfoBarSubtitleSupport.__init__(self)
        InfoBarMenu.__init__(self)
        InfoBarNotifications.__init__(self)
        InfoBarBase.__init__(self)
        InfoBarShowHide.__init__(self)
        self['actions'] = ActionMap(['WizardActions',
         'MoviePlayerActions',
         'MovieSelectionActions',
         'MediaPlayerActions',
         'EPGSelectActions',
         'MediaPlayerSeekActions',
         'SetupActions',
         'ColorActions',
         'InfobarShowHideActions',
         'InfobarActions',
         'InfobarSeekActions'], {'leavePlayer': self.cancel,
         'showEventInfo': self.showVideoInfo,
         'stop': self.leavePlayer,
         'back': self.cancel}, -1)
        self.allowPiP = False
        InfoBarSeek.__init__(self, actionmap='InfobarSeekActions')       
        url = url.replace(':', '%3a')  
        self.url = url
        self.name = name
        self.oldService = self.session.nav.getCurrentlyPlayingServiceReference()
        self.onLayoutFinish.append(self.openPlay)

    # def openPlay(self):
        # url = self.url
        # if ".ts" in self.url: 
            # ref = '4097:0:1:0:0:0:0:0:0:0:' + url
            # print "ref= ", ref        
        
        # else:
        
            # if config.plugins.XCplugin.services.value == 'Gstreamer':
                # ref = '4097:0:1:0:0:0:0:0:0:0:' + url
                # print "ref= ", ref
            # else:
                # ref = '5002:0:1:0:0:0:0:0:0:0:' + url
                # print "ref= ", ref
        # sref = eServiceReference(ref)
        # sref.setName(self.name)
        # self.session.nav.stopService()
        # self.session.nav.playService(sref)
        
    def openPlay(self):
        url = self.url
        if config.plugins.XCplugin.services.value == 'Gstreamer':
            ref = '4097:0:1:0:0:0:0:0:0:0:' + url
        else:
            ref = '5002:0:1:0:0:0:0:0:0:0:' + url          
        sref = eServiceReference(ref)
        sref.setName(self.name)
        self.session.nav.stopService()
        self.session.nav.playService(sref)
    

    def cancel(self):
        self.session.nav.stopService()
        self.session.nav.playService(self.oldService)
        self.close()



    def ok(self):
        if self.shown:
            self.hideInfobar()
        else:
            self.showInfobar()



    def keyLeft(self):
        self['text'].left()



    def keyRight(self):
        self['text'].right()



    def showVideoInfo(self):
        if self.shown:
            self.hideInfobar()
        if self.infoCallback is not None:
            self.infoCallback()
        return



    def leavePlayer(self):
        self.close()


class xc_help(Screen): 
    def __init__(self, session):

        self.session = session
        skin = SKIN_PATH + '/xc_help.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()
        Screen.__init__(self, session)          
        self['version'] = Label(_(' V. %s' % version))
        self['key_red'] = Label(_("Close"))
        self["helpdesc"] = Label()
        self["infocredits"] = Label()     
        self["actions"] = ActionMap(["SetupActions", "xc_help"],{"back": self.close, 'key_red': self.close}, -1)
        self.onLayoutFinish.append(self.finishLayout)




    def finishLayout(self):
        self["helpdesc"].setText(self.gethelpdesc())
        self["infocredits"].setText(self.getinfocredits())
        return


    def gethelpdesc(self):
        conthelp = "XCplugin by Lululla E2 Plugin (http://lululla.altervista.org) \n\n"
        conthelp += "Skin Mods By:\tMMARK, Info http://e2skin.blogspot.it/\n" 
        conthelp += "Re-coded from Lululla\n"         
        conthelp += "Lo sviluppo e gli aggiornamenti apportati a questo Plugin sono importanti ed hanno richiesto molto tempo e studio\n"
        conthelp += "Se siete utilizzatori di questo plugin, considerate la possibilita di effettuare una donazione anche di piccola entita\n" 
        conthelp += "In questo modo incoraggerete l'autore a proseguire nell'aggiornamento ed il miglioramento del plugin, dandogli il modo\n"
        conthelp += "di acquistare decoder aggiornati neccessari ad aggiornare il plugin alle nuove tecnologie\n\n\n"
        conthelp += "The development and improvements for this Plugins are important, and required a lot of time and study\n"
        conthelp += "If you are a user of this plugin, consider making a small donation.\n"
        conthelp += "In this way, encourage the author to continue updating and improving the plugin, giving him the means\n"
        conthelp += "to purchase the latest decoders needed to upgrade the plugin to new technologies.\n"
        conthelp += "CREDITS TO: CorvoBoys Corvone.com - linuxsat-support.com\n MMark, Pcd, Aime_Jeux, Diamondear, Bliner_Key, M2boom, Pauldb and all those who participated and others I forgot to mention.\n"
        conthelp += "*** Please report any bugs you find ***"
        conthelp += "\n"
        return conthelp


    def getinfocredits(self):
        conthelp = 'XCplugin E2 Plugin v. %s\n' % version
        conthelp += 'XCplugin Version config file .xml v. %s\n' % STREAMS.plugin_version
        conthelp += 'Current Service Type: %s\n' % config.plugins.XCplugin.services.value         
        conthelp += 'VNetSpeedInfo Active in Player %s\n' % config.plugins.XCplugin.VNetSpeedInfo.value
        conthelp += 'LivePlayer Active %s\n' % config.plugins.XCplugin.LivePlayer.value         
        conthelp += 'Folder file xml %s\n' % config.plugins.XCplugin.pthxmlfile.value
        conthelp += 'Movie Folder %smovie/\n' % config.plugins.XCplugin.pthmovie.value        
        conthelp += 'Conversion type List %s\n' % config.plugins.XCplugin.typem3utv.value
        return conthelp   


def debug(obj, text = ''):
    # print datetime.fromtimestamp(time()).strftime('[%H:%M:%S]')
    print '%s' % text + ' %s\n' % obj


  
conversion = {unicode('\xd0\xb0'): 'a',
 unicode('\xd0\x90'): 'A',
 unicode('\xd0\xb1'): 'b',
 unicode('\xd0\x91'): 'B',
 unicode('\xd0\xb2'): 'v',
 unicode('\xd0\x92'): 'V',
 unicode('\xd0\xb3'): 'g',
 unicode('\xd0\x93'): 'G',
 unicode('\xd0\xb4'): 'd',
 unicode('\xd0\x94'): 'D',
 unicode('\xd0\xb5'): 'e',
 unicode('\xd0\x95'): 'E',
 unicode('\xd1\x91'): 'jo',
 unicode('\xd0\x81'): 'jo',
 unicode('\xd0\xb6'): 'zh',
 unicode('\xd0\x96'): 'ZH',
 unicode('\xd0\xb7'): 'z',
 unicode('\xd0\x97'): 'Z',
 unicode('\xd0\xb8'): 'i',
 unicode('\xd0\x98'): 'I',
 unicode('\xd0\xb9'): 'j',
 unicode('\xd0\x99'): 'J',
 unicode('\xd0\xba'): 'k',
 unicode('\xd0\x9a'): 'K',
 unicode('\xd0\xbb'): 'l',
 unicode('\xd0\x9b'): 'L',
 unicode('\xd0\xbc'): 'm',
 unicode('\xd0\x9c'): 'M',
 unicode('\xd0\xbd'): 'n',
 unicode('\xd0\x9d'): 'N',
 unicode('\xd0\xbe'): 'o',
 unicode('\xd0\x9e'): 'O',
 unicode('\xd0\xbf'): 'p',
 unicode('\xd0\x9f'): 'P',
 unicode('\xd1\x80'): 'r',
 unicode('\xd0\xa0'): 'R',
 unicode('\xd1\x81'): 's',
 unicode('\xd0\xa1'): 'S',
 unicode('\xd1\x82'): 't',
 unicode('\xd0\xa2'): 'T',
 unicode('\xd1\x83'): 'u',
 unicode('\xd0\xa3'): 'U',
 unicode('\xd1\x84'): 'f',
 unicode('\xd0\xa4'): 'F',
 unicode('\xd1\x85'): 'h',
 unicode('\xd0\xa5'): 'H',
 unicode('\xd1\x86'): 'c',
 unicode('\xd0\xa6'): 'C',
 unicode('\xd1\x87'): 'ch',
 unicode('\xd0\xa7'): 'CH',
 unicode('\xd1\x88'): 'sh',
 unicode('\xd0\xa8'): 'SH',
 unicode('\xd1\x89'): 'sh',
 unicode('\xd0\xa9'): 'SH',
 unicode('\xd1\x8a'): '',
 unicode('\xd0\xaa'): '',
 unicode('\xd1\x8b'): 'y',
 unicode('\xd0\xab'): 'Y',
 unicode('\xd1\x8c'): 'j',
 unicode('\xd0\xac'): 'J',
 unicode('\xd1\x8d'): 'je',
 unicode('\xd0\xad'): 'JE',
 unicode('\xd1\x8e'): 'ju',
 unicode('\xd0\xae'): 'JU',
 unicode('\xd1\x8f'): 'ja',
 unicode('\xd0\xaf'): 'JA'}


def cyr2lat(text):
    i = 0
    text = text.strip(' \t\n\r')
    text = unicode(text)
    retval = ''
    bukva_translit = ''
    bukva_original = ''
    while i < len(text):
        bukva_original = text[i]
        try:
            bukva_translit = conversion[bukva_original]
        except:
            bukva_translit = bukva_original

        i = i + 1
        retval += bukva_translit
    return retval



       
############ 
class xc_Epg(Screen): 

    def __init__(self, session, text_clear):

        self.session = session
        skin = SKIN_PATH + '/xc_epg.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()
        Screen.__init__(self, session)       
        text_clear = text_clear        
        self['version'] = Label(_(' V. %s' % version))
        self['key_red'] = Label(_("Close"))
        self["text_clear"] = Label(text_clear)        
        self["actions"] = ActionMap(["SetupActions", "xc_epg"],{"back": self.exit, 'key_red': self.exit }, -1)




        
    def exit(self):
        self.close()


class OpenServer(Screen):
    def __init__(self, session):
        global STREAMS
        self.session = session

        if fileExists(BRAND) or fileExists(BRANDP):
            skin = SKIN_PATH + '/xc_OpenServer.xml'
        else:
            skin = SKIN_PATH + '/xc_OpenServerCvs.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()        
        Screen.__init__(self, session)
        self.list = []
        self['list'] = xcM3UList([]) 
        self['version'] = Label(_(' V. %s' % version))
        self['key_red'] = Label(_("Close"))
        self["key_green"] = Label(_("Rename"))        
        self["key_yellow"] = Label(_("Remove"))
        self['srvcsval'] = Label()#ADDADDADDADDADD
        self['VNetSpeedInfo'] = Label()#ADDADDADDADDADD
        self['LivePlayer'] = Label()#ADDADDADDADDADD
        self['ptchxzz'] = Label()#ADDADDADDADDADD
        self['ptchmovie'] = Label()#ADDADDADDADDADD
        self['typem3utv'] = Label()#ADDADDADDADDADD
        self['key_blu'] = Label(_("Import infos server"))#ADDADDADDADDADD
        self['key_blu'].hide()#ADDADDADDADDADD
        if fileExists('/tmp/xc.txt'):
            self['key_blu'].show()
        self['live'] = Label('')
        self['live'].setText('')
        self.name = config.plugins.XCplugin.pthxmlfile.value #+ '/'
        self.oldService = self.session.nav.getCurrentlyPlayingServiceReference()
        self['actions'] = HelpableActionMap(self, 'OpenServer', {'xc_config': self.xc_config,
         'ok': self.selectlist,
         'selectlist': self.selectlist,
         'remove': self.message1,
         'red': self.goMain,
         'back': self.goMain,
         'import': self.ImportInfosServer,#ADD
         'exit': self.goMain,
         'rename': self.rename,
         'help': self.help}, -1)   
        self.onLayoutFinish.append(self.openList)    

        
    def ImportInfosServer(self):#ADDADDADDADDADD
            if fileExists('/tmp/xc.txt'):
                f = file('/tmp/xc.txt',"r")
                chaine = f.readlines()
                f.close()
                url = chaine[0].replace('\n','').replace('\t','').replace('\r','')
                user = chaine[1].replace('\n','').replace('\t','').replace('\r','')
                pswrd = chaine[2].replace('\n','').replace('\t','').replace('\r','')
                filesave = 'xc_' + user + '.xml' 
                # f5 = open(config.plugins.XCplugin.pthxmlfile.value + '/' + filesave, "w") 
                pth= config.plugins.XCplugin.pthxmlfile.value + '/'
                print 'pth:', pth                
                f5 = open(pth + filesave, "w")                  
                f5.write(str('<?xml version="1.0" encoding="UTF-8" ?>\n' + '<items>\n' + '<plugin_version>' + currversion + '</plugin_version>\n' +'<xtream_e2portal_url><![CDATA[http://'+ url + '/enigma2.php]]></xtream_e2portal_url>\n' + '<username>' + user + '</username>\n' + '<password>' + pswrd + '</password>\n'+ '</items>'))
                f5.close()
                self.mbox = self.session.open(MessageBox, _('File saved to %s !' % filesave ), MessageBox.TYPE_INFO, timeout=5)
                self.onLayoutFinish.append(self.openList)
            else:
                self.mbox = self.session.open(MessageBox, _('File not found /tmp/xc.txt!'), MessageBox.TYPE_INFO, timeout=5)                



    def openList(self):
        self.names = []
        path = self.name
        # pass

        for root, dirs, files in os.walk(path):
            files.sort()
            for name in files:
                if not ".xml" in name:
                    continue
                    pass
                self.names.append(name)
        pass
        m3ulistxc(self.names, self['list'])
        self['live'].setText(str(len(self.names)) + ' Team')        
        self.updateConfig

    def updateConfig(self):
        self['srvcsval'].setText(_('Type Services %s' % config.plugins.XCplugin.services.value))
        self['VNetSpeedInfo'].setText(_('VNetSpeedInfo Active in Player %s' % config.plugins.XCplugin.VNetSpeedInfo.value))
        self['LivePlayer'].setText(_('LivePlayer Active %s' % config.plugins.XCplugin.LivePlayer.value))        
        self['ptchxzz'].setText(_('Folder file xml %s' % config.plugins.XCplugin.pthxmlfile.value)) 
        self['ptchmovie'].setText('Movie Folder %s' % config.plugins.XCplugin.pthmovie.value+'movie/')    
        self['typem3utv'].setText(_('Conversion type List %s' % config.plugins.XCplugin.typem3utv.value))


    def selectlist(self):
        idx = self['list'].getSelectionIndex()
        if idx == -1 or None:
            return
        else:
            idx = self['list'].getSelectionIndex()
            dom = self.name + '/' + self.names[idx]        
            if config.plugins.XCplugin.configured.value:
                self.mbox = self.session.open(MessageBox, _('Local Team Active\n\nPlease Start(Blue) or Change in Config'), MessageBox.TYPE_INFO, timeout=5)    
            else:
                clear_img()
                server = self.name + '/' + self.names[idx]
                system("echo '" + server + "' > " + PLUGIN_PATH + "/cfg/server.txt")
                global STREAMS
                STREAMS = iptv_streamse()
                STREAMS.read_config()
                print '\n\n\n\n'
                print '######################################################################'
                print '#######--------- XCplugin E2 Plugin v. %s -------#######' % version
                print '######################################################################'
                # if STREAMS.ar_start:
                    # testme = eAVSwitch.getInstance().setAspectRatio(STREAMS.ar_id_start)
                    # print '!!!!!!!!!!!!!!!!!eAVSwitch.getInstance().setAspectRatio %s' % testme
                self.close(STREAMS.get_list(STREAMS.xtream_e2portal_url))            
                return
            
    def goMain(self):
        clear_img()    
        global STREAMS
        STREAMS = iptv_streamse()
        STREAMS.read_config()
        print '\n\n\n\n'
        print '######################################################################'
        print '#######--------- XCplugin E2 Plugin v. %s -------#######' % version
        print '######################################################################'
        # if STREAMS.ar_start:
            # testme = eAVSwitch.getInstance().setAspectRatio(STREAMS.ar_id_start)
            # print '!!!!!!!!!!!!!!!!!eAVSwitch.getInstance().setAspectRatio %s' % testme
        self.close(STREAMS.get_list(STREAMS.xtream_e2portal_url))      

    #
    def message1(self):
        idx = self['list'].getSelectionIndex()
        if idx == -1 or None:
            return
        else:
            idx = self['list'].getSelectionIndex()
            dom = self.name + '/' + self.names[idx]
            self.session.openWithCallback(self.removeXml,MessageBox,_("Do you want to remove: %s ?")% dom, MessageBox.TYPE_YESNO, timeout = 15, default = False)       
    # #
    def removeXml(self, result):
        if result:
            idx = self['list'].getSelectionIndex()
            dom = self.name + '/' + self.names[idx]
            if fileExists(dom):
                os.remove(dom)
                self.session.open(MessageBox, dom +'   has been successfully deleted\nwait time to refresh the list...', MessageBox.TYPE_INFO, timeout=5)
                del self.names[idx]
                m3ulistxc(self.names, self['list'])
            else:
                self.session.open(MessageBox, dom +'   not exist!', MessageBox.TYPE_INFO, timeout=5)


    def rename(self):
        idx = self['list'].getSelectionIndex()
        if idx == -1 or None:
            return
        else:
            dom = self.name + '/' + self.names[idx]
            dim = self.names[idx]
            if dom is None:
                return
            else:
                global NewName
                NewName = str(dim)
                self.session.openWithCallback(self.newname, VirtualKeyBoard, text=str(dim))
            return   
            
    def newname(self, word):
        if word is None:
            pass
        else:
            oldfile = self.name + '/' + NewName
            newfile = self.name + '/' + word 
            newnameConf = "mv " + "'" + oldfile + "'" + " " + "'" + newfile + "'"
            self.session.open(Console, _('XCplugin Console Rename: %s') % oldfile, ['%s' % newnameConf], closeOnSuccess=True)          
            self.onShown.append(self.openList)
   

    def xc_config(self):
        # self.session.open(xc_config)
        self.session.openWithCallback(self.close,xc_config)
        



    def help(self):
        self.session.open(xc_help)




#xc_iptv_player
class nIPTVplayer(Screen, InfoBarBase, IPTVInfoBarShowHide, InfoBarAudioSelection, InfoBarSubtitleSupport):

    def __init__(self, session):
        self.session = session
        if config.plugins.XCplugin.VNetSpeedInfo.value == True:
            skin = SKIN_PATH + '/xc_iptv_player.xml'    
        else:            
            skin = SKIN_PATH + '/xc_iptv_player_nowifi.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()
        Screen.__init__(self, session)
        global STREAMS        
        InfoBarBase.__init__(self, steal_current_service=True)
        IPTVInfoBarShowHide.__init__(self)
        if STREAMS.disable_audioselector == False:
            InfoBarAudioSelection.__init__(self)
        InfoBarSubtitleSupport.__init__(self)
        self['channel_name'] = Label('')
        self['picon'] = Pixmap()
        if fileExists(BRAND) or fileExists(BRANDP):
           self.picload = ePicLoad()
        #self.picload = ePicLoad()
        self.picfile = ''
        self['programm'] = Label('')
        self.InfoBar_NabDialog = Label('')
        self.session = session
        self.channel_list = STREAMS.iptv_list
        self.index = STREAMS.list_index
        STREAMS.play_vod = False
        self.oldService = self.session.nav.getCurrentlyPlayingServiceReference()
        self.onFirstExecBegin.append(self.play_channel)
        self['actions'] = HelpableActionMap(self, 'nStreamPlayerIPTV', {'toChListIPTV': self.exit,
         'help': self.help,
         'moreInfo': self.show_more_info,
         'prevChannelIPTV': self.prevChannel,
         'nextChannelIPTV': self.nextChannel,
         'nextAR': self.nextAR,
         'prevAR': self.prevAR,
         'power': self.power_off}, -1)
        self.StateTimer = eTimer()
        try:
            self.StateTimer_conn = self.StateTimer.timeout.connect(self.trialWarning)
        except:
            self.StateTimer.callback.append(self.trialWarning)
        if STREAMS.trial != '':
            self.StateTimer.start(STREAMS.trial_time * 1000, True) 




    def nextAR(self):
        message = nextAR()
        self.session.open(MessageBox, message, type=MessageBox.TYPE_INFO, timeout=3)



    def prevAR(self):
        message = prevAR()
        self.session.open(MessageBox, message, type=MessageBox.TYPE_INFO, timeout=3)




    def trialWarning(self):
        self.StateTimer.start(STREAMS.trial_time * 1000, True)
        self.session.open(MessageBox, STREAMS.trial, type=MessageBox.TYPE_INFO, timeout=STREAMS.timeout_time)



    def exit(self):
        if STREAMS.playhack == '':
            self.session.nav.stopService()
            self.session.nav.playService(self.oldService)            
        OnclearMem()
        self.close()



    def power_off(self):
        self.close(1)



    def play_channel(self):
        try:

            selected_channel = STREAMS.iptv_list[self.index]
            self['channel_name'].setText(selected_channel[1])
            text = re.compile('<[\\/\\!]*?[^<>]*?>')
            text_clear = ''
            if selected_channel[2] != None:
                text_clear = text.sub('', selected_channel[2])
            self['programm'].setText(text_clear)

            try:
                #self['picon'].instance.setPixmapFromFile('%s/poster.jpg' % STREAMS.images_tmp_path)
                debug(selected_channel[3], 'selected_channel[3] IPTVLOGO')
                if selected_channel[3] != '':
                    if selected_channel[3].find('http') == -1:
                        self.picfile = selected_channel[3]
                        self.decodeImage()
                        print 'LOCAL IPTV IMG'
                    else:
                        if STREAMS.img_loader == False:
                            self.picfile = '%s/poster.jpg' % STREAMS.images_tmp_path
                        else:
                            m = hashlib.md5()
                            m.update(selected_channel[3])
                            cover_md5 = m.hexdigest()
                            self.picfile = '%s/%s.jpg' % (STREAMS.images_tmp_path, cover_md5)
                        if os.path.exists(self.picfile) == False or STREAMS.img_loader == False:
                            downloadPage(selected_channel[3], self.picfile).addCallback(self.image_downloaded).addErrback(self.downloadError)


                        else:
                            self.decodeImage()
            except Exception as ex:
                print ex
                print 'update PICON'
            try:
                esr_id = 1         
                url = selected_channel[4]
                self.session.nav.stopService()
                if url != '' and url != None:
                    sref = eServiceReference(esr_id, 0, url)
                    try:
                        self.session.nav.playService(sref)
                    except Exception as ex:
                        print 'play_channel'
                        print ex

            except Exception as ex:
                print ex
                print 'play_channel1'

        except Exception as ex:
            print ex
            print 'play_channel2'

        return



    def nextChannel(self):
        index = self.index
        index += 1
        if index == len(self.channel_list):
            index = 0
        if self.channel_list[index][4] != None:
            self.index = index

            STREAMS.list_index = self.index
            STREAMS.list_index_tmp = self.index

            self.play_channel()
        return




    def prevChannel(self):
        index = self.index
        index -= 1
        if index == -1:
            index = len(self.channel_list) - 1
        if self.channel_list[index][4] != None:
            self.index = index

            STREAMS.list_index = self.index
            STREAMS.list_index_tmp = self.index
            self.play_channel()
        return




    def help(self):
        self.session.open(xc_help)



    def show_more_info(self):
        try:
            selected_channel = STREAMS.iptv_list[self.index]
            text = re.compile('<[\\/\\!]*?[^<>]*?>')
            text_clear = ''
            if selected_channel[2] != None:
                text_clear = text.sub('', selected_channel[2])
                self.session.open(xc_Epg, text_clear)
                return
            else:
                return

        except Exception as ex:
            print ex
            print 'ERROR show_more_info'





    # Switch Param for CVS/PLI Based      
    def decodeImage(self):
        try:
            x = self['picon'].instance.size().width()
            y = self['picon'].instance.size().height()
            picture = self.picfile
            picload = self.picload
            sc = AVSwitch().getFramebufferScale()
            self.picload.setPara((x, y, sc[0], sc[1], 0, 0, '#00000000'))
            if fileExists(BRAND)or fileExists(BRANDP):
                self.picload.PictureData.get().append(boundFunction(self.showImage)) ### OPEN

            else:
                self.picload_conn = self.picload.PictureData.connect(self.showImage) ### CVS
            self.picload.startDecode(self.picfile)


        except Exception as ex:
            print ex
            print 'ERROR decodeImage'





    def showImage(self, picInfo = None):
        self['picon'].show()
        try:
            ptr = self.picload.getData()
            if ptr:
                if fileExists(BRAND) or fileExists(BRANDP): 
                    self['picon'].instance.setPixmap(ptr.__deref__())  ### OPEN

                else:

                    self['picon'].instance.setPixmap(ptr)                ### CVS
        except Exception as ex:
            print ex
            print 'ERROR showImage'



    def image_downloaded(self, id):
        self.decodeImage()



    def downloadError(self, raw):
        try:

            system("cd / && cp -f " + piclogo + ' %s/poster.jpg' % STREAMS.images_tmp_path)
            self.decodeImage()
        except Exception as ex:
            print ex
            print 'exe downloadError'


def menu(menuid, **kwargs):
    if menuid == 'mainmenu':

        return [('XCplugin',
          Start_iptv_player,
          'XCplugin',
          4)]
    return []


def Start_iptv_player(session, **kwargs):
    global STREAMS
    STREAMS = iptv_streamse()
    STREAMS.read_config()
    # if STREAMS.ar_start:
        # testme = eAVSwitch.getInstance().setAspectRatio(STREAMS.ar_id_start)
        # print '!!!!!!!!!!!!!!!!!eAVSwitch.getInstance().setAspectRatio %s' % testme
    STREAMS.get_list(STREAMS.xtream_e2portal_url)
    # session.open(xc_Main)
    session.openWithCallback(check_configuring, xc_Main)
    

# mainDescriptor = PluginDescriptor(name='XCplugin', description='XCplugin Mod' + version, where=PluginDescriptor.WHERE_MENU, fnc=menu)        
# def Plugins(**kwargs):
    # result = [PluginDescriptor(name='XCplugin', description='XCplugin Mod' + version, where=PluginDescriptor.WHERE_PLUGINMENU, icon="xcplugin.png", fnc=Start_iptv_player)]
    # if config.plugins.XCplugin.strtmain.value:
        # result.append(mainDescriptor)
    # return result

    
    
############autostart 

###############################################
        
_session = None        
autoStartTimer = None        
class AutoStartTimer:

    def __init__(self, session):
        self.session = session
        self.timer = eTimer()
        try:
            self.timer.callback.append(self.on_timer)
        except:
            self.timer_conn = self.timer.timeout.connect(self.on_timer)
        self.timer.start(50, 1)
        
        self.update()

    def get_wake_time(self):
        # if config.plugins.XCplugin.configured.value and config.plugins.XCplugin.autobouquetupdate.value and config.plugins.XCplugin.updateinterval.value:
        if config.plugins.XCplugin.autobouquetupdate.value and config.plugins.XCplugin.updateinterval.value:        
            interval = int(config.plugins.XCplugin.updateinterval.value)
            nowt = time.time()
            return int(nowt) + interval * 60 * 60    # minutes/hours
        else:
            return -1

    def update(self, atLeast = 0):
        self.timer.stop()
        wake = self.get_wake_time()
        nowt = time.time()
        now = int(nowt)
        if wake > 0:
            next = wake - now
            self.timer.startLongTimer(next)
        else:
            wake = -1
        return wake

    def on_timer(self):
        self.timer.stop()
        now = int(time.time())
        self.startMain()
        self.update()
        localtime = time.asctime(time.localtime(time.time()))
        config.plugins.XCplugin.last_update.value = localtime
        config.plugins.XCplugin.last_update.save()
        
    def startMain(self):        
        from Plugins.Extensions.XCplugin.plugin import iptv_streamse#,xc_Main
        global STREAMS
        STREAMS = iptv_streamse()
        STREAMS.read_config()
        STREAMS.get_list(STREAMS.xtream_e2portal_url)
        #self.session.open(msg_save_tv)
        
        self.save_old()

       
    def save_old(self):
        if not fileExists("/tmp/saveurl.txt"):
            return

        if config.plugins.XCplugin.typem3utv.value == 'MPEGTS to TV':
            pthTv = '/etc/enigma2/'
            xc1 = STREAMS.playlistname
            namebouquet = xc1
            namebouquet = namebouquet.encode('utf-8') 
            f1=open("/tmp/saveurl.txt","r")
            xc12 = f1.readline()
            xc12 = xc12.strip()                
            xc2 = '&type=dreambox&output=mpegts'                
            if os.path.isfile('%suserbouquet.%s__tv_.tv' % (pthTv, namebouquet)):
                os.remove('%suserbouquet.%s__tv_.tv' % (pthTv, namebouquet)) 
            try:
                urlX = xc12 + xc2   
                webFile = urllib.urlopen(urlX)
                localFile = open(('%suserbouquet.%s__tv_.tv' % (pthTv, namebouquet)), 'w') 
                localFile.write(webFile.read())
                webFile.close()
                system('sleep 3')
            except Exception as ex:
                print ex
                print 'exe save_tv'
            in_bouquets = 0
            xcname = 'userbouquet.%s__tv_.tv' % namebouquet
            if os.path.isfile('/etc/enigma2/bouquets.tv'):
                for line in open('/etc/enigma2/bouquets.tv'):
                    if xcname in line:
                        in_bouquets = 1
                if in_bouquets is 0:
                #####
                    new_bouquet = open('/etc/enigma2/new_bouquets.tv', 'w')
                    file_read = open('/etc/enigma2/bouquets.tv' ).readlines()                
                    if config.plugins.XCplugin.bouquettop.value == 'Top': #and config.plugins.XCplugin.bouquettop.value == 'Top':
                        #top  
                        new_bouquet.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\r\n' % xcname)  
                        for line in file_read:
                            new_bouquet.write(line)
                        new_bouquet.close()
                    else: #if config.plugins.XCplugin.bouquettop.value and config.plugins.XCplugin.bouquettop.value == 'Bottom':
                        for line in file_read:
                            new_bouquet.write(line)                        
                        #bottom                          
                        new_bouquet.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\r\n' % xcname)  


                        new_bouquet.close()
                    system('cp -rf /etc/enigma2/bouquets.tv /etc/enigma2/backup_bouquets.tv')
                    system('mv -f /etc/enigma2/new_bouquets.tv /etc/enigma2/bouquets.tv')
                    chmod(("/etc/enigma2/%s" % xcname), 0644)                           
            # #self.mbox = self.session.open(MessageBox, _('Reload list in progress...') + '\n\n\n' + _('wait please...'), MessageBox.TYPE_INFO, timeout=8)
            # message = (_('XcPlugin\n\nReload list in progress...\n\nwait please...' ))
            # web_info(message)
            # from Tools.Notifications import AddPopup
            messageText = _('XcPlugin\n\nReload list in progress...\n\nwait please...')
            AddPopup(messageText, MessageBox.TYPE_INFO, timeout=5) 
            ReloadBouquet()
            return
            
        else:
            pthMovie = config.plugins.XCplugin.pthmovie.value + 'movie/'#'%s' % config.plugins.XCplugin.pthmovie.value
            xc1 = STREAMS.playlistname
            namebouquet = xc1
            namebouquet = namebouquet.encode('utf-8') 
            f1=open("/tmp/saveurl.txt","r")
            xc12 = f1.readline()
            xc12 = xc12.strip()  
            xc2 = '&type=m3u_plus&output=ts'
            if os.path.isfile(pthMovie + namebouquet + ".m3u"):
                os.remove(pthMovie + namebouquet + ".m3u")    
            try:            
                urlX = xc12 + xc2   
                webFile = urllib.urlopen(urlX)
                localFile = open(('%s%s.m3u' % (pthMovie, namebouquet)), 'w') 
                localFile.write(webFile.read())
                system('sleep 5')                    
                webFile.close()
            except Exception as ex:
                print ex
                print 'exe save_tv'
            f1.close()                    
            pth2 = pthMovie
            namebouquet = pth2 + '%s.m3u' % namebouquet.encode('utf-8')
            name = namebouquet.replace('.m3u', '').replace(pth2, '')
            pth =  config.plugins.XCplugin.pthmovie.value + 'movie/' #'%s' % config.plugins.XCplugin.pthmovie.value
            xcname = 'userbouquet.%s__tv_.tv' % name
            self.iConsole = iConsole()
            desk_tmp = hls_opt = ''
            in_bouquets = 0
            if os.path.isfile('/etc/enigma2/%s' % xcname):
                os.remove('/etc/enigma2/%s' % xcname)
            with open('/etc/enigma2/%s' % xcname, 'w') as outfile:
                outfile.write('#NAME %s\r\n' % name.capitalize())
                for line in open(pth + '%s.m3u' % name.encode('utf-8')):
                    if line.startswith('http://'):
                        outfile.write('#SERVICE 4097:0:1:1:0:0:0:0:0:0:%s' % line.replace(':', '%3a'))
                        outfile.write('#DESCRIPTION %s' % desk_tmp)
                    elif line.startswith('#EXTINF'):
                        desk_tmp = '%s' % line.split(',')[-1]
                    elif '<stream_url><![CDATA' in line:
                        outfile.write('#SERVICE 4097:0:1:1:0:0:0:0:0:0:%s\r\n' % line.split('[')[-1].split(']')[0].replace(':', '%3a'))
                        outfile.write('#DESCRIPTION %s\r\n' % desk_tmp)
                    elif '<title>' in line:
                        if '<![CDATA[' in line:
                            desk_tmp = '%s\r\n' % line.split('[')[-1].split(']')[0]
                        else:
                            desk_tmp = '%s\r\n' % line.split('<')[1].split('>')[1]
                outfile.close()
                # # #self.mbox = self.session.open(MessageBox, _('Check on favorites lists...'), MessageBox.TYPE_INFO, timeout=5)
                # #message = (_('XcPlugin\n\nCheck on favorites lists...' ))
                # #web_info(message)
                # from Tools.Notifications import AddPopup
                messageText = _('Check on favorites lists...')
                AddPopup(messageText, MessageBox.TYPE_INFO, timeout=5)
    

            if os.path.isfile('/etc/enigma2/bouquets.tv'):
                for line in open('/etc/enigma2/bouquets.tv'):
                    if xcname in line:
                        in_bouquets = 1
                if in_bouquets is 0:
                #####
                    new_bouquet = open('/etc/enigma2/new_bouquets.tv', 'w')
                    file_read = open('/etc/enigma2/bouquets.tv' ).readlines()                 
                    if config.plugins.XCplugin.bouquettop.value == 'Top': #and config.plugins.XCplugin.bouquettop.value == 'Top':
                        # new_bouquet = open('/etc/enigma2/new_bouquets.tv', 'w')
                            #top  
                        new_bouquet.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\r\n' % xcname)  
                        for line in file_read:
                            new_bouquet.write(line)
                        new_bouquet.close()
                    else: #if config.plugins.XCplugin.bouquettop.value and config.plugins.XCplugin.bouquettop.value == 'Bottom':
                        for line in file_read:
                            new_bouquet.write(line)                        
                            #bottom                          
                        new_bouquet.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\r\n' % xcname)  
                        new_bouquet.close()
                    system('cp -rf /etc/enigma2/bouquets.tv /etc/enigma2/backup_bouquets.tv')
                    system('mv -f /etc/enigma2/new_bouquets.tv /etc/enigma2/bouquets.tv')
                    chmod(("/etc/enigma2/%s" % xcname), 0644)                           
            ##self.mbox = self.session.open(MessageBox, _('Reload list in progress...') + '\n\n\n' + _('wait please...'), MessageBox.TYPE_INFO, timeout=8)
            #message = (_('XcPlugin\n\nReload list in progress...\n\nwait please...' ))
            #web_info(message)
            
            messageText = _('XcPlugin\n\nReload list in progress...\n\nwait please...')
            AddPopup(messageText, MessageBox.TYPE_INFO, timeout=5)
                
            ReloadBouquet()                      
            return
        return                
        
def check_configuring():
    """Check for new config values for auto start
    """
    global autoStartTimer
    if autoStartTimer is not None:
        autoStartTimer.update()
    return


def autostart(reason, session = None, **kwargs):
    global autoStartTimer
    global _session
    if reason == 0 and _session is None:
        if session is not None:
            _session = session
            if autoStartTimer is None:
                autoStartTimer = AutoStartTimer(session)

    return


def get_next_wakeup():
    return -1


   
mainDescriptor = [PluginDescriptor(name='XCplugin', description='XtreamCode Mod' + version, where=[PluginDescriptor.WHERE_AUTOSTART, PluginDescriptor.WHERE_SESSIONSTART], fnc=autostart, wakeupfnc=get_next_wakeup),PluginDescriptor(name='XCplugin Mod', description='XtreamCode Mod' + version, where=PluginDescriptor.WHERE_MENU, fnc=menu)]
  
def Plugins(**kwargs):
    result = [PluginDescriptor(name='XCplugin', description='XtreamCode Mod' + version, where=[PluginDescriptor.WHERE_AUTOSTART, PluginDescriptor.WHERE_SESSIONSTART], fnc=autostart, wakeupfnc=get_next_wakeup), PluginDescriptor(name='XCplugin Mod', description='XtreamCode Mod' + version, where=PluginDescriptor.WHERE_PLUGINMENU, icon="xcplugin.png", fnc=Start_iptv_player)]
    return result    
    if config.plugins.XCplugin.strtmain.value:
        result.append(mainDescriptor)
    return result      