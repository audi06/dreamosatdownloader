# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/XC-Multi/nVars.py
CHANNEL_NUMBER = [0, 8, 60, 40, 0]
CHANNEL_NAME = [90, 8, 1700, 40, 1]
FONT_0 = ('Regular', 20)
FONT_1 = ('Regular', 24)
FONT_2 = ('Regular', 30)
FONT_3 = ('Regular', 32)
BLOCK_H = 37
BLOCK_H1 = 50
NTIMEOUT = 30
VIDEO_FMT_PRIORITY_MAP = {
 '38': 1,
 '37': 2,
 '22': 3,
 '18': 4,
 '35': 5,
 '34': 6}