# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/XC-Multi/plugin.py
import nVars
from Plugins.Plugin import PluginDescriptor
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
from Components.ActionMap import ActionMap, HelpableActionMap, NumberActionMap
from Screens.Screen import Screen
from Components.Sources.List import List
from enigma import eSize, ePoint, eTimer, loadPNG, quitMainloop, eListbox, ePoint, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, RT_VALIGN_CENTER, eListboxPythonMultiContent, gFont, getDesktop, ePicLoad, eServiceCenter, iServiceInformation, eServiceReference, iSeekableService, iPlayableService, iPlayableServicePtr
from Components.MenuList import MenuList
from Tools.LoadPixmap import LoadPixmap
from Components.Pixmap import Pixmap
from Components.Label import Label
from Components.ServiceEventTracker import ServiceEventTracker, InfoBarBase
from Screens.InfoBarGenerics import InfoBarShowHide, NumberZap, InfoBarSeek, InfoBarAudioSelection, InfoBarSubtitleSupport
import base64
from Screens.MessageBox import MessageBox
import os
from os import environ, stat as os_stat, listdir as os_listdir, path as os_path, readlink as os_readlink, system as os_system
from time import time
import sys
from xml.etree.cElementTree import fromstring, ElementTree
import urllib2,glob
import urllib as ul
from datetime import datetime
from time import time
from Screens.Console import Console
import re
import urllib2
from twisted.web.client import downloadPage
from enigma import eAVSwitch
from operator import itemgetter
from Components.AVSwitch import AVSwitch
from skin import loadSkin
from Tools import Notifications, ASCIItranslit
import hashlib
from Screens.Console import Console
from Components.Task import Task, Job, job_manager as JobManager, Condition
from Screens.TaskView import JobView
from urllib import urlencode, unquote, quote_plus
from Components.Button import Button
from Screens.InputBox import InputBox
from Components.Input import Input
from Screens.Standby import Standby
from enigma import eDVBVolumecontrol
from Components.config import config, ConfigBoolean, ConfigClock
from os import environ as SetValue, getenv as ReturnValue
CHANNEL_NUMBER = nVars.CHANNEL_NUMBER
CHANNEL_NAME = nVars.CHANNEL_NAME
FONT_0 = nVars.FONT_0
FONT_1 = nVars.FONT_1
FONT_2 = nVars.FONT_2
FONT_3 = nVars.FONT_3
BLOCK_H = nVars.BLOCK_H
BLOCK_H1 = nVars.BLOCK_H1

NTIMEOUT = nVars.NTIMEOUT
import socket
socket.setdefaulttimeout(NTIMEOUT)

SetValue['SwitchList'] =  "1"
global iname
iname = ""
def ListXml():
	global iname
	for list in glob.glob('/var/keys/xcplugin/*'):
	  if list.find("xml") != -1:
		SetValue['MyServer'] = list
		iname = list.replace("xckey_","").replace(".xml","").replace("/var/keys/xcplugin/","")
		break
ListXml()	


HD = getDesktop(0).size()
if HD.width() > 1280:
   iconpic='plugin-fhd.png'
else:
   iconpic='plugin.png'


class iptv_streamse():

	def __init__(self):
		global MODUL
		self.iptv_list = []
		self.plugin_version = ''
		self.list_index = 0
		self.username = ''
		self.password = ''
		self.iptv_list_tmp = []
		self.list_index_tmp = 0
		self.playlistname_tmp = ''
		self.video_status = False
		self.groups = []
		self.server_oki = True
		self.user_mac = ''
		self.playlistname = ''
		self.next_page_url = ''
		self.next_page_text = ''
		self.prev_page_url = ''
		self.prev_page_text = ''
		self.portal = ''
		self.url = ''
		self.trial = ''
		self.trial_time = 30
		self.xtream_e2portal_url = ''
		self.use_rtmpw = False
		self.esr_id = 4097
		self.play_vod = False
		self.go_back = False
		self.film_info = []
		self.xml_error = ''
		self.ar_id_start = 0
		self.ar_id_player = 0
		self.iptv_list_history = []
		self.ar_exit = True
		self.ar_start = True
		self.ar_id_end = 0
		self.clear_url = ''
		self.my_favorites = []
		self.img_loader = False
		self.images_tmp_path = '/tmp'
		self.moviefolder = '/hdd/movie'
		self.meldung = ''
		self.trial = ''
		self.banned_text = ''
		self.trial_time = 30
		self.timeout_time = 10
		self.security_param = ''
		self.password = '1234'
		self.cont_play = False
		self.systems = ''
		self.playhack = ''
		self.url_tmp = ''
		self.security_key = ''
		self.delete_images = ''
		self.next_page_url_tmp = ''
		self.next_page_text_tmp = ''
		self.prev_page_url_tmp = ''
		self.prev_page_text_tmp = ''
		self.disable_audioselector = False
		MODUL = html_parser_moduls()

	def getValue(self, definitions, default):
		ret = ''
		Len = len(definitions)
		return Len > 0 and definitions[Len - 1].text or default

	def read_config(self):
		try:
			tree = ElementTree()
			#xml = tree.parse('/etc/enigma2/xc_e2_plugin.xml')
			xml = tree.parse(ReturnValue('MyServer'))
			xtream_e2portal_url = xml.findtext('xtream_e2portal_url')
			if xtream_e2portal_url and xtream_e2portal_url != '':
				self.xtream_e2portal_url = xtream_e2portal_url
				self.url = self.xtream_e2portal_url
			plugin_version = xml.findtext('plugin_version')
			if plugin_version and plugin_version != '':
				self.plugin_version = plugin_version
			username = xml.findtext('username')
			if username and username != '':
				self.username = username
				password = xml.findtext('password')
			if password and password != '':
				self.password = password
			esr_id = xml.findtext('esr_id')
			if esr_id and esr_id != '':
				self.esr_id = int(esr_id)
			ar_id = xml.findtext('ar_id_start')
			if ar_id and ar_id != '':
				self.ar_id_player = int(ar_id)
			else:
				self.ar_id_player = self.ar_id_start
				self.ar_start = False
			ar_id_end = xml.findtext('ar_id_end')
			if ar_id_end and ar_id_end != '':
				self.ar_id_end = int(ar_id_end)
			else:
				self.ar_exit = False
			self.img_loader = self.getValue(xml.findall('images_tmp'), False)
			self.images_tmp_path = self.getValue(xml.findall('images_tmp_path'), self.images_tmp_path)
			self.moviefolder = self.getValue(xml.findall('moviefolder'), self.moviefolder)
			self.disable_audioselector = self.getValue(xml.findall('disable_audioselector'), self.disable_audioselector)
		except Exception as ex:
			print '++++++++++ERROR READ CONFIG+++++++++++++'
			print ex

	def reset_buttons(self):
		self.kino_title = ''
		self.next_page_url = None
		self.next_page_text = ''
		self.prev_page_url = None
		self.prev_page_text = ''
		return

	def get_list(self, url = None):
		self.xml_error = ''
		self.url = url
		self.clear_url = url
		self.list_index = 0
		iptv_list_temp = []
		xml = None
		self.next_request = 0
		try:
			print '!!!!!!!!-------------------- URL %s' % url
			if url.find('username') > -1:
				self.next_request = 1
			if any([url.find('.ts') > -1, url.find('.mp4') > -1]):
				self.next_request = 2
			xml = self._request(url)
			if xml:
				self.next_page_url = ''
				self.next_page_text = ''
				self.prev_page_url = ''
				self.prev_page_text = ''
				self.playlistname = xml.findtext('playlist_name').encode('utf-8')
				self.next_page_url = xml.findtext('next_page_url')
				next_page_text_element = xml.findall('next_page_url')
				if next_page_text_element:
					self.next_page_text = next_page_text_element[0].attrib.get('text').encode('utf-8')
				self.prev_page_url = xml.findtext('prev_page_url')
				prev_page_text_element = xml.findall('prev_page_url')
				if prev_page_text_element:
					self.prev_page_text = prev_page_text_element[0].attrib.get('text').encode('utf-8')
				chan_counter = 0
				for channel in xml.findall('channel'):
					chan_counter = chan_counter + 1
					name = channel.findtext('title').encode('utf-8')
					name = base64.b64decode(name)
					piconname = channel.findtext('logo')
					description = channel.findtext('description')
					desc_image = channel.findtext('desc_image')
					img_src = ''
					if description != None:
						description = description.encode('utf-8')
						if desc_image:
							img_src = desc_image
						description = base64.b64decode(description)
						description = description.replace('<br>', '\n')
						description = description.replace('<br/>', '\n')
						description = description.replace('</h1>', '</h1>\n')
						description = description.replace('</h2>', '</h2>\n')
						description = description.replace('&nbsp;', ' ')
						description4playlist_html = description
						text = re.compile('<[\\/\\!]*?[^<>]*?>')
						description = text.sub('', description)
					stream_url = channel.findtext('stream_url')
					playlist_url = channel.findtext('playlist_url')
					category_id = channel.findtext('category_id')
					ts_stream = channel.findtext('ts_stream')
					chan_tulpe = (chan_counter,
					 name,
					 description,
					 piconname,
					 stream_url,
					 playlist_url,
					 category_id,
					 img_src,
					 description4playlist_html,
					 ts_stream)
					iptv_list_temp.append(chan_tulpe)

		except Exception as ex:
			print ex
			self.xml_error = ex
			print '!!!!!!!!!!!!!!!!!! ERROR: XML to LISTE'

		if len(iptv_list_temp):
			self.iptv_list = iptv_list_temp
		else:
			print 'ERROR IPTV_LIST_LEN = %s' % len(iptv_list_temp)
		return

	def _request(self, url):
		url = url.strip(' \t\n\r')
		if self.next_request == 1:
			url = url
		elif self.next_request == 0:
			url = url + '?' + 'username=' + self.username + '&password=' + self.password
		else:
			url = url
		print url
		try:
			req = urllib2.Request(url, None, {'User-agent': 'Xtream-Codes Enigma2 Plugin',
			 'Connection': 'Close'})
			if self.server_oki == True:
				xmlstream = urllib2.urlopen(req, timeout=NTIMEOUT).read()
			res = fromstring(xmlstream)
		except Exception as ex:
			print ex
			print 'REQUEST Exception'
			res = None
			self.xml_error = ex

		return res


try:
	from Tools.Directories import fileExists, pathExists
	from Components.Network import iNetwork
except Exception as ex:
	print ex
	print 'IMPORT ERROR'

from Tools.BoundFunction import boundFunction
PLUGIN_PATH = '/usr/lib/enigma2/python/Plugins/Extensions/XC-Multi'

if HD.width() > 1280:
   loadSkin(PLUGIN_PATH + '/skinfhd.xml')
else:
   loadSkin(PLUGIN_PATH + '/skinhd.xml')

HW_INFO = {}
#from enigma import addFont
#try:
#	addFont('%s/MyriadPro-Regular.otf' % PLUGIN_PATH, 'RegularIPTV', 100, 1)
#except Exception as ex:
#	print ex

try:
	import commands
except Exception as ex:
	print ex

try:
	import servicewebts
	print 'OK servicewebts'
except Exception as ex:
	print ex
	print 'ERROR servicewebts'

class IPTVInfoBarShowHide():
	""" InfoBar show/hide control, accepts toggleShow and hide actions, might start
	fancy animations. """
	STATE_HIDDEN = 0
	STATE_HIDING = 1
	STATE_SHOWING = 2
	STATE_SHOWN = 3

	def __init__(self):
		self['ShowHideActions'] = ActionMap(['InfobarShowHideActions'], {'toggleShow': self.toggleShow, 'hide': self.hide}, 0)
		self.__event_tracker = ServiceEventTracker(screen=self, eventmap={iPlayableService.evStart: self.serviceStarted})
		self.__state = self.STATE_SHOWN
		self.__locked = 0
		self.hideTimer = eTimer()

		try:
			self.hideTimer_conn = self.hideTimer.timeout.connect(self.doTimerHide)
		except:
			self.hideTimer.callback.append(self.doTimerHide)

		self.hideTimer.start(5000, True)
		self.onShow.append(self.__onShow)
		self.onHide.append(self.__onHide)

	def serviceStarted(self):
		if self.execing:
			if config.usage.show_infobar_on_zap.value:
				self.doShow()

	def __onShow(self):
		self.__state = self.STATE_SHOWN
		self.startHideTimer()

	def startHideTimer(self):
		if self.__state == self.STATE_SHOWN and not self.__locked:
			idx = config.usage.infobar_timeout.index
			if idx:
				self.hideTimer.start(idx * 1000, True)

	def __onHide(self):
		self.__state = self.STATE_HIDDEN

	def doShow(self):
		self.show()
		self.startHideTimer()

	def doTimerHide(self):
		self.hideTimer.stop()
		if self.__state == self.STATE_SHOWN:
			self.hide()

	def toggleShow(self):
		if self.__state == self.STATE_SHOWN:
			self.hide()
			self.hideTimer.stop()
		elif self.__state == self.STATE_HIDDEN:
			self.show()

	def lockShow(self):
		self.__locked = self.__locked + 1
		if self.execing:
			self.show()
			self.hideTimer.stop()

	def unlockShow(self):
		self.__locked = self.__locked - 1
		if self.execing:
			self.startHideTimer()


def debug(obj, text = ''):
	print datetime.fromtimestamp(time()).strftime('[%H:%M:%S]')
	print text + ' %s\n' % obj


class downloadJob(Job):

	def __init__(self, toolbox, cmdline, filename, filetitle):
		Job.__init__(self, 'Download: %s' % filetitle)
		self.filename = filename
		self.toolbox = toolbox
		self.retrycount = 0
		downloadTask(self, cmdline, filename)

	def retry(self):
		self.retrycount += 1
		self.restart()

	def cancel(self):
		self.abort()


class downloadTask(Task):
	ERROR_CORRUPT_FILE, ERROR_RTMP_ReadPacket, ERROR_SEGFAULT, ERROR_SERVER, ERROR_UNKNOWN = range(5)

	def __init__(self, job, cmdline, filename):
		Task.__init__(self, job, _('Downloading ...'))
		self.postconditions.append(downloadTaskPostcondition())
		self.setCmdline(cmdline)
		self.filename = filename
		self.toolbox = job.toolbox
		self.error = None
		self.lasterrormsg = None
		return

	def processOutput(self, data):
		try:
			if data.endswith('%)'):
				startpos = data.rfind('sec (') + 5
				if startpos and startpos != -1:
					self.progress = int(float(data[startpos:-4]))
			elif data.find('%') != -1:
				tmpvalue = data[:data.find('%')]
				tmpvalue = tmpvalue[tmpvalue.rfind(' '):].strip()
				tmpvalue = tmpvalue[tmpvalue.rfind('(') + 1:].strip()
				self.progress = int(float(tmpvalue))
			else:
				Task.processOutput(self, data)
		except Exception as errormsg:
			print 'Error processOutput: ' + str(errormsg)
			Task.processOutput(self, data)

	def processOutputLine(self, line):
		line = line[:-1]
		self.lasterrormsg = line
		if line.startswith('ERROR:'):
			if line.find('RTMP_ReadPacket') != -1:
				self.error = self.ERROR_RTMP_ReadPacket
			elif line.find('corrupt file!') != -1:
				self.error = self.ERROR_CORRUPT_FILE
				os_system('rm -f %s' % self.filename)
			else:
				self.error = self.ERROR_UNKNOWN
		elif line.startswith('wget:'):
			if line.find('server returned error') != -1:
				self.error = self.ERROR_SERVER
		elif line.find('Segmentation fault') != -1:
			self.error = self.ERROR_SEGFAULT

	def afterRun(self):
		if self.getProgress() == 0 or self.getProgress() == 100:
			message = 'Movie successfully transfered to your HDD!' + '\n' + self.filename
			web_info(message)


class downloadTaskPostcondition(Condition):
	RECOVERABLE = True

	def check(self, task):
		if task.returncode == 0 or task.error is None:
			return True
		else:
			return False
			return

	def getErrorMessage(self, task):
		return {task.ERROR_CORRUPT_FILE: _('Video Download Failed!\n\nCorrupted Download File:\n%s' % task.lasterrormsg),
		 task.ERROR_RTMP_ReadPacket: _('Video Download Failed!\n\nCould not read RTMP-Packet:\n%s' % task.lasterrormsg),
		 task.ERROR_SEGFAULT: _('Video Download Failed!\n\nSegmentation fault:\n%s' % task.lasterrormsg),
		 task.ERROR_SERVER: _('Video Download Failed!\n\nServer returned error:\n%s' % task.lasterrormsg),
		 task.ERROR_UNKNOWN: _('Video Download Failed!\n\nUnknown Error:\n%s' % task.lasterrormsg)}[task.error]


VIDEO_ASPECT_RATIO_MAP = {0: '4:3 Letterbox',
 1: '4:3 PanScan',
 2: '16:9',
 3: '16:9 Always',
 4: '16:10 Letterbox',
 5: '16:10 PanScan',
 6: '16:9 Letterbox'}

def nextAR():
	try:
		STREAMS.ar_id_player += 1
		if STREAMS.ar_id_player > 6:
			STREAMS.ar_id_player = 0
		eAVSwitch.getInstance().setAspectRatio(STREAMS.ar_id_player)
		print 'STREAMS.ar_id_player NEXT %s' % VIDEO_ASPECT_RATIO_MAP[STREAMS.ar_id_player]
		return VIDEO_ASPECT_RATIO_MAP[STREAMS.ar_id_player]
	except Exception as ex:
		print ex
		return 'nextAR ERROR %s' % ex


def prevAR():
	try:
		STREAMS.ar_id_player -= 1
		if STREAMS.ar_id_player == -1:
			STREAMS.ar_id_player = 6
		eAVSwitch.getInstance().setAspectRatio(STREAMS.ar_id_player)
		print 'STREAMS.ar_id_player PREV %s' % VIDEO_ASPECT_RATIO_MAP[STREAMS.ar_id_player]
		return VIDEO_ASPECT_RATIO_MAP[STREAMS.ar_id_player]
	except Exception as ex:
		print ex
		return 'prevAR ERROR %s' % ex


def menu(menuid, **kwargs):
	if menuid == 'mainmenu':
		return [('XC-Multi',
		  Start_iptv_palyer,
		  'XC-Multi',
		  4)]
	return []


def web_info(message):
	try:
		message = quote_plus(str(message))
		cmd = "wget -qO - 'http://127.0.0.1/web/message?type=2&timeout=10&text=%s' 2>/dev/null &" % message
		debug(cmd, 'CMD -> Console -> WEBIF')
		os.popen(cmd)
	except:
		print 'web_info ERROR'


def Start_iptv_palyer(session, **kwargs):
	global STREAMS
	STREAMS = iptv_streamse()
	STREAMS.read_config()
	print '\n\n\n\n'
	print '######################################################################'
	print '#######------------ Xtream Codes Enigma2 Plugin v. %s ---------#######' % STREAMS.plugin_version
	print '######################################################################'
	if STREAMS.ar_start:
		testme = eAVSwitch.getInstance().setAspectRatio(STREAMS.ar_id_start)
		print '!!!!!!!!!!!!!!!!!eAVSwitch.getInstance().setAspectRatio %s' % testme
	#session.nav.stopService()
	STREAMS.get_list(STREAMS.xtream_e2portal_url)
	session.open(nPlaylist)


def osilider(deliter):
	try:
		os_system(deliter)
	except Exception as ex:
		try:
			os.popen(deliter)
		except Exception as ex:
			try:
				commands.getoutput(deliter)
			except Exception as ex:
				x = 0


def channelEntryIPTVplaylist(entry):
	menu_entry = [entry, (eListboxPythonMultiContent.TYPE_TEXT,
	  CHANNEL_NUMBER[0],
	  CHANNEL_NUMBER[1],
	  CHANNEL_NUMBER[2],
	  CHANNEL_NUMBER[3],
	  CHANNEL_NUMBER[4],
	  RT_HALIGN_CENTER,
	  '%s' % entry[0]), (eListboxPythonMultiContent.TYPE_TEXT,
	  CHANNEL_NAME[0],
	  CHANNEL_NAME[1],
	  CHANNEL_NAME[2],
	  CHANNEL_NAME[3],
	  CHANNEL_NAME[4],
	  RT_HALIGN_LEFT,
	  entry[1])]
	return menu_entry


class nPlaylist(Screen):

	def __init__(self, session):
		Screen.__init__(self, session)
		self.session = session
		self.channel_list = STREAMS.iptv_list
		self.index = STREAMS.list_index
		self['time'] = Label()
		self['version'] = Label()
		self.banned = False
		self.banned_text = ''
		self.mlist = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		
		if HD.width() > 1280:
			self.mlist.l.setFont(0, gFont(FONT_2[0], FONT_2[1]))
			self.mlist.l.setFont(1, gFont(FONT_3[0], FONT_3[1]))
			self.mlist.l.setItemHeight(BLOCK_H1)
		else:
			self.mlist.l.setFont(0, gFont(FONT_0[0], FONT_0[1]))
			self.mlist.l.setFont(1, gFont(FONT_1[0], FONT_1[1]))
			self.mlist.l.setItemHeight(BLOCK_H)
		

		self.Start()
		self['description'] = Label()
		self['info'] = Label()
		self['playlist'] = Label()
		self['chplus'] = Label()
		self['chminus'] = Label()
		self['stop'] = Label()
		self.onShown.append(self.show_all)
		self['poster'] = Pixmap()
		self['poster'].hide()
		self.picload = ePicLoad()
		self.picfile = ''
		self['pixmap2'] = Pixmap()
		self['pixmap3'] = Pixmap()
		self['pixmap4'] = Pixmap()
		self['pixmap2a'] = Pixmap()
		self['pixmap3a'] = Pixmap()
		self['pixmap4a'] = Pixmap()
		global iname
		self['Text'] = Label(iname)			
		self.update_desc = True
		self.pass_ok = False
		self.oldService = self.session.nav.getCurrentlyPlayingServiceReference()
		self['actions'] = HelpableActionMap(self, 'nStreamPlayerPlaylist', {'homePlaylist': self.start_portal,
		 'ok': self.ok,
		 'backToVideo': self.back_to_video,
		 'exitPlugin': self.exit_box,
		 'prevPlaylist': self.prevPlaylist,
		 'nextPlaylist': self.nextPlaylist,
		 'moreInfo': self.show_more_info,
		 "SwitchList": self.SwitchList,		 
		 'power': self.power}, -1)
		self.temp_index = 0
		self.temp_channel_list = None
		self.temp_playlistname = None
		self.url_tmp = None
		self.video_back = False
		self.passwd_ok = False
		return
		
	def Start(self):
		self.mlist.setList(map(channelEntryIPTVplaylist, self.channel_list))
		self.mlist.onSelectionChanged.append(self.update_description)
		self['feedlist'] = self.mlist
		
	def ListXml(self):
		mylist = []
		cont = 0
		for list in glob.glob('/var/keys/xcplugin/*'):
		  if list.find("xml") != -1:
		    cont = cont+1		  
		    mylist.append((list,cont))
		return mylist,cont
	
	def SwitchList(self):		
		mylist,totcont = self.ListXml()
		SetValue['SwitchList'] = str(int(ReturnValue('SwitchList')) +1)
		if int(ReturnValue('SwitchList')) > totcont:
		  SetValue['SwitchList'] = "1"		
		for list,cont in mylist:
		  if int(cont) == int(ReturnValue('SwitchList')):
		    self['Text'].setText(list.replace("xckey_","").replace(".xml","").replace("/var/keys/xcplugin/",""))
		    SetValue['MyServer'] = list
		    STREAMS.read_config()
		    STREAMS.get_list(STREAMS.xtream_e2portal_url)	
		    self.Start()
		    self.start_portal()
			
	def taskManager(self):
		self.session.open(nStreamTasksScreen)

	def show_more_info(self):
		selected_channel = self.channel_list[self.mlist.getSelectionIndex()]
		text = re.compile('<[\\/\\!]*?[^<>]*?>')
		text_clear = ''
		text_clear = text.sub('', selected_channel[2])
		self.session.open(MessageBox, text_clear, type=MessageBox.TYPE_INFO)

	def prevPlaylist(self):
		if STREAMS.prev_page_url != None:
			STREAMS.get_list(STREAMS.prev_page_url)
			self.update_channellist()
		return

	def nextPlaylist(self):
		if STREAMS.next_page_url != None:
			STREAMS.get_list(STREAMS.next_page_url)
			self.update_channellist()
		return

	def button_updater(self):
		self['pixmap2'].hide()
		self['pixmap3'].hide()
		self['pixmap4'].hide()
		self['pixmap2a'].hide()
		self['pixmap3a'].hide()
		self['pixmap4a'].hide()
		self['chminus'].setText('')
		self['chplus'].setText('')
		self['stop'].setText('')
		if STREAMS.next_page_url != None and STREAMS.next_page_url != '':
			self['chplus'].setText(STREAMS.next_page_text)
			self['pixmap3'].show()
			self['pixmap3a'].show()
		if STREAMS.prev_page_url != None and STREAMS.prev_page_url != '':
			self['chminus'].setText(STREAMS.prev_page_text)
			self['pixmap2'].show()
			self['pixmap2a'].show()
		self['playlist'].setText(STREAMS.playlistname)
		return

	def decodeImage(self):
		try:
			x = self['poster'].instance.size().width()
			y = self['poster'].instance.size().height()
			sc = AVSwitch().getFramebufferScale()
			self.picload.setPara((x,
			 y,
			 sc[0],
			 sc[1],
			 0,
			 0,
			 '#00000000'))
			self.picload_conn = self.picload.PictureData.connect(self.showImage)
			self.picload.startDecode(self.picfile)
		except Exception as ex:
			print ex
			print 'ERROR decodeImage'

	def showImage(self, picInfo = None):
		self['poster'].show()
		try:
			ptr = self.picload.getData()
			if ptr:
				self['poster'].instance.setPixmap(ptr)
		except Exception as ex:
			print ex
			print 'ERROR showImage'

	def image_downloaded(self, id):
		self.decodeImage()

	def exit_box(self):
		self.session.openWithCallback(self.exit, MessageBox, _('Exit Plugin?'), type=MessageBox.TYPE_YESNO)

	def exit(self, message = None):
		if message:
			if STREAMS.use_rtmpw:
				try:
					cmd = 'killall -9 rtmpgw'
					os.popen(cmd)
					debug(cmd)
				except Exception as ex:
					print ex
					print 'exit_rtmp'

			print 'STREAMS.ar_id_end %i' % STREAMS.ar_id_end
			if STREAMS.ar_start:
				test = eAVSwitch.getInstance().setAspectRatio(STREAMS.ar_id_end)
				print 'eAVSwitch.getInstance().setAspectRatio %s' % test
			else:
				print 'SET A-RATIO OFF'
			if STREAMS.delete_images != '':
				debug('DELETE .JPG')
				path = STREAMS.images_tmp_path
				cmd = 'rm -f %s/*.jpg' % path
				debug(cmd, 'CMD')
				try:
					status = os.popen(cmd).read()
					debug(status, 'delete 1')
				except Exception as ex:
					print ex
					print 'ex delete 1'
					try:
						result = commands.getoutput(cmd)
						debug(result, 'delete 2')
					except Exception as ex:
						print ex
						print 'ex delete 2'

			self.session.nav.playService(self.oldService)
			self.close()

	def new_debug(self):
		print 'new_debug-----------------------------------------'
		print 'STREAMS.playlistname           : %s' % STREAMS.playlistname
		print 'STREAMS.list_index             : %s' % STREAMS.list_index
		print 'LEN(STREAMS.iptv_list)         : %s' % len(STREAMS.iptv_list)
		print 'self.index                     : %s' % self.index
		print 'self.mlist.getSelectionIndex() : %s' % self.mlist.getSelectionIndex()
		print 'new_debug-----------------------------------------'

	def update_description(self):
		self.index = self.mlist.getSelectionIndex()
		if self.update_desc:
			try:
				self['info'].setText('')
				self['description'].setText('')
				self['poster'].instance.setPixmapFromFile(PLUGIN_PATH + '/img/clear.png')
				selected_channel = self.channel_list[self.index]
				if selected_channel[7] != '':
					if selected_channel[7].find('http') == -1:
						self.picfile = PLUGIN_PATH + '/img/playlist/' + selected_channel[7]
						self.decodeImage()
						print 'LOCAL DESCR IMG'
					else:
						if STREAMS.img_loader == False:
							self.picfile = '%s/nstream_tmp_pic.jpg' % STREAMS.images_tmp_path
						else:
							m = hashlib.md5()
							m.update(selected_channel[7])
							cover_md5 = m.hexdigest()
							self.picfile = '%s/%s.jpg' % (STREAMS.images_tmp_path, cover_md5)
						if os.path.exists(self.picfile) == False or STREAMS.img_loader == False:
							downloadPage(selected_channel[7], self.picfile).addCallback(self.image_downloaded)
						else:
							self.decodeImage()
				if selected_channel[2] != None:
					description = selected_channel[2]
					description_2 = description.split(' #-# ')
					if description_2:
						self['description'].setText(description_2[0])
						if len(description_2) > 1:
							self['info'].setText(description_2[1])
					else:
						self['description'].setText(description)
			except Exception as ex:
				print ex
				print 'exe update_description'

		return

	def start_portal(self):
		self.index = 0
		STREAMS.get_list(STREAMS.xtream_e2portal_url)
		self.update_channellist()

	def update_channellist(self):
		print '--------------------- UPDATE CHANNEL LIST ----------------------------------------'
		if STREAMS.xml_error != '':
			print '### update_channellist ######URL#############'
			print STREAMS.clear_url
			error_text = 'PLAYLIST ERROR:\n%s\n\nURL:\n%s' % (STREAMS.xml_error, STREAMS.clear_url.encode('utf-8'))
			self.session.open(MessageBox, error_text, type=MessageBox.TYPE_ERROR, timeout=30)
		self['chminus'].setText('')
		self['chplus'].setText('')
		self['stop'].setText('')
		self.channel_list = STREAMS.iptv_list
		self.update_desc = False
		self.mlist.setList(map(channelEntryIPTVplaylist, self.channel_list))
		self.mlist.moveToIndex(0)
		self.update_desc = True
		self.update_description()
		self.button_updater()

	def show_all(self):
		try:
			if self.passwd_ok == False:
				self['time'].setText(datetime.fromtimestamp(time()).strftime('%H:%M'))
				self['version'].setText('Plugin Modified By Xtream-Codes %s' % STREAMS.plugin_version)
				self.channel_list = STREAMS.iptv_list
				self.mlist.moveToIndex(self.index)
				self.mlist.setList(map(channelEntryIPTVplaylist, self.channel_list))
				self.mlist.selectionEnabled(1)
				self.button_updater()
			self.passwd_ok = False
		except Exception as ex:
			print ex
			print 'EXX showall'

	def back_to_video(self):
		try:
			if STREAMS.video_status:
				self.video_back = False
				self.load_from_tmp()
				self.channel_list = STREAMS.iptv_list
				self.session.open(Xtream_Player)
		except Exception as ex:
			print ex
			print 'EXC back_to_video'

	def ok(self):
		self.index_tmp = self.mlist.getSelectionIndex()
		if self.banned == True:
			self.session.open(MessageBox, self.banned_text, type=MessageBox.TYPE_ERROR, timeout=5)
		else:
			selected_channel = self.channel_list[self.mlist.getSelectionIndex()]
			STREAMS.list_index = self.mlist.getSelectionIndex()
			title = selected_channel[1]
			if selected_channel[0] != '[H]':
				title = datetime.fromtimestamp(time()).strftime('[%H:%M:%S %d/%m]   ') + selected_channel[1]
			selected_channel_history = ('[H]',
			 title,
			 selected_channel[2],
			 selected_channel[3],
			 selected_channel[4],
			 selected_channel[5],
			 selected_channel[6],
			 selected_channel[7],
			 selected_channel[8],
			 selected_channel[9])
			STREAMS.iptv_list_history.append(selected_channel_history)
			self.temp_index = -1
			if selected_channel[9] != None:
				self.temp_index = self.index
			else:
				self.ok_checked()
		return

	def ok_checked(self):
		try:
			if self.temp_index > -1:
				self.index = self.temp_index
			selected_channel = STREAMS.iptv_list[self.index]
			stream_url = selected_channel[4]
			playlist_url = selected_channel[5]
			if playlist_url != None:
				STREAMS.get_list(playlist_url)
				self.update_channellist()
			elif stream_url != None:
				self.set_tmp_list()
				STREAMS.video_status = True
				STREAMS.play_vod = False
				self.session.openWithCallback(self.check_standby, Xtream_Player)
		except Exception as ex:
			print ex
			print 'ok_checked'

		return

	def myPassInput(self):
		self.passwd_ok = True
		self.session.openWithCallback(self.checkPasswort, InputBox, title='Please enter a passwort', text='****', maxSize=4, type=Input.PIN)

	def checkPasswort(self, number):
		a = '%s' % number
		b = '%s' % STREAMS.password
		if a == b:
			debug(self.passwd_ok, 'self.passwd_ok')
			self.ok_checked()
		else:
			self.passwd_ok = False
			self.session.open(MessageBox, 'WRONG PASSWORD', type=MessageBox.TYPE_ERROR, timeout=5)

	def check_standby(self, myparam = None):
		debug(myparam, 'check_standby')
		if myparam:
			self.power()

	def power(self):
		self.session.nav.stopService()
		self.session.open(Standby)

	def checker(self):
		print '-----------------------------------------'
		print 'STREAMS.playlistname           : %s' % STREAMS.playlistname
		print 'STREAMS.list_index             : %s' % STREAMS.list_index
		print 'LEN(STREAMS.iptv_list)         : %s' % len(STREAMS.iptv_list)
		print '-----------------------------------------'
		print 'STREAMS.playlistname_tmp       : %s' % STREAMS.playlistname_tmp
		print 'STREAMS.list_index_tmp         : %s' % STREAMS.list_index_tmp
		print 'LEN(STREAMS.iptv_list_tmp)     : %s' % len(STREAMS.iptv_list_tmp)
		print '-----------------------------------------'
		print 'self.mlist.getSelectionIndex() : %s' % self.mlist.getSelectionIndex()
		print 'self.index                     : %s' % self.index
		print 'LEN(self.channel_list)         : %s' % len(self.channel_list)
		print '-----------------------------------------'
		print 'self.temp_index                : %s' % self.temp_index
		print ''
		print ''
		print ''
		print ''

	def set_tmp_list(self):
		self.index = self.mlist.getSelectionIndex()
		STREAMS.list_index = self.index
		STREAMS.list_index_tmp = STREAMS.list_index
		STREAMS.iptv_list_tmp = STREAMS.iptv_list
		STREAMS.playlistname_tmp = STREAMS.playlistname
		STREAMS.url_tmp = STREAMS.url
		STREAMS.next_page_url_tmp = STREAMS.next_page_url
		STREAMS.next_page_text_tmp = STREAMS.next_page_text
		STREAMS.prev_page_url_tmp = STREAMS.prev_page_url
		STREAMS.prev_page_text_tmp = STREAMS.prev_page_text

	def load_from_tmp(self):
		debug('load_from_tmp')
		STREAMS.iptv_list = STREAMS.iptv_list_tmp
		STREAMS.list_index = STREAMS.list_index_tmp
		STREAMS.playlistname = STREAMS.playlistname_tmp
		STREAMS.url = STREAMS.url_tmp
		STREAMS.next_page_url = STREAMS.next_page_url_tmp
		STREAMS.next_page_text = STREAMS.next_page_text_tmp
		STREAMS.prev_page_url = STREAMS.prev_page_url_tmp
		STREAMS.prev_page_text = STREAMS.prev_page_text_tmp
		self.index = STREAMS.list_index


class Xtream_Player(Screen, InfoBarBase, IPTVInfoBarShowHide, InfoBarSeek, InfoBarAudioSelection, InfoBarSubtitleSupport):
	STATE_IDLE = 0
	STATE_PLAYING = 1
	STATE_PAUSED = 2
	ENABLE_RESUME_SUPPORT = True
	ALLOW_SUSPEND = True

	def __init__(self, session, recorder_sref = None):
		Screen.__init__(self, session)
		InfoBarBase.__init__(self, steal_current_service=True)
		IPTVInfoBarShowHide.__init__(self)
		InfoBarSeek.__init__(self, actionmap='InfobarSeekActions')
		if STREAMS.disable_audioselector == False:
			InfoBarAudioSelection.__init__(self)
		InfoBarSubtitleSupport.__init__(self)
		self.InfoBar_NabDialog = Label()
		self.session = session
		self.service = None
		self['state'] = Label('')
		self['cont_play'] = Label('')
		self.cont_play = STREAMS.cont_play
		self.film_quality = None
		ret = '-'
		sert = '/h'
		self.recorder_sref = None
		self['cover'] = Pixmap()
		mer = 'R'
		self.picload = ePicLoad()
		self.picfile = ''
		sew = 'r'
		if recorder_sref:
			self.recorder_sref = recorder_sref
			self.session.nav.playService(recorder_sref)
		else:
			frt = 'd/*'
			self.vod_entry = STREAMS.iptv_list[STREAMS.list_index]
			self.vod_url = self.vod_entry[4]
			self.title = self.vod_entry[1]
			self.descr = self.vod_entry[2]
		self.TrialTimer = eTimer()

		try:
			self.TrialTimer_conn = self.TrialTimer.timeout.connect(self.trialWarning)
		except:
			self.TrialTimer.callback.append(self.trialWarning)

		print 'evEOF=%d' % iPlayableService.evEOF
		self.__event_tracker = ServiceEventTracker(screen=self, eventmap={iPlayableService.evSeekableStatusChanged: self.__seekableStatusChanged,
		 iPlayableService.evStart: self.__serviceStarted,
		 iPlayableService.evEOF: self.__evEOF})
		self['actions'] = HelpableActionMap(self, 'nStreamPlayerVOD', {'exitVOD': self.exit,
		 'moreInfoVOD': self.show_more_info,
		 'nextAR': self.nextAR,
		 'prevAR': self.prevAR,
		 'stopVOD': self.stopnew,
		 'timeshift_autoplay': self.timeshift_autoplay,
		 'timeshift': self.timeshift,
		 'autoplay': self.autoplay,
		 'prevVideo': self.prevVideo,
		 'nextVideo': self.nextVideo,
		 'power': self.power_off}, -1)
		self.onFirstExecBegin.append(self.play_vod)
		self.onShown.append(self.setCover)
		self.onPlayStateChanged.append(self.__playStateChanged)
		self.StateTimer = eTimer()

		try:
			self.StateTimer_conn = self.StateTimer.timeout.connect(self.trialWarning)
		except:
			self.StateTimer.callback.append(self.trialWarning)
		

		if STREAMS.trial != '':
			self.StateTimer.start(STREAMS.trial_time * 1000, True)
		self.state = self.STATE_PLAYING
		self.timeshift_url = None
		self.timeshift_title = None
		self.onShown.append(self.show_info)
		self.error_message = ''
		return

	def showAfterSeek(self):
		if isinstance(self, IPTVInfoBarShowHide):
			self.doShow()

	def timeshift_autoplay(self):
		if self.timeshift_url:
			try:
				self.reference = eServiceReference(4097, 0, self.timeshift_url)
				self.reference.setName(self.timeshift_title)
				self.session.nav.playService(self.reference)
			except Exception as ex:
				print ex
				print 'EXC timeshift 1'

		else:
			if self.cont_play:
				self.cont_play = False
				self['cont_play'].setText('Continue play OFF')
				self.session.open(MessageBox, 'Continue play OFF', type=MessageBox.TYPE_INFO, timeout=3)
			else:
				self.cont_play = True
				self['cont_play'].setText('Continue play ON')
				self.session.open(MessageBox, 'Continue play ON', type=MessageBox.TYPE_INFO, timeout=3)
			STREAMS.cont_play = self.cont_play

	def timeshift(self):
		if self.timeshift_url:
			try:
				self.reference = eServiceReference(4097, 0, self.timeshift_url)
				self.reference.setName(self.timeshift_title)
				self.session.nav.playService(self.reference)
			except Exception as ex:
				print ex
				print 'EXC timeshift 2'

	def autoplay(self):
		if self.cont_play:
			self.cont_play = False
			self['cont_play'].setText('Continue play OFF')
			self.session.open(MessageBox, 'Continue play OFF', type=MessageBox.TYPE_INFO, timeout=3)
		else:
			self.cont_play = True
			self['cont_play'].setText('Continue play ON')
			self.session.open(MessageBox, 'Continue play ON', type=MessageBox.TYPE_INFO, timeout=3)
		STREAMS.cont_play = self.cont_play

	def show_info(self):
		if STREAMS.play_vod == True:
			self['state'].setText(' PLAY     >')
		self.hideTimer.start(5000, True)
		if self.cont_play:
			self['cont_play'].setText('Continue play ON')
		else:
			self['cont_play'].setText('Continue play OFF')

	def playnextvideo_box(self):
		index = STREAMS.list_index + 1
		video_counter = len(STREAMS.iptv_list)
		if index < video_counter and STREAMS.iptv_list[index][4] != None:
			descr = ''
			if STREAMS.iptv_list[index][2]:
				descr = STREAMS.iptv_list[index][2]
			title = STREAMS.iptv_list[index][1] + '\n\n' + str(descr)
			self.session.openWithCallback(self.playnextvideo, MessageBox, _('PLAY NEXT VIDEO?\n%s') % title, type=MessageBox.TYPE_YESNO)
		return

	def playnextvideo(self, message = None):
		if message:
			try:
				self.nextVideo()
			except Exception as ex:
				print ex
				print 'EXC playnextvideo'

	def nextVideo(self):
		try:
			index = STREAMS.list_index + 1
			video_counter = len(STREAMS.iptv_list)
			if index < video_counter:
				if STREAMS.iptv_list[index][4] != None:
					STREAMS.list_index = index
					self.player_helper()
		except Exception as ex:
			print ex
			print 'EXC nextVideo'

		return

	def prevVideo(self):
		try:
			index = STREAMS.list_index - 1
			if index > -1:
				if STREAMS.iptv_list[index][4] != None:
					STREAMS.list_index = index
					self.player_helper()
		except Exception as ex:
			print ex
			print 'EXC prevVideo'

		return

	def player_helper(self):
		self.show_info()
		if self.vod_entry:
			self.vod_entry = STREAMS.iptv_list[STREAMS.list_index]
			self.vod_url = self.vod_entry[4]
			self.title = self.vod_entry[1]
			self.descr = self.vod_entry[2]
		self.session.nav.stopService()
		STREAMS.play_vod = False
		STREAMS.list_index_tmp = STREAMS.list_index
		self.setCover()
		self.play_vod()

	def setCover(self):
		try:
			vod_entry = STREAMS.iptv_list[STREAMS.list_index]
			self['cover'].instance.setPixmapFromFile(PLUGIN_PATH + '/img/clear.png')
			if self.vod_entry[3] != '':
				if vod_entry[3].find('http') == -1:
					self.picfile = PLUGIN_PATH + '/img/playlist/' + vod_entry[3]
					self.decodeImage()
					print 'LOCAL IMG VOD'
				else:
					if STREAMS.img_loader == False:
						self.picfile = '%s/nstream_tmp_pic.jpg' % STREAMS.images_tmp_path
					else:
						m = hashlib.md5()
						m.update(self.vod_entry[3])
						cover_md5 = m.hexdigest()
						self.picfile = '%s/%s.jpg' % (STREAMS.images_tmp_path, cover_md5)
					if os.path.exists(self.picfile) == False or STREAMS.img_loader == False:
						downloadPage(self.vod_entry[3], self.picfile).addCallback(self.image_downloaded).addErrback(self.image_error)
					else:
						self.decodeImage()
		except Exception as ex:
			print ex
			print 'update COVER'

	def decodeImage(self):
		try:
			x = self['cover'].instance.size().width()
			y = self['cover'].instance.size().height()
			sc = AVSwitch().getFramebufferScale()
			self.picload.setPara((x,
			 y,
			 sc[0],
			 sc[1],
			 0,
			 0,
			 '#00000000'))
			self.picload_conn = self.picload.PictureData.connect(self.showImage)
			self.picload.startDecode(self.picfile)
		except Exception as ex:
			print ex
			print 'ERROR decodeImage'

	def showImage(self, picInfo = None):
		self['cover'].show()
		try:
			ptr = self.picload.getData()
			if ptr:
				self['cover'].instance.setPixmap(ptr)
		except Exception as ex:
			print ex
			print 'ERROR showImage'

	def image_downloaded(self, id):
		self.decodeImage()

	def image_error(self, id):
		i = 0

	def LastJobView(self):
		currentjob = None
		for job in JobManager.getPendingJobs():
			currentjob = job

		if currentjob is not None:
			self.session.open(JobView, currentjob)
		return

	def createMetaFile(self, filename):
		try:
			text = re.compile('<[\\/\\!]*?[^<>]*?>')
			text_clear = ''
			if self.vod_entry[2] != None:
				text_clear = text.sub('', self.vod_entry[2])
			serviceref = eServiceReference(4097, 0, STREAMS.moviefolder + '/' + filename)
			metafile = open('%s/%s.meta' % (STREAMS.moviefolder, filename), 'w')
			metafile.write('%s\n%s\n%s\n%i\n' % (serviceref.toString(),
			 self.title.replace('\n', ''),
			 text_clear.replace('\n', ''),
			 time()))
			metafile.close()
		except Exception as ex:
			print ex
			print 'ERROR metaFile'

		return

	def __evEOF(self):
		if self.cont_play:
			self.nextVideo()

	def __seekableStatusChanged(self):
		print 'seekable status changed!'

	def __serviceStarted(self):
		self['state'].setText(' PLAY     >')
		self['cont_play'].setText('Continue play OFF')
		self.state = self.STATE_PLAYING

	def doEofInternal(self, playing):
		if not self.execing:
			return
		if not playing:
			return
		print 'doEofInternal EXIT OR NEXT'

	def stopnew(self):
		if STREAMS.playhack == '':
			self.session.nav.stopService()
			STREAMS.play_vod = False
			self.exit()

	def nextAR(self):
		message = nextAR()
		self.session.open(MessageBox, message, type=MessageBox.TYPE_INFO, timeout=3)

	def prevAR(self):
		message = prevAR()
		self.session.open(MessageBox, message, type=MessageBox.TYPE_INFO, timeout=3)

	def trialWarning(self):
		self.StateTimer.start(STREAMS.trial_time * 1000, True)
		self.session.open(MessageBox, STREAMS.trial, type=MessageBox.TYPE_INFO, timeout=STREAMS.trial_time)

	def show_more_info(self):
		self.session.open(MessageBox, self.vod_url, type=MessageBox.TYPE_INFO)

	def __playStateChanged(self, state):
		self.hideTimer.start(5000, True)
		print 'self.seekstate[3] ' + self.seekstate[3]
		text = ' ' + self.seekstate[3]
		if self.seekstate[3] == '>':
			text = ' PLAY     >'
		if self.seekstate[3] == '||':
			text = 'PAUSE   ||'
		if self.seekstate[3] == '>> 2x':
			text = '    x2     >>'
		if self.seekstate[3] == '>> 4x':
			text = '    x4     >>'
		if self.seekstate[3] == '>> 8x':
			text = '    x8     >>'
		self['state'].setText(text)

	def play_vod(self):
		try:
			if self.vod_url != '' and self.vod_url != None and len(self.vod_url) > 5:
				if self.vod_url.find('.ts') > 0:
					print '------------------------ LIVE ------------------'
					self.session.nav.stopService()
					self.reference = eServiceReference(1, 0, self.vod_url)
					print self.reference
					self.reference.setName(self.title)
					self.session.nav.playService(self.reference)
				else:
					print '------------------------ movie ------------------'
					self.session.nav.stopService()
					self.reference = eServiceReference(4097, 0, self.vod_url)
					self.reference.setName(self.title)
					self.session.nav.playService(self.reference)
			else:
				if self.error_message:
					self.session.open(MessageBox, self.error_message.encode('utf-8'), type=MessageBox.TYPE_ERROR)
				else:
					self.session.open(MessageBox, 'NO VIDEOSTREAM FOUND'.encode('utf-8'), type=MessageBox.TYPE_ERROR)
				self.close()
		except Exception as ex:
			print 'vod play error 2'
			print ex

		return

	def parse_url(self):
		if STREAMS.playhack != '':
			self.vod_url = STREAMS.playhack
		print '++++++++++parse_url+++++++++++'
		try:
			url = self.vod_url
		except Exception as ex:
			print 'ERROR+++++++++++++++++parse_url++++++++++++++++++++++ERROR'
			print ex

	def power_off(self):
		self.close(1)

	def exit(self):
		if STREAMS.playhack == '':
			self.close()


class SelectQuality(Screen):

	def __init__(self, session, film_quality = None):
		Screen.__init__(self, session)
		self.film_quality = []
		self['actions'] = HelpableActionMap(self, 'nStreamPlayerVOD', {'back': self.exit,
		 'ok': self.ok}, -1)
		for x in range(len(film_quality)):
			self.film_quality.append('%i. %sp' % (x + 1, film_quality[x]))

		self['filmparts'] = MenuList(self.film_quality)
		self['menulabel'] = Label('SELECT QUALITY')

	def ok(self):
		self.close(self['filmparts'].l.getCurrentSelectionIndex())

	def exit(self):
		self.close(None)
		return


def Plugins(**kwargs):
	return [PluginDescriptor(name='XC-Multi', description='XcPlugin-MultiServer IpTV-VoD Player', where=PluginDescriptor.WHERE_MENU, fnc=menu), PluginDescriptor(name='XC-Multi', description='XcPlugin-MultiServer IpTV-VoD Player', where=PluginDescriptor.WHERE_PLUGINMENU, fnc=Start_iptv_palyer, icon=iconpic)]


class nStreamTasksScreen(Screen):

	def __init__(self, session):
		Screen.__init__(self, session)
		self.session = session
		self['shortcuts'] = ActionMap(['OkCancelActions'], {'ok': self.keyOK,
		 'cancel': self.keyClose}, -1)
		self['movielist'] = List([])
		self.Timer = eTimer()

		try:
			self.Timer_conn = self.Timer.timeout.connect(self.TimerFire)
		except:
			self.Timer.callback.append(self.TimerFire)

		self.onLayoutFinish.append(self.layoutFinished)
		self.onClose.append(self.__onClose)

	def __onClose(self):
		del self.Timer

	def layoutFinished(self):
		self.Timer.startLongTimer(2)

	def TimerFire(self):
		self.Timer.stop()
		self.rebuildMovieList()

	def rebuildMovieList(self):
		self.movielist = []
		self.getTaskList()

	def getTaskList(self):
		for job in JobManager.getPendingJobs():
			self.movielist.append((job,
			 job.name,
			 job.getStatustext(),
			 int(100 * job.progress / float(job.end)),
			 str(100 * job.progress / float(job.end)) + '%'))

		if len(self.movielist) >= 1:
			self.Timer.startLongTimer(10)

	def getMovieList(self):
		filelist = os_listdir(STREAMS.moviefolder)
		if filelist is not None:
			filelist.sort()
			for filename in filelist:
				if os_path.isfile(STREAMS.moviefolder + '/' + filename) and filename.endswith('.meta') is False:
					self.movielist.append(('movie',
					 filename,
					 _('Finished'),
					 100,
					 '100%'))

		return

	def keyOK(self):
		current = self['movielist'].getCurrent()
		if current:
			if current[0] == 'movie':
				sref = eServiceReference(4097, 0, STREAMS.moviefolder + '/' + current[1])
				sref.setName(current[1])
				self.session.open(Xtream_Player, sref)
			else:
				job = current[0]
				self.session.openWithCallback(self.JobViewCB, JobView, job)

	def JobViewCB(self, why):
		pass

	def keyClose(self):
		self.close()


def debug(obj, text = ''):
	print datetime.fromtimestamp(time()).strftime('[%H:%M:%S]')
	print '%s' % text + ' %s\n' % obj


class html_parser_moduls():

	def __init__(self):
		self.video_list = []
		self.next_page_url = ''
		self.next_page_text = ''
		self.prev_page_url = ''
		self.prev_page_text = ''
		self.search_text = ''
		self.search_on = ''
		self.active_site_url = ''
		self.playlistname = ''
		self.playlist_cat_name = ''
		self.kino_title = ''
		self.category_back_url = ''
		self.error = ''

	def reset_buttons(self):
		self.kino_title = ''
		self.next_page_url = None
		self.next_page_text = ''
		self.prev_page_url = None
		self.prev_page_text = ''
		self.search_text = ''
		self.search_on = None
		return

	def get_list(self, url):
		debug(url, 'MODUL URL: ')
		self.reset_buttons()