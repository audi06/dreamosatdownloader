gVersion = 'gp4-unstable'
gUrl = 'http://download.blue-panel.com/krogoth/gemini4-unstable/'
gKeyUrl = 'http://download.blue-panel.com/info@ihad.tv.key'
