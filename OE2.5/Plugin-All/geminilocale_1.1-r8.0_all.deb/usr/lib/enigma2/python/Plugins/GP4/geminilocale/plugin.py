# -*- coding: utf-8 -*-
from gLocale import ArchBox
from Plugins.Plugin import PluginDescriptor
from Tools.NumericalTextInput import NumericalTextInput
from enigma import eRCInput, getPrevAsciiCode
from Components.ActionMap import NumberActionMap
from Tools.HardwareInfo import HardwareInfo
from Tools.Directories import createDir
from Tools.Log import Log
from gVersion import *

import os
from twisted.web.client import downloadPage
from twisted.internet.protocol import ServerFactory
from twisted.internet import reactor
from twisted.protocols import basic

class CharJump(object):
	def __init__(self, session, char=u'ABCDEFGHIJKLMNOPQRSTUVWXYZ'):
		rcinput = eRCInput.getInstance()
		rcinput.setKeyboardMode(rcinput.kmAscii)

		self.numericalTextInput = NumericalTextInput()
		self.numericalTextInput.setUseableChars(char)

		self["NumberActions"] = NumberActionMap(["NumberActions", "InputAsciiActions"],
		{
			"gotAsciiCode": self.__keyAsciiCode,
			"1": self.__keyNumberGlobal,
			"2": self.__keyNumberGlobal,
			"3": self.__keyNumberGlobal,
			"4": self.__keyNumberGlobal,
			"5": self.__keyNumberGlobal,
			"6": self.__keyNumberGlobal,
			"7": self.__keyNumberGlobal,
			"8": self.__keyNumberGlobal,
			"9": self.__keyNumberGlobal,
			"0": self.__KeyNull
		}, -1)
		
		self.onClose.append(self.__onClose)
		
	def __onClose(self):
		rcinput = eRCInput.getInstance()
		rcinput.setKeyboardMode(rcinput.kmNone)

	def __KeyNull(self, number):
		self.Key0()

	def __keyAsciiCode(self):
		unichar = unichr(getPrevAsciiCode())
		charstr = unichar.encode("utf-8")
		if len(charstr):
			if charstr[0] == "0":
				self.__KeyNull(0)
			else:
				self.getListByCharBegin(charstr[0].upper())
			
	def __keyNumberGlobal(self, number):
		unichar = self.numericalTextInput.getKey(number)
		if unichar is not None:
			charstr = unichar.encode("utf-8")
			if len(charstr):
				if charstr[0] == "0":
					self.__KeyNull(0)
				else:
					self.getListByCharBegin(charstr[0])

#---------------------------------------------------------------------------------------

class GlobalEvent(object):
	def __init__(self):
		self.__globalEvent=[]
		
	def startEvents(self, what, data):
		#print "startEvents_________________________________________",what, data
		retdata=None
		for callback in self.__globalEvent:
			try:
				if callback[0] == what:
					if callable(callback[1]):
						retdata=callback[1](what, data)
			except Exception as e:
				Log.e(e)
				self.removeCallback(callback)
		return retdata
				
	def addCallback(self,callback):
		self.__globalEvent.append(callback)
		
	def removeCallback(self,callback):
		try:
			self.__globalEvent.remove(callback)
		except Exception as e:
			Log.e(e)

gGlobalEvent = GlobalEvent()

#---------------------------------------------------------------------------------------

def CheckGeminiApt():
	KEYFILE="/tmp/gemini4.key"
	#Wegen Backup nicht in /etc/enigma2
	INITFILE="/etc/GP-Feed-init"
	INITKEY="/etc/GP-Key-init"

	def _createFeedConf(version, url, typ):
		fname="/etc/apt/sources.list.d/%s-%s-feed.list" %(version,typ)
		if os.path.exists(fname)==False:
			try:
				wfile = open(fname, 'w')
				wfile.write("deb %s%s ./\n" % (url,typ))
				wfile.close()
				Log.i("'%s' create"%fname)
			except Exception, e:
				Log.e(e)
		else:
			Log.i("'%s' found"%fname)
			
	def __installkey(val=None):
		if os.path.exists(KEYFILE):
			cmd = "apt-key add '%s'" %KEYFILE
			os.system(cmd)
			try:
				open(INITKEY, 'w').close()
				Log.i("keyfile installed")
				os.remove(KEYFILE)
			except Exception, e:
				Log.e(e)
			
	def __downloadERR(error):
		print "[%s] <%s>"%(__name__,error.getErrorMessage())
			
	#print "-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-"
	
	#data und cache Ordner anlegen
	if os.path.exists("/data")==False:
		createDir("/data")
	if os.path.exists("/tmp/.cache/gemini")==False:
		createDir("/tmp/.cache/gemini",True)
		
	#wenn INITFILE nicht vorhanden apt-Listen erstellen
	if os.path.exists(INITFILE)==False and ArchBox:
		extraPlugins="extraPluginsArmhf"
		if ArchBox=="mipsel":
			extraPlugins="extraPluginsMipsel"
			
		device = HardwareInfo().get_device_name()
		_createFeedConf(gVersion,gUrl,ArchBox)
		_createFeedConf(gVersion,gUrl,device)
		_createFeedConf(gVersion,gUrl,'all')
		_createFeedConf(gVersion,gUrl,'allcodes')
		_createFeedConf(gVersion,gUrl,extraPlugins)
		
		try:
			open(INITFILE, 'w').close()
			if device == "dm520" or device == "dm525" or device == "dm900" or device == "dm920":
				from Components.config import config
				config.misc.recording_allowed.value = True
				config.misc.recording_allowed.save()
			
		except Exception, e:
			Log.e(e)
			
	#key file installieren
	if os.path.exists(INITKEY)==False:
		Log.i("download keyfile")
		downloadPage(gKeyUrl, KEYFILE, timeout=10).addCallback(__installkey).addErrback(__downloadERR)

CheckGeminiApt()
#---------------------------------------------------------------------------------------

class GP4Protocol(basic.LineReceiver):
	def lineReceived(self, line):
		data=line.split('-',1)
		if data and len(data)==2:
			ret=gGlobalEvent.startEvents(data[0],data[1])
			if ret and len(ret)>0:
				self.transport.write("%s\n" %ret)
		self.transport.loseConnection()

def localestart(**kwargs):
	if kwargs['reason']==0:
		try:
			os.remove("/tmp/.cache/gemini/.gemini4sock")
		except:
			pass
		
		factory = ServerFactory()
		factory.protocol = GP4Protocol
		reactor.listenUNIX("/tmp/.cache/gemini/.gemini4sock",factory)

def Plugins(**kwargs):
	list=[]
	list.append(PluginDescriptor(where=PluginDescriptor.WHERE_AUTOSTART,fnc=localestart))
	return list
