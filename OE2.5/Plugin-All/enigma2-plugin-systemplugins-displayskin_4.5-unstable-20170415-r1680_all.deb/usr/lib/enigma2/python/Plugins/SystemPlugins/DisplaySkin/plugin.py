from Plugins.Plugin import PluginDescriptor

def SkinSelMain(session, **kwargs):
	from displayskin import DisplaySkin
	session.open(DisplaySkin)

def SkinSelSetup(menuid, **kwargs):
	if menuid == "osd_video_audio":
		return [(_("Display Skin"), SkinSelMain, "DisplaySkin", None)]
	else:
		return []

def Plugins(**kwargs):
	return [PluginDescriptor(name="Display Skin", description=_("Select your display look"), where = PluginDescriptor.WHERE_MENU, fnc=SkinSelSetup),
		PluginDescriptor(name="Display Skin", description=_("Select your display look"), where = PluginDescriptor.WHERE_PLUGINMENU, icon="displayskin.png", fnc=SkinSelMain),
		PluginDescriptor(name="Display Skin", description=_("Select your display look"), where = PluginDescriptor.WHERE_EXTENSIONSMENU, icon="g3icon_displayskin.png", fnc=SkinSelMain)]
