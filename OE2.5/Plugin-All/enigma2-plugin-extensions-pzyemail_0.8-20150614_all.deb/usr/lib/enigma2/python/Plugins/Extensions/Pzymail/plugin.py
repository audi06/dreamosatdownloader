# -*- coding: iso-8859-1 -*-
#
##    Enigma2 -- PzyEMAIL -- by pzy-co  (GNU GPL3)
##
##    Copyright (C) 2010  pzy-co
##
##    This program is free software: you can redistribute it and/or modify
##    it under the terms of the GNU General Public License as published by
##    the Free Software Foundation, either version 3 of the License, or
##    (at your option) any later version.
##
##    This program is distributed in the hope that it will be useful,
##    but WITHOUT ANY WARRANTY; without even the implied warranty of
##    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##    GNU General Public License for more details.
##
##    You should have received a copy of the GNU General Public License
##    along with this program.  If not, see <http://www.gnu.org/licenses/>.
##
##
##
##    Thanks to Aaron Swartz for his html2text-Script (GNU GPL3)
##
##    Thanks to pasurimi for his beta-testing and inspiration for the scrolling LCD
##
##    Thanks to Happy2000 & Dr. Best for the renderers
##
##    Thanks to all plugin-writers published their code and shared the knowledge
##
################################################################################################################################
Pzymail_version="PzyEMAIL v0.8"
Pzymail_plugindir="/usr/lib/enigma2/python/Plugins/Extensions/Pzymail/"
################################################################################################################################

# You can edit this section

pzymailIcon = "pzymail.png"
pzy_settings_file = "/etc/enigma2/pzymail.settings"
pzy_tmp_dir = "/tmp/pzymails/"
pzywebkit_data = "/media/hdd/webkit-data"
debuglevelnr = 0                     # 0 = Off ; for poplib, imaplib, smtplib ; set to 0 to avoid personal data in the crashlog!!

################################################################################################################################


from Plugins.Plugin import PluginDescriptor
from Plugins.Extensions.Pzymail.html2text import html2text  ##Script by Aaron Swartz (GNU GPL3)!!
from base64 import b64encode, b64decode
from email import message_from_string, message_from_file, Encoders
from email.header import decode_header, Header
from email.MIMEMultipart import MIMEMultipart
from email.MIMEBase import MIMEBase
from email.MIMEText import MIMEText
from email.Utils import formatdate
from mimetypes import guess_extension
from Screens.Screen import Screen
from Screens.ChoiceBox import ChoiceBox
from Screens.VirtualKeyBoard import VirtualKeyBoard, VirtualKeyBoardEntryComponent, VirtualKeyBoardList
from re import compile as re_compile
from skin import parseColor, parseFont, parseSize, parsePosition, loadSkin
from Components.ActionMap import ActionMap, NumberActionMap
from Components.Button import Button
from Components.FileList import MultiFileSelectList, EXTENSIONS #,FileList
from Components.Label import Label
from Components.MenuList import MenuList
#from Components.Network import iNetwork
from Components.Pixmap import Pixmap
from Components.ServiceEventTracker import ServiceEventTracker
from Components.ScrollLabel import ScrollLabel
from Components.Sources.StaticText import StaticText
from Components.Sources.CanvasSource import CanvasSource
from Components.config import config, getConfigListEntry ,ConfigSubsection, ConfigSubDict, ConfigSelection, ConfigText, ConfigInteger, NoSave
from Components.ConfigList import ConfigListScreen, ConfigList
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
from Components.Language import language
from Components.Harddisk import harddiskmanager
from ConfigParser import SafeConfigParser, ParsingError
from enigma import gFont, eListboxPythonMultiContent, getDesktop, eTimer, eServiceReference, iPlayableService, ePoint, eConsoleAppContainer,RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, RT_HALIGN_BLOCK, RT_VALIGN_TOP, RT_VALIGN_BOTTOM, RT_VALIGN_CENTER, RT_WRAP
from os import mkdir, rmdir, remove, path as os_path, listdir
from os.path import exists, join, basename
from time import strftime, strptime, localtime
from Tools.Directories import SCOPE_PLUGINS, resolveFilename, SCOPE_CURRENT_SKIN, resolveFilename, fileExists
from Tools.LoadPixmap import LoadPixmap
from imaplib import IMAP4
from poplib import POP3
from smtplib import SMTP

pzyOE20 = False
pzyWebNavigation = False
pzyopera = True
pzyopera_2015_05 = True
try:
	from Components.Sources.WebNavigation import WebNavigation
	pzyOE20 = True
	
	from Plugins.Extensions.Browser import Browser
	pzyWebNavigation = True
	pzyopera = False
	pzyopera_2015_05 = False
except:
	#pzyWebNavigation = False
	try:
		# VTI v6.0.8
		from Plugins.Extensions.HbbTV.plugin import OperaBrowser, setPluginBrowser
		#pzyopera = True
		pzyopera_2015_05 = False
	except:
		try:
			#OpenVix
			from Plugins.Extensions.HbbTV.browser import Browser
			#pzyopera = True
			#pzyopera_2015_05 = True
		except:
			try:
				#original vu 2015_05
				from Plugins.Extensions.Vbrowser.browser import Browser
				#pzyopera = True
				#pzyopera_2015_05 = True
			except:
				pzyopera = False
				pzyopera_2015_05 = False
			
	if pzyopera:	
		print "[PZYMAIL] Opera supported"
	else:
		print "[PZYMAIL] No Opera support, sorry"

		
try:
	from imaplib import IMAP4_SSL
	from poplib import POP3_SSL
	from smtplib import SMTP_SSL
	pzyhave_ssl = True
except:
	print "[PZYMAIL] No SSL support, sorry"
	IMAP4_SSL = IMAP4
	POP3_SSL = POP3
	SMTP_SSL = SMTP
	pzyhave_ssl = False


try:
	from enigma import PACKAGE_VERSION
	major, minor, patch = [int(n) for n in PACKAGE_VERSION.split('.')]
	if major > 4 or (major == 4 and minor >= 2):
		#7080
		pzy_bln_DreamOS = True
		
	else:
		pzy_bln_DreamOS = False	
except ImportError:
	pzy_bln_DreamOS = False	
	
if pzy_bln_DreamOS:
	from Components.Network import iNetworkInfo
else:
	from Components.Network import iNetwork
	
###################################################################################################################################################################

def Plugins(**kwargs):
	loadPluginSkin(kwargs["path"])
	l = [ PluginDescriptor(where = PluginDescriptor.WHERE_AUTOSTART, fnc = autostart),
	      PluginDescriptor(where=[PluginDescriptor.WHERE_SESSIONSTART], fnc=sessionstart),
	      PluginDescriptor(name=_("PzyEMAIL"), description=_("imap, pop3, smtp, ssl, tls"), where = PluginDescriptor.WHERE_PLUGINMENU, icon=pzymailIcon, fnc=main)  ]
	return l


def main(session, **kwargs):
	session.open(PzymailPlugin)

###################################################################################################################################

DEFAULTSECT = "DEFAULT"
pzypop3_Server = None
pzyautopoller = None
pzysession = None
pzynewmails = 0
pzyinfoscreen = False
pzyinfoinstance = None
pzyLCD = None
pzynewmailsListAccounts = []
pzymsgs = []
pzynewmailsList = []
pzynewmailsDict = {}
pzyExtendedInfoScreen = True
pzyExtendedLCD = True
pzyautoClose = 0
pzyinfoScreenMaxRuns = 0
pzymp3Path = None
pzyPlaymp3 = False
pzyOnlyHeaders = True
pzyDeleteYES = False
pzyswapoff = True
pzywebview = True
pzyPersistentStorage = False
#pzyStorageDir = ""
pzyhtmldefault = True
pzyboxcomment = ""
pzyboxtype = ""

###################################################################################################################################

def sessionstart(reason, **kwargs):
	global pzysession
	if reason == 0:
		pzysession = kwargs["session"]


def autostart(reason, **kwargs):
	global pzyautopoller
	global pzyboxcomment
	global pzyboxtype

	## Startup
	if reason == 0:
		print "[PZYMAIL] autostart 0 : Startup "
		pzyautopoller = PzyAutoPoller()
		pzyautopoller.start()

		imgver = "/etc/image-version"
		if exists(imgver):
			f = File_Access()
			data = f.read_File(imgver)
		
			lines = []
			lines = data.splitlines()
			for l in lines:
				if l.startswith("comment"):
					list=l.split("=")
					pzyboxcomment=list[1]
				elif l.startswith("boxtype"):
					list=l.split("=")
					pzyboxtype=list[1]

		
	## Shutdown
	elif reason == 1:
		print "[PZYMAIL] autostart 1 : Shutdown"
		if pzyautopoller is not None:
			pzyautopoller.stop()
			pzyautopoller = None

###################################################################################################################################


def loadSkinReal(skinPath):
	if exists(skinPath):
		print "[PZYMAIL] Loading skin ", skinPath
		loadSkin(skinPath)


def loadPluginSkin(pluginPath):
	loadSkinReal(pluginPath + "/" + config.skin.primary_skin.value)
	loadSkinReal(pluginPath + "/skin.xml")
	
###################################################################################################################################


class PzyAutoPoller:
	def __init__(self):
		self.timer = eTimer()
		self.timer_conn = None

	def start(self, initial = True):
		if initial:
			delay = 180
		else:
			delay = 30*60
		
		if not pzy_bln_DreamOS:
			if self.query not in self.timer.callback:
				self.timer.callback.append(self.query)
		else:
			self.timer_conn = self.timer.timeout.connect(self.query)
		self.timer.startLongTimer(delay)
		

	def stop(self):
		if not pzy_bln_DreamOS:
			if self.query in self.timer.callback:
				self.timer.callback.remove(self.query)
		else:
			self.timer_conn = None
		self.timer.stop()
			
			
	def query(self):
		global pzypop3_Server

		if pzypop3_Server is None:
			pop3_Server = Pop3_Server()
			if pzypop3_Server is None:
				pzypop3_Server = pop3_Server
			else:
				self.timer.start(500)
				return
			
			#pzypop3_Server.networkCheckedCallback(self.updateAllAccounts)
			pzypop3_Server.networkCheckedCallback(self.updateAllAccounts_timer)
		else:
			print "[PZYMAIL] Waiting for GUI to close ... we won't mess any data"
			self.timer.startLongTimer(60) ##60 secs
			
			
	def updateAllAccounts(self,state=0):
		global pzypop3_Server
		global pzysession
		global pzynewmails
		global pzyinfoscreen
		global pzyinfoinstance
		global pzyExtendedInfoScreen
	
		try:
			pop3_Server = pzypop3_Server
			
			pop3_Server.read_cfg()
	
			if pop3_Server.globalpzymailsettings["updateInStandby"] == "False":
				import Screens.Standby
				if Screens.Standby.inStandby is not None:
					pzypop3_Server = None
					print "[PZYMAIL] AutoUpdate Disabled"
	
					if self.start not in Screens.Standby.inStandby.onClose:
						Screens.Standby.inStandby.onClose.append(self.start)
					print "[PZYMAIL] IN STANDBY -- Waiting For Callback"
					return
				
			minutes = pop3_Server.globalpzymailsettings["intervall"]
			if minutes == "0":
				self.stop()
				print "[PZYMAIL] AutoUpdate Disabled"
				pzypop3_Server = None
				return
			else:
				print "[PZYMAIL] AutoUpdate Enabled ... every %s minutes ..." %minutes
				pop3_Server.update_allAccounts(True) #from_autostart=True
				pop3_Server.set_cfg_allAccounts_dict()
				pop3_Server.write_cfg()
						
				self.timer.startLongTimer(60*int(minutes))
	
				pzypop3_Server = None
	
				print "[PZYMAIL] Mails fetched since last GUI visit: # ",len(pzynewmailsList)
				if pzynewmails != 0:
					if pzyinfoinstance is None:
						if pzysession is not None:
							if pzyExtendedInfoScreen:
								pzyinfoinstance = pzysession.open(InfoScreen)
							else:
								pzyinfoinstance = pzysession.open(InfoScreenMini)
						else:
							print "[PZYMAIL] Waiting for Session"
							self.timer.startLongTimer(30) ##60 secs
					else:
						pzyinfoinstance.checknew()	
		except Exception:
			import traceback, sys
			traceback.print_exc(file=sys.stdout)   # Dump error to stdout, Ignore any program errors
			
			
	def updateAllAccounts_timer(self,state=0):
		global pzypop3_Server
		global pzysession
		global pzynewmails
		global pzyinfoscreen
		global pzyinfoinstance
		global pzyExtendedInfoScreen
	
		try:
			pop3_Server = pzypop3_Server
			
			pop3_Server.read_cfg()
	
			if pop3_Server.globalpzymailsettings["updateInStandby"] == "False":
				import Screens.Standby
				if Screens.Standby.inStandby is not None:
					pzypop3_Server = None
					print "[PZYMAIL] AutoUpdate Disabled"
	
					if self.start not in Screens.Standby.inStandby.onClose:
						Screens.Standby.inStandby.onClose.append(self.start)
					print "[PZYMAIL] IN STANDBY -- Waiting For Callback"
					return
				
			minutes = pop3_Server.globalpzymailsettings["intervall"]
			if minutes == "0":
				self.stop()
				print "[PZYMAIL] AutoUpdate Disabled"
				pzypop3_Server = None
				return
			else:
				print "[PZYMAIL] AutoUpdate Enabled ... every %s minutes ..." %minutes
				pop3_Server.update_allAccounts_timer_buildList(self.update_allAccounts_timer_fin)
	
		except Exception:
			import traceback, sys
			traceback.print_exc(file=sys.stdout)			


	def update_allAccounts_timer_fin(self,state=0):
		global pzypop3_Server
		global pzysession
		global pzynewmails
		global pzyinfoscreen
		global pzyinfoinstance
		global pzyExtendedInfoScreen

		try:
			pop3_Server = pzypop3_Server
			pop3_Server.set_cfg_allAccounts_dict()
			pop3_Server.write_cfg()
			
			minutes = pop3_Server.globalpzymailsettings["intervall"]
			self.timer.startLongTimer(60*int(minutes))

			pzypop3_Server = None

			print "[PZYMAIL] Mails fetched since last GUI visit: # ",len(pzynewmailsList)
			if pzynewmails != 0:
				if pzyinfoinstance is None:
					if pzysession is not None:
						if pzyExtendedInfoScreen:
							pzyinfoinstance = pzysession.open(InfoScreen)
						else:
							pzyinfoinstance = pzysession.open(InfoScreenMini)
					else:
						print "[PZYMAIL] Waiting for Session"
						self.timer.startLongTimer(30) ##60 secs
				else:
					pzyinfoinstance.checknew()	
		except Exception:
			import traceback, sys
			traceback.print_exc(file=sys.stdout)   # Dump error to stdout, Ignore any program errors
			
###################################################################################################################################################################
		
current_ScreenWidth = getDesktop(0).size().width()
if current_ScreenWidth > 1200 and current_ScreenWidth < 1900:
	HDSkn = True
else:
	HDSkn = False

if current_ScreenWidth > 1900:
	FullHDSkn = True
else:
	FullHDSkn = False
	

###################################################################################################################################################################


def get_widgetAttribute(instance,widgetname="",attributename=""):
	for (key,value) in instance[widgetname].skinAttributes:
		if key == attributename:
			return value

		
################################################################################################################################

class Keypress2ascii:
	def __init__(self,on_keypressed=[],on_finished=[]):
		self.__timer = eTimer()
		if not pzy_bln_DreamOS:
			self.__timer.callback.append(self.__query)
		else:
			self.__timer_conn = self.__timer.timeout.connect(self.__query)
		
		self.on_keypressed=on_keypressed
		self.on_finished=on_finished
		
		self.keynumber = None
		self.keypresses = 0
		
		#rc
		self.keyindex = { 1 : [" ","*","#",'"',"1"],
		                  2 : ["A","B","C","2"],
		                  3 : ["D","E","F","3"],
		                  4 : ["G","H","I","4"],
		                  5 : ["J","K","L","5"],
		                  6 : ["M","N","O","6"],
		                  7 : ["P","Q","R","S","7"],
		                  8 : ["T","U","V","8"],
		                  9 : ["W","X","Y","Z","9"],
		                  0 : ["0"] }		
		
		
		
	def setDict(self,dict):
		self.keyindex = dict
		
		
	def stop(self):
		self.__timer.stop()
		if not pzy_bln_DreamOS:
			if self.__query in self.__timer.callback:
				self.__timer.callback.remove(self.__query)
		else:
			del self.__timer_conn
			
		self.__timer = None
		self.on_keypressed = []
		self.on_finished = []

		
	def pressed(self,keynumber):
		
		if not self.keyindex.has_key(keynumber):
			return
		
		
		if keynumber == self.keynumber:
			if self.keypresses < len(self.keyindex.get(self.keynumber))-1:
				self.keypresses +=1
			else:
				self.keypresses = 0
		else:
			self.keypresses = 0
			self.keynumber = keynumber
		
		self.__timer.stop()	
		self.__timer.start(750) #ms delay
		str_ret = str(self.keyindex.get(self.keynumber)[self.keypresses])
		for fnc in self.on_keypressed:
			fnc(str_ret)		
		
			
	def __query(self):
		if not self.keyindex.has_key(self.keynumber):
			self.keynumber = None
			return
		
		str_ret = str(self.keyindex.get(self.keynumber)[self.keypresses])
		self.keypresses = 0
		self.keynumber = None
		
		for fnc in self.on_finished:
			fnc(str_ret)	
				
			
################################################################################################################################			
			
class MailMenuList(MenuList):
	def __init__(self, list=[], enableWrapAround=True, content=eListboxPythonMultiContent):
		MenuList.__init__(self, list, enableWrapAround, content)

		self.list=list
		self.fromLabelPos_x = 10
		self.fromLabelPos_y = 5 
		self.fromLabelSize_x = 160
		self.fromLabelSize_y = 25 
		self.fromLabelAlign = RT_HALIGN_LEFT|RT_VALIGN_TOP
		self.fromLabelColor = None #0x0000ff00
		self.fromTextPos_x = 160
		self.fromTextPos_y = 5
		self.fromTextSize_x = 1200
		self.fromTextSize_y = 25
		self.fromLabelAlign = RT_HALIGN_LEFT|RT_VALIGN_TOP
		self.fromTextColor = None #0x0000ff00
		
		self.subjectLabelPos_x = 10
		self.subjectLabelPos_y = 30 
		self.subjectLabelSize_x = 160
		self.subjectLabelSize_y = 25
		self.subjectLabelAlign = RT_HALIGN_LEFT|RT_VALIGN_TOP
		self.subjectLabelColor = None #0x00c9ff00
		self.subjectTextPos_x = 160
		self.subjectTextPos_y = 30 
		self.subjectTextSize_x = 1200
		self.subjectTextSize_y = 25
		self.subjectTextAlign = RT_HALIGN_LEFT|RT_VALIGN_TOP
		self.subjectTextColor = None #0x00c9ff00
		
		self.timeLabelPos_x = 10
		self.timeLabelPos_y = 55 
		self.timeLabelSize_x = 160
		self.timeLabelSize_y = 25
		self.timeLabelAlign = RT_HALIGN_LEFT|RT_VALIGN_TOP
		self.timeLabelColor = None #0x0000c9ff
		self.timeTextPos_x = 160
		self.timeTextPos_y = 55
		self.timeTextSize_x = 1200
		self.timeTextSize_y = 25 
		self.timeTextAlign = RT_HALIGN_LEFT|RT_VALIGN_TOP
		self.timeTextColor = None #0x0000c9ff
		
		self.fromLabelText = "From:"
		self.subjectLabelText = "Subject:"
		self.timeLabelText = "Time:"
					
		self.use_uniForegroundSelected = False
		
		self.l.setFont(0, gFont("Regular", 20)) #from
		self.l.setFont(1, gFont("Regular", 20))
		self.l.setFont(2, gFont("Regular", 20)) #subject
		self.l.setFont(3, gFont("Regular", 20))
		self.l.setFont(4, gFont("Regular", 20)) #time
		self.l.setFont(5, gFont("Regular", 20))
		
		self.l.setItemHeight(80)
		self.l.setBuildFunc(self.buildEntry)
		
		
	def applySkin(self,desktop,parent):
		attribs = [ ] 
		if self.skinAttributes is not None:
			for (attrib, value) in self.skinAttributes:

				if attrib == "fromLabelFont":
					self.l.setFont(0, parseFont(value, ((1,1),(1,1))))

				elif attrib == "fromTextFont":
					self.l.setFont(1, parseFont(value, ((1,1),(1,1))))
				
				elif attrib == "subjectLabelFont":
					self.l.setFont(2, parseFont(value, ((1,1),(1,1))))	
					
				elif attrib == "subjectTextFont":
					self.l.setFont(3, parseFont(value, ((1,1),(1,1))))	
					
				elif attrib == "timeLabelFont":
					self.l.setFont(4, parseFont(value, ((1,1),(1,1))))	
					
				elif attrib == "timeTextFont":
					self.l.setFont(5, parseFont(value, ((1,1),(1,1))))

				elif attrib == "fromLabelPos":
					ep = parsePosition(value, ((1,1),(1,1)))
					self.fromLabelPos_x = int(ep.x())
					self.fromLabelPos_y = int(ep.y())
					
				elif attrib == "fromTextPos":
					es = parseSize(value, ((1,1),(1,1))) #eSize
					self.fromTextPos_x = int(es.width())
					self.fromTextPos_y = int(es.height())					
					
				elif attrib == "subjectLabelPos":
					ep = parsePosition(value, ((1,1),(1,1)))
					self.subjectLabelPos_x = int(ep.x())
					self.subjectLabelPos_y = int(ep.y())
				
				elif attrib == "subjectTextPos":
					es = parseSize(value, ((1,1),(1,1)))
					self.subjectTextPos_x = int(es.width())
					self.subjectTextPos_y = int(es.height())
					
				elif attrib == "timeLabelPos":
					ep = parsePosition(value, ((1,1),(1,1)))
					self.timeLabelPos_x = int(ep.x())
					self.timeLabelPos_y = int(ep.y())
				
				elif attrib == "timeTextPos":
					es = parseSize(value, ((1,1),(1,1))) 
					self.timeTextPos_x = int(es.width())
					self.timeTextPos_y = int(es.height())

				elif attrib == "fromLabelSize":
					es = parseSize(value, ((1,1),(1,1))) 
					self.fromLabelSize_x = int(es.width())
					self.fromLabelSize_y = int(es.height())
					
				elif attrib == "fromTextSize":
					es = parseSize(value, ((1,1),(1,1))) 
					self.fromTextSize_x = int(es.width())
					self.fromTextSize_y = int(es.height())
					
				elif attrib == "subjectLabelSize":
					es = parseSize(value, ((1,1),(1,1)))
					self.subjectLabelSize_x = int(es.width())
					self.subjectLabelSize_y = int(es.height())
					
				elif attrib == "subjectTextSize":
					es = parseSize(value, ((1,1),(1,1)))
					self.subjectTextSize_x = int(es.width())
					self.subjectTextSize_y = int(es.height())
					
				elif attrib == "timeLabelSize":
					es = parseSize(value, ((1,1),(1,1)))
					self.timeLabelSize_x = int(es.width())
					self.timeLabelSize_y = int(es.height())
					
				elif attrib == "timeTextSize":
					es = parseSize(value, ((1,1),(1,1)))
					self.timeTextSize_x = int(es.width())
					self.timeTextSize_y = int(es.height())					
	
				elif attrib == "fromLabelColor":				
					self.fromLabelColor = parseColor(value).argb()
					
				elif attrib == "fromTextColor":				
					self.fromTextColor = parseColor(value).argb()	
					
				elif attrib == "subjectLabelColor":				
					self.subjectLabelColor = parseColor(value).argb()
					
				elif attrib == "subjectTextColor":				
					self.subjectTextColor = parseColor(value).argb()	
					
				elif attrib == "timeLabelColor":				
					self.timeLabelColor = parseColor(value).argb()
					
				elif attrib == "timeTextColor":				
					self.timeTextColor = parseColor(value).argb()					

				elif attrib == "itemHeight":
					self.l.setItemHeight(int(value))
					
				elif attrib == "fromLabelAlign":
					self.fromLabelAlign = eval(value)
					
				elif attrib == "fromTextAlign":
					self.fromTextAlign = eval(value)
					
				elif attrib == "subjectLabelAlign":
					self.subjectLabelAlign = eval(value)
					
				elif attrib == "subjectTextAlign":
					self.subjectTextAlign = eval(value)					
					
				elif attrib == "timeLabelAlign":
					self.timeLabelAlign = eval(value)	
					
				elif attrib == "timeTextAlign":
					self.timeTextAlign = eval(value)					
					
				elif attrib == "foregroundColorSelected":
					self.use_uniForegroundSelected = True
					attribs.append((attrib, value))
				
				elif attrib == "fromLabelText":
					self.fromLabelText = value
					
				elif attrib == "subjectLabelText":
					self.subjectLabelText = value
					
				elif attrib == "timeLabelText":
					self.timeLabelText = value					
					
				else:
					attribs.append((attrib, value))
					
		self.skinAttributes = attribs
		return MenuList.applySkin(self,desktop,parent)

	
	def buildEntry(self,idx,From,Subject,Time,uid):
		#width = self.l.getItemSize().width()
		#height = self.l.getItemSize().height()

		if (From == "") or (From is None):
			str_from = "-- Nobody --"
		else:
			str_from = From.replace('"',"")
		if (Subject == "") or (Subject is None):
			str_subject = "-- No Subject --"
		else:
			str_subject = Subject.lstrip()
		if (Time == "") or (Time is None):
			str_time = "-- No Time --"
		else:
			str_time = Time 

		if self.use_uniForegroundSelected:
			fromLabelColor_sel = None
			fromTextColor_sel = None
			subjectLabelColor_sel = None
			subjectTextColor_sel = None
			timeLabelColor_sel = None
			timeTextColor_sel = None			
		else:
			fromLabelColor_sel = self.fromLabelColor
			fromTextColor_sel = self.fromTextColor
			subjectLabelColor_sel = self.subjectLabelColor
			subjectTextColor_sel = self.subjectTextColor
			timeLabelColor_sel = self.timeLabelColor
			timeTextColor_sel = self.timeTextColor
			
		menuEntry = [(idx,From,Subject,Time,uid)]

		menuEntry.append(MultiContentEntryText(pos=(self.fromLabelPos_x, self.fromLabelPos_y), size=(self.fromLabelSize_x, self.fromLabelSize_y), font=0, text=self.fromLabelText, color=self.fromLabelColor, color_sel=fromLabelColor_sel, flags=self.fromLabelAlign))
		menuEntry.append(MultiContentEntryText(pos=(self.fromTextPos_x, self.fromTextPos_y), size=(self.fromTextSize_x, self.fromTextSize_y), font=1, text=str_from, color=self.fromTextColor, color_sel=fromTextColor_sel, flags=self.fromTextAlign))
		menuEntry.append(MultiContentEntryText(pos=(self.subjectLabelPos_x, self.subjectLabelPos_y), size=(self.subjectLabelSize_x, self.subjectLabelSize_y), font=2, text=self.subjectLabelText, color=self.subjectLabelColor, color_sel=subjectLabelColor_sel, flags=self.subjectLabelAlign))
		menuEntry.append(MultiContentEntryText(pos=(self.subjectTextPos_x, self.subjectTextPos_y), size=(self.subjectTextSize_x, self.subjectTextSize_y), font=3, text=str_subject, color=self.subjectTextColor, color_sel=subjectTextColor_sel, flags=self.subjectTextAlign))
		menuEntry.append(MultiContentEntryText(pos=(self.timeLabelPos_x, self.timeLabelPos_y), size=(self.timeLabelSize_x, self.timeLabelSize_y), font=4, text=self.timeLabelText, color=self.timeLabelColor, color_sel=timeLabelColor_sel, flags=self.timeLabelAlign))
		menuEntry.append(MultiContentEntryText(pos=(self.timeTextPos_x, self.timeTextPos_y), size=(self.timeTextSize_x, self.timeTextSize_y), font=5, text=str_time, color=self.timeTextColor, color_sel=timeTextColor_sel, flags=self.timeTextAlign))

		return menuEntry

################################################################################################################################	
	
class AccountMenuList(MenuList):
	def __init__(self, list=[], enableWrapAround=True, content=eListboxPythonMultiContent):
		MenuList.__init__(self, list, enableWrapAround, content)
		
		self.pzySelectedAccountColor = 0x00ffffff
		self.pzyConnectedAccountColor = 0x0000c8ff
		
		self.accountColor = 0x0033ff33
		self.counterColor = 0x0033ff33
		self.fillPatternColor = 0x0033ff33
		self.dateColor = 0x0033ff33
		self.timeColor = 0x0033ff33
		
		self.accountPos_x = 10
		self.accountPos_y = 0
		self.accountSize_x = 150
		self.accountSize_y = 40
	
		self.counterTemplate = ["[", " Total/", " New ]"]
		self.counterPos_x = 150
		self.counterPos_y = 0
		self.counterSize_x1 = 10
		self.counterSize_x2 = 70
		self.counterSize_x3 = 120
		self.counterSize_y = 40

		self.datePos_x = 470
		self.datePos_y = 0 
		self.dateSize_x = 120
		self.dateSize_y = 40  
		
		self.timePos_x = 640
		self.timePos_y = 0 
		self.timeSize_x = 120
		self.timeSize_y = 40		      
     
		self.fillPattern = "> > > > >"  
		self.fillPatternPos_x = 400
		self.fillPatternPos_y = 0	
		self.fillPatternSize_x = 120
		self.fillPatternSize_y = 40		
		
		self.use_uniForegroundSelected = False
		
		self.accountAlign = RT_HALIGN_LEFT|RT_VALIGN_TOP
		self.counterAlign = RT_HALIGN_RIGHT|RT_VALIGN_TOP
		self.fillPatternAlign = RT_HALIGN_LEFT|RT_VALIGN_CENTER
		self.dateAlign = RT_HALIGN_LEFT|RT_VALIGN_TOP
		self.timeAlign = RT_HALIGN_LEFT|RT_VALIGN_TOP
					
		self.list=list
		self.l.setFont(0, gFont("Regular", 20))
		self.l.setFont(1, gFont("Regular", 20))
		self.l.setFont(2, gFont("Regular", 15))
		self.l.setFont(3, gFont("Regular", 20))
		self.l.setFont(4, gFont("Regular", 20))
		
		self.l.setItemHeight(40)
		self.l.setBuildFunc(self.buildEntry)
		
				
	def applySkin(self,desktop,parent):
		attribs = [ ] 
		if self.skinAttributes is not None:
			for (attrib, value) in self.skinAttributes:
				if attrib == "accountFont":
					self.l.setFont(0, parseFont(value, ((1,1),(1,1))))
					
				elif attrib == "counterFont":
					self.l.setFont(1, parseFont(value, ((1,1),(1,1))))
					
				elif attrib == "fillPatternFont":
					self.l.setFont(2, parseFont(value, ((1,1),(1,1))))
					
				elif attrib == "dateFont":
					self.l.setFont(3, parseFont(value, ((1,1),(1,1))))
					
				elif attrib == "timeFont":
					self.l.setFont(4, parseFont(value, ((1,1),(1,1))))					
					
				elif attrib == "accountAlign":
					self.accountAlign = eval(value)
					
				elif attrib == "counterAlign":
					self.counterAlign = eval(value)
					
				elif attrib == "fillPatternAlign":
					self.fillPatternAlign = eval(value)
					
				elif attrib == "dateAlign":
					self.dateAlign = eval(value)
					
				elif attrib == "timeAlign":
					self.timeAlign = eval(value)

				elif attrib == "itemHeight":
					self.l.setItemHeight(int(value))
					
				elif attrib == "colorSelected":				
					self.pzySelectedAccountColor = parseColor(value).argb()
					
				elif attrib == "colorConnected":	
					self.pzyConnectedAccountColor = parseColor(value).argb()
					
				elif attrib == "accountColor":				
					self.accountColor = parseColor(value).argb()
					
				elif attrib == "counterColor":	
					self.counterColor = parseColor(value).argb()					
					
				elif attrib == "fillPatternColor":				
					self.fillPatternColor = parseColor(value).argb()
					
				elif attrib == "dateColor":	
					self.dateColor = parseColor(value).argb()
					
				elif attrib == "timeColor":	
					self.timeColor = parseColor(value).argb()					
					
				elif attrib == "accountPos":
					ep = parsePosition(value, ((1,1),(1,1)))
					self.accountPos_x = int(ep.x())
					self.accountPos_y = int(ep.y())
					
				elif attrib == "accountSize":
					es = parseSize(value, ((1,1),(1,1))) #eSize
					self.accountSize_x = int(es.width())
					self.accountSize_y = int(es.height())
					
				elif attrib == "counterPos":
					ep = parsePosition(value, ((1,1),(1,1)))
					self.counterPos_x = int(ep.x())
					self.counterPos_y = int(ep.y())

				elif attrib == "counterSize_x1_x2_x3_y":
					valx1,valx2,valx3,valy = value.split(",")
					self.counterSize_x1 = int(valx1)
					self.counterSize_x2 = int(valx2)
					self.counterSize_x3 = int(valx3)
					self.counterSize_y = int(valy)
					
				elif attrib == "datePos":
					ep = parsePosition(value, ((1,1),(1,1)))
					self.datePos_x = int(ep.x())
					self.datePos_y = int(ep.y())
				
				elif attrib == "dateSize":
					es = parseSize(value, ((1,1),(1,1))) #eSize
					self.dateSize_x = int(es.width())
					self.dateSize_y = int(es.height())					
				
				elif attrib == "timePos":
					ep = parsePosition(value, ((1,1),(1,1)))
					self.timePos_x = int(ep.x())
					self.timePos_y = int(ep.y())

				elif attrib == "timeSize":
					es = parseSize(value, ((1,1),(1,1))) #eSize
					self.timeSize_x = int(es.width())
					self.timeSize_y = int(es.height())
					
				elif attrib == "counterTemplate":
					counterTemplate = value.split(",")
					lst = []
					for el in counterTemplate:
						lst.append(eval(el))
					self.counterTemplate = lst
					
				elif attrib == "fillPattern":
					self.fillPattern = value
					
				elif attrib == "fillPatternPos":
					ep = parsePosition(value, ((1,1),(1,1)))
					self.fillPatternPos_x = int(ep.x())
					self.fillPatternPos_y = int(ep.y())
				
				elif attrib == "fillPatternSize":
					es = parseSize(value, ((1,1),(1,1)))
					self.fillPatternSize_x = int(es.width())
					self.fillPatternSize_y = int(es.height())						
					
				elif attrib == "foregroundColorSelected":
					self.use_uniForegroundSelected = True
					attribs.append((attrib, value))
					
				else:
					attribs.append((attrib, value))
					
		self.skinAttributes = attribs
		return MenuList.applySkin(self,desktop,parent) 
	
	
	def buildEntry(self,account,currAccount,message_num,message_num_new,str_checked,connectType):
		#width = self.l.getItemSize().width()
		#height = self.l.getItemSize().height()
	
		l=str_checked.split(" ")
		for e in range(len(l)-1,0,-1):
			if l[e]=='':
				l.pop(e)
		str_date = l[0]
		str_time = l[1]

		menuEntry = [(account)]
	
		if currAccount == account:
			if connectType is None:
				accountColor = self.pzySelectedAccountColor
				counterColor = self.pzySelectedAccountColor
				fillPatternColor = self.pzySelectedAccountColor
				dateColor = self.pzySelectedAccountColor
				timeColor = self.pzySelectedAccountColor
				
				accountColor_sel = self.pzySelectedAccountColor
				counterColor_sel = self.pzySelectedAccountColor
				fillPatternColor_sel = self.pzySelectedAccountColor
				dateColor_sel = self.pzySelectedAccountColor
				timeColor_sel = self.pzySelectedAccountColor				
			else:
				col = self.pzyConnectedAccountColor
				accountColor = self.pzyConnectedAccountColor
				counterColor = self.pzyConnectedAccountColor
				fillPatternColor = self.pzyConnectedAccountColor
				dateColor = self.pzyConnectedAccountColor
				timeColor = self.pzyConnectedAccountColor
				
				accountColor_sel = self.pzyConnectedAccountColor
				counterColor_sel = self.pzyConnectedAccountColor
				fillPatternColor_sel = self.pzyConnectedAccountColor
				dateColor_sel = self.pzyConnectedAccountColor
				timeColor_sel = self.pzyConnectedAccountColor				
		else:
			accountColor = self.accountColor
			counterColor = self.counterColor
			fillPatternColor = self.fillPatternColor
			dateColor = self.dateColor
			timeColor = self.timeColor

			if self.use_uniForegroundSelected:
				accountColor_sel = None
				counterColor_sel = None
				fillPatternColor_sel = None
				dateColor_sel = None
				timeColor_sel = None
			else:		
				accountColor_sel = self.accountColor
				counterColor_sel = self.counterColor
				fillPatternColor_sel = self.fillPatternColor
				dateColor_sel = self.dateColor
				timeColor_sel = self.timeColor			
			
		menuEntry.append(MultiContentEntryText(pos=(self.accountPos_x, self.accountPos_y), size=(self.accountSize_x,self.accountSize_y), font=0, flags=self.accountAlign, color_sel=accountColor_sel,color=accountColor, text=account)) #backcolor_sel=0x00ff00ff, 
		
		menuEntry.append(MultiContentEntryText(pos=(self.counterPos_x, self.counterPos_y), size=(self.counterSize_x1,self.counterSize_y), font=1, flags=self.counterAlign, color_sel=counterColor_sel ,color=counterColor, text=self.counterTemplate[0])) #backcolor_sel=0x00ffff00, 
		menuEntry.append(MultiContentEntryText(pos=(self.counterPos_x+self.counterSize_x1, self.counterPos_y), size=(self.counterSize_x2,self.counterSize_y), font=1, flags=self.counterAlign, color_sel=counterColor_sel ,color=counterColor, text=message_num.rjust(3) + self.counterTemplate[1])) #backcolor_sel=0x00ff0000, 
		menuEntry.append(MultiContentEntryText(pos=(self.counterPos_x+self.counterSize_x1+self.counterSize_x2, self.counterPos_y), size=(self.counterSize_x3,self.counterSize_y), font=1, flags=self.counterAlign, color_sel=counterColor_sel ,color=counterColor, text=message_num_new + self.counterTemplate[2] )) #backcolor_sel=0x0000ff00, 
		
		menuEntry.append(MultiContentEntryText(pos=(self.fillPatternPos_x, self.fillPatternPos_y), size=(self.fillPatternSize_x,self.fillPatternSize_y), font=2, flags=self.fillPatternAlign, color_sel=fillPatternColor_sel ,color=fillPatternColor, text=self.fillPattern )) #backcolor_sel=0x00ff0000, 
		
		menuEntry.append(MultiContentEntryText(pos=(self.datePos_x,self.datePos_y), size=(self.dateSize_x,self.dateSize_y), font=3, flags=self.dateAlign, color_sel=dateColor_sel ,color=dateColor, text=str_date)) #backcolor_sel=0x0000ffff,
		
		menuEntry.append(MultiContentEntryText(pos=(self.timePos_x,self.timePos_y), size=(self.timeSize_x,self.timeSize_y), font=4, flags=self.timeAlign,color_sel=timeColor_sel ,color=timeColor, text=str_time)) #backcolor_sel=0x00ff0000, 		
		
		return menuEntry
	

################################################################################################################################	
	
class PzymailPlugin(Screen):
	def __init__(self, session):
		global pzysession
		global pzynewmails
		global pzyLCD
		
		Screen.__init__(self, session)
		
		self["Mail_List_SelectedIndex"] = Button()
		self["Mail_List_SelectedIndex"].hide()
		
		self["KeyPressed"] = Button()
		self["KeyPressed"].hide()
		
		self.kpa = Keypress2ascii([self.showPressedKey],[self.hidePressedKey])
		self.lastpressednumber = None
	
		pzysession = session
		self.session = session
		
		self.newmailscount = 0
		
		self.sortindex = 0 #1=From, 2=Subject, 0=Time/Headerlist)
		self.nextMailIndex = 0
		self.nextMail = None
		
		self.networkstatestr = ""
		self.bln_started = False
		
		self.swap=ShellCommands()

		self.count_newmails_String = "0"
		self.mailtitle = ""
		self.whichlist = "all_mails"
		self.currList = "Account_List"

		self["KeyGreen"] = Pixmap()
		self["KeyGreen_Text"] = Label("")		
		
		self["Account_Button"] = SkinableLabel(_("Account"))
		self["Mail_Button"] = SkinableLabel(_("Mail"))
		
		self["Account_List"] = AccountMenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self["Mail_List"] = MailMenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)		
		
		self["Mail_List"].onSelectionChanged.append(self.showCurrMailIndex)
				
		self["redDelete"] = Pixmap()
		self["redDeleteText"] = Button("")
		
		self["SortOrder"] = Button("Time")
		self["KeyYellow"] = Pixmap()

		self["actions"] = NumberActionMap(["PiPSetupActions","MenuActions","ColorActions","InfobarChannelSelection","ChannelSelectEPGActions","NumberActions"],  #ActionMap
		                            {       "1": self.keyNumberGlobal,
		                                    "2": self.keyNumberGlobal,
		                                    "3": self.keyNumberGlobal,
		                                    "4": self.keyNumberGlobal,
		                                    "5": self.keyNumberGlobal,
		                                    "6": self.keyNumberGlobal,
		                                    "7": self.keyNumberGlobal,
		                                    "8": self.keyNumberGlobal,
		                                    "9": self.keyNumberGlobal,
		                                    "0": self.keyNumberGlobal,
		                                    "red": self.reddelete,
		                                    "green": self.update_allAccounts,
		                                    "yellow": self.changeSortIndex,
		                                    "blue": self.mailListStartPos,
		                                    "up": self.menuListUp,
		                                    "down": self.menuListDown,
		                                    "left": self.menuListPageUp,
		                                    "right": self.menuListPageDown,
		                                    "menu": self.KeyMenu,
		                                    "cancel": self.Exit,
		                                    "ok": self._loadMailHelper,
		                                    "historyNext": self.listToggle,
		                                    "showEPGList": self.greenLongInfo,
		                                    "historyBack": self.toggle_new_all_mails,
		                                    "size+": self.listToggle,
		                                    "size-": self.listToggle      }, -1)
		                                                                                  

		newmailscount = 0
		for account in pzynewmailsDict:
			newmailscount = newmailscount + len(pzynewmailsDict[account]["mailList"])
		self.newmailscount = newmailscount
		self.setTitle(Pzymail_version + " -- New Mails since last GUI visit: # " + str(newmailscount))

		self.onLayoutFinish.append(self.firstStart)
		self.LCD = None
		self.summary = None
		
	##########################################################################################################################################	Start
		
	def showCurrMailIndex(self):
		mlsi = self["Mail_List_SelectedIndex"]
	 	ml = self["Mail_List"]
		curr = ml.getCurrent()
		if curr is None:
			if mlsi.visible  == 1: 
				mlsi.hide()
		else:
			text = str(ml.getSelectionIndex()+1)
			mlsi.setText(text) 
			if mlsi.visible == 0:
				mlsi.show()

				
	def keyNumberGlobal(self, number):
		self.lastpressednumber = number
		self.kpa.pressed(number)
	
		
	def showPressedKey(self,data=None):
		if self.sortindex == 0:
			if self.lastpressednumber is None:
				return
			data = str(self.lastpressednumber * 100)
			
		if data is not None: 
			if data == " ":
				data = "SPACE"
			self["KeyPressed"].setText(data)
			self["KeyPressed"].show()
		
			
	def hidePressedKey(self,data=""):		
		self["KeyPressed"].hide()
		
		if self.sortindex == 0:
			if self.lastpressednumber is None:
				return
			int_idx = self.lastpressednumber * 100 -1
			int_lastidx = len(self["Mail_List"].list)-1
			if int_idx < int_lastidx:
				self["Mail_List"].moveToIndex(int_idx)
			else:
				self["Mail_List"].moveToIndex(int_lastidx)
			self.lastpressednumber = None
			return
		
		lst=self["Mail_List"].list

		ctr = 0
		for el in lst:
			#strel = el[0][self.sortindex]
			strel = el[self.sortindex]
			if self.sortindex == 1:
				strel = strel.replace('"',"")
				
			elif self.sortindex == 2:
				strel = strel.lstrip()				
				
			if strel.upper().startswith(data,0,1):	
				self["Mail_List"].moveToIndex(ctr)
				break
			ctr +=1

		
	def changeSortIndex(self): 
		self.get_Selections()
		
		if self.selectedMail is None:
			return	
		
		if self.sortindex < 2:
			self.sortindex +=1 #From, Subject
		else:
			self.sortindex = 0 # Time
		choices=["Time","From","Subject"]
		self["SortOrder"].setText(choices[self.sortindex])
		
		if self.whichlist == "all_mails":
			mailList = self.pop3_Server.get_mailList(sortindex=self.sortindex)	
			self["Mail_List"].setList(mailList)	
		else:
			self.show_only_newmails()
			
		lst=self["Mail_List"].list
		self["Mail_List"].moveToIndex(lst.index(self.selectedMail))		
		
		
	def mailListStartPos(self):
		self["Mail_List"].moveToIndex(0)		

		
	def clearBrowserData(self):
		global pzy_tmp_dir

		c = ShellCommands()
		str_cmd="rm -fR %s*" %pzy_tmp_dir
		c.cmdlist=[str_cmd]
		c.executeCmdList()
		
		
	def createSummary(self):
		return LCDAusg
			

	def changeText(self, text="", LCDzeile=3):
		self.LCD.setText(text, LCDzeile)

			
	def firstStart(self):
		global pzypop3_Server
		global current_ScreenWidth
		global HDSkn
		global pzyWebNavigation
		global pzywebview
		global Pzymail_plugindir
		#global pzyPersistentStorage
		#global pzyStorageDir
		global pzyswapoff
		global pzywebkit_data
		global pzyboxcomment
		global pzyboxtype
		global FullHDSkn
		
		print "[PZYMAIL] BoxComment: ",pzyboxcomment, pzyboxtype
		
		if not (pzypop3_Server is None):
			print "[PZYMAIL] ... Polling, Try Again ... EXIT() ..."
			self.close()
		else:
			pzypop3_Server = Pop3_Server(self.session)
			self.pop3_Server = pzypop3_Server
			
			self.pop3_Server.networkCheckedCallback(self.setNetworkTitle)			
			self.pop3_Server.read_cfg()
			
			print "[PZYMAIL] Current Desktop Size, HD-Skin, FullHD: ",current_ScreenWidth,HDSkn,FullHDSkn
						
			file_Access = File_Access()
			file_Access.makeDefaultDirectory()
			#if pzyPersistentStorage:
				#if not pzyStorageDir == "":
					#file_Access.makeDefaultDirectory(pzyStorageDir)
			#exists(pzywebkit_data)
			if pzyswapoff:
				self.swap.procSwaps_off()			

			self.currentAccount = self.pop3_Server.get_currentAccount()
			self.messageObject = MessageObject()
			
			if self.pop3_Server.globalpzymailsettings["redkeydelete"] == "True":
				self["redDelete"].show()
				self["redDeleteText"].show()
			else:
				self["redDelete"].hide()
				self["redDeleteText"].hide()
					
			self["Account_Button"].setSelected()
			self["Mail_Button"].setDeselected()
			
			self["Mail_List"].moveToIndex(0)			
			self["Account_List"].moveToIndex(0)
			
			self.pop3_Server.on_connected.append(self.fillMenuList_A)
			self.pop3_Server.on_disconnected.append(self.fillMenuList_A)
			self.fillMenuList_A()


	def setNetworkTitle(self,bln_state=False):
		if bln_state:
			self.networkstatestr = " -- Internet OK"
		else:
			self.networkstatestr = " -- NO Internet"
		self.setTitle(str(self.getTitle()) + self.networkstatestr)
			
			
	def fillMenuList_A(self,fromdelete=False):
		accountList = self.pop3_Server.get_status()
		self["Account_List"].setList(accountList)
		
		self.fillMenuList_M(fromdelete)


	def fillMenuList_M(self,fromdelete=False):
		if self.whichlist == "all_mails":
			mailList = self.pop3_Server.get_mailList(sortindex=self.sortindex)
			self["Mail_List"].setList(mailList)
			if fromdelete and self.sortindex > 0:
				if self.nextMail is not None:
					self["Mail_List"].moveToIndex(self["Mail_List"].list.index(self.nextMail))
		else:
			if pzynewmailsDict[self.currentAccount]["mailList"] == []:
				self["Mail_List"].setList([])
			else:
				self.show_only_newmails()
		
				if fromdelete:   ##war alllgemein ,daf�roben wegmachen #if fromdelete and self.sortindex > 0: 
					if self.nextMail is not None:
						self["Mail_List"].moveToIndex(self["Mail_List"].list.index(self.nextMail))				
			
				
	def show_all_mails(self):
		if self.currentAccount is None:
			return
		self.fillMenuList_M()


	def show_only_newmails(self):
		global pzynewmailsDict

		if self.currentAccount is None:
			return False

		if pzynewmailsDict.has_key(self.currentAccount):
			maillist = pzynewmailsDict[self.currentAccount]["mailList"]
			if maillist == []:
				return False
		else:
			return False

		if self.sortindex > 0 and self.sortindex < 4:
			self.pop3_Server.sortindex = self.sortindex
			sortedlist = sorted(maillist,key=self.pop3_Server.getSorted)
		else:
		        sortedlist = maillist			

		self["Mail_List"].setList(sortedlist) 
		return True

	######################################################################################################

	def reddelete(self):
		if self.pop3_Server.globalpzymailsettings["redkeydelete"] == "False":
			return

		self.get_Selections()
		if self.selectedAccount is None or self.selectedMail is None:
			return
		self.deleteMail()

		
	def greenLongInfo(self): 
		curr = self["Mail_List"].getCurrent()
		if not curr is None:
			currtext = "%s\n\n%s\n\n%s" %(curr[1], curr[2], curr[3])
			self.session.openWithCallback(self.__backEmailView,EmailView,currtext,None,self.pop3_Server,"HeaderInfo")
						

	def menuListPageUp(self):
		self[self.currList].pageUp()


	def menuListPageDown(self):
		self[self.currList].pageDown()


	def menuListUp(self):
		self[self.currList].up()


	def menuListDown(self):
		self[self.currList].down()
		
		
	def listToggle(self):
		if self.currList == "Account_List":
			self.currList = "Mail_List"
		
			self["Account_Button"].setDeselected()
			self["Mail_Button"].setSelected()

			if self.mailtitle != "":
				self.setTitle(Pzymail_version + " -- " + self.mailtitle)
			else:
				if self.whichlist == "all_mails":
					self.setTitle(Pzymail_version + " -- All Mails" + self.networkstatestr)
				else:
					if pzynewmailsDict[self.currentAccount]["mailList"] == []:
						self.setTitle(Pzymail_version + " -- No New Mails" )
					else:
						self.setTitle(Pzymail_version + " -- New Mails" )
		else:
			self.currList = "Account_List"

			self["Account_Button"].setSelected()
			self["Mail_Button"].setDeselected()
			
			if self.whichlist == "all_mails":
				self.setTitle(Pzymail_version + " -- All Mails" + self.networkstatestr)
			else:
				if pzynewmailsDict[self.currentAccount]["mailList"] == []:
					self.setTitle(Pzymail_version + " -- No New Mails" )
				else:
					self.setTitle(Pzymail_version + " -- New Mails" )


	def toggle_new_all_mails(self):
		if self.currentAccount is None:
			return

		self.get_Selections()
		if self.whichlist == "all_mails":
			self.whichlist = "new_mails"

			if self.show_only_newmails():
				self.setTitle(Pzymail_version + " -- New Mails")
			else:
				self.setTitle(Pzymail_version + " -- No New Mails")
				self["Mail_List"].setList([])
		else:
			self.whichlist = "all_mails"
			self.show_all_mails()
			self.setTitle(Pzymail_version + " -- All Mails" + self.networkstatestr)
		
		if self.selectedMail is not None:
			lst=self["Mail_List"].list
			try:
				self["Mail_List"].moveToIndex(lst.index(self.selectedMail))				
			except:
				self["Mail_List"].moveToIndex(0)
			
	
	def KeyMenu(self):
		if self.currList == "Account_List":
			menu = [ (_("New / All Mails Toggle"), self.toggle_new_all_mails),
			         (_("Update All Accounts"), self.update_allAccounts),
			         (_("Update Current Account"), self.update_currentAccount),
			         (_("Disconnect Current Account"), self.disconnect_currentAccount),
			         (_("Set Current Account"), self.setCurrentAccount),
			         ("--", ""),
			         (_("Create Account"), self.newAccount),
			         (_("Edit Account"), self.editAccount),
			         (_("Delete Account"), self.deleteAccount),
			         ("--", ""),
			         (_("Edit Global Settings"), self.editGlobalSettings),
			         (_("Write eMail"), self.writeMail) ]
			keys = [ "<", "1", "2", "3", "4", "", "5", "6", "7", "", "8", "9" ]
		else:
			menu = [ (_("New / All Mails Toggle"), self.toggle_new_all_mails),
			         (_("Load eMail From Server"), self._loadMailHelper),
			         (_("Erase eMail From Server"), self.deleteMail),
			         (_("Load eMail From Server And Save To 'Mail Directory'"), self.writeMail_tmp),
			         ("--", ""),
			         (_("Read eMail From Mail Directory"), self.readMail_tmp),
			         (_("View Last Loaded Mail"), self.view_lastLoaded),        # As Plain Text
			         #(_("View Last Loaded Mail As html2text"), self.view_lastLoadedhtml),
			         (_("Save Attachments From Last Loaded Mail To '/tmp/'"), self.saveAttachments_lastLoaded),
			         ("--", ""),
			         (_("Name To Adressbook"), self.name2Adressbook),
			         (_("Reply To eMail"), self.replyTo),
			         (_("Write eMail"), self.writeMail) ]
			
		self.session.openWithCallback(
			self.menuCallback,
			cbx,
		        title = "Menu",
			list = menu,
		        
		        keys = [ "<", "1", "2", "3", "", "4", "5", "6", "7", "", "8" , "9", "0" ]
		)			
		self.get_Selections()

		
	def menuCallback(self, ret):
		ret and ret[1]()
		
		
	def noSelection(self):
		pass
	

	def _loadMailHelper(self):
		self.get_Selections()
		if self.selectedAccount is None:
			return

		if self.currList == "Mail_List":
			status = self.loadMail()
			if status == False:
				status = self.loadMail()
				if status == False:
					self.setTitle(Pzymail_version + " -- " + _("Can Not Connect"))
					self.pop3_Server.networkCheckedCallback(self.setNetworkTitle,True)

		else:			
			if self.pop3_Server.currAccount == self.selectedAccount[0]:
				self.update_currentAccount()
			else:
				self.pop3_Server._pop3_disconnect()
				self.pop3_Server._imap_disconnect()
				self.pop3_Server._smtp_disconnect()
				self.setCurrentAccount()
				self.setTitle(Pzymail_version)


	def Exit(self, serverError=False):
		global pzypop3_Server
		global pzynewmails
		global pzynewmailsListAccounts
		global pzynewmailsDict
		global pzynewmailsList
		global pzymsgs
		#global pzyPersistentStorage
		#global pzyStorageDir
		global pzyswapoff
	
		pzynewmailsDict = {}
		pzynewmailsList = []
		pzynewmailsListAccounts = []
		pzymsgs = []
		pzynewmails = 0

		if self.fillMenuList_A in self.pop3_Server.on_connected:
			self.pop3_Server.on_connected.remove(self.fillMenuList_A)
		if self.fillMenuList_A in self.pop3_Server.on_disconnected:
			self.pop3_Server.on_disconnected.remove(self.fillMenuList_A)
			
		if not serverError:
			self.pop3_Server._imap_disconnect()
			self.pop3_Server._pop3_disconnect()
			self.pop3_Server._smtp_disconnect()
		self.pop3_Server.set_cfg_allAccounts_dict()
		self.pop3_Server.write_cfg()
		print "[PZYMAIL] cfg written ... EXIT() ..."
		#if pzyPersistentStorage == "Temp":
			#if exists(pzyStorageDir):
				#rmdir(pzyStorageDir)
		self.pop3_Server.timer.stop()		
		if not pzy_bln_DreamOS:
			for fnc in self.pop3_Server.timer.callback:
				self.pop3_Server.timer.callback.remove(fnc)
		else:
			self.pop3_Server.timer_conn = None
			
		self.pop3_Server = None
		pzypop3_Server = None

		if pzyswapoff:
			self.swap.finishedCallback = self.__Exit
			self.swap.procSwaps_on()
		else:
			self.__Exit()
		
	def __Exit(self,data=None):
		self.swap.finishedCallback = None
		self.swap = None
		self.kpa.stop()		
		self.kpa = None
		self.close()

	####################################################################################################################

	def newAccount(self):
		currAccount = self.pop3_Server.get_currentAccount()
		self.pop3_Server.set_currentAccount(None)
		self.session.openWithCallback(self.__backEmailSetup, EmailSetup,self.pop3_Server)
		self.pop3_Server.set_currentAccount(currAccount)


	def editGlobalSettings(self):
		self.session.openWithCallback(self.__backEmailSetup, EmailSetup, self.pop3_Server, True)


	def editAccount(self):
		if self.selectedAccount is not None:
			self.pop3_Server._pop3_disconnect()
			self.pop3_Server.set_currentAccount(self.selectedAccount[0])
			self.session.openWithCallback(self.__backEmailSetup, EmailSetup, self.pop3_Server)


	def __backEmailSetup(self, val=False):
		if self.pop3_Server.globalpzymailsettings["redkeydelete"] == "True":
			self["redDelete"].show()
			self["redDeleteText"].show()
		else:
			self["redDelete"].hide()
			self["redDeleteText"].hide()
		self.fillMenuList_A()


	def deleteAccount(self):
		global pzyDeleteYES
		
		if self.selectedAccount is not None:
			screenTitle = "Really Delete This Account?"
			text = self.selectedAccount[0]

			if pzyDeleteYES:
				menu = [ ("Yes", self._backdeleteaccount_yes),
				         ("No", self._backdeleteaccount_no)  ]				
			else:
				menu = [ ("No", self._backdeleteaccount_no),
					 ("Yes", self._backdeleteaccount_yes) ]

			self.session.openWithCallback(
				self.menuCallback,
				cbx,
				title = screenTitle,
				list = menu,
				
				keys = ["1", "2"]
			)			
		

	def menuCallback(self, ret):
		ret and ret[1]()
		
		
	def _backdeleteaccount_no(self):
		self.__backdeleteaccount(False)


	def _backdeleteaccount_yes(self):
		self.__backdeleteaccount(True)


	def __backdeleteaccount(self,answer=False):
		if answer:
			self.pop3_Server.delete_Account(self.selectedAccount[0])
			self.fillMenuList_A()


	def get_Selections(self):
		self.selectedAccount = self["Account_List"].getCurrent()
		self.selectedAccountIndex = self["Account_List"].getSelectionIndex()
		self.selectedMail = self["Mail_List"].getCurrent()
		self.selectedMailIndex = self["Mail_List"].getSelectionIndex() ##muss auf headerlist nach Time-Sortierung zeigen -> f�r die Mailroutinen
		
		if self.selectedMailIndex < len(self["Mail_List"].list)-1:
			self.nextMail = self["Mail_List"].list[self.selectedMailIndex + 1 ]
		else:
			if self.selectedMailIndex > 0:
				self.nextMail = self["Mail_List"].list[self.selectedMailIndex - 1 ]
			else:
				self.nextMail = None
			
		if self.currentAccount is not None:  ##zeigt auf headerlist 'alle Mails' nach Time-Sortierung 
			lst = self.pop3_Server.accounts[self.currentAccount]["HeaderList"]

			if self.selectedMail is not None:
				self.selectedMailIndex = lst.index(self.selectedMail)
					
	
	def setCurrentAccount(self):
		self.showCurrMailIndex()
		if self.selectedAccount is None :
			return
		self.currentAccount = self.selectedAccount[0]
		self.pop3_Server.set_currentAccount(self.currentAccount)
		self["Mail_List"].moveToIndex(0)
		self.fillMenuList_A()


	def disconnect_currentAccount(self):
		self.pop3_Server._smtp_disconnect()
		typ = self.pop3_Server.accounts[self.currentAccount]["Typ"]
		if typ == "143" or typ == "993":
			is_disconnected = self.pop3_Server._imap_disconnect()
		else:
			is_disconnected = self.pop3_Server._pop3_disconnect()

		if is_disconnected:
			self.setTitle(Pzymail_version + " -- " + _("Postbox Unlocked"))
		else:
			self.setTitle(Pzymail_version + " -- " + _("Can Not Unlock Postbox"))


	def imap_disconnect(self):
		self.pop3_Server._imap_disconnect()


	def writeMail(self, mailtuple=None):
		currentAccount = self.pop3_Server.get_currentAccount()
		if currentAccount is not None:
			self.session.openWithCallback(self.__backWriteMail,WriteEmail,self.pop3_Server, mailtuple)


	def __backWriteMail(self,nix):
		pass


	def loadMail(self):
		global pzyWebNavigation
		global pzywebview
		global pzyopera
		global pzy_tmp_dir
		
		if self.selectedAccount is None or self.selectedMail is None:
			return False

		loadMailUidl = self.selectedMail[4]
		self.mailtitle = self.selectedMail[2]		
		typ = self.pop3_Server.accounts[self.currentAccount]["Typ"]
		if (typ == "993" or typ == "995") and not pzyhave_ssl:
			self.setTitle(Pzymail_version + " -- No SSL In This Image -- Change Your Settings")
			return

		if typ == "143" or typ == "993":
			msgObject = self.pop3_Server.imap_load_Mail(loadMailUidl)
		else:
			msgObject = self.pop3_Server.load_Mail(loadMailUidl)

		if msgObject is None:
			return False

		msgCharset_default=self.pop3_Server.get_currdefaultEncoding()
		msgCharset = self.messageObject.get_msgObject_Charset(msgObject,msgCharset_default)
		msgObject_PlainText_String = self.messageObject.get_msgObject_PlainText(msgObject)
		eMailViewString = self.messageObject.msgStringConvert(msgObject_PlainText_String, msgCharset, "utf-8") #msgString_output_encoding="utf-8"
		if eMailViewString is None:
			eMailViewString = self.messageObject.msgStringConvert(msgObject_PlainText_String, msgCharset_default, "utf-8")
		if eMailViewString is None:
			eMailViewString = msgObject_PlainText_String
		if eMailViewString is not None:
			eMailViewString = eMailViewString.strip()
			testhtml = eMailViewString[0:21]
			testhtml = testhtml.upper()
			
			if testhtml.startswith("<!DOCTYPE HTML PUBLIC") or testhtml.startswith("<HTML>"):
				if pzyWebNavigation and pzywebview:				
					openhtml=True
					eMailViewString = self.messageObject.msgStringConvert(msgObject_PlainText_String, msgCharset, "latin-1") #msgString_output_encoding="utf-8"
				
				elif pzyopera and pzywebview:
					openhtml=True

				else:
					openhtml=False
					try:
						htmlMailViewString = html2text(eMailViewString, "")
						eMailViewString = htmlMailViewString.encode("utf8","replace")
					
					except:
						print "[PZYMAIL] HTML Error"
						eMailViewString = msgObject_PlainText_String
			else:
				openhtml=False
	
		else:
			eMailViewString = ""

		if openhtml:
			if pzyopera:
				self.saveAttachments_lastLoaded()
				
				if exists(pzy_tmp_dir + "mailpart-001.html"):
				        filepath="file://%smailpart-001.html" %pzy_tmp_dir
					
				elif exists(pzy_tmp_dir + "mailpart-002.html"): 
					filepath="file://%smailpart-002.html" %pzy_tmp_dir
					
				else:
					filepath="file://%smailpart-001.txt" %pzy_tmp_dir
				
				if pzyopera_2015_05:
					self.session.openWithCallback(self.clearBrowserData, Browser, filepath)
				else:	
					setPluginBrowser(self.session.openWithCallback(self.clearBrowserData, OperaBrowser, filepath, False)) 
			else:
				self.session.openWithCallback(self.__backEmailView,HTMLview,self.mailtitle,eMailViewString)
		else:
			self.session.openWithCallback(self.__backEmailView,EmailView,eMailViewString,msgObject,self.pop3_Server,self.mailtitle)
		
		return True


	def view_lastLoadedhtml(self):
		self.view_lastLoaded(True)


	def view_lastLoaded(self, html=False,autohtml=False):
		global pzyWebNavigation
		global pzywebview
		global pzyopera
		global pzy_tmp_dir
		
		if self.pop3_Server.msgObject is not None:
			msgObject = self.pop3_Server.msgObject
			msgCharset_default=self.pop3_Server.get_currdefaultEncoding()
			if msgCharset_default is None:
				msgCharset_default="latin-1"
			msgCharset = self.messageObject.get_msgObject_Charset(msgObject,msgCharset_default)
			msgObject_PlainText_String = self.messageObject.get_msgObject_PlainText(msgObject,html)
			eMailViewString = self.messageObject.msgStringConvert(msgObject_PlainText_String, msgCharset, "utf-8") #msgString_output_encoding="utf-8"

			if eMailViewString is None:
				eMailViewString = self.messageObject.msgStringConvert(msgObject_PlainText_String, msgCharset_default, "utf-8")
			if eMailViewString is None:
				eMailViewString = msgObject_PlainText_String
			if eMailViewString is not None:
				eMailViewString = eMailViewString.strip()
				testhtml = eMailViewString[0:21]
				testhtml = testhtml.upper()
				
				if (pzyWebNavigation or pzyopera) and pzywebview:
					autohtml=True
					
				if html or (autohtml and (testhtml.startswith("<!DOCTYPE HTML PUBLIC") or testhtml.startswith("<HTML>"))):
					
					if pzyWebNavigation and pzywebview:
						self.session.openWithCallback(self.__backEmailView,HTMLview,self.mailtitle,eMailViewString)
						return
					
					elif pzyopera and pzywebview:
						self.saveAttachments_lastLoaded()

						if exists(pzy_tmp_dir + "mailpart-001.html"):
							filepath="file://%smailpart-001.html" %pzy_tmp_dir
							
						elif exists(pzy_tmp_dir + "mailpart-002.html"): 
							filepath="file://%smailpart-002.html" %pzy_tmp_dir
							
						else:
							filepath="file://%smailpart-001.txt" %pzy_tmp_dir
					
						if pzyopera_2015_05:
							self.session.openWithCallback(self.clearBrowserData, Browser, filepath)
						else:								
							setPluginBrowser(self.session.openWithCallback(self.clearBrowserData, OperaBrowser, filepath, False))						

					else:
						try:
							htmlMailViewString = html2text(eMailViewString, "")
							eMailViewString = htmlMailViewString.encode("utf8","replace")
						except:
							print "[PZYMAIL] HTML Error"
							eMailViewString = msgObject_PlainText_String
			else:
				eMailViewString = ""
			self.session.openWithCallback(self.__backEmailView,EmailView,eMailViewString,msgObject,self.pop3_Server,self.mailtitle)
		else:
			self.setTitle(Pzymail_version + " -- " + _("No Mail Loaded - Please Load First"))


	def __backEmailView(self):

		if self.mailtitle != "":
			self.setTitle(Pzymail_version + " -- " + self.mailtitle)
		else:
			if self.whichlist == "all_mails":
				self.setTitle(Pzymail_version + " -- All Mails" )
			else:
				if pzynewmailsDict[self.currentAccount]["mailList"] == []:
					self.setTitle(Pzymail_version + " -- No New Mails" )
				else:
					self.setTitle(Pzymail_version + " -- New Mails" )
		

	def saveAttachments_lastLoaded(self):
		if not self.pop3_Server.saveAttachments_lastLoaded():
			self.setTitle(Pzymail_version + " -- " + _("No Mail Loaded - Please Load First"))


	def deleteMail(self):
		global pzyhave_ssl
		if self.selectedMail is None:
			return
		eraseMailUidl = self.selectedMail[4]
		selectedMailIndex = self.selectedMailIndex

		typ = self.pop3_Server.accounts[self.currentAccount]["Typ"]
		if (typ == "993" or typ == "995") and not pzyhave_ssl:
			self.setTitle(Pzymail_version + " -- No SSL In This Image -- Change Your Settings")
			return

		if typ == "143" or typ == "993":
			erased = self.pop3_Server.imap_erase_Mail(str(eraseMailUidl),selectedMailIndex)
		elif typ == "110" or typ == "995" :
			erased = self.pop3_Server.erase_Mail(eraseMailUidl,selectedMailIndex)

		print "[PZYMAIL] ERASED ### ",erased
		if erased:
			self.setTitle(Pzymail_version + " -- " + _("Mail erased"))
		else:
			self.setTitle(Pzymail_version + " -- " + _("Mail Not Erased"))
		self.fillMenuList_A(fromdelete=True)


	def readMail_tmp(self):
		pzydir = self.pop3_Server.globalpzymailsettings["pzy_dir"]
		sourcesTitle = _("Mail") + " " + _("Selector")
		selectedTitle= _("Selected") + "-" + _("Mail")
		multiFiles=False
		dirmode=False
		self.session.openWithCallback(self.__backPzyFileBrowser_ReadMail, PzyFileBrowser, [],multiFiles, dirmode,sourcesTitle,selectedTitle,startdir=pzydir)


	def __backPzyFileBrowser_ReadMail(self,selectedList, selectedFile):
		file_Access = File_Access()
		msgObject = file_Access.readCompleteMail(selectedFile)
		if msgObject is None:
			self.setTitle(Pzymail_version + " -- " + _("Cannot Read File"))
			return
		self.pop3_Server.set_msgObject(msgObject)
		
		defenc=self.pop3_Server.get_currdefaultEncoding()
		self.mailtitle = self.messageObject.get_decodedString(msgObject,defenc,"Subject")
		self.setTitle(Pzymail_version + " -- " + self.mailtitle)
		self.view_lastLoaded(html=False,autohtml=True)


	def writeMail_tmp(self):
		if self.selectedMail is None:
			return

		typ = self.pop3_Server.accounts[self.currentAccount]["Typ"]
		if (typ == "993" or typ == "995") and not pzyhave_ssl:
			self.setTitle(Pzymail_version + " -- No SSL In This Image -- Change Your Settings")
			return

		loadMailUidl = self.selectedMail[4]
		if typ == "143" or typ == "993":
			msgObject = self.pop3_Server.imap_load_Mail(loadMailUidl)
		else:
			msgObject = self.pop3_Server.load_Mail(loadMailUidl)

		if msgObject is not None:
			pzydir = self.pop3_Server.globalpzymailsettings["pzy_dir"]
			accountname = self.pop3_Server.currAccount
			file_Access = File_Access()
			file_Access.makeDefaultDirectory(pzydir)
			file_Access.makeDefaultDirectory(pzydir + accountname)
			blnOK = file_Access.writeCompleteMail(msgObject,pzydir + accountname + "/")
			if blnOK:
				text = "Mail Written"
			else:
				text = "Mail Not Written"
				
			self.setTitle(Pzymail_version + " -- " + _(text))
			defenc=self.pop3_Server.get_currdefaultEncoding()
			self.mailtitle = self.messageObject.get_decodedString(msgObject,defenc,"Subject")
				
		else:
			self.setTitle(Pzymail_version + " -- " + _("Connection FAILED"))


	def update_currentAccount(self):
		global pzyLCD
		global pzyhave_ssl

		if self.currentAccount is None:
			return

		typ = self.pop3_Server.accounts[self.currentAccount]["Typ"]
		if (typ == "993" or typ == "995") and not pzyhave_ssl:
			self.setTitle(Pzymail_version + " -- No SSL In This Image -- Change Your Settings")
			return

		if typ == "143" or typ == "993":
			self.imap_update_currentAccount()
			return

		if self.pop3_Server.pop3Object is not None:
			#if self.pop3_Server.currAccount != self.selectedAccount[0]: ##only if new account is selected
			self.pop3_Server._pop3_disconnect()

		self.pop3_Server.set_currentAccount(self.currentAccount)
		mailtuple = self.pop3_Server.get_mailHeaders()
		if mailtuple is not None:
			(list, count_newmails_String) = mailtuple
			self.count_newmails_String = count_newmails_String
			self.setTitle(Pzymail_version + " -- Mails Fetched: # " + str(self.count_newmails_String))
			pzyLCD.setText(" "*10 + "New Mails: " + str(self.count_newmails_String),3 )
			self.fillMenuList_A()
		else:
			self.setTitle(Pzymail_version + " -- Can Not Connect") #+ self.networkstatestr)
			self.pop3_Server.networkCheckedCallback(self.setNetworkTitle,True)
		#self.fillMenuList_A()

		
	def imap_update_currentAccount(self):
		mailtuple = self.pop3_Server.get_all_imapheaders()
		if mailtuple is not None:
			(list, count_newmails_String) = mailtuple
			self.count_newmails_String = count_newmails_String
			self.setTitle(Pzymail_version + " -- Mails Fetched: # " + str(self.count_newmails_String))
			pzyLCD.setText(" "*10 + "New Mails # " + str(pzynewmails),3)
			self.fillMenuList_A()
		else:
			self.setTitle(Pzymail_version + " -- Can Not Connect") # + self.networkstatestr)
			self.pop3_Server.networkCheckedCallback(self.setNetworkTitle,True)
		#self.fillMenuList_A()


	def update_allAccounts(self):
		global pzynewmails

		pzynewmails = 0

		ssl_error = self.pop3_Server.update_allAccounts()
		if ssl_error:
			self.setTitle(Pzymail_version + " -- Mails Fetched: # " + str(pzynewmails) + " -- SSL Is Not Supported In This Image -- Check Your Settings!")
		else:
			self.setTitle(Pzymail_version + " -- Mails Fetched: # " + str(pzynewmails))
		pzyLCD.setText(" "*10 + "New Mails # " + str(pzynewmails),3)

		self.fillMenuList_A()


	def name2Adressbook(self):
		if self.selectedAccount is None or self.selectedMail is None:
			return
		From = self.selectedMail[1]
		
		if From.find("<") == -1:
			adress = From
		else:
			name, adress = From.strip(">").split("<")

		adressBook = self.pop3_Server.get_adresses()
		adressBook.append(adress)
		adressBook.sort()
		self.pop3_Server.set_adresses(self.selectedAccount[0], adressBook)


	def replyTo(self):
		if self.selectedAccount is None or self.selectedMail is None:
			return
		mailtuple = self.selectedMail
		self.writeMail(mailtuple)

############################################################################################################################################################################

class EmailSetup(Screen, ConfigListScreen):
	def __init__(self, session, pop3_Server, globalsettings = False):
		Screen.__init__(self, session)
		
		self.session = session
		self.pop3_Server = pop3_Server
		self.onClose.append(self.abort)
		self.accountName = None
		self.configList = None
		self.globalsettings = globalsettings
		self.oldMarkedPos = 0

		self.onLayoutFinish.append(self.firstStart)

		self["config"] = ConfigList([])
		self["VKeyIcon"] = Pixmap()
		self["saveButton"] = Button(_("Save"))
		self["cancelButton"] = Button(_("Cancel"))
		
		self["dirButton"] = Button(_("Dir"))
		if globalsettings == False:
			self["dirButton"].hide()
			self["dirButton"].disable()

		self["actions"] = NumberActionMap(["ColorActions","SetupActions","VirtualKeyboardActions","ChannelSelectEPGActions"],
		                            {       "green": self.save_Configuration,
		                                    "cancel": self.Exit,
		                                    "red": self.Exit,
		                                    "blue": self.openFileBrowser,
		                                    "showEPGList": self.key_Info,
		                                    "1": self.keyNumberGlobal,
		                                    "2": self.keyNumberGlobal,
		                                    "3": self.keyNumberGlobal,
		                                    "4": self.keyNumberGlobal,
		                                    "5": self.keyNumberGlobal,
		                                    "6": self.keyNumberGlobal,
		                                    "7": self.keyNumberGlobal,
		                                    "8": self.keyNumberGlobal,
		                                    "9": self.keyNumberGlobal,
		                                    "0": self.keyNumberGlobal,
		                                    "ok": self.save_Configuration   }, 0)

		self.setTitle(Pzymail_version + " -- " + _("Setup") )
		config.pzymail = ConfigSubsection()
		config.pzymail.accounts = ConfigSubDict()

		self.accountName = self.pop3_Server.get_currentAccount()
		if self.accountName is None:
			self.accountName = "default"

		self.new_account(self.accountName)
		self.configList = self.fillConfigList(self.accountName)
		ConfigListScreen.__init__(self, self.configList)

		#########################################################################

	def firstStart(self):
		pass
	

	def openFileBrowser(self,multiFiles=False,dirmode=True):
		startdirList = []
		if self.globalsettings == False:
			return

		currentIndex = self["config"].getCurrentIndex()
		if currentIndex == 6:  #pzy_dir  (check autochangeConfListValue(), too)
			currentValue = self["config"].getCurrent()[1].getValue()
			sourcesTitle = _("Save Mails To:  ")
			selectedTitle = _("Selected-Directory")
			self.session.openWithCallback(self.__backPzyFileBrowser_MailDir, PzyFileBrowser, [currentValue],multiFiles, dirmode, sourcesTitle, selectedTitle,startdir=currentValue)

		#if currentIndex == 9:  #pzyStorageDir  (check autochangeConfListValue(), too)
			#currentValue = self["config"].getCurrent()[1].getValue()
			#sourcesTitle = _("HTML Cache Directory:  ")
			#selectedTitle = _("Selected-Directory")
			#self.session.openWithCallback(self.__backPzyFileBrowser_CacheDir, PzyFileBrowser, [currentValue],multiFiles, dirmode, sourcesTitle, selectedTitle,startdir=currentValue)

		elif currentIndex == 16:  #mp3 File  (check autochangeConfListValue(), too)
			currentValue = self["config"].getCurrent()[1].getValue()
			sourcesTitle = _("mp3 File:  ")
			selectedTitle = _("Selected-File")
			startdirList = currentValue.split("/")
			startdirList.pop()
			startdirectory = "/".join(startdirList) + "/"
			
			self.session.openWithCallback(self.__backPzyFileBrowser_mp3Path, PzyFileBrowser, [currentValue],multiFiles, False, sourcesTitle, selectedTitle,startdir=startdirectory)


	def __backPzyFileBrowser_MailDir(self,selectedList, selectedDir):
		global pzy_tmp_dir
		
		if selectedDir == "":
			selectedDir = pzy_tmp_dir
		config.pzymail.accounts[self.accountName]["pzy_dir"].value = selectedDir
		
		
	def __backPzyFileBrowser_mp3Path(self,selectedList, selectedFile):
		config.pzymail.accounts[self.accountName]["mp3Path"].value = selectedFile


	def VirtualKeyBoardCallback(self, callback = None):
		ConfigListScreen.VirtualKeyBoardCallback(self,callback)


	def key_Info(self):
		pass


	def keyOK(self):
		self.close()


	def keyLeft(self):
		ConfigListScreen.keyLeft(self)
		self.autochangeConfListValue()


	def keyRight(self):
		ConfigListScreen.keyRight(self)
		self.autochangeConfListValue()


	def keyNumberGlobal(self, number):
		ConfigListScreen.keyNumberGlobal(self,number)


	def keyGotAscii(self):
		ConfigListScreen.keyGotAscii(self)


	def autochangeConfListValue(self,accountName="test"):
		if self.globalsettings is True:
			self.configList = self.fillConfigList(self.accountName)

			currentIndex = self["config"].getCurrentIndex()
			#if currentIndex == 3:  #pzy_dir
					#self["dirButton"].show()
					#self["dirButton"].enable()
			#else:
					#self["dirButton"].hide()
					#self["dirButton"].disable()
				
			if currentIndex == 17:  #statistics  (check openFileBrowser(), too)
				self["config"].setList(self.configList)

		else:
			currentValue = self["config"].getCurrent()[1].getValue()
			
			if currentValue in ["110","995","143","993"]:
				config.pzymail.accounts[self.accountName]["port"].setValue(int(currentValue))
				self["config"].setList(self.configList)
		
			if currentValue == "587S":
				config.pzymail.accounts[self.accountName]["smtpport"].setValue(587)
				self["config"].setList(self.configList)	
				
			if currentValue in ["25","465","587"]:
				config.pzymail.accounts[self.accountName]["smtpport"].setValue(int(currentValue))
				self["config"].setList(self.configList)			
				

	def KeyText(self):
		self.session.openWithCallback(self.VirtualKeyBoardCallback, VirtualKeyBoard, title = self["config"].getCurrent()[0], text = self["config"].getCurrent()[1].getValue())

	#########################################################################

	def new_account(self,accountName):
		if self.accountName == "default":
			currdict = self.pop3_Server.get_default()
		else:
			currdict = self.pop3_Server.get_accountDict(self.accountName)
		self.currdict = currdict

		config.pzymail.accounts[accountName] = ConfigSubDict()

		if self.globalsettings:
			config.pzymail.accounts[accountName]["updateInStandby"]=NoSave(ConfigSelection(default = self.pop3_Server.globalpzymailsettings["updateInStandby"], choices=[("True","yes"), ("False","no")]))
			config.pzymail.accounts[accountName]["minutes"]=NoSave(ConfigInteger(default = int(self.pop3_Server.globalpzymailsettings["intervall"]),limits=(0,99999)))
			config.pzymail.accounts[accountName]["crypt"]=NoSave(ConfigSelection(default = self.pop3_Server.globalpzymailsettings["crypt"], choices=[("False","no"), ("True","yes")]))
			#config.pzymail.accounts[accountName]["imap_fastsync"]=NoSave(ConfigSelection(default = self.pop3_Server.globalpzymailsettings["imap_fastsync"], choices=[("True","yes"), ("False","no")]))
			config.pzymail.accounts[accountName]["pzyOnlyHeaders"]=NoSave(ConfigSelection(default = self.pop3_Server.globalpzymailsettings["pzyOnlyHeaders"], choices=[("True","yes"), ("False","no")]))
			config.pzymail.accounts[accountName]["redkeydelete"]=NoSave(ConfigSelection(default = self.pop3_Server.globalpzymailsettings["redkeydelete"], choices=[("True","yes"), ("False","no")]))
			config.pzymail.accounts[accountName]["defaultanswer"]=NoSave(ConfigSelection(default = self.pop3_Server.globalpzymailsettings["defaultanswer"], choices=[("False","no"), ("True","yes")]))
			config.pzymail.accounts[accountName]["pzy_dir"]=NoSave(ConfigText(default = self.pop3_Server.globalpzymailsettings["pzy_dir"], fixed_size=False, visible_width=55))
			config.pzymail.accounts[accountName]["swapoff"]=NoSave(ConfigSelection(default = self.pop3_Server.globalpzymailsettings["swapoff"], choices=[("True","yes"), ("False","no")]))
			config.pzymail.accounts[accountName]["enablewebview"]=NoSave(ConfigSelection(default = self.pop3_Server.globalpzymailsettings["enablewebview"], choices=[("True","yes"), ("False","no")]))
			config.pzymail.accounts[accountName]["persistent_storage"]=NoSave(ConfigSelection(default = self.pop3_Server.globalpzymailsettings["persistent_storage"], choices=[("False","no"), ("True","yes")]))
			#config.pzymail.accounts[accountName]["storage_dir"]=NoSave(ConfigText(default = self.pop3_Server.globalpzymailsettings["storage_dir"], fixed_size=False, visible_width=55))
			config.pzymail.accounts[accountName]["htmldefault"]=NoSave(ConfigSelection(default = self.pop3_Server.globalpzymailsettings["htmldefault"], choices=[("False","no"), ("True","yes")]))
			config.pzymail.accounts[accountName]["extendedInfoScreen"]=NoSave(ConfigSelection(default = self.pop3_Server.globalpzymailsettings["extendedInfoScreen"], choices=[("True","yes"), ("False","no")]))
			config.pzymail.accounts[accountName]["extendedLCD"]=NoSave(ConfigSelection(default = self.pop3_Server.globalpzymailsettings["extendedLCD"], choices=[("True","yes"), ("False","no")]))
			config.pzymail.accounts[accountName]["infoScreenAutoClose"]=NoSave(ConfigInteger(default = int(self.pop3_Server.globalpzymailsettings["infoScreenAutoClose"]),limits=(0,999)))
			config.pzymail.accounts[accountName]["infoScreenMaxRuns"]=NoSave(ConfigInteger(default = int(self.pop3_Server.globalpzymailsettings["infoScreenMaxRuns"]),limits=(0,99)))
			config.pzymail.accounts[accountName]["playmp3"]=NoSave(ConfigSelection(default = self.pop3_Server.globalpzymailsettings["playmp3"], choices=[("True","yes"), ("False","no")]))
			config.pzymail.accounts[accountName]["mp3Path"]=NoSave(ConfigText(default = self.pop3_Server.globalpzymailsettings["mp3Path"], fixed_size=False, visible_width=50))
			config.pzymail.accounts[accountName]["stats"]=NoSave(ConfigSelection(default = self.pop3_Server.globalpzymailsettings["stats"], choices=[("True","yes"), ("False","no")]))
			config.pzymail.accounts[accountName]["stat_del"]=NoSave(ConfigInteger(default = int(self.pop3_Server.globalpzymailsettings["stat_del"]),limits=(0,9999999999)))
			config.pzymail.accounts[accountName]["stat_load"]=NoSave(ConfigInteger(default = int(self.pop3_Server.globalpzymailsettings["stat_load"]),limits=(0,9999999999)))
			config.pzymail.accounts[accountName]["stat_sent"]=NoSave(ConfigInteger(default = int(self.pop3_Server.globalpzymailsettings["stat_sent"]),limits=(0,9999999999)))
			config.pzymail.accounts[accountName]["stat_view"]=NoSave(ConfigInteger(default = int(self.pop3_Server.globalpzymailsettings["stat_view"]),limits=(0,9999999999)))
		else:
			config.pzymail.accounts[accountName]["accountName"]=NoSave(ConfigText(default=self.accountName, fixed_size=False, visible_width=40))
			config.pzymail.accounts[accountName]["typ"]=NoSave(ConfigSelection(default=currdict["Typ"], choices=[("110","Pop3"), ("995","Pop3-SSL"), ("143","IMAP"), ("993","IMAP-SSL")]))
			config.pzymail.accounts[accountName]["smtptyp"]=NoSave(ConfigSelection(default=currdict["SMTP_Typ"], choices=[("25","SMTP"), ("465","SMTP-SSL"),("587","SMTP-587"),("587S","SMTP-587-SSL")]))
			config.pzymail.accounts[accountName]["server"]=NoSave(ConfigText(default=currdict["Server"], fixed_size=False, visible_width=40))
			config.pzymail.accounts[accountName]["smtpserver"]=NoSave(ConfigText(default=currdict["SMTP_Server"], fixed_size=False, visible_width=40))
			config.pzymail.accounts[accountName]["port"]=NoSave(ConfigInteger(default = int(currdict["Port"]),limits=(0,65000)))
			config.pzymail.accounts[accountName]["smtpport"]=NoSave(ConfigInteger(default = int(currdict["SMTP_Port"]),limits=(0,65000)))
			config.pzymail.accounts[accountName]["user"]=NoSave(ConfigText(default=currdict["User"], fixed_size=False, visible_width=40))
			config.pzymail.accounts[accountName]["passw"]=NoSave(ConfigText(default=currdict["Password"], fixed_size=False, visible_width=40))
			config.pzymail.accounts[accountName]["defenc"]=NoSave(ConfigSelection(default=currdict["DefaultEncoding"],choices=[("latin-1","latin-1"),("iso8859_1","iso8859_1"),("iso8859_2","iso8859_2"),("iso8859_15","iso8859_15"),("utf-8","utf-8")]))
			config.pzymail.accounts[accountName]["maxmess"]=NoSave(ConfigInteger(default = int(currdict["MaxMessages"]), limits=(1,999)))
			#config.pzymail.accounts[accountName]["stayconnected"]=NoSave(ConfigSelection(default=currdict["StayConnected"], choices=[("True","yes"), ("False","no")]))
			config.pzymail.accounts[accountName]["autoupdate"]=NoSave(ConfigSelection(default=currdict["Autoupdate"], choices=[("True","yes"), ("False","no")]))


	def fillConfigList(self,accountName):
		list = []
		if self.globalsettings:
			list.append(getConfigListEntry(_("Autoupdate in Standby") + ":", config.pzymail.accounts[accountName]["updateInStandby"]))
			list.append(getConfigListEntry(_("Autoupdate") + " " + _("Mails") + " [" + _("Minutes") + "]" + ":", config.pzymail.accounts[accountName]["minutes"]))
			list.append(getConfigListEntry(_("Save Settings Crypted") + ":", config.pzymail.accounts[accountName]["crypt"]))
			#list.append(getConfigListEntry(_("Imap FastSync") + ":", config.pzymail.accounts[accountName]["imap_fastsync"]))
			list.append(getConfigListEntry(_("Only Mail-Headers") + ":", config.pzymail.accounts[accountName]["pzyOnlyHeaders"]))
			list.append(getConfigListEntry(_("Erase Mails with 'red key'") + ":", config.pzymail.accounts[accountName]["redkeydelete"]))
			list.append(getConfigListEntry(_("Default Dialog Answer") + ":", config.pzymail.accounts[accountName]["defaultanswer"]))
			list.append(getConfigListEntry(_("Save Mail Directory") + ":", config.pzymail.accounts[accountName]["pzy_dir"]))
			list.append(getConfigListEntry(_("Disable Swaps") + ":", config.pzymail.accounts[accountName]["swapoff"]))
			list.append(getConfigListEntry(_("Enable Browser WebView") + ":", config.pzymail.accounts[accountName]["enablewebview"]))
			list.append(getConfigListEntry(_("Enable Browser Cache") + ":", config.pzymail.accounts[accountName]["persistent_storage"]))
			##if not config.pzymail.accounts[accountName]["persistent_storage"].value == "False":
			#list.append(getConfigListEntry(_("HTML Cache Directory") + ":", config.pzymail.accounts[accountName]["storage_dir"]))
			list.append(getConfigListEntry(_("Force HTML") + ":", config.pzymail.accounts[accountName]["htmldefault"]))
			list.append(getConfigListEntry(_("Extended InfoScreen") + ":", config.pzymail.accounts[accountName]["extendedInfoScreen"]))
			list.append(getConfigListEntry(_("Extended LCD") + ":", config.pzymail.accounts[accountName]["extendedLCD"]))
			list.append(getConfigListEntry(_("AutoClose InfoScreen") + " [" + _("Seconds") + "]"+ ":", config.pzymail.accounts[accountName]["infoScreenAutoClose"]))
			list.append(getConfigListEntry(_("InfoScreen MaxRuns") + " [" + _("Cycles") + "]"+ ":", config.pzymail.accounts[accountName]["infoScreenMaxRuns"]))
			list.append(getConfigListEntry(_("Play mp3 For New Mails") + ":", config.pzymail.accounts[accountName]["playmp3"]))
			list.append(getConfigListEntry(_("mp3-File For InfoScreen") + ":", config.pzymail.accounts[accountName]["mp3Path"]))
			
			if config.pzymail.accounts[accountName]["stats"].value == "True":
				list.append(getConfigListEntry(_("Statistics") + ":", config.pzymail.accounts[accountName]["stats"]))
				list.append(getConfigListEntry(_("Headers") + " " + _("Received") + ":", config.pzymail.accounts[accountName]["stat_load"]))
				list.append(getConfigListEntry(_("Mails") + " " +  _("Sent") + ":", config.pzymail.accounts[accountName]["stat_sent"]))
				list.append(getConfigListEntry(_("Mails") + " " +  _("Deleted") + ":", config.pzymail.accounts[accountName]["stat_del"]))
				list.append(getConfigListEntry(_("Mails") + " " +  _("Viewed") + ":", config.pzymail.accounts[accountName]["stat_view"]))
			else:
				list.append(getConfigListEntry(_("Statistics (reset to '0')") + ":", config.pzymail.accounts[accountName]["stats"]))
		else:
			list.append(getConfigListEntry(_("Accountname") + ":", config.pzymail.accounts[accountName]["accountName"]))
			list.append(getConfigListEntry(_("User") + ":", config.pzymail.accounts[accountName]["user"]))
			list.append(getConfigListEntry(_("Password") + ":", config.pzymail.accounts[accountName]["passw"]))
			list.append(getConfigListEntry(_("Pop3- / Imap-Server") + ":", config.pzymail.accounts[accountName]["server"]))
			list.append(getConfigListEntry(_("Pop3- / Imap-Typ") + ":", config.pzymail.accounts[accountName]["typ"]))
			list.append(getConfigListEntry(_("Pop3- / Imap-Port") + ":", config.pzymail.accounts[accountName]["port"]))
			list.append(getConfigListEntry(_("SMTP-Server") + ":", config.pzymail.accounts[accountName]["smtpserver"]))
			list.append(getConfigListEntry(_("SMTP-Typ") + ":", config.pzymail.accounts[accountName]["smtptyp"]))
			list.append(getConfigListEntry(_("SMTP-Port") + ":", config.pzymail.accounts[accountName]["smtpport"]))
			list.append(getConfigListEntry(_("Max Messsages") + ":", config.pzymail.accounts[accountName]["maxmess"]))
			list.append(getConfigListEntry(_("Default Encoding") + ":", config.pzymail.accounts[accountName]["defenc"]))
			#list.append(getConfigListEntry(_("Stay Connected") + ":", config.pzymail.accounts[accountName]["stayconnected"]))
			list.append(getConfigListEntry(_("Autoupdate") + " " + _("Mails") + ":", config.pzymail.accounts[accountName]["autoupdate"]))
		return list


	def save_Configuration(self):
		global pzyautopoller
		global pzyExtendedInfoScreen
		global pzyExtendedLCD
		global pzyautoClose
		global pzyinfoScreenMaxRuns
		global pzymp3Path
		global pzyPlaymp3
		global pzyOnlyHeaders
		global pzyDeleteYES
		global pzyPersistentStorage 
		#global pzyStorageDir
		global pzyhtmldefault
		global pzyswapoff
		global pzywebview

		valuelist = []
		for x in self["config"].list:
			x[1].save()
			valuelist.append(x[1].value)

		##parselist in Reihenfolge von ConfigList
		if self.globalsettings:
			parselist = ["updateInStandby", "Minutes", "crypt", "pzyOnlyHeaders", "redkeydelete", "defaultanswer", "pzy_dir", "swapoff", "enablewebview", "persistent_storage", "htmldefault", "extendedInfoScreen", "extendedLCD", "infoScreenAutoClose", "infoScreenMaxRuns", "playmp3", "mp3Path", "stats"]
		else:
			parselist = ["AccountName","User","Password","Server","Typ","Port","SMTP_Server","SMTP_Typ","SMTP_Port","MaxMessages","DefaultEncoding","Autoupdate"]
		newAccountDict = dict(zip(parselist,valuelist))

		if self.accountName == "default":
			newAccountDict.update( {  "LastCheck" : "11.11.1980     11:11" , "Adresses" : [] , "HeaderList" : []}  )
			self.currdict = newAccountDict
		else:
			self.currdict.update(newAccountDict)

		if self.globalsettings:
			self.pop3_Server.globalpzymailsettings["updateInStandby"] = newAccountDict["updateInStandby"]
			self.pop3_Server.globalpzymailsettings["crypt"] = newAccountDict["crypt"]
			#self.pop3_Server.globalpzymailsettings["imap_fastsync"] = newAccountDict["imap_fastsync"]
			self.pop3_Server.globalpzymailsettings["redkeydelete"] = newAccountDict["redkeydelete"]
			self.pop3_Server.globalpzymailsettings["defaultanswer"] = newAccountDict["defaultanswer"]
			self.pop3_Server.globalpzymailsettings["pzy_dir"] = newAccountDict["pzy_dir"]
			self.pop3_Server.globalpzymailsettings["swapoff"] = newAccountDict["swapoff"]
			self.pop3_Server.globalpzymailsettings["enablewebview"] = newAccountDict["enablewebview"]
			self.pop3_Server.globalpzymailsettings["persistent_storage"] = newAccountDict["persistent_storage"]
			##if not self.pop3_Server.globalpzymailsettings["persistent_storage"] == "False":
			#self.pop3_Server.globalpzymailsettings["storage_dir"] = newAccountDict["storage_dir"]
			#else:
				#self.pop3_Server.globalpzymailsettings["storage_dir"] = ""
			self.pop3_Server.globalpzymailsettings["htmldefault"] = newAccountDict["htmldefault"]
			
			self.pop3_Server.globalpzymailsettings["extendedInfoScreen"] = newAccountDict["extendedInfoScreen"]
			self.pop3_Server.globalpzymailsettings["extendedLCD"] = newAccountDict["extendedLCD"]
			self.pop3_Server.globalpzymailsettings["pzyOnlyHeaders"] = newAccountDict["pzyOnlyHeaders"]
			self.pop3_Server.globalpzymailsettings["infoScreenAutoClose"] = newAccountDict["infoScreenAutoClose"]
			self.pop3_Server.globalpzymailsettings["infoScreenMaxRuns"] = newAccountDict["infoScreenMaxRuns"]
			self.pop3_Server.globalpzymailsettings["playmp3"] = newAccountDict["playmp3"]
			self.pop3_Server.globalpzymailsettings["mp3Path"] = newAccountDict["mp3Path"]

			self.pop3_Server.globalpzymailsettings["stats"] = newAccountDict["stats"]
			if self.pop3_Server.globalpzymailsettings["stats"] == "False":
				self.pop3_Server.globalpzymailsettings["stat_load"] = "0"
				self.pop3_Server.globalpzymailsettings["stat_sent"] = "0"
				self.pop3_Server.globalpzymailsettings["stat_del"] = "0"
				self.pop3_Server.globalpzymailsettings["stat_view"] = "0"

			self.pop3_Server.globalpzymailsettings["intervall"] = newAccountDict["Minutes"]

			pzyautoClose = int(newAccountDict["infoScreenAutoClose"])
			pzyinfoScreenMaxRuns = int(newAccountDict["infoScreenMaxRuns"])
			pzymp3Path = newAccountDict["mp3Path"]

			if newAccountDict["extendedInfoScreen"] == "True":
				pzyExtendedInfoScreen = True
			else:
				pzyExtendedInfoScreen = False

			if newAccountDict["extendedLCD"] == "True":
				pzyExtendedLCD = True
			else:
				pzyExtendedLCD = False

			if newAccountDict["pzyOnlyHeaders"] == "True":
				pzyOnlyHeaders = True
			else:
				pzyOnlyHeaders = False

			if newAccountDict["playmp3"] == "True":
				pzyPlaymp3 = True
			else:
				pzyPlaymp3 = False

			if newAccountDict["defaultanswer"] == "True":
				pzyDeleteYES = True
			else:
				pzyDeleteYES = False

			if newAccountDict["swapoff"] == "True":
				pzyswapoff = True
			else:
				pzyswapoff = False
				
			if newAccountDict["enablewebview"] == "True":
				pzywebview = True
			else:
				pzywebview = False				
	
			if newAccountDict["persistent_storage"] == "True":
				pzyPersistentStorage = True
			else:
				pzyPersistentStorage = False
			
			if newAccountDict["htmldefault"] == "True":
				pzyhtmldefault = True
			else:
				pzyhtmldefault = False
				
			#pzyPersistentStorage = newAccountDict["persistent_storage"]
			#pzyStorageDir = newAccountDict["storage_dir"]
	
			autostart(1)
			autostart(0)
		else:
			self.pop3_Server.set_newAccountDict(self.currdict)
			if not pzynewmailsDict.has_key(valuelist[0]):
				pzynewmailsDict.update( { valuelist[0] : { "mailList": [] }})
		self.Exit()


	def abort(self):
		print "[PZYMAIL] ... Screen closed ..."


	def Exit(self):
		global pzyOE20
		global pzyWebNavigation
		global pzywebview
		global pzyboxcomment
		global pzyopera
		
		if pzyOE20 and pzywebview and not pzyWebNavigation:
			eMailViewString = "\n Without The Official OE2.0 Browser Plugin \n\n You Will Only Have Text2Html."
			self.session.open(EmailView,eMailViewString)
			
		elif pzyboxcomment=="vuplus" and pzywebview and not pzyopera:	
			eMailViewString = "\n Without Opera Browser In The hbbtv Plugin \n\n You Will Only Have Text2Html."
			self.session.open(EmailView,eMailViewString)

		self.close(True)

###################################################################################################################################################################

class EmailView(Screen):
	def __init__(self,session,mailtext="",msgObject=None,pop3_Server=None,title=""):
		Screen.__init__(self,session)

		self.messageObject = MessageObject()
		self.htmltext = ""
		self.session = session
		self.msgObject = msgObject
		self.pop3_Server = pop3_Server
		self.forcehtml =  False
		self.mailtext = mailtext
		self.mailtitle = title
		self.oldservice = None
		
		self["text"] = ScrollLabel(mailtext)
		self["actions"] = ActionMap(["WizardActions","MenuActions","ColorActions","ChannelSelectEPGActions"],
		                            {
		                                    "up": self.scrollLabelPageUp,
		                                    "down": self.scrollLabelPageDown,
		                                    "left": self.scrollLabelPageUp,
		                                    "right": self.scrollLabelPageDown,
		                                    "back": self.Exit,
		                                    "menu": self.KeyMenu,
		                                    "ok": self.show_attachmentList,
		                                    "green": self.toggleHtml,
		                                    "showEPGList": self.key_Info
		                                    }, -1)

		self.setTitle(Pzymail_version + " -- " + title )
		self.onFirstExecBegin.append(self.firststart)

		
	def firststart(self):
		global pzyhtmldefault
		if self.mailtext == "" or pzyhtmldefault:
			self.__backAttachmentView(html=True)
		
		
	def key_Info(self):
		pass


	def toggleHtml(self):
		self.forcehtml = not self.forcehtml
		if self.forcehtml:
			self.__backAttachmentView(html=True)
		else:
			self.__backAttachmentView(text=True)
			

	def scrollLabelPageUp(self):
		self["text"].pageUp()


	def scrollLabelPageDown(self):
		self["text"].pageDown()


	def Exit(self):
		self.close()


	def KeyMenu(self):
		if self.msgObject is None:
			return

		menu = [ (_("Toggle HTML / PlainText"), self.toggleHtml),
		         (_("Show Attachment-List"), self.show_attachmentList),
		         (("--", "")),
		         (_("Save Attachments To '/tmp/'"), self.save_attachments_tmp),
		         ((_("Save eMail To 'Mail Directory'"), self.save_eMail_tmp))  ]

		self.session.openWithCallback(
			self.menuCallback,
			cbx,
		        title = "Menu",
			list = menu,
		        
		        keys = ["1", "2", "", "3", "4"]
		)
		
		
	def menuCallback(self, ret):
		ret and ret[1]()
		
		
	def show_attachmentList(self):
		if self.msgObject is None:
			return
		self.session.openWithCallback(self.__backAttachmentView, AttachmentView, self.msgObject, self.pop3_Server)


	def __backAttachmentView(self,text=False,html=False):
		global pzyWebNavigation
		global pzywebview
		global pzyopera
		global pzy_tmp_dir
		
		if self.msgObject is None:
			return
				
		if html:
			if self.htmltext != "":
				self["text"].setText(self.htmltext)
				return
			
			messageObject=MessageObject()

			msgObject = self.pop3_Server.msgObject
			msgCharset_default=self.pop3_Server.get_currdefaultEncoding()
			if msgCharset_default is None:
				msgCharset_default="latin-1"
			msgCharset = messageObject.get_msgObject_Charset(msgObject,msgCharset_default)
			msgObject_PlainText_String = messageObject.get_msgObject_PlainText(msgObject,html)
			
			if pzyWebNavigation and pzywebview:
				eMailViewString = messageObject.msgStringConvert(msgObject_PlainText_String, msgCharset, "latin-1") #msgString_output_encoding="utf-8" #ok f�r WebNavigation
			else:
				eMailViewString = messageObject.msgStringConvert(msgObject_PlainText_String, msgCharset, "utf-8") #msgString_output_encoding="utf-8" #ok
			
			if eMailViewString is None:
				eMailViewString = messageObject.msgStringConvert(msgObject_PlainText_String, msgCharset_default, "utf-8")

			messageObject=None
			
			if eMailViewString is None:
				eMailViewString = msgObject_PlainText_String
			if eMailViewString is not None:
				eMailViewString = eMailViewString.strip()
				
				if pzyWebNavigation and pzywebview:
					self.session.openWithCallback(self.__backHTMLview,HTMLview,self.mailtitle,eMailViewString)
					
					
				elif pzyopera and pzywebview:
					self.save_attachments_tmp()
					
					if exists(pzy_tmp_dir + "mailpart-001.html"):
						filepath="file://%smailpart-001.html" %pzy_tmp_dir
						
					elif exists(pzy_tmp_dir + "mailpart-002.html"): 
						filepath="file://%smailpart-002.html" %pzy_tmp_dir
						
					else:
						filepath="file://%smailpart-001.txt" %pzy_tmp_dir
						
					if pzyopera_2015_05:
						self.session.openWithCallback(self.clearBrowserData, Browser, filepath)
					else:							
						setPluginBrowser(self.session.openWithCallback(self.clearBrowserData, OperaBrowser, filepath, False))
				
				else:
					try:
						htmlMailViewString = html2text(eMailViewString, "")
						eMailViewString = htmlMailViewString.encode("utf8","replace")
						self.htmltext = eMailViewString
					except:
						print "[PZYMAIL] HTML Error"
						eMailViewString = msgObject_PlainText_String
			else:
				eMailViewString = ""
			###self.mailtext=eMailViewString
			if (not pzyWebNavigation and not pzyopera) or not pzywebview:
				self["text"].setText(eMailViewString)
		
		elif text:
			self["text"].setText(self.mailtext)
			
	
	def clearBrowserData(self):
		global pzy_tmp_dir
		
		c = ShellCommands()
		str_cmd="rm -fR %s*" %pzy_tmp_dir
		c.cmdlist=[str_cmd]
		c.executeCmdList()

	
	def __backHTMLview(self):
		self.forcehtml = False
			
	############################################################################################################################################

	def save_eMail_tmp(self):
		if self.msgObject is None:
			return
		accountname = self.pop3_Server.currAccount
		if accountname is None:
			print "[PZYEMAIL] ... No Account Selected, Not Written ..."
			return
		
		accountname = accountname.replace("/","").replace("\\","")
		pzydir = self.pop3_Server.globalpzymailsettings["pzy_dir"]
		file_Access = File_Access()
		file_Access.makeDefaultDirectory(pzydir)
		file_Access.makeDefaultDirectory(pzydir + accountname)
		file_Access.writeCompleteMail(self.msgObject,pzydir + accountname + "/")


	def save_attachments_tmp(self):
		if self.msgObject is None:
			return
		file_Access = File_Access()
		file_Access.saveAttachments(self.msgObject)

###################################################################################################################################################################

class AttachmentView(Screen):
	def __init__(self,session,msgObject,pop3_Server):
		Screen.__init__(self,session)

		self.session = session
		self.msgObject = msgObject
		self.pop3_Server = pop3_Server
		
		self["Attachment_List"] = SkinableMenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		
		self["actions"] = ActionMap(["PiPSetupActions","MenuActions","ColorActions","ChannelSelectEPGActions"],
		                            {
		                                    "up": self.menuListUp,
		                                    "down": self.menuListDown,
		                                    "left": self.menuListPageUp,
		                                    "right": self.menuListPageDown,
		                                    "cancel": self.Exit,
		                                    "showEPGList": self.key_Info,
		                                    "ok": self.openPlayers
		                                    }, -1)

		self.setTitle(Pzymail_version + " -- " + _("Attachment") + " " + _("Viewer") )
		self.onLayoutFinish.append(self.firstStart)
		
	##########################################################################################################################################	Start

	def firstStart(self):
		if self.msgObject is None:
			self.Exit()
			return
		
		self.messageObject = MessageObject()
		attachmentList = self.messageObject.getAttachmentList(self.msgObject)
		self["Attachment_List"].setList(self.list2tuplelist(attachmentList))
		self["Attachment_List"].moveToIndex(0)			

		
	def list2tuplelist(self,list):
		lst = []
		for el in list:
			lst.append((el,None))
		return lst
	
	
	def key_Info(self):
		pass


	def menuListPageUp(self):
		self["Attachment_List"].pageUp()


	def menuListPageDown(self):
		self["Attachment_List"].pageDown()


	def menuListUp(self):
		self["Attachment_List"].up()


	def menuListDown(self):
		self["Attachment_List"].down()

		
	def clearBrowserData(self):
		pass
	
	
	def openPlayers(self):
		global pzy_tmp_dir
		global pzyopera
		
		filename = self["Attachment_List"].getCurrent()[0]
		namepartList=[]
		namepartList = filename.split(".")
		namepartList.reverse()
		ext = namepartList[0]
		ext = ext.lower()
		
		mediaList_pics = ["jpg","gif","jpeg","jpe","png","bmp"]
		
		mediaList_dreamExplorer = ["ts","m2ts","mp3","wav","ogg","jpg","jpeg","jpe","png","bmp","mpg","mpeg","mkv","mp4","mov","divx","avi","mp2","m4a","flac","ifo","vob","iso"]

		mediaList_MediaPlayer = ["mp2","mp3","ogg","ts","m2ts","wav","wave","m3u","pls","e2pls","mpg","vob","avi","divx","m4v","mkv","mp4","m4a","dat","flac","mov","m3u","e2pls","pls"]

		mediaList_Opera = ["txt","cfg","htm","html","xml","mht"]
		
		mediaList_Opera.extend(mediaList_pics)
		
		if ext == "ksh":
			pass
		
		if filename == pzy_tmp_dir + "mailpart-001.txt":
			self.Exit(text=True)
			
		elif ext == "html":
			self.Exit(html=True)

		elif ext in mediaList_Opera and pzyopera:
			file_Access = File_Access()
			file_Access.saveAttachments(self.msgObject)
			
			if exists(filename):
				filepath="file://%s" %filename
			else:
				filepath = ""
			
			if pzyopera_2015_05:
				self.session.openWithCallback(self.clearBrowserData, Browser, filepath)
			else:					
				setPluginBrowser(self.session.openWithCallback(self.clearBrowserData, OperaBrowser, filepath, False))  # ins hauptprg verschieben
			
			
		elif ext in mediaList_pics:
			if exists("/usr/lib/enigma2/python/Plugins/Extensions/PicturePlayer/plugin.pyo"):
				file_Access = File_Access()
				file_Access.saveAttachments(self.msgObject)
				from Plugins.Extensions.PicturePlayer.plugin import picshow
				self.session.open(picshow)

		elif ext in mediaList_MediaPlayer:
			if exists("/usr/lib/enigma2/python/Plugins/Extensions/MediaPlayer/plugin.pyo"):
				file_Access = File_Access()
				file_Access.saveAttachments(self.msgObject)
				from Plugins.Extensions.MediaPlayer.plugin import MediaPlayer
				self.session.open(MediaPlayer)

		elif ext in mediaList_dreamExplorer:
			if exists("/usr/lib/enigma2/python/Plugins/Extensions/DreamExplorer/plugin.pyo"):
				from Plugins.Extensions.DreamExplorer.plugin import DreamExplorerII
				file_Access = File_Access()
				file_Access.saveAttachments(self.msgObject)
				self.session.open(DreamExplorerII)

		elif exists("/usr/lib/enigma2/python/Bp/BPBrowser.pyo"):
			file_Access = File_Access()
			file_Access.saveAttachments(self.msgObject)
			from Bp.BPBrowser import BPBrowser
			self.session.open(BPBrowser)
		else:
			self.setTitle(Pzymail_version + " -- " + _("Please install a suitable plugin for this extension") )


	def __backEmailView(self):
		pass


	def Exit(self,text=False,html=False):
		self.close(text,html)

###################################################################################################################################################################

class Pop3_Server(object):
	def __init__(self, session=None):
		global pzy_tmp_dir
		
		self.nooptimer = eTimer()
		self.nooptimer_conn = None
		
		self.connectType = None
		self.on_connected = []
		self.on_disconnected = []
		
		self.bln_networkOK = False
		self.bln_updatingNetworkState = True

		self.timer = eTimer()
		self.timer_conn = None
		
		self.callback = []
		self.conf = Configuration()
		self.pop3Object = None
		self.imapObject = None
		self.smtpObject = None
		self.msgObject = None
		self.stayConnected = True
		self.currAccount = None
		self.accounts = {}
		self.currUidlDict = {}
		self.currUidlList = []
		self.imapalluidList = []
		self.imapsinceuidList = []
		self.newmailtuplesList = []
		self.nottoscrollList = []
		
		self.sortindex = 0 
		
		
		self.cb = None #test
		self.ssl_error = False #test
		self.lst = [] #test
		self.cb_timer = eTimer()
		self.cb_timer_conn = None
		
		
		self.globalpzymailsettings = {"updateInStandby": "False",
		                              "intervall" : "0",
		                              "crypt" : "False",
		                              "imap_fastsync" : "True",
		                              "pzyOnlyHeaders" : "False",
		                              "redkeydelete" : "False",
		                              "defaultanswer" : "False",
		                              "pzy_dir" : pzy_tmp_dir,
		                              "swapoff" : "True",
		                              "enablewebview" : "True",
		                              "persistent_storage" : "False",
		                              #"storage_dir" : pzyStorageDir,
		                              "htmldefault" : "False",
		                              "extendedInfoScreen" : "True",
		                              "extendedLCD" : "True",
		                              "infoScreenAutoClose" : "0",
		                              "infoScreenMaxRuns" : "0",
		                              "playmp3" : "False",
		                              "mp3Path" : "/",
		                              "stats" : "True",
		                              "stat_load" : "0",
		                              "stat_sent" : "0",
		                              "stat_del" : "0",
		                              "stat_view" : "0"  }

		self.defaults = { "default" : { "Typ" : "995",
		                                "Server" : "pop.nix.net",
		                                "SMTP_Server" : "smtp.nix.net",
		                                "SMTP_Port" : 25,
		                                "SMTP_Typ" : "25",
		                                "Port" : 995,
		                                "User" : "me@nix.net",
		                                "Password" : "secret",
		                                "DefaultEncoding" : "latin-1",
		                                "MaxMessages" :50,
		                                "Checktime" : 60,
		                                "LastCheck" : "11.11.1980     11:11",
		                                "HeaderList":[],
		                                "Adresses":[],
		                                "StayConnected" : "True",
		                                "Autoupdate" : "False"  }  }

		if not pzy_bln_DreamOS:
			iNetwork.checkNetworkState(self._checkNetworkCB)
		else:
			if iNetworkInfo.isOnline():
				self.bln_networkOK = True
			else:
				self.bln_networkOK = False
			self.bln_updatingNetworkState = False
				
		#self.bln_networkOK = True
	

	def autonoop(self):
		if self.connectType == "pop3":
			self._pop3_connect()
			
		elif self.connectType == "imap":
			self._imap_connect()
			
		elif self.connectType == "smtp":
			self._smtp_connect()
			
		else:
			self.nooptimer.stop()
			if not pzy_bln_DreamOS:
				if self.autonoop in self.nooptimer.callback:
					self.nooptimer.callback.remove(self.autonoop)
			else:
				self.nooptimer_conn = None
			return
		
		self.nooptimer.stop()	
		self.nooptimer.startLongTimer(30)
		
		
	def _checkNetworkCB(self,data=None):
		self.bln_networkOK = False
		
		if data is not None:
			if data < 3:
				self.bln_networkOK = True
			
		self.bln_updatingNetworkState = False
		
		
	def networkCheckedCallback(self,callback=None,check=False):
		if not callback is None:
			if callback not in self.callback:
				self.callback.append(callback)
			
			if check:
				self.bln_updatingNetworkState = True
				if not pzy_bln_DreamOS:
					iNetwork.checkNetworkState(self._checkNetworkCB)
				else:
					if iNetworkInfo.isOnline():
						self.bln_networkOK = True
					else:
						self.bln_networkOK = False
					self.bln_updatingNetworkState = False
			
		if self.bln_updatingNetworkState:
			if not pzy_bln_DreamOS:
				if self.networkCheckedCallback not in self.timer.callback:
					self.timer.callback.append(self.networkCheckedCallback)
			else:
				self.timer_conn = self.timer.timeout.connect(self.networkCheckedCallback)			

			self.timer.start(100)
			return
		
		self.timer.stop()
		for fnc in self.callback:
			fnc(self.bln_networkOK)
		self.callback=[]
	
		
	def get_currdefaultEncoding(self):
		if self.currAccount is not None:
			return self.accounts[self.currAccount]["DefaultEncoding"]
		else:
			return None


	def read_cfg(self):
		global pzyExtendedLCD
		global pzyExtendedInfoScreen
		global pzyautoClose
		global pzyinfoScreenMaxRuns
		global pzymp3Path
		global pzyPlaymp3
		global pzyOnlyHeaders
		global pzyDeleteYES
		global pzyPersistentStorage
		global pzyhtmldefault
		#global pzyStorageDir
		global pzyswapoff
		global pzywebview
		
		confdict = self.conf.read_cfg()
		#print "[PZYMAIL] ####confdict",confdict
		if confdict.has_key("globalpzymailsettings"):
			self.globalpzymailsettings.update (confdict["globalpzymailsettings"])
			if self.globalpzymailsettings["extendedInfoScreen"] == "True":
				pzyExtendedInfoScreen = True
			else:
				pzyExtendedInfoScreen = False

			if self.globalpzymailsettings["extendedLCD"] == "True":
				pzyExtendedLCD = True
			else:
				pzyExtendedLCD = False

			if self.globalpzymailsettings["pzyOnlyHeaders"] == "True":
				pzyOnlyHeaders = True
			else:
				pzyOnlyHeaders = False
				
			if self.globalpzymailsettings["defaultanswer"] == "True":
				pzyDeleteYES = True
			else:
				pzyDeleteYES = False	
				
			if self.globalpzymailsettings["swapoff"] == "True":
				pzyswapoff = True
			else:
				pzyswapoff = False				
				
			if self.globalpzymailsettings["enablewebview"] == "True":
				pzywebview = True
			else:
				pzywebview = False					

			if self.globalpzymailsettings["persistent_storage"] == "True":
				pzyPersistentStorage = True
			else:
				pzyPersistentStorage = False
				
			if self.globalpzymailsettings["htmldefault"] == "True":
				pzyhtmldefault = True
			else:
				pzyhtmldefault = False			
				
			#pzyStorageDir = self.globalpzymailsettings["storage_dir"]
			pzyautoClose = int(self.globalpzymailsettings["infoScreenAutoClose"])
			pzyinfoScreenMaxRuns = int(self.globalpzymailsettings["infoScreenMaxRuns"])
			pzymp3Path = self.globalpzymailsettings["mp3Path"]
			
			if self.globalpzymailsettings["playmp3"] == "True":
				pzyPlaymp3 = True
			else:
				pzyPlaymp3 = False

			confdict.pop("globalpzymailsettings")
		self.accounts.update(confdict)

		if self.accounts == {}:          ##add defaults if accounts = {}
			print "[PZYMAIL] read_cfg  {} ... appending defaults ..."
			self.accounts.update(self.defaults)
			pzynewmailsDict.update({"default" : { "mailList" : [] } })


	def write_cfg(self):
		self.conf.write_cfg()


	def set_cfg_allAccounts_dict(self):
		self.conf.set_cfg_allAccounts_dict(self.accounts)
		self.conf.set_cfg_globalpzymailsettings_dict(self.globalpzymailsettings)


	def get_default(self):
		return self.defaults["default"]


	def get_msgObject(self):
		return self.msgObject


	def set_msgObject(self,msgObject=None):
		self.msgObject = msgObject

		
	def get_status(self):
		global pzySelectedAccountColor
		global pzyConnectedAccountColor
		
		sortedAccountList=[]
		accounts_List=self.accounts.items()
		for account_dict_list in accounts_List:
			accountname=account_dict_list[0]
			sortedAccountList.append(accountname)
		sortedAccountList.sort()
		
		statusList = []
		for account in sortedAccountList:
			message_num = str(len(self.accounts[account]["HeaderList"]))
			message_num_new = str(len(pzynewmailsDict[account]["mailList"]))
			str_checked = str(self.accounts[account]["LastCheck"])
			menuEntry = (account,self.currAccount,message_num,message_num_new,str_checked,self.connectType)
			statusList.append(menuEntry)
		return statusList

	
	def getSorted(self,item):
		#1,2
		if self.sortindex == 1:
			ritem = item[1].replace('"',"").upper() + str(9999999999-item[0]).rjust(10)
		
		elif self.sortindex == 2:
			ritem = item[2].upper().lstrip() + str(9999999999-item[0]).rjust(10)
		
		else:
			ritem = item[self.sortindex]
			
		return ritem
	
	
	def get_mailList(self,account=None,sortindex=0,itemsize=(1200,90)):
		if self.currAccount is None:
			return []

		if account is not None:
			headerList = self.accounts[account]["HeaderList"]
		else:
			headerList = self.accounts[self.currAccount]["HeaderList"]

		self.sortindex = sortindex
		if sortindex > 0 and sortindex < 4:
			sortedlist = sorted(headerList,key=self.getSorted)
		else:
			sortedlist = headerList			

		return sortedlist


	def get_headerList(self, account=None):
		if account is None:
			headerList = self.accounts[self.currAccount]["HeaderList"]
		else:
			headerList = self.accounts[account]["HeaderList"]
		return headerList


	def get_adresses(self, account=None):
		if account is None:
			if self.currAccount is None:
				return ["me@nix.net"]
			adresses = self.accounts[self.currAccount]["Adresses"]
		else:
			if account == "default":
				adresses = self.defaults["default"]["Adresses"]
			else:
				adresses = self.accounts[account]["Adresses"]
		adressBook = adresses[:]
		return adressBook


	def set_adresses(self, account=None, adressList=[]):
		if account is None:
			return False
		self.accounts[account]["Adresses"] = adressList
		return True


	def set_lastCheck(self, account=None):
		lastCheck = strftime("%d.%m.%Y     %H:%M", localtime())
		if account is None:
			self.accounts[self.currAccount]["LastCheck"] = strftime("%d.%m.%Y     %H:%M", localtime())
		else:
			self.accounts[account]["LastCheck"] = strftime("%d.%m.%Y     %H:%M", localtime())


	def set_newAccountDict(self,dictionary={}):
		accountName = dictionary["AccountName"]
		if self.accounts.has_key(accountName):
			self.accounts[accountName].update(dictionary)
		else:
			self.accounts[accountName] = dictionary
		self.conf.set_cfg_singleAccount_dict(key=accountName,dictionary=dictionary)
		return accountName,dictionary


	def get_accountDict(self,accountName=None):
		if accountName is None:
			return
		dictionary = self.accounts[accountName]
		return dictionary


	def delete_Account(self,AccountName=None):
		if self.currAccount == AccountName:
			self.currAccount = None
		if self.accounts.has_key(AccountName):
			del self.accounts[AccountName]
			statusList = self.get_status()
			if statusList == []:
				self.currAccount = None
			return True
		else:
			print "[PZYMAIL] ..." + AccountName + " is not in the dictionary..."
		return False


	def update_allAccounts(self, from_autostart=False):
		global pzynewmails
		ssl_error = False

		storecurrAccount = self.currAccount
		for accountName in self.accounts:
			if accountName is not None:
				print "[PZYMAIL] Account: ",accountName
				autoUpdate = self.accounts[accountName]["Autoupdate"]
				if (from_autostart) and (autoUpdate == "False"):
					print "[PZYMAIL] ####### Nothing To Do #######"
				else:
					self.set_currentAccount(accountName)

					typ = self.accounts[self.currAccount]["Typ"]
					if (typ == "993" or typ == "995") and not pzyhave_ssl:
						ssl_error = True
						continue

					if typ == "143" or typ == "993":
						if self.imapObject is not None:
							self._imap_disconnect()

						self._imap_connect()
						oldpzynewmails = pzynewmails
						self.get_all_imapheaders(from_autostart=from_autostart)
						pzynewmails = pzynewmails + oldpzynewmails
						self._imap_disconnect()
					else:
						if self.pop3Object is not None:
							self._pop3_disconnect()

						self._pop3_connect()
						oldpzynewmails = pzynewmails
						self.get_mailHeaders(from_autostart=from_autostart)
						pzynewmails = pzynewmails + oldpzynewmails
						self._pop3_disconnect()
		self.currAccount = storecurrAccount
		return ssl_error

	#############################################
	
	# polling with eTimer can avoid spinner on a fast network (2..n accounts)
	def update_allAccounts_timer_buildList(self,cb=None):
		self.cb = cb
		self.ssl_error = False

		lst = []
		for accountName in self.accounts:
			if accountName is not None:
				lst.append(accountName)
		self.lst = lst
		self.update_allAccounts_timer()
				
		
	def update_allAccounts_timer(self,state=0):		
		global pzynewmails
		
		ssl_error = False
		if len(self.lst) > 0:
			storecurrAccount = self.currAccount
			accountName = self.lst[0]
			if accountName is not None:
				print "[PZYMAIL] Account: ",accountName
				autoUpdate = self.accounts[accountName]["Autoupdate"]
				if (autoUpdate == "False"):
					print "[PZYMAIL] ####### Nothing To Do #######"
				else:
					self.set_currentAccount(accountName)

					typ = self.accounts[self.currAccount]["Typ"]
					if (typ == "993" or typ == "995") and not pzyhave_ssl:
						ssl_error = True

					if not ssl_error:
						if typ == "143" or typ == "993":
							if self.imapObject is not None:
								self._imap_disconnect()
	
							self._imap_connect()
							oldpzynewmails = pzynewmails
							self.get_all_imapheaders(from_autostart=True)
							pzynewmails = pzynewmails + oldpzynewmails
							self._imap_disconnect()
						else:
							if self.pop3Object is not None:
								self._pop3_disconnect()
	
							self._pop3_connect()
							oldpzynewmails = pzynewmails
							self.get_mailHeaders(from_autostart=True)
							pzynewmails = pzynewmails + oldpzynewmails
							self._pop3_disconnect()
			self.lst.pop(0)
			self.currAccount = storecurrAccount
			
			if not pzy_bln_DreamOS:
				if self.update_allAccounts_timer not in self.cb_timer.callback:
					self.cb_timer.callback.append(self.update_allAccounts_timer)
			else:
				self.cb_timer_conn = self.cb_timer.timeout.connect(self.update_allAccounts_timer)

			self.cb_timer.startLongTimer(1) #1 sec. delay to avoid spinner
			#self.cb_timer.start(500) #500 msec. delay to avoid spinner
		else:
			if self.cb:
				self.cb_timer.stop()
				if not pzy_bln_DreamOS:
					if self.update_allAccounts_timer in self.cb_timer.callback:
						self.cb_timer.callback.remove(self.update_allAccounts_timer)
				else:
					self.cb_timer_conn = None			

				self.cb_timer = None
				self.cb()
		
	#############################################		

	
	def get_currentAccount(self):
		return self.currAccount


	def set_currentAccount(self,AccountName=None):
		self.currAccount = AccountName

	##########################################################################

	def is_connected(self):
		if self.pop3Object is None:
			return False
		return True


	def _pop3_connect(self):
		global debuglevelnr

		if self.pop3Object is not None:
			print "[PZYMAIL] ... Pop3 Connection Already Exists ..."
			try:
				self.pop3Object.sock.settimeout(10)
				print "[PZYMAIL] NOOP ",self.pop3Object.noop()
				self.pop3Object.sock.settimeout(120)
				return self.pop3Object
			except:
				print "\n[PZYMAIL] ... Connection Lost ..."
				print "\n[PZYMAIL] ... Reconnecting ..."
				self.pop3Object = None
			
		if not self.bln_networkOK:
			return None
		
		self.set_stayConnected()
		print "\n[PZYMAIL] ... connecting to pop3 server ...\n"
		popserverhost = self.accounts[self.currAccount]["Server"]
		popserverport = self.accounts[self.currAccount]["Port"]
		popservermode = self.accounts[self.currAccount]["Typ"]
		try:
			if popservermode == "995":
				pop3Object = POP3_SSL(popserverhost, popserverport)
				print "[PZYMAIL] POP3_SSL -- Port: ",popserverport
			else:
				pop3Object = POP3(popserverhost, popserverport)
				print "[PZYMAIL] POP3 -- Port: ",popserverport
			pop3Object.sock.settimeout(10)
			pop3Object.set_debuglevel(debuglevelnr)
			print pop3Object.getwelcome()
		except:
			print "\n[PZYMAIL] poplib.POP3(_SSL) Server Error\n"
			self.pop3Object = None
			return None
		try:
			popuser = self.accounts[self.currAccount]["User"]
			pop3Object.user(popuser)
		except:
			print "\n[PZYMAIL] Popuser Name Error \n"
			self.pop3Object = None
			return None
		try:
			poppass = self.accounts[self.currAccount]["Password"]
			pop3Object.pass_(poppass)
		except:
			print "\n[PZYMAIL] Popuser Password Error\n"
			self.pop3Object = None
			return None
		print "\n[PZYMAIL] ... connected ...\n"

		pop3Object.sock.settimeout(120)
		self.pop3Object = pop3Object
		self.currUidlDict = self._get_uidlDict()
		self.connectType = "pop3"
		
		if not pzy_bln_DreamOS:
			if self.autonoop not in self.nooptimer.callback:
				self.nooptimer.callback.append(self.autonoop)
		else:
			self.nooptimer_conn = self.nooptimer.timeout.connect(self.autonoop)

		self.nooptimer.startLongTimer(30)
		for fnc in self.on_connected:
			fnc()		
		return pop3Object


	def _pop3_disconnect(self):
		if self.pop3Object is None:
			print "[PZYMAIL] ... pop3 connection is already closed ..."
			return True
		try:
			self.pop3Object.sock.settimeout(10)
			self.pop3Object.quit()
		except:
			print "\n[PZYMAIL] ... pop3 cannot disconnect ... Error \n"
			self.pop3Object = None
			return False
		print "\n[PZYMAIL] ... pop3 Postbox unlocked ...\n"
		
		self.connectType = None
		self.nooptimer.stop()
		
		if not pzy_bln_DreamOS:
			if self.autonoop in self.nooptimer.callback:
				self.nooptimer.callback.remove(self.autonoop)
		else:
			self.nooptimer_conn = None
			
		self.pop3Object = None
		for fnc in self.on_disconnected:
			fnc()		
		return True


	def _imap_disconnect(self):
		if self.imapObject is None:
			print "[PZYMAIL] ... imap connection is already closed ..."
			return True
		try:
			self.imapObject.sock.settimeout(10)
			self.imapObject.close()
			self.imapObject.logout()
		except:
			print "\n[PZYMAIL] ... imap cannot disconnect ... Error \n"
			self.imapObject = None
			return False
		print "\n[PZYMAIL] ... imap Postbox unlocked ...\n"
		
		self.connectType = None
		self.nooptimer.stop()
		if not pzy_bln_DreamOS:
			if self.autonoop in self.nooptimer.callback:
				self.nooptimer.callback.remove(self.autonoop)
		else:
			self.nooptimer_conn = None

		self.imapObject = None
		for fnc in self.on_disconnected:
			fnc()		
		return True

	############################################################################

	def get_loaded_uidl_list(self):
		uidl_list = []
		for element in self.accounts[self.currAccount]["HeaderList"]:
			uidl = element[4]
			uidl_list.append(uidl)
		return uidl_list


	def set_stayConnected(self):
		#if self.accounts[self.currAccount]["StayConnected"] == "True":
			#self.stayConnected = True
			#print "[PZYMAIL] set_stayConnected: True"
		#else:
			#self.stayConnected = False
			#print "[PZYMAIL] set_stayConnected: False"
		self.stayConnected = True #v0.7.3
		

	def get_mailHeaders(self,default_enc=None,from_autostart=False):
		global pzynewmails
		global pzynewmailsDict
		global pzynewmailsList
		global pzynewmailsListAccounts
		global pzymsgs
		global pzyOnlyHeaders

		self._pop3_connect()
		if not self.is_connected():
			pzynewmails = 0
			return None
		messageObject = MessageObject()
		uidl_list = self.get_loaded_uidl_list()
		maxmess = int(self.accounts[self.currAccount]["MaxMessages"])
		pop3uidlList = self.currUidlList[:]
		pop3uidlList.reverse()
		pop3uidlList = pop3uidlList[0:maxmess]
		newmailindexList = []
		for pair in pop3uidlList:
			msgnum, uidl = pair.split( )
			if not uidl in uidl_list:
				newmailindexList.append((int(msgnum),uidl))
		newmailindexList.sort()
		newmailindexList.reverse() ##h�chste msgnr zuerst
		count_newmails = len(newmailindexList)
		count_newmails_String = str(count_newmails)

		newmailsList = []
		pzynewmailsListAccounts2 = []
		pzymsgs2 = []

		if self.accounts[self.currAccount]["HeaderList"] != []:
			lowestIndex = self.accounts[self.currAccount]["HeaderList"][-1][0]
		else:
			lowestIndex = 0

		for (mailindex,uidl) in newmailindexList:
			try:
				if pzyOnlyHeaders or not from_autostart or lowestIndex > int(mailindex):
					msgString = "\r\n".join(self.pop3Object.top(str(mailindex),0)[1])
				else:
					msgString = "\r\n".join(self.pop3Object.retr(mailindex)[1])
			except:
				print "\n[PZYMAIL] Mail receive Error \n"
				self._pop3_disconnect()
				return None
			msgObject = message_from_string(msgString)
			if default_enc is None:
				default_enc = self.accounts[self.currAccount]["DefaultEncoding"]
			subject = messageObject.get_decodedString(msgObject,default_enc,"Subject")
			print "\n[PZYMAIL] SUBJECT :  ",subject
			msgFrom = messageObject.get_decodedString(msgObject,default_enc,"From")
			msgTime = msgObject.get("Date")
			newmailsList.append((mailindex,msgFrom,subject,msgTime,uidl))

			if not int(mailindex) < lowestIndex:
				pzynewmailsListAccounts2.append(self.currAccount)
			if not pzyOnlyHeaders and not int(mailindex) < lowestIndex:
				#pzymsgs.append(msgObject)
				msgCharset_default=self.get_currdefaultEncoding()
				msgCharset = messageObject.get_msgObject_Charset(msgObject,msgCharset_default)
				msgObject_PlainText_String = messageObject.get_msgObject_PlainText(msgObject)
				eMailViewString = messageObject.msgStringConvert(msgObject_PlainText_String, msgCharset, "utf-8") #msgString_output_encoding="utf-8"
				if eMailViewString is None:
					eMailViewString = messageObject.msgStringConvert(msgObject_PlainText_String, msgCharset_default, "utf-8")
				if eMailViewString is None:
					eMailViewString = msgObject_PlainText_String
				if eMailViewString is not None:
					eMailViewString = eMailViewString.strip()
					testhtml = eMailViewString[0:21]
					testhtml = testhtml.upper()
					if testhtml.startswith("<!DOCTYPE HTML PUBLIC") or testhtml.startswith("<HTML>"):
						try:
							htmlMailViewString = html2text(eMailViewString, "")
							eMailViewString = htmlMailViewString.encode("utf8","replace")
						except:
							print "[PZYMAIL] HTML Error"
							eMailViewString = msgObject_PlainText_String
				else:
					eMailViewString = ""
				if not int(mailindex) < lowestIndex:
					pzymsgs2.append(eMailViewString)

			if self.globalpzymailsettings["stats"] == "True":
				val = int(self.globalpzymailsettings["stat_load"])
				self.globalpzymailsettings["stat_load"] = str(val + 1)

		pzymsgs2.reverse()
		pzymsgs.extend(pzymsgs2)
		pzynewmailsListAccounts2.reverse()
		pzynewmailsListAccounts.extend(pzynewmailsListAccounts2)

		messageObject = None

		if not self.stayConnected:
			self._pop3_disconnect()
		else:
			print "[PZYMAIL] ...staying online..."
		headerlist = self.accounts[self.currAccount]["HeaderList"]

		tmp_list = newmailsList[:]
		tmp_list.reverse()
		for element in tmp_list:
			if int(element[0]) > lowestIndex:
				pzynewmailsList.append(element)

		tmp_nm = newmailsList[:]
		extlist = []
		for element in tmp_nm:
			if int(element[0]) > lowestIndex:
				extlist.append(element)

		pzynewmails = len(extlist)
		count_newmails_String = str(pzynewmails)

		extlist.extend(pzynewmailsDict[self.currAccount]["mailList"])
		pzynewmailsDict[self.currAccount]["mailList"] = extlist[:]
		newmailsList.extend(headerlist)
		self.accounts[self.currAccount]["HeaderList"] = newmailsList
		self.set_lastCheck()
		self._sort_headerlist_by_uidl()
		self.accounts[self.currAccount]["HeaderList"] = self.accounts[self.currAccount]["HeaderList"][0:maxmess]
		return (newmailsList, count_newmails_String)


	def sendMail(self, From="Nobody", To=[], Subject="No Subject", mailText="",files=[]):
		smtpObject = self._smtp_connect()
		if smtpObject is None:
			return False

		subjectFileList = []
		for filename in files[:3]:
			list = filename.split("/")
			subjectFileList.append(list[-1])
			
		subjAdd = ""
		filecount = len(files)
		if filecount > 3:
			subjAdd = ': ' + ', '.join(subjectFileList[:3]) + '...'
		elif filecount > 0:
			subjAdd = ': ' + ', '.join(subjectFileList)
		Subject = Subject + subjAdd

		msgObject = self._prepareMail( From, To, Subject, mailText, files )

		try:
			failed = smtpObject.sendmail(From, To, msgObject.as_string())
			print "[PZYMAIL] ... sendMail(): ",failed
		except:
			print "[PZYMAIL] sendMail Error"
			self.smtpObject = None
			return False

		if not self.stayConnected:
			self._smtp_disconnect()
		print "[PZYMAIL] ... sendMail():  OK"

		if self.globalpzymailsettings["stats"] == "True":
			val = int(self.globalpzymailsettings["stat_sent"])
			self.globalpzymailsettings["stat_sent"] = val + 1
		return True


	def _smtp_connect(self):
		global debuglevelnr
		if self.currAccount is None:
			return None

		if self.smtpObject is not None:
			print "[PZYMAIL] ... Smtp Connection Already Exists ..."
			try:
				self.smtpObject.sock.settimeout(10)
				print "[PZYMAIL] NOOP ",self.smtpObject.noop()
				self.smtpObject.sock.settimeout(120)
				return self.smtpObject
			except:
				print "\n[PZYMAIL] ... Connection Lost ..."
				print "\n[PZYMAIL] ... Reconnecting ..."
				self.smtpObject = None

		if not self.bln_networkOK:
			return None
		
		self.set_stayConnected()

		username = self.accounts[self.currAccount]["User"]
		password = self.accounts[self.currAccount]["Password"]
		smtpserver = self.accounts[self.currAccount]["SMTP_Server"]
		smtptyp = self.accounts[self.currAccount]["SMTP_Typ"]
		smtpport = self.accounts[self.currAccount]["SMTP_Port"]

		try:
			if smtptyp == "465" or smtptyp == "587S":
				print "\n[PZYMAIL] ... connecting to smtp server (SSL-Mode)..."
				smtpObject = SMTP_SSL(host=smtpserver,port=smtpport)
				smtpObject.sock.settimeout(10)
				smtpObject.set_debuglevel(debuglevelnr)
			else:
				print "\n[PZYMAIL] ... connecting to smtp server (TLS-Mode)..."
				smtpObject = SMTP(host=smtpserver,port=smtpport)
				smtpObject.sock.settimeout(10)
				smtpObject.set_debuglevel(debuglevelnr)
				if pzyhave_ssl:
					try:
						smtpObject.ehlo_or_helo_if_needed()
						smtpObject.starttls()
						smtpObject.ehlo_or_helo_if_needed()
						print "[PZYMAIL] ... smtp tls encryption started ..."
					except:
						print "[PZYMAIL] ... smtp -- problems with tls, encryption not started ..."
				else:
					print "[PZYMAIL] ... No TLS/SSL Support In This Image "
		except:
			print "[PZYMAIL] SMTP-Server Socket Error"
			
			self.smtpObject = None
			return None

		try:
			smtpObject.login(username, password)
		except:
			print "[PZYMAIL] Login Error"
			self.smtpObject = None
			return None
		smtpObject.sock.settimeout(120)
		self.smtpObject = smtpObject
		self.connectType = "smtp"
		
		if not pzy_bln_DreamOS:
			if self.autonoop not in self.nooptimer.callback:
				self.nooptimer.callback.append(self.autonoop)
		else:
			self.nooptimer_conn = self.nooptimer.timeout.connect(self.autonoop)

		self.nooptimer.startLongTimer(30)
		for fnc in self.on_connected:
			fnc()		
		return 	smtpObject


	def _smtp_disconnect(self):
		if self.smtpObject is None:
			print "[PZYMAIL] ... smtp connection is already closed ..."
			return True
		try:
			self.smtpObject.sock.settimeout(10)
			self.smtpObject.quit()
		except:
			print "\n[PZYMAIL] smtp cannot disconnect ... Error \n"
			self.smtpObject = None
			return False
		print "\n[PZYMAIL] ... smtp connection unlocked ...\n"
		self.connectType = None			
		self.nooptimer.stop()
		if not pzy_bln_DreamOS:
			if self.autonoop in self.nooptimer.callback:
				self.nooptimer.callback.remove(self.autonoop)	
		else:
			self.nooptimer_conn = None
		
		self.smtpObject = None
		for fnc in self.on_disconnected:
			fnc()		
		return True


	def _prepareMail(self, From, To, Subject, mailText, attachments=[]):
		msg = MIMEMultipart()
		hsub = Header(Subject.encode("utf-8","replace"),"utf-8")

		msg['From'] = From
		msg['To'] = ", ".join(To)
		msg['Subject'] = hsub
		msg['Date'] = formatdate(localtime=True)
		msg['X-Mailer'] = Pzymail_version

		msg.attach( MIMEText(mailText.encode("utf-8","replace"),'plain',"utf-8") )

		for filename in attachments:
			#We could check for mimetypes here
			part = MIMEBase('application', "octet-stream")
			part.set_payload( open(filename,"rb").read() )
			Encoders.encode_base64(part)
			part.add_header('Content-Disposition', 'attachment; filename="%s"' % basename(filename))
			msg.attach(part)
		return msg


	def load_Mail(self, mailuidl=None):
		#global pzyLCD
		self._pop3_connect()
		if not self.is_connected():
			return None
		try:
			#pzyLCD.setText("...loading...", LCDzeile=3)
			#tmp_uidldict = self.currUidlDict
			#newmailindex = tmp_uidldict[mailuidl]
			newmailindex = self.currUidlDict[mailuidl]
			msgString = "\r\n".join(self.pop3Object.retr(newmailindex)[1])
		except:
			print "\n[PZYMAIL] Mail Receive Error \n"
			self._pop3_disconnect()
			return None
		
		if not self.stayConnected:
			self._pop3_disconnect()
		else:
			print "[PZYMAIL] ... staying online ..."
		self.msgObject = message_from_string(msgString)
		if self.globalpzymailsettings["stats"] == "True":
			val = int(self.globalpzymailsettings["stat_view"])
			self.globalpzymailsettings["stat_view"] = val + 1
		return (self.msgObject)


	def imap_load_Mail(self, mailuidl=""):
		imapObject = self._imap_connect()
		if imapObject is None:
			return None
		try:
			imapObject.select('INBOX', readonly=False)
			typ, msg_data = self.imapObject.uid("fetch", mailuidl, '(RFC822)')
			for response_part in msg_data:
				if isinstance(response_part, tuple):
					self.msgObject = message_from_string(response_part[1])
			imapObject.select(readonly=True)		
		except:
			print "\n[PZYMAIL] Mail Receive Error \n"
			self._imap_disconnect()
			return None

		if not self.stayConnected:
			self._imap_disconnect()
		else:
			print "[PZYMAIL] ... staying online ..."

		if self.globalpzymailsettings["stats"] == "True":
			val = int(self.globalpzymailsettings["stat_view"])
			self.globalpzymailsettings["stat_view"] = val + 1
		return (self.msgObject)


	def erase_Mail(self, mailuidl, selectionIndex):
		global pzynewmailsDict

		self._pop3_connect()
		if not self.is_connected():
			return False
		try:
			tmp_uidldict = self.currUidlDict
			newmailindex = tmp_uidldict[mailuidl]
		except:
			print "[PZYMAIL] uidldict Error ..."
			return False
		try:
			self.pop3Object.dele(newmailindex)
			print "[PZYMAIL] ... eMail erased ...  #",newmailindex
		except:
			print "\n[PZYMAIL] Mail Erase Error \n"
			self._pop3_disconnect()
			return False

		headerList = self.accounts[self.currAccount]["HeaderList"]
		headerList.pop(selectionIndex)

		try:
			pzynewmailsDict[self.currAccount]["mailList"].pop(selectionIndex)
		except:
			pass

		delindex = self.currUidlList.index((str(newmailindex) + " " + str(mailuidl)))
		self.currUidlList.pop(delindex)
		self.get_mailHeaders()

		if not self.stayConnected:
			self._pop3_disconnect()
		else:
			print "[PZYMAIL] ... staying online ..."

		if self.globalpzymailsettings["stats"] == "True":
			val = int(self.globalpzymailsettings["stat_del"])
			self.globalpzymailsettings["stat_del"] = val + 1
		return True


	def imap_erase_Mail(self, mailuid="", selectionIndex=0):
		global pzynewmailsDict

		imapObject = self._imap_connect()
		if imapObject is None:
			return False
		try:
			imapObject.select(mailbox='INBOX', readonly=False)
			typ,response = imapObject.uid("store",mailuid, '+FLAGS', r'(\Deleted)')
			print "[PZYMAIL] ... typ, response",typ,response
			
			if typ.upper() == "OK":
				print "[PZYMAIL] ... eMail erased ...  #",typ,response
				typ,response = imapObject.expunge()
				print "[PZYMAIL] ... expunge() ...  #",typ,response
			else:
				print "[PZYMAIL] ... eMail not erased ...  #",typ,response
			
			imapObject.select(readonly=True)
		except:
			print "\n[PZYMAIL] Mail Erase Error \n"
			self._imap_disconnect()
			return False

		headerList = self.accounts[self.currAccount]["HeaderList"]
		headerList.pop(selectionIndex)

		try:
			pzynewmailsDict[self.currAccount]["mailList"].pop(selectionIndex)
		except:
			pass

		self.get_all_imapheaders()

		if not self.stayConnected:
			self._imap_disconnect()
		else:
			print "[PZYMAIL] ... staying online ..."

		if self.globalpzymailsettings["stats"] == "True":
			val = int(self.globalpzymailsettings["stat_del"])
			self.globalpzymailsettings["stat_del"] = val + 1
		return True


	def saveAttachments_lastLoaded(self):
		if self.msgObject is not None:
			file_Access = File_Access()
			file_Access.saveAttachments(self.msgObject)
			return True
		else:
			print "[PZYMAIL] No msgObject \n\n\t ... please load first ..."
			return False


	def _sort_headerlist_by_uidl(self):
		global pzynewmailsDict
		global pzynewmailsList

		uidldict = self.currUidlDict
		removelist = []
		tickerremoveList = []

		for index, element in enumerate(self.accounts[self.currAccount]["HeaderList"]):
			uidl = element[4]
			if uidldict.has_key(uidl):
				newmailindex = uidldict[uidl]
				newtuple = (int(newmailindex),element[1],element[2],element[3],element[4]) # (mailindex,from,subject,date,uidl)
				self.accounts[self.currAccount]["HeaderList"][index] = newtuple
			else:
				removelist.append(index)
				print "[PZYMAIL] ... removing from HeaderList ... :", element

				for tickerindex, tickertuple in enumerate(pzynewmailsList):
					if tickertuple[4] == element[4]:
						tickerremoveList.append(tickerindex)

		tickerremoveList.reverse()
		for index in tickerremoveList:
			pzynewmailsList.pop(index)

		removelist.reverse()
		print "[PZYMAIL] removelist ",removelist

		currNewmailsList = pzynewmailsDict[self.currAccount]["mailList"]
		currNewmailsListlen = len(currNewmailsList)

		for index in removelist:
			self.accounts[self.currAccount]["HeaderList"].pop(index)
			print "[PZYMAIL] Headerlist entry removed because uidl does not exist anymore - Index # ",index

			if index < currNewmailsListlen:
				currNewmailsList.pop(index)

		self.accounts[self.currAccount]["HeaderList"].sort()
		self.accounts[self.currAccount]["HeaderList"].reverse()


	def _clean_imap_headerlist_by_uidl(self):
		global pzynewmailsDict

		removelist = []
		self.nottoscrollList = []
		tickerremoveList = []

		for index, element in enumerate(self.accounts[self.currAccount]["HeaderList"]):
			uidl = element[4]
			if not uidl in self.imapalluidList:
				removelist.append(index)

				for tickerindex, tickertuple in enumerate(pzynewmailsList):
					if tickertuple[4] == element[4]:
						tickerremoveList.append(tickerindex)

			elif uidl in self.imapsinceuidList: ## for optimal sync, causes not much more traffic on socket
				self.nottoscrollList.append(uidl)
				removelist.append(index)

		tickerremoveList.reverse()
		for index in tickerremoveList:
			pzynewmailsList.pop(index)

		removelist.reverse()

		currNewmailsList = pzynewmailsDict[self.currAccount]["mailList"]
		currNewmailsListlen = len(currNewmailsList)

		for index in removelist:
			print "[PZYMAIL] Removing HeaderList-Index For Total Sync: ", index
			self.accounts[self.currAccount]["HeaderList"].pop(index)

			if index < currNewmailsListlen:
				currNewmailsList.pop(index)


	def _imap_connect(self):
		global debuglevelnr
		if self.imapObject is not None:
			print "[PZYMAIL] ... Imap Connection Already Exists ..."
			try:
				self.imapObject.sock.settimeout(5)
				print "[PZYMAIL] NOOP ",self.imapObject.noop()
				self.imapObject.sock.settimeout(120)
				return self.imapObject
			except:
				print "\n[PZYMAIL] ... Connection Lost ..."
				print "\n[PZYMAIL] ... Reconnecting ..."
				self.imapObject = None

				
		if not self.bln_networkOK:
			return None
		
		self.set_stayConnected()
		print "\n[PZYMAIL] ... connecting to imap server ...\n"
		popserverhost = self.accounts[self.currAccount]["Server"]
		popserverport = int(self.accounts[self.currAccount]["Port"] )
		popservermode = self.accounts[self.currAccount]["Typ"]
		popuser = self.accounts[self.currAccount]["User"]
		poppass = self.accounts[self.currAccount]["Password"]
		try:
			if popservermode == "993":
				imapObject = IMAP4_SSL(host=popserverhost, port=popserverport)
				print "[PZYMAIL] IMAP_SSL -- Port: ",popserverport
			else:
				imapObject = IMAP4(host=popserverhost, port=popserverport)
				print "[PZYMAIL] IMAP -- Port: ",popserverport
			imapObject.sock.settimeout(10)
			imapObject.debug = debuglevelnr
		except:
			print "\n[PZYMAIL] imaplib.IMAP4(_SSL) Server Error\n"
			self.imapObject = None
			return None
		try:
			(retcode, capabilities) = imapObject.login_cram_md5(popuser,poppass)
			print "\n[PZYMAIL] cram_md5: ",capabilities
		except:
			try:
				(retcode, capabilities) = imapObject.login(popuser,poppass)
				print "\n[PZYMAIL] ",capabilities
			except:
				print "\n[PZYMAIL] Imap-User Name, Password Error \n"
				self.imapObject = None
				return None
		print "\n[PZYMAIL] ... connected ...\n"
		imapObject.sock.settimeout(120)
		imapObject.select(mailbox='INBOX', readonly=True)
		self.imapObject = imapObject
		self.connectType = "imap"
		
		if not pzy_bln_DreamOS:
			if self.autonoop not in self.nooptimer.callback:
				self.nooptimer.callback.append(self.autonoop)	
		else:
			self.nooptimer_conn = self.nooptimer.timeout.connect(self.autonoop)
		
		self.nooptimer.startLongTimer(30)
		for fnc in self.on_connected:
			fnc()
		return imapObject


	def get_all_imapuids(self):
		if self.imapObject is None:
			return None
		imapObject = self.imapObject
		
		(retcode, messages) = imapObject.uid("search",'ALL')
		#print "[PZYMAIL] ALL Message UIDs: ",retcode,messages
		if retcode == 'OK':
			msgList = messages[0].split(' ')
			if msgList == ['']:
				msgList = []
			self.imapalluidList = msgList
			return msgList
		return None


	def get_imap_new_uids(self,alluidList=[]):
		newmailsuidlist = []
		ownuidlist = self.get_loaded_uidl_list()
		for element in alluidList:
			if not element in ownuidlist:
				newmailsuidlist.append(element)
		#print "[PZYMAIL] Own UIDs",ownuidlist
		print "[PZYMAIL] New Mail UIDs",newmailsuidlist
		return newmailsuidlist


	def get_since_imapuids(self):
		if self.imapObject is None:
			return None
		imapObject = self.imapObject
		lastcheckstr = self.accounts[self.currAccount]["LastCheck"]

		timeObj = strptime(lastcheckstr,"%d.%m.%Y     %H:%M")
		sincestr = "(SINCE " + strftime("%d-%b-%Y",timeObj) + ")"

		(retcode, messages) = imapObject.uid("search",sincestr)
		print "[PZYMAIL] Since Mail UIDs: ",sincestr,retcode,messages
		if retcode == 'OK':
			msgList = messages[0].split(' ')
			self.imapsinceuidList = msgList
			return msgList
		return None


	def get_all_imapheaders(self,message_set=[],default_enc=None,from_autostart=False):
		global pzynewmails
		global pzyOnlyHeaders
		global pzynewmailsListAccounts
		global pzynewmailsList
		global pzynewmailsDict
		global pzymsgs

		pzynewmails = 0
		imapObject = self._imap_connect()
		if imapObject is None:
			return None

		allUIDs_List = self.get_all_imapuids()
		if allUIDs_List is None:
			return None

		maxmess = int(self.accounts[self.currAccount]["MaxMessages"])
		allUIDs_List.reverse()
		allUIDs_List = allUIDs_List[0:maxmess]

		if self.accounts[self.currAccount]["HeaderList"] != []:
			lowestIndex = self.accounts[self.currAccount]["HeaderList"][-1][0]
			lowestIndex = int(lowestIndex)
		else:
			lowestIndex = 0

		sinceUIDs_List = []
		self._clean_imap_headerlist_by_uidl()
		newUIDs_List = self.get_imap_new_uids(allUIDs_List)
		oldnewUIDs_List = newUIDs_List
		#-------
		
		#print "[PZYMAIL] New Message UIDs",newUIDs_List
		count_newmails = len(oldnewUIDs_List)

		if newUIDs_List == ['']:
			self.set_lastCheck()
			return (self.accounts[self.currAccount]["HeaderList"],str(count_newmails))

		messageObject = MessageObject()

		newmailsList = []
		pzymsgs2 = []
		pzynewmailsListAccounts2 = []

		for message in newUIDs_List:

			if pzyOnlyHeaders or not from_autostart: # or int(mailindex) < lowestIndex:
				(ret, mesginfo) = imapObject.uid("fetch",str(message),"(UID INTERNALDATE BODY[HEADER.FIELDS (FROM SUBJECT DATE)])")
				msgString=mesginfo[0][1]
				msgObject = message_from_string(msgString)
			else:
				typ, msg_data = imapObject.uid("fetch", str(message), '(RFC822)')
				for response_part in msg_data:
					if isinstance(response_part, tuple):
						msgObject = message_from_string(response_part[1])

			if default_enc is None:
				default_enc = self.accounts[self.currAccount]["DefaultEncoding"]

			subject = messageObject.get_decodedString(msgObject,default_enc,"Subject")
			msgFrom = msgObject["From"]
			msgTime = msgObject.get("Date")
			mailindex = message
			uidl = message
			newmailsList.append((int(mailindex),msgFrom,subject,msgTime,uidl))

			if not (uidl in self.nottoscrollList) and not int(mailindex) < lowestIndex:
				pzynewmailsListAccounts2.append(self.currAccount)

			if not pzyOnlyHeaders and not (uidl in self.nottoscrollList) and not int(mailindex) < lowestIndex:
				msgCharset_default=self.get_currdefaultEncoding()
				msgCharset = messageObject.get_msgObject_Charset(msgObject,msgCharset_default)
				msgObject_PlainText_String = messageObject.get_msgObject_PlainText(msgObject)
				eMailViewString = messageObject.msgStringConvert(msgObject_PlainText_String, msgCharset, "utf-8") #msgString_output_encoding="utf-8"
				if eMailViewString is None:
					eMailViewString = messageObject.msgStringConvert(msgObject_PlainText_String, msgCharset_default, "utf-8")
				if eMailViewString is None:
					eMailViewString = msgObject_PlainText_String
				if eMailViewString is not None:
					eMailViewString = eMailViewString.strip()
					testhtml = eMailViewString[0:21]
					testhtml = testhtml.upper()
					if testhtml.startswith("<!DOCTYPE HTML PUBLIC") or testhtml.startswith("<HTML>"):
						try:
							htmlMailViewString = html2text(eMailViewString, "")
							eMailViewString = htmlMailViewString.encode("utf8","replace")
						except:
							print "[PZYMAIL] HTML Error"
							eMailViewString = msgObject_PlainText_String
				else:
					eMailViewString = ""
				if not int(mailindex) < lowestIndex:
					pzymsgs2.append(eMailViewString)

			if self.globalpzymailsettings["stats"] == "True":
				val = int(self.globalpzymailsettings["stat_load"])
				self.globalpzymailsettings["stat_load"] = str(val + 1)

		pzynewmailsListAccounts2.reverse
		if not pzyOnlyHeaders:
			pzymsgs2.reverse()
			pzymsgs.extend(pzymsgs2)
		pzynewmailsListAccounts.extend(pzynewmailsListAccounts2)

		messageObject = None
		if not self.stayConnected:
			self._imap_disconnect()
		else:
			print "[PZYMAIL] ... staying online ..."

		headerlist = self.accounts[self.currAccount]["HeaderList"]

		newlist = []
		for mailtuple in newmailsList:
			if mailtuple[4] not in self.nottoscrollList and not int(mailindex) < lowestIndex:
				newlist.append(mailtuple)

		self.nottoscrollList = []
		tmp_list = newlist[:]
		tmp_list.reverse()
		pzynewmailsList.extend(tmp_list)

		pzynewmails = len(newlist)
		count_newmails_String = str(pzynewmails)

		newlist.extend(pzynewmailsDict[self.currAccount]["mailList"])
		pzynewmailsDict[self.currAccount]["mailList"] = newlist

		newmailsList.extend(headerlist)
		newmailsList = newmailsList[0:maxmess]
		newmailsList.sort()
		newmailsList.reverse()
		self.accounts[self.currAccount]["HeaderList"] = newmailsList
		self.set_lastCheck()
		return (newmailsList, count_newmails_String)


	def _get_uidlDict(self):   ## { uidl : msgnum, ...}
		uidlDict = {}
		try:
			pop3uidlList = self.pop3Object.uidl()
			self.currUidlList = pop3uidlList[1]
			for pair in self.currUidlList:
				msgnum, uidl = pair.split( )
				uidlDict[uidl] = msgnum
		except:
			print "[PZYMAIL] UIDL Error"

		return uidlDict

###################################################################################################################################################################

class Configuration():
	def __init__(self):
		self.cfg = PzyConfigParser( { "AccountName":"default",
		                               "Typ" : "995",
		                               "Server" : "pop.nix.net",
		                               "SMTP_Server" : "smtp.nix.net",
		                               "SMTP_Typ" : "25",
		                               "SMTP_Port" : "25",
		                               "Port" : "995",
		                               "User" : "me",
		                               "Password" : "secret",
		                               "DefaultEncoding" : "latin-1",
		                               "MaxMessages" : "50",
		                               "Checktime" : "60",
		                               "LastCheck" : "11.11.1980     11:11",
		                               "HeaderList":[],
		                               "Adresses":[],
		                               "StayConnected" : "True",
		                               "Autoupdate" : "False",
		                               "intervall" : "0" } )
		

	def crypt_cfg(self):
		#print "[PZYMAIL] crypt self.cfg._sections",self.cfg._sections
		crypt = self.cfg._sections["globalpzymailsettings"]["crypt"]
		if crypt == "True":
			for account in self.cfg._sections:
				if account != "globalpzymailsettings":
					self.cfg._sections[account]["User"] = b64encode(str(self.cfg._sections[account]["User"]))
					self.cfg._sections[account]["Password"] = b64encode(str(self.cfg._sections[account]["Password"]))
					self.cfg._sections[account]["Server"] = b64encode(str(self.cfg._sections[account]["Server"]))
					self.cfg._sections[account]["SMTP_Server"] = b64encode(str(self.cfg._sections[account]["SMTP_Server"]))
					self.cfg._sections[account]["LastCheck"] = b64encode(str(self.cfg._sections[account]["LastCheck"]))
					self.cfg._sections[account]["HeaderList"] = b64encode(str(self.cfg._sections[account]["HeaderList"]))
					self.cfg._sections[account]["Adresses"] = b64encode(str(self.cfg._sections[account]["Adresses"]))


	def decrypt_cfg(self):
		global pzynewmailsDict
		crypt = "True"
		list = []
		if self.cfg._sections.has_key("globalpzymailsettings"):
			if self.cfg._sections["globalpzymailsettings"].has_key("crypt"):
				crypt = self.cfg._sections["globalpzymailsettings"]["crypt"]

		print "[PZYMAIL] Crypted Settings: ",crypt
		for account in self.cfg._sections:
			if account != "globalpzymailsettings":
				if not pzynewmailsDict.has_key(account):
					pzynewmailsDict.update( { account : {"mailList"  : [] }})

				if crypt == "True":
					self.cfg._sections[account]["User"] = b64decode(str(self.cfg._sections[account]["User"]))
					self.cfg._sections[account]["Password"] = b64decode(str(self.cfg._sections[account]["Password"]))
					self.cfg._sections[account]["Server"] = b64decode(str(self.cfg._sections[account]["Server"]))
					self.cfg._sections[account]["SMTP_Server"] = b64decode(str(self.cfg._sections[account]["SMTP_Server"]))
					self.cfg._sections[account]["LastCheck"] = b64decode(str(self.cfg._sections[account]["LastCheck"]))
					self.cfg._sections[account]["HeaderList"] = b64decode(str(self.cfg._sections[account]["HeaderList"]))
					self.cfg._sections[account]["Adresses"] = b64decode(str(self.cfg._sections[account]["Adresses"]))

				if not self.cfg._sections[account].has_key("Autoupdate"):
					self.cfg._sections[account].update( {  "Autoupdate" : "False"}  )

				if not self.cfg._sections[account].has_key("SMTP_Port"):
					self.cfg._sections[account].update( {  "SMTP_Port" : 25,
					                                       "SMTP_Typ" : "25" }  )

	def read_cfg(self):
		self.cfg.read(pzy_settings_file)
		self.decrypt_cfg()
		self._parse_Configfile()
		return self.cfg._sections


	def write_cfg(self,filename=pzy_settings_file):
		self.crypt_cfg()
		cfgfile = open(filename, 'wb')
		self.cfg.write(cfgfile)
		cfgfile.close()


	def _parse_Configfile(self):
		headerString = "[]"
		adressesString = "[]"
		for account in self.cfg._sections:
			if account != "globalpzymailsettings":
				headerString = self.cfg._sections[account]["HeaderList"]
				adressesString = self.cfg._sections[account]["Adresses"]
				self.cfg._sections[account]["HeaderList"] = eval(headerString)
				self.cfg._sections[account]["Adresses"] = eval(adressesString)


	def set_cfg_singleAccount_dict(self,key="default",dictionary={}):
		self.cfg._sections[key] = dictionary


	def set_cfg_allAccounts_dict(self,dictionary={}):
		self.cfg._sections = dictionary


	def set_cfg_globalpzymailsettings_dict(self,dictionary={}):
		self.cfg._sections["globalpzymailsettings"] = dictionary


###############################################################################################################################################################
###############################################################################################################################################################

class File_Access(object):
	global pzy_tmp_dir
		
	def makeDefaultDirectory(self, directoryPath=pzy_tmp_dir,mode=0755):
		if not exists(directoryPath):
			try:
				mkdir(directoryPath, mode)
				print _("\n[PZYMAIL] Directory created: "),directoryPath
				return True
			except:
				print "\n[PZYMAIL] Cannot create directory ...",directoryPath
				return False
		else:
			print "[PZYMAIL] ... directory already exists ...",directoryPath
			return True


	def removeDirectory(self, directoryPath=pzy_tmp_dir):
		try:
			rmdir(directoryPath)
			print _("\n[PZYMAIL] Directory Removed: "),directoryPath
			return True
		except:
			print "\n[PZYMAIL] Cannot Remove Directory ...",directoryPath
			return False


	def removeFile(self, filePath=pzy_tmp_dir):
		try:
			remove(filePath)
			print _("\n[PZYMAIL] File Removed: "),filePath
			return True
		except:
			print "\n[PZYMAIL] Cannot Remove File ...",filePath
			return False


	def read_File(self, filename="/tmp/pzyTest.txt", mode="rb"):
		try:
			email_file = open(filename, mode)
			filedata = email_file.read()
			email_file.close()
			print "[PZYMAIL] ... read file ...",filename
		except:
			print "[PZYMAIL] ... cannot read file ...",filename
			return None
		return filedata


	def write_File(self, filename="/tmp/pzyTest.txt", filedata="", mode="wb"):
		try:
			email_file = open(filename, mode)
			email_file.write(filedata)
			email_file.close()
			print "[PZYMAIL] ... file writen ...",filename
		except:
			print "[PZYMAIL] ... cannot write file ...",filename
			return False
		return True


	def readCompleteMail(self,filename="",mode="rb"):
		try:
			fp = open(filename,mode)
			msgObject = message_from_file(fp)
			fp.close()
			self.msgObject = msgObject
		except:
			print "[PZYMAIL] ... cannot read file ...",filename
			return None
		return msgObject


	def writeCompleteMail(self,msgObject,dirName=pzy_tmp_dir):
		filedata = msgObject.as_string(True)  #(unixfrom=False, maxheaderlen=0)
		mailFrom = ""
		mailSubject = ""
		messageObject=MessageObject()

		defenc = pzypop3_Server.get_currdefaultEncoding()
		mailFrom = messageObject.get_decodedString(msgObject,defenc,"From")
		mailSubject = messageObject.get_decodedString(msgObject,defenc,"Subject")
		mailDate = msgObject["Date"]
		mailSubject = mailSubject.replace("/","").replace("\\","")

		fileName = dirName + mailSubject + " ## " + mailFrom + " ## " + mailDate + ".mail"
		if not exists(fileName):
			blnOK = self.write_File(fileName, filedata)
			return blnOK
		else:
			print "\n[PZYMAIL] ... File Already Exists ..."
			return False

		
	def saveAttachments(self, msgObject):
		counter = 1
		for part in msgObject.walk():
			currpartcharset = part.get_content_charset()
			parttype = part.get_content_maintype()
			if parttype == 'multipart':
				continue
			#paramList = part.get_params()
			filename = part.get_filename()
			if not filename:
				ext = guess_extension(part.get_content_type())
				if ext == ".conf":
					ext = ".txt"
				if not ext:
					ext = ".bin"
				filename = "mailpart-%03d%s" % (counter, ext)
			counter += 1
			print "\n[PZYMAIL] ... writing attachments ..."
			data = part.get_payload(decode=1)
			attfilename = join(pzy_tmp_dir, filename)
			try:
				self.write_File(attfilename, data)
			except:
				print "\n[PZYMAIL] ... cannot create files in: ",pzy_tmp_dir


				
class ShellCommands():
	def __init__(self, cmdlist = [""], finishedCallback = None, closeOnSuccess = True):
		self.container = eConsoleAppContainer()
		self.swapon = True
		self.devices = []
		self.data = []

		self.finishedCallback = finishedCallback
		self.closeOnSuccess = closeOnSuccess
		self.cmdlist = cmdlist
		self.run = 0
		
		self.dataAvail_conn = None
		self.appClosed_conn = None
		
	
	def procSwaps_on(self):
		self.swapon = True
		self.run = 0
		self.__swapdevices2cmdList()
		
		
	def procSwaps_off(self):
		self.swapon = False
		self.run = 0		
		
		if not pzy_bln_DreamOS:
			self.container.dataAvail.append(self.__getSwapDevices)
			self.container.appClosed.append(self.__shellClosed)	
		else:
			self.dataAvail_conn = self.container.dataAvail.connect(self.__getSwapDevices)
			self.appClosed_conn = self.container.appClosed.connect(self.__shellClosed)		

		str_cmd = "cat /proc/swaps" 	
		self.container.execute(str_cmd)                
	
		
	def __swapdevices2cmdList(self,swapon=True):
		global pzyswapoff
		global pzypop3_Server
		
		cmdlst=[]
		for path in self.devices:
			if path.find("flodder") < 0:
				if self.swapon:
					str_cmd = "swapon %s" %path
				else:
					str_cmd = "swapoff %s" %path
				cmdlst.append(str_cmd)
			else:
				cmdlst=[]
				pzyswapoff = False
				
				if pzypop3_Server is not None:
					pzypop3_Server.globalpzymailsettings["swapoff"] = "False"
					print "[PZYMAIL] Flodder Found. SwapOff Disabled."
				break
		
		if len(cmdlst) > 0:
			self.cmdlist = cmdlst
			self.executeCmdList()
		else:
			self.__runFinished(-1)
		
			
	def __getSwapDevices(self, str_data):
		devices = []
		lst_lines = str_data.split("\n")
		for str_line in lst_lines:
			if str_line.startswith("/"):
				lst_parts = str_line.split(" ")
				devices.append(lst_parts[0])
		self.devices = devices
		
	
	def __shellClosed(self,strx):
		if not pzy_bln_DreamOS:
			self.container.dataAvail.remove(self.__getSwapDevices)
			self.container.appClosed.remove(self.__shellClosed)
		else:
			self.dataAvail_conn = None
			self.appClosed_conn = None
		self.__swapdevices2cmdList(self.swapon)
	
		
	def executeCmdList(self):
		if not pzy_bln_DreamOS:
			self.container.appClosed.append(self.__runFinished)
			self.container.dataAvail.append(self.dataAvail)
		else:
			self.appClosed_conn = self.container.appClosed.connect(self.__runFinished)
			self.dataAvail_conn = self.container.dataAvail.connect(self.dataAvail)
			
		print "[PZYMAIL] Console:  executing in run %s the command:  %s" %(self.run, self.cmdlist[self.run])
		
		if self.container.execute(self.cmdlist[self.run]): #start of container application failed...
			self.__runFinished(-1) # so we must call __runFinished manual
			
			
	def __runFinished(self, retval):
		self.run += 1
		if self.run != len(self.cmdlist):
			if self.container.execute(self.cmdlist[self.run]): 
				self.__runFinished(-1) 
		else:
			if self.finishedCallback is not None:
				data = self.data[:]
				self.finishedCallback(data)
			if not retval and self.closeOnSuccess:
				self.cancel()

				
	def cancel(self):
		if self.run == len(self.cmdlist):
			self.container.appClosed.remove(self.__runFinished)
			self.container.dataAvail.remove(self.dataAvail)
			self.data = []				
			#self.devices = []
			print "[PZYMAIL] Console: READY"

			
	def dataAvail(self, str):
		self.data.append(str)
					
##################################################################################################################################### msgObject Funktionen

class MessageObject(object):
	def __init__(self):
		self.msgObject = None
		self.msgObject_asString = None


##	def set_msgObject(self,msgObject): ##ok
##		self.msgObject=msgObject


	def get_msgObject(self):
		return self.msgObject


##	def set_msgObject_asString(self,msgObject=None): ##ok
##		self.msgObject_asString = msgObject


	def get_msgObject_asString(self):
		return self.msgObject_asString


##	def set_msgString_input_encoding(self,encoding="latin-1"): ##ok
##		self.msgString_input_encoding = encoding


	def msgStringConvert(self,msgString="",msgString_input_encoding="latin-1",msgString_output_encoding="utf-8"):
		try:
			msgStringEncoded = unicode(msgString, msgString_input_encoding).encode(msgString_output_encoding,"replace")
		except:
			print "[PZYMAIL] UNICODE ERROR in Mailtext"
			return None
		return msgStringEncoded


##	def create_msgObject(self,msgString=""): ##ok
##		msgObject = message_from_string(msgString) # msgObject erzeugen aus String
##		if msgObject is None:
##			return None
##		else:
##			return msgObject


	def get_msgObject_Charset(self, msgObject, msgCharset_default="latin-1" ):
		msgCharset = msgCharset_default
		msgObjectCharsets = msgObject.get_charsets()
		charsetClass = msgObject.get_charset()  #
		for payload_charset in msgObjectCharsets:
			if payload_charset is not None:
				msgCharset = payload_charset
				break
		return msgCharset


	def get_msgObject_PlainText(self,msgObject,html=False):  #False = Automatic
		msgObjectPlainTextString = None
		msgObjectHtml = None
		for part in msgObject.walk():
			typeStr = part.get_content_type()
			if typeStr.find("text/plain") >= 0: # Accept only the FIRST text/plain as a possible message
				msgObjectPlainTextString = part.get_payload(decode=True)
			if typeStr.find("text/html") >= 0:
				msgObjectHtml = part.get_payload(decode=True)
		if msgObjectPlainTextString is None:
			if msgObjectHtml is not None:
				msgObjectPlainTextString = msgObjectHtml
			else:
				print "[PZYMAIL] No TEXT.parts And No HTML.parts ..."
		if html:
			if msgObjectHtml is not None:
				return msgObjectHtml
		
		return msgObjectPlainTextString


	def getAttachmentList(self, msgObject):
		global pzy_tmp_dir
		
		counter = 1
		attachmentList = []
		afilename = None
		for part in msgObject.walk():
			currpartcharset = part.get_content_charset()
			parttype = part.get_content_maintype()
			if parttype == "multipart":
				continue
			filename = part.get_filename()
			if not filename:
				ext = guess_extension(part.get_content_type())
				if ext == ".conf":
					ext = ".txt"
				if not ext:
					ext = ".bin"
				filename = "mailpart-%03d%s" % (counter, ext)
			counter += 1
			attfilename = join(pzy_tmp_dir, filename)
			attachmentList.append(attfilename)
		return attachmentList
	
		
	def get_decodedString(self, msgObject=None, default_enc="latin-1", what="Subject"):
		#default_enc = self.pop3_Server.accounts[self.pop3_Server.currAccount]["DefaultEncoding"]
		
		statusOK = False
		
		if msgObject is None:
			return None
			
		if what == "Subject":
			if msgObject["Subject"] is not None:
				codedString = msgObject["Subject"]
				statusOK = True
			else:
				decodedString = "-- No Subject --"
		
		elif what == "From":
			if msgObject["From"] is not None:
				codedString = msgObject["From"]
				statusOK = True
			else:
				decodedString = "-- Nobody --"
		else:
			return None
			
		if statusOK:	
			if default_enc is None:
				default_enc="latin-1"
				
			decodefrag = decode_header(codedString)
			fragmentList = []
			for s, enc in decodefrag:
				try:
					if enc:
						s = unicode(s , enc).encode("utf8","replace")
						fragmentList.append(s)
					else:
						sr = s.replace("?=","?= ")
						decodefragn = decode_header(sr)
						for sn, encn in decodefragn:
							try:
								if encn:
									s = unicode(sn , encn).encode("utf8","replace")
								else:							
									s = unicode(s , default_enc).encode("utf8","replace")
								fragmentList.append(s)
							except:	
								raise	
									
				except:
					print "[PZYMAIL] UNICODE ERROR in Message['%s']" %what
					try:
						s = unicode(s , default_enc).encode("utf8","replace")
					except:
						fragmentList.append(s)

			decodedString = " ".join(fragmentList)
			decodedString = decodedString.replace("\n","").replace("\r","")			
		return decodedString

###################################################################################################################################################################

				
class PzyMultiFileSelectList(MultiFileSelectList): 
	
	def __init__(self, preselectedFiles, directory, showMountpoints = False, matchingPattern = None, showDirectories = True, showFiles = True,  useServiceRef = False, inhibitDirs = False, inhibitMounts = False, isTop = False, enableWrapAround = False, additionalExtensions = None):
		
		#defaults, for old skins
		self.selectIcon_Pos_x = 2
		self.selectIcon_Pos_y = 0
		self.selectIcon_Size_x = 25
		self.selectIcon_Size_y = 25
		
		self.folderIcon_Pos_x = 30
		self.folderIcon_Pos_y = 2
		self.folderIcon_Size_x = 20
		self.folderIcon_Size_y = 20
		
		self.text_Pos_x = 55
		self.text_Pos_y = 1			
		
		MultiFileSelectList.__init__(self, preselectedFiles, directory, showMountpoints, matchingPattern, showDirectories, showFiles,  useServiceRef, inhibitDirs, inhibitMounts, isTop, enableWrapAround, additionalExtensions)

		self.l.setFont(0, gFont("Regular", 22))
		self.l.setItemHeight(30)
		
		self.l.setBuildFunc(self.buildEntry)
		self.changeDir(directory)
		self.selectedFiles = []
		
		
	def applySkin(self,desktop,parent):
		# new params for skin
		attribs = [ ] 
		if self.skinAttributes is not None:
			for (attrib, value) in self.skinAttributes:
				if attrib == "font":
					self.l.setFont(0, parseFont(value, ((1,1),(1,1))))
					
				elif attrib == "itemHeight":
					self.l.setItemHeight(int(value))
					
				elif attrib == "selectIcon_Pos":	
					ep = parsePosition(value, ((1,1),(1,1)))
					self.selectIcon_Pos_x = int(ep.x())
					self.selectIcon_Pos_y = int(ep.y())					
					
				elif attrib == "selectIcon_Size":
					es = parseSize(value, ((1,1),(1,1))) #eSize
					self.folderIcon_Size_x = int(es.width())
					self.folderIcon_Size_y = int(es.height())					
					
				elif attrib == "folderIcon_Pos":	
					ep = parsePosition(value, ((1,1),(1,1)))
					self.folderIcon_Pos_x = int(ep.x())
					self.folderIcon_Pos_y = int(ep.y())					

				elif attrib == "folderIcon_Size":
					es = parseSize(value, ((1,1),(1,1))) #eSize
					self.folderIcon_Size_x = int(es.width())
					self.folderIcon_Size_y = int(es.height())					
					
				elif attrib == "text_Pos":	
					ep = parsePosition(value, ((1,1),(1,1)))
					self.text_Pos_x = int(ep.x())
					self.text_Pos_y = int(ep.y())					
					
				else:
					attribs.append((attrib, value))
		self.skinAttributes = attribs
		return MenuList.applySkin(self,desktop,parent)
	
	
	def buildEntry(self,absolute = None, isDir = False, selected = False, name=""):	
		width = self.l.getItemSize().width()
		height = self.l.getItemSize().height()
		
		res = [ (absolute, isDir, selected, name) ]
		res.append((eListboxPythonMultiContent.TYPE_TEXT, self.text_Pos_x, self.text_Pos_y, width, height, 0, RT_HALIGN_LEFT, name))
		if isDir:
			png = LoadPixmap(cached=True, path=resolveFilename(SCOPE_CURRENT_SKIN, "extensions/directory.png"))
		else:
			extension = name.split('.')
			extension = extension[-1].lower()
			if EXTENSIONS.has_key(extension):
				png = LoadPixmap(resolveFilename(SCOPE_CURRENT_SKIN, "extensions/" + EXTENSIONS[extension] + ".png"))
			else:
				png = None
		if png is not None:
			res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, self.folderIcon_Pos_x, self.folderIcon_Pos_y, self.folderIcon_Size_x, self.folderIcon_Size_y, png))
	
		if not name.startswith('<'):
			if selected is False:
				icon = LoadPixmap(cached=True, path=resolveFilename(SCOPE_CURRENT_SKIN, "skin_default/icons/lock_off.png"))
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, self.selectIcon_Pos_x, self.selectIcon_Pos_y, self.selectIcon_Size_x , self.selectIcon_Size_y, icon))
			else:
				icon = LoadPixmap(cached=True, path=resolveFilename(SCOPE_CURRENT_SKIN, "skin_default/icons/lock_on.png"))
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, self.selectIcon_Pos_x, self.selectIcon_Pos_y, self.selectIcon_Size_x , self.selectIcon_Size_y, icon))
		return res
		
	
	def getSelection(self):
		cur = self.l.getCurrentSelection()
		if cur is None:
			return None
		return cur
	
	
	def getCurrentEvent(self):
		l = self.l.getCurrentSelection()
		if not l or l[1] == True:
			return None
		else:
			return self.serviceHandler.info(l[0]).getEvent(l[0])
		
	
	def descent(self):
		sel = self.getSelection()
		if sel is None:
			return
		
		p = sel[0]
		if p == "":
			p = None

		self.changeDir(p, select = self.current_directory)
		
		
	def changeSelectionState(self):
		idx = self.l.getCurrentSelectionIndex()
		count = 0
		newList = []
		for x in self.list:
			if idx == count:
				if x[3].startswith('<'):
					newList.append(x)
				else:
					if x[1] is True:
						realPathname = x[0]
					else:
						realPathname = self.current_directory + x[0]
					if x[2] == True:
						SelectState = False
						for entry in self.selectedFiles:
							if entry == realPathname:
								self.selectedFiles.remove(entry)
	
					else:
						SelectState = True
						alreadyinList = False	
						for entry in self.selectedFiles:
							if entry == realPathname:
								alreadyinList = True
						if not alreadyinList:
							self.selectedFiles.append(realPathname)
					newList.append((x[0], x[1], SelectState,x[3]))
			else:
				newList.append(x)
			
			count += 1
		
		self.list = newList
		self.l.setList(self.list)
		
		
	def changeDir(self, directory, select = None):
		self.list = []
		
		# if we are just entering from the list of mount points:
		if self.current_directory is None:
			if directory and self.showMountpoints:
				self.current_mountpoint = self.getMountpointLink(directory)
			else:
				self.current_mountpoint = None
		self.current_directory = directory
		directories = []
		files = []

		if directory is None and self.showMountpoints: # present available mountpoints
			for p in harddiskmanager.getMountedPartitions():
				path = os_path.join(p.mountpoint, "")
				if path not in self.inhibitMounts and not self.inParentDirs(path, self.inhibitDirs):
					self.list.append((path, True,False,p.description))
			files = [ ]
			directories = [ ]
		elif directory is None:
			files = [ ]
			directories = [ ]
		elif self.useServiceRef:
			root = eServiceReference("2:0:1:0:0:0:0:0:0:0:" + directory)
			if self.additional_extensions:
				root.setName(self.additional_extensions)
			serviceHandler = eServiceCenter.getInstance()
			list = serviceHandler.list(root)

			while 1:
				s = list.getNext()
				if not s.valid():
					del list
					break
				if s.flags & s.mustDescent:
					directories.append(s.getPath())
				else:
					files.append(s)
			directories.sort()
			files.sort()
		else:
			if fileExists(directory):
				try:
					files = listdir(directory)
				except:
					files = []
				files.sort()
				tmpfiles = files[:]
				for x in tmpfiles:
					if os_path.isdir(directory + x):
						directories.append(directory + x + "/")
						files.remove(x)

		if directory is not None and self.showDirectories and not self.isTop:
			if directory == self.current_mountpoint and self.showMountpoints:
				self.list.append(( '', True,False,"<" +_("List of Storage Devices") + ">"))
			elif (directory != "/") and not (self.inhibitMounts and self.getMountpoint(directory) in self.inhibitMounts):
				self.list.append(('/'.join(directory.split('/')[:-2]) + '/', True,False,"<" +_("Parent Directory") + ">"))
				
		if self.showDirectories:
			for x in directories:
				if not (self.inhibitMounts and self.getMountpoint(x) in self.inhibitMounts) and not self.inParentDirs(x, self.inhibitDirs):
					name = x.split('/')[-2]
					alreadySelected = False
					for entry in self.selectedFiles:
						if entry  == x:
							alreadySelected = True					
					if alreadySelected:		
						self.list.append((x, True, True,name))
					else:
						self.list.append((x, True, False,name))
						
		if self.showFiles:
			for x in files:
				if self.useServiceRef:
					path = x.getPath()
					name = path.split('/')[-1]
				else:
					path = directory + x
					name = x

				if (self.matchingPattern is None) or re_compile(self.matchingPattern).search(path):
					alreadySelected = False
					for entry in self.selectedFiles:
						if os_path.basename(entry)  == x:
							alreadySelected = True	
					if alreadySelected:
						self.list.append((x , False, True,name))
					else:
						self.list.append((x , False, False,name))
		self.l.setList(self.list)

		if select is not None:
			i = 0
			self.moveToIndex(0)
			for x in self.list:
				#p = x[0][0]
				p = x[0]
				
				if isinstance(p, eServiceReference):
					p = p.getPath()
				
				if p == select:
					self.moveToIndex(i)
				i += 1


		
	
class PzyFileBrowser(Screen, ConfigListScreen):
	def __init__(self, session, selectedList,mutiSelect=False,dirmode=False, sourcesTitle="", selectedTitle="",landscapeMode=False,startdir="/",starttext="MailDir"):
		Screen.__init__(self, session)

		self.session = session
		self.oldselectedlist = selectedList[:]
		self.selectedList = selectedList
		self.mutiSelect = mutiSelect
		self.dirmode = dirmode
		self.sourcesTitle = sourcesTitle
		self.selectedTitle = selectedTitle
		self.landscapeMode = landscapeMode
		starttext = starttext.replace("/","").replace("\\","")
		self.starttext = starttext
		self.startdir = startdir

		self["VKeyIcon"] = Pixmap()

		self["config"] = ConfigList([])

		configList = []
		configList.append(getConfigListEntry("", NoSave(ConfigText(default=starttext, fixed_size=False, visible_width=50))))
		ConfigListScreen.__init__(self, configList)

		self.currList = "File_Browser"
		self.viewString = ""
		text = ""
		self["Selected_Files"] = ScrollLabel(text)
		if startdir == "":
			startdir = "/"
		
		self.filelist = PzyMultiFileSelectList(preselectedFiles = selectedList, directory = startdir, showMountpoints = True, matchingPattern = None, showDirectories = True, showFiles = True,  useServiceRef = False, inhibitDirs = [], inhibitMounts = [], isTop = False, enableWrapAround = True, additionalExtensions = None)
			
		if dirmode:
			self.filelist.showFiles=False
			self.filelist.refresh()
		self["File_Browser"] = self.filelist
		
		self["actions"] = ActionMap(["PiPSetupActions","MenuActions","ColorActions","InfobarChannelSelection","ChannelSelectEPGActions"],
		                            {
		                                    "ok": self.keyOK,
		                                    "menu": self.KeyMenu,
		                                    "up": self.menuListUp,
		                                    "down": self.menuListDown,
		                                    "left": self.menuListPageUp,
		                                    "right": self.menuListPageDown,
		                                    "cancel": self.Exit,
		                                    "historyNext": self.listToggle,
		                                    #"historyBack": self.listToggle,
		                                    "size+": self.listToggle,
		                                    "size-": self.listToggle,
		                                    "green": self.keySelect,
		                                    "showEPGList": self.key_Info,
		                                    "red": self.Abort,
		                                    }, -2)

		self.setTitle(Pzymail_version + " -- " + sourcesTitle + "  " + startdir )
		self.onLayoutFinish.append(self.landsc)
		self.onLayoutFinish.append(self._update_selectedFiles)
		self.onFirstExecBegin.append(self.firstStart)


	def firstStart(self):
		self.filelist.moveToIndex(0)
	
	
	def key_Info(self):
		pass


	def KeyText(self):
		self.session.openWithCallback(self.VirtualKeyBoardCallback, VirtualKeyBoard, title = self["config"].getCurrent()[0], text = self["config"].getCurrent()[1].getValue())


	def landsc(self):
		if self.landscapeMode: 
			self["Selected_Files"].setPosition(0,0)
			self.filelist.setPosition(0,250)
			self.filelist.resize(1200,400)
			self["Selected_Files"].resize(700,220)


	def keySelect(self):
		if self.mutiSelect == False:
			self["File_Browser"].selectedFiles=[]
		self["File_Browser"].refresh()
		self["File_Browser"].changeSelectionState()
		self._update_selectedFiles()


	def Abort(self):
		self.selectedList = self.oldselectedlist
		self.viewString = "\r\n".join(self.selectedList)
		self.close(self.selectedList, self.viewString)


	def Exit(self):
		self.close(self.selectedList, self.viewString)


	def menuListPageUp(self):
		self[self.currList].pageUp()


	def menuListPageDown(self):
		self[self.currList].pageDown()


	def menuListUp(self):
		if self.currList == "File_Browser":
			self["File_Browser"].up()


	def menuListDown(self):
		if self.currList == "File_Browser":
			self["File_Browser"].down()


	def listToggle(self):
		if self.currList == "Selected_Files":
			self.currList = "File_Browser"
			currentDir = self["File_Browser"].getCurrentDirectory()
			if currentDir is None:
				currentDir = "Devices"
			self.setTitle(Pzymail_version + " -- " + self.sourcesTitle + "  " + currentDir)
		else:
			self.currList = "Selected_Files"
			self.setTitle(Pzymail_version + " -- [" + self.selectedTitle + "]")


	def keyOK(self):
		if self["File_Browser"].canDescent():
			self["File_Browser"].descent()
			
			currentDir = self["File_Browser"].getCurrentDirectory()
			if currentDir is None:
				currentDir = "Devices"
			self.setTitle(Pzymail_version + " -- " + self.sourcesTitle + "  " + currentDir)
		else:
			if self.dirmode == False:
				testFileName = self["File_Browser"].getFilename()
				if testFileName is not None:
					if not self.mutiSelect:
						self["File_Browser"].selectedFiles=[]
						self["File_Browser"].refresh()

					self["File_Browser"].changeSelectionState()
					self._update_selectedFiles()
				

	def _update_selectedFiles(self):
		self.selectedList = self["File_Browser"].getSelectedList()
		self.selectedList.sort()
		self.viewString = "\r\n".join(self.selectedList)
		self["Selected_Files"].setText(self.viewString)


	def KeyMenu(self):
		menu = [ 
		        (_("Create Directory"), self.makeDir),
		        (_("Remove Empty Directory"),  self.removeDir),
		        (_("Remove File"), self.removeMail),
		        (_("Unselect All"), self.unselectAll) 
		]

		self.session.openWithCallback(
		        self.menuCallback,
		        cbx,
		        title = "Menu",
		        list = menu,
		        
		        keys = ["1", "2", "3", "4"]
		)

		
	def menuCallback(self, ret):
		ret and ret[1]()
		
		
	def unselectAll(self):
		self["File_Browser"].selectedFiles=[]
		self["File_Browser"].refresh()
		self._update_selectedFiles()


	def makeDir(self):
		fileAccess = File_Access()
		currentDir = self["File_Browser"].getCurrentDirectory()
		newDirectory = self["config"].getCurrent()[1].getValue()
		fileAccess.makeDefaultDirectory(currentDir + newDirectory,0755)
		self["File_Browser"].refresh()


	def removeDir(self):
		fileAccess = File_Access()
		self.selectedList = self["File_Browser"].getSelectedList()
		for directory in self.selectedList:
			fileAccess.removeDirectory(directory)
		self["File_Browser"].selectedFiles=[]
		self["File_Browser"].refresh()
		self._update_selectedFiles()


	def removeMail(self):
		fileAccess = File_Access()
		self.selectedList = self["File_Browser"].getSelectedList()
		for filePath in self.selectedList:
			fileAccess.removeFile(filePath)
		self["File_Browser"].selectedFiles=[]
		self["File_Browser"].refresh()
		self._update_selectedFiles()

###################################################################################################################################################################

class WriteEmail(Screen, ConfigListScreen):
	def __init__(self, session, pop3_Server, mailtuple):
		Screen.__init__(self, session)
		self.session = session
		self.pop3_Server = pop3_Server
		self.onClose.append(self.abort)
		self.selectedAdressesList = []
		self.selectedList = []
		self.accountName = None
		self.configList = None
		self.currList = "mailtext"
		self.mailtuple = mailtuple
		self.sendcounter = 0

		self["redpic"] = Pixmap()
		self["greenpic"] = Pixmap()
		self["yellowpic"] = Pixmap()
		self["bluepic"] = Pixmap()
		
		self["config"] = ConfigList([])
		self["VKeyIcon"] = Pixmap()
		self["saveButton"] = Button(_("Send"))
		self["cancelButton"] = Button(_("Cancel"))
		self["attachmentButton"] = Button(_("Attachments"))
		self["adressesButton"] = Button(_("Adresses"))

		self["attachScroll"] = ScrollLabel("")

		self["actions"] = NumberActionMap(["ColorActions","SetupActions","MenuActions","VirtualKeyboardActions","PiPSetupActions", "DirectionActions","ChannelSelectEPGActions"],
		                            {
		                                    "ok": self.keyOK,
		                                    "menu": self.KeyMenu,
		                                    "left": self.menuListPageUp,
		                                    "right": self.menuListPageDown,
		                                    "green": self.send_Email,
		                                    "cancel": self.Exit,
		                                    "yellow": self.openFileBrowser,
		                                    "blue": self.openAdressbook,
		                                    "red": self.Exit,
		                                    #"historyNext": self.listToggle,
		                                    "size+": self.listToggle,
		                                    "size-": self.listToggle,
		                                    "1": self.keyNumberGlobal,
		                                    "2": self.keyNumberGlobal,
		                                    "3": self.keyNumberGlobal,
		                                    "4": self.keyNumberGlobal,
		                                    "5": self.keyNumberGlobal,
		                                    "6": self.keyNumberGlobal,
		                                    "7": self.keyNumberGlobal,
		                                    "8": self.keyNumberGlobal,
		                                    "9": self.keyNumberGlobal,
		                                    "0": self.keyNumberGlobal,
		                                    "showEPGList": self.key_Info,
		                                    }, -2)

		self.setTitle(Pzymail_version + " -- [" + _("Email") + "-" + _("Editor") + "]")
		config.pzymail = ConfigSubsection()
		config.pzymail.accounts = ConfigSubDict()

		self.accountName = self.pop3_Server.get_currentAccount()
		if self.accountName is None:
			self.accountName = "default"

		self.new_account(self.accountName)

		self.configList = self.fillConfigList(self.accountName)
		ConfigListScreen.__init__(self, self.configList)
		self.onLayoutFinish.append(self.firstStart)

	##################################################################################################

	def firstStart(self):
		pass


	def KeyText(self):
		self.session.openWithCallback(self.VirtualKeyBoardCallback, VirtualKeyBoard, title = self["config"].getCurrent()[0], text = self["config"].getCurrent()[1].getValue())


	def VirtualKeyBoardCallback(self, callback = None):
		ConfigListScreen.VirtualKeyBoardCallback(self,callback)
		self.firstStart()


	def keyNumberGlobal(self, number):
		ConfigListScreen.keyNumberGlobal(self,number)

		
	def KeyMenu(self):
		self.session.openWithCallback(
			self.menuCallback,
			cbx,
		        title = "Menu",
			list = [ (_("Open Adressbook"), self.openAdressbook),
		         (_("Send eMail"), self.send_Email),
		         (_("Cancel"), self.Exit),
		         (_("Select Attachments"), self.openFileBrowser),
		         (_("Toggle Mail / Attachments"), self.listToggle)  ],
		        
		        keys = ["1", "2", "3", "4", "5"]
		)		
		
	def menuCallback(self, ret):
		ret and ret[1]()
		
		
	def key_Info(self):
		pass


	def new_account(self,accountName):
		if self.accountName == "default":
			currdict = self.pop3_Server.get_default()
		else:
			currdict = self.pop3_Server.get_accountDict(self.accountName)

		config.pzymail.accounts[accountName] = ConfigSubDict()

		if self.mailtuple is None:
			config.pzymail.accounts[accountName]["TO"]=NoSave(ConfigText(default=currdict["User"], fixed_size=False, visible_width=60))
			config.pzymail.accounts[accountName]["SUBJECT"]=NoSave(ConfigText(default="Mail from 'YOU'", fixed_size=False, visible_width=60))
		else:
			From = self.mailtuple[1]
			if From.find("<") == -1:
				adress = From
			else:
				name, adress = From.strip(">").split("<")
			self.selectedAdressesList = [adress]
			config.pzymail.accounts[accountName]["TO"]=NoSave(ConfigText(default=self.mailtuple[1], fixed_size=False, visible_width=60))
			config.pzymail.accounts[accountName]["SUBJECT"]=NoSave(ConfigText(default="RE: " + self.mailtuple[2], fixed_size=False, visible_width=60))

		config.pzymail.accounts[accountName]["FROM"]=NoSave(ConfigText(default=currdict["User"], fixed_size=False, visible_width=60))
		config.pzymail.accounts[accountName]["TEXT00"]=NoSave(ConfigText(default="-"*1000, fixed_size=False, visible_width=1000))
		config.pzymail.accounts[accountName]["TEXT0"]=NoSave(ConfigText(default="Please enter your Text the next lines:", fixed_size=False, visible_width=40))
		config.pzymail.accounts[accountName]["TEXT1"]=NoSave(ConfigText(default="", fixed_size=False, visible_width=70))
		config.pzymail.accounts[accountName]["TEXT2"]=NoSave(ConfigText(default="", fixed_size=False, visible_width=70))
		config.pzymail.accounts[accountName]["TEXT3"]=NoSave(ConfigText(default="", fixed_size=False, visible_width=70))
		config.pzymail.accounts[accountName]["TEXT4"]=NoSave(ConfigText(default="", fixed_size=False, visible_width=70))
		config.pzymail.accounts[accountName]["TEXT5"]=NoSave(ConfigText(default="", fixed_size=False, visible_width=70))
		config.pzymail.accounts[accountName]["TEXT6"]=NoSave(ConfigText(default="", fixed_size=False, visible_width=70))
		config.pzymail.accounts[accountName]["TEXT7"]=NoSave(ConfigText(default="", fixed_size=False, visible_width=70))
		config.pzymail.accounts[accountName]["TEXT8"]=NoSave(ConfigText(default="", fixed_size=False, visible_width=70))
		config.pzymail.accounts[accountName]["TEXT9"]=NoSave(ConfigText(default="", fixed_size=False, visible_width=70))
		config.pzymail.accounts[accountName]["TEXT10"]=NoSave(ConfigText(default="", fixed_size=False, visible_width=70))
		config.pzymail.accounts[accountName]["TEXT11"]=NoSave(ConfigText(default="", fixed_size=False, visible_width=70))
		config.pzymail.accounts[accountName]["TEXT12"]=NoSave(ConfigText(default="", fixed_size=False, visible_width=70))
		config.pzymail.accounts[accountName]["TEXT13"]=NoSave(ConfigText(default="", fixed_size=False, visible_width=70))
		config.pzymail.accounts[accountName]["TEXT14"]=NoSave(ConfigText(default="", fixed_size=False, visible_width=70))
		config.pzymail.accounts[accountName]["TEXT15"]=NoSave(ConfigText(default="", fixed_size=False, visible_width=70))
		config.pzymail.accounts[accountName]["TEXT16"]=NoSave(ConfigText(default="", fixed_size=False, visible_width=70))
		config.pzymail.accounts[accountName]["TEXT17"]=NoSave(ConfigText(default="", fixed_size=False, visible_width=70))
		config.pzymail.accounts[accountName]["TEXT18"]=NoSave(ConfigText(default="", fixed_size=False, visible_width=70))


	def fillConfigList(self,accountName):
		list = []
		list.append(getConfigListEntry(_("FROM") + ":", config.pzymail.accounts[accountName]["FROM"]))
		list.append(getConfigListEntry(_("TO ") + ":", config.pzymail.accounts[accountName]["TO"]))
		list.append(getConfigListEntry(_("SUBJECT") + ":", config.pzymail.accounts[accountName]["SUBJECT"]))
		list.append(getConfigListEntry("", config.pzymail.accounts[accountName]["TEXT00"]))
		list.append(getConfigListEntry("", config.pzymail.accounts[accountName]["TEXT0"]))
		list.append(getConfigListEntry("", config.pzymail.accounts[accountName]["TEXT1"]))
		list.append(getConfigListEntry("", config.pzymail.accounts[accountName]["TEXT2"]))
		list.append(getConfigListEntry("", config.pzymail.accounts[accountName]["TEXT3"]))
		list.append(getConfigListEntry("", config.pzymail.accounts[accountName]["TEXT4"]))
		list.append(getConfigListEntry("", config.pzymail.accounts[accountName]["TEXT5"]))
		list.append(getConfigListEntry("", config.pzymail.accounts[accountName]["TEXT6"]))
		list.append(getConfigListEntry("", config.pzymail.accounts[accountName]["TEXT7"]))
		list.append(getConfigListEntry("", config.pzymail.accounts[accountName]["TEXT8"]))
		list.append(getConfigListEntry("", config.pzymail.accounts[accountName]["TEXT9"]))
		list.append(getConfigListEntry("", config.pzymail.accounts[accountName]["TEXT10"]))
		list.append(getConfigListEntry("", config.pzymail.accounts[accountName]["TEXT11"]))
		list.append(getConfigListEntry("", config.pzymail.accounts[accountName]["TEXT12"]))
		list.append(getConfigListEntry("", config.pzymail.accounts[accountName]["TEXT13"]))
		list.append(getConfigListEntry("", config.pzymail.accounts[accountName]["TEXT14"]))
		list.append(getConfigListEntry("", config.pzymail.accounts[accountName]["TEXT15"]))
		list.append(getConfigListEntry("", config.pzymail.accounts[accountName]["TEXT16"]))
		list.append(getConfigListEntry("", config.pzymail.accounts[accountName]["TEXT17"]))
		list.append(getConfigListEntry("", config.pzymail.accounts[accountName]["TEXT18"]))
		return list

	##################################################################################################

	def menuListPageUp(self):
		if self.currList == "attachments":
			self.scrollLabelPageUp()

		elif self.currList == "mailtext":
			ConfigListScreen.keyLeft(self)


	def menuListPageDown(self):
		if self.currList == "attachments":
			self.scrollLabelPageDown()

		elif self.currList == "mailtext":
			ConfigListScreen.keyRight(self)


	def menuListUp(self):
		if self.currList == "mailtext":
			ConfigListScreen.keyHome(self)


	def menuListDown(self):
		if self.currList == "mailtext":
			ConfigListScreen.keyEnd(self)


	def listToggle(self):
		if self.currList == "attachments":
			self.currList = "mailtext"
			self.setTitle(Pzymail_version + " -- [" + _("Email") + "-" + _("Editor") + "]")
			self.firstStart()
		else:
			self.currList = "attachments"
			self.setTitle(Pzymail_version + " -- [" + _("Attachments") + "]")


	def keyLeft(self):
		ConfigListScreen.keyLeft(self)


	def keyRight(self):
		ConfigListScreen.keyRight(self)


	def keyOK(self):
		self.send_Email()

	#########################################################################

	def scrollLabelPageUp(self):
		self["attachScroll"].pageUp()


	def scrollLabelPageDown(self):
		self["attachScroll"].pageDown()


	def send_Email(self):
		global debuglevelnr
		typ = self.pop3_Server.accounts[self.accountName]["SMTP_Typ"]
		if typ == ("465" or typ == "587S") and not pzyhave_ssl:
			self.setTitle(Pzymail_version + " -- No SSL In This Image -- Change Your Settings")
			return

		valuelist = []
		for x in self["config"].list:
			x[1].save()
			valuelist.append(x[1].value)
		l=[]
		for textpart in valuelist[5:23]:
			text = textpart.rstrip()
			l.append(text)
		MSG = "\r\n".join(l)

		FROM = valuelist[0]
		SUBJECT = valuelist[2]
		TOstring = valuelist[1]

		TO = []
		list = TOstring.split(",")
		for adress in list:
			TO.append(adress.strip())

		if TO == [""]:
			TO = FROM
			SUBJECT = "Mail From 'You' " + SUBJECT
			MSG = u"\r\n########## \r\nMemo For Myself: \r\nNext Time I Really Should Put A Recipient Into The Mailheader ;-) \r\n########## \r\n" + MSG
		if debuglevelnr != 0:
			print "[PZYMAIL] MSG: ",MSG

		self.selectedAdressesList = TO

		mailstatus = self.pop3_Server.sendMail(From=FROM, To=TO, Subject=SUBJECT, mailText=MSG, files=self.selectedList)
		if mailstatus:
			self.sendcounter += 1
			self.setTitle(Pzymail_version + " -- [" + _("Email") + "-" + _("Editor") + "] -- " + _("Mail") + " #" + str(self.sendcounter) + " " + _("sent"))
		else:
			self.setTitle(Pzymail_version + " -- [" + _("Email") + "-" + _("Editor") + "] -- " + _("Mail") + " " + _("not") + " " + _("sent"))

	#####################################

	def openFileBrowser(self, multiFiles=True, dirmode=False):
		selectedList=self.selectedList
		sourcesTitle = _("Attachment") + " " + _("Selector")
		selectedTitle = _("Selected") + "-" + _("Files")
		configtext = self.accountName
		self.session.openWithCallback(self.__backPzyFileBrowser, PzyFileBrowser, selectedList, multiFiles, dirmode,sourcesTitle,selectedTitle,starttext=configtext)


	def openAdressbook(self):
		newlist = []
		string = config.pzymail.accounts[self.accountName]["TO"].getValue()
		list = string.split(",")
		for adress in list:
			if adress != "":
				newlist.append(adress.strip())
		self.selectedAdressesList = newlist
		self.session.openWithCallback(self.__backAdressbook, Adressbook, self.pop3_Server,self.selectedAdressesList)


	def __backPzyFileBrowser(self, selectedList, viewString):
		self.setTitle(Pzymail_version + " -- [" + _("Email") + "-" + _("Editor") + "]")
		self["attachScroll"].setText(viewString)
		self.selectedList = selectedList
		self.firstStart()


	def __backAdressbook(self,selectedAdressesList):
		self.setTitle(Pzymail_version + " -- [" + _("Email") + "-" + _("Editor") + "]")
		self.selectedAdressesList = selectedAdressesList
		config.pzymail.accounts[self.accountName]["TO"].setValue(str(selectedAdressesList).strip("[]").strip("'").replace("', '", ", "))
		self.configList = self.fillConfigList(self.accountName)
		self["config"].setList(self.configList)
		self.firstStart()


	def abort(self):
		print "[PZYMAIL] ... Screen closed ..."


	def Exit(self):
		self.close(True)

###################################################################################################################################	
###################################################################################################################################
###################################################################################################################################			
			

class SkinableMenuList(MenuList):
	def __init__(self, list=[], enableWrapAround=True, content=eListboxPythonMultiContent):
		MenuList.__init__(self, list, enableWrapAround, content)

		self.l.setFont(0, gFont("Regular", 20))
		self.l.setItemHeight(60)
		self.l.setBuildFunc(self.buildEntry)
		self.list=list
		
		self.textpos_x = 0
		self.textpos_y = 0
		self.textwidth = None
		self.textheight = None
		self.textalign = RT_HALIGN_LEFT|RT_VALIGN_TOP
	
		
	def applySkin(self,desktop,parent):
		attribs = [ ] 
		if self.skinAttributes is not None:
			for (attrib, value) in self.skinAttributes:
				if attrib == "font":
					self.l.setFont(0, parseFont(value, ((1,1),(1,1))))
					
				elif attrib == "itemHeight":
					self.l.setItemHeight(int(value))
					
				elif attrib == "textAlign":
					self.textalign = eval(value)					
					
				elif attrib == "textPos":
					ep = parsePosition(value, ((1,1),(1,1)))
					self.textpos_x = int(ep.x())
					self.textpos_y = int(ep.y())
					
				elif attrib == "textSize":
					es = parseSize(value, ((1,1),(1,1)))
					self.textwidth = int(es.width())
					self.textheight = int(es.height())
					
				else:
					attribs.append((attrib, value))
					
		self.skinAttributes = attribs
		return MenuList.applySkin(self,desktop,parent)

	
	def buildEntry(self,element,x):
		if not self.textwidth:
			self.textwidth = self.l.getItemSize().width()
			self.textheight = self.l.getItemSize().height()

		menuEntry = [(element)]
		menuEntry.append(MultiContentEntryText(pos=(self.textpos_x, self.textpos_y), size=(self.textwidth, self.textheight), font=0, flags=self.textalign, text=element))
		return menuEntry

	
	def getCurrent(self):
		cur = self.l.getCurrentSelection()
		return cur

	
	def moveToEntry(self, entry):
		if entry is None:
			return

		idx = 0
		for x in self.list:
			if x == entry:
				self.instance.moveSelectionTo(idx)
				break
			idx += 1
			
			
###################################################################################################################################	
###################################################################################################################################
###################################################################################################################################

class Adressbook(Screen, ConfigListScreen):
	def __init__(self, session, pop3_Server,selectedAdressesList):
		Screen.__init__(self, session)
		
		self.session = session
		self.pop3_Server = pop3_Server

		self.selectedList = []
		self.accountName = None
		self.currList = "Adress_List"
		self.adressBook = []
		self.selectedAdresses = selectedAdressesList
		self.oldselectedAdresses = selectedAdressesList[:]

		self.onLayoutFinish.append(self.firstStart)

		self["config"] = ConfigList([])
		self["VKeyIcon"] = Pixmap()
		self["ToggleButton"] = Button(_("Save"))
		self["cancelButton"] = Button(_("Cancel"))
		self["addButton"] = Button(_("New Adress"))
		self["removeButton"] = Button(_("Remove Adress"))

		self["Selected_List"] = SkinableMenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self["Adress_List"] = SkinableMenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)			
		
		configList = []
		configList.append(getConfigListEntry("", NoSave(ConfigText(default="me@nix.net", fixed_size=False, visible_width=50))))

		ConfigListScreen.__init__(self, configList)

		self["actions"] = NumberActionMap(["ColorActions","MenuActions","SetupActions","VirtualKeyboardActions","PiPSetupActions", "DirectionActions","InfobarChannelSelection","ChannelSelectEPGActions"],
		                            {
		                                    "ok": self.toggleAdress,
		                                    "up": self.menuListUp,
		                                    "down": self.menuListDown,
		                                    "left": self.menuListPageUp,
		                                    "right": self.menuListPageDown,
		                                    "green": self.set_AdressBook,
		                                    "cancel": self.Exit,
		                                    "yellow": self.newAdress,
		                                    "blue": self.removeAdress,
		                                    "red": self.Exit,
		                                    "historyNext": self.listToggle,
		                                    "size+": self.listToggle,
		                                    "size-": self.listToggle,
		                                    "showEPGList": self.key_Info,
		                                    "menu": self.KeyMenu,
		                                    "1": self.keyNumberGlobal,
		                                    "2": self.keyNumberGlobal,
		                                    "3": self.keyNumberGlobal,
		                                    "4": self.keyNumberGlobal,
		                                    "5": self.keyNumberGlobal,
		                                    "6": self.keyNumberGlobal,
		                                    "7": self.keyNumberGlobal,
		                                    "8": self.keyNumberGlobal,
		                                    "9": self.keyNumberGlobal,
		                                    "0": self.keyNumberGlobal,
		                                    }, -2)

		
		self.setTitle(Pzymail_version + " -- [" + _("Adressbook") + "]")
		self.accountName = self.pop3_Server.get_currentAccount()
		if self.accountName is None:
			self.accountName = "default"
		self.openAdresses()


	def firstStart(self):
		self["Selected_List"].moveToIndex(0)
		self["Adress_List"].moveToIndex(0)		
		
		
	def KeyMenu(self):
		self.session.openWithCallback(
			self.menuCallback,
			cbx,
		        title = "Menu",
			list = [ (_("Toggle Adress"), self.toggleAdress),
		         (_("Toggle List"), self.listToggle),
		         (_("New Adress"), self.newAdress),
		         (_("Remove Adress"), self.removeAdress),
		         (_("Cancel"), self.Exit),
		         (_("Save"), self.set_AdressBook)],
		        
		        keys = ["1", "2", "3", "4", "5", "6"]
		)		

	def menuCallback(self, ret):
		ret and ret[1]()
		
		
	def keyNumberGlobal(self, number):
		ConfigListScreen.keyNumberGlobal(self,number)

		
	def key_Info(self):
		pass


	def abort(self):
		print "[PZYMAIL] ... Screen closed ..."


	def Exit(self):
		self.close(self.oldselectedAdresses)


	def set_AdressBook(self):
		self.pop3_Server.set_adresses(self.accountName, self.adressBook)
		self.close(self.selectedAdresses)


	def menuListPageUp(self):
		self[self.currList].pageUp()


	def menuListPageDown(self):
		self[self.currList].pageDown()


	def menuListUp(self):
		self[self.currList].up()


	def menuListDown(self):
		self[self.currList].down()


	def listToggle(self):
		if self.currList == "Adress_List":
			self.currList = "Selected_List"
			self.setTitle(Pzymail_version + " -- [" + _("Selected")+ " " + _("Adresses") + "]")
			esptext = "Selected Adresses"
		else:
			self.currList = "Adress_List"
			self.setTitle(Pzymail_version + " -- [" + _("Adressbook")+ "]")
			esptext = "Adressbook"


	def KeyText(self):
		self.session.openWithCallback(self.VirtualKeyBoardCallback, VirtualKeyBoard, title = self["config"].getCurrent()[0], text = self["config"].getCurrent()[1].getValue())

	#############################################################################

	def list2tuplelist(self,list):
		lst = []
		for el in list:
			lst.append((el,None))
		return lst
	
	
	def openAdresses(self):
		self.adressBook = self.pop3_Server.get_adresses(self.accountName )
		self.adressBook.sort()
		self.oldadressBook = self.adressBook[:]
		menuadresses = self.list2tuplelist(self.adressBook) 
		self["Adress_List"].setList(menuadresses)

		self.selectedAdresses.sort()
		menuadresses = self.list2tuplelist(self.selectedAdresses)
		self["Selected_List"].setList(menuadresses)

		
	def newAdress(self):
		newAdress = self["config"].getCurrent()[1].getValue()

		if self.currList == "Adress_List":
			self.adressBook.append(newAdress)
			self.adressBook.sort()
			menuadresses = self.list2tuplelist(self.adressBook) 
			self["Adress_List"].setList(menuadresses)
		else:
			self.selectedAdresses.append(newAdress)
			self.selectedAdresses.sort()
			menuadresses = self.list2tuplelist(self.selectedAdresses)
			self["Selected_List"].setList(menuadresses)


	def removeAdress(self):
		selectedIndex = self[self.currList].getSelectionIndex()

		if self.currList == "Adress_List":
			if self.adressBook == []:
				return
			self.adressBook.pop(selectedIndex)
			menuadresses = self.list2tuplelist(self.adressBook) 
			self["Adress_List"].setList(menuadresses)
		else:
			if self.selectedAdresses == []:
				return
			self.selectedAdresses.pop(selectedIndex)
			menuadresses = self.list2tuplelist(self.selectedAdresses)
			self["Selected_List"].setList(menuadresses)


	def toggleAdress(self):
		if self.currList == "Adress_List":
			if self.adressBook == []:
				return
			adress = self["Adress_List"].getCurrent()[0]
			self.selectedAdresses.append(adress)
			self.selectedAdresses.sort()
			menuadresses = self.list2tuplelist(self.selectedAdresses)
			self["Selected_List"].setList(menuadresses)
		else:
			self.removeAdress()


######################################################################################################################################################

class InfoScreen(Screen):
	global pzyExtendedLCD
	global pzyExtendedInfoScreen
	global pzyautoClose
	global pzyinfoScreenMaxRuns

	def __init__(self, session, maxruns = 0):
		Screen.__init__(self, session)
		global pzyinfoscreen
		global pzyExtendedInfoScreen
		global pzymp3Path
		global pzyOnlyHeaders

		pzyinfoscreen = True
		self.session = session
		self.oldservice = None
		self.timer = eTimer()
		self.autoCloseTimer = eTimer()
		self.timer_conn = None
		self.autoCloseTimer_conn = None
		self.listindex = -2
		self.lastcount = 0
		self.playing = False
		self.mailTextHidden = True
		self.stopMailText = False
		self.currControl = "Ticker"
		self.oldTickerStatus = False
		self.forcehtml = False
		self._goodbye = False
		self.FromTicker = ""
		self.SubjectTicker = ""
		self.DateTicker = ""
		self.espmailtext = ""
		self.espaccounttext = ""
		self.listindexRun = 0
		self._backfromGUI = False
		self.pop3_Server = None

		self["Account"] = StaticText("")
		self["From"] = StaticText("")
		self["Subject"] = StaticText("")
		self["Date"] = StaticText("")
		self["MailCount"] = StaticText("")
		self["MailTextStopped"] = Button("Stopped")
		self["MailTextStopped"].hide()
		self["TickerToggle"] = Button("Ticker")
		self["MailText"] = ScrollLabel()

		if pzyExtendedInfoScreen and not pzyOnlyHeaders:
			self["TickerToggle"].show()
		else:
			self["TickerToggle"].hide()

		self["actions"] = ActionMap(["InfobarChannelSelection", "ColorActions", "PiPSetupActions","ChannelSelectEPGActions"],
		                            {       "cancel": self.keyExit,
		                                    "ok": self.Ok,
		                                    "size+": self.toggleList,
		                                    "size-": self.toggleList,
		                                    "blue": self.toggleHide,
		                                    "red": self.stopDelete,
		                                    "green": self.toggleHtml,
		                                    "left": self.keyleft,
		                                    "right": self.keyright,
		                                    "up": self.keyup,
		                                    "down": self.keydown,
		                                    "showEPGList": self.key_Info,
		                                    "yellow": self.toggleTicker   }, -2)

		self.__event_tracker = ServiceEventTracker(screen = self, eventmap = { iPlayableService.evEOF : self.stopmp3 })
		self.onLayoutFinish.append(self.firstStart)

		self.lcdRuns = maxruns
		self.maxRuns = 0
		self.LCD = None
		self.summary = None


	def createSummary(self):
		return LCDAusg


	def changeText(self, text="", LCDzeile=3):
		global pzynewmails
		text = "New Mails # " + str(pzynewmails)
		self.LCD.setText(text, LCDzeile)


	def stop(self):
		self.timer.stop()
		self.autoCloseTimer.stop()
		
		if not pzy_bln_DreamOS:
			if self.query in self.timer.callback:
				self.timer.callback.remove(self.query)	
				
			if self.Exit in self.autoCloseTimer.callback:
				self.autoCloseTimer.callback.remove(self.Exit)
			
		else:
			self.timer_conn = None
			self.autoCloseTimer_conn = None


	def checknew(self):
		global pzynewmailsList

		pzynewmailsListLen = len(pzynewmailsList)
		if (self.lastcount != pzynewmailsListLen) and not self.playing:
			self.playmp3()

		self.lastcount = int(pzynewmailsListLen)
		self["MailCount"].setText(str(pzynewmailsListLen))

	
	def key_Info(self):
		global pzymsgs
		global pzyWebNavigation
		global pzywebview
		global pzyExtendedInfoScreen
		global pzyExtendedLCD
		global pzyopera
		global pzy_tmp_dir
		
		if pzyWebNavigation and pzywebview:
			#if pzyExtendedInfoScreen or pzyExtendedLCD:
			if self.stopMailText:
				self.oldTickerStatus = True
			else:
				self.oldTickerStatus = False
			
			self.stopMailText = True
					
			eMailViewString = pzymsgs[self.listindex]
			msgObject=MessageObject()
			navstr = msgObject.msgStringConvert(eMailViewString,"utf-8","latin-1")
			self.session.openWithCallback(self.__backHTMLview,HTMLview,self.SubjectTicker,navstr)
			
		elif pzyopera and pzywebview:
			eMailViewString = pzymsgs[self.listindex]			
			str_filepath = pzy_tmp_dir + "preview.html"
			f=File_Access()
			f.write_File(str_filepath, eMailViewString)
				
			if pzyopera_2015_05:
				self.session.openWithCallback(self.clearBrowserData, Browser, filepath)
			else:				
				setPluginBrowser(self.session.openWithCallback(self.clearBrowserData, OperaBrowser, str_filepath, False))			
			

	def clearBrowserData(self):
		global pzy_tmp_dir
		
		c = ShellCommands()
		str_cmd="rm -fR %s*" %pzy_tmp_dir
		c.cmdlist=[str_cmd]
		c.executeCmdList()
		
		
	def __backHTMLview(self):
		self.stopMailText = self.oldTickerStatus
				
		
	def keyup(self):
		if self.currControl == "Ticker":
			self.firstTicker()
		else:
			self["MailText"].pageUp()


	def keydown(self):
		if self.currControl == "Ticker":
			self.lastTicker()
		else:
			self["MailText"].pageDown()


	def keyright(self):
		self.prevTicker()


	def keyleft(self):
		self.nextTicker()


	def toggleTicker(self):
		global pzyExtendedInfoScreen

		if self.stopMailText:
			self["MailTextStopped"].hide()
			self.stopMailText = False
			self.timer.start(0)
		else:
			if pzyExtendedInfoScreen:
				self["MailTextStopped"].show()
			self.stopMailText = True


	def toggleHtml(self):
		global pzyExtendedInfoScreen
		global pzyOnlyHeaders

		if pzyExtendedInfoScreen and not pzyOnlyHeaders:
			self.forcehtml = not self.forcehtml
			self.timer.stop()
			if not self.stopMailText:
				self.listindex = self.listindex + 1
			self.query(True)


	def toggleList(self):
		global pzyExtendedInfoScreen
		global pzyOnlyHeaders

		if pzyExtendedInfoScreen and not pzyOnlyHeaders:
			if self.currControl == "Ticker":
				self.currControl = "MailText"
				if self.mailTextHidden:
					self["MailText"].show()
					self.mailTextHidden = False
			else:
				self.currControl = "Ticker"
			self["TickerToggle"].setText(self.currControl)


	def stopDelete(self):
		global pzyExtendedLCD
		global pzyExtendedInfoScreen
		global pzyDeleteYES

		if pzyExtendedInfoScreen or pzyExtendedLCD:
			if self.stopMailText:
				self.oldTickerStatus = True
			else:
				self.oldTickerStatus = False
				self.stopMailText = True

			if pzyDeleteYES:
				menu = [ ("Yes", self._backdeletemail_yes),
					 ("No", self._backdeletemail_no)   ]
			else:
				menu = [ ("No", self._backdeletemail_no),
					 ("Yes", self._backdeletemail_yes)  ]

			screenTitle = "Really Delete Mail #" + str(self.listindex+1) + " ?"
			Subject = pzynewmailsList[self.listindex][2]

			self.session.openWithCallback(
				self.menuCallback,
				cbx,
				title = screenTitle,
				list = menu,
				
				keys = ["1", "2"]
			)				

		
	def menuCallback(self, ret):
		ret and ret[1]()
		
		
	def _backdeletemail_no(self):
		self.__backdeletemail(False)


	def _backdeletemail_yes(self):
		self.__backdeletemail(True)


	def __backdeletemail(self,answer=False):
		if answer:
			self.deletemail()
		else:
			if not self.oldTickerStatus:
				self.listindex = self.listindex + 1
			self.stopMailText = self.oldTickerStatus
			self.query(True)


	def firstTicker(self):
		self.timer.stop()
		self.listindex = (len(pzynewmailsList))
		self.query(True)


	def lastTicker(self):
		self.timer.stop()
		if self.stopMailText:
			self.listindex = 0
		else:
			self.listindex = 1
		self.query(True)


	def nextTicker(self):
		self.timer.stop()
		if self.stopMailText:
			self.listindex = self.listindex - 1
		self.query(True)


	def prevTicker(self):
		self.timer.stop()
		if self.listindex < (len(pzynewmailsList)-1):
			if self.stopMailText:
				self.listindex = self.listindex + 1
			else:
				self.listindex = self.listindex + 2
		else:
			if self.stopMailText:
				self.listindex = 0
			else:
				self.listindex = 1
		self.query(True)


	def playmp3(self):
		global pzymp3Path
		global pzyPlaymp3

		if not pzyPlaymp3:
			return

		import Screens.Standby
		if Screens.Standby.inStandby is not None:
			return

		if not exists(pzymp3Path):
			print "[PZYMAIL] Mp3-File Not Found: ",pzymp3Path
			return

		#lpath = pzymp3Path.lower()
		#if not lpath.endswith(".mp3"):
			#return
		
		self.oldservice = self.session.nav.getCurrentlyPlayingServiceReference()

		sref = "4097:0:0:0:0:0:0:0:0:0:%s"%pzymp3Path
		self.session.nav.stopService()
		try:
			self.session.nav.playService(eServiceReference(sref))
			self.playing = True
		except:
			self.session.nav.playService(self.oldservice)
			self.playing = False


	def stopmp3(self):
		if self.playing:
			self.session.nav.stopService()
			self.session.nav.playService(self.oldservice)
			self.playing = False


	def firstStart(self):
		global pzyExtendedInfoScreen
		global pzyOnlyHeaders

		self["MailText"].hide()
		if pzyExtendedInfoScreen and not pzyOnlyHeaders:
			self["TickerToggle"].show()
		else:
			self["TickerToggle"].hide()

		file_Access = File_Access()
		file_Access.makeDefaultDirectory()

		self.playmp3()
		self.start()


	def start(self):
		global pzyautoClose
		global pzyinfoScreenMaxRuns
		global pzynewmails

		self.maxRuns = pzyinfoScreenMaxRuns

		if pzyautoClose != 0:
			if not pzy_bln_DreamOS:
				if self.Exit not in self.autoCloseTimer.callback:
					self.autoCloseTimer.callback.append(self.Exit)
			else:
				self.autoCloseTimer_conn = self.autoCloseTimer.timeout.connect(self.Exit)
			self.autoCloseTimer.startLongTimer(pzyautoClose)
			
		if not pzy_bln_DreamOS:
			if self.query not in self.timer.callback:
				self.timer.callback.append(self.query)
		else:
			self.timer_conn = self.timer.timeout.connect(self.query)

		self.timer.start(0)


	def query(self, once=False):
		global pzynewmailsDict
		global pzynewmails
		global pzynewmailsList
		global pzyExtendedInfoScreen
		global pzyExtendedLCD
		global pzyOnlyHeaders
		global pzymsgs
		global pzynewmailsListAccounts
		global pzypop3_Server
		global pzyopera
		
		pzynewmailsListCopy = pzynewmailsList[:]
		if pzynewmailsListCopy != []:
			pzynewmailsListCopyLen = len(pzynewmailsListCopy)

			if self.stopMailText:
				stopMailTextRun = True
			else:
				stopMailTextRun = False

			listindexRun = self.listindex
			if not stopMailTextRun:
				listindexRun = listindexRun - 1

			if listindexRun < 0 or (listindexRun > (pzynewmailsListCopyLen - 1)):
				listindexRun = pzynewmailsListCopyLen - 1
				if not stopMailTextRun:
					self.lcdRuns = self.lcdRuns + 1

			if (self.lcdRuns > self.maxRuns) and (self.maxRuns > 0) and (self.pop3_Server is None):
				if pzypop3_Server is None:
					self.Exit(forceExit=True)
				else:
					self.Exit()
				return

			FromTicker = str(pzynewmailsListCopy[listindexRun][1])
			SubjectTicker = str(pzynewmailsListCopy[listindexRun][2])
			DateTicker = str(pzynewmailsListCopy[listindexRun][3])

			self.FromTicker = FromTicker
			self.SubjectTicker = SubjectTicker
			self.DateTicker = DateTicker
			self.listindexRun = listindexRun
			
			if pzyExtendedLCD:
				lcdText1 = FromTicker
				lcdText2 = SubjectTicker			
			else:
				lcdText1 = "PzyEMAIL"
				lcdText2 = "New Mails # " + str(pzynewmailsListCopyLen)			
				
			tlength1 = (len(lcdText1))
			tlength2 = (len(lcdText2))

			if pzyopera:
				length1 = tlength1 * 14 / 50 + 5  # in seconds
				length2 = tlength2 * 14 / 50 + 5 
			else:
				length1 = tlength1 * 22 / 50 + 5 
				length2 = tlength2 * 22 / 50 + 5 				
			
			
			if length1 > length2:
				maxlength = length1
				lcdText2 = lcdText2 + (tlength1-tlength2+30) * " "
			else:
				maxlength = length2
				lcdText1 = lcdText1 + (tlength2-tlength1+30) * " "

			self.LCD.setText(lcdText1, 1)
			self.LCD.setText(lcdText2, 3)

			if pzyExtendedInfoScreen:
				self["MailCount"].setText(str(listindexRun + 1) + " / " + str(pzynewmailsListCopyLen))
				if not stopMailTextRun or once:
					self.espaccounttext = pzynewmailsListAccounts[listindexRun]
					self["Account"].setText(pzynewmailsListAccounts[listindexRun])
					self["From"].setText(FromTicker)
					self["Subject"].setText(SubjectTicker)
					self["Date"].setText(DateTicker)
					if not pzyOnlyHeaders:
						if self.forcehtml:
							try:
								htmlMailViewString = html2text(pzymsgs[listindexRun], "")
								eMailViewString = htmlMailViewString.encode("utf8","replace")
								self["MailText"].setText(eMailViewString)
								self.espmailtext = eMailViewString
							except:
								print "[PZYMAIL] HTML Error"
								self["MailText"].setText(pzymsgs[listindexRun])
								self.espmailtext = pzymsgs[listindexRun]
						else:
							self["MailText"].setText(pzymsgs[listindexRun])
							self.espmailtext = pzymsgs[listindexRun]
			else:
				if pzyExtendedLCD:
					self["MailCount"].setText(str(listindexRun + 1) + " / " + str(pzynewmailsListCopyLen))
				else:
					self["MailCount"].setText(str(pzynewmailsListCopyLen))

			self.listindex = listindexRun
			self.timer.startLongTimer(maxlength)
		else:
			self.Exit(forceExit=True)


	def Ok(self):
		global pzysession
		global pzypop3_Server

		self._backfromGUI = True
		
		if not self.pop3_Server is None:
			typ = self.pop3_Server.accounts[self.pop3_Server.currAccount]["Typ"]
			if typ == "143" or typ == "993":
				disconnected = self.pop3_Server._imap_disconnect()
			elif typ == "110" or typ == "995" :
				disconnected = self.pop3_Server._pop3_disconnect()
			self.pop3_Server.set_cfg_allAccounts_dict()
			self.pop3_Server.write_cfg()				
			self.pop3_Server = None 		
				
		pzypop3_Server = None
		pzysession.openWithCallback(self.__backPzymailPlugin, PzymailPlugin)


	def __backPzymailPlugin(self):
		self.Exit(forceExit=True)


	def toggleHide(self):
		global pzyExtendedInfoScreen
		global pzyOnlyHeaders

		if self.mailTextHidden:
			self["MailText"].show()
			if pzyExtendedInfoScreen and not pzyOnlyHeaders:
				if self.currControl == "Ticker":
					self.currControl = "MailText"
					self["TickerToggle"].setText(self.currControl)
			self.mailTextHidden = False
		else:
			self["MailText"].hide()
			if pzyExtendedInfoScreen and not pzyOnlyHeaders:
				if self.currControl == "MailText":
					self.currControl = "Ticker"
					self["TickerToggle"].setText(self.currControl)
			self.mailTextHidden = True

			
	def keyExit(self):
		self.Exit(True)
		
		
	def Exit(self, fromkey=False, forceExit=False):
		global pzypop3_Server
		global pzyinfoscreen
		global pzyinfoinstance
		global pzynewmails
		global pzynewmailsList
		global pzynewmailsListAccounts
		global pzyLCD
		global pzymsgs
		global pzy_speech

		if self.playing:
			self.stopmp3()
			if fromkey:
				return
		self._goodbye = True
		self.stop()
				
		if (pzypop3_Server is None) or fromkey or forceExit: 

			if not self.pop3_Server is None:
				typ = self.pop3_Server.accounts[self.pop3_Server.currAccount]["Typ"]
				if typ == "143" or typ == "993":
					disconnected = self.pop3_Server._imap_disconnect()
				elif typ == "110" or typ == "995" :
					disconnected = self.pop3_Server._pop3_disconnect()
				self.pop3_Server.set_cfg_allAccounts_dict()
				self.pop3_Server.write_cfg()				
				
				self.pop3_Server = None 
			
			pzynewmails = 0
			pzynewmailsList = []
			pzynewmailsListAccounts = []
			pzymsgs = []
			pzyLCD = None
			pzyinfoinstance = None
			pzyinfoscreen = False
			pzypop3_Server = None
			self.close()

		
	def deletemail(self):
		global pzypop3_Server
		
		if pzypop3_Server is None or not self.pop3_Server is None:
			try:
				if self.pop3_Server is None:
					pop3_Server = Pop3_Server()
					pop3_Server.read_cfg()
				else:
					pop3_Server = self.pop3_Server
										
				if pzypop3_Server is None or not self.pop3_Server is None:
					pzypop3_Server = pop3_Server
					self.pop3_Server = pop3_Server
					self.pop3_Server.networkCheckedCallback(self._delmail)
					#self._delmail()
				else:
					print "[PZYMAIL] Server Is Busy"
								
			except Exception:
				import traceback, sys
				traceback.print_exc(file=sys.stdout)   # Dump error to stdout, Ignore any program errors
				self.pop3_Server = None
				pzypop3_Server = None

		
	def _delmail(self,state=0):
		global pzypop3_Server
		global pzyOnlyHeaders
		global pzynewmailsListAccounts
		global pzynewmailsDict
		global pzynewmailsList
		global pzymsgs
		
		try:
			pop3_Server = self.pop3_Server
			
			if pop3_Server.currAccount != pzynewmailsListAccounts[self.listindex]:
				if not pop3_Server.currAccount is None:
					typ = pop3_Server.accounts[pop3_Server.currAccount]["Typ"]
					if typ == "143" or typ == "993":
						disconnected = pop3_Server._imap_disconnect()
					elif typ == "110" or typ == "995" :
						disconnected = pop3_Server._pop3_disconnect()					
				
			pop3_Server.currAccount = pzynewmailsListAccounts[self.listindex]
			typ = pop3_Server.accounts[pop3_Server.currAccount]["Typ"]
			mailuidl = pzynewmailsList[self.listindex][4]
			for index, mailtuple in enumerate(pzynewmailsDict[pop3_Server.currAccount]["mailList"]):
				if mailtuple[4] == mailuidl:
					if typ == "143" or typ == "993":
						erased = pop3_Server.imap_erase_Mail(str(mailuidl),index)
					elif typ == "110" or typ == "995" :
						erased = pop3_Server.erase_Mail(mailuidl,index)
					print "[PZYMAIL] ERASED ### ",erased

			if erased:
				pzynewmailsList.pop(self.listindex)

				pzynewmailsListAccounts.pop(self.listindex)
				if not pzyOnlyHeaders:
					pzymsgs.pop(self.listindex)
					
			else:
				print "[PZYMAIL] ... Cannot Erase Mail ... Error"

		except Exception:
			import traceback, sys
			traceback.print_exc(file=sys.stdout)   # Dump error to stdout, Ignore any program errors
			self.pop3_Server = None
		
		if not self.oldTickerStatus:
			self.listindex = self.listindex + 1
		self.stopMailText = self.oldTickerStatus
		self.query(True)			

#####################################################################################################################################################

class InfoScreenMini(InfoScreen):
	def __init__(self, session, maxruns=0):
		InfoScreen.__init__(self, session, maxruns=0)

######################################################################################################################################################

class LCDAusg(Screen):
	
	def __init__(self, session, parent):
		Screen.__init__(self, session)
		global pzyLCD
		global pzyboxcomment
	
		self.skinName = "LCDAusg"
		
		self["entry"] = StaticText("PzyEMAIL")
		self["desc"] = StaticText("    " + pzyboxcomment)

		parent.LCD = self
		pzyLCD = self
		

	def setText(self, text, LCDzeile):
		if LCDzeile == 1:
			self["entry"].text = text
		elif LCDzeile == 3:
			self["desc"].text = text

######################################################################################################################################################
########################################################################################

class PzyConfigParser(SafeConfigParser):
	def __init__(self,defaults=None, dict_type=dict):
		SafeConfigParser.__init__(self, defaults, dict_type)
		self.optionxform = str
		
	
	def _read(self, fp, fpname):
		cursect = None
		optname = None
		lineno = 0
		e = None                                  
		while True:
			line = fp.readline()
			if not line:
				break
			lineno = lineno + 1
			if line.strip() == '' or line[0] in '#;':
				continue
			if line.split(None, 1)[0].lower() == 'rem' and line[0] in "rR":
				continue
			if line[0].isspace() and cursect is not None and optname:
				value = line.strip()
				if value:
					cursect[optname] = "%s\n%s" % (cursect[optname], value)
			else:
				mo = self.SECTCRE.match(line)
				if mo:
					sectname = mo.group('header')
					if sectname in self._sections:
						cursect = self._sections[sectname]
					elif sectname == DEFAULTSECT:
						cursect = self._defaults
					else:
						cursect = self._dict()
						cursect['__name__'] = sectname
						self._sections[sectname] = cursect
					optname = None
				elif cursect is None:
					raise MissingSectionHeaderError(fpname, lineno, line)
				else:
					mo = self.OPTCRE.match(line)
					if mo:
						optname, vi, optval = mo.group('option', 'vi', 'value')
						optval = optval.strip()
						if optval == '""':
							optval = ''
						optname = self.optionxform(optname.rstrip())
						cursect[optname] = optval
					else:
						if not e:
							e = ParsingError(fpname)
						e.append(lineno, repr(line))
		if e:
			raise e

########################################################################################
		
class PzySendMail:
	
	# Use this part of code in your plugin to send a mail:
	#
	#
	# from Plugins.Extensions.Pzymail.plugin import PzySendMail
	#	
	# class YourClass:
	#        def __init__(self):
	#	        pzySendMail = PzySendMail()
	#	
	#	        Account = "YourAccountNameInPzyEMAIL"
	#	
	#               pzySendMail.sendmail(self.callme, Account, To = ["Buddy1@test.net","Buddy2@test.net"], Subject = u"No Subject", mailText = u"Text Of Your Mail", Files = ["/tmp/test1.txt","/tmp/test2.txt"])
	#	       
	#	
	#        def callme(self, rc):
	#	        pass
	#             
	#        
	#
	#===================================================
	# Account must be STRING or DICTIONARY
	#===================================================
	# Account = "YourAccountNameInPzyEMAIL"
	#---------------------------------------------------
	# Account = { "SMTP_Server" : "smtp.nix.net",
	#             "SMTP_Port" : 25,
	#             "SMTP_Typ" : "25",            #use '465' or '587S' for ssl
	#	      "User" : "me@nix.net",
	#             "Password" : "secret" }
	#===================================================
	# Subject and mailText must be UNICODE
	#===================================================
	# Return-Codes
	#    0 : Mail Sent.
	#    1 : Mail Not Sent. Busy, Try Again In A Few Seconds. PzyEMAIL GUI Is Open Or Polling Is Active.
	#    2 : Mail Not Sent. This Account Does Not Exist.
	#    3 : Mail Not Sent. Check Your 'Account' Dictionary.
	#    4 : Mail Not Sent. Check Your 'To' Parameter.
	#    5 : Mail Not Sent. Check Your 'Files' Parameter.
	#    6 : Mail Not Sent. No Connection To Server Or Login Failed. Check Your 'Account' Data.
	#    7 : Mail Not Sent. No Connection To Internet. Check Your Network.
	# (666): Crash intercepted. You Should Never Get This RC.


	
	def __init__(self):
		self.callback = None
		self.Account = ""
		self.Subject = u""
		self.mailText = u""
		self.To = []
		self.Files = []
	
	
	def sendmail(self,callback=None,Account="",To=[],Subject=u"No Subject",mailText=u"",Files=[]):
		global pzypop3_Server		

		if pzypop3_Server is None:
			self.callback = callback
			self.Account = Account
			self.To = To
			self.Subject = Subject
			self.mailText = mailText
			self.Files = Files			

			pop3_Server = Pop3_Server()
			if pzypop3_Server is None:
				pzypop3_Server = pop3_Server
				pop3_Server.networkCheckedCallback(self._send)
				#self._send()

		else:
			print "[PZYMAIL] Busy, Try Again In A Few Seconds."
			
			if not callback is None:
				self.callback(1)
			
		
	def _send(self,rc_state=True):
		global pzypop3_Server
		
		if not rc_state:
			print "[PZYMAIL] Mail Not Sent. No Connection To Internet. Check Your Network."
			self.callback(7)
			return
		
		pop3_Server = pzypop3_Server
		
		try:
			if not isinstance(self.To,list):
				pzypop3_Server = None
				print "[PZYMAIL] Mail Not Sent. Check Your 'To' Parameter."
				self.callback(4)
				return

			attachStatus = self._checkFiles(self.Files)
			if not attachStatus:
				pzypop3_Server = None
				print "[PZYMAIL] Mail Not Sent. Check Your Attachments."
				self.callback(5)
				return
					
			pop3_Server.read_cfg()
			
			if isinstance(self.Account,str):
				if not pop3_Server.accounts.has_key(self.Account):
					pzypop3_Server = None
					print "[PZYMAIL] This Account Does Not Exist: ",self.Account
					self.callback(2)
					return

				pop3_Server.set_currentAccount(self.Account)

				tmp_stay = pop3_Server.accounts[self.Account]["StayConnected"]
				pop3_Server.accounts[self.Account]["StayConnected"] = "False"
				
				From = pop3_Server.accounts[self.Account]["User"]

				if not pop3_Server.sendMail(From, self.To, self.Subject, self.mailText, self.Files):
					pzypop3_Server = None
					print "[PZYMAIL] Mail Not Sent. No Connection To Server Or Login Failed. Check Your 'Account' Data."
					self.callback(6)
					return

				pop3_Server.accounts[self.Account]["StayConnected"] = tmp_stay

			elif isinstance(self.Account,dict):
				keyList=["SMTP_Server","SMTP_Port","SMTP_Typ","User","Password"]
				for keyName in keyList:
					if not self.Account.has_key(keyName):
						pzypop3_Server = None
						print "[PZYMAIL] Mail Not Sent. Check Your 'Account' Dictionary."
						self.callback(3)
						return

				pop3_Server.accounts.update({"guest_plugin" : self.Account})
				pop3_Server.accounts["guest_plugin"].update({"StayConnected" : "False"})
				pop3_Server.set_currentAccount("guest_plugin")
				
				From = pop3_Server.accounts["guest_plugin"]["User"]

				if not pop3_Server.sendMail(From, self.To, self.Subject, self.mailText, self.Files ):
					pzypop3_Server = None
					print "[PZYMAIL] Mail Not Sent. No Connection To Server Or Login Failed. Check Your 'Account' Data."
					self.callback(6)
					return

				pop3_Server.accounts.pop("guest_plugin")
				
			else:
				pzypop3_Server = None
				print "[PZYMAIL] Mail Not Sent. Check Your 'Account' Parameter."
				self.callback(3)
				return

			pop3_Server.set_cfg_allAccounts_dict()
			pop3_Server.write_cfg()
			pzypop3_Server = None
			print "[PZYMAIL] Mail Sent."
			self.callback(0)

		except Exception:
			import traceback, sys
			traceback.print_exc(file=sys.stdout)
			pzypop3_Server = None
			self.callback(666)
			

	def _checkFiles(self,files=[]):
		if not isinstance(files,list):
			return False

		for fileName in files:
			if not exists(fileName):
				return False
		return True
	
######################################################################################################################################################

class HTMLview(Screen):
	def __init__(self, session, mailtitle="", htmltext=" <a href='http://www.test.de'</a> <p>Ein Absatz, mit <em>betontem</em> Wort.</p> "):
		global pzyPersistentStorage
		#global pzyStorageDir
		global Pzymail_version
		global pzywebkit_data
		
		Screen.__init__(self, session)
		self.container = None
		self.pageTitle = ""

		self.mailtitle = StaticText(mailtitle)
		self["mailtitle"] = self.mailtitle		
		
		self.scrolldownmode = True
		self.str_mode = "up/down"
		self.pagemode = StaticText(self.str_mode)
		self["pagemode"] = self.pagemode		
		
		self.lastzoom = 1.0
		self.zoom = StaticText("1.0x")
		self["zoom"] = self.zoom

		self.html = htmltext
		self.htmlview = WebNavigation(html=htmltext) 
		self.htmlview.zoomFactor = 1.0		
		self["htmlview"] = self.htmlview

		self.urlnavlistcurrindex = -1
		self.urlnavlist = []
		self.bln_history = False
		
		self["cursor"] = Pixmap()
		self.__cursorPos = ePoint(getDesktop(0).size().width()/2,getDesktop(0).size().height()/2)
		self.__mouseMode = False	
		self.mouseturbofactor = 1
		
		self.canvas =  CanvasSource()
		self["canvas"] = self.canvas	
		
		self["actions"] = ActionMap(["InfobarChannelSelection","PiPSetupActions","MenuActions","ColorActions","ChannelSelectEPGActions","HelpActions"],
		                            {       "red" : self.__actionRed,
		                                    "menu": self.show_attachmentList,
		                                    "up": self.htmlUp,
		                                    "down": self.htmlDown,
		                                    "left": self.htmlPageUp,
		                                    "right": self.htmlPageDown,
		                                    "ok": self.keyOK,
		                                    "cancel": self.Exit,
		                                    "showEPGList": self.key_Info,
		                                    "displayHelp": self.mouseturbo,
		                                    "historyNext" : self.navnext,
		                                    "historyBack" : self.navback,
		                                    "size+": self.zoomplus,
		                                    "size-": self.zoomminus   }, -1)

		#self.setTitle(Pzymail_version + " -- HTML")
		
		#if config.plugins.WebBrowser.storage.enabled.value:
		if pzyPersistentStorage:
			if exists(pzywebkit_data):
				print "[PZYMAIL] webkit-data found"
				self.htmlview.enablePersistentStorage(pzywebkit_data) #("/media/hdd/webkit-data") #pzyStorageDir
		self.onFirstExecBegin.append(self.__onFirstExecBegin)

		
	def mouseturbo(self):
		if self.__mouseMode:
			self.mouseturbofactor += 1   
			if self.mouseturbofactor > 3:
				self.mouseturbofactor = 1  
				self.str_mode="Mouse"
			else:
				self.str_mode = "%sxMouse" %str(self.mouseturbofactor)
			self.pagemode.setText(self.str_mode)	
			        
  
	def keyOK(self):
		if not self.__mouseMode:	
			self.scrolldownmode = not self.scrolldownmode
			if self.scrolldownmode:
				str_mode = "up/down"
			else:
				str_mode = "left/right"
			self.str_mode = str_mode	
			self.pagemode.setText(str_mode)	
		else:	
			self.htmlview.leftClick(self.__cursorPos)
			
	
	def navnext(self):
		if self.urlnavlistcurrindex < len(self.urlnavlist)-1:
			self.urlnavlistcurrindex += 1
			self.bln_history = True
			self.htmlview.url = self.urlnavlist[self.urlnavlistcurrindex]


	def navback(self):
		self.bln_history = True
		if self.urlnavlistcurrindex > 0:
			self.urlnavlistcurrindex -= 1
			self.htmlview.url = self.urlnavlist[self.urlnavlistcurrindex]
		else:
			self.htmlview.html = self.html		
	
			
	def __onUrlChanged(self, url):
		print "[PZYMAIL]__onUrlChanged: '%s'" %url
		if url != None:
			self.__clearCanvas()
			if not self.bln_history:
				self.urlnavlist = self.urlnavlist[0:self.urlnavlistcurrindex+1]
				self.urlnavlist.append(url)
				self.urlnavlistcurrindex += 1
			else:
				self.bln_history = False
				
		
	def __onWindowRequested(self, url):
		print "[PZYMAIL]__onWindowRequested: '%s'" %url
		self.setUrl(url)		
		
		
	def setUrl(self, url):
		if url != None:
			if url.find("://") == -1:
				url = "http://%s" %url
			if url:
				self.htmlview.url = url		
		
		
	def __onTitleChanged(self, title):
		if title != None:
			self.pageTitle = title
			self.mailtitle.setText(self.pageTitle)
			
			
	def __onFirstExecBegin(self):
		#set Accept-Language header to current language
		lang = '-'.join(language.getLanguage().split('_'))
		self.htmlview.setAcceptLanguage(lang)		
		
		self["cursor"].instance.setPixmapFromFile(resolveFilename(SCOPE_PLUGINS, "Extensions/Browser/cursor.png"))
		self.__setCursor()
		self.__setMouseMode(self.__mouseMode)
		self.__registerCallbacks()
		
		
	def __registerCallbacks(self):
		self.htmlview.onLoadFinished.append(self.__onLoadFinished)
		self.htmlview.onLoadProgress.append(self.__onLoadProgress)
		self.htmlview.onUrlChanged.append(self.__onUrlChanged)
		self.htmlview.onWindowRequested.append(self.__onWindowRequested)
		self.htmlview.onTitleChanged.append(self.__onTitleChanged)		
		
		
	def __actionRed(self):
		self.__setMouseMode(not self.__mouseMode)
		if self.__mouseMode:
			if self.mouseturbofactor == 1:
				str_mode="Mouse"
			else:
				str_mode="%sxMouse" %str(self.mouseturbofactor)
		else:
			if self.scrolldownmode:
				str_mode = "up/down"
			else:
				str_mode = "left/right"
		self.str_mode=str_mode
		self.pagemode.setText(str_mode)	
			
		
	def __setMouseMode(self, enabled):
		self.__mouseMode = enabled
		if enabled:
			self.__setCursor()
			self["cursor"].show()
			self.__clearCanvas()
		else:
			self["cursor"].hide()
			
			
	def __setCursor(self):
		wPos = self.htmlview.position
		relPos = None
		if wPos.x() > 0 or wPos.y() > 0:
			relPos = ePoint(self.__cursorPos.x() + wPos.x(), self.__cursorPos.y() + wPos.y())
		else:
			relPos = self.__cursorPos
		self["cursor"].move(relPos)
		
		
	def __moveCursor(self, x=0, y=0):
		f = int(self.mouseturbofactor)
		x *= f
		y *= f
		val = 10 * f
		if x != 0 or y != 0:
			wSize = self.htmlview.size
			#horizontal
			if x != 0:
				x = self.__cursorPos.x() + x
				w = wSize.width()
				if x <= 2:
					x = 2
					self.__scroll(0-int(val), 0)
				elif x >= w-2:
					x = w-2
					self.__scroll(int(val), 0)
				self.__cursorPos.setX(x)
			#vertical
			if y != 0:
				y = self.__cursorPos.y() + y
				h = wSize.height()
				if y < 2:
					y = 2
					self.__scroll(0, 0-int(val))
				elif y > h-2:
					y = h-2
					self.__scroll(0, int(val))
				self.__cursorPos.setY(y)
		self.__setCursor()		
			
		
	def __scroll(self, dx, dy):
		self.htmlview.scroll(dx, dy)
		
		
	def __clearCanvas(self):
		size = getDesktop(0).size()
		self.canvas.fill(0, 0, size.width(), size.height(), 0xFF000000)
		self.canvas.flush()
		
			
	def __onLoadProgress(self, progress):
		#print "[PZYMAIL].__onLoadProgress %s%%" %progress
		self.pagemode.setText("%s%%" %progress)	
		
			
	def __onLoadFinished(self, val):
		self.pagemode.setText(self.str_mode)
		

	def show_attachmentList(self):
		global pzypop3_Server
		
		if not pzypop3_Server is None:
			if not pzypop3_Server.msgObject is None:
				self.session.openWithCallback(self.__backAttachmentView, AttachmentView, pzypop3_Server.msgObject, pzypop3_Server)		

				
	def __backAttachmentView(self,text=False,html=False):
		pass
	
		
	def setText(self, htmltext=""):
		self.htmlview.html = htmltext #" <a href='http://www.test.de'</a> <p>Ein Absatz, mit <em>betontem</em> Wort.</p> "

		
	def key_Info(self):
		if self.htmlview.zoomFactor != 1.0:
			self.lastzoom = self.htmlview.zoomFactor
			self.htmlview.zoomFactor = 1.0
		else:
			self.htmlview.zoomFactor = self.lastzoom
		self.zoom.setText(str(self.htmlview.zoomFactor)+"x")
		
		
	def zoomplus(self):
		self.lastzoom = 1.0
		self.htmlview.zoomFactor += 0.5
		self.zoom.setText(str(self.htmlview.zoomFactor)+"x")
		
		
	def zoomminus(self):
		self.lastzoom = 1.0
		self.htmlview.zoomFactor -= 0.5
		self.zoom.setText(str(self.htmlview.zoomFactor)+"x")
		
			
	def htmlUp(self):
		if not self.__mouseMode:
			self.htmlview.scroll( 0 , 0-self.htmlview.size.height()/4 )
		else:
			self.__moveCursor(y=-10)
		
			
	def htmlDown(self):
		if not self.__mouseMode:
			self.htmlview.scroll( 0, self.htmlview.size.height()/4 )
		else:
			self.__moveCursor(y=10)
		
	
	def htmlPageUp(self):
		if not self.__mouseMode:
			if self.scrolldownmode:
				self.htmlview.scroll( 0 , 0-self.htmlview.size.height() )
			else:
				self.htmlview.scroll( 0-self.htmlview.size.width()/4 , 0 )
		else:
			self.__moveCursor(x=-10)
			
			
	def htmlPageDown(self):
		if not self.__mouseMode:
			if self.scrolldownmode:
				self.htmlview.scroll( 0 , self.htmlview.size.height() )	
			else:
				self.htmlview.scroll( self.htmlview.size.width()/4 , 0 )
		else:	
			self.__moveCursor(x=10)			
		
	
	def Exit(self):
		self.setText("")
		self.htmlview.onLoadFinished.remove(self.__onLoadFinished)
		self.htmlview.onLoadProgress.remove(self.__onLoadProgress)	
		self.htmlview.onUrlChanged.remove(self.__onUrlChanged)
		self.htmlview.onWindowRequested.remove(self.__onWindowRequested)
		self.htmlview.onTitleChanged.remove(self.__onTitleChanged)
		self.htmlview.url = None
		self.htmlview = None
		self.urlnavlist=[]
		self.lastzoom=None
		self.zoom=None
		self.close()

		
		
###################################################################################################################################	
###################################################################################################################################
###################################################################################################################################



class SkinableChoiceList(MenuList):
	def __init__(self, list, selection = 0, enableWrapAround=False):
		MenuList.__init__(self, list, enableWrapAround, eListboxPythonMultiContent) 
		
		self.list = list
		self.l.setFont(0, gFont("Regular", 20))
		self.l.setItemHeight(25)
		self.l.setBuildFunc(self.buildChoiceEntry)
		self.selection = selection	

		self.width = 1200
		self.height = 70		
		
		self.iconpos_x = 5
		self.iconpos_y = 20
		
		self.iconwidth = 40
		self.iconheight = 40	
		
		self.textpos_x = 60
		self.textpos_y = 0

		
	def postWidgetCreate(self, instance):
		MenuList.postWidgetCreate(self, instance)
		self.moveToIndex(self.selection)
		
		
	def applySkin(self,desktop,parent):
		attribs = [ ] 
		if self.skinAttributes is not None:
			for (attrib, value) in self.skinAttributes:
				if attrib == "font":
					self.l.setFont(0, parseFont(value, ((1,1),(1,1))))
					
				elif attrib == "itemHeight":
					val = int(value)
					self.l.setItemHeight(val)
					self.height = val
				
				elif attrib == "iconpos":
					ep = parsePosition(value, ((1,1),(1,1))  )#ePoint
					self.iconpos_x = int(ep.x())
					self.iconpos_y = int(ep.y())
					
				elif attrib == "iconsize":
					es = parseSize(value, ((1,1),(1,1))) #eSize
					self.iconwidth = int(es.width())
					self.iconheight = int(es.height())
					
				elif attrib == "textpos":
					ep = parsePosition(value, ((1,1),(1,1)))
					self.textpos_x = int(ep.x())
					self.textpos_y = int(ep.y())
					
				elif attrib == "size":
					es = parseSize(value, ((1,1),(1,1)))
					self.width = int(es.width())
					##self.height = int(es.height())
					attribs.append((attrib, value))
					
				else:
					attribs.append((attrib, value))
					
		self.skinAttributes = attribs
		return MenuList.applySkin(self,desktop,parent)
	
	
	def buildChoiceEntry(self, key = "", text = ["--"]):
		res = [ text ]
		if text[0] == "--":
			res.append((eListboxPythonMultiContent.TYPE_TEXT, self.textpos_x, self.textpos_y, self.width, self.height, 0, RT_HALIGN_LEFT, "-"*200))
		else:
			res.append((eListboxPythonMultiContent.TYPE_TEXT, self.textpos_x, self.textpos_y, self.width-self.textpos_x, self.height, 0, RT_HALIGN_LEFT, text[0]))
		
			png = LoadPixmap(resolveFilename(SCOPE_CURRENT_SKIN, "skin_default/buttons/key_" + key + ".png"))
			if png is not None:
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, self.iconpos_x, self.iconpos_y, self.iconwidth, self.iconheight, png))
		
		return res	
	



class ChoiceBoxPlus(Screen):
	def __init__(self, session, title = "", list = [], keys = None, selection = 0, skin_name = []):
		Screen.__init__(self, session)

		self["VKeyIcon"] = Pixmap()
		
		self.lcd_xres = None
		self.lcd_xres=self.readlcdxres()
		self["text"] = Label(title)
		self.list = []
		self.summarylist = []
		if keys is None:
			self.__keys = [ "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "red", "green", "yellow", "blue" , "info"] + (len(list) - 10) * [""]
		else:
			self.__keys = keys + (len(list) - len(keys)) * [""]
			
		self.keymap = {}
		pos = 0
		for x in list:
			strpos = str(self.__keys[pos])
			self.list.append((strpos, x))
			if self.__keys[pos] != "":
				self.keymap[self.__keys[pos]] = list[pos]
			self.summarylist.append((self.__keys[pos],x[0]))
			pos += 1			
			
			
		self["list"] = SkinableChoiceList(list = self.list, selection = selection)
		self["summary_list"] = StaticText()
		self.updateSummary(selection)
				
		self["actions"] = NumberActionMap(["WizardActions", "InputActions", "ColorActions", "DirectionActions"], 
		{
			"ok": self.go,
			"back": self.cancel,
			"1": self.keyNumberGlobal,
			"2": self.keyNumberGlobal,
			"3": self.keyNumberGlobal,
			"4": self.keyNumberGlobal,
			"5": self.keyNumberGlobal,
			"6": self.keyNumberGlobal,
			"7": self.keyNumberGlobal,
			"8": self.keyNumberGlobal,
			"9": self.keyNumberGlobal,
			"0": self.keyNumberGlobal,
			"red": self.keyRed,
			"green": self.keyGreen,
			"yellow": self.keyYellow,
			"blue": self.keyBlue,
			"up": self.up,
			"down": self.down
		}, -1)
		
		
		self["ChannelSelectEPGActions"] = ActionMap(["ChannelSelectEPGActions"],
			{
				"showEPGList": self.key_INFO
			}
		)		
		
		self["VirtualKeyboardActions"] = ActionMap(["VirtualKeyboardActions"],
			{
				"showVirtualKeyboard": self.key_TEXT
			}
		)	
		
		#self["PiPSetupActions"] = ActionMap(["PiPSetupActions"],
			#{
		                #"size+": self.key_bouq_pl,
		                #"size-": self.key_bouq_min
			#}
		#)		
		
		self["InfobarChannelSelection"] = ActionMap(["InfobarChannelSelection"],
			{
				"historyNext": self.key_greater,
		                "historyBack": self.key_less
			}
		)
		
		self.onFirstExecBegin.append(self.first_start)
	
	
	def first_start(self):
		self["list"].moveToIndex(0)		

	
	def keyLeft(self):
		pass
	
	
	def keyRight(self):
		pass

	
	def up(self):
		if len(self["list"].list) > 0:
			while 1:
				self["list"].instance.moveSelection(self["list"].instance.moveUp)
				self.updateSummary(self["list"].l.getCurrentSelectionIndex())
				if self["list"].l.getCurrentSelection()[1][0] != "--" or self["list"].l.getCurrentSelectionIndex() == 0: #[0][0]
					break

	def down(self):
		if len(self["list"].list) > 0: 
			while 1:
				self["list"].instance.moveSelection(self["list"].instance.moveDown)
				self.updateSummary(self["list"].l.getCurrentSelectionIndex())
				if self["list"].l.getCurrentSelection()[1][0] != "--" or self["list"].l.getCurrentSelectionIndex() == len(self["list"].list) - 1:
					break

				
	
	#def key_bouq_pl(self):
		##self.goKey("")

		
	#def key_bouq_min(self):
		##self.goKey("")
	
	
	def key_greater(self):
		self.goKey(">")

		
	def key_less(self):
		self.goKey("<")

		
	def key_INFO(self):
		self.goKey("info")

		
	def key_TEXT(self):
		self.goKey("text")
		
		
	def keyNumberGlobal(self, number):
		self.goKey(str(number))


	def go(self):
		cursel = self["list"].l.getCurrentSelection()
		if cursel:
			self.goEntry(cursel[1])
		else:
			self.cancel()


	def goEntry(self, entry):
		if len(entry) > 2 and isinstance(entry[1], str) and entry[1] == "CALLFUNC":
			# CALLFUNC wants to have the current selection as argument
			arg = self["list"].l.getCurrentSelection()[0]
			entry[2](arg)
		else:
			self.close(entry)

			
	def goKey(self, key):
		if self.keymap.has_key(key):
			entry = self.keymap[key]
			self.goEntry(entry)


	def keyRed(self):
		self.goKey("red")

		
	def keyGreen(self):
		self.goKey("green")

		
	def keyYellow(self):
		self.goKey("yellow")

		
	def keyBlue(self):
		self.goKey("blue")

		
	def updateSummary(self, curpos=0):
		pos = 0
		summarytext = ""
		for entry in self.summarylist:
			if self.lcd_xres is not None and self.lcd_xres > 140:
				if pos > curpos-2 and pos < curpos+5:
					if pos == curpos:
						summarytext += ">"
					else:
						summarytext += entry[0]
					summarytext += ' ' + entry[1] + '\n'
			else:
				if pos == curpos:
					summarytext += entry[0]+' '+ entry[1]
			pos += 1
		self["summary_list"].setText(summarytext)

		
	def cancel(self):
		self.close(None)

		
	def readlcdxres(self):
		try:
			fd = open("/proc/stb/lcd/xres","r")
			value = int(fd.read().strip(),16)
			fd.close()
			return value
		except:
			return None

		
		
class SkinableLabel(Label):
	def __init__(self, text=""):
		Label.__init__(self,text)
		self.backgroundColorSelected_gRGB = None
		self.backgroundColor_gRGB = parseColor("#000000ff")
		self.foregroundColorSelected_gRGB = parseColor("#00ffc900")
		self.foregroundColor_gRGB = parseColor("#000000ff")		
		self.selected = False
		self.selectedText = None
		self.deselectedText = None
		
	
	def applySkin(self,desktop,screen):
		attribs = [ ] 
		if self.skinAttributes is not None:
			for (attrib, value) in self.skinAttributes:
				if attrib == "backgroundColorSelected":
					self.backgroundColorSelected_gRGB = parseColor(value)
				elif attrib == "backgroundColor":
					self.backgroundColor_gRGB = parseColor(value)
					attribs.append((attrib, value))
				elif attrib == "foregroundColorSelected":
					self.foregroundColorSelected_gRGB = parseColor(value)
				elif attrib == "foregroundColor":
					self.foregroundColor_gRGB = parseColor(value)
					attribs.append((attrib, value))					
				else:
					attribs.append((attrib, value))
					
			if self.backgroundColorSelected_gRGB is None:
				self.backgroundColorSelected_gRGB = self.backgroundColor_gRGB
				
		self.skinAttributes = attribs
		return Label.applySkin(self, desktop, screen)

		
	def setSelected(self):
		if self.instance:
			self.instance.setBackgroundColor(self.backgroundColorSelected_gRGB)
			self.instance.setForegroundColor(self.foregroundColorSelected_gRGB)
			self.selected = True
			if self.selectedText:
				self.setText(self.selectedText)
			self.instance.invalidate()
		
			
	def setDeselected(self):
		if self.instance:
			self.instance.setBackgroundColor(self.backgroundColor_gRGB)
			self.instance.setForegroundColor(self.foregroundColor_gRGB)
			self.selected = False
			if self.deselectedText:
				self.setText(self.deselectedText)
			self.instance.invalidate()	
			

if pzy_bln_DreamOS:
	from Screens.ChoiceBox import ChoiceBox
	cbx = ChoiceBox
	#cbx = ChoiceBoxPlus
else:
	cbx = ChoiceBoxPlus			