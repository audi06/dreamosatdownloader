# -*- coding: iso-8859-1 -*-
#
# SplitScreen by gutemine
#
splitscreen_version="0.7"
#
from Screens.InfoBar import *
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.InfoBarGenerics  import InfoBarPiP
from Screens.PictureInPicture import PictureInPicture
from Components.SystemInfo import SystemInfo
from Components.config import config, ConfigPosition
from Screens.ChannelSelection import ChannelSelection

def autostart(reason, **kwargs):
   if SystemInfo.get("NumVideoDecoders", 1) > 1:
      print "[SPLITSCEEN] resetting"
      l=open("/proc/stb/vmpeg/0/dst_left","w")
      l.write("%x" % 0)
      l.close()
      t=open("/proc/stb/vmpeg/0/dst_top","w")
      t.write("%x" % 0)
      t.close()
      h=open("/proc/stb/vmpeg/0/dst_height","w")
      h.write("%x" % 576)
      h.close()
      w=open("/proc/stb/vmpeg/0/dst_width","w")
      w.write("%x" % 720)
      w.close()
      try:
         xxx = config.av.pip.value[0]
         yyy = config.av.pip.value[1]
         www = config.av.pip.value[2]
         hhh = config.av.pip.value[3] 
      except:
         # default location
         xxx = 400
         yyy = 60
         www = 240
         hhh = 192
      l=open("/proc/stb/vmpeg/1/dst_left","w")
      l.write("%x" % xxx)
      l.close()
      t=open("/proc/stb/vmpeg/1/dst_top","w")
      t.write("%x" % yyy) 
      t.close()
      h=open("/proc/stb/vmpeg/1/dst_height","w")
      h.write("%x" % hhh)
      h.close()
      w=open("/proc/stb/vmpeg/1/dst_width","w")
      w.write("%x" % www)
      w.close()

def Plugins(**kwargs):
    return [PluginDescriptor(where = [PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART], fnc = autostart),
            PluginDescriptor(name=_("Split Screen"), description=_("split PIP screen"), where = PluginDescriptor.WHERE_EXTENSIONSMENU, icon="splitscreen.png", fnc=main)]

def main(session, **kwargs):
    session.open(SplitScreen)

class SplitScreen(Screen):
    def __init__(self, session, args = 0):
        Screen.__init__(self, session)
        if SystemInfo.get("NumVideoDecoders", 1) > 1:
           try:
              self.session.pipshown
           except:
              self.session.pipshown = False
           if self.session.pipshown:
              print "[SPLITSCREEN] pip already shown"
              w=open("/proc/stb/vmpeg/0/dst_width","r")
              ww=w.readline().rstrip()
              w.close()
   	      print "----------------------------------------------"
              print "[SPLITSCREEN] width %s" % ww
              if not ww.endswith("%x" % 720):
		 print "----------------------------------------------"
                 print "[SPLITSCREEN] PiP is stopped"
		 print "----------------------------------------------"
                 self.showPiP()
                 print "[SPLITSCREEN] unsplitting"
                 l=open("/proc/stb/vmpeg/0/dst_left","w")
                 l.write("%x" % 0)
                 l.close()
                 t=open("/proc/stb/vmpeg/0/dst_top","w")
                 t.write("%x" % 0)
                 t.close()
                 h=open("/proc/stb/vmpeg/0/dst_height","w")
                 h.write("%x" % 576)
                 h.close()
                 w=open("/proc/stb/vmpeg/0/dst_width","w")
                 w.write("%x" % 720)
                 w.close()
                 try:
                    xxx = config.av.pip.value[0]
                    yyy = config.av.pip.value[1]
                    www = config.av.pip.value[2]
                    hhh = config.av.pip.value[3] 
                 except:
                    # default location
                    xxx = 400
                    yyy = 60
                    www = 240
                    hhh = 192
                 l=open("/proc/stb/vmpeg/1/dst_left","w")
                 l.write("%x" % xxx)
                 l.close()
                 t=open("/proc/stb/vmpeg/1/dst_top","w")
                 t.write("%x" % yyy) 
                 t.close()
                 h=open("/proc/stb/vmpeg/1/dst_height","w")
                 h.write("%x" % hhh)
                 h.close()
                 w=open("/proc/stb/vmpeg/1/dst_width","w")
                 w.write("%x" % www)
                 w.close()
              else:
		 print "----------------------------------------------"
                 print "[SPLITSCREEN] splitting"
		 print "----------------------------------------------"
                 l=open("/proc/stb/vmpeg/0/dst_left","w")
                 l.write("%x" % 0)
                 l.close()
                 t=open("/proc/stb/vmpeg/0/dst_top","w")
                 t.write("%x" % 0)
                 t.close()
                 h=open("/proc/stb/vmpeg/0/dst_height","w")
                 h.write("%x" % 576)
                 h.close()
                 w=open("/proc/stb/vmpeg/0/dst_width","w")
                 w.write("%x" % 360)
                 w.close()
                 l=open("/proc/stb/vmpeg/1/dst_left","w")
                 l.write("%x" % 360)
                 l.close()
                 t=open("/proc/stb/vmpeg/1/dst_top","w")
                 t.write("%x" % 0)
                 t.close()
                 h=open("/proc/stb/vmpeg/1/dst_height","w")
                 h.write("%x" % 576)
                 h.close()
                 w=open("/proc/stb/vmpeg/1/dst_width","w")
                 w.write("%x" % 360)
                 w.close()
           else:
		 print "----------------------------------------------"
                 print "[SPLITSCREEN] PiP is started"
		 print "----------------------------------------------"
                 self.showPiP()
                 print "[SPLITSCREEN] splitting"
		 print "----------------------------------------------"
                 l=open("/proc/stb/vmpeg/0/dst_left","w")
                 l.write("%x" % 0)
                 l.close()
                 t=open("/proc/stb/vmpeg/0/dst_top","w")
                 t.write("%x" % 0)
                 t.close()
                 h=open("/proc/stb/vmpeg/0/dst_height","w")
                 h.write("%x" % 576)
                 h.close()
                 w=open("/proc/stb/vmpeg/0/dst_width","w")
                 w.write("%x" % 360)
                 w.close()
                 l=open("/proc/stb/vmpeg/1/dst_left","w")
                 l.write("%x" % 360)
                 l.close()
                 t=open("/proc/stb/vmpeg/1/dst_top","w")
                 t.write("%x" % 0)
                 t.close()
                 h=open("/proc/stb/vmpeg/1/dst_height","w")
                 h.write("%x" % 576)
                 h.close()
                 w=open("/proc/stb/vmpeg/1/dst_width","w")
                 w.write("%x" % 360)
                 w.close()
        else:
            print "[SPLITSCREEN] too less video decoders"
        self.close()

    def showPiP(self):
	if self.session.pipshown:
	        print "[SPLITSCREEN] closes PIP"
		print "pip currently shown.... pointer:", self.session.pip
		self.session.deleteDialog(self.session.pip)
		del self.session.pip
		print 'hasattr(self.session,"pip")', hasattr(self.session,"pip")
		self.session.pipshown = False
	else:
	        print "[SPLITSCREEN] opens PIP"
		self.session.pip = self.session.instantiateDialog(PictureInPicture)
		self.session.pip.neverAnimate()
		self.session.pip.show()
		newservice = self.session.nav.getCurrentlyPlayingServiceReference()
		if self.session.pip.playService(newservice):
			self.session.pipshown = True
#			self.session.pip.servicePath = self.servicelist.getCurrentServicePath()
		else:
			self.session.pipshown = False
			self.session.deleteDialog(self.session.pip)
			del self.session.pip
		self.session.nav.playService(newservice)

