# -*- coding: utf-8 -*-
#
# OpenEPG Plugin by gutemine
#
openepg_version="1.4-r10"
#
from Components.ActionMap import ActionMap, NumberActionMap
from Components.Label import Label
from Tools.Directories import InitFallbackFiles, resolveFilename, SCOPE_CURRENT_SKIN, SCOPE_PLUGINS, SCOPE_CONFIG
from Components.config import config, configfile, ConfigText, ConfigYesNo, ConfigInteger, ConfigSelection, ConfigEnableDisable, ConfigClock, NoSave, ConfigSubsection, getConfigListEntry
from Components.ConfigList import ConfigListScreen
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox 
from Screens.InputBox import InputBox
from Components.Input import Input
from Screens.ChoiceBox import ChoiceBox
from Screens.Console import Console                                                                           
from Components.MenuList import MenuList       
from Components.Slider import Slider       
from enigma import  ePoint, quitMainloop, getDesktop, eTimer, eActionMap, eEPGCache, eConsoleAppContainer, eServiceReference
from twisted.internet import reactor, threads
import twisted.python.runtime
from ServiceReference import ServiceReference
from Tools.FuzzyDate import FuzzyTime
from Screens.TimerSelection import TimerSelection
import Screens.Standby
from Components.SystemInfo import SystemInfo

import gettext, datetime, time
import sys, os
if os.path.exists("/var/lib/dpkg/status"):
	from enigma import cachestate
	from sqlite3 import dbapi2 as sqlite
	from epgdb import epgdb_class
else:
	from epgdat import epgdat_class

# Global variable                        
OpenEPGautoStartTimer = None            
global openepg_session
openepg_session=None

# only for debugging purpose
crossepg_keep=False

openepg_plugindir="/usr/lib/enigma2/python/Plugins/Extensions/OpenEPG" 
f=open("/proc/stb/info/model")   
boxtype=f.read()             
f.close()                 
boxtype=boxtype.replace("\n","").replace("\l","")
if boxtype == "dm900":          
	openepg_plugindir_bin="/usr/lib/enigma2/python/Plugins/Extensions/OpenEPG/armhf" 
else:
	openepg_plugindir_bin="/usr/lib/enigma2/python/Plugins/Extensions/OpenEPG/mipsel" 
openepg_download="/tmp/openepg_download.log" 
openepg_dbinfo="/tmp/openepg_dbinfo.log" 
openepg_dbconvert="/tmp/openepg_dbconvert.log" 
openepg_resetting="/tmp/openepg_resetting.log" 
global openepg_events_loaded
openepg_events_loaded=-1

# add local language file
openepg_sp=config.osd.language.value.split("_")
openepg_language = openepg_sp[0]
if os.path.exists("%s/locale/%s" % (openepg_plugindir,openepg_language)):
	_=gettext.Catalog('openepg', '%s/locale' % openepg_plugindir,openepg_sp).gettext

openepg_title=_("Open EPG plugin by gutemine V%s") % openepg_version
yes_no_descriptions = {False: _("no"), True: _("yes")}    

config.plugins.openepg = ConfigSubsection()
openepg_e2settings=open("/etc/enigma2/settings","r")
openepg_e2settings_data=openepg_e2settings.read()
openepg_e2settings.close()
if openepg_e2settings_data.find("282") is not -1:
	openepg_282=True
else:
	openepg_282=False
if openepg_e2settings_data.find("284") is not -1:
	openepg_284=True
else:
	openepg_284=False
provider=[]
for name in os.listdir("%s/providers" % openepg_plugindir):            
	if name.endswith(".conf"):
		p=open("%s/providers/%s" % (openepg_plugindir,name),"r")
		d=p.readline()
		description=d.replace("description=","").rstrip().lstrip()
		if description.startswith("protocol="):
			d=p.readline()
			d=p.readline()
			d=p.readline()
			description=d.replace("description=","").replace("- mhw2epgdownloader","").rstrip().lstrip()
		name=name.replace(".conf","")
		if name.find("28.4") is not -1 and not openepg_282:
       			provider.append((name,description))
		elif name.find("28.2") is not -1 and not openepg_284:
       			provider.append((name,description))
		else:
       			provider.append((name,description))
		p.close()
	provider.sort()
if openepg_284:
	config.plugins.openepg.provider = ConfigSelection(default = "skyuk_astra2_28.4", choices = provider)
else:
	config.plugins.openepg.provider = ConfigSelection(default = "skyuk_astra2_28.2", choices = provider)
extensions=[]
extensions.append(("plugin",_("plugin")))
extensions.append(("download",_("download")))
config.plugins.openepg.extension = ConfigSelection(default = "download", choices = extensions)
loading=[]
loading.append(("tune",_("Tune")))
decoders=SystemInfo.get("NumVideoDecoders", 1)
if decoders > 1 and os.path.exists("/var/lib/dpkg/status"):
	loading.append(("record",_("Recording")))
	config.plugins.openepg.tune = ConfigSelection(default = "record", choices = loading)
else:
	config.plugins.openepg.tune = ConfigSelection(default = "tune", choices = loading)
config.plugins.openepg.enabled = ConfigEnableDisable(default = False)
config.plugins.openepg.info = ConfigEnableDisable(default = False)
if hasattr(eEPGCache.getInstance(), 'importEvent') or os.path.exists("/var/lib/dpkg/status"):
	config.plugins.openepg.convert = ConfigEnableDisable(default = False)
else:
	config.plugins.openepg.convert = ConfigEnableDisable(default = True)
config.plugins.openepg.wakeup = ConfigClock(default = ((5*60) + 45) * 60)
waking=[]
waking.append(("no",_("no")))
waking.append(("yes",_("yes")))
waking.append(("temporary",_("temporary")))
config.plugins.openepg.wakefromstandby = ConfigSelection(default = "no", choices = waking)
resetting=[]
resetting.append(("events",_("events")))
resetting.append(("empty",_("empty")))
config.plugins.openepg.reset = ConfigSelection(default = "empty", choices = resetting)
config.plugins.openepg.days = ConfigInteger(default = 0, limits=(0,30)) 
config.plugins.openepg.lastimport = ConfigText(default = "")
config.plugins.openepg.delay = ConfigInteger(default = 0, limits=(0,30)) 
config.plugins.openepg.priority = ConfigInteger(default = 100, limits=(90,110)) 
importing=[]
importing.append(("channels",_("Channels")))
for filename in os.listdir("/etc/enigma2"):            
   	if filename.startswith("userbouquet") and filename.endswith(".tv"):
		bouquetfile="/etc/enigma2/%s" % filename
		f=open(bouquetfile,"r")
		bouquet=f.readline()
		f.close()
		bouquetname=bouquet.replace("#NAME ","").replace(" (TV)","").rstrip().lstrip()
		importing.append((filename,bouquetname))
config.plugins.openepg.bouquet = ConfigSelection(default = "channels", choices = importing)
config.plugins.openepg.episode = ConfigEnableDisable(default = False)
demuxes=[]
for name in os.listdir("/dev/dvb/adapter0"):            
	if name.startswith("demux"):
		number=name.replace("demux","")
		demuxes.append((number, number))
demuxes.sort() 
# 3 is good for single tuner, 2 for dual tuner ...
config.plugins.openepg.demux = ConfigSelection(default = "3", choices = demuxes)

class OpenEPG(Screen, ConfigListScreen):
	skin = """
		<screen position="center,80" size="680,480" title="%s" >
        	<ePixmap position="10,10" size="100,40" pixmap="%s/openepg.png" transparent="1" alphatest="on" />
        	<widget name="config" position="10,60" size="660,350" scrollbarMode="showOnDemand" />
		<widget name="buttonred" position="120,10" size="130,40" backgroundColor="red" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;18"/>
		<widget name="buttongreen" position="260,10" size="130,40" backgroundColor="green" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;18"/>
		<widget name="buttonyellow" position="400,10" size="130,40" backgroundColor="yellow" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;18"/>
		<widget name="buttonblue" position="540,10" size="130,40" backgroundColor="blue" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;18"/>
		<ePixmap alphatest="on" pixmap="skin_default/icons/clock.png" position="650,440" size="20,20" zPosition="3"/>
		<widget font="Regular;18" halign="left" position="580,430" render="Label" size="55,40" source="global.CurrentTime" transparent="1" valign="center" zPosition="3">
			<convert type="ClockToText">Default</convert>
		</widget>
		<widget name="status" position="10,430" size="580,40" font="Regular;18" valign="center" />
	</screen>""" % (openepg_title,openepg_plugindir)
	def __init__(self, session, args = 0):
		Screen.__init__(self, session)
        	self.skin = OpenEPG.skin  
                self.epginstance = eEPGCache.getInstance()         
		self.source_name="OpenTV"
		global openepg_events_loaded
		if openepg_events_loaded < 0:
			openepg_events_loaded=0
	        # explicit check on every entry
		self.onChangedEntry = []
	        self.list = []                                                  
	       	ConfigListScreen.__init__(self, self.list, session = self.session, on_change = self.changedEntry)
	       	self.createSetup()       
                self["status"] = Label()                                        
		self["buttonred"] = Label(_("Exit"))
		self["buttongreen"] = Label(_("Load"))
		if os.path.exists("/var/lib/dpkg/status"):
			self["buttonyellow"] = Label(_("Reset"))
		else:
			self["buttonyellow"] = Label(_("---"))
		self["buttonblue"] = Label(_("About"))
        	self["actions"] = ActionMap(["SetupActions", "ColorActions"],{"ok": self.save,  "exit": self.cancel, "cancel": self.save, "red": self.save, "green": self.loadepg, "yellow": self.reset, "blue": self.about, })
		self.updateTimer = eTimer()
		if os.path.exists("/var/lib/dpkg/status"):
			self.updateTimer_conn = self.updateTimer.timeout.connect(self.updateStatus)
		else:
		        self.updateTimer.callback.append(self.updateStatus)
		self.updateTimer.start(2000,True)
		self.updateStatus()
	
	def cleanLoad(self):
		if crossepg_keep:
			print "[EPGDB] keeps busy"
			return
		print "[EPGDB] cleans busy"
		if os.path.exists(openepg_download):
			os.remove(openepg_download)
		if os.path.exists(openepg_dbinfo):
			os.remove(openepg_dbinfo)
		if os.path.exists(openepg_dbconvert):
			os.remove(openepg_dbconvert)
		for name in os.listdir("/tmp"):            
   			if name.startswith("crossepg") or name.startswith("mhw") or name.startswith("movistar"):
				os.remove("/tmp/%s" % name)
		if os.path.exists(openepg_resetting):
			os.remove(openepg_resetting)

	def checkLoad(self):
		busy=False
		if os.path.exists(openepg_download):
			busy=True
		if os.path.exists(openepg_dbinfo):
			busy=True
		if os.path.exists(openepg_dbconvert):
			busy=True
		for name in os.listdir("/tmp"):            
   			if name.startswith("crossepg") or name.startswith("mhw") or name.startswith("movistar"):
				busy=True
		if os.path.exists(openepg_resetting):
			busy=True
		return busy

	def updateStatus(self):
		global openepg_events_loaded
		self.updateTimer.stop()
		if self.checkLoad() and not os.path.exists(openepg_resetting):
			self["buttonblue"].setText(_("Abort"))
		else:
			self["buttonblue"].setText(_("About"))
		text = ""
		if os.path.exists(openepg_download) and not os.path.exists(openepg_dbinfo):
			cross=0
			for name in os.listdir("/tmp"):            
	   			if name.startswith("crossepg") or name.startswith("mhw") or name.startswith("movistar"):
					cross += os.path.getsize("/tmp/%s" % name)
			cross=cross/1024
			text = _("Receiving EPG from Transponder %d kB") % cross
		if os.path.exists(openepg_dbinfo):
			if os.path.exists(openepg_download):
				size=os.path.getsize(openepg_dbinfo)/1024
				text = _("Extracting received EPG %d kB") % size
			else:
				size=0
				if os.path.exists(config.misc.epgcache_filename.value):
					size=os.path.getsize(config.misc.epgcache_filename.value)/1024
				if os.path.exists("/var/lib/dpkg/status"):
					text = _("Loading %d Events into EPG database %d kB") % (openepg_events_loaded,size)
				else:
					text = _("Loading %d Events directly into enigma2")  % (openepg_events_loaded)
		if os.path.exists(openepg_dbconvert):
			text = _("Converting EPG to %s") % config.misc.epgcache_filename.value
		if os.path.exists(openepg_resetting):
			size=0
			if os.path.exists(config.misc.epgcache_filename.value):
				size=os.path.getsize(config.misc.epgcache_filename.value)/1024
			text = _("Resetting EPG datatabase %d kB") % size
		if openepg_events_loaded < 0:
			text = _("EPG datatabase load failed - probably already corrupt")
			openepg_events_loaded=0
			self.updateTimer.start(10000,True)
		else:
			self.updateTimer.start(2000,True)
		self["status"].setText(text)

	def save(self):
		self.updateTimer.stop()
		print "[OPENEPG] saves config"
		for x in self["config"].list:
       			x[1].save()
		self.close(True)

	def cancel(self):
		self.updateTimer.stop()
		print "[OPENEPG] cancels config"
		for x in self["config"].list:
			x[1].cancel()
		self.close(False)

	def about(self):
		self.updateStatus()
		if self.checkLoad() and not os.path.exists(openepg_resetting):
			self.cleanLoad()
			self.session.open(MessageBox, openepg_title+"\n\n"+_("Download was reset!"), MessageBox.TYPE_WARNING)
		else:
			self.session.open(MessageBox, openepg_title+"\n\n"+_("Thanks for the CrossEPG binaries!")+"\n\n"+config.plugins.openepg.lastimport.value, MessageBox.TYPE_INFO)
		self.updateStatus()

	def reset(self):
		if self.checkLoad():
			self.session.open(MessageBox, _("Open EPG is busy"),  MessageBox.TYPE_WARNING)  
			return
		if not os.path.exists("/var/lib/dpkg/status"):
			return
		global openepg_events_loaded
		openepg_events_loaded=0
    		open(openepg_resetting, 'a').close()  
		self.epginstance = eEPGCache.getInstance()
		if config.plugins.openepg.reset.value == "events":
			config.plugins.openepg.lastimport.value=_("EPG datatabase save for resetting started at %s %s") % (datetime.date.today(),time.strftime("%H:%M"))
			self.updateStatus()
			self.cacheState_conn = self.epginstance.cacheState.connect(self.cacheStateChanged)
	        	eEPGCache.save(self.epginstance)                   
		else: # empty database
			config.plugins.openepg.lastimport.value=_("EPG datatabase emptying started at %s %s") % (datetime.date.today(),time.strftime("%H:%M"))
			self.updateStatus()
			if os.path.exists(config.misc.epgcache_filename.value):
				os.remove(config.misc.epgcache_filename.value)
			connection = sqlite.connect(config.misc.epgcache_filename.value, timeout=10)
			connection.text_factory = str
			cursor = connection.cursor()
			cursor.execute("CREATE TABLE T_Service (id INTEGER PRIMARY KEY, sid INTEGER NOT NULL, tsid INTEGER, onid INTEGER, dvbnamespace INTEGER, changed DATETIME NOT NULL DEFAULT current_timestamp)")
			cursor.execute("CREATE TABLE T_Source (id INTEGER PRIMARY KEY, source_name TEXT NOT NULL, priority INTEGER NOT NULL, changed DATETIME NOT NULL DEFAULT current_timestamp)")
			cursor.execute("CREATE TABLE T_Title (id INTEGER PRIMARY KEY, hash INTEGER NOT NULL UNIQUE, title TEXT NOT NULL, changed DATETIME NOT NULL DEFAULT current_timestamp)")
			cursor.execute("CREATE TABLE T_Short_Description (id INTEGER PRIMARY KEY, hash INTEGER NOT NULL UNIQUE, short_description TEXT NOT NULL, changed DATETIME NOT NULL DEFAULT current_timestamp)")
			cursor.execute("CREATE TABLE T_Extended_Description (id INTEGER PRIMARY KEY, hash INTEGER NOT NULL UNIQUE, extended_description TEXT NOT NULL, changed DATETIME NOT NULL DEFAULT current_timestamp)")
			cursor.execute("CREATE TABLE T_Event (id INTEGER PRIMARY KEY, service_id INTEGER NOT NULL, begin_time INTEGER NOT NULL, duration INTEGER NOT NULL, source_id INTEGER NOT NULL, dvb_event_id INTEGER, changed DATETIME NOT NULL DEFAULT current_timestamp)")
			cursor.execute("CREATE TABLE T_Data (event_id INTEGER NOT NULL, title_id INTEGER, short_description_id INTEGER, extended_description_id INTEGER, iso_639_language_code TEXT NOT NULL, changed DATETIME NOT NULL DEFAULT current_timestamp)")
			cursor.execute("CREATE INDEX data_title ON T_Data (title_id)")
			cursor.execute("CREATE INDEX data_shortdescr ON T_Data (short_description_id)")
			cursor.execute("CREATE INDEX data_extdescr ON T_Data (extended_description_id)")
			cursor.execute("CREATE INDEX service_sid ON T_Service (sid)")
			cursor.execute("CREATE INDEX event_service_id_begin_time ON T_Event (service_id, begin_time)")
			cursor.execute("CREATE INDEX event_dvb_id ON T_Event (dvb_event_id)")
			cursor.execute("CREATE INDEX data_event_id ON T_Data (event_id)")
			cursor.execute("CREATE TRIGGER tr_on_delete_cascade_t_event AFTER DELETE ON T_Event FOR EACH ROW BEGIN DELETE FROM T_Data WHERE event_id = OLD.id; END")
			cursor.execute("CREATE TRIGGER tr_on_delete_cascade_t_service_t_event AFTER DELETE ON T_Service FOR EACH ROW BEGIN DELETE FROM T_Event WHERE service_id = OLD.id; END")
			cursor.execute("CREATE TRIGGER tr_on_delete_cascade_t_data_t_title AFTER DELETE ON T_Data FOR EACH ROW WHEN ((SELECT event_id FROM T_Data WHERE title_id = OLD.title_id LIMIT 1) ISNULL) BEGIN DELETE FROM T_Title WHERE id = OLD.title_id; END")
			cursor.execute("CREATE TRIGGER tr_on_delete_cascade_t_data_t_short_description AFTER DELETE ON T_Data FOR EACH ROW WHEN ((SELECT event_id FROM T_Data WHERE short_description_id = OLD.short_description_id LIMIT 1) ISNULL) BEGIN DELETE FROM T_Short_Description WHERE id = OLD.short_description_id; END")
			cursor.execute("CREATE TRIGGER tr_on_delete_cascade_t_data_t_extended_description AFTER DELETE ON T_Data FOR EACH ROW WHEN ((SELECT event_id FROM T_Data WHERE extended_description_id = OLD.extended_description_id LIMIT 1) ISNULL) BEGIN DELETE FROM T_Extended_Description WHERE id = OLD.extended_description_id; END")
			cursor.execute("CREATE TRIGGER tr_on_update_cascade_t_data AFTER UPDATE ON T_Data FOR EACH ROW WHEN (OLD.title_id <> NEW.title_id AND ((SELECT event_id FROM T_Data WHERE title_id = OLD.title_id LIMIT 1) ISNULL)) BEGIN DELETE FROM T_Title WHERE id = OLD.title_id; END")
			cursor.execute("INSERT INTO T_Source (id,source_name,priority) VALUES('0','Sky Private EPG','0')")
			cursor.execute("INSERT INTO T_Source (id,source_name,priority) VALUES('1','DVB Now/Next Table','0')")
			cursor.execute("INSERT INTO T_Source (id,source_name,priority) VALUES('2','DVB Schedule (same Transponder)','0')")
			cursor.execute("INSERT INTO T_Source (id,source_name,priority) VALUES('3','DVB Schedule Other (other Transponder)','0')")
			cursor.execute("INSERT INTO T_Source (id,source_name,priority) VALUES('4','Viasat','0')")
                        connection.commit()
			cursor.close()
			connection.close()
			config.plugins.openepg.lastimport.value=_("EPG loading of empty database started at %s %s") % (datetime.date.today(),time.strftime("%H:%M"))
			print "[OPENEPG] loads now empty epg.db"
			self.cacheState_conn = self.epginstance.cacheState.connect(self.cacheStateChanged)
			eEPGCache.load(self.epginstance)                   

	def cacheStateChanged(self, state):
		global openepg_events_loaded
		if state.state == cachestate.load_finished:
			del self.cacheState_conn
        		print "[EPGDB] epgcache load finished"
			if os.path.exists(openepg_resetting):
				os.remove(openepg_resetting)
				print "[OPENEPG] epg.db reset finished"
				if config.plugins.openepg.reset.value == "events":
					if openepg_events_loaded < 0:
						config.plugins.openepg.lastimport.value=_("EPG Events reset failed at %s %s - probably already corrupt") % (datetime.date.today(),time.strftime("%H:%M"))
					else:
						config.plugins.openepg.lastimport.value=_("EPG Events were reset at %s %s") % (datetime.date.today(),time.strftime("%H:%M"))
				else: # empty database 
					config.plugins.openepg.lastimport.value=_("EPG Database was emptied at %s %s") % (datetime.date.today(),time.strftime("%H:%M"))
				self.updateStatus()
				self.cleanLoad()
				self.session.open(MessageBox, config.plugins.openepg.lastimport.value, MessageBox.TYPE_INFO)
		elif state.state == cachestate.save_finished:
        		print "[EPGDB] epgcache save finished"
			if os.path.exists(config.misc.epgcache_filename.value):
				size=os.path.getsize(config.misc.epgcache_filename.value)/1024
				# even empty epg.db has at least 23k size
		       		min_size = 23
				if size < min_size:
					print "[OPENEPG] saving of epg.db failed"
					config.plugins.openepg.lastimport.value=_("EPG datatabase save failed at %s %s") % (datetime.date.today(),time.strftime("%H:%M"))
					if os.path.exists(openepg_resetting):
						os.remove(openepg_resetting)
					return
			else:
				print "[OPENEPG] saving of epg.db failed"
				config.plugins.openepg.lastimport.value=_("EPG datatabase save failed at %s %s") % (datetime.date.today(),time.strftime("%H:%M"))
				if os.path.exists(openepg_resetting):
					os.remove(openepg_resetting)
				return
			if os.path.exists(openepg_resetting):
#				os.remove(openepg_resetting)
				config.plugins.openepg.lastimport.value=_("EPG datatabase cleaning started at %s %s") % (datetime.date.today(),time.strftime("%H:%M"))
				print "[OPENEPG] cleans now external events"
				try:
					connection = sqlite.connect(config.misc.epgcache_filename.value, timeout=10)
					connection.text_factory = str
					cursor = connection.cursor()
					# check if OpenTV is already a valid T_source
					cmd ="SELECT id from T_Source WHERE source_name=? and priority=?"
					self.priority=int(config.plugins.openepg.priority.value)
					cursor.execute(cmd, (self.source_name,self.priority))
					row = cursor.fetchone()
					if row is not None:
						self.source_id=int(row[0])
						print "[OPENEPG] OpenTV found with source_id %d" % (self.source_id)
					else:
						print "[OPENEPG] OpenTV was not yet loaded"
					print "[OPENEPG] deletes all external events"
        			        cmd = "DELETE FROM T_Event WHERE source_id>4"
			                cursor.execute(cmd)
					connection.commit()
					cursor.close()
					print "[OPENEPG] vacuums now epg.db"
					connection.execute("VACUUM")
					connection.close()
					config.plugins.openepg.lastimport.value=_("EPG datatabase cleaning finished at %s %s") % (datetime.date.today(),time.strftime("%H:%M"))
					print "[OPENEPG] loads now cleaned epg.db"
				        eEPGCache.load(self.epginstance)                   
		                except Exception, e:
                		        print "[OPENEPG] Error:", e
					config.plugins.openepg.lastimport.value=_("EPG datatabase cleaning failed at %s %s\n\n%s") % (datetime.date.today(),time.strftime("%H:%M"),e)
					openepg_events_loaded=-1
					return

	def finishedImport(self):
		pass

	def loadepg(self):
		for x in self["config"].list:
       			x[1].save()
		global openepg_session
		LoadOpenEPG(openepg_session)

	def changedEntry(self):                                                 
       		self.createSetup()       

	def createSetup(self):                                                  
	       	self.list = []
		self.list.append(getConfigListEntry(_("EPG Provider"), config.plugins.openepg.provider))
		self.list.append(getConfigListEntry(_("Load")+" "+_("EPG"), config.plugins.openepg.bouquet))
		if os.path.exists("/var/lib/dpkg/status"):
			self.list.append(getConfigListEntry(_("Load by"), config.plugins.openepg.tune))
		else:
			self.list.append(getConfigListEntry(_("Load by")+" "+_("demux"), config.plugins.openepg.demux))
			if hasattr(eEPGCache.getInstance(), 'importEvent'):
				self.list.append(getConfigListEntry(_("Load by")+" "+config.misc.epgcache_filename.value, config.plugins.openepg.convert))
		self.list.append(getConfigListEntry(_("Episode"), config.plugins.openepg.episode))
		if os.path.exists("/var/lib/dpkg/status"):
			self.list.append(getConfigListEntry(_("Load days [0-30] 0=unlimited"), config.plugins.openepg.days))
		self.list.append(getConfigListEntry(_("Daily automatic import"), config.plugins.openepg.enabled))
		if config.plugins.openepg.enabled.value:
			self.list.append(getConfigListEntry(_("Automatic start time"), config.plugins.openepg.wakeup))
#			self.list.append(getConfigListEntry(_("Automatic start info message"), config.plugins.openepg.info))
			self.list.append(getConfigListEntry(_("Wakeup from Standby"), config.plugins.openepg.wakefromstandby))
		self.list.append(getConfigListEntry(_("Extension Menu"), config.plugins.openepg.extension))
		if os.path.exists("/var/lib/dpkg/status"):
			self.list.append(getConfigListEntry(_("Reset"), config.plugins.openepg.reset))
			self.list.append(getConfigListEntry(_("Delay"), config.plugins.openepg.delay))
			self.list.append(getConfigListEntry(_("Priority"), config.plugins.openepg.priority))
	        self["config"].list = self.list                                 
	        self["config"].l.setList(self.list)         

def getChannelFilter(ref, bouquetchannels):                                                         
#	print "[OpenEPG] filtering channel %s with filter %s" % (ref,filter)
        channel = ServiceReference(str(ref)).getServiceName()                   
        if len(channel) == 0:                                                    
		return ""
	if bouquetchannels is None:
	        print "[OpenEPG] found channel %s" % (channel)                
		return channel
	else:
		if bouquetchannels.find(ref) is not -1:
		        print "[OpenEPG] found bouqet channel %s" % (channel)                
			return channel
	return ""
                                                                                
##################################
# Global EPG Load 
##################################

class LoadOpenEPG(Screen):
	@classmethod
	def __init__(self, session):
		global openepg_session
		if session is None:
			self.session=openepg_session
		else:
			self.session=session
		if self.checkLoad():
			self.session.open(MessageBox, _("Open EPG is busy"),  MessageBox.TYPE_WARNING)  
			return
		if not Screens.Standby.inStandby and config.plugins.openepg.info.value and config.plugins.openepg.wakefromstandby.value != "no":
			self.session.open(MessageBox, _("Open EPG is loading ..."),  MessageBox.TYPE_WARNING, timeout=10)  
		print "[OPENEPG] loading now ..."
	        self.epginstance = eEPGCache.getInstance()         
		self.source_name="OpenTV"
		self.priority=int(config.plugins.openepg.priority.value)
		global openepg_events_loaded
		openepg_events_loaded=0
		config.plugins.openepg.lastimport.value=_("EPG DVB download started at %s %s") % (datetime.date.today(),time.strftime("%H:%M"))
		# first start loading from transponder
		p=open("%s/providers/%s.conf" % (openepg_plugindir,config.plugins.openepg.provider.value),"r")
		d=p.readline()
		if d.startswith("protocol="):
			d=p.readline()
			d=p.readline()
			d=p.readline()
		description=d.replace("description=","").rstrip().lstrip()
		d=p.readline()
		d=p.readline()
		self.onid=int(d.replace("nid=","").rstrip().lstrip())
		d=p.readline()
		self.tsid=int(d.replace("tsid=","").rstrip().lstrip())
		d=p.readline()
		self.sid=int(d.replace("sid=","").rstrip().lstrip())
		d=p.readline()
		self.dvbnamespace=int(d.replace("namespace=","").rstrip().lstrip())
		epgservicerefstr="1:0:1:%X:%X:%X:%X:0:0:0:" % (self.sid,self.tsid,self.onid,self.dvbnamespace)
		epgserviceref=eServiceReference(epgservicerefstr)
		print "[OPENEPG] description %s serviceref %s" % (description,epgservicerefstr)
   		self.oldservice = self.session.nav.getCurrentlyPlayingServiceReference()
		if self.oldservice is not None:
			current_service = self.oldservice.toString()
		else:
			current_service = None
		if config.plugins.openepg.tune.value == "tune" and os.path.exists("/var/lib/dpkg/status"):
			self.session.nav.playService(epgserviceref)
			service = self.session.nav.getCurrentService()
    			stream = service and service.stream()
		else: # recording 
	               	self.streamservice=self.session.nav.recordService(epgserviceref)
			if self.streamservice is None:
				print "[OPENEPG] start recording failed"
	        	        self.downloadFinished(-2) 
			else:
		                self.streamservice.prepareStreaming()                       
                      		self.streamservice.start()                                
	    			stream = self.streamservice.stream()
				demux = stream and stream.getStreamingData()
				self.demux = demux and demux.get("demux", -1)
				if self.demux < 0: 
					self.streamservice.stop()                                
                	        	self.session.nav.stopRecordService(self.streamservice)
					self.streamservice=None
					print "[OPENEPG] stops live TV as there is no free tuner"
			       	        self.session.nav.stopService()  
					# 2nd try ... especially on single tuner box
		        	       	self.streamservice=self.session.nav.recordService(epgserviceref)
					if self.streamservice is None:
						print "[OPENEPG] start recording failed"
        		        		self.downloadFinished(-2) 
					else:
				                self.streamservice.prepareStreaming()                       
	              				self.streamservice.start()                                
						stream = self.streamservice.stream()
		if os.path.exists("/var/lib/dpkg/status"):
			demux = stream and stream.getStreamingData()
			self.demux = demux and demux.get("demux", -1)
		else:
			self.demux=int(config.plugins.openepg.demux.value)
		if self.demux < 0:
			print "[OPENEPG] found no free tuner"
	                self.downloadFinished(-2) 
		else:
			try:
				print "[OPENEPG] loads with demux %d" % self.demux
				self.download = eConsoleAppContainer()
				if os.path.exists("/var/lib/dpkg/status"):
					self.download.appClosed_conn = self.download.appClosed.connect(self.downloadFinished)
				else:
					self.download.appClosed.append(self.downloadFinished)
				command="sleep %d; %s/crossepg_downloader -l %s -d /tmp -x /dev/dvb/adapter0/demux%d -p %s > %s" % (config.plugins.openepg.delay.value, openepg_plugindir_bin, openepg_plugindir,self.demux,config.plugins.openepg.provider.value,openepg_download)
				print "[OPENEPG] executing %s" % command
				if self.download.execute(command):                                                              
               			       	self.downloadFinished(-1) 
			except:
				print "[OPENEPG] channel not found"
		                self.downloadFinished(-2) 

	@classmethod
	def downloadFinished(self, retval):                                                                       
		if retval < 0:
			print "[OPENEPG] download failed"
			config.plugins.openepg.lastimport.value=_("EPG datatabase downloads failed at %s %s") % (datetime.date.today(),time.strftime("%H:%M"))
			if retval == -1 and os.path.exists("/var/lib/dpkg/status"):
	        	        del self.download.appClosed_conn
		else:
			print "[OPENEPG] download finished"
		if config.plugins.openepg.tune.value == "tune" and os.path.exists("/var/lib/dpkg/status"):
			self.session.nav.playService(self.oldservice)
		else: # stop recording
       			self.streamservice.stop()                                
                        self.session.nav.stopRecordService(self.streamservice)
			self.streamservice=None
			del self.streamservice
			self.session.nav.playService(self.oldservice)

		if not os.path.exists(openepg_download) or retval == -1:
			self.cleanLoad()
			self.session.open(MessageBox, _("Download of EPG data for %s failed") % config.plugins.openepg.provider.value.replace("_"," ").upper(), MessageBox.TYPE_ERROR)
			return
		else:
			openepg_data=open(openepg_download,"r")
			lines=openepg_data.read()
			openepg_data.close()
			if os.path.exists(openepg_download):
				os.remove(openepg_download)
			if lines.find("Read 0 channels") is not -1:
				self.cleanLoad()
				config.plugins.openepg.lastimport.value=_("EPG datatabase downloads found no channels at %s %s") % (datetime.date.today(),time.strftime("%H:%M"))
				self.session.open(MessageBox, _("Download of EPG data for %s found no channels") % config.plugins.openepg.provider.value.replace("_"," ").upper(), MessageBox.TYPE_ERROR)
				return
			else:
				if config.plugins.openepg.convert.value:
					# second step is to convert to epg.dat from CrossEPG database ...
					if os.path.exists(config.misc.epgcache_filename.value):
						os.remove(config.misc.epgcache_filename.value)
					self.dbconvert = eConsoleAppContainer()
					if os.path.exists("/var/lib/dpkg/status"):
						self.dbconvert.appClosed_conn = self.dbconvert.appClosed.connect(self.dbconvertFinished)
					else:
						self.dbconvert.appClosed.append(self.dbconvertFinished)
					command="%s/crossepg_dbconverter -d /tmp -e %s > %s" % (openepg_plugindir_bin, config.misc.epgcache_filename.value, openepg_dbconvert)
					print "[OPENEPG] executing %s" % command
					config.plugins.openepg.lastimport.value=_("EPG datatabase convert started at %s %s") % (datetime.date.today(),time.strftime("%H:%M"))
					if self.dbconvert.execute(command):                                                              
						self.dbconvertinished(-1) 
				else:
					# second step is to extract from CrossEPG database ...
					self.dbinfo = eConsoleAppContainer()
					if os.path.exists("/var/lib/dpkg/status"):
						self.dbinfo.appClosed_conn = self.dbinfo.appClosed.connect(self.dbinfoFinished)
					else:
						self.dbinfo.appClosed.append(self.dbinfoFinished)
					command="%s/crossepg_dbinfo -t  -d /tmp > %s" % (openepg_plugindir_bin,openepg_dbinfo)
					print "[OPENEPG] executing %s" % command
					config.plugins.openepg.lastimport.value=_("EPG datatabase extract started at %s %s") % (datetime.date.today(),time.strftime("%H:%M"))
					if self.dbinfo.execute(command):                                                              
		               		        self.dbinfoFinished(-1) 

	@classmethod
	def dbinfoFinished(self, retval):                                                                       
		if retval < 0:
			print "[OPENEPG] dbinfo failed"
		else:
			print "[OPENEPG] dbinfo finished"
		if os.path.exists("/var/lib/dpkg/status"):
	                del self.dbinfo.appClosed_conn
		if not os.path.exists(openepg_dbinfo) or retval == -1:
			self.cleanLoad()
			config.plugins.openepg.lastimport.value=_("EPG datatabase extract failed at %s %s") % (datetime.date.today(),time.strftime("%H:%M"))
			self.session.open(MessageBox, _("Loading of EPG data for %s failed") % config.plugins.openepg.provider.value.replace("_"," ").upper(), MessageBox.TYPE_ERROR)
			return
		else:
			if os.path.exists("/var/lib/dpkg/status"):
				self.epginstance = eEPGCache.getInstance()
				self.epginstance.cacheState_conn = self.epginstance.cacheState.connect(self.cacheStateChanged)
				print "[OPENEPG] starts saving EPG to database"
				config.plugins.openepg.lastimport.value=_("EPG datatabase started saving at %s %s") % (datetime.date.today(),time.strftime("%H:%M"))
				self.priority=int(config.plugins.openepg.priority.value)
	              		self.epg = epgdb_class(self.source_name, self.priority, config.misc.epgcache_filename.value)
				if os.path.exists(openepg_download):
					os.remove(openepg_download)
			else:
				print "[OPENEPG] starts loading EPG to enigma2"
				config.plugins.openepg.lastimport.value=_("EPG data started saving at %s %s") % (datetime.date.today(),time.strftime("%H:%M"))
				self.priority=int(config.plugins.openepg.priority.value)
	              		self.epg = epgdat_class(self.source_name, self.priority, config.misc.epgcache_filename.value)
				print "[OPENEPG] starts loading EPG from file to enigma2"
				config.plugins.openepg.lastimport.value=_("EPG starts loading to enigma2 at %s %s") % (datetime.date.today(),time.strftime("%H:%M"))
				if twisted.python.runtime.platform.supportsThreads():
					threads.deferToThread(self.loadEPGfromFile).addCallback(lambda ignore: self.finishedImport())
				else:
					self.loadEPGfromFile()
					if openepg_events_loaded > 0:
						config.plugins.openepg.lastimport.value=_("EPG loaded %d events successfull at %s %s") % (openepg_events_loaded, datetime.date.today(),time.strftime("%H:%M"))
					else:
						config.plugins.openepg.lastimport.value=_("EPG loading failed at %s %s") % (datetime.date.today(),time.strftime("%H:%M"))
					self.cleanLoad()
					if os.path.exists(openepg_download):
						os.remove(openepg_download)

	@classmethod
	def dbconvertFinished(self, retval):                                                                       
		print "[OPENEPG] convert finished with status %d" % retval
		if os.path.exists(openepg_dbconvert) and os.path.exists(config.misc.epgcache_filename.value) and retval == 0:
			res=open(openepg_dbconvert,"r")
			result=res.read()
			res.close()
			if result.find("EPGDB closed") is not -1:
				print "[OPENEPG] starts loading EPG from file to enigma2"
				config.plugins.openepg.lastimport.value=_("EPG starts loading to enigma2 at %s %s") % (datetime.date.today(),time.strftime("%H:%M"))
				self.epgcache=eEPGCache.getInstance()
				try:
					if hasattr(self.epgcache, 'Lock'):
						# OE 2.0
						self.epgcache.Lock()  
                        	        self.epgcache.load()  
					if hasattr(self.epgcache, 'Unlock'):
						# OE 2.0
						self.epgcache.Unlock()  
					config.plugins.openepg.lastimport.value=_("EPG loaded %s successfull at %s %s") % (config.misc.epgcache_filename.value, datetime.date.today(),time.strftime("%H:%M"))
				except:
					config.plugins.openepg.lastimport.value=_("EPG data convert failed at %s %s") % (datetime.date.today(),time.strftime("%H:%M"))
					self.session.open(MessageBox, _("Convert of EPG data for %s failed") % config.plugins.openepg.provider.value.replace("_"," ").upper(), MessageBox.TYPE_ERROR)
		else:
			print "[OPENEPG] convert failed"
			config.plugins.openepg.lastimport.value=_("EPG data convert failed at %s %s") % (datetime.date.today(),time.strftime("%H:%M"))
			self.session.open(MessageBox, _("Convert of EPG data for %s failed") % config.plugins.openepg.provider.value.replace("_"," ").upper(), MessageBox.TYPE_ERROR)
		self.cleanLoad()
		if os.path.exists(openepg_dbconvert):
			os.remove(openepg_dbconvert)
		return

	@classmethod
	def checkLoad(self):
		busy=False
		if os.path.exists(openepg_download):
			busy=True
		if os.path.exists(openepg_dbinfo):
			busy=True
		for name in os.listdir("/tmp"):            
   			if name.startswith("crossepg") or name.startswith("mhw") or name.startswith("movistar"):
				busy=True
		if os.path.exists(openepg_resetting):
			busy=True
		return busy

	@classmethod
	def cleanLoad(self):
		if crossepg_keep:
			print "[EPGDB] keeps busy"
			return
		print "[EPGDB] cleans busy"
		if os.path.exists(openepg_download):
			os.remove(openepg_download)
		if os.path.exists(openepg_dbinfo):
			os.remove(openepg_dbinfo)
		for name in os.listdir("/tmp"):            
   			if name.startswith("crossepg") or name.startswith("mhw") or name.startswith("movistar"):
				os.remove("/tmp/%s" % name)
		if os.path.exists(openepg_resetting):
			os.remove(openepg_resetting)

	@classmethod
	def cacheStateChanged(self, state):
		global openepg_events_loaded
		if state.state == cachestate.load_finished:
			del self.epginstance.cacheState_conn
        		print "[EPGDB] epgcache load finished"
			if openepg_events_loaded > 0:
				config.plugins.openepg.lastimport.value=_("EPG loaded %d Events successfull at %s %s") % (openepg_events_loaded, datetime.date.today(),time.strftime("%H:%M"))
			self.cleanLoad()
			# check if this was a temporary wakeup from standby and we are still in Idle Mode
			if Screens.Standby.inStandby and config.plugins.openepg.enabled.value and config.plugins.openepg.wakefromstandby.value == "temporary":
				clock = config.plugins.openepg.wakeup.value
				nowt = time.time()
				now = time.localtime(nowt)
				wake=int(time.mktime((now.tm_year, now.tm_mon, now.tm_mday,  
					clock[0], clock[1], 0, 0, now.tm_yday, now.tm_isdst)))
				now = int(time.time())
				w=open("/proc/stb/fp/wakeup_time","r")
				wakeup_time=int(w.readline())
				w.close()
				# normally box wakes 5min before so we now probably have 10
				# as load typically takes a few minutes so we check if not more then 10
				print "[OpenEPG] now %d wake %d up %d" % (now, wake, wakeup_time)
			        if (wake > 0) and (wake - now < 600) and (wakeup_time - now < 600):  
					print "[OpenEPG] woke up from Standby and goes back to Standby"
					config.plugins.openepg.lastimport.save()
					quitMainloop(1)

		elif state.state == cachestate.save_finished:
        		print "[EPGDB] epgcache save finished"
			if os.path.exists(config.misc.epgcache_filename.value):
				size=os.path.getsize(config.misc.epgcache_filename.value)/1024
				# even empty epg.db has at least 23k size
		       		min_size = 23
				if size < min_size:
					print "[OPENEPG] saving of epg.db failed"
					config.plugins.openepg.lastimport.value=_("EPG datatabase save failed at %s %s") % (datetime.date.today(),time.strftime("%H:%M"))
					if os.path.exists(openepg_resetting):
						os.remove(openepg_resetting)
					return
			else:
				print "[OPENEPG] saving of epg.db failed"
				config.plugins.openepg.lastimport.value=_("EPG datatabase save failed at %s %s") % (datetime.date.today(),time.strftime("%H:%M"))
				self.cleanLoad()
				return
			if self.epg is not None:
				if not self.epg.start_process():
					config.plugins.openepg.lastimport.value=_("EPG datatabase failed to connect at %s %s") % (datetime.date.today(),time.strftime("%H:%M"))
		    			print "[EPGDB] EPG database failed to connect"
				else:
					config.plugins.openepg.lastimport.value=_("EPG datatabase starts loading at %s %s") % (datetime.date.today(),time.strftime("%H:%M"))
					if twisted.python.runtime.platform.supportsThreads():
						threads.deferToThread(self.loadEPGfromFile).addCallback(lambda ignore: self.finishedImport())
					else:
						self.loadEPGfromFile()

	@classmethod
	def finishedImport(self):
		if not os.path.exists("/var/lib/dpkg/status"):
			if openepg_events_loaded > 0:
				config.plugins.openepg.lastimport.value=_("EPG loaded %d events successfull at %s %s") % (openepg_events_loaded, datetime.date.today(),time.strftime("%H:%M"))
			else:
				config.plugins.openepg.lastimport.value=_("EPG loading failed at %s %s") % (datetime.date.today(),time.strftime("%H:%M"))
			self.cleanLoad()
			if os.path.exists(openepg_download):
				os.remove(openepg_download)

	def save(self):
		self.updateTimer.stop()
		print "[OPENEPG] saves config"

	@classmethod
	def loadEPGfromFile(self):                                                                       
		global openepg_events_loaded
		openepg_events_loaded=0
		self.boquets=None
		bouquetchannels=None
		if config.plugins.openepg.bouquet.value != "channels":
			bouquetfile="/etc/enigma2/%s" % config.plugins.openepg.bouquet.value
			if os.path.exists(bouquetfile):
		      		print "[OpenEPG] reads bouquet %s" % (bouquetfile)                
				f=open(bouquetfile,"r")
				bouquetchannels=f.read()
				f.close()
			else:
			        print "[OpenEPG] does not find bouquet %s" % (bouquetfile)                
		# Read all alias files in 'aliases' sub-directory and construct alias lookup table 
		aliases=[]
		if os.path.exists("%s/aliases" % (openepg_plugindir)):
			for alias_filename in os.listdir("%s/aliases" % openepg_plugindir):            
				if alias_filename.endswith(".conf"):
					aliases_in_file = 0
					p=open("%s/aliases/%s" % (openepg_plugindir,alias_filename),"r")
					line=p.readline()
					while line:
						line=''.join(line.split()) # remove all whitespace
						if line.startswith("#") or line.startswith("[") or len(line) == 0:
							# Ignore comment or empty lines
							pass
						else:
							aliases_in_file += 1
							if line.startswith("alias="):
								# MOVISTAR type of alias file:
								# format is "alias=SID:TSID:ONID,SID:TSID:ONID# comment"
								# numbers in file are already hex
								source_alias=line.split(",")
								source_refstr_start="1:0:1:%s:" % (source_alias[0].replace("alias=",""))
								alias_ref=source_alias[1].split("#")
								# ugly HD recognition
								if alias_ref[1].endswith("HD"):
									alias_refstr="1:0:19:%s:C00000:0:0:0:" % (alias_ref[0].rstrip().lstrip())
								else:
									alias_refstr="1:0:1:%s:C00000:0:0:0:" % (alias_ref[0].rstrip().lstrip())
							else:   # classic alias file format
								# format is "ONID|TSID|SID,ONID|TSID|SID|namespace"
								# numbers in file are decimal, use hex in lookup table strings
								source_alias=line.split(",")
								source_ids=source_alias[0].split("|")
								alias_ids=source_alias[1].split("|")
								source_onid=int(source_ids[0])
								source_tsid=int(source_ids[1])
								source_sid=int(source_ids[2])
								alias_onid=int(alias_ids[0])
								alias_tsid=int(alias_ids[1])
								alias_sid=int(alias_ids[2])
								# make channel name comments work 
								alias_ref=alias_ids[3].split("#")
								alias_namespace=int(alias_ref[0])
								source_refstr_start="1:0:1:%X:%X:%X" % (source_sid,source_tsid,source_onid)
								# ugly HD recognition with channel name comment
								if line.endswith("HD"):
									alias_refstr="1:0:19:%X:%X:%X:%X:0:0:0:" % (alias_sid,alias_tsid,alias_onid,alias_namespace)
								else:
									alias_refstr="1:0:1:%X:%X:%X:%X:0:0:0:" % (alias_sid,alias_tsid,alias_onid,alias_namespace)
#							print "[OPENEGP] Alias: %s < %s"  % (source_refstr_start,alias_refstr)
       							aliases.append((source_refstr_start,alias_refstr))
						line=p.readline()
					print "[OpenEPG] found %d aliases in file %s" % (aliases_in_file,alias_filename)                
					p.close()
		now = int(time.time())
		uncut=True
		if int(config.plugins.openepg.days.value) > 0:
			uncut=False
			cutoff=now+int(config.plugins.openepg.days.value)*24*3600
			print "[OPENEPG] loads data until %d epoch time" % cutoff
		lang='eng'
		if config.plugins.openepg.provider.value.find("skyit") is not -1:
			# for our Italian friends ...
			lang='ita'
		if config.plugins.openepg.provider.value.find("plus") is not -1:
			# for our Spanish friends ...
			lang='spa'
		if config.plugins.openepg.provider.value.find("movistar") is not -1:
			# for our Spanish friends ...
			lang='spa'
		if config.plugins.openepg.provider.value.find("nl") is not -1:
			# for our Dutch friends ...
			lang='dut'
		if config.plugins.openepg.provider.value.find("france") is not -1:
			# for our French friends ...
			lang='fre'
		if config.plugins.openepg.provider.value.find("cyfra") is not -1:
			# for our Polish friends ...
			lang='pol'
		try:
			openepg_data=open(openepg_dbinfo,"r")
			# first 3 lines are just log info - then comes EPG data 
			line=openepg_data.readline()
			line=openepg_data.readline()
			line=openepg_data.readline()
			line=openepg_data.readline()
			sp=[]
			while line:
				if line.startswith("Service ID:"):
					sp=line.split()
					sid=sp[2]
					tsid=sp[6]
					onid=sp[9]
					servicerefstr="1:0:1:%s:%s:%s:%X:0:0:0:" % (sid,tsid,onid,self.dvbnamespace)
					channel=getChannelFilter(servicerefstr,bouquetchannels)
					line=openepg_data.readline()
					while line.startswith("Start time:"):
						sp=line.split()
						begin=sp[2]
						duration=sp[4]
#						print "[OPENEPG] found EPG begin %s duration %s" % (begin,duration)
						title=openepg_data.readline().rstrip().lstrip()
						description=openepg_data.readline().rstrip().lstrip()
						line=openepg_data.readline().rstrip().lstrip()
#						while (line and not line.startswith("Start time:") and not line.startswith("Service ID:")):
						empty=0
						while (empty < 3 and not line.startswith("Start time:") and not line.startswith("Service ID:")):
							description +=line
							line=openepg_data.readline().rstrip().lstrip()
							if not line:
								empty=empty+1
						if config.plugins.openepg.episode.value:
							episode=[]
							episode=description.split()
							length=len(episode)
							if length > 2:
								if episode[length-1].startswith("Ep"):
#									print "[OpenEPG] episode %s %s" % (episode[length-2],episode[length-1])
									if episode[length-2].startswith("S") or episode[length-2].startswith("(S"):
										# Season and Episode
										title="%s %s %s" % (title,episode[length-2],episode[length-1])
									else:
										# only Episode
										title="%s %s" % (title,episode[length-1])
#									print "[OpenEPG] title with episode %s" % (title)
								if episode[1].startswith("Staffel") and episode[2].startswith("Folge"):
									# Season and Episode
									title="%s %s %s %s %s" % (episode[0],episode[1],episode[2],episode[3],title)
						if len(channel) > 0:
							if uncut or (int(begin) < cutoff):
								openepg_events_loaded += 1
								self.epg.add_event(begin, duration, title, description, lang)
					# no more events for this channel found - hence add to epg.db 
					channels=[]
					# here we only pass 1 channel per processing, 
					# but it has to be a tuple, so we append only 1 value
					if len(channel) > 0:
						channels.append(servicerefstr)
						# If the channel has aliases, append them to the channels list
						for entry in aliases:
							# Each tuple in aliases table is (service refstring start, alias refstring full)
							if servicerefstr.startswith(entry[0]):
								channels.append(entry[1])
						self.epg.preprocess_events_channel(channels)
				else:
					line=openepg_data.readline()
					print "[OPENEPG] unknown: %s" % line.lstrip().rstrip()
			openepg_data.close()
                except Exception, e:
                        print "[OPENEPG] Error:", e
			config.plugins.openepg.lastimport.value=_("EPG load failed at %s %s\n\n%s") % (datetime.date.today(),time.strftime("%H:%M"),e)
			openepg_events_loaded=-1
			self.cleanLoad()
			return

		# now let us close epg.db and load it to enigma2
		config.plugins.openepg.lastimport.value=_("EPG datatabase loading at %s %s") % (datetime.date.today(),time.strftime("%H:%M"))
		self.epg.final_process()      

##################################
# Autostart of EPG Load 
##################################

class OpenEPGAutoStartTimer:
	def __init__(self, session):
		self.session = session
		self.timer = eTimer() 
		if os.path.exists("/var/lib/dpkg/status"):
			self.timer_conn = self.timer.timeout.connect(self.onTimer)
		else:
		        self.timer.callback.append(self.onTimer)
		# enigma2 restart cleans all EPG Loads
		self.cleanLoad()
		self.update()

	def getWakeTime(self):
		if config.plugins.openepg.enabled.value:
			clock = config.plugins.openepg.wakeup.value
			nowt = time.time()
			now = time.localtime(nowt)
			return int(time.mktime((now.tm_year, now.tm_mon, now.tm_mday,  
				clock[0], clock[1], 0, 0, now.tm_yday, now.tm_isdst)))
		else:
			print "[OpenEPG] automatic epg loading is disabled"
			return -1 

	def update(self, atLeast = 0):
		self.timer.stop()
		wake = self.getWakeTime()
		now = int(time.time())
		if wake > 0:
			if wake < now + atLeast:
				# Tomorrow.
				wake += 24*3600
			next = wake - now
			self.timer.startLongTimer(next)
		else:
			wake = -1
		print "[OPENEPG] WakeUpTime now set to", wake, "(now=%s)" % now
		return wake

	def onTimer(self):
		self.timer.stop()
		now = int(time.time())
		print "[OPENEPG] onTimer occured at", now
		wake = self.getWakeTime()
		# If we're close enough, we're okay...
		atLeast = 0
		if wake - now < 60:
			self.autoOpenEPG() 
			atLeast = 60
		self.update(atLeast)

	def autoOpenEPG(self):
		if self.checkLoad():
			print "[OpenEPG] automatic epg loading found busy"
		else:
			print "[OpenEPG] automatic epg loading starts"
			global openepg_session
			LoadOpenEPG(openepg_session)

	def checkLoad(self):
		busy=False
		if os.path.exists(openepg_download):
			busy=True
		if os.path.exists(openepg_dbinfo):
			busy=True
		for name in os.listdir("/tmp"):            
   			if name.startswith("crossepg") or name.startswith("mhw") or name.startswith("movistar"):
				busy=True
		if os.path.exists(openepg_resetting):
			busy=True
		return busy

	def cleanLoad(self):
		print "[EPGDB] cleans busy"
		if os.path.exists(openepg_download):
			os.remove(openepg_download)
		if os.path.exists(openepg_dbinfo):
			os.remove(openepg_dbinfo)
		for name in os.listdir("/tmp"):            
   			if name.startswith("crossepg") or name.startswith("mhw") or name.startswith("movistar"):
				os.remove("/tmp/%s" % name)
		if os.path.exists(openepg_resetting):
			os.remove(openepg_resetting)

def autostart(reason, session=None, **kwargs):
	global OpenEPGautoStartTimer
	global openepg_session
	if reason == 0:
		if session is not None:
			openepg_session = session 
			if OpenEPGautoStartTimer is None:
				print "[OpenEPG] Start epg loading check"
				OpenEPGautoStartTimer = OpenEPGAutoStartTimer(session)
				if config.plugins.openepg.enabled.value and config.plugins.openepg.wakefromstandby.value != "no":
					clock = config.plugins.openepg.wakeup.value
					nowt = time.time()
					now = time.localtime(nowt)
					wake=int(time.mktime((now.tm_year, now.tm_mon, now.tm_mday,  
						clock[0], clock[1], 0, 0, now.tm_yday, now.tm_isdst)))
					now = int(time.time())
					w=open("/proc/stb/fp/wakeup_time","r")
					wakeup_time=int(w.readline())
					w.close()
					# normally box wakes 5min before
					print "[OpenEPG] now %d wake %d up %d" % (now, wake, wakeup_time)
				        if (wake > 0) and (wake - now < 600) and (wakeup_time - now < 600):  
						print "[OpenEPG] woke up from Standby and goes to Idle-Mode"
						from Tools import Notifications                         
						Notifications.AddNotification(Screens.Standby.Standby)

def getNextWakeup():                                                            
        "returns timestamp of next time when autostart should be called"        
        if OpenEPGautoStartTimer:                                                      
                if config.plugins.openepg.wakefromstandby.value != "no":      
                        print "[OPENEPG] Will wake up from deep sleep"  
                        return OpenEPGautoStartTimer.update()                          
        return -1                                                               


def main_download(session,**kwargs):                                                     
	global openepg_session
	if config.plugins.openepg.extension.value == "download":
		LoadOpenEPG(openepg_session)
	else:
		openepg_session.open(OpenEPG)       

def main(session,**kwargs):                                                     
	global openepg_session
	openepg_session.open(OpenEPG)       

def Plugins(**kwargs):
	name = _("OpenEPG")
	descr = _("loads EPG via DVB transponder")
	return [PluginDescriptor(name=name, description=descr, where = PluginDescriptor.WHERE_PLUGINMENU, icon="openepg.png", fnc=main),
		PluginDescriptor(name=name, description=descr, where = PluginDescriptor.WHERE_EVENTINFO, needsRestart = False, fnc=main_download),
		PluginDescriptor(name=name, description=descr, where = PluginDescriptor.WHERE_EXTENSIONSMENU, needsRestart = False, fnc=main_download),
      		PluginDescriptor(where=[PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART], fnc=autostart, wakeupfnc= getNextWakeup)]
