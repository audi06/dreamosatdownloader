#!/bin/sh
rm /usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/Auto_start/*_Cam.sh
rm /usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/Auto_start/*_Srv.sh
exit 0
