from enigma import getPrevAsciiCode
from Screens.Screen import Screen
from Components.ActionMap import NumberActionMap
from Components.Label import Label
from Plugins.Extensions.GlassSysUtil.editInput import editInput as Input
from Tools.BoundFunction import boundFunction

class editInputBox(Screen):
	skin = """<screen name="editInputBox" position="center,center" size="1200,110" title="InputBox">
						<widget name="text" position="10,5" size="1180,60" font="Regular;17"/>
						<ePixmap position="30,65" zPosition="3" size="560,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/tib2.png" alphatest="on"/>
						<ePixmap position="590,65" zPosition="3" size="560,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/tib2.png" alphatest="on"/>
						<widget name="input" position="10,72" size="1180,24" font="Regular;17"/>
						</screen>"""
	def __init__(self, session, title = "", windowTitle = _("Input"), useableChars = None, **kwargs):
		Screen.__init__(self, session)

		self["text"] = Label(title)
		self["input"] = Input(**kwargs)
		self.onShown.append(boundFunction(self.setTitle, windowTitle))
		if useableChars is not None:
			self["input"].setUseableChars(useableChars)

		self["actions"] = NumberActionMap(["WizardActions", "InputBoxActions", "InputAsciiActions", "KeyboardInputActions"], 
		{
			"gotAsciiCode": self.gotAsciiCode,
			"ok": self.go,
			"back": self.cancel,
			"left": self.keyLeft,
			"right": self.keyRight,
			"home": self.keyHome,
			"end": self.keyEnd,
			"deleteForward": self.keyDelete,
			"deleteBackward": self.keyBackspace,
			"tab": self.keyTab,
			"toggleOverwrite": self.keyInsert,
			"1": self.keyNumberGlobal,
			"2": self.keyNumberGlobal,
			"3": self.keyNumberGlobal,
			"4": self.keyNumberGlobal,
			"5": self.keyNumberGlobal,
			"6": self.keyNumberGlobal,
			"7": self.keyNumberGlobal,
			"8": self.keyNumberGlobal,
			"9": self.keyNumberGlobal,
			"0": self.keyNumberGlobal
		}, -1)

		if self["input"].type == Input.TEXT:
			self.onExecBegin.append(self.setKeyboardModeAscii)
		else:
			self.onExecBegin.append(self.setKeyboardModeNone)

	def gotAsciiCode(self):
		self["input"].handleAscii(getPrevAsciiCode())

	def keyLeft(self):
		self["input"].left()

	def keyRight(self):
		self["input"].right()

	def keyNumberGlobal(self, number):
		self["input"].number(number)

	def keyDelete(self):
		self["input"].delete()

	def go(self):
		self.close(self["input"].getText())

	def cancel(self):
		self.close(None)

	def keyHome(self):
		self["input"].home()

	def keyEnd(self):
		self["input"].end()

	def keyBackspace(self):
		self["input"].deleteBackward()

	def keyTab(self):
		self["input"].tab()

	def keyInsert(self):
		self["input"].toggleOverwrite()

