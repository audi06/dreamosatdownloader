ok_plugin = """<screen name="GlassSysUtil" position="center,75" size="500,597" title="Glass System Utility" backgroundColor="#31000000" >
		<widget name="list" position="20,5" size="275,455" zPosition="2" scrollbarMode="showOnDemand" backgroundColor="#31000000" />
		<ePixmap position="330,97" zPosition="1" size="107,200" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/sys_util.png" transparent="1"  alphatest="off"/>     
		<ePixmap position="20,457" zPosition="3" size="460,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/tib2.png" alphatest="on"/>
		<widget name="info" position="20,454" size="460,85" font="Regular;17" zPosition="4" valign="center" halign="center" foregroundColor="#666666" transparent="1" />                        
		<eLabel text="Update" position="343,562" size="130,25" font="Regular;20" zPosition="4" valign="center" halign="center" backgroundColor="#31000000" foregroundColor="blue" transparent="1" />
		<eLabel text="Exit" position="28,562" size="130,25" font="Regular;20" zPosition="1" valign="center" halign="center" backgroundColor="#31000000" foregroundColor="red" transparent="1"/>
		<eLabel text="Select" position="186,562" size="130,25" font="Regular;20" zPosition="1" valign="center" halign="center" backgroundColor="#31000000" foregroundColor="green" transparent="1"/>
		<ePixmap position="454,20" zPosition="2" size="36,20" pixmap="skin_default/buttons/key_menu.png" alphatest="on" />
		</screen>"""

no_plugin = """<screen name="GlassSysUtil" position="0,0" size="720,576" title="GlassSysUtil" backgroundColor="#31000000" flags="wfNoBorder" >
                 
              <eLabel text="This plugin works only with HD skin" font="Regular;22" position="130,260" size="450,30" halign="center"  backgroundColor="#353e575e" shadowColor="#1A58A6" shadowOffset="-2,-1" transparent="1"/>
            
      	      </screen>"""
	
startstop_services = """<screen name="startStopServices" position="center,center" size="440,440" title="Start/Stop Services" backgroundColor="#31000000" >

              <widget name="list" position="20,50" size="400,310" scrollbarMode="showOnDemand" backgroundColor="#31000000" />
              <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="107,360" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
              <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ok_button.png" position="273,360" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                     
              </screen>"""

startUp_Services = """<screen name="startsetup" position="center,center" size="440,440" title="Manage Startup Services" backgroundColor="#31000000" >

              <widget name="config" position="20,50" size="400,300" scrollbarMode="showOnDemand" backgroundColor="#31000000" />
              <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="107,360" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
              <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ok_button.png" position="273,360" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                     
              </screen>"""

GlassSysInfo = """<screen name="GlassSysInfo" position="0,0" size="1280,720" title="GlassSysInfo" backgroundColor="#31000000" flags="wfNoBorder" >

                      <widget name="mem_labels" font="Regular;17" position="50,50" zPosition="0" size="100,100" valign="top" halign="left" backgroundColor="#31000000" foregroundColor="#666666" transparent="1" />
                      <widget name="ram" font="Regular;17" position="163,50" zPosition="3" size="90,100" valign="top" halign="left" backgroundColor="#31000000" transparent="1" />
                      <widget name="root" font="Regular;17" position="264,50" zPosition="3" size="90,100" valign="top" halign="left" backgroundColor="#31000000" transparent="1" />
                      <widget name="swap" font="Regular;17" position="359,50" zPosition="4" size="90,100" valign="top" halign="left" backgroundColor="#31000000" transparent="1" />      
                      <widget name="mem_tot" font="Regular;17" position="454,50" zPosition="5" size="90,100" valign="top" halign="left" backgroundColor="#31000000" transparent="1" />
                      <widget name="membar" position="148,70" size="5,75" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/bar.png" orientation="orBottomToTop" zPosition="2" backgroundColor="#41000000" transparent="1" />
                      <widget name="rootbar" position="249,70" size="5,75" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/bar.png" orientation="orBottomToTop" zPosition="2" backgroundColor="#41000000" transparent="1" />
                      <widget name="swapbar" position="342,70" size="5,75" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/bar.png" orientation="orBottomToTop" zPosition="2" backgroundColor="#41000000" transparent="1" />
                      <widget name="memtotalbar" position="437,70" size="5,75" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/bar.png" orientation="orBottomToTop" zPosition="2" backgroundColor="#41000000" transparent="1" />
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/bar_back.png" position="148,70" size="5,75" zPosition="1" backgroundColor="#31000000" alphatest="on"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/bar_back.png" position="249,70" size="5,75" zPosition="1" backgroundColor="#31000000" alphatest="on"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/bar_back.png" position="342,70" size="5,75" zPosition="1" backgroundColor="#31000000" alphatest="on"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/bar_back.png" position="437,70" size="5,75" zPosition="1" backgroundColor="#31000000" alphatest="on"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/devices/mem.png" position="163,170" size="40,80" zPosition="2" backgroundColor="#31000000" alphatest="off"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/devices/root.png" position="264,170" size="40,80" zPosition="2" backgroundColor="#31000000" alphatest="off"/>                      
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/devices/swap.png" position="359,170" size="40,80" zPosition="2" backgroundColor="#31000000" alphatest="off"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/devices/summ.png" position="460,170" size="40,80" zPosition="2" backgroundColor="#31000000" alphatest="off"/>

                      <widget name="space_labels" font="Regular;17" position="50,250" zPosition="0" size="100,100" valign="top" halign="left" backgroundColor="#31000000" foregroundColor="#666666" transparent="1" />
                      <widget name="hdd" font="Regular;17" position="163,250" zPosition="3" size="90,100" valign="top" halign="left" backgroundColor="#31000000" transparent="1" />
                      <widget name="usb" font="Regular;17" position="264,250" zPosition="4" size="90,100" valign="top" halign="left" backgroundColor="#31000000" transparent="1" />      
                      <widget name="cf" font="Regular;17" position="359,250" zPosition="5" size="90,100" valign="top" halign="left" backgroundColor="#31000000" transparent="1" />      
                      <widget name="sd" font="Regular;17" position="454,250" zPosition="5" size="90,100" valign="top" halign="left" backgroundColor="#31000000" transparent="1" />
                      <widget name="hddbar" position="148,270" size="5,75" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/bar.png" orientation="orBottomToTop" zPosition="2" backgroundColor="#41000000" transparent="1" />
                      <widget name="usbbar" position="249,270" size="5,75" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/bar.png" orientation="orBottomToTop" zPosition="2" backgroundColor="#41000000" transparent="1" />
                      <widget name="cfbar" position="342,270" size="5,75" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/bar.png" orientation="orBottomToTop" zPosition="2" backgroundColor="#41000000" transparent="1" />
                      <widget name="sdbar" position="435,270" size="5,75" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/bar.png" orientation="orBottomToTop" zPosition="2" backgroundColor="#41000000" transparent="1" />
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/bar_back.png" position="148,270" size="5,75" zPosition="1" backgroundColor="#31000000" alphatest="on"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/bar_back.png" position="249,270" size="5,75" zPosition="1" backgroundColor="#31000000" alphatest="on"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/bar_back.png" position="342,270" size="5,75" zPosition="1" backgroundColor="#31000000" alphatest="on"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/bar_back.png" position="435,270" size="5,75" zPosition="1" backgroundColor="#31000000" alphatest="on"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/devices/hdd.png" position="163,370" size="40,80" zPosition="2" backgroundColor="#31000000" alphatest="off"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/devices/usb.png" position="264,370" size="40,80" zPosition="2" backgroundColor="#31000000" alphatest="off"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/devices/cf.png" position="359,370" size="40,80" zPosition="2" backgroundColor="#31000000" alphatest="off"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/devices/sd.png" position="454,370" size="40,80" zPosition="2" backgroundColor="#31000000" alphatest="off"/>

                      <widget name="HDDCPULabels"  noWrap="1" position="50,450" size="100,100" font="Regular;17" halign="left" valign="top" zPosition="0" foregroundColor="#666666" backgroundColor="#31000000" />
                      <widget name="HDDTemperature"  noWrap="1" position="133,450" size="110,90" font="Regular;17" halign="center" valign="top" backgroundColor="#31000000" />
                      <widget name="HDDstatus"  noWrap="1" position="229,450" size="110,90" font="Regular;17" halign="center" valign="top" backgroundColor="#31000000" />
                      <widget name="cpu" font="Regular;17" position="327,450" zPosition="2" size="110,90" valign="top" halign="center" backgroundColor="#31000000" transparent="1" />      
                      <widget name="sensors" font="Regular;17" position="423,450" zPosition="2" size="110,90" valign="top" halign="center" backgroundColor="#31000000" transparent="1" />      
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/devices/hdd_temp.png" position="163,500" size="40,80" zPosition="2" backgroundColor="#31000000" alphatest="off"/>
                      <widget name="HDDanim" position="264,500" size="40,80" zPosition="3" alphatest="off" />
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/devices/summ.png" position="359,500" size="40,80" zPosition="2" backgroundColor="#31000000" alphatest="off"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/devices/sensor.png" position="454,500" size="40,80" zPosition="2" backgroundColor="#31000000" alphatest="off"/>
                      <widget name="hddtempbar" position="145,490" size="5,44" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/barm.png" orientation="orBottomToTop" zPosition="2" backgroundColor="#41000000" transparent="1" />
                      <widget name="HDDstatusbar" position="246,490" size="5,44" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/barm.png" orientation="orBottomToTop" zPosition="2" backgroundColor="#41000000" transparent="1" />
                      <widget name="cpubar" position="341,490" size="5,44" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/barm.png" orientation="orBottomToTop" zPosition="2" backgroundColor="#41000000" transparent="1" />
                      <widget name="tempDBbar" position="436,490" size="5,44" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/barm.png" orientation="orBottomToTop" zPosition="2" backgroundColor="#41000000" transparent="1" />
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/barm_back.png" position="145,490" size="5,44" zPosition="1" backgroundColor="#31000000" alphatest="on"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/barm_back.png" position="246,490" size="5,44" zPosition="1" backgroundColor="#31000000" alphatest="on"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/barm_back.png" position="341,490" size="5,44" zPosition="1" backgroundColor="#31000000" alphatest="on"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/barm_back.png" position="436,490" size="5,44" zPosition="1" backgroundColor="#31000000" alphatest="on"/>

                      <eLabel text="Services:" font="Regular;17" position="50,583" zPosition="0" size="100,100" valign="top" halign="left" backgroundColor="#31000000" foregroundColor="#666666" transparent="1" />
                      <widget name="ftp_on" position="150,585" size="40,40" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/services/ftp_on.png" zPosition="2" alphatest="off" />
                      <widget name="telnet_on" position="226,585" size="40,40" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/services/telnet_on.png" zPosition="2" alphatest="off" />
                      <widget name="vpn_on" position="302,585" size="40,40" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/services/vpn_on.png" zPosition="2" alphatest="off" />
                      <widget name="smb_on" position="378,585" size="40,40" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/services/smb_on.png" zPosition="2" alphatest="off" />
                      <widget name="nfs_on" position="454,585" size="40,40" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/services/nfs_on.png" zPosition="2" alphatest="off" />
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/services/ftp.png" position="150,585" size="40,40" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/services/telnet.png" position="226,585" size="40,40" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/services/vpn.png" position="302,585" size="40,40" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/services/smb.png" position="378,585" size="40,40" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/services/nfs.png" position="454,585" size="40,40" zPosition="1" backgroundColor="#31000000" alphatest="off"/>

                      <eLabel text="Remote:" font="Regular;17" position="50,635" zPosition="0" size="100,100" valign="top" halign="left" backgroundColor="#31000000" foregroundColor="#666666" transparent="1" />
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="150,630" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/help_button.png" position="245,630" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/refresh_button.png" position="340,630" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/blue_button.png" position="435,630" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>

                      <widget name="ProccessInfo"  noWrap="1" position="604,130" size="626,220" font="Regular;17" zPosition="2" halign="left" valign="top" backgroundColor="#31000000" />
                      <widget name="DmesgInfo"  noWrap="1" position="604,450" size="626,220" font="Regular;17" zPosition="2" halign="left" valign="top" backgroundColor="#31000000" />
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/lr.png" position="604,50" size="40,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/updown.png" position="604,370" size="40,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                      <eLabel text="Process Info"    font="Regular;26" position="604,50" size="626,50" halign="center"  backgroundColor="#353e575e" shadowColor="#1A58A6" shadowOffset="-2,-1" transparent="1"/>
                      <eLabel text="Dmesg Info"    font="Regular;26" position="604,370" size="626,50" halign="center"  backgroundColor="#353e575e" shadowColor="#1A58A6" shadowOffset="-2,-1" transparent="1"/>
                      
                      </screen>""" 

GlassSysNetwork = """<screen name="Glass SysNetwork" position="435,250" size="410,220" title="Glass SysNetwork" backgroundColor="#31000000">

                      <widget name="column_labels" font="Regular;16" position="30,50" zPosition="0" size="150,80" valign="top" halign="left" backgroundColor="#31000000" foregroundColor="#666666" transparent="1" />
                      <widget name="receive" font="Regular;16" position="140,50" zPosition="3" size="130,100" valign="top" halign="left" backgroundColor="#31000000" transparent="1" />
                      <widget name="transmit" font="Regular;16" position="280,50" zPosition="5" size="120,100" valign="top" halign="left" backgroundColor="#31000000" transparent="1" />

                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="35,140" size="60,80" zPosition="1"  transparent="1" alphatest="off"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/help_button.png" position="130,140" size="60,80" zPosition="1"  alphatest="off"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/refresh_button.png" position="225,140" size="60,80" zPosition="1" alphatest="off"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/auto_button.png" position="320,140" size="60,80" zPosition="1" alphatest="off"/>
                      <widget name="autorefresh_on" position="320,140" size="60,80" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/manual_button.png" zPosition="2" alphatest="off" />
                      
                      </screen>"""

channelInfo_Center = """<screen name="Channel Info Center" position="0,0" size="1280,720" title="Channel Info Center" backgroundColor="#31000000" flags="wfNoBorder">

                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ecm_info.png" position="110,80" size="200,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                      <widget name="ecmlabels" font="Regular;17" position="90,165" zPosition="2" size="100,230" foregroundColor="#666666" transparent="1" />
                      <widget name="ecmValues" font="Regular;17" position="185,165" zPosition="3" size="195,230" transparent="1" />

                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/bitrate.png" position="120,413" size="200,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                      <widget name="bit_labels" font="Regular;17" position="88,498" zPosition="5" size="100,100" foregroundColor="#666666" transparent="1" />
                      <widget name="bit_min" font="Regular;17" position="146,498" zPosition="6" size="90,100" halign="left" transparent="1" />
                      <widget name="bit_max" font="Regular;17" position="204,498" zPosition="7" size="90,100" halign="left" transparent="1" />      
                      <widget name="bit_avg" font="Regular;17" position="262,498" zPosition="8" size="90,100" halign="left" transparent="1" />
                      <widget name="bit_act" font="Regular;17" position="320,498" zPosition="9" size="90,100" halign="left" transparent="1" />

                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/transporder.png" position="865,80" size="300,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                      <widget name="transporder_labels" font="Regular;17" position="867,165" zPosition="2" size="130,530" foregroundColor="#666666" transparent="1" />
                      <widget name="transporder_values" font="Regular;17" position="998,165" zPosition="3" size="240,560" transparent="1" />

                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/signal.png" position="520,413" size="200,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                      <eLabel text="Snr:" font="Regular;17" position="533,516" zPosition="2" size="95,20" halign="left" foregroundColor="#666666" transparent="1" />
                      <widget source="session.FrontendStatus" render="Label" font="Regular;17" position="533,535" zPosition="5" size="70,20" halign="left" transparent="1" >
                      <convert type="FrontendInfo">SNR</convert>
                      </widget>
                      <widget source="session.FrontendStatus" render="Progress" position="518,517" size="5,33" zPosition="4" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/barmm.png" orientation="orBottomToTop" transparent="1" >
                      <convert type="FrontendInfo">SNR</convert>
                      </widget>
                      <eLabel text="Agc:" font="Regular;17" position="608,516" zPosition="3" size="95,20" halign="left" foregroundColor="#666666" transparent="1"  />
                      <widget source="session.FrontendStatus" render="Label" font="Regular;17" position="608,535" zPosition="5" size="70,20" halign="left" transparent="1" >
                      <convert type="AgcConv">AgcText</convert>
                      </widget>
                      <widget source="session.FrontendStatus" render="Progress" position="593,517" size="5,33" zPosition="4" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/barmm.png" orientation="orBottomToTop" transparent="1" >
                      <convert type="AgcConv">AgcNum</convert>
                      </widget>
                      <eLabel text="Ber:" font="Regular;17" position="683,516" zPosition="4" size="95,20" halign="left" foregroundColor="#666666" transparent="1" />
                      <widget source="session.FrontendStatus" render="Label" 	font="Regular;17" position="683,535" zPosition="5" size="70,20" halign="left" transparent="1"  >
                      <convert type="FrontendInfo">BER</convert> 
                      </widget>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/barmm_back.png" position="518,517" size="5,33" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/barmm_back.png" position="593,517" size="5,33" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/barmm_back.png" position="668,517" size="5,33" zPosition="1" backgroundColor="#31000000" alphatest="off"/>

                      <widget position="395, 20" size="450,80" source="session.CurrentService" render="Label" font="Regular;38" valign="center" halign="center" backgroundColor="#353e575e" shadowColor="#1A58A6" shadowOffset="-2,-1" transparent="1">
                      <convert type="ServiceName">Name</convert>
                      </widget>
                      <widget source="session.CurrentService" render="Label" position="395,85" size="450,60" font="Regular;26" valign="center" halign="center" backgroundColor="#353e575e" shadowColor="green" shadowOffset="-2,-1" transparent="1">
                       <convert type="ServiceName">Provider</convert>
                      </widget>
                      <widget name="picchannel" position="430,161" size="100,60" zPosition="2" alphatest="on" />
                      <widget name="picprov" position="570,161" size="100,60" zPosition="2" alphatest="on" />
                      <widget name="picsat" position="710,161" size="100,60" zPosition="2" alphatest="on" />
                      <widget name="piccode" position="540,285" size="160,82" zPosition="2" alphatest="on" />
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/frame.png" position="417,150" size="126,125" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/frame.png" position="557,150" size="126,125" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/frame.png" position="697,150" size="126,125" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/frame-code.png" position="540,285" size="160,125" zPosition="0" backgroundColor="#31000000" alphatest="off"/>
 
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="610,610" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                      
                      </screen>"""

cccam_Info = """<screen name="CCCamMainScreen" position="center,center" size="440,380" title="CCCam ChoiceBox " backgroundColor="#31000000" >

                <widget name="server_name" font="Regular;17" position="0,0" zPosition="0" size="440,60" valign="center" halign="center" backgroundColor="#353e575e" shadowColor="#1A58A6" shadowOffset="-2,-1" transparent="1" />      
                <widget name="list" position="20,60" size="400,320" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="107,300" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ok_button.png" position="273,300" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                    
                </screen>"""

cccam_InfoChoiseServer = """<screen name="CCCamChoiseServer" position="center,center" size="600,420" title="CCCam Choice Server" backgroundColor="#31000000" >

                            <widget name="list" position="20,20" size="560,196" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

                            <ePixmap position="20,228" zPosition="3" size="560,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/tib2.png" alphatest="on"/>

                            <widget name="server_detailed_labels" position="20,240" size="100,230" font="Regular;17" halign="left" foregroundColor="#666666" transparent="1" />
                            <widget name="server_detailed_values" position="115,240" size="395,230" font="Regular;17" halign="left" transparent="1" />

                            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="160,348" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ok_button.png" position="380,348" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
       
                            </screen>"""
cccam_servers_Info = """<screen name="ServersInfo" position="center,center" size="600,420" title="Servers Status" backgroundColor="#31000000" >

                        <widget name="list" position="20,20" size="560,196" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

                        <ePixmap position="20,228" zPosition="3" size="560,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/tib2.png" alphatest="on"/>

                        <widget name="server_detailed_labels" position="20,240" size="100,230" font="Regular;17" halign="left" foregroundColor="#666666" transparent="1" />
                        <widget name="server_detailed_values" position="115,240" size="395,230" font="Regular;17" halign="left" transparent="1" />
                        
                        <widget name="enaButton" position="120,352" size="60,80" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ena-button.png" zPosition="2" alphatest="off" />
                        <widget name="disButton" position="120,352" size="60,80" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/dis-button.png" zPosition="2" alphatest="off" />
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/refresh_button.png" position="280,352" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="440,352" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                        
                        </screen>"""

cccam_providers_Info = """<screen name="ProvidersInfo" position="center,center" size="600,380" title="Providers Info" backgroundColor="#31000000" >

                          <widget name="list" position="20,20" size="560,196" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

                          <ePixmap position="20,228" zPosition="3" size="560,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/tib2.png" alphatest="on"/>

                          <widget name="prov_detailed_labels" position="20,240" size="100,210" font="Regular;17" halign="left" foregroundColor="#666666" transparent="1" />
                          <widget name="prov_detailed_values" position="115,240" size="395,210" font="Regular;17" halign="left" transparent="1" />

                          <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="270,319" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>

                          </screen>"""                        

cccam_shares_Info = """<screen name="SharesInfo" position="center,center" size="600,420" title="Shares Info" backgroundColor="#31000000" >

                        <widget name="list" position="20,20" size="560,196" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

                        <ePixmap position="20,228" zPosition="3" size="560,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/tib2.png" alphatest="on"/>

                        <widget name="shares_detailed_labels" position="20,240" size="100,230" font="Regular;17" halign="left" foregroundColor="#666666" transparent="1" />
                        <widget name="shares_detailed_values" position="115,240" size="395,230" font="Regular;17" halign="left" transparent="1" />

                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="270,348" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>

                        </screen>"""

cccam_clients_Info = """<screen name="ClientsInfo" position="center,center" size="600,430" title="Clients Info" backgroundColor="#31000000" >

                        <widget name="list" position="20,20" size="560,196" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

                        <ePixmap position="20,228" zPosition="3" size="560,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/tib2.png" alphatest="on"/>

                        <widget name="client_detailed_labels" position="20,240" size="100,230" font="Regular;17" halign="left" foregroundColor="#666666" transparent="1" />
                        <widget name="client_detailed_values" position="120,240" size="395,230" font="Regular;17" halign="left" transparent="1" />

                        <widget name="enaButton" position="120,365" size="60,80" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ena-button.png" zPosition="2" alphatest="off" />
                        <widget name="disButton" position="120,365" size="60,80" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/dis-button.png" zPosition="2" alphatest="off" />
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/refresh_button.png" position="280,365" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="440,365" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>

                        </screen>"""

cccam_activeClients_Info = """<screen name="ActiveClientsInfo" position="center,center" size="600,425" title="Active Clients Info" backgroundColor="#31000000" >

                        <widget name="list" position="20,20" size="560,196" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

                        <ePixmap position="20,228" zPosition="3" size="560,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/tib2.png" alphatest="on"/>

                        <widget name="active_client_detailed_labels" position="20,240" size="100,230" font="Regular;17" halign="left" foregroundColor="#666666" transparent="1" />
                        <widget name="active_client_detailed_values" position="115,240" size="395,230" font="Regular;17" halign="left" transparent="1" />

                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="270,360" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>

                        </screen>"""

cccam_entitlements = """<screen name="Entitlements" position="center,center" size="600,510" title="Local Card(s) Info" backgroundColor="#31000000" >

                        <widget name="entitlements_info"  noWrap="1" position="10,10" size="580,420" font="Regular;17" zPosition="2" halign="left" valign="top" backgroundColor="#31000000" />

                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="270,440" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>

                        </screen>"""

cccam_summary_Info = """<screen name="CccamSumaryInfo" position="center,center" size="470,320" title="Summary information" backgroundColor="#31000000" >

                        <widget name="summary_labels" font="Regular;17" position="30,30" zPosition="1" size="250,260" foregroundColor="#666666" transparent="1" />
                        <widget name="summary_values" font="Regular;17" position="265,30" zPosition="1" size="200,260" transparent="1" />

                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="205,247" size="60,80" zPosition="2" backgroundColor="#31000000" alphatest="off"/>

                        </screen>"""                        

cccam_providerCardView_Info = """<screen name="Extend view" position="center,center" size="900,470" title="Extend view" backgroundColor="#31000000" >

                                 <widget name="count" font="Regular;20" position="10,5" zPosition="1" size="200,260" transparent="1" />
                                 <widget name="list" position="20,40" size="860,320" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

                                 <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="380,380" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>

                                 </screen>""" 

UCM = """
			<screen name="Glass Cams Manager" position="center,90" size="858,535" title="UCM" backgroundColor="#31000000" >

			<widget name="config" position="40,5" size="338,55" itemHeight="25" zPosition="2" backgroundColor="#353e575e" transparent="1" />
			<ePixmap position="20,6" size="10,18" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/bp_icons/left.png" zPosition="3" alphatest="on" />
			<ePixmap position="388,6" size="10,18" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/bp_icons/right.png" zPosition="3" alphatest="on" />
			<ePixmap position="20,30" size="10,18" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/bp_icons/left.png" zPosition="3" alphatest="on" />
			<ePixmap position="388,30" size="10,18" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/bp_icons/right.png" zPosition="3" alphatest="on" />

			<ePixmap position="17,64" zPosition="1" size="385,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/bp_icons/tib.png" alphatest="on"/>
			<widget name="commPic" position="20,70"  size="20,20" zPosition="3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/bp_icons/white.png" alphatest="on" />
			<widget name="statPic" position="20,95"  size="20,20" zPosition="3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/bp_icons/white.png" alphatest="on" />
			<widget name="statCamSrvcmd" position="40,70" size="364,20" zPosition="1" font="Regular;18" halign="left" backgroundColor="#353e575e" shadowColor="#1A58A6" shadowOffset="-1,-1" transparent="1" />
			<widget name="statCamSrvbin" position="40,95" size="364,20" zPosition="1" font="Regular;18" halign="left" backgroundColor="#353e575e" shadowColor="#1A58A6" shadowOffset="-1,-1" transparent="1" />
			<ePixmap position="17,119" zPosition="1" size="385,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/bp_icons/tib.png" alphatest="on"/>
			<widget name="CamPic" position="20,125"  size="20,20" zPosition="3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/bp_icons/white.png" alphatest="on" />
			<widget name="SrvPic" position="20,150"  size="20,20" zPosition="3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/bp_icons/white.png" alphatest="on" />
			<widget name="activCam" position="40,125" size="364,20" zPosition="1" font="Regular;18" halign="left" backgroundColor="#353e575e" shadowColor="#1A58A6" shadowOffset="-1,-1" transparent="1" />
			<widget name="activSrv" position="40,150" size="364,20" zPosition="1" font="Regular;18" halign="left" backgroundColor="#353e575e" shadowColor="#1A58A6" shadowOffset="-1,-1" transparent="1" />
			<ePixmap position="17,174" zPosition="1" size="385,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/bp_icons/tib.png" alphatest="on"/>
			<widget name="fullEcmLine" position="14,317" size="390,70" zPosition="1" font="Regular;16" valign="center" halign="center" backgroundColor="#353e575e" shadowColor="#1A58A6" shadowOffset="-1,-1" transparent="1" />

      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/frame_hd.png" position="151,215" size="126,82" zPosition="1" backgroundColor="#31000000" alphatest="on"/>
      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/frame_hd.png" position="288,215" size="126,82" zPosition="1" backgroundColor="#31000000" alphatest="on"/>
			<widget name="picECM" position="14,215"  size="126,82" zPosition="2" alphatest="on" />
      <widget name="picprov" position="164,226" size="100,60" zPosition="2" alphatest="on" />
      <widget name="picsat" position="301,226" size="100,60" zPosition="2" alphatest="on" />
			<widget name="CAID_info" position="14,397" size="398,50" zPosition="1" font="Regular;16" valign="center" halign="center" backgroundColor="#353e575e" shadowColor="#1A58A6" shadowOffset="-1,-1" transparent="1" />

      <widget name="txt0" position="474,10" size="364,20" font="Regular;18" zPosition="4" valign="center" halign="left" foregroundColor="#ffffff" backgroundColor="#31000000" transparent="1" />
      <widget name="txt1" position="474,35" size="364,20" font="Regular;18" zPosition="4" valign="center" halign="left" foregroundColor="#ffffff" backgroundColor="#31000000" transparent="1" />
			<widget name="txt2" position="474,60" size="364,20" zPosition="5" font="Regular;18" valign="center" halign="left" foregroundColor="#ffffff" backgroundColor="#31000000" transparent="1" />
			<widget name="txt3" position="474,85" size="364,20" zPosition="5" font="Regular;18" valign="center" halign="left" foregroundColor="#ffffff" backgroundColor="#31000000" transparent="1" />
			<widget name="txt4" position="474,110" size="364,20" zPosition="5" font="Regular;18" valign="center" halign="left" foregroundColor="#ffffff" backgroundColor="#31000000" transparent="1" />
			<widget name="txt5" position="474,135" size="364,20" zPosition="5" font="Regular;18" valign="center" halign="left" foregroundColor="#ffffff" backgroundColor="#31000000" transparent="1" />
			<widget name="txt6" position="474,160" size="364,20" zPosition="5" font="Regular;18" valign="center" halign="left" foregroundColor="#ffffff" backgroundColor="#31000000" transparent="1" />
      <widget name="txt7" position="474,185" size="364,20" font="Regular;18" zPosition="4" valign="center" halign="left" foregroundColor="#ffffff" backgroundColor="#31000000" transparent="1" />
      <widget name="txt8" position="474,210" size="364,20" font="Regular;18" zPosition="4" valign="center" halign="left" foregroundColor="#ffffff" backgroundColor="#31000000" transparent="1" />

			<widget name="select_pict" position="444,10" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/bp_icons/arrow.png" zPosition="8" alphatest="blend" />
			<ePixmap position="513,260" size="256,200" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/bp_icons/ucm.png" zPosition="3" alphatest="blend" />
			<widget name="PicBig" position="434,251" size="400,240" zPosition="5" transparent="0" alphatest="on" />
			<widget name="PicBigFrame" position="421,240" size="426,262" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/bp_icons/ucmFrame.png" zPosition="4" transparent="1" alphatest="on" />
            			  
			<eLabel text="Stop" position="0,500" size="207,35" font="Regular;18" valign="center" halign="center" zPosition="1" foregroundColor="red" backgroundColor="#31000000" transparent="1"/>
			<eLabel text="Start/Re-start" position="207,500" size="207,35" font="Regular;18" valign="center" halign="center" zPosition="1" foregroundColor="green" backgroundColor="#31000000" transparent="1"/>
			<eLabel text="Activate" position="434,500" size="207,35" font="Regular;18" valign="center" halign="center" zPosition="1" foregroundColor="yellow" backgroundColor="#31000000" transparent="1"/>
			<eLabel text="Move selection" position="641,500" size="207,35" font="Regular;18" valign="center" halign="center" zPosition="1" foregroundColor="blue" backgroundColor="#31000000" transparent="1"/>

 			</screen>"""

oscam_start = """<screen name="OscamStartCfg" position="center,80" size="900,580" title="Oscam start cfg" backgroundColor="#31000000" >

	                  <widget name="config" position="20,10" size="860,500" zPosition="1" transparent="0" backgroundColor="#31000000" scrollbarMode="showOnDemand" />
	                  <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="180,520" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
	                  <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/dvbapi.png" position="420,520" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
	                  <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ok_button.png" position="660,520" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
 
	                  </screen>"""
                
ipkScript_center = """<screen name="GlassIpkScriptCenter" position="center,center" size="500,320" title="Ipk and Script Manager" backgroundColor="#31000000" >

                        <widget name="list" position="20,20" size="460,196" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

                        <ePixmap position="20,150" zPosition="3" size="460,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/tib2.png" alphatest="on"/>

                        <widget name="descriptions" position="20,152" size="460,78" font="Regular;17" valign="center" halign="center" foregroundColor="#666666" transparent="1" />

                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="120,230" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ok_button.png" position="320,230" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>

                        </screen>"""
                
Script_center_scr = """<screen name="GlassScriptCenter" position="center,center" size="500,320" title="Script Center" backgroundColor="#31000000" >

                        <widget name="list" position="20,20" size="460,150" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

                        <ePixmap position="20,180" zPosition="3" size="460,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/tib2.png" alphatest="on"/>

                        <widget name="descriptions" position="20,182" size="460,58" font="Regular;17" valign="center" halign="center" foregroundColor="#666666" transparent="1" />

                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="120,240" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ok_button.png" position="320,240" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>

                        </screen>""" 
                
ipk_center_scr = """<screen name="GlassIpkCenter" position="center,center" size="900,380" title="Ipk Install Center" backgroundColor="#31000000" >

                <widget name="list" position="20,20" size="860,270" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="220,310" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ok_button.png" position="620,310" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                    
                </screen>"""               

ipk_uninstall_scr = """<screen name="GlassIpkUninstallCenter" position="center,center" size="900,380" title="Ipk Uninstall Center" backgroundColor="#31000000" >

                <widget name="list" position="20,20" size="860,270" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="220,310" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ok_button.png" position="620,310" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                    
                </screen>"""
                
tar_center_scr = """<screen name="GlassTarCenter" position="center,center" size="900,380" title="Tar Install Center" backgroundColor="#31000000" >

                <widget name="list" position="20,20" size="860,270" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="220,310" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ok_button.png" position="620,310" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                    
                </screen>"""                
                
oscam_Info = """<screen name="OScamMainScreen" position="center,center" size="540,390" title="OScam ChoiceBox " backgroundColor="#31000000" >

                <widget name="server_name" font="Regular;16" position="0,0" zPosition="0" size="540,100" valign="center" halign="center" backgroundColor="#353e575e" shadowColor="#1A58A6" shadowOffset="-2,-1" transparent="1" />      
                <widget name="list" position="20,100" zPosition="1" size="400,190" scrollbarMode="showOnDemand" backgroundColor="#31000000" />
                <widget name="info" font="Regular;17" position="150,230" zPosition="3" size="380,100" valign="center" halign="center" backgroundColor="#31000000" transparent="1" />      
                <widget name="logo" position="10,238" zPosition="2" size="160,82" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/oscam.png" backgroundColor="#31000000" alphatest="on" />
 
                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="140,330" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ok_button.png" position="340,330" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                    
                </screen>"""

oscam_Files_scr = """<screen name="OscamFilesMenu" position="center,center" size="440,455" title="OScam Select Files " backgroundColor="#31000000" >

                <widget name="list" position="20,20" size="400,450" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="107,395" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ok_button.png" position="273,395" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                    
                </screen>"""

oscam_Files_scr2 = """<screen name="OscamFileShow" position="center,center" size="1100,500" title="Oscam File" backgroundColor="#31000000" >

                        <widget name="file_info" position="10,10" size="1090,415" font="Regular;16" valign="top" backgroundColor="#31000000" halign="left" />
                        
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="450,435" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                        
                        </screen>"""

oscam_InfoChoiseServer = """<screen name="OScamChoiseServer" position="center,center" size="600,420" title="OScam Choice Server" backgroundColor="#31000000" >

                            <widget name="list" position="20,20" size="560,196" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

                            <ePixmap position="20,228" zPosition="3" size="560,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/tib2.png" alphatest="on"/>

                            <widget name="server_detailed_labels" position="20,240" size="100,230" font="Regular;17" halign="left" foregroundColor="#666666" transparent="1" />
                            <widget name="server_detailed_values" position="115,240" size="395,230" font="Regular;17" halign="left" transparent="1" />

                            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="160,348" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ok_button.png" position="380,348" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
       
                            </screen>"""
                            
oscam_Summary_scr = """<screen name="OscamSummary" position="center,center" size="960,600" title="Oscam Summary Info" backgroundColor="#31000000" >

                        <widget name="list" position="20,13" size="920,374" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

                        <ePixmap position="10,398" zPosition="3" size="560,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/tib2.png" alphatest="on"/>
                        <ePixmap position="570,398" zPosition="3" size="380,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/tib2.png" alphatest="on"/>

                        <widget name="status_labels_0" position="10,410" size="90,230" font="Regular;17" halign="left" foregroundColor="#666666" transparent="1" />
                        <widget name="status_values_0" position="100,410" size="400,230" font="Regular;17" halign="left" transparent="1" />
                        <widget name="status_labels_1" position="290,410" size="110,230" font="Regular;17" halign="left" foregroundColor="#666666" transparent="1" />
                        <widget name="status_values_1" position="390,410" size="400,230" font="Regular;17" halign="left" transparent="1" />
                        <widget name="status_labels_2" position="595,410" size="120,230" font="Regular;17" halign="left" foregroundColor="#666666" transparent="1" />
                        <widget name="status_values_2" position="695,410" size="400,230" font="Regular;17" halign="left" transparent="1" />
                        
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="280,535" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/rstOsc.png" position="620,535" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                        
                        </screen>"""
                            
oscam_logInfo_scr = """<screen name="OscamLogInfo" position="center,center" size="1280,720" title="Oscam Log Info" backgroundColor="#31000000" flags="wfNoBorder" >

                        <widget name="log_info" position="50,50" size="1180,620" scrollbarMode="showOnDemand" backgroundColor="#31000000" />
                                                
                        </screen>"""

oscam_Readers_scr = """<screen name="OscamReaders" position="center,center" size="900,380" title="Oscam Readers Info" backgroundColor="#31000000" >

                        <widget name="list" position="20,20" size="860,196" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

                        <ePixmap position="10,228" zPosition="3" size="560,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/tib2.png" alphatest="on"/>
                        <ePixmap position="570,228" zPosition="3" size="320,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/tib2.png" alphatest="on"/>
 
                        <widget name="status_labels_0" position="10,240" size="270,240" font="Regular;17" halign="left" foregroundColor="#666666" transparent="1" />
                        <widget name="status_values_0" position="280,240" size="170,240" font="Regular;17" halign="left" transparent="1" />
                        <widget name="status_labels_1" position="460,240" size="270,240" font="Regular;17" halign="left" foregroundColor="#666666" transparent="1" />
                        <widget name="status_values_1" position="730,240" size="170,240" font="Regular;17" halign="left" transparent="1" />
                        
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="132,310" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ent_icon.png" position="410,310" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                        <widget name="blue_button" position="708,310" zPosition="2" size="60,80" pixmaps="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/dis-button.png,/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ena1-button.png" backgroundColor="#31000000" alphatest="off" />
                          
                        </screen>"""
                        
oscam_Users_scr = """<screen name="OscamUsers" position="center,center" size="960,435" title="Oscam Users Info" backgroundColor="#31000000" >

                        <widget name="list" position="20,20" size="920,196" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

                        <ePixmap position="10,228" zPosition="3" size="560,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/tib2.png" alphatest="on"/>
                        <ePixmap position="570,228" zPosition="3" size="380,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/tib2.png" alphatest="on"/>

                        <widget name="status_labels_0" position="10,240" size="90,230" font="Regular;17" halign="left" foregroundColor="#666666" transparent="1" />
                        <widget name="status_values_0" position="100,240" size="200,230" font="Regular;17" halign="left" transparent="1" />
                        <widget name="status_labels_1" position="310,240" size="110,230" font="Regular;17" halign="left" foregroundColor="#666666" transparent="1" />
                        <widget name="status_values_1" position="420,240" size="200,230" font="Regular;17" halign="left" transparent="1" />
                        <widget name="status_labels_2" position="630,240" size="120,230" font="Regular;17" halign="left" foregroundColor="#666666" transparent="1" />
                        <widget name="status_values_2" position="750,240" size="200,230" font="Regular;17" halign="left" transparent="1" />
                        
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="280,370" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                        <widget name="blue_button" position="620,370" zPosition="2" size="60,80" pixmaps="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/dis-button.png,/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ena1-button.png" backgroundColor="#31000000" alphatest="off" />
                        
                        </screen>"""
                        
oscam_Entitlements_scr = """<screen name="Entitlements" position="center,center" size="1280,720" title="Reader Entitlements" flags="wfNoBorder" backgroundColor="#31000000" >

                        <widget name="Crd_info" position="230,60" font="Regular;15" zPosition="1" size="1080,82" valign="center" halign="left" backgroundColor="#353e575e" shadowColor="#1A58A6" shadowOffset="-2,-1" transparent="1" />
                        <widget name="Crd_system" position="60,60" zPosition="0" size="160,82"  backgroundColor="#31000000" alphatest="on" />

                        <widget name="Host" text="Host" position="60,152" font="Regular;15" zPosition="0" size="300,20" halign="left" foregroundColor="yellow" backgroundColor="#31000000" />
                        <widget name="Caid" text="Caid" position="340,152" font="Regular;15" zPosition="1" size="300,20" halign="left" foregroundColor="yellow" backgroundColor="#31000000" />
                        <widget name="System" text="System" position="390,152" font="Regular;15" zPosition="2" size="300,20" halign="left" foregroundColor="yellow" backgroundColor="#31000000" />
                        <widget name="Type" text="Type" position="500,152" font="Regular;14" zPosition="3" size="300,20" halign="left" foregroundColor="yellow" backgroundColor="#31000000" />
                        <widget name="share id" text="share id" position="540,152" font="Regular;15" zPosition="4" size="300,20" halign="left" foregroundColor="yellow" backgroundColor="#31000000" />
                        <widget name="remote id" text="remote id" position="640,152" font="Regular;17" zPosition="5" size="300,20" halign="left" foregroundColor="yellow" backgroundColor="#31000000" />
                        <widget name="Up" text="Up" position="740,152" font="Regular;15" zPosition="6" size="300,20" halign="left" foregroundColor="yellow" backgroundColor="#31000000" />
                        <widget name="Re" text="Re" position="770,152" font="Regular;15" zPosition="7" size="300,20" halign="left" foregroundColor="yellow" backgroundColor="#31000000" />
                        <widget name="Providers" text="Providers" position="800,152" font="Regular;15" zPosition="8" size="330,20" halign="left" foregroundColor="yellow" backgroundColor="#31000000" />

                        <widget name="TypeCRD" text="Type" position="70,152" font="Regular;15" zPosition="1" size="300,20" halign="left" foregroundColor="yellow" backgroundColor="#31000000" />
                        <widget name="CaidCRD" text="Caid" position="165,152" font="Regular;15" zPosition="2" size="300,20" halign="left" foregroundColor="yellow" backgroundColor="#31000000" />
                        <widget name="Provid" text="Provid" position="240,152" font="Regular;14" zPosition="3" size="300,20" halign="left" foregroundColor="yellow" backgroundColor="#31000000" />
                        <widget name="ID" text="ID" position="340,152" font="Regular;15" zPosition="4" size="300,20" halign="left" foregroundColor="yellow" backgroundColor="#31000000" />
                        <widget name="Class" text="Class" position="540,152" font="Regular;17" zPosition="5" size="300,20" halign="left" foregroundColor="yellow" backgroundColor="#31000000" />
                        <widget name="Start Date" text="Start Date" position="690,152" font="Regular;15" zPosition="6" size="300,20" halign="left" foregroundColor="yellow" backgroundColor="#31000000" />
                        <widget name="Expire Date" text="Expire Date" position="845,152" font="Regular;15" zPosition="7" size="300,20" halign="left" foregroundColor="yellow" backgroundColor="#31000000" />
                        <widget name="Name" text="Name" position="1000,152" font="Regular;15" zPosition="7" size="300,20" halign="left" foregroundColor="yellow" backgroundColor="#31000000" />

                        <widget name="entitlements_list" position="40,172" size="1200,418" zPosition="9" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="387,610" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ent_icon_r.png" position="834,610" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>

                        </screen>""" 
                        
oscam_LB_scr = """<screen name="OscamLoadbalance" position="center,center" size="1090,520" title="Oscam Loadbalance" backgroundColor="#31000000" >

                        <eLabel position="45,20" text="Channel:" font="Regular;17" zPosition="1" size="120,20" halign="left" foregroundColor="yellow" backgroundColor="#31000000" />
                        <eLabel position="220,20" text="Channelname:" font="Regular;17" zPosition="2" size="120,20" halign="left" foregroundColor="yellow" backgroundColor="#31000000" />
                        <eLabel position="460,20" text="ECM Length:" font="Regular;17" zPosition="3" size="120,20" halign="left" foregroundColor="yellow" backgroundColor="#31000000" />
                        <eLabel position="580,20" text="Avg-Time:" font="Regular;17" zPosition="4" size="120,20" halign="left" foregroundColor="yellow" backgroundColor="#31000000" />
                        <eLabel position="680,20" text="Last-Time:" font="Regular;17" zPosition="5" size="120,20" halign="left" foregroundColor="yellow" backgroundColor="#31000000" />
                        <eLabel position="780,20" text="Count:" font="Regular;17" zPosition="6" size="120,20" halign="left" foregroundColor="yellow" backgroundColor="#31000000" />
                        <eLabel position="880,20" text="Last checked/found:" font="Regular;17" zPosition="7" size="300,20" halign="left" foregroundColor="yellow" backgroundColor="#31000000" />

                        <widget name="list" position="20,50" size="1050,400" scrollbarMode="showOnDemand" backgroundColor="#31000000" />
                       
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="550,460" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                        
                        </screen>"""

Ecm_Info_scr = """<screen name="ECMInfo" position="center,center" size="350,357" title="ECM Informations" backgroundColor="#31000000" >
                        
	               	<widget name="ecmlabels" font="Regular;16" position="20,15" zPosition="2" size="100,260" backgroundColor="#31000000" foregroundColor="#666666" transparent="1" />
                 	<widget name="ecmValues" font="Regular;16" position="116,15" zPosition="3" size="234,260" backgroundColor="#31000000" transparent="1" />

                  <widget name="piccode" position="95,260"  size="160,82" zPosition="4" alphatest="on" />
                        
                  </screen>"""                        

OSD_ECM_Menu_scr = """<screen name="OSDECMMenu" position="center,center" size="600,290" title="OSD Ecm Info setup" backgroundColor="#31000000" >

                      <widget name="list" position="20,20" size="560,115" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

                      <ePixmap position="20,140" zPosition="3" size="560,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/tib2.png" alphatest="on"/>

                      <widget name="info" position="20,142" size="560,88" font="Regular;17" valign="center" halign="center" foregroundColor="#666666" transparent="1" />

                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="160,230" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ok_button.png" position="380,230" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                    
                      </screen>"""

onScreenEcm_scr = """<screen name="OSDECMInfo" position="1030,70" size="204,34" title="..." flags="wfNoBorder" backgroundColor="#31000000" >

                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/frame-1.png" position="0,0" size="204,34" zPosition="1" backgroundColor="#31000000" alphatest="off"/>              
                        
	                 	<widget name="OSD_Ecm_info" font="Regular;18" position="2,5" halign="left" noWrap="1" zPosition="0" size="200,25" backgroundColor="#31000000" transparent="1" />
                         
                    </screen>"""

onScreenEcmBig_scr = """<screen name="BigOSDECMInfo" position="1030,70" size="204,174" title="..." flags="wfNoBorder" backgroundColor="#31000000" >
                   
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/frame-2.png" position="0,0" size="204,174" zPosition="0" backgroundColor="#31000000" alphatest="off"/>              
                        
	                    	<widget name="ecm_items" font="Regular;16" position="10,12" zPosition="2" valign="top" halign="left" size="75,170" backgroundColor="#31000000" transparent="1" />
	                    	<widget name="OSD_Ecm_info" font="Regular;16" position="85,12" zPosition="3" valign="top" halign="left" size="110,170" backgroundColor="#31000000" transparent="1" />
                         
                        </screen>"""
                        
treshold_input = """<screen name="EcmTreshold" position="center,center" size="500,130" title="Ecm Treshold" backgroundColor="#31000000" >

	                  <widget name="config" position="20,10" size="460,50" zPosition="1" transparent="0" backgroundColor="#31000000" scrollbarMode="showOnDemand" />
	                  <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="130,70" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
	                  <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ok_button.png" position="310,70" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
 
	                  </screen>"""
                    
mbox_Main = """<screen name="MboxMainScreen" position="center,center" size="960,427" title="Mbox ChoiceBox " backgroundColor="#31000000" >

               <widget name="server_name" font="Regular;17" position="0,0" zPosition="0" size="960,45" valign="center" halign="center" backgroundColor="#353e575e" shadowColor="#1A58A6" shadowOffset="-2,-1" transparent="1" />      
               <widget name="list" position="20,45" size="200,110" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

               <ePixmap position="10,155" zPosition="3" size="560,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/tib2.png" alphatest="on"/>
               <ePixmap position="570,155" zPosition="3" size="380,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/tib2.png" alphatest="on"/>

               <widget name="info" position="10,167" size="940,180" font="Regular;14" valign="center" halign="left" backgroundColor="#31000000" transparent="1" />
 
               <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="280,357" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
               <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ok_button.png" position="620,357" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                    
               </screen>"""
                
mbox_pid_scr = """<screen name="MboxPidInfo" position="center,center" size="400,380" title="Pid Info" backgroundColor="#31000000" >

                  <widget name="list" position="20,20" size="360,196" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

                  <ePixmap position="20,228" zPosition="3" size="360,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/tib2.png" alphatest="on"/>

                  <widget name="status_labels_0" position="20,240" size="100,210" font="Regular;17" halign="left" foregroundColor="#666666" transparent="1" />
                  <widget name="status_values_0" position="115,240" size="395,210" font="Regular;17" halign="left" transparent="1" />

                  <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="170,319" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>

                  </screen>"""                
                
mbox_servers_scr = """<screen name="MboxServerInfo" position="center,center" size="400,380" title="Servers Info" backgroundColor="#31000000" >

                      <widget name="list" position="20,20" size="360,196" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

                      <ePixmap position="20,228" zPosition="3" size="360,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/tib2.png" alphatest="on"/>

                      <widget name="status_labels_0" position="20,240" size="100,210" font="Regular;17" halign="left" foregroundColor="#666666" transparent="1" />
                      <widget name="status_values_0" position="115,240" size="395,210" font="Regular;17" halign="left" transparent="1" />

                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="170,319" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>

                      </screen>"""                

mbox_netstat_scr = """<screen name="MboxNetState" position="center,center" size="600,420" title="Net Status" backgroundColor="#31000000" >

                      <widget name="list" position="20,20" size="560,196" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

                      <ePixmap position="20,228" zPosition="3" size="560,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/tib2.png" alphatest="on"/>

                      <widget name="status_labels_0" position="20,240" size="100,210" font="Regular;17" halign="left" foregroundColor="#666666" transparent="1" />
                      <widget name="status_values_0" position="130,240" size="450,210" font="Regular;17" halign="left" transparent="1" />

                      <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="270,359" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>

                      </screen>"""

mbox_share_scr = """<screen name="MboxShare" position="center,center" size="400,440" title="Share Info" backgroundColor="#31000000" >

                    <widget name="list" position="20,20" size="360,196" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

                    <ePixmap position="20,228" zPosition="3" size="360,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/tib2.png" alphatest="on"/>

                    <widget name="status_labels_0" position="20,240" size="100,210" font="Regular;17" halign="left" foregroundColor="#666666" transparent="1" />
                    <widget name="status_values_0" position="115,240" size="395,210" font="Regular;17" halign="left" transparent="1" />

                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="170,379" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>

                    </screen>"""
                    
swap_main = """<screen name="Swap Menu" position="center,center" size="400,320" title="Swap Menu" backgroundColor="#31000000" >

               <widget name="list" position="40,40" size="260,60" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

               <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="80,260" size="80,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
               <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ok_button.png" position="240,260" size="80,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>

               </screen>"""   
                        
swap_info = """<screen name="Swap Summary Info" position="center,center" size="800,300" title="Swap info and delete" backgroundColor="#31000000" >
               <eLabel text="Filename:" font="Regular;17" position="20,20" size="250,20" backgroundColor="#31000000"/>
               <eLabel text="Type:" font="Regular;17" position="420,20" size="100,20" backgroundColor="#31000000"/>
               <eLabel text="Size:" font="Regular;17" position="510,20" size="100,20" backgroundColor="#31000000"/>
               <eLabel text="Used:" font="Regular;17" position="620,20" size="100,20" backgroundColor="#31000000"/>
               <eLabel text="Priority:" font="Regular;17" position="710,20" size="80,20" backgroundColor="#31000000"/>

               <widget name="list" position="20,40" size="760,100" scrollbarMode="showOnDemand" backgroundColor="#31000000" zPosition="2"  />

               <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="213,240" size="80,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
               <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/button-del.png" position="507,240" size="80,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>

               </screen>"""
                        
swap_create = """<screen name="Swap create" position="center,center" size="600,400" title="Swap create" backgroundColor="#31000000" >

                 <widget name="config" position="20,20" size="400,50" zPosition="2" backgroundColor="#353e575e" transparent="1" />

                 <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="147,340" size="80,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                 <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/button-cr.png" position="386,340" size="80,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
 
                 </screen>"""                                                                                                                                                                                

devices_management_main = """<screen name="Devices Management" position="center,center" size="800,415" title="Devices Management" backgroundColor="#31000000" >
                 <ePixmap position="20,18" zPosition="3" size="760,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/devices/tib3.png" alphatest="on"/>

                 <widget name="devices" position="20,20" size="760,321" scrollbarMode="showOnDemand" />

                 <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="155,355" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                 <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/create.png" position="370,355" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                 <widget name="button_bg" position="585,355" size="60,80" pixmaps="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ok_button.png,/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/del.png" zPosition="1" backgroundColor="#31000000" alphatest="off" />

                 </screen>"""
                 
usb_management = """<screen name="Usb Management" position="center,center" size="500,342" title="Usb Management" backgroundColor="#31000000" >

                        <widget name="list" position="20,10" size="275,250" zPosition="2" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

                        <ePixmap position="313,18" zPosition="-1" size="145,169" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/devices/usb2.png" alphatest="off"/>     
                        <ePixmap position="20,197" zPosition="3" size="460,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/tib2.png" alphatest="on"/>

                        <widget name="info" position="20,199" size="460,75" font="Regular;17" zPosition="4" valign="center" halign="center" foregroundColor="#666666" transparent="1" />

                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="120,272" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ok_button.png" position="320,272" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>

                        </screen>"""                 

hdd_management = """<screen name="Hdd Management" position="center,center" size="500,342" title="Hdd Management" backgroundColor="#31000000" >

                        <widget name="list" position="20,10" size="275,250" zPosition="2" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

                        <ePixmap position="313,18" zPosition="-1" size="145,154" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/devices/hdd2.png" alphatest="off"/>     
                        <ePixmap position="20,197" zPosition="3" size="460,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/tib2.png" alphatest="on"/>

                        <widget name="info" position="20,199" size="460,75" font="Regular;17" zPosition="4" valign="center" halign="center" foregroundColor="#666666" transparent="1" />

                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="120,272" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ok_button.png" position="320,272" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>

                        </screen>"""
                        
select_Partition = """<screen name="Select Partition" position="center,center" size="850,259" title="Select Partition" backgroundColor="#31000000" >

                        <eLabel position="40,15" text="Part.:" font="Regular;17" zPosition="1" size="120,20" valign="center" halign="left" backgroundColor="#31000000" />
                        <eLabel position="110,15" text="Mount:" font="Regular;17" zPosition="2" size="120,20" valign="center" halign="left" backgroundColor="#31000000" />
                        <eLabel position="270,15" text="Start:" font="Regular;17" zPosition="3" size="120,20" valign="center" halign="left" backgroundColor="#31000000" />
                        <eLabel position="390,15" text="End:" font="Regular;17" zPosition="4" size="120,20" valign="center" halign="left" backgroundColor="#31000000" />
                        <eLabel position="510,15" text="Size:" font="Regular;17" zPosition="5" size="120,20" valign="center" halign="left" backgroundColor="#31000000" />
                        <eLabel position="630,15" text="Id:" font="Regular;17" zPosition="6" size="120,20" valign="center" halign="left" backgroundColor="#31000000" />
                        <eLabel position="670,15" text="Type:" font="Regular;17" zPosition="7" size="120,20" valign="center" halign="left" backgroundColor="#31000000" />
                         
                        <widget name="list" position="10,40" size="830,250" zPosition="0" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="122,199" size="60,80" zPosition="4" backgroundColor="#31000000" alphatest="off"/>
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/part-add.png" position="304,199" size="60,80" zPosition="4" backgroundColor="#31000000" alphatest="off"/>
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/part-del.png" position="486,199" size="60,80" zPosition="4" backgroundColor="#31000000" alphatest="off"/>
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ok_button.png" position="668,199" size="60,80" zPosition="4" backgroundColor="#31000000" alphatest="off"/>

                        </screen>"""
                        
autoInst_cfg = """<screen name="AutoInstCfg" position="center,160" size="850,200" title="AutoInstall" backgroundColor="#31000000" >

	                  <widget name="config" position="20,20" size="810,90" zPosition="1" transparent="0" backgroundColor="#31000000" scrollbarMode="showOnDemand" />
	                  <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="122,140" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/status.png" position="304,140" size="60,80" zPosition="4" backgroundColor="#31000000" alphatest="off"/>
                    <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/install.png" position="486,140" size="60,80" zPosition="4" backgroundColor="#31000000" alphatest="off"/>
	                  <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ok_button.png" position="668,140" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
 
	                  </screen>"""
                                                                    
autoInstStatus_scr = """<screen name="AutoInstState" position="center,center" size="800,400" title="AutoInstall Status" backgroundColor="#31000000" >

                        <widget name="list" position="20,20" size="760,300" zPosition="0" scrollbarMode="showOnDemand" backgroundColor="#31000000" />
                        
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="370,340" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                        
                        </screen>"""
                        
settings_menu = """<screen name="SettingsMenu" position="center,center" size="600,304" title="Settings/satellites.xml menu" backgroundColor="#31000000" >

                        <widget name="list" position="20,10" size="560,165" zPosition="2" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

                        <ePixmap position="20,175" zPosition="3" size="560,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/tib2.png" alphatest="on"/>

                        <widget name="info" position="20,177" size="560,68" font="Regular;17" zPosition="4" valign="center" halign="center" foregroundColor="#666666" transparent="1" />

                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="160,244" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ok_button.png" position="380,244" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>

                        </screen>"""

settings_center_scr = """<screen name="SettingsCenter" position="center,center" size="900,380" title="Please, select zip/rar file with settings" backgroundColor="#31000000" >

                <widget name="list" position="20,20" size="860,270" scrollbarMode="showOnDemand" backgroundColor="#31000000" />

                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/back_button.png" position="220,310" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/GlassSysUtil/icons/ok_button.png" position="620,310" size="60,80" zPosition="1" backgroundColor="#31000000" alphatest="off"/>
                    
                </screen>"""  
                
cronMng_scr = """<screen position="center,center" size="720,400" title="Cron Manager" backgroundColor="#31000000" >
                <widget name="list" position="20,20" size="680,310" scrollbarMode="showOnDemand" backgroundColor="#31000000" />
    <widget name="key_red" position="0,350" zPosition="1" size="120,40" font="Regular;18" halign="center" valign="center" backgroundColor="#31000000" foregroundColor="red" transparent="1" />
    <widget name="key_yellow" position="120,350" zPosition="1" size="120,40" font="Regular;18" halign="center" valign="center" backgroundColor="#31000000" foregroundColor="yellow" transparent="1" />
    <widget name="key_green" position="240,350" zPosition="1" size="120,40" font="Regular;18" halign="center" valign="center" backgroundColor="#31000000" foregroundColor="green" transparent="1" />
    <widget name="key_blue" position="360,350" zPosition="1" size="120,40" font="Regular;18" halign="center" valign="center" backgroundColor="#31000000" foregroundColor="blue" transparent="1" />
    <widget name="key_ok" position="480,350" zPosition="1" size="120,40" font="Regular;18" halign="center" valign="center" backgroundColor="#31000000" foregroundColor="white" transparent="1" />
    <widget name="key_exit" position="600,350" zPosition="1" size="120,40" font="Regular;18" halign="center" valign="center" backgroundColor="#31000000" foregroundColor="white" transparent="1" />

    </screen>"""                

cfgScreen = """<screen name="GSUcfgScreen" position="center,center" size="600,400" title="GSU configuration" backgroundColor="#31000000" >
    <widget name="config" position="10,10" size="580,330" zPosition="1" transparent="0" backgroundColor="#31000000" scrollbarMode="showOnDemand" />
    <eLabel text="Exit" position="0,350" size="300,30" font="Regular;24" zPosition="1" valign="center" halign="center" backgroundColor="#31000000" foregroundColor="red" transparent="1"/>
    <eLabel text="Save" position="300,350" size="300,30" font="Regular;24" zPosition="1" valign="center" halign="center" backgroundColor="#31000000" foregroundColor="green" transparent="1"/> 
	  </screen>"""
	                  
