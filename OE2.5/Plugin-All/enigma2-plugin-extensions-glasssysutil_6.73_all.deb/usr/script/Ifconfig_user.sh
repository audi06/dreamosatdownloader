#!/bin/sh
#ScriptName=Network Interfaces
#description= Show Network Interfaces
ifconfig

echo ""
exit 0

