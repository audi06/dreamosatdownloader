#!/bin/sh
netstat | grep tcp
netstat | grep unix

echo ""
exit 0