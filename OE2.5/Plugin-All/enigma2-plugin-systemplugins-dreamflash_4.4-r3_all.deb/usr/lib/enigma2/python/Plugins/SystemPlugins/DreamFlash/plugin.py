from Plugins.Plugin import PluginDescriptor
from Tools.HardwareInfo import HardwareInfo
from downloader import DreamFlashDownload, filescan
from os import path, mkdir
from enigma import eConsoleAppContainer

def DreamFlashMain(session, **kwargs):
	session.open(DreamFlashDownload)

def DreamFlasherMain(session, tmp = None, **kwargs):
	session.open(DreamFlashDownload)

def DreamFlashCallFnc(tmp = None):
	return DreamFlasherMain

def autostart(reason,**kwargs):                   
        if kwargs.has_key("session") and reason == 0:
                session = kwargs["session"]          
                print "[DreamFlash] autostart"
                if not path.exists("/media/DREAMFLASH"):
                	mkdir("/media/DREAMFLASH")
                if path.exists("/dev/disk/by-label/DREAMFLASH"):
	                print "[DreamFlash] mounts USB ..."
			container = eConsoleAppContainer()             
			container.execute("mount -o rw,async /dev/disk/by-label/DREAMFLASH /media/DREAMFLASH")

def Plugins(**kwargs):
	return [PluginDescriptor(name=_("Dream Flash"),
		description=_("Install a new image with a USB stick"),
		icon = "dreamflash.png",
		where = PluginDescriptor.WHERE_SOFTWAREMANAGER,
		needsRestart = False,
		fnc={"SoftwareSupported": DreamFlashCallFnc, "menuEntryName": lambda x: _("Dream Flash"),
			"menuEntryDescription": lambda x: _("Install a new image with a USB stick")}),
		PluginDescriptor(name=_("Dream Flash"),
		description=_("Install a new image with a USB stick"),
		icon = "dreamflash.png",
		where = PluginDescriptor.WHERE_PLUGINMENU,
		needsRestart = False,
		fnc=DreamFlashMain),
		PluginDescriptor(name="dreamflash", where = PluginDescriptor.WHERE_FILESCAN, needsRestart = False, fnc = filescan),
		PluginDescriptor(where = [PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART], fnc = autostart)]
