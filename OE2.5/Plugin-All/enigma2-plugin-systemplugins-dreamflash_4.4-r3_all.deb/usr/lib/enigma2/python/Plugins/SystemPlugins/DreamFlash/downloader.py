# -*- coding: utf-8 -*-
#
dreamflash_version="4.4-r3"
#
dreamflash_about="Dream Flash Plugin"
#
dreamflash_author=_("(c) gutemine")+" "+_("Version")+" "+ dreamflash_version
#
dreamflash_support="Kit and Support www.oozoon-board.de"
#
# Thanks for the NFIFlasher plugin, which was the basis for all this
#
from Plugins.SystemPlugins.Hotplug.plugin import hotplugNotifier
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Screens.HelpMenu import HelpableScreen
from Screens.TaskView import JobView
from Components.About import about
from Components.ActionMap import ActionMap
from Components.Sources.List import List
from Components.Label import Label
from Components.FileList import FileList
from Components.MultiContent import MultiContentEntryText
from Components.ScrollLabel import ScrollLabel
from Components.Sources.StaticText import StaticText
from Components.Harddisk import harddiskmanager
from Components.Task import Task, Job, job_manager, Condition
from Components.config import config, ConfigSubsection, ConfigText, ConfigBoolean, ConfigInteger, ConfigSelection, getConfigListEntry
from Components.ConfigList import ConfigListScreen
from Tools.Directories import isMount, resolveFilename, SCOPE_HDD, SCOPE_MEDIA
from Tools.HardwareInfo import HardwareInfo
from Tools.Downloader import downloadWithProgress
from enigma import eConsoleAppContainer, getDesktop, gFont, RT_HALIGN_LEFT, RT_HALIGN_CENTER, RT_VALIGN_CENTER, RT_WRAP, eTimer
from os import system, access, remove, readlink, R_OK, mkdir, listdir, path, chmod, statvfs
from twisted.web import client
import re
import base64
import hashlib
import time

LINE="################################################"
KEY_KROGOTH="mQENBFf2sl4BCADLOA4VixBkeZahH8JDHH5MzJllK0OSmWBsK0LPBD3DPc+nci5lceDzY1HuHpG6\n\
iqpkCU8Dsr9TYfpLjLBMUoAOXDxcdU/GVQ1U3Of/1fhG+ZNb2GhiP4vR9omPeujkKmmcgaViR9ia\n\
px/DIcMCnx95WgZ4KBTH9OGgrYI0jHaBi4RcJPzDyNB/B8p/tMEx2PRXjecubr3FPY+bJDR3bPLS\n\
sjgU6Gj6VHRz90couUJQ70ZayXUSAEB0Xu6NhszjOKWZO52PD+nLe5KUkVYCi2h9/XX/h1m4Cfg9\n\
NEMy6UpCl86cA6LGuFQ+cTkfaGLkCUYHlWDBeo7AVsYnj+lQuWnfABEBAAG0R29wZW5kcmVhbWJv\n\
eCByZXBvc2l0b3J5IHNpZ25pbmcga2V5ICgyLjUpIDxyZXBvc2l0b3J5QG9wZW5kcmVhbWJveC5v\n\
cmc+iQE4BBMBAgAiBQJX9rJeAhsDBgsJCAcDAgYVCAIJCgsEFgIDAQIeAQIXgAAKCRB7dL9J+iIE\n\
59cEB/oDMdR5DqNMh6ZLdWWLMmtILw8SQ8S1nDsBVqm9uJYY6bM3WglPeAPR5GW21C/sCKVXHBI9\n\
yIzvd3C8XnCP11rNHVOgN5fo7JMMPrZNvZr9mFP6mXBPvTjm5zlGZVPp33ajDANvjyRNwWeZOGI0\n\
IEYmeKTt02lnncGwLyBfic06sp9Yz4e8qW2KVErEg9pWsakhxJzQrJRvMF9w9AzeIelQqcJEwd+v\n\
PTFxW77/r+vQbinW8fKxPHMuVFkJiF9evfHyUDcLepe9Zgetve/Z73KIBjjk8PX5UAJqAKT0rNCc\n\
kDLoJ9bq6USze9RQNmqEfA/Sr9P8ezkrzvsXftP3EnjPuQENBFf2sl4BCADMAna974PotpvcYMgR\n\
1ch/71SljKqTZbsSVeamkdwSwmpxmeEfH5iIA3phaAAJ5OjVc7sSMX8EJU8nszIo7eIaO4aoQdgN\n\
g86H7JVMBc4gGxQAfUPcp6oiKcyufZdz52xT8qyFmzpwiwVNg60I5eTRRHOdv14+SniipOG0jqNA\n\
elHQm9BJwPh4ohRAgK8QOoPTitq/llSOnxZyX09LjMmtyUPtiCbH4OtKYAYcj5GsDVpb14+Tz4NC\n\
B9tx/mEzfUGr5SpmKaorqSDMXxJZ6jtoFXUXTw2qjsLWESwHyVD6s4ugfDfsMQzMEIuSDzeGF6u0\n\
E6ADndlf1W9Y+apyDUfFABEBAAGJAR8EGAECAAkFAlf2sl4CGwwACgkQe3S/SfoiBOdJ1wf+JXWL\n\
w2E3rkObvzXdsfiO1VvS6YpTY5v6M4AtG+t5R9/gkMooYiCTWGrKTsIPttwKvaEE3CpX0tcFCPc/\n\
n7hEiJD6xIhoXx1OJH52Svc4oOhHTmBCpuMtAvtBsBMm4OJg8tLDb7I/OXdpJT+YUNhxfs2+/u/3\n\
75H8Mf2pUDfu58gHpaH6cHcRypRKJTWYuagBZ+jEKl1zpAkqQMPQxGET/wWhisZwwS680qBkL+iO\n\
85jokbt9hbFYvvi6qM0WqkqN9wiIKAXlJn4Yri6sXlwGltTdfE72h7cWJfdi7wTLu1W1mVVBtsds\n\
7fDteCBdzElW9pWpNlRWRu85cIBMBExCrQ=="

# for later usage from librecovery
KEY_PYRO="""
mQENBFgH4aYBCADihD/BzLWxDBO9b/3jPAeWfB0cDUzoMXVSZaoVTxbcrDpIblNEONPKAZ/cCrFG
6hKgeHqCQpb13onRNrn9LM0FenrmBiO2zB1pxyDCtv9mnkm7wUuIdCTUIFPRoupGnwYuvFcFrvjl
hotim/Q9+sksQ1j5dR0rByP8nfO0YvdOKVpQwBsx2qh3iCjdz39d9Q50qNHFxfxHcGNPhXoKPIQ3
8QxxEvOcyDciIwuqG9g1WIr2lyDgkGmukUmGN+KpicIXGamZlaKsJgygdapJNXxxaAbqgzDzq1Ld
eIsLdHLQ4xIxX7+x17uAl+OmZexkei18iLgyzNpEnAKdumyMvpwHABEBAAG0R29wZW5kcmVhbWJv
eCByZXBvc2l0b3J5IHNpZ25pbmcga2V5ICgyLjcpIDxyZXBvc2l0b3J5QG9wZW5kcmVhbWJveC5v
cmc+iQE4BBMBAgAiBQJYB+GmAhsDBgsJCAcDAgYVCAIJCgsEFgIDAQIeAQIXgAAKCRDI4nzv4C9h
bzdxCAC1jyJQtGVuDd7br2C4e4YaWqRj+T4t9+sUzHU3rIPVZr5kKJVJh808cgcWEEEhpzD8XWxL
WFF+Do2aiem52Y77da7nLDy31nHv/J19M6Gh8H41pwsaT7OMyB0tn962fS556EczfA9aFOF1fTJn
vLJj1SnMACbtbT29X8SOKYUHLsodH83klc8o8MrILDRTe5fc3lHC06BPtVYK6fgyrxLeOP6gHZPS
eiqL0c/DKRntl0Hyfb1GnOy0ovDGHgtu53eAUtrHaurtXngB/bD0I0Dm2I183jas5i9i6cq+Y7YU
p8sVD3JUKQk121s8gbL6In6D23pLnu2cVmSDQ8zXNHA3uQENBFgH4aYBCADVubVaEazvcEMTdj/R
stw6cPfsiwAJldULoYvJlGy7rtU5P0JmPWWNzsUNm88Z0tNParTa8RM2NoKkfYwmsIVci/riQI3L
kGXq/j/jltVrJCZoXN8iqZBW6bm8W2RHopzl2oftFmLnj+UJxtsQLcYfx0Yl8q9V8hqKaIdNR4Xj
XJRzETfMtYLiRTk5sPFRlms7rZ0UfchaFh92UBKV51VkA4OeUglL8s0Ev3JKAHYN8NZXB34nDEQ1
sJCEYw4I/CkSKtNLnJWPYCTULGoxIO/RVkOlEoacocnwbcehmnKiSOrlHnP5uZjj+kq17V4uHVL0
0WcUSGs2Is3CGTzy/JjZABEBAAGJAR8EGAECAAkFAlgH4aYCGwwACgkQyOJ87+AvYW/JWgf8DCNE
dHpocTPUWrR+lV8/HbiCyfMJgthtuAuEDPZKgiFLqa9FVhv6n3fSVn4IKccXAd12iTCIfOGdR6H/
5ynNzUtP2PqzCcsEWIX2ioUmqZbZrNUzS23/EWGp9cZsE6GecAa75S7+gLr0WPU9XM2kAfpteEFG
bQm80SFV5BybxtQt9llT/ZPKFwuwNl4huyInqxmv/+8KzH5jZastSV4rlmpKaPQNiiSjlkpXDgSZ
HNPeBMj3gKtM+v/L2V4UoeyRHGDfXHIqXG/JuFvZVcgppzf89IqPY5nb+NRAxk9su7VeRcSJrVZ0
paOJqGsBphzT0OuENs3Oj7RsxU9oYj5Mcg==
"""

dreamflash_plugindir="/usr/lib/enigma2/python/Plugins/SystemPlugins/DreamFlash"

yes_no_descriptions = {False: _("no"), True: _("yes")}    

config.plugins.dreamflash = ConfigSubsection()
config.plugins.dreamflash.stable_image = ConfigBoolean(default = True, descriptions=yes_no_descriptions)
config.plugins.dreamflash.unstable_image = ConfigBoolean(default = True, descriptions=yes_no_descriptions)
config.plugins.dreamflash.stable_rescue = ConfigBoolean(default = True, descriptions=yes_no_descriptions)
config.plugins.dreamflash.unstable_rescue = ConfigBoolean(default = True, descriptions=yes_no_descriptions)
config.plugins.dreamflash.signature = ConfigBoolean(default = True, descriptions=yes_no_descriptions)
config.plugins.dreamflash.info = ConfigBoolean(default = True, descriptions=yes_no_descriptions)
config.plugins.dreamflash.backup = ConfigBoolean(default = True, descriptions=yes_no_descriptions)
config.plugins.dreamflash.root_image = ConfigBoolean(default = True, descriptions=yes_no_descriptions)
config.plugins.dreamflash.asksettings = ConfigBoolean(default = True, descriptions=yes_no_descriptions)
config.plugins.dreamflash.epgdb = ConfigBoolean(default = False, descriptions=yes_no_descriptions)
config.plugins.dreamflash.mediadb = ConfigBoolean(default = False, descriptions=yes_no_descriptions)
config.plugins.dreamflash.timers = ConfigBoolean(default = False, descriptions=yes_no_descriptions)
config.plugins.dreamflash.backupsettings = ConfigBoolean(default = False, descriptions=yes_no_descriptions)
config.plugins.dreamflash.aptclean = ConfigBoolean(default = True, descriptions=yes_no_descriptions)
xz_options = []                                                     
xz_options.append(( "0","0" ))
xz_options.append(( "1","1" ))
xz_options.append(( "2","2" ))
xz_options.append(( "3","3" ))
xz_options.append(( "4","4" ))
xz_options.append(( "5","5" ))
xz_options.append(( "6","6" ))
xz_options.append(( "7","7" ))
xz_options.append(( "8","8" ))
xz_options.append(( "9","9" ))
config.plugins.dreamflash.xzcompression = ConfigSelection(default = "0", choices = xz_options)

realbox = HardwareInfo().get_device_name()                                         
if realbox == "dm525":          
	realbox="dm520"   
box_options = []                                                     
box_options.append(( "dm520",_("dm520/dm525") ))
box_options.append(( "dm820",_("dm820") ))
box_options.append(( "dm7080",_("dm7080") ))
box_options.append(( "dm900",_("dm900") ))
box_options.append(( "dm920",_("dm920") ))
config.plugins.dreamflash.box = ConfigSelection(default = realbox, choices = box_options)

feed_options = []
feed_options.append(("http://www.dreamboxupdate.com/opendreambox",_("OpenDreambox") ))
feed_options.append(("http://www.oozoon-download.de/opendreambox",_("OoZooN") ))
config.plugins.dreamflash.feed = ConfigSelection(default="http://www.dreamboxupdate.com/opendreambox", choices = feed_options)

# ignore harddisks = and allow DreamFlash evices starting from 1 GB
# USB stick has to have at least size of 1GB 
dreamflash_minsize=1
dreamflash_maxsize=512
config.plugins.dreamflash.maxdevsize = ConfigInteger(default = 64, limits = (dreamflash_minsize, dreamflash_maxsize))

size_w = getDesktop(0).size().width()  
size_h = getDesktop(0).size().height()

def dreamflash_file_as_bytes(file):
	with file:
		return file.read()

class ImageDownloadJob(Job):
	def __init__(self, url, filename, device=None, mountpoint="/tmp"):
		print "ImageDownloadJob] ", url,filename,device,mountpoint
		box=config.plugins.dreamflash.box.value
		if url.endswith(".bin"):
			Job.__init__(self, filename+" "+_("Download .NFI-Files for USB-Flasher").replace(".NFI-",""))
			filename_dreamflash="rescue-image-%s.bin" % box                     
		else:
			Job.__init__(self, filename+" "+_("Download .NFI-Files for USB-Flasher").replace(".NFI-",""))
			# fixed Filename for autoflashd ...                                            
			filename_dreamflash="dreambox-image-%s.tar.xz" % box                           

		if device:
			if not isMount(mountpoint):
				MountTask(self, device, mountpoint)

		ImageDownloadTask(self, url, mountpoint+filename_dreamflash)                   

		# get signature ...
		if url.endswith("bin") or config.plugins.dreamflash.signature.value:
			ImageDownloadTask(self, url+".sig", mountpoint+filename_dreamflash+".sig")

		# get nfo file ...
		if config.plugins.dreamflash.info.value and url.endswith(".tar.xz"):
			ImageDownloadTask(self, url[:-7]+".nfo", mountpoint+filename_dreamflash.replace(".tar.xz",".nfo"))
		
		# don't umount because we might ask for settings backup next ..
		#if device:
			#UmountTask(self, mountpoint)

	def retry(self):
		self.tasks[0].args += self.tasks[0].retryargs
		Job.retry(self)

class BackupWizardJob(Job):
        def __init__(self, path):                               
		box=config.plugins.dreamflash.box.value
                Job.__init__(self, _("Image")+" "+_("Backup"))
                self.path = path         
		# needed first !!!
		self.usbmountpoint = resolveFilename(SCOPE_MEDIA)+"DREAMFLASH/"
		if self.path.startswith("/dev"):
			# prevent raw device"
			if not self.path.endswith("1"):
				self.path=self.path+"1"
			if not isMount(self.usbmountpoint):
				MountTask(self, self.path, self.usbmountpoint)
			self.path=self.usbmountpoint
                BackupTask(self)     

class BackupTaskPostcondition(Condition):
	def check(self, task):
		return task.returncode == 0

	def getErrorMessage(self, task):
		return self.error_message
		
class BackupTask(Task):                                                           
	def __init__(self, job):                                                
		Task.__init__(self, job, _("Backup")+" "+"...")  
		self.postconditions.append(BackupTaskPostcondition())
		self.progress=0
		self.error_message=""
		realbox = HardwareInfo().get_device_name()                                         
		if realbox == "dm525":          
			realbox="dm520"   
		xz_bin="/usr/bin/xz"
		self.filename_dreamflash="dreambox-image-%s.tar.xz" % realbox                           
		self.target ="%s%s" % (self.job.path, self.filename_dreamflash)
                self.job = job                                                  
                self.setTool("sleep")                                              
	        exclude=" --exclude=smg.sock --exclude msg.sock"

		# currently hidden settings ...
		if config.plugins.dreamflash.epgdb.value:
			exclude +=" --exclude=epg.db"	
		if config.plugins.dreamflash.mediadb.value:
			exclude +=" --exclude=media.db"	
		if config.plugins.dreamflash.timers.value:
			exclude +=" --exclude=timers.xml"	
		if config.plugins.dreamflash.backupsettings.value:
			exclude +=" --exclude=settings"	
		
		dreamflash_backupscript="/tmp/dreamflash.sh"
		
		# here comes the fun ...
		command  = "#!/bin/sh -x\n"
		command +="cat %s\n" % dreamflash_backupscript
		command +="df -h\n"
		if path.exists("/etc/init.d/openvpn"):
			command +="/etc/init.d/openvpn stop\n"
		if config.plugins.dreamflash.aptclean.value:
			command += "apt-get clean\n"
		# make root filesystem ...
		command +="umount /tmp/root\n"
		command +="rmdir /tmp/root\n"
		command +="mkdir /tmp/root\n"
		command +="mount -o bind / /tmp/root\n"
		# tar.xz is default for USB stick flashing
		command +="tar %s -cf - -C /tmp/root . | %s -%s -T 0 -c - > %s\n" % (exclude, xz_bin, config.plugins.dreamflash.xzcompression.value, self.target)
		command +="umount /tmp/root\n"
		command +="rmdir /tmp/root\n"
		if path.exists("/etc/init.d/openvpn"):
			command +="/etc/init.d/openvpn start\n"
		command +="chmod 777 %s.*\n" % (self.target)
		command +="ls -alh %s*\n" % (self.target)
		command +="df -h\n"
		command +="exit 0\n"
		print command
		b=open(dreamflash_backupscript,"w")
		b.write(command)
		b.close()
		chmod(dreamflash_backupscript, 0755)

		self.setTool(dreamflash_backupscript)                                              
		self.args += [""]     
                self.weighting = 20                                             
                self.end = 200                                                   
                self.delayBackupTimer = eTimer()                                      
		if path.exists("/var/lib/dpkg/status"):
			self.delayBackupTimer_conn = self.delayBackupTimer.timeout.connect(self.progress_increment)
		else:
			self.delayBackupTimer.callback.append(self.progress_increment)
                                                                                
        def run(self, callback):                                                
                Task.run(self, callback)                                        
                self.delayBackupTimer.start(2000, False)                               
                                                                                
        def progress_increment(self):                                           
		size=0
		if path.exists(self.target):                                                       
			# MB
			size=int(path.getsize(self.target)/1024/1024)                                                       
		print "[BackupTask] size: ", size
                self.progress = size                                             
                                                                                
        def processOutput(self, data):                                          
                print "[BackupTask] output:", data                                
		self.error_message=str(data)
                                                                                
        def afterRun(self):                                                     
		# backup has no nfo and sig files ...
		if path.exists("%s/%s.nfo" % (self.job.path,self.filename_dreamflash)):
			remove("%s/%s.nfo" % (self.job.path,self.filename_dreamflash))
		if path.exists("%s/%s.sig" % (self.job.path,self.filename_dreamflash)):
			remove("%s/%s.sig" % (self.job.path,self.filename_dreamflash))
		if config.plugins.dreamflash.info.value:
			self.generateNFO()
		if path.exists("/var/lib/dpkg/status"):
	                self.delayBackupTimer_conn=None   
		else:
			self.delayBackupTimer.callback.remove(self.progress_increment)

        def generateNFO(self):                                                     
		realbox = HardwareInfo().get_device_name()                                         
		if realbox == "dm525":          
			realbox="dm520"   
		date=time.strftime("%Y-%m-%d %H:%M:%S")
		distro="opendreambox 2.5"
		if path.exists("/etc/image-version"):
			d=open("/etc/image-version","r")
			line=d.readline()
			while line:
				if line.startswith("creator="):
					line=line.replace("creator=","")
					sp=[]
					sp=line.split()
					distro=sp[0]
				line=d.readline()
			d.close()
		drivers=""
		enigma2=""
		kernel=""
		status=None
		if path.exists("/var/lib/dpkg/status"):
			status="/var/lib/dpkg/status"
		if path.exists("/var/lib/opkg/status"):
			status="/var/lib/opkg/status"
		if path.exists("/var/lib/ipkg/status"):
			status="/var/lib/ipkg/status"
		if status:
			f=open(status,"r")
			line=f.readline()
			while line:
				if line.startswith("Package: dreambox-dvb-modules-%s" % realbox) and not line.startswith("Package: dreambox-dvb-modules-%s-" % realbox):
					while line:
						line=f.readline()
						if line.startswith("Version:"):
							drivers=line.replace("Version:","").replace("\n","")
							line=""
				if line.startswith("Package: dreambox-dvb-modules") and not line.startswith("Package: dreambox-dvb-modules-"):
					while line:
						line=f.readline()
						if line.startswith("Version:"):
							drivers=line.replace("Version:","").replace("\n","")
							line=""
				if line.startswith("Package: enigma2") and not line.startswith("Package: enigma2-"):
					while line:
						line=f.readline()
						if line.startswith("Version:"):
							enigma2=line.replace("Version:","").replace("\n","")
							line=""
				if line.startswith("Package: kernel-image") and not line.startswith("Package: kernel-image-"):
					while line:
						line=f.readline()
						if line.startswith("Provides:"):
							kernel=line.replace("Provides:","").replace("\n","")
							line=""
				line=f.readline()
			f.close()
		md5file=""
		sha256file=""
		if path.exists("%sdreambox-image-%s.tar.xz" % (self.job.path,realbox)):
			full_path="%sdreambox-image-%s.tar.xz" % (self.job.path,realbox)
			md5file=hashlib.md5(dreamflash_file_as_bytes(open(full_path, 'rb'))).hexdigest()
			sha256file=hashlib.sha256(dreamflash_file_as_bytes(open(full_path, 'rb'))).hexdigest()
#			sha256file=hmac.new(byte_key, , hashlib.sha256).hexdigest().upper()
		machine="Dreambox %s" % realbox
		nfo="Date: %s\nDistro: %s\nDrivers: %s\nEnigma2: %s\nKernel: %s\nMD5: %s\nMachine: %s\nSHA256: %s\n" % (date,distro,drivers,enigma2,kernel,md5file,machine,sha256file)
		print "[generateNFO] writing:\n", nfo
		full_path="%s/%s" % (self.job.path,self.filename_dreamflash.replace(".tar.xz",".nfo"))
		if path.exists(full_path):
			remove(full_path)
		f=open(full_path,"w")
		f.write(nfo)
		f.close()

class CopyWizardJob(Job):
        def __init__(self, filename, path):                               
		box=config.plugins.dreamflash.box.value
                Job.__init__(self, filename+ " "+_("Default")+" "+_("Backup")+" "+_("Location"))
                self.filename = filename        
                self.path = path         
		# needed first !!!
		self.usbmountpoint = resolveFilename(SCOPE_MEDIA)+"DREAMFLASH/"
		if self.path.startswith("/dev"):
			# prevent raw device"
			if not self.path.endswith("1"):
				self.path=self.path+"1"
			if not isMount(self.usbmountpoint):
				MountTask(self, self.path, self.usbmountpoint)
			self.path=self.usbmountpoint
                CopyTask(self)     

class CopyTaskPostcondition(Condition):
	def check(self, task):
		return task.returncode == 0

	def getErrorMessage(self, task):
		return self.error_message
		
class CopyTask(Task):                                                           
	def __init__(self, job):                                                
		Task.__init__(self, job, _("Copy")+" "+"...")  
		self.postconditions.append(CopyTaskPostcondition())
		self.progress=0
		box=config.plugins.dreamflash.box.value
		self.filename_dreamflash="dreambox-image-%s.tar.xz" % box                           
                self.job = job                                                  
                self.setTool("cp")                                              
		self.args += [self.job.filename, "%s/%s" % (self.job.path,self.filename_dreamflash)]     
                self.weighting = 20                                             
                self.end = 100                                                   
		self.error_message=""
                self.delayTimer = eTimer()                                      
		if path.exists("/var/lib/dpkg/status"):
			self.delayTimer_conn = self.delayTimer.timeout.connect(self.progress_increment)
		else:
			self.delayTimer.callback.append(self.progress_increment)
                                                                                
        def run(self, callback):                                                
                Task.run(self, callback)                                        
                self.delayTimer.start(1000, False)                               
                                                                                
        def progress_increment(self):                                           
                self.progress += 1                                              
                                                                                
        def processOutput(self, data):                                          
                print "[CopyTask] output:", data                                
		self.error_message=data
                                                                                
        def afterRun(self):                                                     
		# copy has no nfo and sig files ...
		if path.exists("%s/%s.nfo" % (self.job.path,self.filename_dreamflash)):
			remove("%s/%s.nfo" % (self.job.path,self.filename_dreamflash))
		if path.exists("%s/%s.sig" % (self.job.path,self.filename_dreamflash)):
			remove("%s/%s.sig" % (self.job.path,self.filename_dreamflash))
		if path.exists("/var/lib/dpkg/status"):
	                self.delayTimer_conn=None   
		else:
			self.delayTimer.callback.remove(self.progress_increment)

class MountTask(Task):
	def __init__(self, job, device, mountpoint):
		Task.__init__(self, job, ("mount"))
		self.setTool("mount")
		options = "rw,async"
		type = "vfat"
		self.mountpoint = mountpoint
		self.args += [ "-o"+options, "-t"+type, device, mountpoint ]
		self.weighting = 1

	def processOutput(self, data):
		print "[MountTask] output:", data

class UmountTask(Task):
	def __init__(self, job, mountpoint):
		Task.__init__(self, job, ("umount"))
		self.setTool("umount")
		self.args += [mountpoint]
		self.weighting = 1

class DownloaderPostcondition(Condition):
	def check(self, task):
		return task.returncode == 0

	def getErrorMessage(self, task):
		return self.error_message
		
class ImageDownloadTask(Task):
	def __init__(self, job, url, path):
		Task.__init__(self, job, _("Downloading"))
		self.postconditions.append(DownloaderPostcondition())
		self.job = job
		self.url = url
		self.path = path
		self.error_message = ""
		self.last_recvbytes = 0
		self.error_message = None
		self.download = None
		self.aborted = False

	def run(self, callback):
		self.callback = callback
		self.download = downloadWithProgress(self.url,self.path)
		self.download.addProgress(self.download_progress)
		self.download.start().addCallback(self.download_finished).addErrback(self.download_failed)
		print "[ImageDownloadTask] downloading", self.url, "to", self.path

	def abort(self):
		print "[ImageDownloadTask] aborting", self.url
		if self.download:
			self.download.stop()
		self.aborted = True

	def download_progress(self, recvbytes, totalbytes):
		#print "[update_progress] recvbytes=%d, totalbytes=%d" % (recvbytes, totalbytes)
		if ( recvbytes - self.last_recvbytes  ) > 10000: # anti-flicker
			self.progress = int(100*(float(recvbytes)/float(totalbytes)))
			self.name = _("Downloading") + ' ' + "%d of %d kBytes" % (recvbytes/1024, totalbytes/1024)
			self.last_recvbytes = recvbytes

	def download_failed(self, failure_instance=None, error_message=""):
		self.error_message = error_message
		if error_message == "" and failure_instance is not None:
			self.error_message = failure_instance.getErrorMessage()
		Task.processFinished(self, 1)

	def download_finished(self, string=""):
		if self.aborted:
			self.finish(aborted = True)
		else:
			Task.processFinished(self, 0)

class FlashingWizardJob(Job):
        def __init__(self, path):                               
		realbox = HardwareInfo().get_device_name()                                         
		if realbox == "dm525":          
			realbox="dm520"   
                Job.__init__(self, _("Flashing")+" "+_("Recovery Mode")+" "+realbox)
                self.path = path         
                FlashingTask(self)     

class FlashingTaskPostcondition(Condition):
	def check(self, task):
		return task.returncode == 0

	def getErrorMessage(self, task):
		return self.error_message
		
class FlashingTask(Task):
	def __init__(self, job):
		Task.__init__(self, job, _("Flashing")+" "+_("Recovery Mode")+"...")  
		self.postconditions.append(FlashingTaskPostcondition())
		self.progress=0
		#
		if path.exists("/tmp/flash-rescue.out"):
			remove("/tmp/flash-rescue.out")
		realbox = HardwareInfo().get_device_name()                                         
		if realbox == "dm525":          
                	realbox="dm520"   
		cmd = "/usr/sbin/flash-rescue"
		print "[FlashingTask] ", cmd
		self.job = job		
		self.setTool(cmd)
		
		loader = "%srescue-image-%s.bin" % (self.job.path,realbox)
		self.args += [ "-v", loader ]
		self.weighting = 20
		self.error_message = ""
                self.end = 100                                                   
                self.flashingDelayTimer = eTimer()                                      
		if path.exists("/var/lib/dpkg/status"):
			self.flashingDelayTimer_conn = self.flashingDelayTimer.timeout.connect(self.progress_increment)
		else:
			self.flashingDelayTimer.callback.append(self.progress_increment)
                self.flashingDelayTimer.start(3000, False)                               

	def run(self, callback):
		Task.run(self, callback)
		print "[FlashingTask] flashing ..."

	def processOutput(self, data):
		print "[FlashingTask] output:", data
		self.error_message = data
		out=open("/tmp/flash-rescue.out","w")
		out.write(data)
		out.close()
		if path.exists("/var/lib/dpkg/status"):
	                self.flashingDelayTimer_conn=None      

	def progress_increment(self):
                self.progress += 1                                              
		self.setProgress(self.progress)

class StickWizardJob(Job):
        def __init__(self, path):                               
                Job.__init__(self, _("USB stick wizard"))
                self.path = path         
                self.device = path     
                while self.device[-1:] == "/" or self.device[-1:].isdigit():
                        self.device = self.device[:-1]
                                  
                #UmountTask(self, device)           
                PartitionTask(self)     

class PartitionTaskPostcondition(Condition):
	def check(self, task):
		return task.returncode == 0

	def getErrorMessage(self, task):
		return self.error_message
		
class PartitionTask(Task):
	def __init__(self, job):
		Task.__init__(self, job, _("Initialize")+" "+_("USB Stick"))  
		self.postconditions.append(PartitionTaskPostcondition())
		self.progress=0
		#
		# let's partition and format now as FAT32
		# on a single primary partition 
		# to be sure that device is ONLY for recovery
		#
		f=open("/proc/partitions","r")
		sp=[]
		line = f.readline()                                                    
		line = f.readline()                                                    
		line = f.readline()                                                    
		nn=self.job.path.replace("/dev/","")
		print "[name]", nn
		while (line):        
			sp=line.split()
			if sp[3]==nn:
				major=int(sp[0])
				minor=int(sp[1])+1
				print "[mknod] %d %d", major,minor
			line = f.readline()                                                    
		f.close()
		script="/tmp/dreamflash.sh"
		command ="#!/bin/sh -x\n"
	   	command +="umount %s1\n" % self.job.device
	   	command +="umount %s2\n" % self.job.device
	   	command +="umount %s3\n" % self.job.device
	   	command +="umount %s4\n" % self.job.device
	   	command +="umount %s\n" % self.job.device
		command +="dd if=/dev/zero of=%s bs=1024 count=1\n" % self.job.device
		command +="fdisk %s << EOF\n" % self.job.device
		command +="d\n" 
		command +="1\n" 
		command +="d\n" 
		command +="2\n" 
		command +="d\n" 
		command +="3\n" 
		command +="d\n" 
		command +="n\n" 
		command +="p\n" # new primary partition 
		command +="1\n" 
		command +="\n" 
		command +="\n" 
		command +="w\n" 
		command +="EOF\n"
		command +="partprobe %s\n" % self.job.device  
	   	command +="fdisk %s << EOF\n" % self.job.device
		command +="t\n" 
		command +="b\n" # type FAT32
		command +="a\n"
		command +="1\n" # bootable flag
		command +="w\n"
		command +="EOF\n"
		command +="partprobe %s\n" % self.job.device  
		# if partprobe failed ...
		command +="mknod %s1 b %d %d\n" % (self.job.device, major,minor)
                command +="sleep 1\n"
		#
                command +="umount %s1\n" % self.job.device
                command +="umount %s\n" % self.job.device
                command +="mkdosfs -n DREAMFLASH %s1\n" % self.job.device
                command +="mount %s1 -o rw,async -t vfat /media/DREAMFLASH\n" % self.job.device
		command +="exit 0\n"
#		print command
		b=open(script,"w")
		b.write(command)
		b.close()
		chmod(script, 0755)
		print "[DreamFlash] executing ", script
		self.job = job		
		self.setTool(script)
		self.args += [self.job.device]
		self.weighting = 20
		self.error_message = ""

	def run(self, callback):
		Task.run(self, callback)
		print "[PartitionTask] formatting ..."

	def processOutput(self, data):
		print "[PartitionTask] output:", data
		self.error_message = data
                self.progress += 5                                              
		self.setProgress(self.progress)

class NFOViewer(Screen):
	# Full HD skin
	if size_w > 1280: 
		skin = """
		<screen name="NFOViewer" position="center,170" size="1200,820" title="Changelog" >
			<widget name="changelog" position="20,20" size="1160,780" font="Regular;24" />
		</screen>"""
	else:
		skin = """
		<screen name="NFOViewer" position="center,120" size="820,520" title="Changelog" >
			<widget name="changelog" position="10,10" size="800,500" font="Regular;16" />
		</screen>"""

	def __init__(self, session, nfo):
		Screen.__init__(self, session)
		self["changelog"] = ScrollLabel(nfo)
		self.onShown.append(self.setWindowTitle)

		self["ViewerActions"] = ActionMap(["SetupActions", "ColorActions", "DirectionActions"],
			{
				"green": self.exit,
				"red": self.exit,
				"ok": self.exit,
				"cancel": self.exit,
				"down": self.pageDown,
				"up": self.pageUp
			})

        def setWindowTitle(self):        
                self.setTitle(_("NFO")+" "+_("View details"))

	def pageUp(self):
		self["changelog"].pageUp()

	def pageDown(self):
		self["changelog"].pageDown()

	def exit(self):
		self.close(False)

class feedDownloader:
	def __init__(self, feed_base, box, OE_vers, type, klasse, extension):
		print "[feedDownloader::init] feed_base=%s, box=%s OE_vers=%s type=%s klasse=%s extensions=%s" % (feed_base, box, OE_vers, type, klasse, extension)
		self.feed_base = feed_base
		self.OE_vers = OE_vers
		self.box = box
		self.type=type
		self.klasse=klasse
		self.extension=extension
	
	def getList(self, callback, errback):
		if config.plugins.dreamflash.feed.value=="http://www.dreamboxupdate.com/opendreambox":
			self.urlbase = "%s/%s/%s/images/%s/" % (self.feed_base, self.OE_vers, self.type, self.box)
		else:
			if self.klasse == "bin":
				self.urlbase = "%s/images/%s/%s/" % (self.feed_base, self.box, "rescue")
			else:
				self.urlbase = "%s/images/%s/%s/" % (self.feed_base, self.box, self.type)
		print "[getList]", self.urlbase
		self.callback = callback
		self.errback = errback
		client.getPage(self.urlbase).addCallback(self.feed_finished).addErrback(self.feed_failed)

	def feed_failed(self, failure_instance):
		print "[feed_failed]", str(failure_instance)
		self.errback(failure_instance.getErrorMessage())

	def feed_finished(self, feedhtml):
		print "[feed_finished]", feedhtml
		if config.plugins.dreamflash.feed.value=="http://www.dreamboxupdate.com/opendreambox":
			fileresultmask = re.compile("<div><a class=[\'\"]%s[\'\"] href=[\'\"](?P<url>.*?)[\'\"]>(?P<name>.*?%s)</a>" % (self.klasse,self.extension), re.DOTALL)
		else:
			fileresultmask = re.compile("<tr><td><a href=[\'\"](?P<url>.*?)[\'\"]>(?P<name>.*?)</a>", re.DOTALL)
		searchresults = fileresultmask.finditer(feedhtml)
		fileresultlist = []
		if searchresults:
			for x in searchresults:
				url = x.group("url")
				if url[0:7] != "http://":
					url = self.urlbase + x.group("url")
				name = x.group("name")
				entry = (name, url)
				fileresultlist.append(entry)
		print LINE
		print "FEEDLIST\n", fileresultlist
		print LINE
		self.callback(fileresultlist, self.OE_vers)

class DeviceBrowser(Screen, HelpableScreen):
	# Full HD skin
	if size_w > 1280: 
		skin = """
		<screen name="DeviceBrowser" position="center,170" size="1200,820" title="Please select target medium" >
		<widget backgroundColor="#9f1313" font="Regular;28" halign="center" name="buttonred" position="20,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="270,60" valign="center" />
		<widget backgroundColor="#1f771f" font="Regular;28" halign="center" name="buttongreen" position="300,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="270,60" valign="center" />
		<widget backgroundColor="#a08500" font="Regular;28" halign="center" name="buttonyellow" position="580,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="270,60" valign="center" />
		<widget backgroundColor="#18188b" font="Regular;28" halign="center" name="buttonblue" position="860,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="270,60" valign="center" />
		<ePixmap name="info" position="1130,10" size="60,30" pixmap="skin_default/buttons/key_info.png"/> 
		<ePixmap name="menu" position="1130,40" size="60,30" pixmap="skin_default/buttons/key_menu.png"/> 
		<eLabel position="10,80" size="1180,1" backgroundColor="grey" />
		<widget source="message" render="Label" position="30,100" size="1140,400" font="Regular;32" />
		<widget name="filelist" position="30,520" size="1140,280" scrollbarMode="showOnDemand" />
		</screen>"""
	else:
		skin = """
		<screen name="DeviceBrowser" position="center,120" size="820,520" title="Please select target medium" >
		<widget backgroundColor="#9f1313" font="Regular;18" halign="center" name="buttonred" position="15,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="180,40" valign="center" />
		<widget backgroundColor="#1f771f" font="Regular;18" halign="center" name="buttongreen" position="205,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="180,40" valign="center" />
		<widget backgroundColor="#a08500" font="Regular;18" halign="center" name="buttonyellow" position="395,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="180,40" valign="center" />
		<widget backgroundColor="#18188b" font="Regular;18" halign="center" name="buttonblue" position="585,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="180,40" valign="center" />
		<ePixmap name="info" position="765,5" size="40,20" pixmap="skin_default/buttons/key_info.png"/> 
		<ePixmap name="menu" position="765,25" size="40,20" pixmap="skin_default/buttons/key_menu.png"/> 
		<eLabel position="10,50" size="800,1" backgroundColor="grey" />
		<widget source="message" render="Label" position="10,60" size="800,250" font="Regular;20" />
		<widget name="filelist" position="10,320" size="800,200" scrollbarMode="showOnDemand" />
		</screen>"""

	def __init__(self, session, startdir, message="", showDirectories = True, showFiles = True, showMountpoints = True, matchingPattern = "", useServiceRef = False, inhibitDirs = False, inhibitMounts = False, isTop = False, enableWrapAround = True, additionalExtensions = None):
		Screen.__init__(self, session)

		HelpableScreen.__init__(self)

		self["buttonred"] = Label(_("Cancel"))
		self["buttongreen"] = Label("")
		self["buttonyellow"] = Label("")
		self["buttonblue"] = Label(_("About"))
		self["message"] = StaticText(message)

		self.filelist = FileList(startdir, showDirectories = showDirectories, showFiles = showFiles, showMountpoints = showMountpoints, matchingPattern = matchingPattern, useServiceRef = useServiceRef, inhibitDirs = inhibitDirs, inhibitMounts = inhibitMounts, isTop = isTop, enableWrapAround = enableWrapAround, additionalExtensions = additionalExtensions)
		self["filelist"] = self.filelist

		self["FilelistActions"] = ActionMap(["SetupActions", "ColorActions", "ChannelSelectEPGActions", "ChannelSelectEditActions"],
			{
				"green": self.use,
				"red": self.exit,
				"yellow": self.exit,
				"blue": self.about,
				"ok": self.ok,
				"cancel": self.exit,
				"contextMenu": self.config,                             
				"showEPGList": self.about,        
			})
		
		hotplugNotifier.append(self.hotplugCB)
		self.onShown.append(self.updateButton)
		self.onClose.append(self.removeHotplug)

	def config(self):
		self.session.open(DreamFlashConfiguration)

	def hotplugCB(self, dev, action):
		print "[hotplugCB]", dev, action
		self.updateButton()
	
	def updateButton(self):
		if self["filelist"].getFilename() or self["filelist"].getCurrentDirectory():
			self["buttongreen"].text = _("Use")
		else:
			self["buttongreen"].text = ""
                self.setTitle(_("Please select medium to use as backup location"))
	
	def removeHotplug(self):
		print "[removeHotplug]"
		hotplugNotifier.remove(self.hotplugCB)

	def about(self):
		self.session.open(DreamFlashAbout)

	def ok(self):
		if self.filelist.canDescent():
			if self["filelist"].showMountpoints == True and self["filelist"].showDirectories == False:
				self.use()
			else:
				self.filelist.descent()

	def use(self):
		print "[DreamFlash] use ", self["filelist"].getCurrentDirectory(), self["filelist"].getFilename()
		if self["filelist"].getCurrentDirectory() is not None:
			if self.filelist.canDescent() and self["filelist"].getFilename() and len(self["filelist"].getFilename()) > len(self["filelist"].getCurrentDirectory()):
				self.filelist.descent()
			self.close(self["filelist"].getCurrentDirectory())
		elif self["filelist"].getFilename():
			self.close(self["filelist"].getFilename())

	def exit(self):
		self.close(False)

(ALLIMAGES, RELEASE, EXPERIMENTAL, BIOS_RELEASE, BIOS_EXPERIMENTAL, LOCAL, FLASHIMAGE, STICK_WIZARD, START) = range(9)

class DreamFlashDownload(Screen):
	# Full HD skin
	if size_w > 1280: 
		skin = """
		<screen name="DreamFlashDownload" position="center,170" size="1200,820" title="DreamFlash Download" >
		<widget backgroundColor="#9f1313" font="Regular;28" halign="center" name="buttonred" position="20,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="270,60" valign="center" />
		<widget backgroundColor="#1f771f" font="Regular;28" halign="center" name="buttongreen" position="300,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="270,60" valign="center" />
		<widget backgroundColor="#a08500" font="Regular;28" halign="center" name="buttonyellow" position="580,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="270,60" valign="center" />
		<widget backgroundColor="#18188b" font="Regular;28" halign="center" name="buttonblue" position="860,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="270,60" valign="center" />
		<ePixmap name="info" position="1130,10" size="60,30" pixmap="skin_default/buttons/key_info.png"/> 
		<ePixmap name="menu" position="1130,40" size="60,30" pixmap="skin_default/buttons/key_menu.png"/> 
		<eLabel position="10,80" size="1180,1" backgroundColor="grey" />
		<widget source="menu" render="Listbox" position="20,100" size="550,600" scrollbarMode="showOnDemand">
			<convert type="TemplatedMultiContent">
				{"templates": 
					{"default": (40, [
						MultiContentEntryText(pos = (4, 4), size = (530, 36), flags = RT_HALIGN_LEFT, text = 1), # index 0 is the MenuText,
					], True, "showOnDemand")
					},
				"fonts": [gFont("Regular", 24)],
				"itemHeight": 40
				}
			</convert>
		</widget>
		<widget source="menu" render="Listbox" position="580,100" size="600,610" scrollbarMode="showNever" selectionDisabled="1">
			<convert type="TemplatedMultiContent">
				{"templates":
					{"default": (600, [
						MultiContentEntryText(pos = (4, 4), size = (580, 600), flags = RT_HALIGN_CENTER|RT_VALIGN_CENTER|RT_WRAP, text = 2), # index 2 is the Description,
					], False, "showNever")
					},	
				"fonts": [gFont("Regular", 32)],
				"itemHeight": 600
				}
			</convert>
		</widget>
		<eLabel position="10,720" size="1180,1" backgroundColor="grey" />
		<widget source="status" render="Label" position="10,730" zPosition="10" size="1180,80" halign="center" valign="center" font="Regular;32" transparent="1" shadowColor="black" shadowOffset="-1,-1" />
		</screen>"""
	else:
		skin = """
		<screen name="DreamFlashDownload" position="center,120" size="820,520" title="DreamFlash Download" >
		<widget backgroundColor="#9f1313" font="Regular;18" halign="center" name="buttonred" position="15,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="180,40" valign="center" />
		<widget backgroundColor="#1f771f" font="Regular;18" halign="center" name="buttongreen" position="205,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="180,40" valign="center" />
		<widget backgroundColor="#a08500" font="Regular;18" halign="center" name="buttonyellow" position="395,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="180,40" valign="center" />
		<widget backgroundColor="#18188b" font="Regular;18" halign="center" name="buttonblue" position="585,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="180,40" valign="center" />
		<ePixmap name="info" position="765,5" size="40,20" pixmap="skin_default/buttons/key_info.png"/> 
		<ePixmap name="menu" position="765,25" size="40,20" pixmap="skin_default/buttons/key_menu.png"/> 
		<eLabel position="10,50" size="800,1" backgroundColor="grey" />
		<widget source="menu" render="Listbox" position="15,60" size="370,380" scrollbarMode="showOnDemand">
			<convert type="TemplatedMultiContent">
				{"templates": 
					{"default": (25, [
						MultiContentEntryText(pos = (2, 2), size = (350, 24), flags = RT_HALIGN_LEFT, text = 1), # index 0 is the MenuText,
					], True, "showOnDemand")
					},
				"fonts": [gFont("Regular", 18)],
				"itemHeight": 25
				}
			</convert>
		</widget>
		<widget source="menu" render="Listbox" position="395,60" size="410,380" scrollbarMode="showNever" selectionDisabled="1">
			<convert type="TemplatedMultiContent">
				{"templates":
					{"default": (380, [
						MultiContentEntryText(pos = (2, 2), size = (390, 380), flags = RT_HALIGN_CENTER|RT_VALIGN_CENTER|RT_WRAP, text = 2), # index 2 is the Description,
					], False, "showNever")
					},	
				"fonts": [gFont("Regular", 22)],
				"itemHeight": 380
				}
			</convert>
		</widget>
		<eLabel position="10,450" size="800,1" backgroundColor="grey" />
		<widget source="status" render="Label" position="10,460" zPosition="10" size="800,50" halign="center" valign="center" font="Regular;22" transparent="1" shadowColor="black" shadowOffset="-1,-1" />
		</screen>"""
		
	def __init__(self, session):
		Screen.__init__(self, session)
		
		self.box=config.plugins.dreamflash.box.value
		self.feed_base = config.plugins.dreamflash.feed.value 
		self.usbmountpoint = resolveFilename(SCOPE_MEDIA)+"DREAMFLASH/"
		self.menulist = []

		self["menu"] = List(self.menulist)
		self["buttonred"] = Label(_("Close"))
		self["buttongreen"] = Label("")
		self["buttonyellow"] = Label("")
		self["buttonblue"] = Label(_("About"))

		self["status"] = StaticText(_("Please wait... Loading list..."))

		self["shortcuts"] = ActionMap(["OkCancelActions", "ColorActions", "ShortcutActions", "DirectionActions",  "ChannelSelectEPGActions", "ChannelSelectEditActions"],
		{
			"ok": self.keyOk,
			"green": self.keyOk,
			"red": self.keyRed,
			"blue": self.keyBlue,
			"yellow": self.keyYellow,
			"up": self.keyUp,
			"down": self.keyDown,
			"right": self.keyRight,
			"left": self.keyLeft,
			"upRepeated": self.keyUp,
			"downRepeated": self.keyDown,
			"cancel": self.close,
			"contextMenu": self.config,                             
			"showEPGList": self.keyBlue,        
		}, -1)
		self.feedlists = [[],[],[],[],[],[]] # extended for Recovery Bios and local images
		self.onShown.append(self.go)
		self.branch = START
		self.container = eConsoleAppContainer()
		if path.exists("/var/lib/dpkg/status"):
			self.container_dataAvail_conn= self.container.dataAvail.connect(self.tool_avail)
		else:
			self.container.dataAvail.append(self.tool_avail)
		self.taskstring = ""
		self.image_idx = 0
		self.nfofilename = ""
		self.nfo = ""
		self.target_dir = None

	def config(self):
		self.session.openWithCallback(self.setMenu,DreamFlashConfiguration)

	def tool_avail(self, string):
		print "[tool_avail]" + string
		self.taskstring += string

	def go(self):
                self.setTitle(_("Dream Flash")+" "+config.plugins.dreamflash.box.value)
		# dynamic Menus are evil ...
		self.onShown.remove(self.go)
		self.umount()
		# minimal menus without feed
		self.gotFeed("", "")
		# full menus with feed
		self.getFeed()
	
	def keyRed(self):
		if self.branch == START:
			self.close()
		else:
			self.branch = START
			self["menu"].setList(self.menulist)

	def keyBlue(self):
		self.session.openWithCallback(self.setMenu,DreamFlashAbout)

	def keyYellow(self):
		if self.nfo != "":
			self.session.open(NFOViewer, self.nfo)

	def keyOk(self):
		current = self["menu"].getCurrent()
		print "[keyOk]", current
		if current:
			if self.branch == ALLIMAGES:
				self.image_idx = self["menu"].getIndex()
				print "ALLIMAGES >>>>>>>>> ", self.branch, self.image_idx
				self.askDestination()
			elif self.branch == LOCAL:
				self.image_idx = self["menu"].getIndex()
				print "LOCAL >>>>>>>>> ", self.branch, self.image_idx
				self.askDestination()
			elif self.branch == FLASHIMAGE:
				self.image_idx = self["menu"].getIndex()
				print "FLASHIMAGE >>>>>>>>> ", self.branch, self.image_idx
				self.askDestination()
			else:
				# OpenDreambox Feed first is always latest ...
				currentEntry = current[0]
				print "START BRANCH >>>>>>>>> ", self.branch, currentEntry
				if currentEntry == RELEASE:
					if config.plugins.dreamflash.feed.value=="http://www.dreamboxupdate.com/opendreambox":
						self.image_idx = 0
					else:
						length=len(self.feedlists[RELEASE])
						self.image_idx = length-1
					self.branch = RELEASE
					self.askDestination()
				elif currentEntry == EXPERIMENTAL:
					if config.plugins.dreamflash.feed.value=="http://www.dreamboxupdate.com/opendreambox":
						self.image_idx = 0
					else:
						length=len(self.feedlists[EXPERIMENTAL])
						self.image_idx = length-1
					self.branch = EXPERIMENTAL
					self.askDestination()
				elif currentEntry == BIOS_RELEASE:
					if config.plugins.dreamflash.feed.value=="http://www.dreamboxupdate.com/opendreambox":
						self.image_idx = 0
					else:
						length=len(self.feedlists[BIOS_RELEASE])
						self.image_idx = length-1
					self.branch = BIOS_RELEASE
					self.askDestination()
				elif currentEntry == BIOS_EXPERIMENTAL:
					if config.plugins.dreamflash.feed.value=="http://www.dreamboxupdate.com/opendreambox":
						self.image_idx = 0
					else:
						length=len(self.feedlists[BIOS_EXPERIMENTAL])
						self.image_idx = length-1
					self.branch = BIOS_EXPERIMENTAL
					self.askDestination()
				elif currentEntry == ALLIMAGES:
					self.image_idx = self["menu"].getIndex()
					self.branch = ALLIMAGES
					self.listImages()
				elif currentEntry == LOCAL:
					self.image_idx = self["menu"].getIndex()
					self.branch = LOCAL
					self.listLocalImages()
				elif currentEntry == FLASHIMAGE:
					self.image_idx = self["menu"].getIndex()
					self.branch = FLASHIMAGE
					self.askDestination()
				elif currentEntry == STICK_WIZARD:
					self.askStartWizard()
		self.updateButtons()

	def keyUp(self):
		self["menu"].selectPrevious()
		self.updateButtons()

	def keyRight(self):
		self["menu"].pageDown()
		self.updateButtons()

	def keyLeft(self):
		self["menu"].pageUp()
		self.updateButtons()

	def keyDown(self):
		self["menu"].selectNext()
		self.updateButtons()
		
	def updateButtons(self):
		current = self["menu"].getCurrent()
		if current:
			if self.branch == START:
				self["buttonred"].text = _("Close")
				currentEntry = current[0]
				if currentEntry in (RELEASE, EXPERIMENTAL):
					self.nfo_download(currentEntry, 0)
					self["buttongreen"].text = _("Download")
				else:
					self.nfofilename = ""
					self.nfo = ""
					self["buttonyellow"].text = ""
					self["buttongreen"].text = _("continue")

			elif self.branch == ALLIMAGES:
				self["buttonred"].text = _("Back")
				self["buttongreen"].text = _("Download")
				self.nfo_download(ALLIMAGES, self["menu"].getIndex())

	def listLocalImages(self):
		print "[listLocalImages]"
		imagelist = []
		OE_vers="2.5"
		# LOCAL IMAGES
		if config.plugins.dreamflash.backup.value and path.exists("/media/hdd/backup"):
			# use images from normal backup directory ...
			for image in listdir("/media/hdd/backup"):                
				if image.endswith(".tar.xz"):
	                		name=image.replace(".tar.xz","")
					description = "\n%s\n" % (name)
	                        	imagelist.append(("/media/hdd/backup/%s" % image, name, _("Default")+" "+_("Backup")+" "+_("Location")+description, None))              
		self["menu"].setList(imagelist)

	def listImages(self):
		print "[listImages]"
		imagelist = []
		OE_vers="2.5"
		# Images
		if config.plugins.dreamflash.stable_image.value:
			branch="Stable"
			for name, url in self.feedlists[RELEASE]:
				dat = name[-15:-7]
#				print "RELEASE",name, url
				version = "%s-%s-%s" % (dat[:4], dat[4:6], dat[6:])
				if config.plugins.dreamflash.feed.value == "http://www.dreamboxupdate.com/opendreambox":
					description = "\nOpenDreambox %s\n%s image\n%s\n" % (OE_vers, branch, version)
				else:
					description = "\nOoZooN %s\n%s image\n%s\n" % (OE_vers, branch, version)
				imagelist.append((url, name[:-7], _("Download %s from Server" ) % description, None))

		if config.plugins.dreamflash.unstable_image.value:
			branch="Unstable"
			for name, url in self.feedlists[EXPERIMENTAL]:
				dat = name[-15:-7]
#				print "EXPERIMENTAL",name, url
				version = "%s-%s-%s" % (dat[:4], dat[4:6], dat[6:])
				if config.plugins.dreamflash.feed.value == "http://www.dreamboxupdate.com/opendreambox":
					description = "\nOpenDreambox %s\n%s image\n%s\n" % (OE_vers, branch, version)
				else:
					description = "\nOoZooN %s\n%s image\n%s\n" % (OE_vers, branch, version)
				imagelist.append((url, name[:-7], _("Download %s from Server" ) % description, None))

		# Rescue Loader
		if config.plugins.dreamflash.stable_rescue.value:
			branch="Stable"
			for name, url in self.feedlists[BIOS_RELEASE]:
				dat = name[-12:-4]
#				print "BIOS_RELEASE",name, url
				version = "%s-%s-%s" % (dat[:4], dat[4:6], dat[6:])
				description = "\nOpendreambox %s\n%s Rescue Loader\n%s\n" % (OE_vers, branch, version)
				imagelist.append((url, name[:-4], _("Download %s from Server" ) % description, None))

		if config.plugins.dreamflash.unstable_rescue.value:
			branch="Unstable"
			for name, url in self.feedlists[BIOS_EXPERIMENTAL]:
				dat = name[-12:-4]
#				print "BIOS_EXPERIMENTAL",name, url
				version = "%s-%s-%s" % (dat[:4], dat[4:6], dat[6:])
				description = "\nOpendreambox %s\n%s Rescue Loader\n%s\n" % (OE_vers, branch, version)
				imagelist.append((url, name[:-4], _("Download %s from Server" ) % description, None))

		self["menu"].setList(imagelist)
	
	def getUSBPartitions(self):
		usbpartition = []
		# Fallback for our blue Friends ...
		if path.exists("/var/lib/dpkg/status"):
			sp=[]
			for dev in listdir("/dev/disk/by-id"):
				if dev.startswith("usb") and dev.endswith("0:0"):
					label=dev.replace("usb-","").replace("_"," ").rstrip().lstrip()
#					print "LABEL", label
					sp=label.split()
					ll=len(sp)
					sp[ll-1]=""
					label=' '.join(sp).lstrip().rstrip()
#					print "LABEL", label
					device=readlink("/dev/disk/by-id/%s" % dev).replace("../../","/dev/")
					size=self.getDeviceSize(device)
					if size < int(config.plugins.dreamflash.maxdevsize.value):
						usbpartition.append((label,device))
		else:   # for our Open Friends ...
			f=open("/proc/partitions","r")
			sp=[]
			line = f.readline()                                                    
			line = f.readline()                                                    
			line = f.readline()                                                    
			while (line):        
				sp=line.split()
				devlen=len(sp[3])
				if (sp[3].startswith("sd") and devlen==3):
					device="/dev/%s" % sp[3]
					size=self.getDeviceSize(device)
					if size < int(config.plugins.dreamflash.maxdevsize.value):
						usbpartition.append((device,device))
				line = f.readline()                                                 
			f.close()

		if len(usbpartition) == 0:
			allpartitions = [ (r.description, r.mountpoint) for r in harddiskmanager.getMountedPartitions(onlyhotplug = True)]
			usbpartition = []
			for x in allpartitions:
				print x, x[1] == '/', x[0].find("USB"), access(x[1], R_OK)
				label=str(x[0])
				mount=str(x[1])
				if mount != '/' and label.find("USB") is not -1: 
					usbpartition.append(x)

		print "[getUSBPartitions]", usbpartition
		return usbpartition

        def getDeviceSize(self, device):                                               
		f=open("/proc/partitions","r")
		sp=[]
		devsizeunit="GB"
		line = f.readline()                                                    
		line = f.readline()                                                    
		line = f.readline()                                                    
		while (line):        
			sp=line.split()
#			print sp
			devlen=len(sp[3])
			if (sp[3].startswith("sd") and devlen==3):
				devname="/dev/%s" % sp[3]
				# make GB
				size=int(sp[2])/1024/1024
#				print devname, size
				if device==devname:
					print "[DreamFlash] found device %s size %d" % (device,size)
					f.close()
					return size
			line = f.readline()                                                 
		return 0
		f.close()
				
	def askDestination(self):
		usbpartition = self.getUSBPartitions()
		print "[askDestination] found USB partitions:", usbpartition
		if len(usbpartition) == 1:
			self.target_dir = usbpartition[0][1]
			self.ackDestinationDevice(device_description=usbpartition[0][0])
		else:
			if config.plugins.dreamflash.backup.value and path.exists("/media/hdd/backup"):
				# use normal backup directory ...
				self.DeviceBrowserClosed("/media/hdd/backup")
				return
			# ask user for directory where to load files ...
			self.openDeviceBrowser()
	
	def openDeviceBrowser(self):
		self.session.openWithCallback(self.DeviceBrowserClosed, DeviceBrowser, None, showDirectories=True, showMountpoints=True, inhibitMounts=["/autofs"])

	def DeviceBrowserClosed(self, path):
		print "[DeviceBrowserClosed]", str(path)
		self.target_dir = path
		if path:
			self.ackDestinationDevice()
		else:
			self.keyRed()
	
	def ackDestinationDevice(self, device_description=None):
		if device_description == None:
			dev = self.target_dir
		else:
			dev = device_description
		message = _("Do you want to download the image to %s ?") % (dev)
		choices = [(_("Yes"), self.ackedDestination), (_("List of Storage Devices"),self.openDeviceBrowser), (_("Cancel"),self.keyRed)]
		self.session.openWithCallback(self.ackDestination_query, ChoiceBox, title=message, list=choices)

	def ackDestination_query(self, choice):
		print "[ackDestination_query]", choice
		if isinstance(choice, tuple):
			choice[1]()
		else:
			self.keyRed()

	def ackedDestination(self):
		print "[ackedDestination] ", self.branch, self.target_dir
		self.container.setCWD(resolveFilename(SCOPE_MEDIA)+"DREAMFLASH/")
		if self.target_dir[:8] == "/autofs/":
			self.target_dir = "/dev/" + self.target_dir[8:-1]
			# prevent raw device"
			if not self.target_dir.endswith("1"):
				self.target_dir=self.target_dir+"1"

		if self.branch == STICK_WIZARD:                                 
			#   only stick formatting possible for now ...       
			print "[DreamFlash] stick wizzard job ..."
			job = StickWizardJob(self.target_dir)
			job.afterEvent = "close"
			job_manager.AddJob(job)
			job_manager.failed_jobs = []
			self.session.openWithCallback(self.StickWizardCB, JobView, job, backgroundable = False, afterEventChangeable = False)
		elif self.branch == FLASHIMAGE:                                 
			print "[DreamFlash] backup job..."
			job = BackupWizardJob(self.target_dir)
			job.afterEvent = "close"
			job_manager.AddJob(job)
			job_manager.failed_jobs = []
			self.session.openWithCallback(self.BackupWizardCB, JobView, job, backgroundable = False, afterEventChangeable = False)
		else:
			url = self.feedlists[self.branch][self.image_idx][1]
			filename = self.feedlists[self.branch][self.image_idx][0]
			if url[0:7] != "http://":
				print "[getImage] copy local %s %s" % (url, self.target_dir)
				job = CopyWizardJob(url, self.target_dir)
				job.afterEvent = "close"
				job_manager.AddJob(job)
				job_manager.failed_jobs = []
				self.session.openWithCallback(self.ImageCopyCB, JobView, job, backgroundable = False, afterEventChangeable = False)
			else:
				print "[getImage] start downloading %s" % (url)
				if self.target_dir.startswith("/dev/"):
					# prevent raw device"
					if not self.target_dir.endswith("1"):
						self.target_dir=self.target_dir+"1"
					job = ImageDownloadJob(url, filename, self.target_dir, self.usbmountpoint)
				else:
					job = ImageDownloadJob(url, filename, None, self.target_dir)
				job.afterEvent = "close"
				job_manager.AddJob(job)
				job_manager.failed_jobs = []
				if url.endswith("bin"):
					self.session.openWithCallback(self.ImageFlashCB, JobView, job, backgroundable = False, afterEventChangeable = False)
				else:
					self.session.openWithCallback(self.ImageDownloadCB, JobView, job, backgroundable = False, afterEventChangeable = False)
	
	def StickWizardCB(self, ret=None):
		print "[StickWizardCB]", ret
		print job_manager.active_jobs, job_manager.failed_jobs, job_manager.job_classes, job_manager.in_background, job_manager.active_job
		if len(job_manager.failed_jobs) == 0:
			self.session.open(MessageBox, _("The USB stick was prepared to be bootable.\nNow you can download an NFI image file!").replace("NFI","tar.xz"), type = MessageBox.TYPE_INFO)
			if len(self.feedlists[ALLIMAGES]) == 0:
				self.getFeed()
			else:
				self.setMenu()
		else:
			self.session.open(MessageBox, _("USB")+" "+_("Creating partition failed"), type = MessageBox.TYPE_ERROR)
			self.umountCallback = self.checkUSBStick
			self.umount()

	def BackupWizardCB(self, ret=None):
		print "[BackupWizardCB]", ret
		print job_manager.active_jobs, job_manager.failed_jobs, job_manager.job_classes, job_manager.in_background, job_manager.active_job
		if len(job_manager.failed_jobs) == 0:
			try:
				from Plugins.SystemPlugins.SoftwareManager.BackupRestore import BackupScreen
				if config.plugins.dreamflash.asksettings.value:
					self.session.openWithCallback(self.askBackupCB, MessageBox, _("The wizard can backup your current settings. Do you want to do a backup now?"), MessageBox.TYPE_YESNO)
				else:   # do not backup settings
					self.askBackupCB(False)
			except:
				self.showHint()
		else:
			self.umountCallback = self.keyRed
			self.umount()

	def ImageCopyCB(self, ret):
		print "[ImageCopyCB]"
		print job_manager.active_jobs, job_manager.failed_jobs, job_manager.job_classes, job_manager.in_background, job_manager.active_job
		if len(job_manager.failed_jobs) == 0:
			try:
				from Plugins.SystemPlugins.SoftwareManager.BackupRestore import BackupScreen
				if config.plugins.dreamflash.asksettings.value:
					self.session.openWithCallback(self.askBackupCB, MessageBox, _("The wizard can backup your current settings. Do you want to do a backup now?"), MessageBox.TYPE_YESNO)
				else:   # do not backup settings
					self.askBackupCB(False)
			except:
				self.showHint()
		else:
			self.umountCallback = self.keyRed
			self.umount()

	def ImageDownloadCB(self, ret):
		print "[ImageDownloadCB]"
		print job_manager.active_jobs, job_manager.failed_jobs, job_manager.job_classes, job_manager.in_background, job_manager.active_job
		target_dir=self.target_dir
		if self.target_dir.startswith("/dev/"):
			target_dir=self.usbmountpoint
		box=config.plugins.dreamflash.box.value
		if len(job_manager.failed_jobs) == 0:
			if config.plugins.dreamflash.signature.value:
				self.createKeystore()
				cmd = "gpgv -q --ignore-time-conflict %sdreambox-image-%s.tar.xz.sig %sdreambox-image-%s.tar.xz" % (target_dir,box,target_dir,box)
				print "[ImageDownloadCB] check sig ", cmd
				self.imagetaskstring=""
				self.imagecheckcontainer = eConsoleAppContainer()
#				self.imagecheckcontainer.setCWD('/')
				if path.exists("/var/lib/dpkg/status"):
					self.imagecheckcontainer.appClosed_conn= self.imagecheckcontainer.appClosed.connect(self.image_checking_finished)
					self.imagecheckcontainer.dataAvail_conn= self.imagecheckcontainer.dataAvail.connect(self.image_checking_avail)
				else:
					self.imagecheckcontainer.appClosed.append(self.image_checking_finished)
					self.imagecheckcontainer.dataAvail.append(self.image_checking_avail)
				self["status"].setText(_("Please wait... Checking...")+" "+_("Image"))
				self.imagecheckcontainer.execute(cmd)
			else:   # if signature is disabled check at least md5 from nfo
				if path.exists("%sdreambox-image-%s.nfo" % (target_dir,box)):
					n=open("%sdreambox-image-%s.nfo" % (target_dir,box),"r")
					line=n.readline()
					md5nfo=""
					sp=[]
					while line:
						if line.startswith("MD5:"):
							sp=line.split()
							md5nfo=sp[1].rstrip().lstrip()
						line=n.readline()
					n.close()
					print "[nfo_checking] ", md5nfo
					md5file=""
					if path.exists("%sdreambox-image-%s.tar.xz" % (target_dir,box)):
						full_path="%sdreambox-image-%s.tar.xz" % (target_dir,box)
						md5file=hashlib.md5(dreamflash_file_as_bytes(open(full_path, 'rb'))).hexdigest()
						print "[MD5]", full_path, md5file
					self["status"].setText(_("Currently installed image") + ": %s" % (about.getImageVersionString()))
					if md5file==md5nfo:
						print "[MD5] signature matches"
					else:
						print "[MD5] signature failed"
						self.session.open(MessageBox, _("Image Download")+" "+_("Signature")+" "+_("failed"), type = MessageBox.TYPE_ERROR)
						self.umount()
						return
				try:
					from Plugins.SystemPlugins.SoftwareManager.BackupRestore import BackupScreen
					if config.plugins.dreamflash.asksettings.value:
						self.session.openWithCallback(self.askBackupCB, MessageBox, _("The wizard can backup your current settings. Do you want to do a backup now?"), MessageBox.TYPE_YESNO)
					else:   # do not backup settings
						self.askBackupCB(False)
				except:
					self.showHint()
		else:
			self.umountCallback = self.keyRed
			self.umount()

	def image_checking_avail(self, string):
		print "[image_checking_avail]", string
		self.imagetaskstring += string

	def image_checking_finished(self, retval):
		print "[image_checking_finished]", str(retval), self.imagetaskstring
		if path.exists("/var/lib/dpkg/status"):
			self.imagecheckcontainer.appClosed_conn=None
			self.imagecheckcontainer.dataAvail_conn=None
		else:
			self.imagecheckcontainer.appClosed.remove(self.image_checking_finished) 
			self.imagecheckcontainer.dataAvail.remove(self.image_checking_avail)

		if self.imagetaskstring.find("Good signature") is not -1:
			# Images is as signed, continue with settings ...     
			try:
				from Plugins.SystemPlugins.SoftwareManager.BackupRestore import BackupScreen
				if config.plugins.dreamflash.asksettings.value:
					self.session.openWithCallback(self.askBackupCB, MessageBox, _("The wizard can backup your current settings. Do you want to do a backup now?"), MessageBox.TYPE_YESNO)
				else:   # do not backup settings
					self.askBackupCB(False)
			except:
				self.showHint()
		else:
			print "[image_checking_finished] failed"
			self.session.open(MessageBox, _("Image Download")+":\n\n"+self.imagetaskstring, type = MessageBox.TYPE_ERROR)
		self["status"].setText(_("Currently installed image") + ": %s" % (about.getImageVersionString()))

	def ImageFlashCB(self, ret):
		print "[ImageFlashCB]"
		print job_manager.active_jobs, job_manager.failed_jobs, job_manager.job_classes, job_manager.in_background, job_manager.active_job
		box=config.plugins.dreamflash.box.value
		realbox = HardwareInfo().get_device_name()                                         
		if realbox == "dm525":          
			realbox="dm520"   
		if len(job_manager.failed_jobs) == 0 and box==realbox:
			self.session.openWithCallback(self.askFlashingCB, MessageBox, _("Recovery Mode")+" "+_("flashing")+" "+box+"?", MessageBox.TYPE_YESNO)
		else:
			self.session.open(MessageBox, _("Recovery Mode")+" "+box+" "+_("flashing")+" "+realbox+" "+_("not used")+"!", MessageBox.TYPE_ERROR)
			self.umountCallback = self.keyRed
			self.umount()

	def askFlashingCB(self, ret):
		if ret:
			self.flashingRecovery()
		else:
			pass

	def flashingRecovery(self):
		realbox = HardwareInfo().get_device_name()                                         
		if realbox == "dm525":          
			realbox="dm520"   
		target_dir=self.target_dir
		if self.target_dir.startswith("/dev/"):
			target_dir=self.usbmountpoint
		self.createKeystore()
		cmd = "gpgv -q --ignore-time-conflict %srescue-image-%s.bin.sig %srescue-image-%s.bin" % (target_dir,realbox,target_dir,realbox)
		print "[flashingRecovery] check sig ", cmd
		self.taskstring=""
		self.checkcontainer = eConsoleAppContainer()
#		self.checkcontainer.setCWD('/')
		if path.exists("/var/lib/dpkg/status"):
			self.checkcontainer.appClosed_conn= self.checkcontainer.appClosed.connect(self.checking_finished)
			self.checkcontainer_dataAvail_conn= self.checkcontainer.dataAvail.connect(self.checking_avail)
		else:
			self.checkcontainer.appClosed.append(self.checking_finished)
			self.checkcontainer.dataAvail.append(self.checking_avail)
		self["status"].setText(_("Please wait... Checking...")+" "+_("Recovery Mode"))
		self.checkcontainer.execute(cmd)

	def createKeystore(self):
		if path.exists("/var/lib/dpkg/status"):
			if not path.exists("/root"):
				mkdir("/root")
			if not path.exists("/root/.gnupg"):
				mkdir("/root/.gnupg/")
			if not path.exists("/root/.gnupg/trustedkeys.gpg"):
				decoded=base64.b64decode(KEY_KROGOTH)
				t=open("/root/.gnupg/trustedkeys.gpg","w")
				t.write(decoded)
				t.close()
		else:   # for our Open Friends
			if not path.exists("/home/root"):
				mkdir("/home/root")
			if not path.exists("/home/root/.gnupg"):
				mkdir("/home/root/.gnupg/")
			if not path.exists("/home/root/.gnupg/trustedkeys.gpg"):
				decoded=base64.b64decode(KEY_KROGOTH)
				t=open("/home/root/.gnupg/trustedkeys.gpg","w")
				t.write(decoded)
				t.close()

	def checking_avail(self, string):
		print "[checking_avail]", string
		self.taskstring += string

	def checking_finished(self, retval):
		print "[checking_finished]", str(retval), self.taskstring
		if path.exists("/var/lib/dpkg/status"):
			self.checkcontainer.appClosed_conn=None
			self.checkcontainer.dataAvail_conn=None
		else:
			self.checkcontainer.appClosed.remove(self.checking_finished) 
			self.checkcontainer.dataAvail.remove(self.checking_avail)
		if self.taskstring.find("Good signature") is not -1:
			#   now we can flash the new rescue loader ...       
			print "[DreamFlash] flashing wizzard job ..."
			target_dir=self.target_dir
			if self.target_dir.startswith("/dev"):
				target_dir=self.usbmountpoint
			job = FlashingWizardJob(target_dir)
			job.afterEvent = "close"
			job_manager.AddJob(job)
			job_manager.failed_jobs = []
			self.session.openWithCallback(self.FlashWizardCB, JobView, job, backgroundable = False, afterEventChangeable = False)
		else:
			self.session.open(MessageBox, _("Recovery Mode")+":\n\n"+self.taskstring, type = MessageBox.TYPE_ERROR)
		self["status"].setText(_("Currently installed image") + ": %s" % (about.getImageVersionString()))

	def FlashWizardCB(self, ret=None):
		print "[FlashizardCB]", ret
		print job_manager.active_jobs, job_manager.failed_jobs, job_manager.job_classes, job_manager.in_background, job_manager.active_job
		result=""
		if path.exists("/tmp/flash-rescue.out"):
			out=open("/tmp/flash-rescue.out","r")
			data=out.readlines()
			out.close()
			last=len(data)
			result=data[last-1]
		print "[result] ", result
		
		if len(job_manager.failed_jobs) == 0:
			self.session.open(MessageBox, _("Recovery Mode")+" "+_("Software update")+"\n\n"+result, type = MessageBox.TYPE_INFO)
		else:
			self.session.open(MessageBox, _("Recovery Mode")+" "+_("Flashing failed")+"\n\n"+result, type = MessageBox.TYPE_ERROR)

	def askBackupCB(self, ret):
		if ret:
			from Plugins.SystemPlugins.SoftwareManager.BackupRestore import BackupScreen

			class USBBackupScreen(BackupScreen):
				def __init__(self, session, usbmountpoint):
					BackupScreen.__init__(self, session, runBackup = True)
					self.backuppath = usbmountpoint
					self.fullbackupfilename = self.backuppath + "/" + self.backupfile
			target_dir=self.target_dir
			if target_dir.startswith("/dev"):
				target_dir=self.usbmountpoint

			self.session.openWithCallback(self.showHint, USBBackupScreen, target_dir)
		else:
			self.showHint()

	def showHint(self, ret=None):
		sp=[]
		hint=_("To update your Dreambox firmware, please follow these steps:\n1) Turn off your box with the rear power switch and make sure the bootable USB stick is plugged in.\n2) Turn mains back on and hold the DOWN button on the front panel pressed for 10 seconds.\n3) Wait for bootup and follow instructions of the wizard.")
		sp=hint.split("\n")
		connectUSB="1) "+_("Connect")+" "+_("USB Stick")
		restartBox="2) "+_("Select")+" "+_("Menu")+" "+_("Standby / Restart")
		rescueBox="3) "+_("Select")+" "+_("Menu")+" "+_("Recovery Mode")
		haltBox=_("Action on long powerbutton press")
		hint=sp[0]+"\n\n"+connectUSB+"\n"+restartBox+"\n"+rescueBox+"\n"+sp[3].replace("3)","4)")
		self.session.open(MessageBox, hint, type = MessageBox.TYPE_INFO)
		self.umountCallback = self.keyRed
		self.umount()

	def getFeed(self):
		# Images	
		if config.plugins.dreamflash.stable_image.value:
			self.feedDownloader25stable = feedDownloader(self.feed_base, self.box, OE_vers="2.5", type="stable", klasse="tarxz", extension=".tar.xz")
		if config.plugins.dreamflash.unstable_image.value:
			self.feedDownloader25unstable = feedDownloader(self.feed_base, self.box, OE_vers="2.5", type="unstable", klasse="tarxz", extension=".tar.xz")
		# Rescue Loader
		if config.plugins.dreamflash.stable_rescue.value:
			self.feedDownloader25stableBios = feedDownloader(self.feed_base, self.box, OE_vers="2.5", type="stable", klasse="bin", extension=".bin")
		if config.plugins.dreamflash.unstable_rescue.value:
			self.feedDownloader25unstableBios = feedDownloader(self.feed_base, self.box, OE_vers="2.5", type="unstable", klasse="bin", extension=".bin")
		# Images Result	 
		if config.plugins.dreamflash.stable_image.value:
			self.feedDownloader25stable.getList(self.gotFeed, self.feed_failed)
		if config.plugins.dreamflash.unstable_image.value:
			self.feedDownloader25unstable.getList(self.gotFeed, self.feed_failed)
		# Rescue Loader Result
		if config.plugins.dreamflash.stable_rescue.value:
			self.feedDownloader25stableBios.getList(self.gotFeed, self.feed_failed)
		if config.plugins.dreamflash.unstable_rescue.value:
			self.feedDownloader25unstableBios.getList(self.gotFeed, self.feed_failed)
		
	def feed_failed(self, message=""):
		self["status"].setText(_("Could not connect to Dreambox .NFI Image Feed Server:").replace(".NFI",".tar.xz").replace("NFI-","tar.xz ") + "\n" + str(message) + "\n" + _("Please check your network settings!"))

	def gotFeed(self, feedlist, OE_vers):
		print "[gotFeed]", OE_vers
		releaselist = []
		experimentallist = []
		bios_releaselist = []
		bios_experimentallist = []
		all_list = []
		local_list = []
		
		# IMAGES
		for name, url in feedlist:
			# we have stable and unstable	
			if url.find("/stable") is not -1:
				if name.endswith(".tar.xz"):
					releaselist.append((name, url))
			if url.find("/unstable") is not -1:
				if name.endswith(".tar.xz"):
					experimentallist.append((name, url))

		# RESCUE LOADER
		for name, url in feedlist:
			# we have stable and unstable	
			if url.find("/stable/") is not -1:
				if name.endswith(".bin"):
					bios_releaselist.append((name, url))
			if url.find("/unstable/") is not -1:
				if name.endswith(".bin"):
					bios_experimentallist.append((name, url))
			# for OoZooN ...
			if url.find("/rescue/") is not -1:
				if name.endswith(".bin"):
					bios_experimentallist.append((name, url))
		
		# LOCAL IMAGES
		if config.plugins.dreamflash.backup.value and path.exists("/media/hdd/backup"):
			# use images from normal backup directory ...
			for image in listdir("/media/hdd/backup"):                
				if image.endswith(".tar.xz"):
	                		name=image.replace(".tar.xz","")
	                        	local_list.append((name, "/media/hdd/backup/%s" % image))              

		print LINE
		self.feedlists[RELEASE] = releaselist + self.feedlists[RELEASE]
		print "RELEASE\n", self.feedlists[RELEASE]
		print LINE
		self.feedlists[EXPERIMENTAL] = experimentallist + self.feedlists[EXPERIMENTAL]
		print "EXPERIMENTAL\n", self.feedlists[EXPERIMENTAL]
		print LINE
		self.feedlists[BIOS_RELEASE] = bios_releaselist + self.feedlists[BIOS_RELEASE]
		print "BIOS_RELEASE\n", self.feedlists[BIOS_RELEASE]
		print LINE
		self.feedlists[BIOS_EXPERIMENTAL] = bios_experimentallist + self.feedlists[BIOS_EXPERIMENTAL]
		print "BIOS_EXPERIMENTAL\n", self.feedlists[BIOS_EXPERIMENTAL]
		print LINE
		self.feedlists[LOCAL] = local_list + self.feedlists[LOCAL]
		print "LOCAL\n", self.feedlists[LOCAL]
		print LINE

		if config.plugins.dreamflash.stable_image.value:
			all_list=all_list+self.feedlists[RELEASE]
		if config.plugins.dreamflash.unstable_image.value:
			all_list=all_list+self.feedlists[EXPERIMENTAL]
		if config.plugins.dreamflash.stable_rescue.value:
			all_list=all_list+self.feedlists[BIOS_RELEASE]
		if config.plugins.dreamflash.unstable_rescue.value:
			all_list=all_list+self.feedlists[BIOS_EXPERIMENTAL]
		self.feedlists[ALLIMAGES] = all_list
		print LINE
		print "ALLIMAGES\n", self.feedlists[ALLIMAGES]
		print LINE

		self.setMenu()

	def checkUSBStick(self):
		self.target_dir = None
		usbpartition = self.getUSBPartitions()
		print "[checkUSBStick] found USB partitions:", usbpartition
		if len(usbpartition) == 1:
			if path.exists("/dev/disk/by-label/DREAMFLASH"):
				print "[DreamFlash] usb already has only one partition labeled DREAMFLASH"
				self.target_dir = usbpartition[0][1]
			else:
				print "[DreamFlash] needs to create usb flasher stick first!"
				self.askStartWizard()
		elif usbpartition == []:
			print "[DreamFlash] needs to create usb flasher stick first!"
			self.askStartWizard()
		else:
			print "[DreamFlash] needs to choose USB"
			self.askStartWizard()

	def askStartWizard(self):
		self.branch = STICK_WIZARD
		usbpartition = self.getUSBPartitions()
		print "[askStartWizard] found USB partitions:", usbpartition
		if len(usbpartition) == 1:
			self.target_dir = usbpartition[0][1]
			self.wizardDeviceBrowserClosed(self.target_dir)
		else:
			message = _("""This plugin creates a USB stick which can be used to update the firmware of your Dreambox without the need for a network or WLAN connection.
First, a USB stick needs to be prepared so that it becomes bootable.
In the next step, an NFI image file can be downloaded from the update server and saved on the USB stick.
If you already have a prepared bootable USB stick, please insert it now. Otherwise plug in a USB stick with a minimum size of 64 MB!""").replace("64","1024").replace("NFI-","tar.xz ")
			self.session.openWithCallback(self.wizardDeviceBrowserClosed, DeviceBrowser, None, message, showDirectories=True, showMountpoints=True, inhibitMounts=["/","/autofs/sr0/","/media/hdd/","/media/net/",self.usbmountpoint,"/media/dvd/"])

	def wizardDeviceBrowserClosed(self, path):
		print "[wizardDeviceBrowserClosed]", path
		self.target_dir = path
		if path:
			self.target_dir = path
			if self.target_dir[:8] == "/autofs/":
				self.target_dir = "/dev/" + self.target_dir[8:-1]
			print "[DreamFlash] choosen for format ", self.target_dir
			StickWizardJob(self.target_dir)
			self.wizardQuery() # always ask for Formatting ...
		else:
			self.close()
	
	def wizardQuery(self):
		print "[wizardQuery]"
		description = self.target_dir
		usbpartition=self.getUSBPartitions()
		print "[wizardQuery] found USB partitions:", usbpartition
		for name, dev in usbpartition:
			if dev == self.target_dir:
				description = name
#		message = _("You have chosen to create a new .NFI flasher bootable USB stick. This will repartition the USB stick and therefore all data on it will be erased.").replace(".NFI",".tar.xz").replace("NFI-","tar.xz ") + "\n"
		message = _("The following device was found: %s\nDo you want to write the USB flasher to this stick?") % description
		choices = [(_("Yes"), self.ackedDestination), (_("List of Storage Devices"),self.askStartWizard), (_("Cancel"),self.close)]
		self.session.openWithCallback(self.ackDestination_query, ChoiceBox, title=message, list=choices)
			
	def setMenu(self, changed=None):
		self.menulist = []
		OE_vers="2.5"
		realbox = HardwareInfo().get_device_name()                                         
		if realbox == "dm525":          
			realbox="dm520"   

		self.menulist.append((STICK_WIZARD, _("USB stick wizard"), _("Prepare another USB stick for image flashing" ), None))
		if config.plugins.dreamflash.root_image.value:
			self.menulist.append((FLASHIMAGE, _("Image")+" "+_("Backup"), _("Backup")+" "+_("Flash")+" "+realbox, None))

		# LOCAL IMAGES
		if config.plugins.dreamflash.backup.value and len(self.feedlists[LOCAL]) > 0:
			self.menulist.append((LOCAL, _("Image")+" "+_("Copy"), _("Default")+" "+_("Backup")+" "+_("Location"), None))

		# IMAGES
		try:
			if config.plugins.dreamflash.feed.value=="http://www.dreamboxupdate.com/opendreambox":
				dat = self.feedlists[EXPERIMENTAL][0][0][-15:-7]
			else:
				length=len(self.feedlists[EXPERIMENTAL])
				dat = self.feedlists[EXPERIMENTAL][length-1][0][-15:-7]
			if config.plugins.dreamflash.feed.value=="http://www.dreamboxupdate.com/opendreambox":
				latest_experimental = "Unstable %s-%s-%s (Opendreambox %s)" % (dat[:4], dat[4:6], dat[6:], OE_vers)
			else:
				latest_experimental = "Unstable %s-%s-%s (OoZooN %s)" % (dat[:4], dat[4:6], dat[6:], OE_vers)
			if config.plugins.dreamflash.unstable_image.value:
				self.menulist.append((EXPERIMENTAL, _("Get latest experimental image").replace("experimental","unstable").replace("Experimental","Unstable"), _("Download %s from Server") % latest_experimental, None))
		except IndexError:
			pass

		try:
			if config.plugins.dreamflash.feed.value=="http://www.dreamboxupdate.com/opendreambox":
				dat = self.feedlists[RELEASE][0][0][-15:-7]
			else:
				length=len(self.feedlists[RELEASE])
				dat = self.feedlists[RELEASE][length-1][0][-15:-7]
			if config.plugins.dreamflash.feed.value=="http://www.dreamboxupdate.com/opendreambox":
				latest_release = "Stable %s-%s-%s (Opendreambox %s)" % (dat[:4], dat[4:6], dat[6:], OE_vers)
			else:
				latest_release = "Stable %s-%s-%s (OoZooN %s)" % (dat[:4], dat[4:6], dat[6:], OE_vers)
			if config.plugins.dreamflash.stable_image.value:
				self.menulist.append((RELEASE, _("Get latest release image").replace("release","stable").replace("Release","Stable"), _("Download %s from Server" ) % latest_release, None))
		except IndexError:
			pass

		# RESCUE LOADER
		try:
			if config.plugins.dreamflash.feed.value=="http://www.dreamboxupdate.com/opendreambox":
				dat = self.feedlists[BIOS_EXPERIMENTAL][0][0][-12:-4]
			else:
				length=len(self.feedlists[BIOS_EXPERIMENTAL])
				dat = self.feedlists[BIOS_EXPERIMENTAL][length-1][0][-12:-4]
			latest_biosexperimental = "Unstable %s-%s-%s (%s)" % (dat[:4], dat[4:6], dat[6:],_("Recovery Mode"))
			if config.plugins.dreamflash.unstable_rescue.value:
				self.menulist.append((BIOS_EXPERIMENTAL, _("Get latest experimental image").replace("experimental","unstable").replace("Experimental","Unstable").replace("image",_("Recovery Mode")).replace("Image",_("Recovery Mode")), _("Download %s from Server" ) % latest_biosexperimental, None))
		except IndexError:
			pass

		try:
			if config.plugins.dreamflash.feed.value=="http://www.dreamboxupdate.com/opendreambox":
				dat = self.feedlists[BIOS_RELEASE][0][0][-12:-4]
			else:
				length=len(self.feedlists[BIOS_RELEASE])
				dat = self.feedlists[BIOS_RELEASE][length-1][0][-12:-4]
			latest_biosrelease = "Stable %s-%s-%s (%s)" % (dat[:4], dat[4:6], dat[6:],_("Recovery Mode"))
			if config.plugins.dreamflash.stable_rescue.value:
				self.menulist.append((BIOS_RELEASE, _("Get latest release image").replace("release","stable").replace("Release","Stable").replace("image",_("Recovery Mode")).replace("Image",_("Recovery Mode")), _("Download %s from Server" ) % latest_release, None))
		except IndexError:
			pass

		if len(self.feedlists[ALLIMAGES]) > 0:
			self.menulist.append((ALLIMAGES, _("Choose image to download"), _("Select desired image from feed list" ), None))

		self["menu"].setList(self.menulist)
		self["status"].setText(_("Currently installed image") + ": %s" % (about.getImageVersionString()))
		self.branch = START
		self.updateButtons()

	def nfo_download(self, branch, idx):
		if (self.feedlists[branch][idx][1]).endswith(".bin"):
			self.nfo_failed("no .nfo available")
			return
		if not config.plugins.dreamflash.info.value:
			self.nfo_failed("no .nfo wanted")
			return
		nfourl = (self.feedlists[branch][idx][1])[:-7]+".nfo"
		if nfourl[0:7] != "http://":
			self.nfo_failed("no .nfo available")
			return
		self.nfofilename = (self.feedlists[branch][idx][0])[:-7]+".nfo"
		print "[check_for_NFO]", nfourl
		client.getPage(nfourl).addCallback(self.nfo_finished).addErrback(self.nfo_failed)

	def nfo_failed(self, failure_instance):
		print "[nfo_failed] " + str(failure_instance)
		self["buttonyellow"].text = ""
		self.nfofilename = ""
		self.nfo = ""

	def nfo_finished(self,nfodata=""):
		print "[nfo_finished] " + str(nfodata)
		self["buttonyellow"].text = _("Changelog")
		self.nfo = nfodata

	def umount(self):
		cmd = "umount " + self.usbmountpoint
		print "[umount]", cmd
		self.container.setCWD('/')
		if path.exists("/var/lib/dpkg/status"):
			self.container.appClosed_conn= self.container.appClosed.connect(self.umountFinished)
		else:
			self.container.appClosed.append(self.umountFinished)
		self.container.execute(cmd)

	def umountFinished(self, retval):
		print "[umountFinished]", str(retval)
		if path.exists("/var/lib/dpkg/status"):
			self.container.appClosed_conn=None
		else:
			self.container.appClosed.remove(self.umountFinished)
#		self.umountCallback()

def main(session, **kwargs):
	session.open(DreamFlashDownload)

def filescan_open(list, session, **kwargs):
	dev = "/dev/" + (list[0].path).rsplit('/',1)[0][7:]
	print "mounting device " + dev + " to /media/DREAMFLASH..."
	usbmountpoint = resolveFilename(SCOPE_MEDIA)+"DREAMFLASH/"
	system("mount -o rw,async -t vfat %s %s" % (dev, usbmountpoint))
	session.open(DreamFlashDownload)

def filescan(**kwargs):
	from Components.Scanner import Scanner, ScanPath
	return \
		Scanner(mimetypes = ["application/x-dream-image"], 
			paths_to_scan = 
				[
					ScanPath(path = "", with_subdirs = False),
				], 
			name = "tar.xz", 
			description = (_("Download .NFI-Files for USB-Flasher").replace(".NFI",".tar.xz")+"..."),
			openfnc = filescan_open, )

class DreamFlashAbout(Screen):
	# Full HD skin
	if size_w > 1280: 
	        skin = """
	        <screen position="center,170" size="1200,820" title="About DreamFlash" >
		<widget backgroundColor="#9f1313" font="Regular;30" halign="center" name="buttonred" position="25,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="280,60" valign="center" />
		<widget backgroundColor="#1f771f" font="Regular;30" halign="center" name="buttongreen" position="895,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="280,60" valign="center" />
	        <widget name="about" foregroundColor="yellow" position="10,20" size="1160,50" halign="center" font="Regular;36"/>
	        <eLabel backgroundColor="grey" position="10,90" size="1180,1" />
	        <widget name="author" position="10,110" size="1160,50" halign="center" foregroundColor="yellow" font="Regular;36"/>
	        <widget name="support" position="10,160" size="1160,50" halign="center" foregroundColor="yellow" font="Regular;36"/>
	        <eLabel backgroundColor="grey" position="10,230" size="1180,1" />
		<ePixmap position="200,260" size="800,210" pixmap="/usr/lib/enigma2/python/Plugins/SystemPlugins/DreamFlash/dreamboxupdate.png"/> 
	        <eLabel backgroundColor="grey" position="10,500" size="1180,1" />
	        <widget name="freefilesystem" position="60,530" size="280,260" valign="center" halign="center" font="Regular;30"/>
	        <widget name="freememory" position="860,530" size="280,260" valign="center" halign="center" font="Regular;30"/>
	    	</screen>"""
	else:
	        skin = """
	        <screen position="center,120" size="820,520" title="About DreamFlash" >
		<widget backgroundColor="#9f1313" font="Regular;19" halign="center" name="buttonred" position="15,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="200,40" valign="center" />
		<widget backgroundColor="#1f771f" font="Regular;19" halign="center" name="buttongreen" position="605,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="200,40" valign="center" />
	        <widget name="about" position="15,15" size="800,30" halign="center" foregroundColor="yellow" font="Regular;24"/>
	        <eLabel backgroundColor="grey" position="10,60" size="800,1" />
	        <widget name="author" position="10,80" size="800,30" halign="center" foregroundColor="yellow" font="Regular;24"/>
	        <widget name="support" position="10,120" size="800,30" halign="center" foregroundColor="yellow" font="Regular;24"/>
	        <eLabel backgroundColor="grey" position="10,170" size="800,1" />
		<ePixmap position="200,190" size="400,105" pixmap="/usr/lib/enigma2/python/Plugins/SystemPlugins/DreamFlash/dreamboxupdate.png"/> 
	        <eLabel backgroundColor="grey" position="10,315" size="800,1" />
	        <widget name="freefilesystem" position="50,320" size="220,190" valign="center" halign="center" font="Regular;24"/>
	        <widget name="freememory" position="560,320" size="220,190" valign="center" halign="center" font="Regular;24"/>
	    	</screen>"""

	def __init__(self, session, args = 0):
		Screen.__init__(self, session)
	        self.onShown.append(self.setWindowTitle)
        	st = statvfs("/")                                                                           
	        free = st.f_bavail * st.f_frsize/1024/1024                                                               
	        total = st.f_blocks * st.f_frsize/1024/1024                                                
	        used = (st.f_blocks - st.f_bfree) * st.f_frsize/1024/1024 
		freefilesystem=_("Root Filesystem\n\ntotal: %s MB\nused:  %s MB\nfree:  %s MB") %(total,used,free)		

	      	memfree=0
	      	memtotal=0
	      	memused=0
		fm=open("/proc/meminfo")
	
	      	line = fm.readline()
	      	sp=line.split()
	      	memtotal=int(sp[1])/1024
	      	line = fm.readline()
	      	sp=line.split()
	      	memfree=int(sp[1])/1024
		fm.close()
		memused=memtotal-memfree
		freememory=_("Memory\n\ntotal: %i MB\nused: %i MB\nfree: %i MB") %(memtotal,memused,memfree)		

	       	self["buttonred"] = Label(_("Exit"))
	       	self["buttongreen"] = Label(_("OK"))
	       	self["about"] = Label(dreamflash_about)
	       	self["author"] = Label(dreamflash_author)
	       	self["support"] = Label(dreamflash_support)
	       	self["freefilesystem"] = Label(freefilesystem)
	       	self["freememory"] = Label(freememory)
	        self["setupActions"] = ActionMap(["SetupActions", "ColorActions"],
		       	{
	       		"green": self.cancel,
	        	"red": self.cancel,
		       	"yellow": self.cancel,
	        	"blue": self.cancel,
	            	"save": self.cancel,
	            	"cancel": self.cancel,
	            	"ok": self.cancel,
		       	})

	def setWindowTitle(self):
	        self.setTitle( _("About")+" "+_("Dream Flash"))

	def cancel(self):
		self.close(False)

class DreamFlashConfiguration(Screen, ConfigListScreen):
    if size_w == 1920:
        skin = """
        <screen position="center,170" size="1200,820" title="DreamFlash Configuration" >
	<widget backgroundColor="#9f1313" font="Regular;28" halign="center" name="buttonred" position="20,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="270,60" valign="center" />
	<widget backgroundColor="#1f771f" font="Regular;28" halign="center" name="buttongreen" position="300,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="270,60" valign="center" />
	<widget backgroundColor="#a08500" font="Regular;28" halign="center" name="buttonyellow" position="580,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="270,60" valign="center" />
	<widget backgroundColor="#18188b" font="Regular;28" halign="center" name="buttonblue" position="860,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="270,60" valign="center" />
	<ePixmap name="info" position="1130,10" size="60,30" pixmap="skin_default/buttons/key_info.png"/> 
	<ePixmap name="menu" position="1130,40" size="60,30" pixmap="skin_default/buttons/key_menu.png"/> 
	<eLabel position="10,80" size="1180,1" backgroundColor="grey" />
        <widget enableWrapAround="1" name="config" position="10,90" scrollbarMode="showOnDemand" size="1180,720" />
    	</screen>"""
    else:
        skin = """
        <screen position="center,120" size="820,520" title="DreamFlash Configuration" >
	<widget backgroundColor="#9f1313" font="Regular;18" halign="center" name="buttonred" position="15,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="180,40" valign="center" />
	<widget backgroundColor="#1f771f" font="Regular;18" halign="center" name="buttongreen" position="205,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="180,40" valign="center" />
	<widget backgroundColor="#a08500" font="Regular;18" halign="center" name="buttonyellow" position="395,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="180,40" valign="center" />
	<widget backgroundColor="#18188b" font="Regular;18" halign="center" name="buttonblue" position="585,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="180,40" valign="center" />
	<ePixmap name="info" position="765,5" size="40,20" pixmap="skin_default/buttons/key_info.png"/> 
	<ePixmap name="menu" position="765,25" size="40,20" pixmap="skin_default/buttons/key_menu.png"/> 
	<eLabel position="10,50" size="800,1" backgroundColor="grey" />
        <widget name="config" position="15,60" size="790,450" enableWrapAround="1" scrollbarMode="showOnDemand" />
    	</screen>"""

    def __init__(self, session, args = 0):
	Screen.__init__(self, session)

        self.onShown.append(self.setWindowTitle)
        # explizit check on every entry
	self.onChangedEntry = []
	
        self.list = []                                                  
       	ConfigListScreen.__init__(self, self.list, session = self.session, on_change = self.changedEntry)
       	self.createSetup()       

       	self["buttonred"] = Label(_("Exit"))
       	self["buttongreen"] = Label(_("OK"))
       	self["buttonyellow"] = Label("")
	self["buttonblue"] = Label(_("About"))
        self["setupActions"] = ActionMap(["SetupActions", "ColorActions", "ChannelSelectEPGActions", "ChannelSelectEditActions"],
       	{
       		"green": self.save,
        	"red": self.cancel,
	       	"yellow": self.keyYellow,
        	"blue": self.about,
            	"save": self.save,
            	"cancel": self.cancel,
            	"ok": self.save,
		"contextMenu": self.close,                             
		"showEPGList": self.about,        
       	})
       	
    def createSetup(self):                                                  
       	self.list = []
	self.list.append(getConfigListEntry(_("Dreambox")+" "+_("Type"),  config.plugins.dreamflash.box))
	self.list.append(getConfigListEntry(_("Downloading"),  config.plugins.dreamflash.feed))
	self.list.append(getConfigListEntry(_("Stable")+" "+_("Image"),   config.plugins.dreamflash.stable_image))
      	self.list.append(getConfigListEntry(_("Unstable")+" "+_("Image"), config.plugins.dreamflash.unstable_image))
	if config.plugins.dreamflash.feed.value=="http://www.dreamboxupdate.com/opendreambox":
		self.list.append(getConfigListEntry(_("Stable")+" "+_("Recovery Mode"),   config.plugins.dreamflash.stable_rescue))
	      	self.list.append(getConfigListEntry(_("Unstable")+" "+_("Recovery Mode"), config.plugins.dreamflash.unstable_rescue))
	else:   # only OpenDreambox has loaders with sig at the moment ...
		config.plugins.dreamflash.stable_rescue.value=False
		config.plugins.dreamflash.stable_rescue.save()
		config.plugins.dreamflash.unstable_rescue.value=False
		config.plugins.dreamflash.unstable_rescue.save()
	if path.exists("/media/hdd/backup"):
	      	self.list.append(getConfigListEntry(_("Default")+" "+_("Backup")+" "+_("Location"), config.plugins.dreamflash.backup))
      	self.list.append(getConfigListEntry(_("Image")+" "+_("Backup"), config.plugins.dreamflash.root_image))
	if config.plugins.dreamflash.feed.value=="http://www.dreamboxupdate.com/opendreambox":
	      	self.list.append(getConfigListEntry(_("Changelog"), config.plugins.dreamflash.info))
	else:
	      	config.plugins.dreamflash.info.value=True
	      	config.plugins.dreamflash.info.save()
	if config.plugins.dreamflash.feed.value=="http://www.dreamboxupdate.com/opendreambox":
	      	self.list.append(getConfigListEntry(_("Signature"), config.plugins.dreamflash.signature))
	else:
	      	config.plugins.dreamflash.signature.value=False
	      	config.plugins.dreamflash.signature.save()
      	self.list.append(getConfigListEntry(_("Backup your Dreambox settings.").replace(".",""), config.plugins.dreamflash.asksettings))
	self.list.append(getConfigListEntry(_("tar.xz")+" "+_("Compression")+" "+_("(0-9)"), config.plugins.dreamflash.xzcompression))
	self.list.append(getConfigListEntry(_("USB")+" "+_("Device")+" "+_("blacklist")+" "+_(" > %d-%d GB") % (dreamflash_minsize,dreamflash_maxsize), config.plugins.dreamflash.maxdevsize))

        self["config"].list = self.list                                 
        self["config"].l.setList(self.list)         

    def keyYellow(self):                                                 
	pass
       	
    def changedEntry(self):                                                 
       	self.createSetup()       

    def setWindowTitle(self):
	self.setTitle(_("Dream Flash")+" "+_("Configuration"))

    def save(self):
        for x in self["config"].list:
           x[1].save()
        self.close(True)

    def cancel(self):
        for x in self["config"].list:
           x[1].cancel()
        self.close(False)

    def about(self):
       	self.session.open(DreamFlashAbout)

