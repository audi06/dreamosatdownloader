# -*- coding: utf-8 -*-
#
# HDMI Input Plugin by gutemine
#
hdmi_in_version="2.6-r0"
#
# Thanks emanuel for the basics
#
# Thanks dre for the CEC code and bugfixes
#
from Components.ActionMap import ActionMap
from Components.Label import Label
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox 
from Plugins.Plugin import PluginDescriptor
from Components.config import config, ConfigSubsection, ConfigText, ConfigBoolean, ConfigInteger, ConfigSelection, getConfigListEntry
from Components.ConfigList import ConfigListScreen
from enigma import quitMainloop, eServiceReference, eDVBDB, getDesktop
from Screens.Standby import Standby as StandbyOrg, StandbySummary as StandbySummaryOrg
import Screens.Standby
from Components.AVSwitch import AVSwitch
from Components.SystemInfo import SystemInfo
from enigma import eTimer, eDVBVolumecontrol, eDVBLocalTimeHandler, eServiceReference
from GlobalActions import globalActionMap
from os import statvfs as os_statvfs, path as os_path

f=open("/proc/stb/info/model")   
boxtype=f.read()             
f.close()                 
boxtype=boxtype.replace("\n","").replace("\l","")

yes_no_descriptions = {False: _("no"), True: _("yes")}
config.plugins.hdmiin = ConfigSubsection()
hdmiin_resolutions = []                                                     
hdmiin_resolutions.append(( "720p",_("Enable 720p24 Mode").replace("720p24","720p") ))
hdmiin_resolutions.append(( "720p24",_("Enable 720p24 Mode") ))
hdmiin_resolutions.append(( "720p60",_("Enable 720p24 Mode").replace("720p24","720p60") ))
if boxtype == "dm900" or boxtype == "dm920":          
	hdmiin_resolutions.append(( "1080i",_("Enable 720p24 Mode").replace("720p24","1080i") ))
	hdmiin_resolutions.append(( "1080p",_("Enable 720p24 Mode").replace("720p24","1080p") ))
	hdmiin_resolutions.append(( "1080p25",_("Enable 720p24 Mode").replace("720p24","1080p25") ))
	hdmiin_resolutions.append(( "1080p30",_("Enable 720p24 Mode").replace("720p24","1080p30") ))
	hdmiin_resolutions.append(( "1080p50",_("Enable 720p24 Mode").replace("720p24","1080p50") ))

if boxtype == "dm900" or boxtype == "dm920":          
	config.plugins.hdmiin.resolution = ConfigSelection(default = "1080p", choices = hdmiin_resolutions)
else:
	config.plugins.hdmiin.resolution = ConfigSelection(default = "720p", choices = hdmiin_resolutions)
hdmiin_setup = []                                                     

if os_path.exists("/var/lib/dpkg/status"):
	from enigma import eCec
	hdmiin_setup.append(( "devices",_("Devices") ))
	hdmiin_setup.append(( "both",_("Menu")+" & "+_("Devices") ))
else:
	hdmiin_setup.append(( "devices",_("System") ))
	hdmiin_setup.append(( "both",_("Menu")+" & "+_("System") ))
hdmiin_setup.append(( "menu",_("Menu") ))
config.plugins.hdmiin.setup = ConfigSelection(default = "devices", choices = hdmiin_setup)
hdmiin_show = []                                                     
hdmiin_show.append(( "main",_("Main")+" "+_("Menu") ))
hdmiin_show.append(( "extension",_("Extensions") ))
hdmiin_show.append(( "both",_("Main")+" "+_("Menu")+" & "+_("Extensions") ))
config.plugins.hdmiin.show = ConfigSelection(default = "main", choices = hdmiin_show)
config.plugins.hdmiin.force_hdmi_audio_disable = ConfigBoolean(default = False, descriptions=yes_no_descriptions) 
config.plugins.hdmiin.bypass_edid_checking = ConfigBoolean(default = False, descriptions=yes_no_descriptions) 
config.plugins.hdmiin.on_idle = ConfigBoolean(default = False, descriptions=yes_no_descriptions) 
config.plugins.hdmiin.suspend_streamserver = ConfigBoolean(default = True, descriptions=yes_no_descriptions) 
config.plugins.hdmiin.disabled_streamserver = ConfigBoolean(default = False, descriptions=yes_no_descriptions) 
config.plugins.hdmiin.channel_streamserver = ConfigBoolean(default = False, descriptions=yes_no_descriptions) 
config.plugins.hdmiin.led_pattern = ConfigInteger(default = 128, limits=(0,255))

hdmi_in_title=_("HDMI Input")+" "+_("Plugin")
hdmi_in_title_version=hdmi_in_title+" "+" V%s" % hdmi_in_version+"\n(c) "+_("gutemine")
#hdmi_in_service="1:0:1:0:0:0:0:0:0:0:rtsp%3a//127.0.0.1%3a554/stream:HDMI-In"
hdmi_in_service="4097:0:1:0:0:0:0:0:0:0:rtsp%3a//127.0.0.1%3a554/stream:HDMI-In"

sz_w = getDesktop(0).size().width() 

class StandbyHdmiIn(StandbyOrg):                                                      
        def __init__(self, session):                                            
		StandbyOrg.__init__(self, session)

class HdmiIn(Screen):
	if sz_w == 1920:
		skin = """
		<screen position="0,0" size="1920,1080" title="HDMI Input" flags="wfNoBorder" zPosition="10" transparent="1" >
		</screen>"""
	else:
		skin = """
		<screen position="0,0" size="1280,720" title="HDMI Input" flags="wfNoBorder" zPosition="10" transparent="1" >
		</screen>"""
	def __init__(self, session, args = 0):
		self.session=session
		self.skin=HdmiIn.skin
		Screen.__init__(self, session)
		f=open("/proc/interrupts","r")
		line=f.readline()
		self.interrupts=0
		while line:
			line=f.readline()
			if line.endswith("HDMI_RX_0\n"):
				sp=[]	
				sp=line.split()
				self.interrupts=int(sp[1])
		f.close()
		print _("[HDMI-IN] interrupts: %d") % (self.interrupts)
		self.onFirstExecBegin.append(self.passtrough)

		self["setupActions"] = ActionMap([ "SetupActions", "ChannelSelectEPGActions", "DirectionActions", "PowerKeyActions", "MenuActions" ],
			{
			"save": self.leave,
			"cancel": self.leave,
			"showEPGList": self.about,
			"ok": self.about,
			"left": self.about,
			"right": self.about,
			"previousSection": self.about,
			"nextSection": self.about,
			"deleteForward": self.about,
			"deleteBackward": self.about,
			"up": self.about,
			"down": self.about,
			"powerdown": self.powerdown,
			"powerup": self.powerup,
			"menu": self.configure,
                        }, -3)   
		config.plugins.hdmiin.disabled_streamserver.value=False                 

	def passtrough(self):
		f=open("/proc/stb/video/videomode","r")
		self.oldvideomode=f.read()
		f.close()
		f=open("/proc/stb/video/videomode_50hz","r")
		self.oldvideomode_50hz=f.read()
		f.close()
		f=open("/proc/stb/video/videomode_60hz","r")
		self.oldvideomode_60hz=f.read()
		f.close()

		oldservice=self.session.nav.getCurrentlyPlayingServiceReference()
		if oldservice is not None:
			self.oldservice=oldservice.toString()
		else:
			self.oldservice=None
		print "--------------------------------------------------"
		print self.oldservice
		print "--------------------------------------------------"
		if self.oldservice==hdmi_in_service:
			print "[HDMI-IN] already shown"
			self.session.openWithCallback(self.close,MessageBox, _("HDMI Input")+" "+_("Streamserver")+" "+_("Channel")+" "+_("Active").lower(), MessageBox.TYPE_ERROR) 
			return

		f=open("/proc/interrupts","r")
		line=f.readline()
		self.interrupts=0
		while line:
			line=f.readline()
			if line.endswith("HDMI_RX_0\n"):
				sp=[]	
				sp=line.split()
				self.interrupts=int(sp[1])
		f.close()

		self.InterruptsTimer = eTimer()
  		if os_path.exists("/var/lib/dpkg/status"):
	                self.InterruptsTimer_conn = self.InterruptsTimer.timeout.connect(self.enablePasstrough)
        	else:                        
                	self.InterruptsTimer.callback.append(self.enablePasstrough)

	        self.InterruptsTimer.start(200, True)

	def enablePasstrough(self):
		f=open("/proc/interrupts","r")
		line=f.readline()
		interrupts=0
		global hdmi_in_interrupts
		while line:
			line=f.readline()
			if line.endswith("HDMI_RX_0\n"):
				sp=[]	
				sp=line.split()
				interrupts=int(sp[1])
		f.close()
		print _("[HDMI-IN] interrupts: %d -> %d") % (self.interrupts, interrupts)
		if interrupts == self.interrupts:
			# interrupts are not going up - probably nothing plugged into HDMI-IN
			if boxtype != "dm900" and boxtype != "dm920":          
				self.session.openWithCallback(self.close,MessageBox, _("HDMI Input")+" "+_("nothing connected").lower(), MessageBox.TYPE_ERROR) 
				return

  		if os_path.exists("/var/lib/dpkg/status"):
			DEVICE_TYPE = {
			eCec.ADDR_TV : _("TV"),
			eCec.ADDR_RECORDING_DEVICE_1 : _("Recording Device"),
			eCec.ADDR_RECORDING_DEVICE_2 : _("Recording Device 2"),
			eCec.ADDR_TUNER_1 : _("Tuner"),
			eCec.ADDR_PLAYBACK_DEVICE_1 : _("Playback Device"),
			eCec.ADDR_AUDIO_SYSTEM : _("Audio System"),
			eCec.ADDR_TUNER_2 : _("Tuner 2"),
			eCec.ADDR_TUNER_3 : _("Tuner 3"),
			eCec.ADDR_PLAYBACK_DEVICE_2 : _("Playback Device 2"),
			eCec.ADDR_RECORDING_DEVICE_3 : _("Recording Device 3"),
			eCec.ADDR_TUNER_4 : _("Tuner 4"),
			eCec.ADDR_PLAYBACK_DEVICE_3 : _("Playback Device 3"),
			}
		
			cec = eCec.getInstance()
			deviceList = cec.getKnownDevices()
			devices = []
			for device in deviceList:
				deviceType = DEVICE_TYPE.get(device.logicalAddress(), _("Other"))
				if device.logicalAddress() == 4:
					self.setTitle(device.deviceName())
					break
		
		print "###############################################"
		print _("[HDMI-IN] Display content")
		print "###############################################"

		self.session.nav.stopService()

		f=open("/proc/stb/video/videomode","w")
		f.write(config.plugins.hdmiin.resolution.value)
		f.close()

		f=open("/proc/stb/audio/hdmi_rx_monitor","w")
		f.write("on")
		f.close()

		f=open("/proc/stb/hdmi-rx/0/hdmi_rx_monitor","w")
		f.write("on")
		f.close()

		if os_path.exists("/proc/stb/fp/led_set_pattern"):
			f=open("/proc/stb/fp/led_set_pattern","w")
			f.write(str(config.plugins.hdmiin.led_pattern.value))
			f.close()
		if os_path.exists("/proc/stb/fp/led0_pattern"):
			f=open("/proc/stb/fp/led0_pattern","w")
			f.write(str(config.plugins.hdmiin.led_pattern.value))
			f.close()
		
		f=open("/proc/stb/hdmi/bypass_edid_checking","w")
		if config.plugins.hdmiin.bypass_edid_checking.value:
			f.write("1")
		else:
			f.write("0")
		f.close()
	
		f=open("/proc/stb/audio/force_hdmi_audio_disable","w")
		if config.plugins.hdmiin.force_hdmi_audio_disable:
			f.write("1")
		else:
			f.write("0")
		f.close()
		
  		if os_path.exists("/var/lib/dpkg/status"):
			try:
				print "isActiveAgain", cec.isActiveSource()
			except:
				print "isActiveAgain failed"

	def leave(self):
		print "###############################################"
		print "[HDMI-IN] Display last channel"
		print "###############################################"

		f=open("/proc/stb/audio/hdmi_rx_monitor","w")
		f.write("off")
		f.close()

		f=open("/proc/stb/hdmi-rx/0/hdmi_rx_monitor","w")
		f.write("off")
		f.close()

		f=open("/proc/stb/avs/0/input","w")
		f.write("aux")
		f.close()

		f=open("/proc/stb/avs/0/input","w")
		f.write("encoder")
		f.close()

		f=open("/proc/stb/video/videomode","w")
		f.write(self.oldvideomode)
		f.close()

		f=open("/proc/stb/video/videomode_50hz","w")
		f.write(self.oldvideomode_50hz)
		f.close()

		f=open("/proc/stb/video/videomode_60hz","w")
		f.write(self.oldvideomode_60hz)
		f.close()

		if os_path.exists("/proc/stb/fp/led_set_pattern"):
			f=open("/proc/stb/fp/led_set_pattern","w")
			f.write("0")
			f.close()
		if os_path.exists("/proc/stb/fp/led0_pattern"):
			f=open("/proc/stb/fp/led0_pattern","w")
			f.write("0")
			f.close()

		if config.plugins.hdmiin.bypass_edid_checking.value:
			f=open("/proc/stb/hdmi/bypass_edid_checking","w")
			f.write("0")
			f.close()

		if config.plugins.hdmiin.force_hdmi_audio_disable:
			f=open("/proc/stb/audio/force_hdmi_audio_disable","w")
			f.write("0")
			f.close()

		if self.oldservice is not None:
			self.session.nav.playService(eServiceReference(self.oldservice))
		self.oldservice=None
		self.close(True)

	def about(self):
	       	self.session.open(HdmiInAbout)

	def configure(self):
		if config.plugins.hdmiin.setup.value!="devices":
			self.session.open(HdmiInConfiguration)
		else:
			self.about()

	def powerdown(self):
		if config.plugins.hdmiin.on_idle.value:
			self.leave()
			return
		f=open("/proc/stb/avs/0/input","r")
		status=f.read()
		f.close()
		if status.startswith("encoder"):
		        print "[HDMI-IN] power down"
			f=open("/proc/stb/avs/0/input","w")
			f.write("aux")
			f.close()
		else:
		        print "[HDMI-IN] power up"
			f=open("/proc/stb/avs/0/input","w")
			f.write("encoder")
			f.close()

	def powerup(self):
		pass

# rename Standby if needed
if config.plugins.hdmiin.on_idle.value: 
	Screens.Standby.Standby=HdmiIn
else:
	Screens.Standby.Standby=StandbyHdmiIn

class HdmiInConfiguration(Screen, ConfigListScreen):
	if sz_w == 1920:
		skin = """
		<screen position="center,170" size="1200,600" title="HDMI Input Configuration" >
		<widget backgroundColor="#9f1313" font="Regular;30" halign="center" name="buttonred" position="15,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="285,60" valign="center" />
		<widget backgroundColor="#1f771f" font="Regular;30" halign="center" name="buttongreen" position="310,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="285,60" valign="center" />
		<widget backgroundColor="#a08500" font="Regular;30" halign="center" name="buttonyellow" position="605,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="285,60" valign="center" />
		<widget backgroundColor="#18188b" font="Regular;30" halign="center" name="buttonblue" position="900,10" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="285,60" valign="center" />
		<eLabel backgroundColor="grey" position="10,80" size="1180,1" />
	        <widget name="config" position="20,90" size="1160,500" scrollbarMode="showOnDemand" />
		</screen>"""
	else:
		skin = """
		<screen position="center,120" size="800,420" title="HDMI Input Configuration" >
		<widget backgroundColor="#9f1313" font="Regular;19" halign="center" name="buttonred" position="15,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="185,40" valign="center" />
		<widget backgroundColor="#1f771f" font="Regular;19" halign="center" name="buttongreen" position="210,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="185,40" valign="center" />
		<widget backgroundColor="#a08500" font="Regular;19" halign="center" name="buttonyellow" position="405,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="185,40" valign="center" />
		<widget backgroundColor="#18188b" font="Regular;19" halign="center" name="buttonblue" position="600,5" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="185,40" valign="center" />
		<eLabel backgroundColor="grey" position="5,50" size="790,1" />
	        <widget name="config" position="10,60" size="780,350" scrollbarMode="showOnDemand" />
		</screen>"""

	def __init__(self, session, args = 0):
		Screen.__init__(self, session)

		self.skin=HdmiInConfiguration.skin
	        self.onShown.append(self.setWindowTitle)
		self.onChangedEntry = []
	
	        self.list = []                                                  
	       	ConfigListScreen.__init__(self, self.list, session = self.session, on_change = self.changedEntry)
		self.createSetup()       

	       	self["buttonred"] = Label(_("Exit"))
	       	self["buttongreen"] = Label(_("OK"))
	       	self["buttonyellow"] = Label(_("Help"))
		self["buttonblue"] = Label(_("About"))
	        self["setupActions"] = ActionMap(["SetupActions", "ColorActions"],
		       	{
       			"green": self.save,
        		"red": self.cancel,
		       	"yellow": self.about,
        		"blue": self.about,
        	    	"save": self.save,
        	    	"cancel": self.cancel,
        	    	"ok": self.save,
       			})
       	
	def createSetup(self):                                                  
	       	self.list = []
		self.list.append(getConfigListEntry(_("Resolution"), config.plugins.hdmiin.resolution))
      		self.list.append(getConfigListEntry(_("Idle")+" "+_("Mode")+" "+_("enable"), config.plugins.hdmiin.on_idle))
#      		self.list.append(getConfigListEntry(_("Audio")+" "+_("disable"), config.plugins.hdmiin.force_hdmi_audio_disable))
      		self.list.append(getConfigListEntry(_("Setup")+" "+_("HDMI Input"), config.plugins.hdmiin.setup))
      		self.list.append(getConfigListEntry(_("Show")+" "+_("HDMI Input"), config.plugins.hdmiin.show))
#      		self.list.append(getConfigListEntry(_("EDID")+" "+_("Check")+" "+_("disable"), config.plugins.hdmiin.bypass_edid_checking))
		if os_path.exists("/proc/stb/fp/led_set_pattern") or os_path.exists("/proc/stb/fp/led0_pattern"):
		      	self.list.append(getConfigListEntry(_("LED")+" "+_("blue"), config.plugins.hdmiin.led_pattern))
        	if os_path.exists("/usr/lib/enigma2/python/Plugins/SystemPlugins/StreamServer/StreamServerConfig.py"):
		    self.list.append(getConfigListEntry(_("Streamserver")+" "+_("Channel")+" ("+_("Restart GUI")+"!)", config.plugins.hdmiin.channel_streamserver))
        	if os_path.exists("/usr/lib/enigma2/python/Plugins/SystemPlugins/StreamServer/StreamServerConfig.py") and not os_path.exists("/usr/bin/dreamliveserver"):
		    if config.streamserver.source.value=="1" and not config.plugins.hdmiin.channel_streamserver.value:
		      	self.list.append(getConfigListEntry(_("Streamserver")+" "+_("Standby"), config.plugins.hdmiin.suspend_streamserver))
        	self["config"].list = self.list                                 
        	self["config"].l.setList(self.list)         
       	
	def changedEntry(self):                                                 
	       	self.createSetup()       
		
	def setWindowTitle(self):
		self.setTitle(hdmi_in_title+" "+_("Setup"))

	def save(self):
		#f=open("/proc/stb/video/videomode","w")
		#f.write(config.plugins.hdmiin.resolution.value)
		#f.close()

		f=open("/proc/stb/hdmi/bypass_edid_checking","w")
		if config.plugins.hdmiin.bypass_edid_checking.value:
			f.write("1")
		else:
			f.write("0")
		f.close()

		f=open("/proc/stb/audio/force_hdmi_audio_disable","w")
		if config.plugins.hdmiin.force_hdmi_audio_disable.value:
			f.write("1")
		else:
			f.write("0")
		f.close()

		# rename Standby if needed
		if config.plugins.hdmiin.on_idle.value: 
			Screens.Standby.Standby=HdmiIn
		else:
			Screens.Standby.Standby=StandbyHdmiIn

	        for x in self["config"].list:
        	   x[1].save()

	        if os_path.exists("/usr/lib/enigma2/python/Plugins/SystemPlugins/StreamServer/StreamServerConfig.py"):
			if config.plugins.hdmiin.channel_streamserver.value:
				print "[HDMI-In] enable Channel"
				if os_path.exists("/etc/enigma2/userbouquet.favourites.tv"):
					fv=open("/etc/enigma2/userbouquet.favourites.tv","r")
					fav=fv.read()
					fv.close()
					if fav.find("HDMI-In") is -1:
						fav=fav+"#SERVICE %s\n" % hdmi_in_service
						fav=fav+("#DESCRIPTION HDMI-In\n")
						fv=open("/etc/enigma2/userbouquet.favourites.tv","w")
						fv.write(fav)
						fv.close()
				# suspend makes no sense when HDMI Input channel is enabled
				config.plugins.hdmiin.suspend_streamserver.value=False
				config.plugins.hdmiin.suspend_streamserver.save()
			else:
				print "[HDMI-In] disable Channel"
				if os_path.exists("/etc/enigma2/userbouquet.favourites.tv"):
					fv=open("/etc/enigma2/userbouquet.favourites.tv","r")
					fav=fv.read()
					fv.close()
					if fav.find("HDMI-In") is not -1:
						fav=fav.replace("#SERVICE %s\n" % hdmi_in_service,"")
						fav=fav.replace("#DESCRIPTION HDMI-In\n","")
						fv=open("/etc/enigma2/userbouquet.favourites.tv","w")
						fv.write(fav)
						fv.close()

			# now reload the Favourites
			print "[HDMI-In] reload Favorites"
			db = eDVBDB.getInstance()                               
			db.reloadBouquets()                                  

			# enable stream server when leaving configuration
			import Plugins.SystemPlugins.StreamServer.StreamServerConfig
			from Components.StreamServerControl import StreamServerControl, streamServerControl
			Plugins.SystemPlugins.StreamServer.StreamServerConfig.applyConfig(streamServerControl)

	        self.close(True)

	def cancel(self):
	        for x in self["config"].list:
	           x[1].cancel()

	        self.close(False)

	def about(self):
	       	self.session.open(HdmiInAbout)

class HdmiInAbout(Screen):
	if sz_w == 1920:
		skin = """
		<screen position="center,170" size="1200,600" title="About HDMI Input Plugin" >
	        <ePixmap position="530,30" size="150,150" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/HdmiIn/g3icon_hdmi_in.png" transparent="1" alphatest="on" />
		<widget backgroundColor="#9f1313" font="Regular;32" halign="center" name="buttonred" position="60,60" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="360,90" valign="center" />
		<widget backgroundColor="#1f771f" font="Regular;32" halign="center" name="buttongreen" position="780,60" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="360,90" valign="center" />
        	<widget name="abouthdmiin" position="10,200" size="1180,140" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;48"/>
        	<widget name="freefilesystem" position="100,340" size="300,240" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;36"/>
        	<widget name="freememory" position="800,340" size="300,240" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;36"/>
        	</screen>"""
	else:
		skin = """
		<screen position="center,120" size="800,420" title="About HDMI Input Plugin" >
	        <ePixmap position="350,10" size="100,100" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/HdmiIn/g3icon_hdmi_in.png" transparent="1" alphatest="on" />
		<widget backgroundColor="#9f1313" font="Regular;24" halign="center" name="buttonred" position="30,30" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="280,60" valign="center" />
		<widget backgroundColor="#1f771f" font="Regular;24" halign="center" name="buttongreen" position="490,30" foregroundColor="white" shadowColor="black" shadowOffset="-2,-2" size="280,60" valign="center" />
        	<widget name="abouthdmiin" position="10,130" size="780,80" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;32"/>
        	<widget name="freefilesystem" position="80,210" size="200,220" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;24"/>
        	<widget name="freememory" position="530,210" size="200,220" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;24"/>
        	</screen>"""

	def __init__(self, session, args = 0):
		Screen.__init__(self, session)
		self.skin=HdmiInAbout.skin
	        self.onShown.append(self.setWindowTitle)
	        st = os_statvfs("/")                                                                           
	        free = st.f_bavail * st.f_frsize/1024/1024                                                               
	        total = st.f_blocks * st.f_frsize/1024/1024                                                
	        used = (st.f_blocks - st.f_bfree) * st.f_frsize/1024/1024 
		freefilesystem=_("Root Filesystem\n\ntotal: %s MB\nused:  %s MB\nfree:  %s MB") % (total,used,free)		

	      	memfree=0
	      	memtotal=0
	      	memused=0
		fm=open("/proc/meminfo")
	      	line = fm.readline()
      		sp=line.split()
      		memtotal=int(sp[1])/1024
      		line = fm.readline()
	 	sp=line.split()
	      	memfree=int(sp[1])/1024
		fm.close()
		memused=memtotal-memfree
		freememory=_("Memory\n\ntotal: %i MB\nused: %i MB\nfree: %i MB") % (memtotal,memused,memfree)		

	       	self["buttonred"] = Label(_("Exit"))
	       	self["buttongreen"] = Label(_("OK"))
	       	self["abouthdmiin"] = Label(hdmi_in_title_version)
	       	self["freefilesystem"] = Label(freefilesystem)
	       	self["freememory"] = Label(freememory)
	        self["setupActions"] = ActionMap(["SetupActions", "ColorActions"],
		       	{
	       		"green": self.cancel,
	        	"red": self.cancel,
		       	"yellow": self.cancel,
	        	"blue": self.cancel,
	            	"save": self.cancel,
	            	"cancel": self.cancel,
	            	"ok": self.cancel,
		       	})

	def setWindowTitle(self):
	        self.setTitle(_("About")+" "+hdmi_in_title)

	def cancel(self):
	        self.close(False)

def startHdmiIn(session, **kwargs):
	f=open("/proc/stb/info/model")   
	boxtype=f.read()             
	f.close()                 
	boxtype=boxtype.replace("\n","").replace("\l","")
	if not boxtype.startswith("dm5"):
		session.open(HdmiIn)    
	else:
		session.open(MessageBox, _("HDMI Input")+" "+_("Unsupported").lower()+" "+boxtype, MessageBox.TYPE_ERROR) 

def startHdmiInConfiguration(session, **kwargs):
	f=open("/proc/stb/info/model")   
	boxtype=f.read()             
	f.close()                 
	boxtype=boxtype.replace("\n","").replace("\l","")
	if not boxtype.startswith("dm5"):
		session.open(HdmiInConfiguration)    
	else:
		session.open(MessageBox, _("HDMI Input")+" "+_("Unsupported").lower()+" "+boxtype, MessageBox.TYPE_ERROR) 

def autostart(reason,**kwargs):     
        print "[HDMI-IN] autostart"
	f=open("/proc/stb/info/model")   
	boxtype=f.read()             
	f.close()                 
	boxtype=boxtype.replace("\n","").replace("\l","")
	if boxtype.startswith("dm5"):
		return
	if os_path.exists("/proc/stb/fp/led_set_pattern"):
		f=open("/proc/stb/fp/led_set_pattern","w")
		f.write("0")
		f.close()
	if os_path.exists("/proc/stb/fp/led0_pattern"):
		f=open("/proc/stb/fp/led0_pattern","w")
		f.write("0")
		f.close()

	f=open("/proc/stb/hdmi-rx/0/hdmi_rx_monitor","r")
	check=f.read()
	f.close()
	if check.startswith("on"):
		f=open("/proc/stb/hdmi-rx/0/hdmi_rx_monitor","w")
		f.write("off")
		f.close()

	f=open("/proc/stb/audio/hdmi_rx_monitor","r")
	check=f.read()
	f.close()
	if check.startswith("on"):
		f=open("/proc/stb/audio/hdmi_rx_monitor","w")
		f.write("off")
		f.close()

	f=open("/proc/stb/hdmi/bypass_edid_checking","r")
	check=f.read()
	f.close()
	if check.find("1") is not -1:
		f=open("/proc/stb/hdmi/bypass_edid_checking","w")
		f.write("o")
		f.close()
	
	f=open("/proc/stb/audio/force_hdmi_audio_disable","r")
	check=f.read()
	f.close()
	if check.find("1") is not -1:
		f=open("/proc/stb/audio/force_hdmi_audio_disable","w")
		f.write("0")
		f.close()
	config.plugins.hdmiin.disabled_streamserver.value=False
	config.plugins.hdmiin.disabled_streamserver.save()

def Plugins(**kwargs):
	if config.plugins.hdmiin.show.value!="main":
		return [PluginDescriptor(name=_("HDMI Input"), description=hdmi_in_title, where = PluginDescriptor.WHERE_EXTENSIONSMENU, icon="g3icon_hdmi_in.png", fnc=startHdmiIn),
			PluginDescriptor(where = [PluginDescriptor.WHERE_AUTOSTART], fnc = autostart),
			PluginDescriptor(name=_("HDMI Input"), description=hdmi_in_title, where=PluginDescriptor.WHERE_MENU, fnc=mainconf)]
	else:
		return [PluginDescriptor(where = [PluginDescriptor.WHERE_AUTOSTART], fnc = autostart),
			PluginDescriptor(name=_("HDMI Input"), description=hdmi_in_title, where=PluginDescriptor.WHERE_MENU, fnc=mainconf)]

def mainconf(menuid):
	if menuid == "mainmenu":                                                  
		if config.plugins.hdmiin.show.value!="extension":
			return [(_("HDMI Input"), startHdmiIn, "hdmi_in", None)] 
	if os_path.exists("/var/lib/dpkg/status"):
		if menuid == "devices":                                                  
			if config.plugins.hdmiin.setup.value!="menu":
				return [(_("HDMI Input"), startHdmiInConfiguration, "hdmi_in_config", None)] 
	else:
		if menuid == "extended":                                                  
			if config.plugins.hdmiin.setup.value!="menu":
				return [(_("HDMI Input"), startHdmiInConfiguration, "hdmi_in_config", None)] 
	return [ ]                                                     

