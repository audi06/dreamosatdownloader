from Plugins.Plugin import PluginDescriptor
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Screens.Screen import Screen
from Screens.Console import Console
from Screens.MessageBox import MessageBox
import os

systemboot_sh = "systemctl"
systemboot_version = "0.04"

class Systemboot(Screen):
	skin = """
	<screen position="center,center" size="350,320" title="Kodi System Boot Menu" >
		<widget name="menu" position="10,10" size="350,310" scrollbarMode="showOnDemand" />
	</screen>"""
	
	def __init__(self, session, args=None):
		Screen.__init__(self, session)
		self.session = session
		self.menu = args
		list = []
		list.append((_("start kodi"), "start"))
		list.append((_("enable kodi autostart"), "enable"))
		list.append((_("disable kodi autostart"), "disable"))
		list.append((_("stop tvheadend"), "stop1"))
		list.append((_("enable tvheadend autostart"), "enable1"))
		list.append((_("disable tvheadend autostart"), "disable1"))
		list.append((_("restart enigma2"), "restart2"))
		list.append((_("enable enigma2 autostart"), "enable2"))
		list.append((_("disable enigma2 autostart"), "disable2"))
		list.append((_("about System Boot plugin"), "about_systemboot"))
		self["menu"] = MenuList(list)
		self["actions"] = ActionMap(["OkCancelActions"], {"ok": self.run, "cancel": self.close}, -1)
	
	def run(self):
		returnValue = self["menu"].l.getCurrentSelection()[1]
        	if returnValue is not None:
			if returnValue is "start":
				self.session.open(Console,_("start doit"),["%s start doit" % systemboot_sh])
			elif returnValue is "enable":
				self.session.open(Console,_("enable kodi"),["%s enaable kodi" % systemboot_sh])
			elif returnValue is "disable":
				self.session.open(Console,_("disable kodi"),["%s disable kodi" % systemboot_sh])
			elif returnValue is "stop1":
				self.session.open(Console,_("stop tvheadend"),["%s stop tvheadend" % systemboot_sh])
			elif returnValue is "enable1":
				self.session.open(Console,_("enable tvheadend"),["%s enable tvheadend" % systemboot_sh])
			elif returnValue is "disable1":
				self.session.open(Console,_("disable tvheadend"),["%s disable tvheadend" % systemboot_sh])
			elif returnValue is "restart2":
				self.session.open(Console,_("restart enigma2"),["%s restart enigma2" % systemboot_sh])
			elif returnValue is "enable2":
				self.session.open(Console,_("enable enigma2"),["%s enable enigma2" % systemboot_sh])
			elif returnValue is "disable2":
				self.session.open(Console,_("disable enigma2"),["%s disable enigma2" % systemboot_sh])
			elif returnValue is "about_systemboot":
				title="System Boot %s plugin by pclin 2017\n\nbase on:\nemanuel just-doit\nDream-Elite Kodi-Launcher\npclin kodi.sh" % systemboot_version
				self.session.open(MessageBox,("%s") % (title),  MessageBox.TYPE_INFO)
		
def main(session, **kwargs):
	session.open(Systemboot)

def Plugins(path,**kwargs):
    return [PluginDescriptor(
        name=_("SystemBoot"), 
        description="Boot System Auswahl", 
        where = PluginDescriptor.WHERE_PLUGINMENU,icon="kodi.png",
        fnc = main
        ),
	PluginDescriptor(name=_("SystemBoot"), where = PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main)]
