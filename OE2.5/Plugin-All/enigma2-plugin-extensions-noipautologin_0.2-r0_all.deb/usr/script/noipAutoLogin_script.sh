#!/bin/sh

/usr/lib/enigma2/python/Plugins/Extensions/noipAutoLogin/noipAutoLogin.py -u username -p password
