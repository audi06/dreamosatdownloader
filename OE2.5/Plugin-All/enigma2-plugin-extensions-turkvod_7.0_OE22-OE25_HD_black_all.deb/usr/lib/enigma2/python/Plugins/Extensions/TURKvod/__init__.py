# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/TURKvod/__init__.py
pass
