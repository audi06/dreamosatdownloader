#Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/seyirTURK/__init__.py
pass