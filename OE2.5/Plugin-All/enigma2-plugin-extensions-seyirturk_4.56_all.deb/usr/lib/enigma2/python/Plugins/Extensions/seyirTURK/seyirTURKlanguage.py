# -*- coding: utf8 -*-

#Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/seyirTURK/language.py

stream1 = ' [RTMPGW açık]'

plugin1 = 'indiriliyor...'

plugin2 = 'Film harddiskinize başarıyla kaydedildi!!!'

plugin3 = 'Film indirme başarısız!\n\nİndirilen dosya bozulmuş:\n%s'

plugin4 = 'Film indirme başarısız!!\n\nRTMP-paketi okunamıyor:\n%s'

plugin5 = 'Film indirme başarısız!!\n\nSegmentasyon hatası:\n%s'

plugin6 = 'Film indirme başarısız!!\n\nServer şu hata ile dönüş yaptı:\n%s '

plugin7 = 'Film indirme başarısız!!\n\nBilinmeyen hata:\n%s'

plugin8 = 'Yeni sürüm var, yükleme işlemine devam etmek için lütfen \'OK\'tuşuna basınız. Yükleme işlemine devam etmek istemiyorsanız \'EXIT\' tuşuna basınız, bu durumda güncelleme yapmak için http://seyirTURK.com u ziyaret etmeniz gerekecektir.'

plugin9 = 'Kurulum işlemi bitti, cihazınız şimdi yeniden başlatılacak!'

plugin10 = '%s\nFavorilere ekle?'

plugin11 = '%s\nFavorilere eklendi'

plugin12 = '%s\nFavorilerden kaldır?'

plugin13 = '%s Favorilerden kaldırıldı'

plugin14 = 'Aranacak kelimeyi girin'

plugin15 = 'seyirTURK\'den çıkmak mı istiyorsunuz?'

plugin16 = 'Playlist hatası:\n%s\n\nURL:\n%s'

plugin17 = 'Yanlış şifre!!! Lütfen tekrar deneyin.'

plugin18 = 'Otomatik oynatma açık'

plugin19 = 'Otomatik oynatma kapalı'

plugin20 = 'DURAKLAT  ||'

plugin21 = 'Sonraki videoyu oynat?\n%s'

plugin22 = 'Deneme sürümü bu fözelliği desteklemiyor'

plugin23 = 'MAVI = Kaydedilmiş videoyu oynatmaya başla'

plugin24 = 'Oynatılacak video bulunamadı'

plugin25 = 'Oynatılacak videonun çözünürlüğünü seçin.'

plugin26 = 'OYNAT     >'

plugin27 = 'Lütfen şifreyi girin...'

plugin28 = 'Cihazınız yeniden başlatılmadan ayarlar geçerli olmayacak, şimdi yeniden başlatmak istermisiniz ?'

skindownload1 = 'İşlem bitiminde cihazınız otomatik olarak tekrar başlatılacaktır...'

plugin29 = 'Güncellemeyi yüklerseniz, cihazınız yeniden başlatılacak, devam etmek istiyormusunuz ?'

modul1 = 'SONRAKİ'

modul2 = 'ÖNCEKİ'

modul3 = 'KATEGORİLER'

modul4= 'YENİ EKLENENLER'

modul5 = 'ARAYACAĞINIZ KELİMEYİ GİREBİLMEK İCİN LÜTFEN STOP TUŞUNA BASINIZ'

modul6 = 'ADET SONUÇ BULUNMUŞTUR'

modul7 = ' Parça : '

modul8 = 'ARA'

plugin30 = ''

plugin31 = ''

plugin32 = ''

plugin33 =''

plugin34 =''

plugin35 =''

plugin36 =''

plugin37 =''

plugin38 =''

plugin39 =''

plugin40 =''

plugin41 =''

plugin42 =''

plugin43 =''

