# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/LiveFootBall/addons/soccer/settings.py
from Screens.Screen import Screen
from Components.ActionMap import ActionMap, NumberActionMap
from Components.Label import Label
from Components.Sources.StaticText import StaticText
from Components.MenuList import MenuList
from Components.Pixmap import Pixmap
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
from enigma import eTimer, eListboxPythonMultiContent, gFont, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, getDesktop, loadPNG, loadPic
from Components.config import ConfigYesNo
from Components.config import ConfigSubsection
from Components.config import ConfigSubDict
from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import fileExists
from Tools.Directories import resolveFilename, SCOPE_CONFIG
import os
from Components.Button import Button
from Plugins.Plugin import PluginDescriptor
import xml.dom.minidom
from Components.ScrollLabel import ScrollLabel
from Screens.MessageBox import MessageBox
from Screens.Console import Console
from twisted.web.client import downloadPage
import urllib
from xml.dom import minidom
import socket
import urllib2
from urllib2 import URLError
import re
import string
import sys
import datetime
import datetime
from Components.ConfigList import ConfigList, ConfigListScreen
from Components.config import config, ConfigDirectory, ConfigSubsection, ConfigSubList, ConfigEnableDisable, ConfigNumber, ConfigText, ConfigSelection, ConfigYesNo, ConfigPassword, getConfigListEntry, configfile
from enigma import getDesktop
sz_w = getDesktop(0).size().width()


class SoccerseasonSetup(Screen, ConfigListScreen):

    def __init__(self, session):
        Screen.__init__(self, session)
        
        if sz_w==1280:
           self.skinName = 'LF_settings'
        else:
           self.skinName = 'LF_settingsfhd'

        
        self['key_red'] = StaticText(_('Cancel'))
        self['key_green'] = StaticText(_('OK'))
        self.list = []
        self.list.append(getConfigListEntry(_('Use local time:'), config.plugins.Sfootball.uselocaltime))
        self.list.append(getConfigListEntry(_('Show on main menu(need e2 restart):'), config.Sfootball.menuplugin))
        self.list.append(getConfigListEntry(_('Soccerway url:'), config.plugins.Sfootball.soccerways))
        self.list.append(getConfigListEntry(_('Livescore url:'), config.plugins.Sfootball.livescores))
        ConfigListScreen.__init__(self, self.list, session)
        self['setupActions'] = ActionMap(['SetupActions', 'ColorActions'], {'green': self.keySave,
         'cancel': self.keyClose,
         'ok': self.keySave}, -2)

    def keySave(self):
        for x in self['config'].list:
            x[1].save()

        configfile.save()
        self.close()

    def keyClose(self):
        for x in self['config'].list:
            x[1].cancel()

        self.close()
