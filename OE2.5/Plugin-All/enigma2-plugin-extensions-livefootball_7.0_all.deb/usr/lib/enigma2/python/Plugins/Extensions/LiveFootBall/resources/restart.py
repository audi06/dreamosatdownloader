# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/LiveFootBall/restart.py
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Screens.Standby import TryQuitMainloop
from Components.Pixmap import Pixmap
from Components.Label import Label
from Components.MenuList import MenuList
import os

class TSTVrestartScreen(Screen):
    skin = '\n                        <screen name="TSTVrestartScreen" position="center,center" size="500,210" title="Message" >\t\n                        <widget name="text" position="70,8" size="520,50" font="Regular;22" transparent="1"/>\n                        <ePixmap name="QuestionPixmap" pixmap="skin_default/icons/input_question.png" position="5,15" size="53,53" alphatest="blend" />\n                        <widget name="list" position="15,100" size="570,110" transparent="1" />\n                         </screen>'

    def __init__(self, session, text):
        self.session = session
        self.skin = TSTVrestartScreen.skin
        Screen.__init__(self, session)
        self.list = [(_('Yes'), 0), (_('No'), 1)]
        self['text'] = Label(text)
        self['list'] = MenuList(self.list)
        self['actions'] = ActionMap(['MsgBoxActions', 'DirectionActions'], {'cancel': self.cancel,
         'ok': self.ok,
         'alwaysOK': self.alwaysOK,
         'up': self.up,
         'down': self.down,
         'left': self.left,
         'right': self.right,
         'upRepeated': self.up,
         'downRepeated': self.down,
         'leftRepeated': self.left,
         'rightRepeated': self.right}, -1)

    def ok(self):
        if self['list'].getCurrent()[1] == 0:
            self.session.open(TryQuitMainloop, retvalue=3)
        elif self['list'].getCurrent()[1] == 1:
            self.close(False)

    def cancel(self):
        self.close(False)

    def alwaysOK(self):
        self.close(True)

    def up(self):
        self.move(self['list'].instance.moveUp)

    def down(self):
        self.move(self['list'].instance.moveDown)

    def left(self):
        self.move(self['list'].instance.pageUp)

    def right(self):
        self.move(self['list'].instance.pageDown)

    def move(self, direction):
        self['list'].instance.moveSelection(direction)