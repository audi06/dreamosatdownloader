#!/bin/sh
BOXTYPE=$(cat /proc/stb/info/model)
URL="http://dreamboxupdate.com/opendreambox/2.0.3/$BOXTYPE"
UOPT="Mozilla/5.0 (X11; Linux x86_64; rv:2.0b9pre) Gecko/20110111 Firefox/4.0"
fix="kernel"

if [ $BOXTYPE = dm800hd ]; then
        ARCH="mips32el-nf"
else
        ARCH="mips32el"
fi

opkg update &>/dev/null
echo opkg update...
echo
for package in liblzo2-2 openvpn openssl kernel-module-llc kernel-module-stp kernel-module-bridge; do
	if opkg list|grep ^$package; then 
		echo -e "$package auf Merlin Update Feed gefunden\ninstall $package"
		opkg install $package
	else
		echo -e "Package $package nicht auf Merlin Update Feed gefunden\nhole installations $package von dreamboxupdate.com"
		DMMPACKAGE=$(wget -q -U '$UOPT'  -O- "$URL"|awk -F \" '{print $2}'|awk -F \/ '{print $5}'|grep ^$package"_"|grep -v "dbg\|dev\|doc")
		echo $DMMPACKAGE found
		echo install $DMMPACKAGE
		opkg install http://dreamboxupdate.com/opendreambox/2.0.3/$ARCH/$DMMPACKAGE
	fi
    echo Package $package erfolgreich Installiert
    echo
done
