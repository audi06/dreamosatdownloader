﻿#  -*- coding: utf-8 -*-
#
#  OpenVPNManager
#  
#  Support: www.dreambox-tools.info
#  
#  http://board.dreambox-tools.info/member.php?24108-koepi
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Multimedia GmbH.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Multimedia GmbH.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Multimedia GmbH.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.
#
from enigma import eTimer, eConsoleAppContainer
from Components.ActionMap import ActionMap
from Components.Pixmap import Pixmap
from Components.ScrollLabel import ScrollLabel
from Plugins.Plugin import PluginDescriptor
from Screens.Console import Console
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Tools.Directories import fileExists
from os import system as sh
from Tools.LoadPixmap import LoadPixmap
from datetime import datetime
import ping
import time

#******** Hier kannst du deine Werte anpassen ********#
ip = "10.8.0.1"
delay = 5
TimeoutSek = 0.2
pathvpn = "/etc/openvpn/"
pathpic = "/usr/lib/enigma2/python/Plugins/Extensions/OpenVpnManager/"

Version = "V 2.64"

def main(session, **kwargs):
	session.open(OpenVPNManager)
	
def Plugins(**kwargs):
	return [PluginDescriptor(
		name="OpenVpnManager",
		description=_("Starten / Stoppen / Überwachen"),
		where = [PluginDescriptor.WHERE_PLUGINMENU, PluginDescriptor.WHERE_EXTENSIONSMENU],
		icon="openvpn.png",
		fnc = main)]	

class OpenVPNManager(Screen):
	skin = """
		<screen position="center,center" size="720,480" name="OpenVPNManager" title="OpenVPNManager">
			<widget name="OpenVpnPng" position= "75,10"   size=  "60,60" alphatest="on" transparent="1" zPosition="1"/>
			<widget name="warte" position="150, 0" size="600, 30" font="Regular;24" foregroundColor="#00389416"/>
			<widget name="stat"  position="150,40" size="400, 30" font="Regular;24" foregroundColor="#000064c7"/>
			<widget name="Vpn"   position= "75,80" size="620,480" font="Regular;24" noWrap="1"/>
			<ePixmap pixmap="skin_default/buttons/red.png"    position=  "0,440" size="140,40" alphatest="on"/>
			<ePixmap pixmap="skin_default/buttons/green.png"  position="155,440" size="140,40" alphatest="on"/>
			<ePixmap pixmap="skin_default/buttons/yellow.png" position="310,440" size="140,40" alphatest="on"/>			
			<ePixmap pixmap="skin_default/buttons/blue.png"   position="465,440" size="140,40" alphatest="on"/>
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/OpenVpnManager/key_ok.png" position="620,445" size="40,40" alphatest="on"/>
			<eLabel text="Stop"        position=  "0,440" size="140,40" zPosition="1" font="Regular;20" halign="center" valign="center" foregroundColor="#00ffffff" transparent="1"/>
			<eLabel text="Start"       position="155,440" size="140,40" zPosition="1" font="Regular;20" halign="center" valign="center" foregroundColor="#00ffffff" transparent="1"/>
			<eLabel text="OpenVpn-Install" position="310,440" size="140,40" zPosition="1" font="Regular;20" halign="center" valign="center" foregroundColor="#00ffffff" transparent="1"/>
		</screen>"""

	def __init__(self, session, args = 0):
		self.session = session
		self.loop = eTimer()
		Screen.__init__(self, session)
		self["OpenVpnPng"] = Pixmap()
		self["warte"] = ScrollLabel("")
		self["stat"]  = ScrollLabel("")
		self["Vpn"]   = ScrollLabel("")
		self.onLayoutFinish.append(self.statik)		
		self["OpenVPNManagerActionMap"] = ActionMap(["OkCancelActions","ColorActions","DirectionActions","EPGSelectActions"],
		{
			"red": 	  self.stopOpenVPN,
			"green":  self.startOpenVPN,			
			"yellow": self.install,
			"ok":	  self.weiter,
			"cancel": self.cancel
		}, -1)
		self.container = eConsoleAppContainer()
		self.appClosed_conn = self.container.appClosed.connect(self.runFinished)
		self.dataAvail_conn = self.container.dataAvail.connect(self.dataAvail)
		self.getOpenVpnPng()
		self.setTitle(_("OpenVpnManager  ") + Version)
		
	def runCommand(self, action="status"):
		self.action = action
		print "[OpenVPNManager] - command %s" %(self.action)
		cmd = "systemctl %s openvpn.service" %(self.action)
		self.container.execute(cmd)
        
	def dataAvail(self, data):
		currentStatus = "unknown"
		dataArray = data.split("\n")
		for line in dataArray:
			line = line.strip()
			if line.startswith("Active:"):
				statusArray = line.split(":")
				if len(statusArray) > 1:
					currentStatus = statusArray[1].strip()
					print "currentStatus", currentStatus
				break

	def runFinished(self, retval):
		print "[OpenVPNManager] - command executed", retval
		if self.action != "status":
			self.getOpenVpnPng()
			
	def getOpenVpnPng(self):
		self.runCommand("status")

#-----------------------------------------------------------------------------------

	def startOpenVPN(self):
		self.online()
		self.timer()
		self.start()
		self.statik()
	
	def stopOpenVPN(self):
		self.runCommand("stop")
		self.timer()
		self.statik()
		
	def cancel(self):
		self.close(None)

#--------------------- Startzeit in Datai schreiben ------------------------------------------
		
	def start(self):
		aktuell = datetime.strftime(datetime.now(), '%a %b %d %H:%M:%S %Y')
		with open(pathvpn+"startzeit.stat", "wb") as ovpn:
			ovpn.write(aktuell)
		return
		
#--------------------- ist OVpn online ------------------------------------------
		
	def	online(self):
		r = ping.doOne(ip,TimeoutSek)
		if r == None or r > TimeoutSek:								#	Timeout
			self.runCommand("start")
			self.timer()
			self.wiederholer()
		else:														#	Ping erfolgreich
			self["stat"].setText("Ping erfolgreich")
			self.statik()

#--------------------- Status der Verbindung ------------------------------------------			

	def statik(self):
		self.loop.stop()
		if	fileExists(pathvpn+"openvpn.stat"):
			ovpn = file(pathvpn+"openvpn.stat")
			r = ping.doOne(ip,TimeoutSek)
			if	r == None or r > TimeoutSek:
				self["warte"].setText("OpenVpn ist nicht gestartet")	# keine Verbindung
				txt = "Ping {}".format(ip)
				ovpn = file("/etc/openvpn/openvpn.stat")
				self["stat"].setText(''.join(txt+" nicht erfolgreich"))
				self["Vpn"].setText(''.join(ovpn))
				self["OpenVpnPng"].instance.setPixmapFromFile(pathpic+"vpn_off.png")
			else:
				self["warte"].setText("OpenVpn ist gestartet")			# Verbindung
				txt = "Ping {}".format(ip)
				self["stat"].setText(''.join(txt+" erfolgreich"))
				self["OpenVpnPng"].instance.setPixmapFromFile(pathpic+"vpn_on.png")
				ovpn = file("/etc/openvpn/openvpn.stat")
				self["Vpn"].setText(''.join(ovpn))
				self.wiederholer()
		else:
			self["Vpn"].setText("K e i n   S t a t u s - F i l e   a n g e l e g t !\nIn der Datei: /etc/openvpn/server.conf\n >'status /etc/openvpn/openvpn.stat 10'<\neintragen")

#--------------------- OVpn install ------------------------------------------
	def install(self):
		if fileExists("/usr/sbin/openvpn"):
			self.session.openWithCallback(self.drueber,MessageBox,_("Die zusätzlichen Dateien zum betreiben von \n       OpenVpn ist bereits installiert.\n\n         Drüber-Installieren? Ja / Nein"), MessageBox.TYPE_YESNO)
		else:
			self.prombt("sh /usr/script/vpn.sh")
			self.timer()
			
	def drueber(self, answer):
		if answer:
			self.prombt("sh /usr/script/vpn.sh")
			self.timer()
			
	def prombt(self, com):
		self.session.open(Console,_("output: %s") % (com), ["%s" % com])

#--------------------- Timer ------------------------------------------
	def	wiederholer(self):									# eTimer start Status
		self.loop.startLongTimer(delay)
		self.loop_conn = self.loop.timeout.connect(self.statik)
			
	def timer(self):										# Timer wartet bis  Ovpn fertig ist
		time.sleep(5)

	def weiter(self):
		self.session.open(Ausgabe)

class Ausgabe(Screen):
	skin = """
		<screen position="center,center" size="450,170" title="TUN/TAB read/write" >
			<widget name="start"   position="0,  0" size="400, 30" transparent="1" halign="right" font="Regular;24"/>
			<widget name="datum"   position="0, 40" size="400, 30" transparent="1" halign="right" font="Regular;24"/>
			<widget name="lesen"   position="0, 80" size="450, 34" transparent="1" font="Regular;28" foregroundColor="#00389416"/>
			<widget name="schreib" position="0,120" size="450, 34" transparent="1" font="Regular;28" foregroundColor="#000064c7"/>
			<widget name="error"   position="0,  0" size="450,150" transparent="1" font="Regular;24"/>
		</screen>"""

	def __init__(self, session):
		Screen.__init__(self, session)
		self.loop = eTimer()
		Screen.__init__(self, session, list)
		self["error"]   = ScrollLabel("")
		self["start"]   = ScrollLabel("")
		self["datum"]   = ScrollLabel("")
		self["lesen"]   = ScrollLabel("")
		self["schreib"] = ScrollLabel("")
		self.onLayoutFinish.append(self.bytes)		
		self["OpenVPNManagerActionMap"] = ActionMap(["OkCancelActions"],
		{
			"ok":	  self.cancel,
			"cancel": self.cancel
		}, -1)

	def bytes(self):									# Ausgabe Read/Write Tun/Tab
		if	fileExists(pathvpn+"openvpn.stat"):
			with open(pathvpn+"openvpn.stat", "r") as f:	# Update Datum (Ovpn)
				updatum = f.readlines()[1]
				self["datum"].setText(''.join(updatum))
			with open(pathvpn+"startzeit.stat", "r") as f:	# Startzeit Datum (Ovpn)
				updatum = f.readlines()[0]
				self["start"].setText("Started:  "+''.join(updatum))

			with open(pathvpn+"openvpn.stat", "r") as f:	# TunTab read
				inhaltr = f.readlines()[2]
				bitr = inhaltr[19:]
				rk = float(bitr)
				if rk < 1024:
					rk = int(rk)							# keine Nachkommastelle
					bitr = str(rk)+" Byte"
				elif rk < 1048576:
					rk = rk / 1024
					rk = round(rk, 3)						# 3 Nachkommastellen
					bitr = str(rk)+" Kbyte"
				elif rk > 1048576:
					rk = rk / 1048576
					rk = round(rk, 3)						# 3 Nachkommastellen
					bitr = str(rk)+" Mbyte"
				self["lesen"].setText("TUN/TAB read  Bytes:  "+''.join(bitr))

			with open(pathvpn+"openvpn.stat", "r") as f:	# TunTab write
				inhaltw = f.readlines()[3]
				bitw = inhaltw[20:]
				wk = float(bitw)
				if wk < 1024:
					wk = int(wk)							# keine Nachkommastelle
					bitw = str(wk)+" Byte"
				elif wk < 1048576:
					wk = wk / 1024
					wk = round(wk, 3)						# 3 Nachkommastellen
					bitw = str(wk)+" Kbyte"
				elif wk > 1048576:
					wk = wk / 1048576
					wk = round(wk, 3)						# 3 Nachkommastellen
					bitw = str(wk)+" Mbyte"
				self["schreib"].setText("TUN/TAB write Bytes:  "+''.join(bitw))
				self.wiederholer()
		else:
			self["error"].setText("K e i n   S t a t u s - F i l e   a n g e l e g t ! \nIn der Datei: /etc/openvpn/server.conf \n >'status /etc/openvpn/openvpn.stat 10'<  eintragen")	

	def	wiederholer(self):									# eTimer start Status
		self.loop.startLongTimer(delay)
		self.loop_conn = self.loop.timeout.connect(self.bytes)
	
	
	def cancel(self):
		self.loop.stop()
		self.close(None)			
