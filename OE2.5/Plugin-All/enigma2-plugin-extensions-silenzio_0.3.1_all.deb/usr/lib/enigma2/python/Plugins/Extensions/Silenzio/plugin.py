# -*- coding: iso-8859-1 -*-
#
# Silenzio Plugin (c) gutemine
#
silenzio_version = "0.3.1"
#
from Plugins.Plugin import PluginDescriptor
from enigma import eTimer, eActionMap, eDVBVolumecontrol, eServiceReference, eServiceCenter, iServiceInformation, eEPGCache, iTimeshiftServicePtr
from Screens.Screen import Screen
from Screens.Setup import SetupSummary
from Screens.MessageBox import MessageBox
from Components.config import config, ConfigSubsection, ConfigEnableDisable, ConfigInteger, getConfigListEntry
from Components.ConfigList import ConfigListScreen
from Components.ActionMap import ActionMap
from Components.Label import Label, MultiColorLabel
from Components.Sources.Source import Source
from GlobalActions import globalActionMap
from Components.config import config, ConfigSubsection, ConfigInteger, ConfigBoolean
from Tools.Profile import profile
from Screens.Volume import Volume
from Screens.Mute import Mute
from Components.HdmiCec import hdmi_cec
from Components.VolumeControl import VolumeControl
import time
#remember original volMute as volMuteOri
VolumeControl.volMuteOri= VolumeControl.volMute

yes_no_descriptions = {False: _("no"), True: _("yes")}  

config.plugins.silenzio = ConfigSubsection();
config.plugins.silenzio.volume_max = ConfigInteger(default=100, limits=(50,100))
config.plugins.silenzio.volume_silenced = ConfigInteger(default=100, limits=(0,100))
config.plugins.silenzio.volume_timeout = ConfigInteger(default=3000, limits=(500,5000))
config.plugins.silenzio.long_mute = ConfigBoolean(default=False, descriptions=yes_no_descriptions)

global is_silenced
is_silenced = 0
global pre_silence
global post_silence
global last_mute
last_mute=time.time()

def volMuteSilenzio(self, showMuteSymbol=True, force=False):
	global last_mute
	new_mute=time.time()
	delta=int((new_mute-last_mute)*1000) # gives msec since last mute
	last_mute=new_mute
	print "[SILENCIO] volMute", showMuteSymbol, force, delta
        global is_silenced
        global pre_silence
        global post_silence
        volcorr = config.plugins.silenzio.volume_silenced.value
	maxvol = config.plugins.silenzio.volume_max.value
	newvol=0

	if hdmi_cec.isVolumeForwarded():                                
        	return   
	is_muted = self.volctrl.isMuted()
	vol = self.volctrl.getVolume()
	if config.plugins.silenzio.long_mute.value and delta < 150:
               	if not self.volctrl.isMuted():                              
       	        	self.volctrl.volumeToggleMute()                         
		self.volumeDialog.hide()
              	self.muteDialog.show()                  
       		self.volumeDialog.setValue(0)                   
		return
        if volcorr == 100:
        	# act like NORMAL mute
	        if vol or force:                                                
        	        self.volctrl.volumeToggleMute()                         
                	if self.volctrl.isMuted():                              
                       		if showMuteSymbol:                              
                                	self.muteDialog.show()                  
                       		self.volumeDialog.setValue(0)                   
                	else:                                                   
                       		self.muteDialog.hide()                          
				if maxvol < vol:
					self.volumeDialog.setValue(maxvol)
				else:
                       			self.volumeDialog.setValue(vol)   
	else:
                # act ONLY as silencer
		if is_muted:
			self.volMuteOri() # unmute
                	if is_silenced:
                      		# switch back to pre silenced
                         	if vol == post_silence:
                        		# toggle volume back
                            		newvol = pre_silence 
                         	else:
                            		# volume was changed after silenced
	                    		newvol=int(vol*100/volcorr)
	                 	# remember that unsilenced
	   	         	is_silenced = 0
			else:
		         	newvol = vol
		elif not vol:   # volume is 0
		      self.volMuteOri(False, True) # mute but dont show mute symbol
 		else:
                      if is_silenced:
                      		# do unsilence
                         	if vol == post_silence:
                            		# toggle volume back
                            		newvol = pre_silence 
                         	else:
                            		# volume was changed after silenced
	                    		newvol=int(vol*100/volcorr)
	                 	# remember that unsilenced
	              		is_silenced = 0
	              else:
	              		# do silence
	              		newvol=int(vol*volcorr/100)
	              		# remember that silenced
	              		is_silenced = 1
		# remember old unsilenced volume
                pre_silence = vol
		if newvol > maxvol:
		      newvol = maxvol
		# we still have to use the default steps ...
	      	while (vol > newvol):
		      self.volctrl.volumeDown()
		      vol = self.volctrl.getVolume()
	      	while (vol < newvol):
		      self.volctrl.volumeUp()
		      vol = self.volctrl.getVolume()
		self.volumeDialog.show()
		self.volumeDialog.setValue(self.volctrl.getVolume())
		self.volSave()
		# remember new silenced volume
		post_silence = self.volctrl.getVolume()

def setVolumeSilenzio(self, direction):

	print "[SILENCIO] setVolume", direction
	maxvol = config.plugins.silenzio.volume_max.value    

	is_muted = self.volctrl.isMuted()
	vol = self.volctrl.getVolume()
	if direction > 0:
        	val = config.audio.volume_stepsize.value                  
		if (vol < maxvol):                
	        	self.volctrl.volumeUp(val, val)                           
	else:
        	val = config.audio.volume_stepsize.value                  
        	self.volctrl.volumeDown(val, val)                         
	vol = self.volctrl.getVolume()
	self.volumeDialog.show()
	if is_muted:
		self.volMuteOri() 		# unmute
	elif not vol: 				# volume is 0 
		self.volMuteOri(False, True) 	# mute but dont show mute symbol
	if self.volctrl.isMuted():
		self.volumeDialog.setValue(0)
	else:
		if maxvol > vol:        
			self.volumeDialog.setValue(self.volctrl.getVolume())
		else:
			self.volumeDialog.setValue(maxvol)
        self.volSave()                                                    
        hidevoltimeout = config.plugins.silenzio.volume_timeout.value              
        self.hideVolTimer.start(hidevoltimeout, True)                   

# rename on startup
VolumeControl.volMute= volMuteSilenzio
VolumeControl.setVolume= setVolumeSilenzio

def startSilenzio(session, **kwargs):
        session.open(SilenzioConfiguration)           

def Plugins(**kwargs):
	return [PluginDescriptor(name="Silenzio", description="Silenzio", where=PluginDescriptor.WHERE_MENU, fnc=mainconf)]

def mainconf(menuid):
    if menuid != "osd_video_audio":                                                  
        return []                                                     
    return [(_("Mute")+"-"+_("Setup"), startSilenzio, "silenzio", None)]    

class SilenzioConfiguration(Screen, ConfigListScreen):
	skin = """
		<screen position="center,center" size="450,240" title="Silenzio Plugin" >
		<widget name="config" position="0,0" size="450,200" scrollbarMode="showOnDemand" />
		<widget name="buttonred" position="10,200" size="100,40" backgroundColor="red" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;18"/>
		<widget name="buttongreen" position="120,200" size="100,40" backgroundColor="green" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;18"/>
		<widget name="buttonyellow" position="230,200" size="100,40" backgroundColor="yellow" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;18"/>
		<widget name="buttonblue" position="340,200" size="100,40" backgroundColor="blue" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;18"/>
	</screen>""" 
	def __init__(self, session, args = 0):
		Screen.__init__(self, session)
		self.list = []
		self.list.append(getConfigListEntry(_("Maximum Volume"),  config.plugins.silenzio.volume_max))
		self.list.append(getConfigListEntry(_("Mute")+_(" %"), config.plugins.silenzio.volume_silenced))
		self.list.append(getConfigListEntry(_("Volume Timeout 500-5000 msec"), config.plugins.silenzio.volume_timeout))
		self.list.append(getConfigListEntry(_("Long Keypress")+" "+_("Mute"), config.plugins.silenzio.long_mute))
		self.onShown.append(self.setWindowTitle)
		ConfigListScreen.__init__(self, self.list)
		self.onChangedEntry = []
		self["buttonred"] = Label(_("Cancel"))
		self["buttongreen"] = Label(_("OK"))
		self["buttonyellow"] = Label(_("Info"))
		self["buttonblue"] = Label(_("About"))
		self["setupActions"] = ActionMap([ "ColorActions", "SetupActions" ],
			{
			"green": self.save,
			"red": self.cancel,
			"yellow": self.help,
			"blue": self.about,
			"save": self.save,
			"cancel": self.cancel,
			"ok": self.save,
			})

	def setWindowTitle(self):
		self.setTitle(_("Mute")+"-"+_("Setup"))

	def save(self):
		for x in self["config"].list:
			x[1].save()
		self.close(True)

	def cancel(self):
		for x in self["config"].list:
			x[1].cancel()
		self.close(False)

	def about(self):
		self.session.open(MessageBox, _("Silenzio")+" "+_("Mute")+"-"+_("Setup")+"\n\n"+_("Plugin Version %s (c) gutemine") % silenzio_version, MessageBox.TYPE_INFO)

	def help(self):
		self.session.open(MessageBox, _("Change Mute % and try the Mute Button"), MessageBox.TYPE_INFO)

