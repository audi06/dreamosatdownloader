from Components.ActionMap import ActionMap
from Components.AVSwitch import AVSwitch
from Components.Button import Button
from Components.config import config, getConfigListEntry, ConfigText, ConfigInteger, ConfigSelection, ConfigSubsection, ConfigYesNo
from Components.config import ConfigNothing, NoSave, ConfigElement, ConfigPassword
from Components.config import KEY_LEFT, KEY_RIGHT, KEY_HOME, KEY_END, KEY_0, KEY_DELETE, KEY_BACKSPACE, KEY_OK, KEY_TOGGLEOW, KEY_ASCII, KEY_TIMEOUT, KEY_NUMBERS
from Components.ConfigList import ConfigListScreen
from Components.Converter.StringList import StringList
from Components.FileList import FileList
from Components.Input import Input
from Components.Label import Label
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
from Components.Pixmap import Pixmap, MultiPixmap, MovingPixmap
from Components.ScrollLabel import ScrollLabel
from Components.SelectionList import SelectionList, SelectionEntryComponent
from Components.ServiceEventTracker import ServiceEventTracker, InfoBarBase
from Components.ServiceList import ServiceList
from Components.Sources.List import List
from Components.Sources.Source import Source
from Components.Sources.StaticText import StaticText

from Components.Sources.Progress import Progress
from Tools.Downloader import downloadWithProgress

from ServiceReference import ServiceReference
from enigma import *
from enigma import eConsoleAppContainer, eListboxPythonMultiContent, eDVBDB, eListbox, ePicLoad, eServiceCenter, eServiceReference
from enigma import getDesktop, addFont, eTimer
from os import environ as os_environ
from os import path, listdir, remove, mkdir, chmod, sys, rename, system
from Plugins.Plugin import PluginDescriptor
from Components.PluginComponent import plugins
import Components.PluginComponent
from Screens.ChoiceBox import ChoiceBox
from Screens.Console import Console
from Screens.InfoBar import MoviePlayer, InfoBar
from Screens.InfoBarGenerics import *
from Screens.InfoBarGenerics import InfoBarNotifications, InfoBarServiceNotifications, InfoBarTimeshiftState, InfoBarTimeshift, InfoBarNumberZap
from Screens.InfoBarGenerics import InfoBarShowHide, NumberZap, InfoBarSeek, InfoBarAudioSelection, InfoBarSubtitleSupport, InfoBarEPG 


from Screens.InputBox import InputBox
from Screens.PluginBrowser import PluginBrowser
from Screens.Screen import Screen
from Screens.Standby import TryQuitMainloop, Standby
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Tools.Directories import resolveFilename, fileExists, copyfile
from Tools.Directories import SCOPE_PLUGINS
from Tools.LoadPixmap import LoadPixmap
from twisted.web.client import downloadPage, getPage, error
from xml.dom import Node, minidom
import base64
import os, re, glob
import shutil
import time
import urllib
from Components.Console import Console as iConsole
import urllib2, cookielib
from urllib import urlencode, quote
from httplib import HTTP
from urlparse import urlparse
import StringIO
import httplib
from urllib2 import urlopen, Request, URLError, HTTPError



import gettext
from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS, SCOPE_LANGUAGE
PluginLanguageDomain = 'ListFree'
PluginLanguagePath = '/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/res/locale'

def localeInit():
    lang = language.getLanguage()[:2]
    os.environ['LANGUAGE'] = lang
    gettext.bindtextdomain(PluginLanguageDomain, PluginLanguagePath)
    gettext.bindtextdomain('enigma2', resolveFilename(SCOPE_LANGUAGE, ''))

def _(txt):
    t = gettext.dgettext(PluginLanguageDomain, txt)
    if t == txt:
        t = gettext.dgettext('enigma2', txt)
    return t


localeInit()
language.addCallback(localeInit)

currversion = '4.4'
#currversion = '4.2'
Version = ' 4.4 - 13.06.2017'

dataxx = 'cGlucHJvZ3Jlc3MudHh0'
TXT_PUKPRG = base64.b64decode(dataxx)

dataf = 'aHR0cDovL3d3dy5wYW5kYXNhdC5pbmZvL2lwdHYvcGx1Z2luLw=='
FTP_ALL = base64.b64decode(dataf)
data4 = 'cHVrNC50eHQ='
TXT_PUK = base64.b64decode(data4)
data6 = 'dXBkYXRlUGFuZGFmcmVlLnR4dA=='
upd_fr_txt = base64.b64decode(data6)
data7 = 'd2dldCBodHRwOi8vd3d3LnBhbmRhc2F0LmluZm8vaXB0di9wbHVnaW4vcGljb25fdXBkYXRlLnRhciAtTyAvdG1wL3BhbmRhc2F0L3BpY29uX3VwZGF0ZS50YXIgPiAvZGV2L251bGw='
pcn_upd_lnk = base64.b64decode(data7)
data8 = 'd2dldCBodHRwOi8vd3d3LnBhbmRhc2F0LmluZm8vaXB0di9ub3RlLnR4dCAtTyAvdG1wL25vdGUudHh0ID4gL2Rldi9udWxs'
nt_upd_lnk = base64.b64decode(data8)
data11 = 'aHR0cDovL3d3dy5wYW5kYXNhdC5pbmZvL2lwdHYvcGx1Z2luL3BpY29ucy1wYW5kYXNhdC1mcmVlaXB0di11c2Jfdi4xLjBfYWxsLmlwaw=='
picon_ipk_usb = base64.b64decode(data11)
data12 = 'aHR0cDovL3d3dy5wYW5kYXNhdC5pbmZvL2lwdHYvcGx1Z2luL3BpY29ucy1wYW5kYXNhdC1mcmVlaXB0di1oZGRfdi4xLjBfYWxsLmlwaw=='
picon_ipk_hdd = base64.b64decode(data12)
data13 = 'aHR0cDovL3d3dy5wYW5kYXNhdC5pbmZvL2lwdHYvcGx1Z2luL3BpY29ucy1wYW5kYXNhdC1mcmVlaXB0di1mbGFzaF92LjEuMF9hbGwuaXBr'
picon_ipk_flash = base64.b64decode(data13)
data14 = 'aHR0cDovL3d3dy5wYW5kYXNhdC5pbmZvL2lwdHYvcEFuRGFTQVRfRnJlZV9JUFRWLm0zdQ=='
pnd_m3u = base64.b64decode(data14)
data15 = 'd2dldCBodHRwOi8vd3d3LnBhbmRhc2F0LmluZm8vaXB0di9wQW5EYVNBVF9GcmVlX0lQVFYubTN1IC1PIA=='
pnd_m3ulnk = base64.b64decode(data15)
data16 = 'd2dldCBodHRwOi8vd3d3LnBhbmRhc2F0LmluZm8vaXB0di9wQW5EYVNBVF9YWFgubTN1IC1PIC90bXAvcEFuRGFTQVRfWFhYLm0zdSA+IC9kZXYvbnVsbA=='
pnd_m3ucncrtlnk = base64.b64decode(data16)
plugin_path = '/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/'
service_types_tv = '1:7:1:0:0:0:0:0:0:0:(type == 1) || (type == 17) || (type == 22) || (type == 25) || (type == 134) || (type == 195)'
dir_enigma2 = '/etc/enigma2/'
addFont('/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/res/fonts/JAi.ttf', 'pndFont1', 100, 1)
addFont('/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/res/fonts/DopeJam.ttf', 'pndFont2', 100, 1)

def mountpcn():
    pthm3uf = []
    if os.path.isfile('/proc/mounts'):
        for line in open('/proc/mounts'):
            if '/dev/sd' in line or '/dev/disk/by-uuid/' in line or '/dev/mmc' in line or '/dev/mtdblock' in line:
                drive = line.split()[1].replace('\\040', ' ') + '/'
                if not drive in pthm3uf:  # Mod. by Diamondear
                    pthm3uf.append(drive)
    pthm3uf.append('/usr/share/enigma2/')
    return pthm3uf
        
    
    
def mountm3uf():
    pthmpcns = []
    if os.path.isfile('/proc/mounts'):
        for line in open('/proc/mounts'):
            if '/dev/sd' in line or '/dev/disk/by-uuid/' in line or '/dev/mmc' in line or '/dev/mtdblock' in line:
                drive = line.split()[1].replace('\\040', ' ') + '/'
                ##lulu
                if drive== "/media/hdd/" :
                    drive = drive.replace('/media/hdd/', '/media/hdd/movie/')
                    if not os.path.exists('/media/hdd/movie'):
                        os.system('mkdir /media/hdd/movie')
                    
                if drive== "/media/usb/" :
                    drive = drive.replace('/media/usb/', '/media/usb/movie/')
                    if not os.path.exists('/media/usb/movie'):
                        os.system('mkdir /media/usb/movie')                    
                    
                    
                ##                    
                if not drive in pthmpcns:  # Mod. by Diamondear
                      pthmpcns.append(drive)
    pthmpcns.append('/tmp/')
                
    return pthmpcns    
    
    
    
sessions = []
config.plugins.fReE_iPtV_pAnDa_SaT_tEaM = ConfigSubsection()
config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.code = ConfigInteger(limits=(0, 9999), default=1234)
config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.autoupd = ConfigYesNo(default=True)
config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthm3uf = ConfigSelection(choices=mountm3uf())
config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthpcns = ConfigSelection(choices=mountpcn())
config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthchs = ConfigSelection(default='/etc/pandasat/extra', choices=[('/etc/pandasat/extra', _('DEFAULT')), ('/usr/script', _('/USR/SCRIPT'))])
config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthscrpts = ConfigSelection(default='/etc/pandasat/script', choices=[('/etc/pandasat/script', _('DEFAULT'))])
config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.strtext = ConfigYesNo(default=True)
config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.strtmain = ConfigYesNo(default=True)
DESKHEIGHT = getDesktop(0).size().height()




def m3ulistEntry(download):
    res = [download]
    white = 16777215
    yellow = 15053379
    col = 16777215
    backcol = 0
    res.append(MultiContentEntryText(pos=(0, 0), size=(1000, 40), text=download, color=col, color_sel=white, backcolor=backcol, backcolor_sel=yellow))
    return res

def m3ulist(data, list):
    icount = 0
    mlist = []
    for line in data:
        name = data[icount]
        mlist.append(m3ulistEntry(name))
        icount = icount + 1

    list.setList(mlist)

class PNDM3UList(MenuList):
    def __init__(self, list):
        MenuList.__init__(self, list, True, eListboxPythonMultiContent)
        if DESKHEIGHT > 1000:
            self.l.setItemHeight(38)
            textfont = int(28)
            self.l.setFont(0, gFont('pndFont1', textfont))
        else:
            self.l.setItemHeight(30)
            textfont = int(22)
            self.l.setFont(0, gFont('pndFont1', textfont))
   
def remove_line(filename, what):
    if os.path.isfile(filename):
        file_read = open(filename).readlines()
        file_write = open(filename, 'w')
        for line in file_read:
            if what not in line:
                file_write.write(line)

        file_write.close()


class ABOUT(Screen):

    def __init__(self, session):
        self.session = session
        if DESKHEIGHT < 1000:
            skin = '/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/res/HD/ABOUT.xml'
        else:
            skin = '/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/res/FullHD/ABOUTFHD.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()
        Screen.__init__(self, session)
        self['fittitle'] = Label(_('..:: pAnDaSAT fReE iPtV ::..'))
        self['fitred'] = Label(_('Chiudi'))
        self['fitgreen'] = Label(_('Config'))
        self['fityellow'] = Label(_('Bouquet'))
        self['fityellow2'] = Label(_('Player'))
        self['fitblue'] = Label(_('Extra'))
        self['Maintainer'] = Label(_('Maintainer') + ': ')
        self['Maintainer2'] = Label(_('@Lululla'))
        self['Grafic'] = Label(_('Grafica') + ': ')
        self['Grafic2'] = Label(_('@pAnDa'))
        self['pndteam'] = Label('by tEaM dEvElOpEr pAnDa SaT\xae')
        self['version'] = Label(_('Versione %s') % Version)
        
        
        self['status'] = Label()
        self['progress'] = Progress()
        self['progresstext'] = StaticText()
        
        
        info2 = ''
        self['text'] = ScrollLabel()
        self.downloading = False
        self.icount = 0
        self['text'].setText(_('Check Connection wait please') + '...')
        self.timer = eTimer()
        try:
            self.timer.callback.append(self.pndchckint)
        except:
            self.timer_conn = self.timer.timeout.connect(self.pndchckint)
        self.timer.start(50, 1)
        self.cbUpdate = False
        try:
            fp = urllib.urlopen(FTP_ALL + upd_fr_txt)
            count = 0
            self.labeltext = ''
            s1 = fp.readline()
            s2 = fp.readline()
            s3 = fp.readline()
            s1 = s1.strip()
            s2 = s2.strip()
            s3 = s3.strip()
            self.link = s2
            self.version = s1
            self.info = s3
            fp.close()
            cstr = s1 + ' ' + s2
            if s1 == currversion:
                self.cbUpdate = False
            elif float(s1) < float(currversion):
                self.cbUpdate = False
            else:
                self.cbUpdate = True
        except:
            self.cbUpdate = False

        self.xtimer = eTimer()
        try:
            self.xtimer.callback.append(self.msgupdt1)
        except:
            self.xtimer_conn = self.xtimer.timeout.connect(self.msgupdt1)
        self.xtimer.start(2000, 1)
        
        self['actions'] = ActionMap(['OkCancelActions',
         'DirectionActions',
         'ColorActions',
         'WizardActions',
         'NumberActions',
         'EPGSelectActions'], {'ok': self.closes,
         'cancel': self.closes,
         'back': self.closes,
         'red': self.closes,
         'up': self['text'].pageUp,
         'down': self['text'].pageDown,
         'left': self['text'].pageUp,
         'right': self['text'].pageDown,
         'yellow': self.lista,
         'blue': self.extra,
         'green': self.scsetup}, -1)
        self.onLayoutFinish.append(self.Remove)
        


        
    def msgupdt1(self):
        if self.cbUpdate == False:
            return
        if config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.autoupd.value == False:
            return
        self.session.openWithCallback(self.runupdate, pndMessageBox, _('Nuova Versione Online!!!\n\nAggiornare Plugin alla Versione %s ?' % self.version), pndMessageBox.TYPE_YESNO)

    def runupdate(self, result):
        if self.cbUpdate == False:
            return
        if result:
            com = self.link
            dom = self.version
            self['status'].setText(_('Aggiorno Plugin V.: %s') % dom)            
            os.system('mkdir -p /tmp/pandasat')
            self.updateurl = self.link
            self.dlfile = '/tmp/pandasat/tmp.ipk'
            self.download = downloadWithProgress(self.updateurl, self.dlfile)
            self.download.addProgress(self.downloadProgress)
            self.download.start().addCallback(self.downloadFinished).addErrback(self.downloadFailed)             
            
       
    def downloadFinished(self, string = ''):
        dom = 'self.version'
        self['status'].setText(_('Configuro Plugin V.: %s') % dom)
        com = '/tmp/pandasat/tmp.ipk'
        os.system('opkg install -force-overwrite %s' % com)
        os.system('rm -rf /tmp/pandasat')
        os.system('sleep 3')
        
        self['status'].setText(_('Riavvia Interfaccia Prego!'))         
        self['progresstext'].text = ''
        
        #infobox = self.session.open( pndMessageBox, _('Plugin Aggiornato con Successo !!!!!!'), pndMessageBox.TYPE_INFO, timeout=5)
        os.system('sleep 3')
        self.msgrstrt3()

    def downloadFailed(self, failure_instance = None, error_message = ''):
        text = _('Errore durante il download di file!')
        if error_message == '' and failure_instance is not None:
            error_message = failure_instance.getErrorMessage()
            text += ': ' + error_message
        self['status'].setText(text)
        return

    def downloadProgress(self, recvbytes, totalbytes):
        self['progress'].value = int(100 * recvbytes / float(totalbytes))
        self['progresstext'].text = '%d of %d kBytes (%.2f%%)' % (recvbytes / 1024, totalbytes / 1024, 100 * recvbytes / float(totalbytes))   
        
        
        
        
#######################################        

    def Remove(self):
        for x in glob.glob('/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/*'):
            jpy = x[-3:]
            if jpy == '.py':
                os.system('rm -fr ' + x)

    # def msgupdt1(self):
        # if self.cbUpdate == False:
            # return
        # if config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.autoupd.value == False:
            # return
        # self.session.openWithCallback(self.runupdate, pndMessageBox, _('Nuova Versione Online!!!\n\nAggiornare Plugin alla Versione %s ?' % self.version), pndMessageBox.TYPE_YESNO)

    # def runupdate(self, result):
        # if self.cbUpdate == False:
            # return
        # if result:
            # com = self.link
            # dom = 'Nuova versione ' + self.version
            # self.session.open(Consolepnd, _('Aggiorno Plugin: %s') % dom, ['opkg install -force-overwrite %s' % com], finishedCallback=self.msgrstrt3, closeOnSuccess=True)
 
    def msgrstrt3(self):
        #self.session.openWithCallback(pndMessageBox, _('Plugin Aggiornato!\nRiavviare interfaccia utente'), pndMessageBox.TYPE_INFO, timeout=5)
        self.mbox = self.session.open(pndMessageBox, _('Plugin Aggiornato!\nRiavviare interfaccia utente'), pndMessageBox.TYPE_INFO, timeout=5)

    def pndchckint(self):
        url3 = 'http://www.pandasat.info'
        getPage(url3).addCallback(self.ConnOK).addErrback(self.ConnNOK)
        
    def test(self, url):
        getPage(url, method='GET', headers=Agent).addCallback(self.ConnOK, url)        

    def ConnOK(self, data):
        try:
            self.pnd = data
            filex = '/tmp/note.txt'
            if os.path.exists(filex):
                os.remove(filex)
            cmd15 = nt_upd_lnk
            os.system(cmd15)
            filex2 = open(filex, 'r')
            count2 = 0
            self.notetxt = ''
            while 1:
                srg = filex2.readline()
                count2 += 1
                self.notetxt += str(srg)
                if not srg:
                    break
            self['text'].setText(self.notetxt)
        except:
            self['text'].setText(_('Errore nel download degli aggiornamenti') + ' !')
            
    def ConnNOK(self, error):
        self['chckoff'].show()
        self['pndon'].setPixmapNum(2)
        self['pndon'].show()
        self['pndinfo'].setText(_('Nessuna Connessione Internet ?'))
        self['text'].setText(_('www.pandasat.info Server Off') + ' !')  
        
    def extra(self):
        self.session.open(EXTRA)

    def lista(self):
        self.session.open(OpenScript)

    def scsetup(self):
        self.session.open(cfgplgConfig)

    def closes(self):
        filex = '/tmp/note.txt'
        if os.path.exists(filex):
            os.remove(filex)
            self.close()
        else:
            self.close()


class OpenScript(Screen):
    def __init__(self, session):
        self.session = session
        if DESKHEIGHT < 1000:
            skin = '/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/res/HD/OpenScript.xml'
        else:
            skin = '/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/res/FullHD/OpenScriptFHD.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()
        Screen.__init__(self, session)
        try:
            pthscrpts = config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthscrpts.value
            list = listdir(pthscrpts)
            if not path.exists(pthscrpts):
                list = [x[:-3]]
        except:
            list = []
        list.sort()
        self['list'] = MenuList(list)
        self['pndinfo'] = Label()
        self['version'] = Label(_('Versione %s') % Version)
        self['fittitle'] = Label(_('..:: pAnDaSAT fReE IPTV lIsT ::..'))
        self['pndteam'] = Label('by tEaM dEvElOpEr pAnDa SaT\xae')
        self['fitslz'] = Label(_('Aggiorna >> Aggiorna Elenco'))
        self['fitslz2'] = Label(_('OK >> Installa Bouquet'))
        self['fitslz3'] = Label(_('Player >> Apri M3U'))
        self['fitred'] = Label(_('Elimina'))
        self['fitred2'] = Label(_('Le liste canali'))
        self['fitgreen'] = Label(_('Ricarica'))
        self['fitgreen2'] = Label(_('Bouquet'))
        self['fityellow'] = Label(_('Aggiorna'))
        self['fityellow2'] = Label(_('Liste Disponibili'))
        self['fitblue'] = Label(_('Player'))
        self['fitblue2'] = Label(_('List'))
        self['fitgrey'] = Label(_('Info'))
        self['pndchck'] = Label(_('Internet') + _(': '))
        self['chckon'] = Label(_('ATTIVO'))
        self['chckoff'] = Label(_('DISATTIVO'))
        self['pndon'] = MultiPixmap()
        self['pndon'].setPixmapNum(0)
        self['chckon'].hide()
        self['chckoff'].hide()
        self.icount = 0
        self.timer = eTimer()
        self.timer1 = eTimer()
        try:
            self.timer.callback.append(self.pndchckint)
        except:
            self.timer_conn = self.timer.timeout.connect(self.pndchckint)

        self.timer.start(100, 1)
        _lstpnd = '/etc/pandasat/script/pAnDaSAT_FREE_ALL'
        if not os.path.isfile(_lstpnd):
            try:
                self.timer1.callback.append(self.checkList)
            except:
                self.timer1_conn = self.timer1.timeout.connect(self.checkList)

            self.timer1.start(100, 1)
        self['actions'] = ActionMap(['OkCancelActions',
         'DirectionActions',
         'ColorActions',
         'WizardActions',
         'NumberActions',
         'EPGSelectActions'], {'ok': self.messagerun,
         'red': self.messagedellist,
         'green': self.messagereload,
         'info': self.close,
         'yellow': self.messageupProg,
         #'yellow': self.messageupdate,
         'blue': self.M3uPlay,
         'back': self.close,
         'cancel': self.close}, -1)

    def checkList(self):
        #self.session.openWithCallback(self.messageupd, pndMessageBox, _('Nessuna lista in Elenco!') + ' ' + _('Scaricare Liste?') + ' by pAnDa SAT ?', pndMessageBox.TYPE_YESNO)
        self.session.openWithCallback(self.update2, pndMessageBox, _('Nessuna lista in Elenco!') + ' ' + _('Scaricare Liste?') + ' by pAnDa SAT ?', pndMessageBox.TYPE_YESNO)
        
    def pndchckint(self):
        url3 = 'http://www.pandasat.info'
        getPage(url3).addCallback(self.ConnOK).addErrback(self.ConnNOK)

    def ConnOK(self, data):
        self.pnd = data
        self['chckon'].show()
        self['pndon'].setPixmapNum(1)
        self['pndon'].show()
        self['pndinfo'].setText(_('Plugin sincronizzato ...'))

    def ConnNOK(self, error):
        self['chckoff'].show()
        self['pndon'].setPixmapNum(2)
        self['pndon'].show()
        self['pndinfo'].setText(_('Nessuna Connessione Internet ?'))

    def messagereload(self):
        self.session.openWithCallback(self.reloadSettings, pndMessageBox, _('Riordino liste Favorite in Corso') + '\n' + _('Attendere prego ...'), pndMessageBox.TYPE_INFO, timeout=3)

    def reloadSettings(self, result):
        if result:
            self.eDVBDB = eDVBDB.getInstance()
            self.eDVBDB.reloadServicelist()
            self.eDVBDB.reloadBouquets()
            
    def messagerun(self):
        self.session.openWithCallback(self.messagerun2, pndMessageBox, _('Installare lista Favorita selezionata') + ' ' + _('in Elenco') + ' by pAnDa SAT ?', pndMessageBox.TYPE_YESNO)

    def messagerun2(self, result):
        if result:
            self.session.openWithCallback(self.run, pndMessageBox, _('Installazione lista Favorita in Corso') + '\n' + _('Attendere prego ...'), pndMessageBox.TYPE_INFO, timeout=3)

    def run(self, result):
        if result:
            script = self['list'].getCurrent()
            if script is not None:
                system('chmod 755 /etc/pandasat/script/*')
                self.session.open(Consolepnd, _('pAnDaSaT cOnSoLe'), cmdlist=['/etc/pandasat/script/%s' % script], finishedCallback=self.messagereload, closeOnSuccess=True)
            else:
                self.mbox = self.session.open(pndMessageBox, _('Bouquet non Installato'), pndMessageBox.TYPE_ERROR, timeout=4)
        else:
            return
        return

    # def prombt(self, com):
        # self.session.open(Consolepnd, _('pAnDaSaT cOnSoLe'), ['%s' % com], closeOnSuccess=True)

        
    def messageupProg(self):
        self.session.openWithCallback(self.update2, pndMessageBox, _('ATTENZIONE') + ':\n' + _('Aggiornare le liste') + ' ' + _('in Elenco') + ' by pAnDa SAT ?', pndMessageBox.TYPE_YESNO)

    def update2(self, answer):
        if answer is True:
            self.session.open(Updater)
            #self.layoutFinished() #.append(self.layoutFinished)
            #infobox = self.session.open( pndMessageBox, _('Liste aggiornate con Successo !!!!!!'), pndMessageBox.TYPE_INFO, timeout=5)
            self.close()
        else:
            return
       
       
        
    def messagedellist(self):
        self.session.openWithCallback(self.deletelist, pndMessageBox, _('ATTENZIONE') + ':\n' + _('Eliminare le liste canali pAnDa SAT') + ' ?', pndMessageBox.TYPE_YESNO)

    def deletelist(self, result):
        if result:
            for file in os.listdir('/etc/enigma2/'):
                if file.startswith('userbouquet.pAnDaSAT') or file.startswith('userbouquet.pandasat'):
                    file = '/etc/enigma2/' + file
                    if os.path.exists(file):
                        print 'permantly remove file ', file
                        os.remove(file)
                        system("sed -i '/userbouquet.pAnDaSAT/d' /etc/enigma2/bouquets.tv")
                        system("sed -i '/userbouquet.pandasat/d' /etc/enigma2/bouquets.tv")
                        self.reloadSettings2()
                    radio = '/etc/enigma2/userbouquet.pAnDaSAT_RADIO.radio'
                    if os.path.exists(radio):
                        print 'permantly remove file ', radio
                        os.remove(radio)
                        system("sed -i '/userbouquet.pAnDaSAT/d' /etc/enigma2/bouquets.radio")
                        system("sed -i '/userbouquet.pandasat/d' /etc/enigma2/bouquets.radio")
                        self.reloadSettings2()

    def reloadSettings2(self):
        self.eDVBDB = eDVBDB.getInstance()
        self.eDVBDB.reloadServicelist()
        self.eDVBDB.reloadBouquets()
        self.mbox = self.session.open(pndMessageBox, _('Liste canali pAnDa SAT eliminate con successo'), pndMessageBox.TYPE_INFO, timeout=4)

    def M3uPlay(self):
        self.session.open(SELECTPLAY)
        
        
#############################################################
class Updater(Screen):

    def __init__(self, session):
        self.session = session
        if DESKHEIGHT < 1000:
            skin = '/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/res/HD/updater.xml'
        else:
            skin = '/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/res/FullHD/updaterFHD.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()
        Screen.__init__(self, session)

        self['version'] = Label(_('Versione %s') % Version)
        self['pndteam'] = Label('by tEaM dEvElOpEr pAnDa SaT\xae')
        self['status'] = Label()
        self['progress'] = Progress()
        self['progresstext'] = StaticText()
        self.readtar()
        
    def readtar(self):
        self['status'].setText(_('Downloading ...'))
        
        try:
            getPage(FTP_ALL + TXT_PUKPRG).addCallback(self.gotUpdateInfo).addErrback(self.gotError)
        except Exception as error:
            print str(error)
        

    def gotError(self, error = ''):
        pass

    def gotUpdateInfo(self, html):
        tmp_infolines = html.splitlines()
        puk = tmp_infolines[0]
        lnk = tmp_infolines[1]
        default_lnk = tmp_infolines[2]
        pin = base64.b64decode(puk)
        puklnk = base64.b64decode(lnk)
        default_puk_lnk = base64.b64decode(default_lnk)
        
        if int(pin) == config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.code.value:
            os.system('mkdir -p /tmp/pandasat')
            self.updateurl = puklnk
            self.dlfile = '/tmp/pandasat/tmp.tar'
            self.download = downloadWithProgress(self.updateurl, self.dlfile)
            self.download.addProgress(self.downloadProgress)
            
            self.download.start().addCallback(self.downloadFinished).addErrback(self.downloadFailed)

            #self.onLayoutFinish.append(self.layoutFinished)
            
            # self.timerx = eTimer()
            # try:
                # self.timerx.callback.append(self.msgupdt2)
            # except:
                # self.timerx_conn = self.timerx.timeout.connect(self.msgupdt2)
            # self.timerx.start(100, 1)
            
        elif int(pin) != config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.code.value:
            os.system('mkdir -p /tmp/pandasat')
            self.updateurl = default_puk_lnk
            self.dlfile = '/tmp/pandasat/tmp.tar'
            self.download = downloadWithProgress(self.updateurl, self.dlfile)
            self.download.addProgress(self.downloadProgress)
            self.download.start().addCallback(self.downloadFinished).addErrback(self.downloadFailed)
            
            
        else:
            self.session.open(pndMessageBox, _('Server Error!!!'), pndMessageBox.TYPE_ERROR)
      
        
    def downloadFinished(self, string = ''):
        self['status'].setText(_('Installazione di aggiornamenti!'))
        os.system('rm -rf /etc/pandasat > /dev/null')
        os.system('tar -xvf /tmp/pandasat/tmp.tar -C /')
        os.system('rm -rf /tmp/pandasat')
        os.system('sleep 3')
        infobox = self.session.open( pndMessageBox, _('Liste aggiornate con Successo !!!!!!'), pndMessageBox.TYPE_INFO, timeout=5)
        self.close()

    def downloadFailed(self, failure_instance = None, error_message = ''):
        text = _('Errore durante il download di file!')
        if error_message == '' and failure_instance is not None:
            error_message = failure_instance.getErrorMessage()
            text += ': ' + error_message
        self['status'].setText(text)
        return

    def downloadProgress(self, recvbytes, totalbytes):
        self['progress'].value = int(100 * recvbytes / float(totalbytes))
        self['progresstext'].text = '%d of %d kBytes (%.2f%%)' % (recvbytes / 1024, totalbytes / 1024, 100 * recvbytes / float(totalbytes))

     

##########################################################        
class SELECTPLAY(Screen):
    def __init__(self, session):
        self.session = session
        if DESKHEIGHT < 1000:
            skin = '/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/res/HD/SelectPlay.xml'
        else:
            skin = '/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/res/FullHD/SelectPlayFHD.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()
        Screen.__init__(self, session)
        self.list = []
        self['list'] = PNDM3UList([])
        self['version'] = Label(_('Versione %s') % Version)
        self['fittitle'] = Label(_('..:: pAnDaSAT fReE IPTV pLaYeR m3U ::..'))
        self['pndteam'] = Label('by tEaM dEvElOpEr pAnDa SaT\xae')
        self['info'] = Label()
        pthm3uf = config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthm3uf.value
        self['path'] = Label(_('Cartella Configurata in Config %s') % pthm3uf)
        self['fitred'] = Label(_('Uscire'))
        self['fitgreen'] = Label(_('Rimuovi'))
        self['fitblue'] = Label(_('Converti'))
        self['fitblue2'] = Label(_('ExtePlayer3'))
        self['fityellow'] = Label(_('Converti'))
        self['fityellow2'] = Label(_('Gstreamer'))
        self['menu'] = Label(_('Config'))        
        self['setupActions'] = ActionMap(['SetupActions', 'ColorActions', 'MenuActions', 'TimerEditActions'], {'red': self.message1,
         #'green': self.scsetup,
         'menu': self.scsetup,
         'green': self.message1,
         'blue': self.crea_bouquet5002,
         'yellow': self.crea_bouquet,
         'cancel': self.cancel,
         'ok': self.runList}, -2)
        self.convert = False


#download m3u da modificare: se non c' connex? timer?         
        if not path.exists(config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthm3uf.value + 'pAnDaSAT_Free_IPTV.m3u'):
            cmd15 = pnd_m3ulnk + config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthm3uf.value + 'pAnDaSAT_Free_IPTV.m3u > /dev/null'
            os.system(cmd15)
        else:
            cmd66 = 'rm -f ' + config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthm3uf.value + 'pAnDaSAT_Free_IPTV.m3u'
            os.system(cmd66)
            cmd15 = pnd_m3ulnk + config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthm3uf.value + 'pAnDaSAT_Free_IPTV.m3u > /dev/null'
            os.system(cmd15)
            
            
        name = config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthm3uf.value
        self['info'].setText(_('pAnDaSAT m3U: Open Select'))
        self.name = name
        self.srefOld = self.session.nav.getCurrentlyPlayingServiceReference()
        self.onLayoutFinish.append(self.openList)

        
 
#-------download .m3u     
        # self.timer = eTimer()
        # try:
            # self.timer.callback.append(self.nocheckLista)
        # except:
            # self.timer_conn = self.timer1.timeout.connect(self.nocheckLista)

        # self.timer.start(5000, True)

        
    # def nocheckLista(self):
        # cmd66 = 'rm -rf ' + config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthm3uf.value + 'pAnDaSAT_Free_IPTV.m3u'
        # os.system(cmd66)
        # cmd15 = pnd_m3ulnk + config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthm3uf.value + 'pAnDaSAT_Free_IPTV.m3u > /dev/null'
        # os.system(cmd15)
        
      
#>>>>>>>>>>>>>>>>>>end download

        
    def scsetup(self):
        self.session.openWithCallback(self.close, cfgplgConfig)

    def openList(self):
        self.names = []
        path = self.name
        for root, dirs, files in os.walk(path):
            if files is not None:
                files.sort()  
                for name in files:
                    if '.m3u' not in name:
                        continue
                    self.names.append(name)

        m3ulist(self.names, self['list'])

        
        
##############2017 v4.1        
    def message1(self):
        self.session.openWithCallback(self.callMyMsg1,pndMessageBox,_("Vuoi rimuovere?"), pndMessageBox.TYPE_YESNO)       

    def callMyMsg1(self, result):
    
        if result:
            idx = self['list'].getSelectionIndex()
            dom = self.name + self.names[idx]
            com = dom
            self.session.open(Consolepnd, _('pAnDaSaT cOnSoLe Rimuovo: %s') % dom, ['rm -rf %s' % com], closeOnSuccess=True)          
            self.onShown.append(self.openList)
            

###############        


    # def runList(self):
        # idx = self['list'].getSelectionIndex()
        # if idx is None:
            # return
        # else:
            # name = self.name + self.names[idx]
            # if '.m3u' in name : 
                # self.session.open(M3uPlay, name)
                # return
            # else:
                # name = self.name + self.names[idx]            
                # sref = eServiceReference(4097, 0, name)
                # sref.setName(name)
                # self.session.open(M3uPlay2, sref)
                # return
                


        
    def runList(self):
        idx = self['list'].getSelectionIndex()
        if idx is None:
            return
        else:
            name = self.name + self.names[idx]
            self.session.open(M3uPlay, name)
            return

    def crea_bouquet(self):
        idx = self['list'].getSelectionIndex()
        if idx is None:
            return
        else:
            name = self.names[idx]
            self.create_bouquet()
            return
            
    def crea_bouquet5002(self):
        idx = self['list'].getSelectionIndex()
        if idx is None:
            return
        else:
            name = self.names[idx]
            self.create_bouquet5002()
            return
            
    def create_bouquet5002(self):
        idx = self['list'].getSelectionIndex()
        if idx is None:
            return
        else:
            self.convert = True
            name = self.names[idx]
            pth = self.name
            PNDNAME = 'userbouquet.%s.tv' % name
            self['info'] = StaticText()
            self.iConsole = iConsole()
            self['info'].text = _('Converting %s' % name)
            desk_tmp = hls_opt = ''
            in_bouquets = 0
            if os.path.isfile('/etc/enigma2/%s' % PNDNAME):
                os.remove('/etc/enigma2/%s' % PNDNAME)
            with open('/etc/enigma2/%s' % PNDNAME, 'w') as outfile:
                outfile.write('#NAME %s\r\n' % name.capitalize())
                for line in open(pth + '%s' % name):
                    if line.startswith('http://'):
                        outfile.write('#SERVICE 5002:0:1:1:0:0:0:0:0:0:%s' % line.replace(':', '%3a'))
                        outfile.write('#DESCRIPTION %s' % desk_tmp)
                    elif line.startswith('#EXTINF'):
                        desk_tmp = '%s' % line.split(',')[-1]
                    elif '<stream_url><![CDATA' in line:
                        outfile.write('#SERVICE 5002:0:1:1:0:0:0:0:0:0:%s\r\n' % line.split('[')[-1].split(']')[0].replace(':', '%3a'))
                        outfile.write('#DESCRIPTION %s\r\n' % desk_tmp)
                    elif '<title>' in line:
                        if '<![CDATA[' in line:
                            desk_tmp = '%s\r\n' % line.split('[')[-1].split(']')[0]
                        else:
                            desk_tmp = '%s\r\n' % line.split('<')[1].split('>')[1]
                outfile.close()
            self['info'].setText(_('pAnDaSAT m3U: Open Select'))
            self.mbox = self.session.open(pndMessageBox, _('CONTROLLA NELLA LISTA FAVORITI...'), pndMessageBox.TYPE_INFO, timeout=5)
            if os.path.isfile('/etc/enigma2/bouquets.tv'):
                for line in open('/etc/enigma2/bouquets.tv'):
                    if PNDNAME in line:
                        in_bouquets = 1

                if in_bouquets is 0:
                    if os.path.isfile('/etc/enigma2/%s' % PNDNAME) and os.path.isfile('/etc/enigma2/bouquets.tv'):
                        remove_line('/etc/enigma2/bouquets.tv', PNDNAME)
                        with open('/etc/enigma2/bouquets.tv', 'a') as outfile:
                            outfile.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\r\n' % PNDNAME)
                            outfile.close()
            return

    def create_bouquet(self):
        idx = self['list'].getSelectionIndex()
        if idx is None:
            return
        else:
            self.convert = True
            name = self.names[idx]
            pth = self.name
            PNDNAME = 'userbouquet.%s.tv' % name
            self['info'] = StaticText()
            self.iConsole = iConsole()
            self['info'].text = _('Converting %s' % name)
            desk_tmp = hls_opt = ''
            in_bouquets = 0
            if os.path.isfile('/etc/enigma2/%s' % PNDNAME):
                os.remove('/etc/enigma2/%s' % PNDNAME)
            with open('/etc/enigma2/%s' % PNDNAME, 'w') as outfile:
                outfile.write('#NAME %s\r\n' % name.capitalize())
                for line in open(pth + '%s' % name):
                    if line.startswith('http://'):
                        outfile.write('#SERVICE 4097:0:1:1:0:0:0:0:0:0:%s' % line.replace(':', '%3a'))
                        outfile.write('#DESCRIPTION %s' % desk_tmp)
                    elif line.startswith('#EXTINF'):
                        desk_tmp = '%s' % line.split(',')[-1]
                    elif '<stream_url><![CDATA' in line:
                        outfile.write('#SERVICE 4097:0:1:1:0:0:0:0:0:0:%s\r\n' % line.split('[')[-1].split(']')[0].replace(':', '%3a'))
                        outfile.write('#DESCRIPTION %s\r\n' % desk_tmp)
                    elif '<title>' in line:
                        if '<![CDATA[' in line:
                            desk_tmp = '%s\r\n' % line.split('[')[-1].split(']')[0]
                        else:
                            desk_tmp = '%s\r\n' % line.split('<')[1].split('>')[1]

                outfile.close()
            self['info'].setText(_('pAnDaSAT m3U: Open Select'))
            self.mbox = self.session.open(pndMessageBox, _('CONTROLLA NELLA LISTA FAVORITI...'), pndMessageBox.TYPE_INFO, timeout=5)
            if os.path.isfile('/etc/enigma2/bouquets.tv'):
                for line in open('/etc/enigma2/bouquets.tv'):
                    if PNDNAME in line:
                        in_bouquets = 1

                if in_bouquets is 0:
                    if os.path.isfile('/etc/enigma2/%s' % PNDNAME) and os.path.isfile('/etc/enigma2/bouquets.tv'):
                        remove_line('/etc/enigma2/bouquets.tv', PNDNAME)
                        with open('/etc/enigma2/bouquets.tv', 'a') as outfile:
                            outfile.write('#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet\r\n' % PNDNAME)
                            outfile.close()
            return

            
            
#RELOAD LIST da modificare: se non converto nessuna lista ? reload dopo conversione?   #ok         
    def cancel(self):
        if self.convert == False:
            self['info'].setText(_('pAnDaSAT m3U: Open Select'))
            self.close()
        else:
            self.mbox = self.session.open(pndMessageBox, _('Riordino liste Favorite in Corso') + '\n' + _('Attendere prego ...'), pndMessageBox.TYPE_INFO, timeout=5)
            eDVBDB.getInstance().reloadBouquets()
            eDVBDB.getInstance().reloadServicelist()
            self['info'].setText(_('pAnDaSAT m3U: Open Select'))
            self.close()


class M3uPlay(Screen):
    def __init__(self, session, name):
        self.session = session
        if DESKHEIGHT < 1000:
            skin = '/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/res/HD/M3uPlay.xml'
        else:
            skin = '/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/res/FullHD/M3uPlayFHD.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()
        Screen.__init__(self, session)
        self.list = []
        self['list'] = PNDM3UList([])
        self['info'] = Label()
        self['version'] = Label(_('Versione %s') % Version)
        self['fittitle'] = Label(_('..:: pAnDaSAT fReE IPTV pLaYeR m3U ::..'))
        self['pndteam'] = Label('by tEaM dEvElOpEr pAnDa SaT\xae')
        self['fitred'] = Label(_('Chiudi'))
        self['fitgreen'] = Label(_('Play'))
        self['fityellow'] = Label(_('AddStream'))
        self['setupActions'] = ActionMap(['SetupActions', 'ColorActions', 'TimerEditActions'], {'red': self.close,
         'green': self.runChannel,
         'cancel': self.cancel,
         'yellow': self.AdjUrlFavo,
         'ok': self.runChannel}, -2)
        self['info'].setText(_('pAnDaSAT m3U: Select Channel'))
        self['live'] = Label('')
        self['live'].setText('')
        self.name = name
        self.srefOld = self.session.nav.getCurrentlyPlayingServiceReference()
        self.onLayoutFinish.append(self.playList)

    def playList(self):
        self.names = []
        self.urls = []
        if fileExists(self.name):
            f1 = open(self.name, 'r+')
            fpage = f1.read()
            regexcat = 'EXTINF.*?,(.*?)\\n(.*?)\\n'
            match = re.compile(regexcat, re.DOTALL).findall(fpage)
            for name, url in match:
                url = url.replace(' ', '')
                url = url.replace('\\n', '')
                self.names.append(name)
                self.urls.append(url)
            m3ulist(self.names, self['list'])
            self['live'].setText(str(len(self.names)) + ' Stream')
        else:
            self.session.open(MessageBox, 'File Not Found', type=MessageBox.TYPE_INFO, timeout=8)

    def runChannel(self):
        idx = self['list'].getSelectionIndex()
        if idx is None:
            return
        else:
            name = self.names[idx]
            url = self.urls[idx]
            self.session.open(M3uPlay2, name, url)
            return

    def AdjUrlFavo(self):
        idx = self['list'].getSelectionIndex()
        if idx is None:
            return
        else:
            name = self.names[idx]
            url = self.urls[idx]
            self.session.open(AddIpvStream, name, url)
            return

    def cancel(self):
        Screen.close(self, False)


class M3uPlay2(Screen, InfoBarMenu, InfoBarBase, InfoBarSeek, InfoBarNotifications, InfoBarShowHide, InfoBarAudioSelection, InfoBarSubtitleSupport):

    # STATE_IDLE = 0
    # STATE_PLAYING = 1
    # STATE_PAUSED = 2
    # ENABLE_RESUME_SUPPORT = True
    # ALLOW_SUSPEND = True

                
    def __init__(self, session, name, url):
        
        # self.session = session
        # if DESKHEIGHT < 1000:
            # skin = '/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/res/HD/MoviePlayerPnd.xml'
        # else:
            # skin = '/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/res/FullHD/MoviePlayerPnd.xml'
        
        # f = open(skin, 'r')
        # self.skin = f.read()
        # f.close()        
        
        
        Screen.__init__(self, session)
        
        self.skinName = 'MoviePlayer'
        title = 'Play Stream'
        
        self['list'] = MenuList([])
        InfoBarMenu.__init__(self)
        InfoBarNotifications.__init__(self)
        InfoBarBase.__init__(self)
        InfoBarShowHide.__init__(self)
        
        # InfoBarSubtitleSupport.__init__(self)
        # InfoBarAudioSelection.__init__(self)
        
        
        
        self['actions'] = ActionMap(['WizardActions',
         'MoviePlayerActions',
         'MovieSelectionActions',
         'MediaPlayerActions',
         'EPGSelectActions',
         'MediaPlayerSeekActions',
         'ColorActions',
         'InfobarShowHideActions',
         'InfobarActions',
         'InfobarSeekActions'], {'leavePlayer': self.cancel,
         'showEventInfo': self.showVideoInfo,
         'stop': self.leavePlayer,
         
         # "playpauseService": self.playpauseService,
         # "seekFwd": self.playNextFile,
         # "seekBack": self.playPrevFile,

         'back': self.cancel}, -1)
        self.allowPiP = False
        
#        InfoBarSeek.__init__(self, actionmap='MediaPlayerSeekActions')
        InfoBarSeek.__init__(self, actionmap='InfobarSeekActions')       
        
        
        url = url.replace(':', '%3a')
        self.url = url
        self.name = name
        self.srefOld = self.session.nav.getCurrentlyPlayingServiceReference()
        self.onLayoutFinish.append(self.openPlay)

    def openPlay(self):
        url = self.url
        ref = '4097:0:1:0:0:0:0:0:0:0:' + url
        sref = eServiceReference(ref)
        sref.setName(self.name)
        self.session.nav.stopService()
        self.session.nav.playService(sref)

    def keyNumberGlobal(self, number):
        self['text'].number(number)

    def cancel(self):
        self.session.nav.stopService()
        self.session.nav.playService(self.srefOld)
        self.close()

    def ok(self):
        if self.shown:
            self.hideInfobar()
        else:
            self.showInfobar()

    def keyLeft(self):
        self['text'].left()

    def keyRight(self):
        self['text'].right()

    def showVideoInfo(self):
        if self.shown:
            self.hideInfobar()
        if self.infoCallback is not None:
            self.infoCallback()
        return

    def leavePlayer(self):
        self.close()

        
        
class AddIpvStream(Screen):

    def __init__(self, session, name, url):
        self.session = session
        if DESKHEIGHT < 1000:
            skin = '/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/res/HD/AddIpvStream.xml'
        else:
            skin = '/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/res/FullHD/AddIpvStreamFHD.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()
        Screen.__init__(self, session)
        self['version'] = Label(_('Versione %s') % Version)
        self['pndteam'] = Label('by tEaM dEvElOpEr pAnDa SaT')
        self['actions'] = ActionMap(['SetupActions', 'ColorActions'], {'ok': self.keyOk,
         'cancel': self.keyCancel,
         'green': self.keyOk,
         'red': self.keyCancel}, -2)
        self['statusbar'] = StaticText(_('Select streams to add in bouquet '))
        self.list = []
        self['menu'] = MenuList([])
        self.mutableList = None
        self.servicelist = ServiceList(None)
        self.onLayoutFinish.append(self.createTopMenu)
        self.namechannel = name
        self.urlchannel = url
        return

    def initSelectionList(self):
        self.list = []
        self['menu'].setList(self.list)

    def createTopMenu(self):
        self.setTitle(_('Add IPTV Channels'))
        self.initSelectionList()
        self.list = []
        tmpList = []
        self.list = self.getBouquetList()
        self['menu'].setList(self.list)

    def getBouquetList(self):
        self.service_types = service_types_tv
        if config.usage.multibouquet.value:
            self.bouquet_rootstr = '1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "bouquets.tv" ORDER BY bouquet'
        else:
            self.bouquet_rootstr = '%s FROM BOUQUET "userbouquet.favourites.tv" ORDER BY bouquet' % self.service_types
        self.bouquet_root = eServiceReference(self.bouquet_rootstr)
        bouquets = []
        serviceHandler = eServiceCenter.getInstance()
        if config.usage.multibouquet.value:
            list = serviceHandler.list(self.bouquet_root)
            if list:
                while True:
                    s = list.getNext()
                    if not s.valid():
                        break
                    if s.flags & eServiceReference.isDirectory:
                        info = serviceHandler.info(s)
                        if info:
                            bouquets.append((info.getName(s), s))

                return bouquets
        else:
            info = serviceHandler.info(self.bouquet_root)
            if info:
                bouquets.append((info.getName(self.bouquet_root), self.bouquet_root))
            return bouquets
        return None

    def keyOk(self):
        if len(self.list) == 0:
            return
        self.name = ''
        self.url = ''
        self.session.openWithCallback(self.addservice, VirtualKeyBoard, title=_('Enter name'), text=self.namechannel)

    def addservice(self, res):
        if res:
            self.url = res
            str = '4097:0:0:0:0:0:0:0:0:0:%s:%s' % (quote(self.url), quote(self.name))
            ref = eServiceReference(str)
            self.addServiceToBouquet(self.list[self['menu'].getSelectedIndex()][1], ref)
            self.close()

    def addServiceToBouquet(self, dest, service = None):
        mutableList = self.getMutableList(dest)
        if mutableList is not None:
            if service is None:
                return
            if not mutableList.addService(service):
                mutableList.flushChanges()
        return

    def getMutableList(self, root = eServiceReference()):
        if self.mutableList is not None:
            return self.mutableList
        else:
            serviceHandler = eServiceCenter.getInstance()
            if not root.valid():
                root = self.getRoot()
            list = root and serviceHandler.list(root)
            if list is not None:
                return list.startEdit()
            return
            return

    def getRoot(self):
        return self.servicelist.getRoot()

    def keyCancel(self):
        self.close()

class cfgplgConfig(Screen, ConfigListScreen):

    def __init__(self, session):
        self.session = session
        if DESKHEIGHT < 1000:
            skin = '/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/res/HD/cfgplgConfig.xml'
        else:
            skin = '/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/res/FullHD/cfgplgConfigFHD.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()
        Screen.__init__(self, session)
        info = '***'
        self['fittitle'] = Label(_('..:: pAnDaSAT iPtV cOnFiG ::..'))
        self['version'] = Label(_('Versione %s') % Version)
        self['pndteam'] = Label('by tEaM dEvElOpEr pAnDa SaT\xae')
        self['fitred'] = Label(_('Chiudi'))
        self['plgupd'] = Label(_('Aggiorna Plugin'))
        self['fitgreen'] = Label(_('Salva'))
        self['text'] = Label(info)
        configlist = []
        ConfigListScreen.__init__(self, configlist, session=session)
        configlist.append(getConfigListEntry(_('Auto Update Plugin:'), config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.autoupd))
        configlist.append(getConfigListEntry(_('Password Personale:'), config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.code))
        configlist.append(getConfigListEntry(_('Percorso Picons:'), config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthpcns))
        configlist.append(getConfigListEntry(_('Percorso Scripts:'), config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthchs))
        configlist.append(getConfigListEntry(_('Liste Player <.m3u>:'), config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthm3uf))
        configlist.append(getConfigListEntry(_('Percorso Liste Enigma:'), config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthscrpts))
        configlist.append(getConfigListEntry(_('Link in Extensions Menu:'), config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.strtext))
        configlist.append(getConfigListEntry(_('Link in Menu Principale:'), config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.strtmain))
        self['config'].list = configlist
        self['config'].setList(configlist)
        self.cbUpdate = False
        try:
            fp = urllib.urlopen(FTP_ALL + upd_fr_txt)
            count = 0
            self.labeltext = ''
            s1 = fp.readline()
            s2 = fp.readline()
            s3 = fp.readline()
            s1 = s1.strip()
            s2 = s2.strip()
            s3 = s3.strip()
            self.link = s2
            self.version = s1
            self.info = s3
            fp.close()
            cstr = s1 + ' ' + s2
            if s1 == currversion:
                self['text'].setText(_('Free IPTV versione: ') + currversion + _('\n\nNessun aggiornamento online!') + _('\n\nGrazie a coloro che hanno lavorato al progetto') + _('\n\nPLEASE DONATE'))
                self.cbUpdate = False
            elif float(s1) < float(currversion):
                self['text'].setText(_('Free IPTV versione: ') + currversion + _('\n\nNessun aggiornamento online!') + _('\n\nGrazie a coloro che hanno lavorato al progetto') + _('\n\nPLEASE DONATE'))
                self.cbUpdate = False
            else:
                updatestr = (_('Free IPTV versione: ') + currversion + _('\nUltimo aggiornamento ') + s1 + _(' disponibile!  \nChangeLog:') + self.info)
                self.cbUpdate = True
                self['text'].setText(updatestr)
        except:
            self.cbUpdate = False
            self['text'].setText(_('Nessun aggiornamento disponibile') + _('\n\nNessuna connessione Internet o server OFF') + _('\n\nPrego riprova piu tardi.'))

        self.timerx = eTimer()
        try:
            self.timerx.callback.append(self.msgupdt2)
        except:
            self.timerx_conn = self.timerx.timeout.connect(self.msgupdt2)

        self.timerx.start(100, 1)
        self['actions'] = ActionMap(['SetupActions', 'ColorActions'], {'cancel': self.extnok,
         'red': self.extnok,
         'yellow': self.msgupdt1,
         'back': self.close,
         'ok': self.msgok,
         'green': self.msgok}, -1)

    def msgupdt2(self):
        if self.cbUpdate == False:
            return
        if config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.autoupd.value == False:
            return
        self.session.openWithCallback(self.runupdate, pndMessageBox, _('Nuova Versione Online!!!\n\nAggiornare Plugin alla Versione %s ?' % self.version), pndMessageBox.TYPE_YESNO)

    def msgupdt1(self):
        if self.cbUpdate == False:
            return
        self.session.openWithCallback(self.runupdate, pndMessageBox, _('Aggiornare Plugin ?'), pndMessageBox.TYPE_YESNO)

    def runupdate(self, result):
        if self.cbUpdate == False:
            return
        if result:
            com = self.link
            dom = 'Nuova versione ' + self.version
            self.session.open(Consolepnd, _('Aggiorno Plugin: %s') % dom, ['opkg install -force-overwrite %s' % com], finishedCallback=self.msgrstrt3, closeOnSuccess=True)
        
    def msgrstrt3(self):
        self.mbox = self.session.open(pndMessageBox, _('Plugin Aggiornato!\nRiavviare interfaccia utente'), pndMessageBox.TYPE_INFO, timeout=4)
        
    def extnok(self, answer = None):
        if answer is None:
            if self['config'].isChanged():
                self.session.openWithCallback(self.ShowMain2, pndMessageBox, _('Uscire senza salvare') + ' ?')
            else:
                self.close()
        return

    def ShowMain2(self, result):
        if result:
            self.close()

    def msgok(self):
        if not os.path.exists(config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthpcns.value):
            self.mbox = self.session.open(pndMessageBox, _('Device Picons non rilevato!'), pndMessageBox.TYPE_INFO, timeout=4)
            return
        if not os.path.exists(config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthchs.value):
            self.mbox = self.session.open(pndMessageBox, _('Path Scripts non rilevato!'), pndMessageBox.TYPE_INFO, timeout=4)
            return
        if not os.path.exists(config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthm3uf.value):
            self.mbox = self.session.open(pndMessageBox, _('Path Liste m3u non rilevato!'), pndMessageBox.TYPE_INFO, timeout=4)
            return
        for x in self['config'].list:
            x[1].save()

            
        # config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.code.save
        # configfile.save()
        # config.save()
        # plugins.clearPluginList()
        # plugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
        # self.mbox = self.session.open(pndMessageBox, _('Configurazione salvata con successo'), pndMessageBox.TYPE_INFO, timeout=4)        
            
        plugins.clearPluginList()
        plugins.readPluginList(resolveFilename(SCOPE_PLUGINS))
        self.mbox = self.session.open(pndMessageBox, _('Configurazione salvata con successo'), pndMessageBox.TYPE_INFO, timeout=4)
        

class EXTRA(Screen):

    def __init__(self, session):
        self.session = session
        if DESKHEIGHT < 1000:
            skin = '/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/res/HD/EXTRA.xml'
        else:
            skin = '/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/res/FullHD/EXTRAFHD.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()
        Screen.__init__(self, session)
        try:
            pthchs = config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthchs.value
            list = listdir(pthchs)
            if not path.exists(pthchs):
                list = [x[:-3]]
        except:
            list = []

        list.sort()
        self['list'] = MenuList(list)
        self['fittitle'] = Label(_('..:: pAnDaSAT uSeFuLl sCrIpT ::..'))
        self['fitslz'] = Label(_('Utile serie di script selezionati dal team'))
        self['fitslz2'] = Label(_('Scegliere da elenco il comando da eseguire...'))
        self['pndteam'] = Label('by tEaM dEvElOpEr pAnDa SaT\xae')
        self['version'] = Label(_('Versione %s') % Version)
        self['fitred'] = Label(_('Chiudi'))
        self['fitgreen'] = Label(_('Speed'))
        self['fitgreen2'] = Label(_('Test'))
        self['fityellow'] = Label(_('Picons'))
        self['fityellow2'] = Label(_('pAnDaSAT'))
        
        self['fitblue'] = Label(_('Player'))
        self['fitblue2'] = Label(_('List'))
        
        self['fitgrey'] = Label(_('Info'))
        self.icount = 0
        self.timer1 = eTimer()
        _lstpnd = '/etc/pandasat/extra/TempClean'
        if not os.path.isfile(_lstpnd):
            try:
                self.timer1.callback.append(self.checkList)
            except:
                self.timer1_conn = self.timer1.timeout.connect(self.checkList)

            self.timer1.start(100, 1)        
        self['actions'] = ActionMap(['OkCancelActions',
         'DirectionActions',
         'ColorActions',
         'WizardActions',
         'NumberActions',
         'EPGSelectActions'], {'ok': self.messagerun,
         'red': self.close,
         'green': self.messagespeedtest,
         'info': self.close,
         'back': self.close,
         'yellow': self.picon,

         'blue': self.M3uPlay,

         #'blue': self.messagerun,
         'cancel': self.close}, -1)

         
    def checkList(self):
        #self.session.openWithCallback(self.messageupd, pndMessageBox, _('Nessuno script in Elenco!') + ' ' + _('Scaricare Script') + ' by pAnDa SAT ?', pndMessageBox.TYPE_YESNO)
        self.session.openWithCallback(self.update2, pndMessageBox, _('Nessuno script in Elenco!') + ' ' + _('Scaricare Script') + ' by pAnDa SAT ?', pndMessageBox.TYPE_YESNO)        

    def update2(self, answer):
        if answer is True:
            self.session.open(Updater)
            #infobox = self.session.open( pndMessageBox, _('Liste aggiornate con Successo !!!!!!'), pndMessageBox.TYPE_INFO, timeout=5)
            self.close()
        else:
            return

    def messagerun(self):
        self.session.openWithCallback(self.messagerun2, pndMessageBox, _('Esegui script selezionato') + ' ' + _('in Elenco') + ' by pAnDa SAT ?', pndMessageBox.TYPE_YESNO)

    def messagerun2(self, result):
        if result:
            self.session.openWithCallback(self.run, pndMessageBox, _('Recupero Informazioni in Corso') + '\n' + _('Attendere prego ...'), pndMessageBox.TYPE_INFO, timeout=3)

    def run(self, result):
        if result:
            pthchs2 = config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthchs.value
            script = self['list'].getCurrent()
            if script is not None:
                system('chmod 755 %s/*' % pthchs2)
                self.prombt(pthchs2 + '/' + script)
            return
        else:
            return
            return

    def messagespeedtest(self):
        self.session.openWithCallback(self.speedtest, pndMessageBox, _('ATTENZIONE') + ':\n' + _('Utilizzando il test bisogna attendere') + '\n' + _('qualche minuto...') + '\n' + _('Continuare') + ' ?', pndMessageBox.TYPE_YESNO)

    def speedtest(self, result):
        if result:
            cmd17 = 'chmod 755 ' + plugin_path + 'res/script/speedtest.py'
            os.system(cmd17)
            self.session.open(SpeedtestS)
            return

    def prombtspeed(self, com):
        self.session.open(SpeedtestS)

    def prombt(self, com):
        self.session.open(Consolepnd, _('pAnDaSaT cOnSoLe'), ['%s' % com], closeOnSuccess=False)

    def picon(self):
        self.session.open(PICONS)
        
    def M3uPlay(self):
        self.session.open(SELECTPLAY)

class SpeedtestS(Screen):

    def __init__(self, session):
        self.session = session
        if DESKHEIGHT < 1000:
            skin = '/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/res/HD/Speedtestpnd.xml'
        else:
            skin = '/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/res/FullHD/SpeedtestpndFHD.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()
        Screen.__init__(self, session)
        self['version'] = Label(_('Versione %s') % Version)
        self['pndteam'] = Label('by tEaM dEvElOpEr pAnDa SaT\xae')
        self['fitping'] = Label(_('Ping'))
        self['fithost'] = Label(_('Host'))
        self['fitip'] = Label(_('IP'))
        self['fitdownload'] = Label(_('Download'))
        self['fitupload'] = Label(_('Upload'))
        self['fitred'] = Label(_('Chiudi'))
        self['text'] = Label(_('Speed Test in corso, attendere......'))
        self['ping'] = Label(' ')
        self['host'] = Label(' ')
        self['ip'] = Label(' ')
        self['download'] = Label(' ')
        self['upload'] = Label(' ')
        self['actions'] = ActionMap(['WizardActions',
         'OkCancelActions',
         'DirectionActions',
         'ColorActions'], {'ok': self.cancel,
         'back': self.cancel}, -1)
        cmd = 'python ' + plugin_path + 'res/script/speedtest.py'
        self.text = ''
        self.container = eConsoleAppContainer()
        try:
            self.container.appClosed.append(self.runtest)
        except:
            self.appClosed_conn = self.container.appClosed.connect(self.runtest)

        try:
            self.container.dataAvail.append(self.dataAvail)
        except:
            self.dataAvail_conn = self.container.dataAvail.connect(self.dataAvail)

        self.container.execute(cmd)

    def runtest(self, retval):
        print 'retval', retval
        print 'Test OK'
        self['text'].setText(_('\nSPEEDTEST\nCOMPLETATO\n\nby tEaM dEvElOpEr pAnDa SaT'))

        
    def cancel(self):
        try:
            self.container.appClosed.remove(self.runtest)
        except:
            self.appClosed_conn = None

        try:
            self.container.dataAvail.remove(self.dataAvail)
        except:
            self.dataAvail_conn = None

        self.close()
        return

    def dataAvail(self, rstr):
        if rstr:
            self.text = self.text + rstr
            parts = rstr.split('\n')
            for part in parts:
                if 'Hosted by' in part:
                    try:
                        host = part.split('Hosted by')[1].split('[')[0].strip()
                    except:
                        host = ''

                    self['host'].setText(str(host))
                if 'Testing from' in part:
                    ip = part.split('Testing from')[1].split(')')[0].replace('(', '').strip()
                    self['ip'].setText(str(ip))
                if 'Ping' in rstr:
                    try:
                        ping = rstr.split('Ping')[1].split('\n')[0].strip()
                    except:
                        ping = ''

                    self['ping'].setText(str(ping))
                    self.text = ''
                    self.text = 'Test speed download ....'
                if 'Download:' in rstr:
                    try:
                        download = rstr.split(':')[1].split('\n')[0].strip()
                    except:
                        download = ''

                    self['download'].setText(str(download))
                    self.text = ''
                    self.text = 'Test speed upload ....'
                if 'Upload:' in rstr:
                    try:
                        upload = rstr.split(':')[1].split('\n')[0].strip()
                    except:
                        upload = ''

                    self['upload'].setText(str(upload))
                    self.text = ''
                    self['text'].setText('Test OK')

            self['text'].setText(self.text)


class PICONS(Screen):

    def __init__(self, session):
        self.session = session
        if DESKHEIGHT < 1000:
            skin = '/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/res/HD/PICONS.xml'
        else:
            skin = '/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/res/FullHD/PICONSFHD.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()
        Screen.__init__(self, session)
        self['version'] = Label(_('Versione %s') % Version)
        self['fittitle'] = Label(_('..:: pAnDaSAT pIcOnS CoLlEcTiOn ::..'))
        self['fitslz'] = Label(_('Controlla di avere sufficiente spazio per il download dei picons'))
        self['fitslz2'] = Label(_('Scegliere la destinazione dei picons in Config'))
        self['pndteam'] = Label('by tEaM dEvElOpEr pAnDa SaT\xae')
        self['fitred'] = Label(_('Elimina'))
        self['fitred2'] = Label(_('I Picons'))
        self['fitgreen'] = Label(_('Installa'))
        self['fitgreen2'] = Label(_('I Picons'))
        self['fityellow'] = Label(_('Config'))
        self['fitgrey'] = Label(_('Info'))
        patchPcn = config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthpcns.value
        self['path'] = Label(_('Cartella Configurata in Config %s') % patchPcn)
        self['actions'] = ActionMap(['OkCancelActions',
         'DirectionActions',
         'ColorActions',
         'WizardActions',
         'NumberActions',
         'EPGSelectActions'], {'ok': self.close,
         'red': self.messagedelpicon,
         'info': self.close,
         'back': self.close,
         'green': self.runpicons,
         'yellow': self.scsetup,
         'cancel': self.close}, -1)

    def messagedelpicon(self):
        patchPcn = config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthpcns.value
        self.session.openWithCallback(self.delpicon, pndMessageBox, _('ATTENZIONE:\n Eliminare i Picon by pAnDa SAT?') + '\n' + _('in %spicon') % patchPcn, pndMessageBox.TYPE_YESNO)

    def delpicon(self, result):
        if result:
            if config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthpcns.value == '/usr/share/enigma2/':
                system('opkg remove picons-pandasat-freeiptv-flash')
            elif config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthpcns.value == '/media/hdd/':
                system('opkg remove picons-pandasat-freeiptv-hdd')
            elif config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthpcns.value == '/media/usb/':
                system('opkg remove picons-pandasat-freeiptv-usb')
            else:
                cmd17 = 'rm -f ' + config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthpcns.value + 'picon/4097_*'
                os.system(cmd17)
                time.sleep(100)
            self.endpicondel()
        else:
            return

    def endpicondel(self):
        self.mbox = self.session.open(pndMessageBox, _('Picons eliminati con successo'), pndMessageBox.TYPE_WARNING, timeout=4)

    def runpicons(self):
        if not os.path.isfile(config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthpcns.value + '/picon/4097_0_1_A1_998_9999_820000_0_0_0.png'):
            self.messagepcn()
        else:
            self.mbox = self.session.open(pndMessageBox, _("PICONS GIA' INSTALLATI.  ELIMINARE PRIMA."), pndMessageBox.TYPE_WARNING, timeout=4)            
            
    def messagepcn(self):
        patchPcn = config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthpcns.value
        self.session.openWithCallback(self.messagepcn2, pndMessageBox, (_('ATTENZIONE:\n Installa i Picon by pAnDa SAT\n') + _('in %spicon') % patchPcn + _('\n al termine riavviare Enigma!') ), pndMessageBox.TYPE_YESNO)            
            
    def messagepcn2(self, result):
        patchPcn = config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthpcns.value
        if result:
            self.session.openWithCallback(self.piconinst, pndMessageBox, _('Installazione Picons in Corso') + '\n' + _('in %spicon') % patchPcn + '\n' + _('Attendere prego ...'), pndMessageBox.TYPE_WARNING, timeout=3)            
            
    def piconinst(self, result):
        patchPcn = config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthpcns.value
        if result:
            if os.path.exists(patchPcn) is True and patchPcn == '/media/hdd/':
                self.link = picon_ipk_hdd
            if os.path.exists(patchPcn) is True and patchPcn == '/media/usb/':
                self.link = picon_ipk_usb
            if os.path.exists(patchPcn) is True and patchPcn == '/usr/share/enigma2/':
                self.link = picon_ipk_flash
            com = self.link
            dom = (_('in %s') % patchPcn + _('picon'))
            self.session.open(Consolepnd, _('Installazione Picons: %s') % dom, ['opkg install -force-overwrite %s' % com], finishedCallback=self.done(), closeOnSuccess=True)
            
        else:
            self.mbox = self.session.open(pndMessageBox, (_('Impossibile Installare Picon') + _(' in %spicon') % patchPcn), pndMessageBox.TYPE_WARNING, timeout=5)            
            
    def done(self):
        patchPcn = config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.pthpcns.value
        self.mbox = self.session.open(pndMessageBox, (_('Picons installati con successo') + _(' in %spicon') % patchPcn), pndMessageBox.TYPE_INFO, timeout=6)

    def scsetup(self):
        self.session.openWithCallback(self.close, cfgplgConfig)


class Consolepnd(Screen):

    def __init__(self, session, title = None, cmdlist = None, finishedCallback = None, closeOnSuccess = False):
        self.session = session
        if DESKHEIGHT < 1000:
            skin = '/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/res/HD/Consolepnd.xml'
        else:
            skin = '/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/res/FullHD/ConsolepndFHD.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()
        Screen.__init__(self, session)
        self.finishedCallback = finishedCallback
        self.closeOnSuccess = closeOnSuccess
        self['text'] = ScrollLabel('')
        self['actions'] = ActionMap(['WizardActions', 'DirectionActions'], {'ok': self.cancel,
         'back': self.cancel,
         'up': self['text'].pageUp,
         'down': self['text'].pageDown}, -1)
        self.cmdlist = cmdlist
        self.container = eConsoleAppContainer()
        self.run = 0
        try:
            self.container.appClosed.append(self.runFinished)
        except:
            self.appClosed_conn = self.container.appClosed.connect(self.runFinished)

        try:
            self.container.dataAvail.append(self.dataAvail)
        except:
            self.dataAvail_conn = self.container.dataAvail.connect(self.dataAvail)

        self.onLayoutFinish.append(self.startRun)

    def updateTitle(self):
        self.setTitle(self.newtitle)

    def startRun(self):
        self['text'].setText(_('Esecuzione in corso:') + '\n\n')
        print 'Console: executing in run', self.run, ' the command:', self.cmdlist[self.run]
        if self.container.execute(self.cmdlist[self.run]):
            self.runFinished(-1)

    def runFinished(self, retval):
        self.run += 1
        if self.run != len(self.cmdlist):
            if self.container.execute(self.cmdlist[self.run]):
                self.runFinished(-1)
        else:
            str = self['text'].getText()
            str += _('Esecuzione finita!!')
            self['text'].setText(str)
            self['text'].lastPage()
            if self.finishedCallback is not None:
                self.finishedCallback()
            if not retval and self.closeOnSuccess:
                self.cancel()
        return

    def cancel(self):
        if self.run == len(self.cmdlist):
            self.close()
        try:
            self.container.appClosed.remove(self.runFinished)
        except:
            self.appClosed_conn = None

        try:
            self.container.dataAvail.remove(self.dataAvail)
        except:
            self.dataAvail_conn = None

        return

    def dataAvail(self, str):
        self['text'].setText(self['text'].getText() + str)


class pndMessageBox(Screen):
    TYPE_YESNO = 0
    TYPE_INFO = 1
    TYPE_WARNING = 2
    TYPE_ERROR = 3
    TYPE_MESSAGE = 4

    def __init__(self, session, text, type = TYPE_YESNO, timeout = -1, close_on_any_key = False, default = True, enable_input = True, msgBoxID = None, picon = None, simple = False, list = [], timeout_default = None):
        self.type = type
        self.session = session
        if DESKHEIGHT < 1000:
            skin = '/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/res/HD/pndMessageBox.xml'
        else:
            skin = '/usr/lib/enigma2/python/Plugins/Extensions/fReE_iPtV_pAnDa_SaT_tEaM/res/FullHD/pndMessageBoxFHD.xml'
        f = open(skin, 'r')
        self.skin = f.read()
        f.close()
        Screen.__init__(self, session)
        self.msgBoxID = msgBoxID
        self['version'] = Label(_('Versione %s') % Version)
        self['pndteam'] = Label('by tEaM dEvElOpEr pAnDa SaT\xae')
        self['text'] = Label(text)
        self['Text'] = StaticText(text)
        self['selectedChoice'] = StaticText()
        self.text = text
        self.close_on_any_key = close_on_any_key
        self.timeout_default = timeout_default
        self['ErrorPixmap'] = Pixmap()
        self['QuestionPixmap'] = Pixmap()
        self['InfoPixmap'] = Pixmap()
        self['WarningPixmap'] = Pixmap()
        self['title'] = Label(_('..:: pAnDaSAT MeSsAgE ::..'))
        self.timerRunning = False
        self.initTimeout(timeout)
        picon = picon or type
        if picon != self.TYPE_ERROR:
            self['ErrorPixmap'].hide()
        if picon != self.TYPE_YESNO:
            self['QuestionPixmap'].hide()
        if picon != self.TYPE_INFO:
            self['InfoPixmap'].hide()
        if picon != self.TYPE_WARNING:
            self['WarningPixmap'].hide()
        self.title = self.type < self.TYPE_MESSAGE and [_('Question'),
         _('Information'),
         _('Warning'),
         _('Error')][self.type] or _('Message')
        if type == self.TYPE_YESNO:
            if list:
                self.list = list
            elif default == True:
                self.list = [(_('Si'), True), (_('No'), False)]
            else:
                self.list = [(_('No'), False), (_('Si'), True)]
        else:
            self.list = []
        self['list'] = MenuList(self.list)
        if self.list:
            self['selectedChoice'].setText(self.list[0][0])
        else:
            self['list'].hide()
        if enable_input:
            self['actions'] = ActionMap(['MsgBoxActions', 'DirectionActions'], {'cancel': self.cancel,
             'ok': self.ok,
             'alwaysOK': self.alwaysOK,
             'up': self.up,
             'down': self.down,
             'left': self.left,
             'right': self.right,
             'upRepeated': self.up,
             'downRepeated': self.down,
             'leftRepeated': self.left,
             'rightRepeated': self.right}, -1)
        self.onLayoutFinish.append(self.layoutFinished)

    def layoutFinished(self):
        self.setTitle(self.title)

    def initTimeout(self, timeout):
        self.timeout = timeout
        if timeout > 0:
            self.timer = eTimer()
            try:
                self.timer.callback.append(self.timerTick)
            except:
                self.timer_conn = self.timer.timeout.connect(self.timerTick)

            self.onExecBegin.append(self.startTimer)
            self.origTitle = None
            if self.execing:
                self.timerTick()
            else:
                self.onShown.append(self.__onShown)
            self.timerRunning = True
        else:
            self.timerRunning = False
        return

    def __onShown(self):
        self.onShown.remove(self.__onShown)
        self.timerTick()

    def startTimer(self):
        self.timer.start(1000)

    def stopTimer(self):
        if self.timerRunning:
            del self.timer
            self.onExecBegin.remove(self.startTimer)
            self.setTitle(self.origTitle)
            self.timerRunning = False

    def timerTick(self):
        if self.execing:
            self.timeout -= 1
            if self.origTitle is None:
                self.origTitle = self.instance.getTitle()
            self.setTitle(self.origTitle + ' (' + str(self.timeout) + ')')
            if self.timeout == 0:
                self.timer.stop()
                self.timerRunning = False
                self.timeoutCallback()
        return

    def timeoutCallback(self):
        print 'Timeout!'
        if self.timeout_default is not None:
            self.close(self.timeout_default)
        else:
            self.ok()
        return

    def cancel(self):
        self.close(False)

    def ok(self):
        if self.list:
            self.close(self['list'].getCurrent()[1])
        else:
            self.close(True)

    def alwaysOK(self):
        self.close(True)

    def up(self):
        self.move(self['list'].instance.moveUp)

    def down(self):
        self.move(self['list'].instance.moveDown)

    def left(self):
        self.move(self['list'].instance.pageUp)

    def right(self):
        self.move(self['list'].instance.pageDown)

    def move(self, direction):
        if self.close_on_any_key:
            self.close(True)
        self['list'].instance.moveSelection(direction)
        if self.list:
            self['selectedChoice'].setText(self['list'].getCurrent()[0])
        self.stopTimer()

    def __repr__(self):
        return str(type(self)) + '(' + self.text + ')'


def main(session, **kwargs):
    session.open(ABOUT)


def main2(session, **kwargs):
    session.open(SELECTPLAY)


def main3(session, **kwargs):
    session.open(PICONS)


def mainmenu(session, **kwargs):
    main(session, **kwargs)


def cfgmain(menuid):
    if menuid == 'mainmenu':
        return [('Free Iptv pAnDaSat',
          main,
          'iPtV fReE fOr AlL',
          44)]
    else:
        return []

def Plugins(**kwargs):
    screenwidth = getDesktop(0).size().width()
    if screenwidth and screenwidth == 1920:
        icona = '%s/res/FullHD/logohd.png' % plugin_path
    else:
        icona = '%s/res/HD/logo.png' % plugin_path
    if screenwidth and screenwidth == 1920:
        iconaplayer = '%s/res/FullHD/playerhd.png' % plugin_path
    else:
        iconaplayer = '%s/res/HD/player.png' % plugin_path
    if screenwidth and screenwidth == 1920:
        iconapicons = '%s/res/FullHD/piconhd.png' % plugin_path
    else:
        iconapicons = '%s/res/HD/picon.png' % plugin_path
    extDescriptor = PluginDescriptor(name='Free Iptv pAnDaSat', description=_('Free Iptv pAnDaSat'), where=PluginDescriptor.WHERE_EXTENSIONSMENU, icon=icona, fnc=main)
    mainDescriptor = PluginDescriptor(name='Free Iptv pAnDaSat', description=_('Free Iptv pAnDaSat'), where=PluginDescriptor.WHERE_MENU, icon=icona, fnc=cfgmain)
    result = [PluginDescriptor(name='Free Iptv pAnDaSat', description=_('Free Iptv pAnDaSat'), where=[PluginDescriptor.WHERE_PLUGINMENU], icon=icona, fnc=main), PluginDescriptor(name='Free M3U PLAYER pAnDaSat', description='Free Player M3U Converter pAnDaSat', where=[PluginDescriptor.WHERE_PLUGINMENU], icon=iconaplayer, fnc=main2), PluginDescriptor(name='Free PICONS pAnDaSat', description='Free Picons pAnDaSat', where=[PluginDescriptor.WHERE_PLUGINMENU], icon=iconapicons, fnc=main3)]
    if config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.strtext.value:
        result.append(extDescriptor)
    if config.plugins.fReE_iPtV_pAnDa_SaT_tEaM.strtmain.value:
        result.append(mainDescriptor)
    return result
    
#######thanks all friend 
