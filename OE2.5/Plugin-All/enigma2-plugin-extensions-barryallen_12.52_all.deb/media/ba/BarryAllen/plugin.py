# -*- coding: utf-8 -*-
#
# Barry Allen by gutemine
#
# Plugin wrapper to speed up Startup
#
import os
from enigma import eConsoleAppContainer
from Screens.Screen import Screen
from Plugins.Plugin import PluginDescriptor
from Components.config import config
if os.path.exists("/var/lib/dpkg/status") and os.path.exists("/media/ba/BarryAllen/UserScripts.py"):
	import UserScripts

import gettext

barryallen_path = "/media/ba"
barryallen_plugindir="/usr/lib/enigma2/python/Plugins/Extensions/BarryAllen" 
barryallen_localedir="%s/locale" % barryallen_path

# add local language file            
ba_sp=config.osd.language.value.split("_")
ba_language = ba_sp[0]         
if os.path.exists("%s/%s" % (barryallen_localedir, ba_language)) == True:
   os.environ["LANGUAGE"] = ba_sp[1]
else:
   os.environ['LANGUAGE']='en'
   ba_language='en'
if ba_language == 'ar':
   ar="                                                                           "
   ar2=""
else:
   ar=""
   ar2=""
if os.path.exists("/media/ba/locale"):
   _=gettext.Catalog('barryallen', '/media/ba/locale', ba_sp).gettext

def main(session,**kwargs):
	if not os.path.exists("/media/ba/BarryAllen/BarryAllen.py"):
		if os.path.exists("/usr/lib/enigma2/python/Plugins/Bp"):
			print " [BARRYALLEN] checking for /media mount !"
			os.system("umount /media")
	if os.path.exists("/media/ba/BarryAllen/BarryAllen.py"):
		if not os.path.exists(barryallen_plugindir):
			os.sysmlink("/media/ba/BarryAllen/BarryAllen.py", barryallen_plugindir)
		if os.path.exists(barryallen_plugindir):
			from Plugins.Extensions.BarryAllen.BarryAllen import BarryAllenMain
			session.open(BarryAllenMain)
		else:
			print " [BARRYALLEN] Plugin not found, sorry!"
	else:
		print " [BARRYALLEN] Plugin not found, sorry!"

def autostart(reason, **kwargs):                                               
	if kwargs.has_key("session") and reason == 0:                               
		print "[BARRYALLEN] autostart"
	        session = kwargs["session"]                                             
		if os.path.exists("/media/ba/.baprotect") and os.path.exists("/.bainfo") and os.path.exists("/dev/mmcblk0"):
				os.remove("/dev/mmcblk0")
				os.symlink("/dev/null","/dev/mmcblk0")
		if os.path.exists("/etc/init.d/umountfs"):
			b=open("/etc/init.d/umountfs","r")
			inhalt=b.read()
			b.close()
			if inhalt.find("sync") is -1:       
				print "[BARRYALLEN] patching umountfs"
				inhalt=inhalt.replace(": exit 0","sync\n: exit 0")
				b=open("/etc/init.d/umountfs","w")
				b.write(inhalt)
				b.close()
		if not os.path.exists("/media/ba/BarryAllen/BarryAllen.py"):
			if os.path.exists("/usr/lib/enigma2/python/Plugins/Bp"):
				print " [BARRYALLEN] checking for /media mount !"
				os.system("umount /media")
		if os.path.exists("/var/lib/dpkg/status") and os.path.exists("/media/ba/BarryAllen/UserScripts.py"):
			print "[BARRYALLEN] UserScript autostart"
			# add UserSscripts auto start ...
	        	session.open(UserScripts.UserScriptsStartup)       
		else:
			print "[BARRYALLEN] UserScript NO autostart"

def sessionstart(reason, **kwargs):                                               
        if reason == 0 and "session" in kwargs:                                                        
		if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/WebInterface/WebChilds/Toplevel.py"):
			if os.path.exists("/media/ba/BarryAllen/BarryAllen.py"):
				if not os.path.exists(barryallen_plugindir):
					os.sysmlink("/media/ba/BarryAllen/BarryAllen.py", barryallen_plugindir)
                        	from Plugins.Extensions.WebInterface.WebChilds.Toplevel import addExternalChild
		        	from Plugins.Extensions.BarryAllen.BarryAllen import BarryAllen
                        	addExternalChild( ("barryallen", BarryAllen(), "Barry Allen", "1", True) )          
                else:                                                                                  
			print "[BARRYALLEN] Webif not found"

def Plugins(**kwargs):
	if os.path.exists("%s/BarryAllen.py" % barryallen_plugindir):
		return [PluginDescriptor(name="Barry Allen", description=ar+_("the second Flash"), where = PluginDescriptor.WHERE_PLUGINMENU, icon="barryallen.png", fnc=main),
			PluginDescriptor(name="Barry Allen", description=ar+_("the second Flash"), where = PluginDescriptor.WHERE_EXTENSIONSMENU, icon="g3icon_ba.png", fnc=main),
            		PluginDescriptor(where=PluginDescriptor.WHERE_SESSIONSTART, fnc=sessionstart, needsRestart=False),
            		PluginDescriptor(where=[PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART], fnc=autostart)]
	else:
		print "[BARRYALLEN] Plugin not found"
