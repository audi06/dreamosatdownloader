from Plugins.Plugin import PluginDescriptor
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Screens.Screen import Screen
from Screens.Console import Console
from Screens.MessageBox import MessageBox
import os

transmission_sh = "systemctl"
transmission_version = "2.92 (14714)"

class Transmission(Screen):
	skin = """
	<screen position="center,center" size="350,190" title="Transmission Menu" >
		<widget name="menu" position="10,10" size="350,190" scrollbarMode="showOnDemand" />
	</screen>"""
	
	def __init__(self, session, args=None):
		Screen.__init__(self, session)
		self.session = session
		self.menu = args
		list = []
		list.append((_("start transmission-daemon"), "start"))
		list.append((_("stop transmission-daemon"), "stop"))
		list.append((_("restart transmission-daemon"), "restart"))
		list.append((_("enable transmission autostart"), "enable"))
		list.append((_("disable transmission autostart"), "disable"))
		list.append((_("about Transmission plugin"), "about_transmission"))
		self["menu"] = MenuList(list)
		self["actions"] = ActionMap(["OkCancelActions"], {"ok": self.run, "cancel": self.close}, -1)
	
	def run(self):
		returnValue = self["menu"].l.getCurrentSelection()[1]
        	if returnValue is not None:
			if returnValue is "start":
				self.session.open(Console,_("start transmission"),["%s start transmission" % transmission_sh])
			elif returnValue is "stop":
				self.session.open(Console,_("stop transmission"),["%s stop transmission" % transmission_sh])
			elif returnValue is "restart":
				self.session.open(Console,_("restart transmission"),["%s restart transmission" % transmission_sh])
			elif returnValue is "enable":
				self.session.open(Console,_("enable transmission"),["%s enable transmission" % transmission_sh])
			elif returnValue is "disable":
				self.session.open(Console,_("disable transmission"),["%s disable transmission" % transmission_sh])
			elif returnValue is "about_transmission":
				title="Transmission version %s \ncompiled by pclin 2017\nplugin by pclin & mfgeg" % transmission_version
				self.session.open(MessageBox,("%s") % (title),  MessageBox.TYPE_INFO)
		
def main(session, **kwargs):
	session.open(Transmission)

def Plugins(path,**kwargs):
    return [PluginDescriptor(
        name=_("Transmission"), 
        description="Bittorrent client for Dreambox", 
        where = PluginDescriptor.WHERE_PLUGINMENU,icon="transmission.png",
        fnc = main
        ),
	PluginDescriptor(name=_("Transmission"), where = PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main)]
