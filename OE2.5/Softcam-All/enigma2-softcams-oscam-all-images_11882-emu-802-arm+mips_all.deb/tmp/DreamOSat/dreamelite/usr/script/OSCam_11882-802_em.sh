#!/bin/sh
#### "*******************************************"
#### "*          ..:: A U T H O R ::..          *"
#### "*             << Audi06_19 >>             *"
#### "*  ..:: https://dreamosat-forum.com ::..  *"
#### "*******************************************"

CAMNAME="OSCam_11882-802"
BINARY="OSCam_11882-802"

remove_tmp () {
	rm -rf  /tmp/*.info /tmp/cardinfo 
}

case "$1" in
	start)
	remove_tmp
	sleep 1
	  /usr/bin/OSCam_11882-802 --wait 60 --config-dir /etc/tuxbox/config --daemon --pidfile /tmp/oscam.pid --restart 2
	sleep 5
	;;
	stop)
	touch /tmp/OSCam_11882-802.kill
	sleep 3
	killall -9 OSCam_11882-802 2>/dev/null
	sleep 2
	remove_tmp
	;;
	*)
	$0 stop
	exit 1
	;;
esac

exit 0


