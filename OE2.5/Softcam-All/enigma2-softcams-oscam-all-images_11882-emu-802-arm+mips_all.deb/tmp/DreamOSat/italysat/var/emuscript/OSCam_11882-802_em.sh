#!/bin/sh
#### "*******************************************"
#### "*          ..:: A U T H O R ::..          *"
#### "*             << Audi06_19 >>             *"
#### "*  ..:: https://dreamosat-forum.com ::..  *"
#### "*******************************************"

CAMNAME="OSCam_11882-802"
BINARY="OSCam_11882-802"

remove_tmp () {
	rm -rf /tmp/ecm.info /tmp/pid.info /tmp/cardinfo /tmp/mg*
}

case "$1" in
	start)
	remove_tmp
	/var/bin/OSCam_11882-802 --wait 60 --config-dir /etc/tuxbox/config --daemon --pidfile /tmp/oscam.pid --restart 2
	sleep 3
	;;
	stop)
	killall -9 OSCam_11882-802
	remove_tmp
	sleep 2
	;;
	*)
	$0 stop
	exit 1
	;;
esac

exit 0
