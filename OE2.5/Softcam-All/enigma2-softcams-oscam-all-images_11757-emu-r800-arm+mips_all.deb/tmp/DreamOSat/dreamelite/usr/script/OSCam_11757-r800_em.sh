#!/bin/sh
#### "*******************************************"
#### "*          ..:: A U T H O R ::..          *"
#### "*             << Audi06_19 >>             *"
#### "*  ..:: https://dreamosat-forum.com ::..  *"
#### "*******************************************"

CAMNAME="OSCam_11757-r800"
BINARY="OSCam_11757-r800"

remove_tmp () {
	rm -rf  /tmp/*.info /tmp/cardinfo 
}

case "$1" in
	start)
	remove_tmp
	sleep 1
	/usr/bin/OSCam_11757-r800 &
	sleep 5
	;;
	stop)
	touch /tmp/OSCam_11757-r800.kill
	sleep 3
	killall -9 OSCam_11757-r800 2>/dev/null
	sleep 2
	remove_tmp
	;;
	*)
	$0 stop
	exit 1
	;;
esac

exit 0


