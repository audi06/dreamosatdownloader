#!/bin/sh
########################################
######      Edited by RAED        ######
########################################
###### by audi06_19
remove_tmp () {
	rm -rf /tmp/ecm.info /tmp/pid.info /tmp/cardinfo /tmp/mg* /tmp/ncam*
}

case "$1" in
	start)
	remove_tmp
	/var/bin/ncam &
	sleep 3
	;;
	stop)
	killall -9 ncam
	remove_tmp
	sleep 2
	;;
	*)
	$0 stop
	exit 1
	;;
esac

exit 0
