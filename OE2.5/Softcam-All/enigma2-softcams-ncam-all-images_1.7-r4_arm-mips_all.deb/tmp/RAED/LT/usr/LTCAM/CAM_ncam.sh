#!/bin/sh
########################################
######      Edited by RAED        ######
########################################
###### by audi06_19
CAMNAME="NCam 1.7-r4"

usage()
{
	echo "Usage: $0 {start|stop|restart|reload}"
}

if [ $# -lt 1 ] ; then usage ; break ; fi
action=$1

case "$action" in
start)
	echo "[SCRIPT] $1: $CAMNAME"
	/usr/bin/ncam -d -c /etc/tuxbox/config/ncam.conf &
	;;
stop)
	echo "[SCRIPT] $1: $CAMNAME"
	killall -9 ncam
	;;
restart|reload)
	$0 stop
	$0 start
	;;
*)
	usage
	;;
esac

exit 0
