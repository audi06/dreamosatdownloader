#!/bin/sh

rm -f /etc/init.d/softcam.Ncam > /dev/null 2>&1
rm -f /etc/init.d/cardserver.Ncam > /dev/null 2>&1
rm -f /usr/bin/list_smargo > /dev/null 2>&1
rm -f /usr/bin/ncam > /dev/null 2>&1
rm -f /usr/uninstall/hdf_Softcamncam_delfile_gz.sh
exit 0
