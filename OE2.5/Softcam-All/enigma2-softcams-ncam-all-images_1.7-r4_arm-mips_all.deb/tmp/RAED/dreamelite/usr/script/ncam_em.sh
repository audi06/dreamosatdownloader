#!/bin/sh
########################################
######      Edited by RAED        ######
########################################
###### by audi06_19
#emuname=NCam 1.7-r4
#ecminfofile=ecm.info

remove_tmp () {
	rm -rf /tmp/ecm.info /tmp/ecm0.info /tmp/pid.info /tmp/cardinfo /tmp/ncam*
}

case "$1" in
	start)
	remove_tmp
	sleep 1
	/usr/bin/ncam -d -c /etc/tuxbox/config/ncam.conf &
	sleep 5
	;;
	stop)
	touch /tmp/ncam.kill
	sleep 3
	killall -9 ncam 2>/dev/null
	sleep 2
	remove_tmp
	;;
	*)
	$0 stop
	exit 1
	;;
esac

exit 0


