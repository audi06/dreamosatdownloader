#!/bin/sh
#### "*******************************************"
#### "*          ..:: A U T H O R ::..          *"
#### "*             << Audi06_19 >>             *"
#### "*  ..:: https://dreamosat-forum.com ::..  *"
#### "*******************************************"

CAMNAME="OSCam_11814-802"
BINARY="OSCam_11814-802"

remove_tmp () {
  rm -rf /tmp/*.tmp* /tmp/*.info*
}

case "$1" in
  start)
  remove_tmp
  /usr/bin/OSCam_11814-802 &
  ;;
  stop)
  killall -9 OSCam_11814-802 2>/dev/null
  sleep 2
  remove_tmp
  ;;
  *)
  $0 stop
  exit 0
  ;;
esac

exit 0
