#!/bin/sh
#### "*******************************************"
#### "*          ..:: A U T H O R ::..          *"
#### "*             << Audi06_19 >>             *"
#### "*  ..:: https://dreamosat-forum.com ::..  *"
#### "*******************************************"

CAMNAME="OSCam_11.718-r798"
BINARY="OSCam_11.718-r798"

remove_tmp () {
	rm -rf  /tmp/*.info /tmp/cardinfo 
}

case "$1" in
	start)
	remove_tmp
	sleep 1
	/usr/bin/OSCam_11.718-r798 &
	sleep 5
	;;
	stop)
	touch /tmp/OSCam_11.718-r798.kill
	sleep 3
	killall -9 OSCam_11.718-r798 2>/dev/null
	sleep 2
	remove_tmp
	;;
	*)
	$0 stop
	exit 1
	;;
esac

exit 0


