#!/bin/sh
#### "*******************************************"
#### "*          ..:: A U T H O R ::..          *"
#### "*             << Audi06_19 >>             *"
#### "*  ..:: https://dreamosat-forum.com ::..  *"
#### "*******************************************"

CAMNAME="OSCam² modern 1531"
BINARY="oscam-mdrn"

remove_tmp () {
	rm -rf /tmp/cainfo.* /tmp/camd.* /tmp/sc.* /tmp/*.info* /tmp/*.tmp* /tmp/oscam*
	[ -e /tmp/.oscam ] && rm -rf /tmp/.oscam
	[ -e /tmp/.emu.info ] && rm -rf /tmp/.emu.info
	[ -e /tmp/oscam.mem ] && rm -rf /tmp/oscam.mem
}

case "$1" in
	start)
		echo "[SCRIPT] $1: $CAMNAME"
		remove_tmp
		touch /tmp/.emu.info
		echo $BINARY > /tmp/.emu.info
		/usr/bin/$BINARY -b -r 2 -c /etc/tuxbox/config
	;;
	stop)
		echo "[SCRIPT] $1: $CAMNAME"
		kill `pidof $BINARY`
		remove_tmp
	;;
	restart)
		$0 stop
		sleep 2
		$0 start
		exit
	;;
	*)
		$0 stop
		exit 0
	;;
esac

exit 0
