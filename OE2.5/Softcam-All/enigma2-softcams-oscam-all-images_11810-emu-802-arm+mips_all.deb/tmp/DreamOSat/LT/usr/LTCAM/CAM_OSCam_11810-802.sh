#!/bin/sh
#### "*******************************************"
#### "*          ..:: A U T H O R ::..          *"
#### "*             << Audi06_19 >>             *"
#### "*  ..:: https://dreamosat-forum.com ::..  *"
#### "*******************************************"

CAMNAME="OSCam_11810-802"
BINARY="OSCam_11810-802"

usage()
{
	echo "Usage: $0 {start|stop|restart|reload}"
}

if [ $# -lt 1 ] ; then usage ; break ; fi
action=$1

case "$action" in
start)
	echo "[SCRIPT] $1: $CAMNAME"
	/usr/bin/OSCam_11810-802 &
	;;
stop)
	echo "[SCRIPT] $1: $CAMNAME"
	killall -9 OSCam_11810-802
	;;
restart|reload)
	$0 stop
	$0 start
	;;
*)
	usage
	;;
esac

exit 0
