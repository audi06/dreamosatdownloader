#!/bin/sh
#### "*******************************************"
#### "*          ..:: A U T H O R ::..          *"
#### "*             << Audi06_19 >>             *"
#### "*  ..:: https://dreamosat-forum.com ::..  *"
#### "*******************************************"

CAMNAME="OSCam_11749-r800"
BINARY="OSCam_11749-r800"

remove_tmp () {
	rm -rf /tmp/ecm.info /tmp/pid.info /tmp/cardinfo /tmp/mg*
}

case "$1" in
	start)
	remove_tmp
	/var/bin/OSCam_11749-r800 &
	sleep 3
	;;
	stop)
	killall -9 OSCam_11749-r800
	remove_tmp
	sleep 2
	;;
	*)
	$0 stop
	exit 1
	;;
esac

exit 0
