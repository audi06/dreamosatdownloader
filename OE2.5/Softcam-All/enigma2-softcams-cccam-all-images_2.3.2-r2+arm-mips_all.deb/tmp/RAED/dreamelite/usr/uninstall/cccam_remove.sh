#!/bin/sh

########################################
######      Edited by RAED        ######
########################################

killall -9 ncam
sleep 5
rm -rf /usr/bin/CCcam_2.3.2
rm -rf /usr/script/CCcam_2.3.2_em.sh
rm -rf /usr/uninstall/cccam_remove.sh

exit 0
