#!/bin/sh
########################################
######      Edited by RAED        ######
########################################

/var/emuscript/ncam_em.sh stop

rm -rf /var/bin/CCcam_2.3.2
rm -rf /var/emuscript/CCcam_2.3.2_em.sh
rm -rf /var/uninstall/cccam_remove.sh

exit 0
