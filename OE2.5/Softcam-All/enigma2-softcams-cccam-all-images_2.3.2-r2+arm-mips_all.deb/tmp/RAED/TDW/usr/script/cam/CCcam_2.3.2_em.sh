#!/bin/sh
#### "*******************************************"
#### "*          ..:: A U T H O R ::..          *"
#### "*             << Audi06_19 >>             *"
#### "*  ..:: https://dreamosat-forum.com ::..  *"
#### "*******************************************"

#emuname=CCcam 2.3.2
#ecminfofile=ecm.info

remove_tmp () {
	rm -rf /tmp/ecm.info /tmp/ecm0.info /tmp/pid.info /tmp/cardinfo
}

case "$1" in
	start)
	remove_tmp
	sleep 1
	/usr/bin/CCcam_2.3.2 &
	sleep 3
	;;
	stop)
	touch /tmp/CCcam.kill
	sleep 3
	killall -9 CCcam_2.3.2 2>/dev/null
	sleep 2
	remove_tmp
	;;
	*)
	$0 stop
	exit 1
	;;
esac

exit 0
