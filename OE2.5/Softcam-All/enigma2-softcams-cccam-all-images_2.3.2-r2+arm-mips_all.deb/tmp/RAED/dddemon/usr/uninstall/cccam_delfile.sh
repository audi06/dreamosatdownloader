#!/bin/sh
########################################
######      Edited by RAED        ######
########################################
# Type: Cam

killall -9 ncam 2>/dev/null
sleep 2
remove_tmp

rm -rf /usr/bin/CCcam_2.3.2
rm -rf /usr/script/CCcam_2.3.2_em.sh
rm -rf /usr/uninstall/cccam_delfile.sh

exit 0

