#!/bin/sh
#### "*******************************************"
#### "*          ..:: A U T H O R ::..          *"
#### "*             << Audi06_19 >>             *"
#### "*  ..:: https://dreamosat-forum.com ::..  *"
#### "*******************************************"

CAMNAME="GCam² 2.1-r0"
BINARY="gcam"

usage()
{
	echo "Usage: $0 {start|stop|status|restart|reload}"
}

if [ $# -lt 1 ] ; then usage ; break ; fi
action=$1

case "$action" in

start)
	echo -n "Start cam daemon: $BINARY"
	/usr/bin/$BINARY
	echo " $BINARY."
		;;

stop)
	echo -n "Stopping cam daemon: $BINARY"
	while [ -n "`pidof $BINARY`" ] ; do
		kill -9 `pidof $BINARY`
	done
	rm -f /tmp/*.info /tmp/camd.socket /tmp/*.list /tmp/*.pid
	echo "."
	;;

status)
	;;

restart|reload)
	$0 stop
	sleep 2
	$0 start
	;;
*)
	usage
	;;
esac

exit 0
