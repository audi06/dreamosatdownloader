#!/bin/sh
#### "*******************************************"
#### "*          ..:: A U T H O R ::..          *"
#### "*             << Audi06_19 >>             *"
#### "*  ..:: https://dreamosat-forum.com ::..  *"
#### "*******************************************"

CAMNAME="OSCam_11846-802"
BINARY="OSCam_11846-802"

remove_tmp () {
  rm -rf /tmp/*.tmp* /tmp/*.info*
}

case "$1" in
  start)
  remove_tmp
    /usr/bin/OSCam_11846-802 --wait 60 --config-dir /etc/tuxbox/config --daemon --pidfile /tmp/oscam.pid --restart 2
  ;;
  stop)
  killall -9 OSCam_11846-802 2>/dev/null
  sleep 2
  remove_tmp
  ;;
  *)
  $0 stop
  exit 0
  ;;
esac

exit 0
