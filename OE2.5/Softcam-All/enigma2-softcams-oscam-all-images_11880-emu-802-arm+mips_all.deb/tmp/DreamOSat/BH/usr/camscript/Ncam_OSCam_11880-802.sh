#!/bin/sh
#### "*******************************************"
#### "*          ..:: A U T H O R ::..          *"
#### "*             << Audi06_19 >>             *"
#### "*  ..:: https://dreamosat-forum.com ::..  *"
#### "*******************************************"

CAMNAME="OSCam_11880-802"
BINARY="OSCam_11880-802"

remove_tmp () {
  rm -rf /tmp/*.info* /tmp/*.tmp* /tmp/*share* /tmp/*.pid* /tmp/*sbox*
}

case "$1" in
  start)
  echo "[SCRIPT] $1: $CAMNAME"
  remove_tmp
  touch /tmp/.emu.info
  echo OSCam_11880-802 > /tmp/.emu.info
  /usr/bin/OSCam_11880-802 --wait 60 --config-dir /etc/tuxbox/config --daemon --pidfile /tmp/oscam.pid --restart 2
  ;;
  stop)
  echo "[SCRIPT] $1: $CAMNAME"
  killall -9 OSCam_11880-802  2>/dev/null
  remove_tmp
  ;;
  restart)
  $0 stop
  sleep 2
  $0 start
  exit
  ;;
  *)
  $0 stop
  exit 0
  ;;
esac

exit 0
