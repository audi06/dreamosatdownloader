#!/bin/sh
#### "*******************************************"
#### "*          ..:: A U T H O R ::..          *"
#### "*             << Audi06_19 >>             *"
#### "*  ..:: https://dreamosat-forum.com ::..  *"
#### "*******************************************"

NAME="OSCam_11958-802"
BINARY="OSCam_11958-802"

remove_tmp () {
    rm -rf /tmp/*cam* /tmp/camd.socket /tmp/pid.info /tmp/ecm*.info /tmp/cardinfo /tmp/*cam*.pid /tmp/cam.kill
}

case "$1" in
    start)
        echo "[SCRIPT] $1: $NAME"
        remove_tmp
        sleep 1
        /usr/bin/OSCam_11958-802 --wait 60 --config-dir /etc/tuxbox/config --daemon --pidfile /tmp/oscam.pid --restart 2
        sleep 1
        pidof $BINARY > /tmp/$BINARY.pid
        ;;
    stop)
        echo "[SCRIPT] $1: $NAME"
        kill 2>/dev/null `cat 2>/dev/null /tmp/$BINARY.pid`
        sleep 1
        killall -9 $BINARY 2>/dev/null
        remove_tmp
        ;;
    *)
        $0 stop
        exit 1
        ;;
esac

exit 0
