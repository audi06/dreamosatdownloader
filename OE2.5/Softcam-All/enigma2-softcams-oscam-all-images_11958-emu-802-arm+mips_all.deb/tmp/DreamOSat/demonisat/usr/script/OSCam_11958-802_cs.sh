#!/bin/sh
#### "*******************************************"
#### "*          ..:: A U T H O R ::..          *"
#### "*             << Audi06_19 >>             *"
#### "*  ..:: https://dreamosat-forum.com ::..  *"
#### "*******************************************"

CAMNAME="OSCam_11958-802"
BINARY="OSCam_11958-802"
#emuname=OScam
#ecminfofile=ecm.info

remove_tmp ()
{
 [ -e /tmp/ecm.info ] && rm -rf /tmp/ecm.info
 [ -e /tmp/.emu.info ] && rm -rf /tmp/.emu.info
 }

case "$1" in
	start)
	remove_tmp
		systemctl stop dccamd
	sleep 2	
		systemctl disable dccamd
	sleep 2
		systemctl start emu-${BINARY}.service
	sleep 2
		systemctl enable emu-${BINARY}.service
	sleep 2
	;;
	stop)
		remove_tmp
		systemctl stop emu-${BINARY}.service
	sleep 2
		systemctl disable emu-${BINARY}.service
	sleep 2
	;;
	restart|reload)
	$0 stop
	sleep 3
	$0 start
     ;;
	*)
		$0 stop
		exit 1
	;;
esac
exit 0

