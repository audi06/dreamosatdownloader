#!/bin/sh
########################################
######     Powered by RAED        ######
########################################
###### by audi06_19

CAMNAME="OSCam Modern emu 1528"


remove_tmp () {
  rm -rf /tmp/cainfo.* /tmp/camd.* /tmp/sc.* /tmp/*.info* /tmp/*.tmp*
        [ -e /tmp/.emu.info ] && rm -rf /tmp/.emu.info
        [ -e /tmp/oscammodern.mem ] && rm -rf /tmp/oscammodern.mem
        [ -e /tmp/oscammodern.mem ] && rm -rf /tmp/oscammodern.mem
}

case "$1" in
  start)
  echo "[SCRIPT] $1: $CAMNAME"
  remove_tmp
  touch /tmp/.emu.info
  echo $CAMNAME > /tmp/.emu.info
  /usr/bin/oscammodern &
  ;;
  stop)
  echo "[SCRIPT] $1: $CAMNAME"
  kill `pidof oscammodern`
  remove_tmp
  ;;
  restart)
  $0 stop
  sleep 2
  $0 start
  exit
  ;;
  *)
  $0 stop
  exit 0
  ;;
esac

exit 0
