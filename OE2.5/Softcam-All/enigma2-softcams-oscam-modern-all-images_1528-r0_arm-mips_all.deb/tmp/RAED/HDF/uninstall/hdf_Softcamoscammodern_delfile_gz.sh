#!/bin/sh

rm -f /etc/init.d/softcam.oscammodern_emu > /dev/null 2>&1
rm -f /etc/init.d/cardserver.oscammodern > /dev/null 2>&1
rm -f /usr/bin/list_smargo > /dev/null 2>&1
rm -f /usr/bin/oscammodern > /dev/null 2>&1
rm -f /usr/uninstall/hdf_Softcamoscammodern_delfile_gz.sh
exit 0
