#!/bin/sh

########################################
######      Edited by RAED        ######
########################################
###### by audi06_19

OSD="OSCam Modern emu 1528"
PID=`pidof oscammodern`
Action=$1

cam_clean () {
		rm -rf /tmp/*.info*	/tmp/*.tmp*
}

cam_handle () {
		if test	-z "${PID}"	; then
				cam_up;
		else
				cam_down;
		fi;
}

cam_down ()	{
		killall	oscammodern
		sleep 2
		cam_clean
}

cam_up () {
		/usr/bin/cam/oscammodern -c  /etc/tuxbox/config/oscam.conf &
}

if test	"$Action" =	"cam_res" ;	then
		cam_down
		cam_up
elif test "$Action"	= "cam_down" ; then
		cam_down
elif test "$Action"	= "cam_up" ; then
		cam_up
else
		cam_handle
fi

exit 0
