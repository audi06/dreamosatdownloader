#!/bin/sh
########################################
######      Edited by RAED        ######
########################################
###### by audi06_19
remove_tmp () {
	rm -rf /tmp/ecm.info /tmp/pid.info /tmp/cardinfo /tmp/mg* /tmp/oscammodern*
}

case "$1" in
	start)
	remove_tmp
	/var/bin/oscammodern &
	sleep 3
	;;
	stop)
	killall -9 oscammodern
	remove_tmp
	sleep 2
	;;
	*)
	$0 stop
	exit 1
	;;
esac

exit 0
