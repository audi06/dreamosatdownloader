#!/bin/sh
########################################
######      Edited by RAED        ######
########################################

/var/emuscript/oscammodern_em.sh stop

rm -rf /var/bin/oscammodern
rm -rf /var/emuscript/oscammodern_em.sh
rm -rf /var/uninstall/oscammodern_remove.sh

exit 0
