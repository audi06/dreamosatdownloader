#!/bin/sh
#profile for oscammodern

usage()
{
	echo "Usage: $0 {start|stop|status|restart|reload}"
}

if [ $# -lt 1 ] ; then usage ; break ; fi
action=$1

case "$action" in

start)
	echo -n "Start cam daemon: oscammodern"
	/usr/bin/oscammodern
	echo " oscammodern."
		;;

stop)
	echo -n "Stopping cam daemon: oscammodern"
	while [ -n "`pidof oscammodern`" ] ; do
		kill -9 `pidof oscammodern`
	done
	rm -f /tmp/*.info /tmp/camd.socket /tmp/*.list /tmp/*.pid
	echo "."
	;;

status)
	;;

restart|reload)
	$0 stop
	sleep 2
	$0 start
	;;

*)
	usage
	;;

esac

exit 0
