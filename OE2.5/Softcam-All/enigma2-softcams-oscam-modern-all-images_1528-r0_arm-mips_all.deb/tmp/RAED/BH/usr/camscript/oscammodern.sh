#!/bin/sh
###### by audi06_19
CAMNAME="Oscam Modern emu 1528"

remove_tmp () {
  rm -rf /tmp/*.info* /tmp/*.tmp* /tmp/.oscammodern /tmp/*share* /tmp/*.pid* /tmp/*sbox* /tmp/oscammodern.* /tmp/*.oscammodern
}

case "$1" in
  start)
  echo "[SCRIPT] $1: $CAMNAME"
  remove_tmp
  touch /tmp/.emu.info
  echo oscammodern > /tmp/.emu.info
  /usr/bin/oscammodern &
  ;;
  stop)
  echo "[SCRIPT] $1: $CAMNAME"
  killall -9 oscammodern  2>/dev/null
  remove_tmp
  ;;
  restart)
  $0 stop
  sleep 2
  $0 start
  exit
  ;;
  *)
  $0 stop
  exit 0
  ;;
esac

exit 0
