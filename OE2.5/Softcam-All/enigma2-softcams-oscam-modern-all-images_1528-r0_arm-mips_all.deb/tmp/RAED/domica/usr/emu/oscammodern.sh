#!/bin/sh
###### by audi06_19
# DOMICA image
remove_tmp () {
  rm -rf /tmp/*.tmp* /tmp/*.info*
}

case "$1" in
  start)
  remove_tmp
  /usr/bin/oscammodern &
  ;;
  stop)
  killall -9 oscammodern 2>/dev/null
  sleep 2
  remove_tmp
  ;;
  *)
  $0 stop
  exit 0
  ;;
esac

exit 0
