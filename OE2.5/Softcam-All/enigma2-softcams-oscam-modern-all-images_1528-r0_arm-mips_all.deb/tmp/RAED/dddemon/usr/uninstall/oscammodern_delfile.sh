#!/bin/sh
########################################
######      Edited by RAED        ######
########################################
# Type: Cam

killall -9 oscammodern 2>/dev/null
sleep 2
remove_tmp

rm -rf /usr/bin/oscammodern
rm -rf /usr/script/oscammodern_cam.sh
rm -rf /usr/uninstall/oscammodern_delfile.sh

exit 0

