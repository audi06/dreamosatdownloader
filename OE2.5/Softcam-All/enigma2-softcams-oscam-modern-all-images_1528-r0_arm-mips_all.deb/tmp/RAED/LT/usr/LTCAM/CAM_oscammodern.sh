#!/bin/sh
########################################
######      Edited by RAED        ######
########################################
###### by audi06_19
CAMNAME="OSCam Modern emu 1528"

usage()
{
	echo "Usage: $0 {start|stop|restart|reload}"
}

if [ $# -lt 1 ] ; then usage ; break ; fi
action=$1

case "$action" in
start)
	echo "[SCRIPT] $1: $CAMNAME"
	/usr/bin/oscammodern -d -c /etc/tuxbox/config/oscam.conf &
	;;
stop)
	echo "[SCRIPT] $1: $CAMNAME"
	killall -9 oscammodern
	;;
restart|reload)
	$0 stop
	$0 start
	;;
*)
	usage
	;;
esac

exit 0
