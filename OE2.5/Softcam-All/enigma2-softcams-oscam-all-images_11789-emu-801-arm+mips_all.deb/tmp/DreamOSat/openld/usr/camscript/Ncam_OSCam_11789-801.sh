#!/bin/sh
#### "*******************************************"
#### "*          ..:: A U T H O R ::..          *"
#### "*             << Audi06_19 >>             *"
#### "*  ..:: https://dreamosat-forum.com ::..  *"
#### "*******************************************"

CAMNAME="OSCam_11789-801"
BINARY="OSCam_11789-801"

remove_tmp () {
    rm -rf /tmp/*.info* /tmp/*.tmp*
}

echo "[SCRIPT] $1: $CAMNAME"

start_cam () { 
    remove_tmp
    sleep 2
    /usr/bin/$BINARY &
}

echo "[SCRIPT] $1: $CAMNAME"

stop_cam () {
    remove_tmp
    killall -9 $BINARY 2>/dev/null
}
case "$1" in  
    start) 
        start_cam 
        ;; 
    stop) 
        stop_cam 
        ;; 
    restart) 
        $0 stop 
        $0 start 
        ;; 
    *)
    esac
exit 0

