#!/bin/sh
#### "*******************************************"
#### "*          ..:: A U T H O R ::..          *"
#### "*             << Audi06_19 >>             *"
#### "*  ..:: https://dreamosat-forum.com ::..  *"
#### "*******************************************"

CAMNAME="OSCam² 11.426"
BINARY="oscam"


remove_tmp () {
	rm -rf  /tmp/*.info /tmp/cardinfo 
}

case "$1" in
	start)
	remove_tmp
	sleep 1
	/usr/bin/$BINARY -d -c /etc/tuxbox/config/ &
	sleep 5
	;;
	stop)
	touch /tmp/$BINARY.kill
	sleep 3
	killall -9 $BINARY 2>/dev/null
	sleep 2
	remove_tmp
	;;
	*)
	$0 stop
	exit 1
	;;
esac

exit 0


