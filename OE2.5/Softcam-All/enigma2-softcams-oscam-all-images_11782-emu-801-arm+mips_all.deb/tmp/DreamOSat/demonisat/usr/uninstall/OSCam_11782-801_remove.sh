#!/bin/sh
#### "*******************************************"
#### "*          ..:: A U T H O R ::..          *"
#### "*             << Audi06_19 >>             *"
#### "*  ..:: https://dreamosat-forum.com ::..  *"
#### "*******************************************"

CAMNAME="OSCam_11782-801"
BINARY="OSCam_11782-801"

/usr/script/${BINARY}_cs.sh stop
sleep 5

rm -rf /usr/bin/${BINARY} > /dev/null 2>&1
rm -rf /usr/script/${BINARY}_cs.sh > /dev/null 2>&1
rm -rf /usr/uninstall/${BINARY}_remove.sh > /dev/null 2>&1
rm -rf /lib/systemd/system/emu-${BINARY}.service > /dev/null 2>&1
dpkg --remove enigma2-softcams-oscam-all-images
exit 0

