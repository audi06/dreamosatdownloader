#!/bin/sh
#### "*******************************************"
#### "*          ..:: A U T H O R ::..          *"
#### "*             << Audi06_19 >>             *"
#### "*  ..:: https://dreamosat-forum.com ::..  *"
#### "*******************************************"

CAMNAME="OSCam_11811-802"
BINARY="OSCam_11811-802"

remove_tmp () {
	rm -rf /tmp/cainfo.* /tmp/camd.* /tmp/sc.* /tmp/*.info* /tmp/*.tmp*
	[ -e /tmp/.emu.info ] && rm -rf /tmp/.emu.info
}

case "$1" in
	start)
		echo "[SCRIPT] $1: $CAMNAME"
		remove_tmp
		touch /tmp/.emu.info
		echo $BINARY > /tmp/.emu.info
		/usr/bin/$BINARY &
	;;
	stop)
		echo "[SCRIPT] $1: $CAMNAME"
		kill `pidof $BINARY`
		remove_tmp
	;;
	restart)
		$0 stop
		sleep 2
		$0 start
		exit
	;;
	*)
		$0 stop
		exit 0
	;;
esac

exit 0
