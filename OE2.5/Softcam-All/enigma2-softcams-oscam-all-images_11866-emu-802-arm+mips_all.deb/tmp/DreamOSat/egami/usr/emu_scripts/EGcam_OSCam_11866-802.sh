#!/bin/sh
#### "*******************************************"
#### "*          ..:: A U T H O R ::..          *"
#### "*             << Audi06_19 >>             *"
#### "*  ..:: https://dreamosat-forum.com ::..  *"
#### "*******************************************"

CAMNAME="OSCam_11866-802"
BINARY="OSCam_11866-802"

remove_tmp () {
	rm -rf /tmp/*.info* /tmp/*.tmp*
}

case "$1" in
	start)
	echo "[SCRIPT] $1: $CAMNAME"
	remove_tmp
	  /usr/bin/OSCam_11866-802 --wait 60 --config-dir /etc/tuxbox/config --daemon --pidfile /tmp/oscam.pid --restart 2
	;;
	stop)
	echo "[SCRIPT] $1: $CAMNAME"
	killall -9 OSCam_11866-802 2>/dev/null
	sleep 1
	remove_tmp
	;;
	*)
	$0 stop
	exit 0
	;;
esac

exit 0








