#!/bin/sh
#### "*******************************************"
#### "*          ..:: A U T H O R ::..          *"
#### "*             << Audi06_19 >>             *"
#### "*  ..:: https://dreamosat-forum.com ::..  *"
#### "*******************************************"

CAMNAME="OSCam_11759-r801"
BINARY="OSCam_11759-r801"

remove_tmp () {
	rm -rf /tmp/*.info* /tmp/*.tmp*
}

case "$1" in
	start)
	echo "[SCRIPT] $1: $CAMNAME"
	remove_tmp
	/usr/bin/OSCam_11759-r801 &
	;;
	stop)
	echo "[SCRIPT] $1: $CAMNAME"
	killall -9 OSCam_11759-r801 2>/dev/null
	sleep 1
	remove_tmp
	;;
	*)
	$0 stop
	exit 0
	;;
esac

exit 0








