#!/bin/sh
#### "*******************************************"
#### "*          ..:: A U T H O R ::..          *"
#### "*             << Audi06_19 >>             *"
#### "*  ..:: https://dreamosat-forum.com ::..  *"
#### "*******************************************"

OSD="OSCam² mdrn 1535"
CAM="OSCam-mdrn_1535"
PID=`pidof $CAM`
Action=$1

cam_clean () {
        [ -e /tmp/ecm.info ] && rm -rf /tmp/ecm.info
        [ -e /tmp/ecm0.info ] && rm -rf /tmp/ecm0.info
        [ -e /tmp/ecm1.info ] && rm -rf /tmp/ecm1.info
        [ -e /tmp/.oscam ] && rm -rf /tmp/.oscam
        [ -e /tmp/oscam.log ] && rm -rf /tmp/oscam.log
	[ -e /tmp/oscamuser.log ] && rm -rf /tmp/oscamuser.log
        [ -e /tmp/oscam.pid ] && rm -rf /tmp/oscam.pid
}

cam_handle () {
		if test	-z "${PID}"; then
				cam_up;
		else
				cam_down;
		fi;
}

cam_down ()	{
		killall	-9 ${CAM} 2>/dev/null
		sleep 2
		cam_clean
}

cam_up () {
		if [ -f /etc/tuxbox/config/oscam.conf ]; then
                	/usr/bin/${CAM} -c /etc/tuxbox/config > /dev/null 2>&1 &
		elif [ -f /usr/keys/oscam.conf ]; then
                	/usr/bin/${CAM} -c /usr/keys > /dev/null 2>&1 &
		else
                	/usr/bin/${CAM} > /dev/null 2>&1 &
		fi
}

if test	"$Action" =	"cam_startup" ;	then
	if test	-z "${PID}" ; then
		cam_down
		cam_up
	else
		echo "$CAM already running, exiting..."
	fi
elif test	"$Action" =	"cam_res" ;	then
		cam_down
		cam_up
elif test "$Action"	= "cam_down" ; then
		cam_down
elif test "$Action"	= "cam_up" ; then
		cam_up
else
		cam_handle
fi

exit 0
