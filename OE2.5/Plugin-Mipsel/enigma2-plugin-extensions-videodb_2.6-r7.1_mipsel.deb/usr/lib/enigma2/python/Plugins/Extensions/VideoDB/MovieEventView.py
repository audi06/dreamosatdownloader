# -*- coding: utf-8 -*-
#
# VideoDB E2
#
# Coded by Dr.Best (c) 2013
# Support: www.dreambox-tools.info
# E-Mail: dr.best@dreambox-tools.info
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Multimedia GmbH.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Multimedia GmbH.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Multimedia GmbH.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.
#

from Screens.Screen import Screen
from DatabaseFunctions import getTMDbWriters, getTMDbActors, getTMDbDirectors
from DatabaseConnection import ClientID, OpenDatabase
from Tools.FuzzyDate import FuzzyTime
from enigma import getDesktop
from Components.Label import Label
from Components.ScrollLabel import ScrollLabel
from Components.ActionMap import ActionMap
from Components.Sources.StaticText import StaticText
from Components.Pixmap import MultiPixmap
from enigma import ePoint, eSize
from os import path as os_path

from enigma import ePicLoad, eRect, eServiceReference, gRGB
from Components.AVSwitch import AVSwitch
from Components.Pixmap import Pixmap
import servicevideodb
DEFAULT_WALLPAPER = "/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/default_wallpaper"

# for localized messages
from . import _

def getScale():
	return AVSwitch().getFramebufferScale()

class MoviePosterResize(Pixmap):
	def __init__(self, scale_width, scale_height, sc):
		Pixmap.__init__(self)
		self._scaleSize = eSize(scale_width, scale_height)
		self._aspectRatio = eSize(sc[0], sc[1])
		
	def setParam(self, scaleSize):
		self._scaleSize = scaleSize
		
	def updatePoster(self, ptr):
		if ptr is not None:
			pic_scale_size = ptr.size().scale(self._scaleSize, self._aspectRatio)
			if pic_scale_size.isValid():
				pic_scale_width = pic_scale_size.width()
				pic_scale_height = pic_scale_size.height()
				dest_rect = eRect(0, 0, pic_scale_width, pic_scale_height)
				self.instance.setScale(1)
				self.instance.setScaleDest(dest_rect)
			else:
				self.instance.setScale(0)
			self.instance.setPixmap(ptr)
		else:
			self.instance.setPixmap(None)




class MovieEventView(Screen):
	skin = """
		<screen name="MovieEventView" position="0,0" size="1280,720" flags="wfNoBorder" title="Movie Info" >
			<eLabel backgroundColor="#55000000" position="0,0" size="1280,720" zPosition="-1" />
			<widget name="poster" zPosition="5" position="50,100" size="240,356" />
			<widget name="headertext" position="320,40" size="900,60" font="Regular;28" valign="center" zPosition="1" foregroundColor="#00fcc000" transparent="0"  backgroundColor="#55000000" />
			<widget name="overview" position="320,100" size="900,356" zPosition="5" font="Regular;24" transparent="0"  backgroundColor="#55000000" />
			<widget name="misc" position="50,480" size="1170,130" zPosition="2" font="Regular;22" transparent="0"  backgroundColor="#55000000" />
			<eLabel backgroundColor="#44444a" position="50,650" size="1180,2" zPosition="5" />
			<widget name="datetime" font="Regular;20"  position="60,657" size="300,24" zPosition="5" transparent="0"  backgroundColor="#55000000"/>
			<widget name="duration" font="Regular;20" position="440,657" size="200,24" zPosition="5" transparent="0"  backgroundColor="#55000000"/>
			<widget name="channel" font="Regular;20" position="745,657" size="475,24" zPosition="5" halign="right" transparent="0"  backgroundColor="#55000000"/>
			<widget name="audio_icons" pixmaps="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/dts1.png,/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/ac3.png,/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/stereo.png" position="50,610" size="85,30" transparent="0" alphatest="blend" zPosition="3"/>
			<widget name="definition" pixmaps="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/hd.png,/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/sd.png" position="145,610" size="51,30" transparent="0" alphatest="blend" zPosition="3"/>
			<widget name="resolution" pixmaps="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/wide.png,/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/4_3.png" position="201,610" size="51,30" transparent="0" alphatest="blend" zPosition="3"/>
			<widget name="res" position="260,610" size="130,30" zPosition="4" font="Regular;20" halign="center" valign="center" transparent="0"  foregroundColor="#d8a710" backgroundColor="#55000000"/>
			<widget name="framerate" position="400,610" size="190,30" zPosition="3" font="Regular;20" halign="center" valign="center" transparent="0" foregroundColor="#d8a710" backgroundColor="#55000000" />
			<widget name="codec" position="590,610" size="150,30" zPosition="3" font="Regular;20" halign="center" valign="center" transparent="0" foregroundColor="#d8a710" backgroundColor="#55000000" />
			<widget name="col_widget" position="0,456" size="1280,264" transparent="0"  foregroundColor="#bcbbbb" backgroundColor="#55000000" zPosition="8" />
		</screen>"""


	def __init__(self, session, dbData, callback = None):
		Screen.__init__(self, session)
		self.cbFunc = callback
		self.dbData = dbData
		self.sc = getScale()
		self.picload = ePicLoad()
		params = (240,356, self.sc[0], self.sc[1], True, 2, "#00000000")
		self.picload.setPara(params)
		self["key_red"] = StaticText(_("Close"))
		self["key_green"] = StaticText("")
		self["key_yellow"] = StaticText("")
		self["key_blue"] = StaticText("")
		self["poster"] = MoviePosterResize(240, 356, self.sc) 
		self["overview"] = ScrollLabel()
		self["datetime"] = Label()
		self["duration"] = Label()
		self["channel"] = Label()
		self["misc"] = Label()
		self["headertext"] = Label()

		self["audio_icons"] = MultiPixmap()
		self["definition"] = MultiPixmap()
		self["resolution"] = MultiPixmap() 
		self["framerate"] = Label("")
		self["codec"] = Label("")
		self["res"] = Label("")
		
		self["col_widget"] = Label("")


		self["actions"] = ActionMap(["WizardActions", "DirectionActions", "ColorActions", "EPGSelectActions", "InfobarActions"],
		{
			"ok": self.closeScreen,
			"back": self.closeScreen,
			"red": self.closeScreen,
			"upUp": self.pageUp,
			"downUp": self.pageDown,
			"left": self.prevEvent,
			"right": self.nextEvent,
		}, -1)
		
		#self["actionsMenu"] = ActionMap(["MovieSelectionActions", "OkCancelActions", "ColorActions", "InfobarActions"],
		self["actionsInfo"] = ActionMap(["MovieSelectionActions"],
		{
			"showEventInfo": self.showEventInfoPressed,
		}, -1)
		self.onLayoutFinish.append(self.showData)
		self.isTMDbData = 0
		self.fileinfo_description_mode = False
		
	def showEventInfoPressed(self):
		if self.dbData.has_key("col_count") and self.dbData["col_count"] > 1: return
		self.fileinfo_description_mode = not self.fileinfo_description_mode
		if self.fileinfo_description_mode:
			self["misc"].hide()
			self["overview"].hide()
			if not (self.dbData.has_key("col_count") and self.dbData["col_count"] > 1):
				
				connection = OpenDatabase(dictFactory = True)
				if connection is not None:
					cursor = connection.cursor()
					cursor.execute("SELECT movies.movie_id, movies.filename, movies.filesize, paths.path, mountpoints.mountpoint, movies.path_id FROM Movies INNER JOIN Paths ON movies.path_id = paths.path_id INNER JOIN mountpoints on Paths.link_id = Mountpoints.link_id WHERE mountpoints.client_id = %d and movies.movie_id = %d;" % (  ClientID.instance.getClientID(), self.dbData["movie_id"]))
					row = cursor.fetchone()
					if row:
						path = os_path.join(row["mountpoint"],row["path"])
						text = _("Filename: ") + row["filename"] + "\n"
						text += _("Path: ") + path + "\n"
						text += _("Filesize: ") + str(row["filesize"]) + "\n\n"
						text += _("Movie ID: ") + str(row["movie_id"]) + "\n"
						text += _("Path ID: ") + str(row["path_id"]) + "\n"
						self["overview"].setText(text)
					else:
						self["overview"].setText(_("Weird...no data found..."))
					cursor.close()  
					connection.close()
					self["overview"].show()
		else:
			self.showData()
		
	def showData(self):
		self.fileinfo_description_mode = False
		if self.dbData.has_key("col_count") and self.dbData["col_count"] > 1:
			self["col_widget"].show()
			self["headertext"].setText(self.dbData["Movie_Collections_name"])
			if self.dbData["Movie_Collections_overview"] is not None and self.dbData["Movie_Collections_overview"] != "None":
				overview = self.dbData["Movie_Collections_overview"]
			else:
				overview = ""
			self["overview"].setText(overview)
			filename = ""
			if self.dbData["Movie_Collections_wallpaper"]:
				filename = os_path.join(ClientID.instance.getImagePath(), self.dbData["Movie_Collections_wallpaper"])
			if filename != "" and os_path.exists(filename):
				ref = eServiceReference(0x1013, 0, filename)
			else:
				ref = eServiceReference(0x1013, 0, DEFAULT_WALLPAPER)
			service = self.session.nav.getCurrentlyPlayingServiceReference()
			if service is None or service.type == 0x1013:
				self.instance.setBackgroundColor(gRGB(0xff000000))
				self.session.nav.playService(ref)
			if self.dbData["Movie_Collections_cover_filename"]:
				filename = os_path.join(ClientID.instance.getImagePath(), self.dbData["Movie_Collections_cover_filename"] )
				self.picload.startDecode(filename,False)
				ptr = self.picload.getData()
				self["poster"].updatePoster(ptr)
			return
		self["col_widget"].hide()
		filename = ""
		if self.dbData["wallpaper"]:
			filename = os_path.join(ClientID.instance.getImagePath(), self.dbData["wallpaper"])
		if filename != "" and os_path.exists(filename):
			ref = eServiceReference(0x1013, 0, filename)
		else:
			ref = eServiceReference(0x1013, 0, DEFAULT_WALLPAPER)
		service = self.session.nav.getCurrentlyPlayingServiceReference()
		if service is None or service.type == 0x1013:
			self.instance.setBackgroundColor(gRGB(0xff000000))
			self.session.nav.playService(ref)
		if self.dbData["dts"] == 1:
			self["audio_icons"].setPixmapNum(0)
		elif self.dbData["ac3"] == 1:
			self["audio_icons"].setPixmapNum(1)
		elif self.dbData["stereo"] == 1:
			self["audio_icons"].setPixmapNum(2)
		if self.dbData["dts"] or self.dbData["ac3"] or self.dbData["stereo"]:
			self["audio_icons"].show()
		else:
			self["audio_icons"].hide()
		if self.dbData["hd"] == 1:
			self["definition"].setPixmapNum(0)
		else:
			self["definition"].setPixmapNum(1)
		if self.dbData["widescreen"] == 1:
			self["resolution"].setPixmapNum(0)
		else:
			self["resolution"].setPixmapNum(1)
		self["res"].setText("%d x %d" % (self.dbData["res_width"], self.dbData["res_height"]))
		self["framerate"].setText("%.3f frame rate" % self.dbData["framerate"])
		self["codec"].setText(self.dbData["codec"].replace("video","").upper())
		title = self.dbData["name"]
		duration = self.dbData["duration"]
		service_name = self.dbData["servicename"]
		begin = self.dbData["begin"]
		short_description = self.dbData["description"]
		ext_description = self.dbData["extdescription"]
		recording = self.dbData["recording"]
		begin_string = ""
		duration_string = ""
		if recording:
			begin_string = _("Recording...")
		if not begin_string and begin > 0:
			t = FuzzyTime(begin)
			begin_string = "%s, %s" % (t[0],t[1])
		if duration > 0:
			duration_string = "%d:%02d min" % (duration / 60, duration % 60)
		self["datetime"].setText(begin_string)
		self["duration"].setText(duration_string)
		self["channel"].setText(service_name)
		if self.dbData["tmdb_movie_id"]:
			self.isTMDbData = 1
		else:
			self.isTMDbData = 0
		movieID = self.dbData["movie_id"]
		if self.isTMDbData == 0:
			self["headertext"].setText("%s - %s" % (title, short_description))
		else:			
			self["headertext"].setText(title)
		self["overview"].setText(ext_description)
		misc = ""
		if self.isTMDbData == 1:
			categories = short_description
			if categories:
				misc += "Genre: %s\n" % categories
		misc += getTMDbWriters(movieID)
		misc += getTMDbActors(movieID)
		misc += getTMDbDirectors(movieID)
		self["misc"].setText(misc)
		self["overview"].show()
		self["misc"].show()
		self["headertext"].show()
		if self.dbData["cover_filename"]:
			filename = os_path.join(ClientID.instance.getImagePath(), self.dbData["cover_filename"] )
			self.picload.startDecode(filename,False)
			ptr = self.picload.getData()
			self["poster"].updatePoster(ptr)
			
	def pageUp(self):
		self["overview"].pageUp()

	def pageDown(self):
		self["overview"].pageDown()
		
	def setMovieData(self, dbData):
		self.dbData = dbData
		self.showData()


	def closeScreen(self):
		self.close()
		
	def prevEvent(self):
		if self.cbFunc is not None:
			self.cbFunc(self.setMovieData, self.closeScreen, -1)

	def nextEvent(self):
		if self.cbFunc is not None:
			self.cbFunc(self.setMovieData, self.closeScreen, +1)
