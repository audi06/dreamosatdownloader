# -*- coding: utf-8 -*-
#
# VideoDB E2
#
# Coded by Dr.Best (c) 2013
# Support: www.dreambox-tools.info
# E-Mail: dr.best@dreambox-tools.info
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Multimedia GmbH.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Multimedia GmbH.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Multimedia GmbH.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.
#

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.InfoBar import MoviePlayer
from Screens.ChoiceBox import ChoiceBox
from Components.ActionMap import HelpableActionMap
from Components.Sources.Boolean import Boolean
from Screens.InfoBarGenerics import InfoBarShowHide, \
	InfoBarMenu, InfoBarShowMovies, InfoBarSeek,  \
	InfoBarAudioSelection, InfoBarNotifications,  InfoBarExtensions, \
	InfoBarServiceNotifications, InfoBarPVRState, InfoBarCueSheetSupport, \
	InfoBarMoviePlayerSummarySupport, InfoBarTeletextPlugin, InfoBarPlugins, \
	InfoBarSubtitleSupport, InfoBarServiceErrorPopupSupport, InfoBarPlugins

from Screens.HelpMenu import HelpableScreen
from Tools import Notifications
from os import path as os_path
from enigma import eServiceReference
from enigma import iPlayableService
from Components.config import config
from ServiceReference import ServiceReference
from enigma import ePoint
from MovieEventView import MovieEventView
from DatabaseConnection import OpenDatabase, OperationalError, OpenDatabaseForWriting, ClientID
from Components.ServiceEventTracker import ServiceEventTracker, InfoBarBase

# for localized messages
from . import _

class VideoDBInfoBarCueSheetSupport(InfoBarCueSheetSupport):

	def __init__(self, actionmap = "InfobarCueSheetActions"):

		self["CueSheetActions"] = HelpableActionMap(self, actionmap,
			{
				"jumpPreviousMark": (self.jumpPreviousMark, _("jump to previous marked position")),
				"jumpNextMark": (self.jumpNextMark, _("jump to next marked position")),
				"toggleMark": (self.toggleMark, _("toggle a cut mark at the current position"))
			}, prio=1)

		self.cut_list = [ ]
		self.is_closing = False # I don't need this


	def setEventTracker(self):
		self.TestAudio = False
		self.onlyOneTime = False # needed because of evUpdatedEventInfo
		if self.ref.type == eServiceReference.idDVB:
			type_iPlayableService = iPlayableService.evStart
		else:
			# unfortunately evStart is set way too early in servicemp3 --> use evUpdatedEventInfo instead, but make sure only one time...
			type_iPlayableService = iPlayableService.evUpdatedEventInfo

		self.__event_tracker = ServiceEventTracker(screen=self, eventmap=
			{
				type_iPlayableService: self.__serviceStarted,
			})

	def __serviceStarted(self):
		if not self.onlyOneTime:
			self.onlyOneTime = True
			self.downloadCuesheet()
			if self.ENABLE_RESUME_SUPPORT and self.dbData["ismovie"]:
				self.resume_point = 0
				# get resume point from database
				connection = OpenDatabase()
				if connection is not None:
					connection.text_factory = str
					cursor = connection.cursor()
					if config.plugins.videodb.clientmovieposition.value:
						cursor.execute('SELECT clientmovieposition from Client_MoviePosition where movie_id = %d and client_id = %d;' % (self.movieID, ClientID.instance.getClientID()))
					else:
						cursor.execute('SELECT movieposition FROM Movies WHERE movie_id = %d;' % self.movieID)
					row = cursor.fetchone()
					if row is not None:
						self.resume_point = row[0]
					cursor.close()
					connection.close()
				if self.resume_point:
					currentPoint = self.resume_point / 90000
					if currentPoint < self.dbData["duration"]:
						if config.usage.on_movie_start.value == "ask":
							Notifications.AddNotificationWithCallback(self.playLastCB, MessageBox, _("Do you want to resume this playback?") + "\n" + (_("Resume position at %s") % ("%d:%02d:%02d" % (currentPoint/3600, currentPoint%3600/60, currentPoint%60))), timeout=10)
						elif config.usage.on_movie_start.value == "resume":
							Notifications.AddNotificationWithCallback(self.playLastCB, MessageBox, _("Resuming playback"), timeout=2, type=MessageBox.TYPE_INFO)

# internal test for me...
#		if not self.TestAudio:
#			service = self.session.nav.getCurrentService()
#			self.audioTracks = audio = service and service.audioTracks()
#			n = audio and audio.getNumberOfTracks() or 0
#			if n > 0:
#				for x in range(n):
#					i = audio.getTrackInfo(x)
#					print "------------------------->i = ", i.getLanguage()
#				self.TestAudio = True
#				self.audioTracks.selectTrack(1)

class VideoDBPlayer(InfoBarBase, InfoBarShowHide, \
		InfoBarMenu, InfoBarShowMovies, \
		InfoBarSeek, InfoBarAudioSelection, HelpableScreen, InfoBarNotifications, InfoBarExtensions, \
		InfoBarServiceNotifications, InfoBarPVRState, VideoDBInfoBarCueSheetSupport,
		InfoBarMoviePlayerSummarySupport, InfoBarPlugins, InfoBarSubtitleSupport, Screen, InfoBarTeletextPlugin,
		InfoBarServiceErrorPopupSupport):
	

	ENABLE_RESUME_SUPPORT = True
	ALLOW_SUSPEND = True
		
	def __init__(self, session, parent):
		Screen.__init__(self, session, parent = parent)
		
		self.session = session
		self.movieID = 0
		self.ref = None
		self.currentListIndex = -1
		self.dbData = None
		
		self["actions"] = HelpableActionMap(self, "MoviePlayerActions",
			{
				"leavePlayer": (self.leavePlayer, _("leave movie player..."))
			})
		
		self["EPGActions"] = HelpableActionMap(self, "InfobarEPGActions",
			{
				"showEventInfo": (self.openEventView, _("show event details")),
			})
			
		self["BouquetActions"] = HelpableActionMap(self, "EPGSelectActions",
			{
				"nextBouquet": (self.selectResolution, _("switch resolution...")),
				"prevBouquet": (self.selectContentDisplay, _("switch content display...")),
			})
			


		self.allowPiP = False
		

		for x in HelpableScreen, InfoBarShowHide, InfoBarMenu, \
				InfoBarBase, InfoBarSeek, InfoBarShowMovies, \
				InfoBarAudioSelection, InfoBarExtensions, InfoBarNotifications, \
				InfoBarServiceNotifications, InfoBarPVRState, VideoDBInfoBarCueSheetSupport, \
				InfoBarMoviePlayerSummarySupport, InfoBarPlugins, InfoBarSubtitleSupport, \
				InfoBarTeletextPlugin, InfoBarServiceErrorPopupSupport:
			x.__init__(self)


		self.returning = False # i don't need this
		self.skinName = "MoviePlayer"
		self.isPlaying = False

		if hasattr(config, "merlin2"):	# Merlin Image feature only --> InfobarPosition
			self.onExecBegin.append(self.__onExecBegin)

		self.onClose.append(self.__onClose)

	# for audio sync...
	def runPlugin(self, plugin):
		plugin(session = self.session, servicelist = None)

	def __onClose(self):
		if self.dbData["tmdb_movie_id"] is not None:
			config.plugins.videodb.lastPlayedMovieID.value = int(self.dbData["movie_id"])
			config.plugins.videodb.lastPlayedMovieID.save()
		else:
			connection = OpenDatabase(True, True)
			if connection is not None:
				cursor = connection.cursor()
				sql = "SELECT movies_series.season, movies_series.serie_id FROM movies_series where movies_series.movie_id = %d;" % (self.dbData["movie_id"])
				cursor.execute(sql)
				row = cursor.fetchone()
				cursor.close()  
				connection.close()
				if row:
					config.plugins.videodb.lastPlayedEpisodeIDs.value = "%d,%d,%d" % (row["serie_id"] , row["season"], self.dbData["movie_id"])
					config.plugins.videodb.lastPlayedEpisodeIDs.save()
		
	def switchResolution(self, rmode):
		from Plugins.SystemPlugins.Videomode.VideoHardware import video_hw # depends on Videomode Plugin
		try:
			from Plugins.SystemPlugins.AutoResolution.plugin import resolutionlabel
		except:
			resolutionlabel = None
		if rmode:
			mode = rmode[0]
			direct = False
			port = rate = ""
			if mode.find("1080p") != -1 or mode.find("720p24") != -1:
				print "[VideoDB] switching to ", mode
				v = open('/proc/stb/video/videomode' , "w")
				v.write("%s\n" % mode)
				v.close()
				direct = True
			else:
				port = config.av.videoport.value
				rate = config.av.videorate[mode].value
				print "[VideoDB] switching to %s %s %s" % (port, mode, rate)
				video_hw.setMode(port, mode, rate)
			if resolutionlabel is not None:
				if direct:
					resolutionlabel["restxt"].setText("Videomode: %s" % mode)
				else:
					resolutionlabel["restxt"].setText("Videomode: %s %s %s" % (port, mode, rate))
				resolutionlabel.show()


	def selectResolution(self):
		from Plugins.SystemPlugins.Videomode.VideoHardware import video_hw # depends on Videomode Plugin
		try:
			from Plugins.SystemPlugins.AutoResolution.plugin import resolutionlabel
		except:
			resolutionlabel = None
		co = True
		if resolutionlabel is not None:
			if not resolutionlabel.shown:
				resolutionlabel.show()
				co = False
		if co:
			port = config.av.videoport.value
			if not port in ('DVI-PC', 'Scart'):
				modes = [(mode[0],mode[0]) for mode in video_hw.getModeList(port)]
				choices = modes + [('720p24','720p24'),('1080p24','1080p24'), ('1080p25', '1080p25'), ('1080p30', '1080p30')]
				self.session.openWithCallback(self.switchResolution, ChoiceBox, title=_("Select resolution..."), list = choices)
				
	def switchContentDisplay(self, displaymode):
		if displaymode:
			config.av.policy_43.value =  displaymode[1]
			config.av.policy_43.save()
			self.session.open(MessageBox,_("Display 4:3 content as") + " " + displaymode[0], MessageBox.TYPE_INFO, timeout = 3)

				
	def selectContentDisplay(self):
		choices = [(_("Pillarbox"), "pillarbox"), (_("Pan&Scan"), "panscan"), (_("Just Scale"),"scale")]
		self.session.openWithCallback(self.switchContentDisplay, ChoiceBox, title=_("Select mode for 4:3 content..."), list = choices)

	def playMovie(self, movieID, ref, currentListIndex, dbData):
		if self.movieID != movieID:
			if self.movieID: # 
				self.updateMoviePosition() # update position/duration of current playing movie in db
			self.movieID = movieID
			self.ref = ref
			self.dbData = dbData
			self.setEventTracker()
			self.isPlaying = True
			self.session.nav.playService(self.ref)
		self.currentListIndex = currentListIndex

	def updateMoviePosition(self):
		seek = self.getSeek()
		if seek and self.movieID:
			pts = seek.getPlayPosition()
			if self.dbData["ismovie"]:
				position = pts[1]
			else:
				position = 0
			length = seek.getLength()
			connection, error = OpenDatabaseForWriting()
			if connection is not None:
				connection.text_factory = str
				cursor = connection.cursor()
				if config.plugins.videodb.clientmovieposition.value:
					if self.ref.type != eServiceReference.idDVB and length:
						cursor.execute("Update Movies set duration = %d where movie_id = %d;" % ( length[1] / 90000, self.movieID))
					sql = ""
					cursor.execute('select client_movieposition_id from Client_MoviePosition where movie_id = %d and client_id = %d;' % (self.movieID, ClientID.instance.getClientID()))
					row = cursor.fetchone()
					if row:
						sql = "UPDATE Client_MoviePosition set clientmovieposition = %d where client_movieposition_id = %d;" % (position,row[0])
					else:
						sql = "INSERT INTO Client_MoviePosition (movie_id, client_id, clientmovieposition) VALUES (%d,%d,%d);" % (self.movieID,ClientID.instance.getClientID(),position)
					cursor.execute(sql)
				else:
					if self.ref.type == eServiceReference.idDVB:
						sqladditional = ""
					elif length:
						sqladditional = ", duration = %d" % (length[1] / 90000) # update duration in database for serviceID 4097
					cursor.execute("Update Movies set movieposition=%d %s where movie_id = %d;" % (position, sqladditional, self.movieID))
				connection.commit()
				cursor.close()
				connection.close()
				
			else:
				self.session.open(MessageBox, _("Database connection failed...you should close VideoDB, data can not be saved in database...\n%s" % error) , MessageBox.TYPE_ERROR) # FIXME!
			return (position, length[1] / 90000)
		else:
			return (None, None)

	def leavePlayer(self):
		self.handleLeave(config.usage.on_movie_stop.value)

	def handleLeave(self, how):
		if how == "ask" and self.dbData["ismovie"]:
			if config.usage.setup_level.index < 2: # -expert
				list = (
					(_("Yes"), "quit"),
					(_("No"), "continue")
				)
			else:
				
				list = (
					(_("Yes, returning to movie list"), "movielist"),
					(_("Yes, and close VideoDB"), "quit"),
					(_("No"), "continue"),
					(_("No, but restart from begin"), "restart")
				)
			self.session.openWithCallback(self.leavePlayerConfirmed, ChoiceBox, title=_("Stop playing this movie?"), list = list)
		else:
			if self.dbData["ismovie"]:
				self.leavePlayerConfirmed([True, how])
			else:
				if self.parent is not None:
					self.parent.closeVideoManagerFromVideoPlayer()
				else:
					self.close()

	def leavePlayerConfirmed(self, answer):
		answer = answer and answer[1]
		if not answer:
			 return
		if answer in ("quit"):
			self.updateMoviePosition()
			if self.parent is not None:
				self.parent.closeVideoManagerFromVideoPlayer()
			else:
				self.close(0)
		elif answer in ("movielist"):
			moviePosLength = self.updateMoviePosition()
			if self.parent is not None:
				self.parent.updateMoviePositionDuration(self.currentListIndex, moviePosLength, self.movieID) # submit listindex and movieID (listview could have changed, if so, try to find the movie with ID)
			self.movieID = 0
			self.session.nav.stopService()
			self.isPlaying = False
			self.close()
		elif answer == "restart":
			self.doSeek(0)


	def doEofInternal(self, playing):
		self.isPlaying = False
		self.handleLeave(config.usage.on_movie_eof.value)	

	def openEventView(self):
		if self.dbData:
			self.session.open(MovieEventView, self.dbData)

	def showMovies(self):
		moviePosLength = self.updateMoviePosition()
		if self.parent is not None:
			self.parent.updateMoviePositionDuration(self.currentListIndex, moviePosLength, self.movieID) # submit listindex and movieID (listview could have changed, try to find movie with ID)
		self.close()

	def __onExecBegin(self):
		self.onExecBegin.remove(self.__onExecBegin)
		orgpos = self.instance.position()	
		self.instance.move(ePoint(orgpos.x() + config.merlin2.movieplayer_infobar_position_offset_x.value, orgpos.y() + config.merlin2.movieplayer_infobar_position_offset_y.value))


class VideoDBPlayerModal(VideoDBPlayer):		
	def __init__(self, session, movieID, ref, dbData):
		VideoDBPlayer.__init__(self, session, parent = None)
		self.movieID = movieID
		self.ref = ref
		self.dbData = dbData
		self.setEventTracker()
		self.isPlaying = True
		self.session.nav.playService(self.ref)
		self.currentListIndex = -1
		
class VideoDBPlayerWebModal(VideoDBPlayerModal):	
	
	def __init__(self, session, movieID, ref, dbData):
		self.currentService = session.nav.getCurrentlyPlayingServiceReference()
		VideoDBPlayerModal.__init__(self, session, movieID, ref, dbData)
	
	def handleLeave(self, how):
		if how == "ask" and self.dbData["ismovie"]:
			list = (
					(_("Yes"), "quit"),
					(_("No"), "continue")
				)
			self.session.openWithCallback(self.leavePlayerConfirmed, ChoiceBox, title=_("Stop playing this movie?"), list = list)
		else:
			self.leavePlayerConfirmed([True, how])

	def leavePlayerConfirmed(self, answer):
		answer = answer and answer[1]
		if not answer:
			 return
		self.updateMoviePosition()
		if self.currentService:
			self.session.nav.playService(self.currentService)
		self.close()


class VideoDBPlayerModalAllEpisodes(VideoDBPlayer):
		

	def __init__(self, session, movieID, eptuplelist):
		VideoDBPlayer.__init__(self, session, parent = None)

		if Boolean(fixed=config.misc.rcused.value == 0):
			self["AllEpisodesActions"] = HelpableActionMap(self, "ColorActions",
				{
					"green": (self.doEofInternal, _("play next episode...")),
				})
		else:
			
			self["AllEpisodesActions"] = HelpableActionMap(self, "VideoDBMoviePlayerActions",
			{
				"green_l": (self.doEofInternal, _("play next episode...")),
			})
	
		self.isPlaying = False
		self.currentListIndex = -1
		self.epTupleList = eptuplelist
		self.playNextEpisode(movieID)


	def getCurrentMovieData(self, movieID):
		dbData = None
		if movieID:
			connection = OpenDatabase(dictFactory = True)
			if connection is not None:
				cursor = connection.cursor()
				cursor.execute("SELECT %d as mode, movies.name, movies.movie_id, movies.serviceid, movies.filename, movies.path_id, movies.movieposition, movies.duration, servicenames.servicename, movies.begin, movies.description, movies.event_id, movies.filesize, events.extdescription, movies.recording, movies.wallpaper, movies.cover_filename, movies.thumb_filename, movies.tmdb_movie_id, movies.ismovie, movies.dts, movies.ac3, movies.stereo, movies.hd, movies.widescreen, movies.res_width, movies.res_height, movies.framerate, movies.codec, paths.path, mountpoints.mountpoint, client_movieposition.clientmovieposition FROM Movies INNER JOIN Servicenames ON movies.servicename_id = servicenames.servicename_id INNER JOIN Paths ON movies.path_id = paths.path_id INNER JOIN mountpoints on Paths.link_id = Mountpoints.link_id LEFT OUTER JOIN Events ON movies.event_id = events.event_id LEFT OUTER JOIN client_movieposition ON movies.movie_id = client_movieposition.movie_id AND client_movieposition.client_id = %d WHERE movies.visible = 1 and mountpoints.client_id = %d and movies.movie_id = %d;" % (99, ClientID.instance.getClientID(), ClientID.instance.getClientID(), movieID))
				dbData = cursor.fetchone()
				cursor.close()  
				connection.close()
		return dbData

	def doEofInternal(self, playing=None):
		self.isPlaying = False
		self.updateMoviePosition()
		self.playNextEpisode(None)


	def playNextEpisode(self, movieID = None):
		cur = None
		if movieID is not None:
			while True:
				if len(self.epTupleList) == 0:
					break
				else:
					cur = self.epTupleList.pop()[0]
					if cur["movie_id"] == movieID:
						break
	
		elif len(self.epTupleList) != 0:
			cur = self.epTupleList.pop()[0]

		if cur is not None:
			movieID = cur["movie_id"]
			row = self.getCurrentMovieData(movieID)
			if row:

				name = "%s - (%sx%s) %s" % (row["name"], cur["season"], cur["episode"] , cur["episodename"])
				serviceID = row["serviceid"]
				filename = row["filename"]
				path = os_path.join(row["mountpoint"],row["path"])
				if os_path.exists(os_path.join(path,filename)):
					self.ref = eServiceReference(serviceID, 0, os_path.join(path,filename))
					self.ref.setName(name)
				self.movieID = movieID
				self.dbData = row
				self.setEventTracker()
				self.isPlaying = True
				self.session.nav.playService(self.ref)
				
		else:
			self.handleLeave(config.usage.on_movie_stop.value)

