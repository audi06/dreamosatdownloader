# -*- coding: utf-8 -*-
#
# VideoDB E2
#
# Coded by Dr.Best (c) 2013
# Support: www.dreambox-tools.info
# E-Mail: dr.best@dreambox-tools.info
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Multimedia GmbH.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Multimedia GmbH.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Multimedia GmbH.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.
#

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.ActionMap import NumberActionMap
from Components.Pixmap import Pixmap, MultiPixmap
from Components.Label import Label
from Components.CoverCollection import CoverCollection, VideoDBPictureBox
from Components.ScrollLabel import ScrollLabel
from Components.MultiContent import MultiContentEntryProgress
from enigma import eServiceReference, eTimer
from Player import VideoDBPlayerModal, VideoDBPlayerModalAllEpisodes
from enigma import getDesktop, ePoint
from DatabaseConnection import OpenDatabase, OpenDatabaseForWriting, ClientID
from os import path as os_path
from Components.config import config
from enigma import RT_VALIGN_CENTER, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, gFont, eListbox,eListboxPythonMultiContent, eSize
from Components.GUIComponent import GUIComponent
from enigma import loadPNG, loadJPG, eServiceCenter
from skin import parseColor
from Screens.ChoiceBox import ChoiceBox
from Tools.BoundFunction import boundFunction
from Components.ProgressBar import ProgressBar
from MovieEventView import MovieEventView
from DatabaseFunctions import getTMDbWriters, getTMDbActors, getTMDbDirectors, setMovieStatusInDatabase, deleteNotNeededPhysicalImageFiles, deleteTVDbDataFromMovieInDatabase, deleteTMDbDataFromMovieInDatabase, setAllMovieStatusInDatabase, deleteMovieCollection, deleteMovieFromPlaylist
from Screens.MessageBox import MessageBox
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.Sources.StaticText import StaticText
from TextInput import TextInput
import servicevideodb
import time
from MovieDataUpdater import MovieDataUpdater, MovieDataUpdaterScreen
from MovieBrowser import MovieBrowser, ScanLogs
from DialogScreen import DialogScreen
from TMDb import TMDbSelection, DownloadTMDbPictures
from TVDb import TVDbSelection, DownloadTVDbPictures
PLAY=99
DEFAULT_WALLPAPER = "/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/default_wallpaper"
from Screens.Menu import MainMenu
from twisted.internet.threads import deferToThread
from Setup import PlaylistItemSelection

from enigma import ePicLoad, eRect
from Components.AVSwitch import AVSwitch
from skin import TemplatedListFonts

# Check if is FullHD / UHD
DESKTOP_WIDTH = getDesktop(0).size().width()
if DESKTOP_WIDTH > 1920:
	skinFactor = 3.0
elif DESKTOP_WIDTH > 1280:
	skinFactor = 1.5
else:
	skinFactor = 1
	
# for localized messages
from . import _

def getScale():
	return AVSwitch().getFramebufferScale()

class MoviePosterResize(Pixmap):
	def __init__(self, scale_width, scale_height, sc):
		Pixmap.__init__(self)
		self._scaleSize = eSize(scale_width, scale_height)
		self._aspectRatio = eSize(sc[0], sc[1])
		
	def setParam(self, scaleSize):
		self._scaleSize = scaleSize
		
	def updatePoster(self, ptr):
		if ptr is not None:
			pic_scale_size = ptr.size().scale(self._scaleSize, self._aspectRatio)
			if pic_scale_size.isValid():
				pic_scale_width = pic_scale_size.width()
				pic_scale_height = pic_scale_size.height()
				dest_rect = eRect(0, 0, pic_scale_width, pic_scale_height)
				self.instance.setScale(1)
				self.instance.setScaleDest(dest_rect)
			else:
				self.instance.setScale(0)
			self.instance.setPixmap(ptr)
		else:
			self.instance.setPixmap(None)


class MoviePoster(Pixmap):
	def __init__(self, callback = None):
		Pixmap.__init__(self)
		self.images = {}
		self.callback = callback
	def updatePoster(self, filename):
		ptr = self.images.get(filename,None)
		if ptr is None:
			ptr = loadJPG(filename)
			self.images[filename] = ptr
		if ptr is not None:
			self.instance.setPixmap(ptr)
		else:
			self.instance.setPixmap(None)
		if self.callback is not None:
			self.callback()

class MoviesScreen(object):
	def __init__(self, session):
		self.session = session
		self.currentService = self.session.nav.getCurrentlyPlayingServiceReference()
		self.session.nav.stopService()

	def open(self, index = 0, view = -1):
		if ClientID.instance.getClientID() is None:
			self.session.open(MessageBox, _("Your database for VideoDB was not initialized.\nPlease enter Setup to do that."), MessageBox.TYPE_ERROR)
		else:
			if not MovieDataUpdater.instance.isRunning():
				proceed = 0
				connection = OpenDatabase(True, True)
				if connection is not None:
					cursor = connection.cursor()
					sql = "select movie_id from movies where tmdb_movie_id not null LIMIT 1;"
					cursor.execute(sql)
					row = cursor.fetchone()
					if row:
						proceed = 1
						if view > 0: # check if movies are available in selected playlist
							row = self.checkMoviesInPlaylist(view)
							if not row:
								proceed = -1
								self.session.openWithCallback(boundFunction(self.noMoviesInPlaylistCallback,index), MessageBox, _("Could not find any movies in selected playlist. Switching to regular movielist view."), type = MessageBox.TYPE_INFO)
					cursor.close() 
					connection.close()
				if proceed == 1:		
					style = config.plugins.videodb.moviesscreen_style.value
					if style == 0:
						self.session.openWithCallback(self.screenClosed, PosterwallTop, index, view)
					elif style == 1:
						self.session.openWithCallback(self.screenClosed, PosterwallTopThumb, index, view)
					elif style == 2:
						self.session.openWithCallback(self.screenClosed, PosterwallTopThumbRight, index, view)
					elif style == 3:
						self.session.openWithCallback(self.screenClosed, HighListMovies, index, view)
					elif style == 4:
						self.session.openWithCallback(self.screenClosed, CoverflowPosterMovies, index, view)
					elif style == 5:
						self.session.openWithCallback(self.screenClosed, SimpleStyleMovies, index, view)
				elif proceed == 0:
					self.session.openWithCallback(self.dialogScanForMoviesScreenCallBack, DialogScreen, _("There are no movies found in the database...\nWhat do you want to do?"), [ (_("Scan for movies"), 0), (_("Do nothing"), 1) ])
			else:
				self.session.openWithCallback(self.dialogShowMovieDataUpdaterScreenCallBack, DialogScreen, _("You are updating your movies with TMDb- and TVDb service right now...\nWhat do you want to do?"), [ (_("Show status"), 0), (_("Do nothing"), 1) ])
				
	def dialogShowMovieDataUpdaterScreenCallBack(self, result):
		if result:
			self.session.open(MovieDataUpdaterScreen)
			
	def dialogScanForMoviesScreenCallBack(self, result):
		if result:
			self.session.open(MovieBrowser, False)
		
			
	def screenClosed(self, result = None, index = 0, view = -1):
		if result and result == 1:
			self.open(index, view)
		else:
			self.session.nav.playService(self.currentService)
			if isinstance (self.session.current_dialog, MainMenu):
				self.session.current_dialog.closeRecursive()
	
	def checkMoviesInPlaylist(self, playlist_id):
		connection = OpenDatabase(True, True)
		if connection is not None:
			cursor = connection.cursor()
			sql = "select movies.movie_id from movies inner join playlist_movies on movies.movie_id = playlist_movies.movie_id where playlist_movies.playlist_id = %d LIMIT 1;" % (playlist_id)
			cursor.execute(sql)
			row = cursor.fetchone()
			cursor.close() 
			connection.close()
			return row
		return None	
	
	def noMoviesInPlaylistCallback(self, index, result):
		self.open(index, -1) # open again with regular movielist view

class VideoBase:
	def __init__(self):
		self.currentIndex = 0
		self.imagePath = ClientID.instance.getImagePath()

	def dict_factory(self, cursor, row):
		dictList = {}
		for idx, col in enumerate(cursor.description):
			dictList[col[0]] = row[idx]
		return dictList


	def askFordeleteMovieFromDatabase(self):
		cur = self.currentSelectedMovie
		if cur:
			movieID = cur["movie_id"]
			row = self.getCurrentMovieData(movieID)
			if row:
				name = row["name"]
				connection, error = OpenDatabaseForWriting()
				if connection is not None:
					self.session.openWithCallback(boundFunction(self.deleteMovieFromDatabase, movieID, True, connection), MessageBox, _("Do you want to delete this entry (%s) from the database without deleting the physical file?") % (name))
				else:
					self.session.openWithCallback(self.close, MessageBox, _("Database connection failed....\n%s" % error) , MessageBox.TYPE_ERROR) # FIXME!
		

	def deleteMovie(self):
		cur = self.currentSelectedMovie
		if cur:
			movieID = cur["movie_id"]
			row = self.getCurrentMovieData(movieID)
			if row:
				name = row["name"]
				serviceID = row["serviceid"]
				filename = row["filename"]
				path = os_path.join(row["mountpoint"],row["path"])
				ref = eServiceReference(serviceID, 0, os_path.join(path,filename))
				ref.setName(name)
				if os_path.exists(os_path.join(path,filename)):
					if not row["recording"]: # recording
						serviceHandler = eServiceCenter.getInstance()
						offline = serviceHandler.offlineOperations(ref)
						result = False
						if offline is not None:
							# simulate first
							if not offline.deleteFromDisk(1):
								result = True
						if result == True:
							self.session.openWithCallback(boundFunction(self.deleteConfirmed, ref, movieID), MessageBox, _("Do you really want to delete %s?") % (ref.getName()))
						else:
							self.session.open(MessageBox, _("You cannot delete this!"), MessageBox.TYPE_ERROR) # FIXME!
					else:
						self.session.open(MessageBox, _("This video can not be deleted now, because it is currently recording!"), MessageBox.TYPE_ERROR) # FIXME!
				else:
					# physical file is not available (already deleted? not mounted?) FIXME!
					connection, error = OpenDatabaseForWriting()
					if connection is not None:
						self.session.openWithCallback(boundFunction(self.deleteMovieFromDatabase, movieID, True, connection), MessageBox, _("Filename %s\nwas not found.\nDo you want to delete this entry (%s) from the database anyway without deleting the physical file?") % (ref.getPath(), ref.getName()))
					else:
						self.session.openWithCallback(self.close, MessageBox, _("Database connection failed....\n%s" % error) , MessageBox.TYPE_ERROR) # FIXME!

	def deleteConfirmed(self, ref, movieID, confirmed):
		if confirmed:
			result = False
			serviceHandler = eServiceCenter.getInstance()
			offline = serviceHandler.offlineOperations(ref)
			connection, error = OpenDatabaseForWriting()
			if offline is not None and connection is not None:
				# really delete!
				if not offline.deleteFromDisk(0):
					result = True
			if result == False:
				if connection: # if database is open, close it
					connection.close()
					self.session.openWithCallback(self.close, MessageBox, _("Delete failed!"), MessageBox.TYPE_ERROR) # FIXME!
				else:
					self.session.openWithCallback(self.close, MessageBox, _("Delete failed!\n%s" %error), MessageBox.TYPE_ERROR) # FIXME!
			else:
				self.deleteMovieFromDatabase(movieID, True, connection, True)
				
	def deleteMovieFromDatabase(self, movieID, confirmed, connection, confirmed2):
		if confirmed and confirmed2:
			cursor = connection.cursor()
			cursor.execute('DELETE FROM Movies WHERE movie_id = %d;' % (movieID)) # triggers will do the rest :-)
			connection.commit()
			cursor.close()  
			connection.close()
			deleteNotNeededPhysicalImageFiles()
			if hasattr(self,"playlist_id"):
				self.buildList(0, self.playlist_id)
			else:
				self.buildList(0)

	def setMovieStatus(self, status):
		cur = self.currentSelectedMovie
		if cur:
			movieID = cur["movie_id"]
			result =  setMovieStatusInDatabase(status, movieID)
			if result[0]:
				self.updateMoviePositionInList()
			else:
				error = result[1]
				self.session.open(MessageBox, _("Database connection failed...you should close VideoDB, data can not be saved in database...\n%s" % error) , MessageBox.TYPE_ERROR) # FIXME!

	def okPressed(self):
		cur = self.currentSelectedMovie
		if cur:
			if cur.has_key("col_count") and (cur["col_count"] > 1 or self.playlist_id == -4):
				self.movieCollectionOKPressedLastIndex = self.currentIndex
				self.okPressedTagList(cur["tmdb_collection_id"], ' and movies.tmdb_collection_id = %d' % cur["tmdb_collection_id"], "", 9)
				return
			movieID = cur["movie_id"]
			row = self.getCurrentMovieData(movieID)
			if row:
				if cur.has_key("episode"):
					name = "%s - (%sx%s) %s" % (row["name"], cur["season"], cur["episode"] , cur["episodename"])
				else:
					name = row["name"]
				serviceID = row["serviceid"]
				filename = row["filename"]
				path = os_path.join(row["mountpoint"],row["path"])
				if os_path.exists(os_path.join(path,filename)):
					ref = eServiceReference(serviceID, 0, os_path.join(path,filename))
					ref.setName(name)
					self.session.openWithCallback(self.playerClosed, VideoDBPlayerModal, movieID, ref, row)
				else:
					self.session.open(MessageBox, _("Could not find the movie.\nEither the device is not mounted or the movie was deleted."), type = MessageBox.TYPE_INFO)


	def playerClosed(self, result = None):
		if self.ref is not None:
			self.session.nav.playService(self.ref)
		else:
			self.session.nav.stopService()
		if result == 0:
			self.close(0)
		else:
			self.updateMoviePositionInList()

	def openEventView(self):
		cur = self.currentSelectedMovie
		if cur:
			if cur.has_key("col_count") and (cur["col_count"] > 1 or self.playlist_id == -4):
				dbData = cur.copy()
				if self.playlist_id == -4: dbData["col_count"] = 2 # fast fix for MovieEventView --> FIXME
			else:
				movieID = cur["movie_id"]
				dbData = self.getCurrentMovieData(movieID)
			if dbData:
				self.session.open(MovieEventView, dbData, self.EventViewCallback)

	def EventViewCallback(self, setMovieData, closeScreen, direction):
		if direction > 0:
			self.nextMovie()
		else:
			self.previousMovie()
		dbData = None
		cur = self.currentSelectedMovie
		if cur:
			if cur.has_key("col_count") and (cur["col_count"] > 1 or self.playlist_id == -4):
				dbData = cur.copy()
				if self.playlist_id == -4: dbData["col_count"] = 2 # fast fix for MovieEventView --> FIXME
			else:
				movieID = cur["movie_id"]
				dbData = self.getCurrentMovieData(movieID)
			if dbData:
				setMovieData(dbData)
		if dbData is None:
			closeScreen()

	def nextMovie(self):
		pass

	def previousMovie(self):
		pass	


	def getCurrentMovieData(self, movieID):
		dbData = None
		if movieID:
			connection = OpenDatabase(dictFactory = True)
			if connection is not None:
				cursor = connection.cursor()
				cursor.execute("SELECT %d as mode, movies.name, movies.movie_id, movies.serviceid, movies.filename, movies.path_id, movies.movieposition, movies.duration, servicenames.servicename, movies.begin, movies.description, movies.event_id, movies.filesize, events.extdescription, movies.recording, movies.wallpaper, movies.cover_filename, movies.thumb_filename, movies.tmdb_movie_id, movies.ismovie, movies.dts, movies.ac3, movies.stereo, movies.hd, movies.widescreen, movies.res_width, movies.res_height, movies.framerate, movies.codec, movies.tmdb_collection_id, paths.path, mountpoints.mountpoint, client_movieposition.clientmovieposition FROM Movies INNER JOIN Servicenames ON movies.servicename_id = servicenames.servicename_id INNER JOIN Paths ON movies.path_id = paths.path_id INNER JOIN mountpoints on Paths.link_id = Mountpoints.link_id LEFT OUTER JOIN Events ON movies.event_id = events.event_id LEFT OUTER JOIN client_movieposition ON movies.movie_id = client_movieposition.movie_id AND client_movieposition.client_id = %d WHERE movies.visible = 1 and mountpoints.client_id = %d and movies.movie_id = %d;" % (PLAY, ClientID.instance.getClientID(), ClientID.instance.getClientID(), movieID))
				dbData = cursor.fetchone()
				cursor.close()  
				connection.close()
		return dbData


class MoviesBase:
	def __init__(self):
		self["title"] = Label("")
		self["genre"] = Label("")
		self["year"] = Label("")
		self["rating"] = Label("")
		self["duration"] = Label("")
		self["position"] = Label("")
		self["director"] = Label("")
		self["writer"] = Label("")
		self["actors"] = Label("")
		self["position_progress"] = ProgressBar()
		self["selectionframe"] = Pixmap()	
		self["rating_stars"] = ProgressBar()
		self["audio_icons"] = MultiPixmap()
		self["definition"] = MultiPixmap()
		self["resolution"] = MultiPixmap() 
		self["framerate"] = Label("")
		self["codec"] = Label("")
		self["res"] = Label("")
		self["col_widget"] = Label("")
		self["col_overview"] = Label("")
		self["playlist"] = Label("")
		self.index = -1
		self.oldindex = 0
		self.searchTitle = ""
		self.ref = None
		self.playlist_id = self.last_used_playlist_id = -1
		self.imagePath = ClientID.instance.getImagePath()
		self["actionsMoviesBase"] = ActionMap(["MovieSelectionActions", "OkCancelActions", "ColorActions", "InfobarActions"],
		{
			"contextMenu": self.menu,
			"showEventInfo": self.openEventView,
			"ok": self.okPressed,
			"cancel": self.cancel,
			"blue": self.showGenreSelection,
			"yellow": self.showActorSelection,
			"green": self.showDirectorSelection,
			"red": self.showCastList,
			"showTv": self.showTrailer,
			"showRadio": self.showTrailerList,
		}, -1)
		
		self["actionsMoviesBaseNumbers"] = NumberActionMap( [ "SetupActions" ],
			{
				"1": self.keyNumberGlobal,
				"2": self.keyNumberGlobal,
				"3": self.keyNumberGlobal,
				"4": self.keyNumberGlobal,
				"5": self.keyNumberGlobal,
				"6": self.keyNumberGlobal,
				"7": self.keyNumberGlobal,
				"8": self.keyNumberGlobal,
				"9": self.keyNumberGlobal,
				"0": self.keyNumberGlobal,
			})

		
				
		self.filterTagID = None
		self.sqlFilterInnerJoin = ""
		self.sqlFilterWhere = ""
		self.filterMode = None
		self.movieCollectionItem = None
		self.movieCollectionOKPressedLastIndex = None
		
		self.currentSelectedMovie = None
		
		
	def showTrailer(self):
		try:
			from Plugins.Extensions.YTTrailer.plugin import YTTrailer
			proceed = True
		except:
			proceed = False
		if proceed:
			cur = self.currentSelectedMovie
			if cur.has_key("col_count") and (cur["col_count"] > 1 or self.playlist_id == -4):
				return
			if cur:
				movieID = cur["movie_id"]
				row = self.getCurrentMovieData(movieID)
				if row:
					eventname = row["name"]
					ytTrailer = YTTrailer(self.session)
					ytTrailer.showTrailer(eventname)

	def showTrailerList(self):
		try:
			from Plugins.Extensions.YTTrailer.plugin import YTTrailerList
			proceed = True
		except:
			proceed = False
		if proceed:
			cur = self.currentSelectedMovie
			if cur.has_key("col_count") and (cur["col_count"] > 1 or self.playlist_id == -4):
				return
			if cur:
				movieID = cur["movie_id"]
				row = self.getCurrentMovieData(movieID)
				if row:
					eventname = row["name"]
					self.session.open(YTTrailerList, eventname)

	def showCastList(self):
		cur = self.currentSelectedMovie
		if cur:
			if cur.has_key("col_count") and (cur["col_count"] > 1 or self.playlist_id == -4):
				return
			self.session.openWithCallback(self.okPressedTagList, FilterListScreen, FilterListScreen.CAST, cur)
		
	def showGenreSelection(self):
		cur = self.currentSelectedMovie
		self.session.openWithCallback(self.okPressedTagList, FilterListScreen, FilterListScreen.GENRE, cur)
		
	def showActorSelection(self):
		cur = self.currentSelectedMovie
		self.session.openWithCallback(self.okPressedTagList, FilterListScreen, FilterListScreen.ACTOR, cur)
		
	def showDirectorSelection(self):
		cur = self.currentSelectedMovie
		self.session.openWithCallback(self.okPressedTagList, FilterListScreen, FilterListScreen.DIRECTOR, cur)
		
	def okPressedTagList(self, id, where, innerjoin, mode):
		if id != -1:
			self.sqlFilterInnerJoin = innerjoin
			self.sqlFilterWhere = where
			self.filterTagID = id
			self.filterMode = mode
			colset = False
			if mode == 9:
				if self.movieCollectionItem is None:
					if self.currentSelectedMovie is not None and self.currentSelectedMovie["tmdb_collection_id"] == id:
						self.movieCollectionItem = self.currentSelectedMovie
						colset = True
			else:
				self.movieCollectionItem = None
			self.buildList(0,self.playlist_id)
			if mode == 9 and not colset:
				self.movieCollectionItem = self.currentSelectedMovie
		else:
			if mode == 9 and self.filterMode == 9:
				self.movieCollectionItem = None
				self.searchTitle = ""
				self.filterTagID = None
				self.filterMode = None
				if self.movieCollectionOKPressedLastIndex is not None:
					index = self.movieCollectionOKPressedLastIndex
				else:
					index = -1
				self.buildList(index, self.playlist_id)
				
	
	def cancel(self):
		if self.searchTitle != "" or self.filterTagID is not None:
			self.searchTitle = ""
			if self.filterMode == 9:
				if self.movieCollectionOKPressedLastIndex is None:
					self.session.openWithCallback(self.okPressedTagList, MovieCollectionScreen, self.movieCollectionItem)
				else:
					self.okPressedTagList(-1, "", "", 9)
					self.movieCollectionOKPressedLastIndex = None
				return
			self.filterTagID = None
			self.filterMode = None
			self.buildList(-1, self.playlist_id)
		else:
			self.close()
			
	def keyNumberGlobal(self, number):
		if number == 1 and self.playlist_id != -1 and self.filterMode != 9:
			self.deleteFromPlaylist()
		elif number == 3:
			self.addMovieToPlaylist()
		elif number == 5 and self.filterMode != 9:
			self.showPlaylists()
			
	def menu(self):
		options = []
		cur = self.currentSelectedMovie
		collection_selected = cur is not None and cur.has_key("col_count") and (cur["col_count"] > 1 or self.playlist_id == -4)
		if self.playlist_id > 0 and (self.filterMode == None or self.filterMode == 9):
			options.extend(((_("Delete from playlist..."), self.deleteFromPlaylist),))
		if collection_selected:
			options.extend(((_("Delete Movie Collection from Database..."), self.deleteMovieCollection),))
		if not collection_selected:
			options.extend(((_("Delete from database..."), self.askFordeleteMovieFromDatabase),))
			options.extend(((_("Search for TMDB data again..."), self.searchForTMDB),))
			options.extend(((_("Delete..."), self.deleteMovie),))
			options.extend(((_("Mark as seen..."), boundFunction(self.setMovieStatus,True)),))
			options.extend(((_("Mark as unseen..."), boundFunction(self.setMovieStatus,False)),))
		if self.filterMode != 9:
			options.extend(((_("Search..."), self.searchMovie),))
			for sorttype in config.plugins.videodb.moviesscreen_sortorder.choices.choices:
				options.extend(((sorttype[1], boundFunction(self.sortMovielist, sorttype[0])),))
			style = config.plugins.videodb.moviesscreen_style.value
			counter = 0
			while True:
				if style != counter:
					text = ""
					if counter == 0:
						text = _("Style: Poster Top")
					elif counter == 1:
						text = _("Style: Thumbs Top")
					elif counter == 2:
						text = _("Style: Thumbs Right")
					elif counter == 3:
						text = _("Style: Listbox High")
					elif counter == 4:
						text = _("Style: Coverflow 2D")
					elif counter == 5: # SimpleStyleMovies
						text = _("Style: Simple")
					options.extend(((text, boundFunction(self.setListView,counter)),))
				counter += 1
				if counter > 5:
					break
		#if not collection_selected:
		options.extend(((_("TMDb Pictures..."), self.tmdbPictures),))
		options.extend(((_("Show logs..."), self.showScanLog),))
		if self.filterMode != 9:
			if self.playlist_id > 0:
				options.extend(((_("Show regular movielist..."), self.showAllMovies),))
			options.extend(((_("Select playlists..."), self.showPlaylists),))
		options.extend(((_("Add selected movie to a playlist..."), self.addMovieToPlaylist),))
		options.extend(((_("Add files..."), self.addFiles),))
		self.session.openWithCallback(self.menuCallback, ChoiceBox,list = options)
		

	def menuCallback(self, ret):
		ret and ret[1]()
      
	def showAllMovies(self):
		self.playlist_id = -1
		self.buildList(-1, self.playlist_id) # fixme

	def showPlaylists(self):
		self.session.openWithCallback(self.playlistItemSelected, PlaylistItemSelection, None, True, True, is_dialog=True)
		
	def checkMoviesInPlaylist(self, playlist_id):
			if playlist_id == -1: return True
			connection = OpenDatabase(True, True)
			if connection is not None:
				cursor = connection.cursor()
				if playlist_id > 0:
					sql = "select movies.movie_id from movies inner join playlist_movies on movies.movie_id = playlist_movies.movie_id where playlist_movies.playlist_id = %d LIMIT 1;" % (playlist_id)
				elif playlist_id == -2: # recently added
					sql = 'select movies.movie_id from movies where (%d - strftime("%s", movies.modified)) <= %d LIMIT 1;' % (int(time.time()) , "%s", 86400*config.plugins.videodb.recently_added_days.value)
				elif playlist_id == -3: # show unseen
					if config.plugins.videodb.clientmovieposition.value:
						sql = "select movies.movie_id from movies LEFT OUTER JOIN client_movieposition ON movies.movie_id = client_movieposition.movie_id AND client_movieposition.client_id = %d where (((((client_movieposition.clientmovieposition/90000)*1.0)/movies.duration)*100.0 < %d.0) or client_movieposition.clientmovieposition IS NULL) LIMIT 1;" % (ClientID.instance.getClientID(), 95)
					else:
						sql = "select movies.movie_id from movies where (((((movies.movieposition/90000)*1.0)/movies.duration)*100.0 < %d.0) or movies.movieposition IS NULL) LIMIT 1;" % 95
				elif playlist_id == -4: # show collections
						sql = "Select tmdb_collection_id from Movie_Collections order by name LIMIT 1;"
				cursor.execute(sql)
				row = cursor.fetchone()
				cursor.close() 
				connection.close()
				return row
			return None
		
	def playlistItemSelected(self, value):
		if value is not None:
			if self.checkMoviesInPlaylist(int(value)):
				self.playlist_id = int(value)
				self.buildList(0, self.playlist_id) # fixme
			else:
				self.session.open(MessageBox, _("Could not find any movies in selected playlist. Playlist was not changed."), type = MessageBox.TYPE_INFO)
	
	def addMovieToPlaylist(self):
		cur = self.currentSelectedMovie
		if cur is not None:
			self.session.openWithCallback(self.addMovieToPlaylistPlaylistItemSelected, PlaylistItemSelection, self.last_used_playlist_id, False, False, _("Select playlist for movie"), is_dialog=True)
	
	def addMovieToPlaylistPlaylistItemSelected(self, value):
		cur = self.currentSelectedMovie
		if value and cur and self.playlist_id != int(value):
			self.last_used_playlist_id = int(value)
			connection, error = OpenDatabaseForWriting()
			if connection is not None:
				cursor = connection.cursor()
				collection_selected = cur is not None and cur.has_key("col_count") and (cur["col_count"] > 1 or self.playlist_id == -4)
				if collection_selected:
				      sql = "INSERT INTO Playlist_Movies (playlist_id,movie_id) select %d, movie_id from movies where tmdb_collection_id = %d and movie_id not in (select movie_id from Playlist_Movies where playlist_id = %d) order by movie_id;" % (int(value), cur["tmdb_collection_id"], int(value))
				else:  
				      sql = 'insert into playlist_movies (playlist_id, movie_id) values (%d,%d);' % (int(value), cur["movie_id"])
				try:
					cursor.execute(sql)
					connection.commit()
				except: # UNIQUE(playlist_id,movie_id) error?
					pass
				cursor.close()
				connection.close()

	def tmdbPictures(self):
		cur = self.currentSelectedMovie
		if cur is not None:
			options = []
			options.extend(((_("Wallpaper..."), boundFunction(self.tmdbPicturesSelectionCallback,DownloadTVDbPictures.WALLPAPER)),))
			options.extend(((_("Poster..."), boundFunction(self.tmdbPicturesSelectionCallback,DownloadTVDbPictures.POSTER)),))
			self.session.openWithCallback(self.menuCallback, ChoiceBox,title = _("Choose a type for TMDb pictures..."), list = options, titlebartext=_("TVDb pictures"))

	def tmdbPicturesSelectionCallback(self, bannertype):
		cur = self.currentSelectedMovie
		if cur is not None and cur.has_key("col_count") and (cur["col_count"] > 1 or self.playlist_id == -4):
			collection_selected = 1
		else:
			collection_selected = 0
		self.session.openWithCallback(self.downloadTMDbPicturesCallback, DownloadTMDbPictures, self.currentSelectedMovie, bannertype, collection_selected)
		
	def downloadTMDbPicturesCallback(self, value):
		pass
	      
	def deleteMovieCollection(self):
		cur = self.currentSelectedMovie
		if cur:
			self.session.openWithCallback(self.deleteMovieCollectionFromDatabase, MessageBox, _("Do you want to delete this movie collection (%s) from the database?") % (cur["Movie_Collections_name"]))

	def deleteMovieCollectionFromDatabase(self, confirmed):
		if confirmed:
			cur = self.currentSelectedMovie
			if cur:
				deleteMovieCollection(cur["tmdb_collection_id"])
				self.buildList(-1, self.playlist_id) # fixme
	


	def searchForTMDB(self):
		cur = self.currentSelectedMovie
		if cur:
			self.session.openWithCallback(self.searchForTMDBConfirmed, MessageBox, _("In order to search for new TMDB data for this movie, the current data have to be deleted...\nProceed?"))
			
	def deleteFromPlaylist(self):
		cur = self.currentSelectedMovie
		if cur:
			self.session.openWithCallback(self.deleteFromPlaylistConfirmed, MessageBox, _("You you really want to delete this movie from your playlist?"))
	
	def deleteFromPlaylistConfirmed(self, result):
		if result:
			cur = self.currentSelectedMovie
			if cur is not None and cur.has_key("col_count") and (cur["col_count"] > 1 or self.playlist_id == -4):
				connection, error = OpenDatabaseForWriting()
				if connection is not None:
					cursor = connection.cursor()
					cursor.execute('delete from Playlist_Movies where movie_id in (select movie_id from movies where tmdb_collection_id = %d);' % cur["tmdb_collection_id"])
					connection.commit()
					cursor.close()
					connection.close()
			elif cur:
				deleteMovieFromPlaylist(cur["movie_id"])
			if not self.checkMoviesInPlaylist(self.playlist_id):
				self.session.open(MessageBox, _("Could not find any movies in selected playlist. Playlist was changed to regular list."), type = MessageBox.TYPE_INFO)
				self.playlist_id = -1 # no movies are left in this view...skipping back to regular list
			self.buildList(-1, self.playlist_id) # fixme
			

	def searchForTMDBConfirmed(self, result):
		if result:
			cur = self.currentSelectedMovie
			if cur:
				if int(config.plugins.videodb.usePathNameForScanner.value) <= 1:
					self.searchForTMDBData(config.plugins.videodb.usePathNameForScanner.value == "1")
				else:
					self.session.openWithCallback( self.searchForTMDBData,MessageBox,_("Do you want to include the pathname with the filename for video-name detection?"), MessageBox.TYPE_YESNO)
		
	def searchForTMDBData(self, usepathdata):
		cur = self.currentSelectedMovie
		if cur:
			movieID = cur["movie_id"]
			row = self.getCurrentMovieData(movieID)
			if row:
				serviceid = row["serviceid"]
				old_eventID = row["event_id"]
				mpoint = row["mountpoint"]
				path = row["path"]
				metaData, eventID = deleteTMDbDataFromMovieInDatabase(movieID, old_eventID)
				if metaData is not None:
					indicator3D = config.plugins.videodb.Indicator3D.value
					if eventID != -1:
						beginTime = metaData.event.getBeginTime()
					else:
						beginTime = metaData.begin
					if usepathdata:
						searchTitle = os_path.join(mpoint,path,metaData.name.replace(indicator3D,''))
					else:
						searchTitle = metaData.name.replace(indicator3D,'')
					self.session.openWithCallback(self.callbackTMDBSelection, TMDbSelection,movieID, eventID, beginTime, searchTitle, serviceid)

	def callbackTMDBSelection(self, movieID):
		if movieID > 0 and self.playlist_id > 0:
		      connection, error = OpenDatabaseForWriting()
		      if connection is not None:
				connection.text_factory = str
				cursor = connection.cursor()
				try: # if the playlist has autofill=1, it was already added...
				    cursor.execute('INSERT INTO Playlist_Movies (playlist_id,movie_id) VALUES (%d,%d)' % (self.playlist_id,movieID))
				    connection.commit()
				except: pass
				cursor.close() 
				connection.close()
		self.buildList(-1, self.playlist_id)
		
	def addFiles(self):
		playlist_id = 0
		if self.playlist_id > 0:
			connection = OpenDatabase()
			if connection is not None:
				connection.text_factory = str
				connection.row_factory = self.dict_factory
				cursor = connection.cursor()
				sql = "select autofill from playlists where playlist_id= %d;" % (self.playlist_id)
				cursor.execute(sql)
				row = cursor.fetchone()
				cursor.close()  
				connection.close()
				if row and row["autofill"] == 0: # when autofill is not set for current playlist, make sure that this movie is going to be added....
					playlist_id = self.playlist_id
		self.session.openWithCallback(self.movieBrowserClosed, MovieBrowser, False, playlist_id=playlist_id)

	def showScanLog(self):
		self.session.openWithCallback(self.movieBrowserClosed, ScanLogs, False)
		
	def movieBrowserClosed(self, value):
		if value and value == 1:
			self.close(0)
		else:
			self.buildList(-1, self.playlist_id)

	def sortMovielist(self, sorttype):
		if self.playlist_id <= 0:
			config.plugins.videodb.moviesscreen_sortorder.setValue(sorttype)
			config.plugins.videodb.save()
		else:
			connection, error = OpenDatabaseForWriting()
			if connection is not None:
				cursor = connection.cursor()
				sql = 'update Playlists set sort_type=%d where playlist_id=%d;' % (int(sorttype), self.playlist_id)
				cursor.execute(sql)
				connection.commit()
				cursor.close()
				connection.close()
		self.buildList(-1, self.playlist_id)

	def searchMovie(self):
		if config.plugins.videodb.usevirtualkeyboard.value:
			self.session.openWithCallback(self.searchMovieCallback, VirtualKeyBoard, title = _("Enter search criteria for movie:"), text = "")
		else:
			self.session.openWithCallback(self.searchMovieCallback, TextInput, title = _("Enter search criteria for movie"), text = "")

	def searchMovieCallback(self, text = None):
		if text:
			self.searchTitle = text
			self.oldindex = self.index
			self.buildList(0, self.playlist_id)

	def setListView(self, value):
		config.plugins.videodb.moviesscreen_style.value = value
		config.plugins.videodb.save()
		self.close(1, self.index, self.playlist_id)


	def updateMoviePositionInList(self):
		cur = self.currentSelectedMovie
		connection = OpenDatabase()
		if connection is not None:
			connection.text_factory = str
			connection.row_factory = self.dict_factory
			cursor = connection.cursor()
			sql = "select movies.movie_id, movies.name, movies.description, movies.thumb_filename, movies.cover_middle_filename, cover_filename, movies.movieposition, movies.duration, movies.begin, movies.description, movies.filesize, movies.released, movies.rating,events.extdescription, movies.wallpaper, movies.dts, movies.ac3, movies.stereo, movies.hd, movies.widescreen, res_width, res_height, movies.framerate, movies.codec, movies.tmdb_movie_id, movies.tmdb_collection_id, client_movieposition.clientmovieposition FROM Movies LEFT OUTER JOIN Events ON movies.event_id = events.event_id LEFT OUTER JOIN client_movieposition ON movies.movie_id = client_movieposition.movie_id AND client_movieposition.client_id = %d where movies.movie_id = %d;" % (ClientID.instance.getClientID(), cur["movie_id"])
			cursor.execute(sql)
			row = cursor.fetchone()
			cursor.close()  
			connection.close()
			if row:
				self.updateList(row)
				self.currentSelectedMovie = row
				self.setMovieData()
				
	def callBackTwistedThread1(self, mode, movieID):
	      if mode == 1:
		return getTMDbWriters(movieID, False)
	      elif mode == 2:
		return getTMDbActors(movieID, False)
	      else:
		return getTMDbDirectors(movieID, False)      

	def twistedResult(self, mode, result):
	      if mode == 1:
		  self["writer"].setText(result)
	      elif mode == 2:
		  self["actors"].setText(result)
	      else:
		  self["director"].setText(result)
	      
	def setMovieData(self):
		if self.currentSelectedMovie:
			self["title"].setText(self.currentSelectedMovie["name"].upper())
			movieID = self.currentSelectedMovie["movie_id"]
			deferToThread(boundFunction(self.callBackTwistedThread1,1,movieID)).addCallback(boundFunction(self.twistedResult,1))
			deferToThread(boundFunction(self.callBackTwistedThread1,2,movieID)).addCallback(boundFunction(self.twistedResult,2))
			deferToThread(boundFunction(self.callBackTwistedThread1,3,movieID)).addCallback(boundFunction(self.twistedResult,3))
			if self.currentSelectedMovie["description"]:
				self["genre"].setText(self.currentSelectedMovie["description"])
			else:
 				self["genre"].setText("")

			if self.currentSelectedMovie["released"]:
				self["year"].setText(self.currentSelectedMovie["released"][:4])
			else:
 				self["year"].setText("")

			if self.currentSelectedMovie["rating"] != "":
				self["rating"].setText("%s / 10" % self.currentSelectedMovie["rating"])
				rating = float(self.currentSelectedMovie["rating"]) * 10
				self["rating_stars"].setValue(int(rating))
				self["rating_stars"].show()
			else:
 				self["rating"].setText("")
				self["rating_stars"].hide()

			duration = self.currentSelectedMovie["duration"]
			currentPosition = 0
			if config.plugins.videodb.clientmovieposition.value:
				if self.currentSelectedMovie["clientmovieposition"] is not None:
					currentPosition = self.currentSelectedMovie["clientmovieposition"]
			else:
				currentPosition = self.currentSelectedMovie["movieposition"]
			if duration:
				self["duration"].setText("%02d:%02d:%02d" % (duration/3600, duration%3600/60, duration%60))
			else:
 				self["duration"].setText("")
			currentPoint = currentPosition / 90000
			self["position"].setText("%02d:%02d:%02d" % (currentPoint/3600, currentPoint%3600/60, currentPoint%60))

			if currentPosition >0 and duration:
				percent = int((float(currentPosition)  / 90000 / float(duration)) * 100);
			else:
				percent = 0
			if percent > 100: # FIXME: i dont know why movieposition can contain weird data values...
				percent = 100
			self["position_progress"].setValue(percent)
			
			if self.currentSelectedMovie["dts"] == 1:
				self["audio_icons"].setPixmapNum(0)
			elif self.currentSelectedMovie["ac3"] == 1:
				self["audio_icons"].setPixmapNum(1)
			elif self.currentSelectedMovie["stereo"] == 1:
				self["audio_icons"].setPixmapNum(2)
			if self.currentSelectedMovie["dts"] or self.currentSelectedMovie["ac3"] or self.currentSelectedMovie["stereo"]:
				self["audio_icons"].show()
			else:
				self["audio_icons"].hide()

			if self.currentSelectedMovie["hd"] == 1:
				self["definition"].setPixmapNum(0)
			else:
				self["definition"].setPixmapNum(1)

			if self.currentSelectedMovie["widescreen"] == 1:
				self["resolution"].setPixmapNum(0)
			else:
				self["resolution"].setPixmapNum(1)

			self["res"].setText("%d x %d" % (self.currentSelectedMovie["res_width"], self.currentSelectedMovie["res_height"]))
			
			
			self["framerate"].setText("%.3f frame rate" % self.currentSelectedMovie["framerate"])
			self["codec"].setText(self.currentSelectedMovie["codec"].replace("video","").upper())
			

		
			

class PosterwallTop(Screen, VideoBase, MoviesBase):

	
	skin = """
		<screen name="PosterwallTop" position="0,0" size="1280,720" flags="wfNoBorder" title="Movies" backgroundColor="#000000">
				<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/line_1pix-fs8.png" position="0,490" size="1280,2" alphatest="on" />
				<widget name="title" font="Regular;20" position="50,500" size="540,40" transparent="0"  foregroundColor="#bcbbbb" backgroundColor="#000000" zPosition="9" />
				<widget name="page" font="Regular;16" position="1170,500" size="80,30" halign="right" transparent="0"  foregroundColor="#8a8a8a" backgroundColor="#000000" zPosition="9" />
				<eLabel text="GENRES" position="50,540" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#000000" />
				<widget name="genre" position="50,565" size="300,45" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#000000" />
				<eLabel text="YEAR" position="50,620" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#000000" />
				<widget name="year" position="50,645" size="200,20" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#000000" />
				<eLabel text="DURATION" position="380,540" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#000000" />
				<widget name="duration" position="380,565" size="250,40" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#000000" />
				<eLabel text="LAST POSITION" position="380,620" size="300,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#000000" />
				<widget name="position" position="380,645" size="200,20" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#000000" />
				<widget name="position_progress" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/progress-fs8.png" zPosition="3" position="380,675" size="50,12" transparent="0" backgroundColor="#000000" borderColor="#004051" borderWidth="1" orientation="orHorizontal" />
				<eLabel text="DIRECTOR" position="580,540" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#000000" />
				<widget name="director" position="580,565" size="300,45" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#000000" />
				<eLabel text="WRITER" position="580,620" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#000000" />
				<widget name="writer" position="580,645" size="300,45" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#000000" />
				<eLabel text="ACTORS" position="930,540" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#000000" />
				<widget name="actors" position="930,565" size="300,45" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#000000" />
				<eLabel text="RATING" position="930,620" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#000000" />
				<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/five_stars_middle_size-fs8.png" position="930,645" size="114,22" alphatest="on" />
				<widget name="rating_stars" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/five_stars_full_middle_size-fs8.png" zPosition="3" position="930,645" size="114,22" transparent="1" borderWidth="0" orientation="orHorizontal" />
				<widget name="rating" position="1060,647" size="200,20" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#000000" />
				<widget name="audio_icons" pixmaps="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/dts1.png,/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/ac3.png,/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/stereo.png" position="600,500" size="85,30" transparent="0" alphatest="blend" zPosition="3"/>
			<widget name="definition" pixmaps="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/hd.png,/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/sd.png" position="690,500" size="51,30" transparent="0" alphatest="blend" zPosition="3"/>
			<widget name="resolution" pixmaps="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/wide.png,/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/4_3.png" position="750,500" size="51,30" transparent="0" alphatest="blend" zPosition="3"/>
			<widget name="res" position="805,500" size="110,30" zPosition="4" font="Regular;18" halign="center" valign="center" transparent="0"  foregroundColor="#d8a710" backgroundColor="#000000"/>
			<widget name="framerate" position="915,500" size="170,30" zPosition="3" font="Regular;18" halign="center" valign="center" transparent="0" foregroundColor="#d8a710" backgroundColor="#000000" />
			<widget name="codec" position="1085,500" size="100,30" zPosition="3" font="Regular;18" halign="left" valign="center" transparent="0" foregroundColor="#d8a710" backgroundColor="#000000" />
			<widget name="playlist" position="50,680" size="1180,20" zPosition="10" font="Regular;16" transparent="1" foregroundColor="#8a8a8a" backgroundColor="#000000"/>
			<widget name="col_widget" position="0,500" size="1280,220" transparent="0" foregroundColor="#bcbbbb" backgroundColor="#000000" zPosition="8" />
			<widget name="col_overview" font="Regular;24" position="50,550" size="1180,170" transparent="0"  foregroundColor="#bcbbbb" backgroundColor="#000000" zPosition="9" />
			
			
			<widget name="covercollection" position="0,0" size="1280,480" transparent="1" zPosition="10" backgroundColor="#55000000" coverSize="120,177" selectedCoverScale="1.5" unselectedCoverDimm="0.4" coverBeginPosition="175,155" coverDistance="13,13" style="0" noCoverAvailablePic="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/no_poster.jpg" />
			
			
		</screen>"""
		
	# 1920 x 1080 Skin values...
	#<widget name="covercollection" position="0,0" size="1920,800" transparent="0" zPosition="10" backgroundColor="#000000" coverSize="185,278" selectedCoverScale="1.5" unselectedCoverDimm="0.4" coverBeginPosition="175,155" coverDistance="23,23" style="0" noCoverAvailablePic="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/no_poster.jpg" />


	def __init__(self, session, start_index, playlist_id):
		Screen.__init__(self, session)
		self.session = session
		self.start_index = start_index
		VideoBase.__init__(self)
		MoviesBase.__init__(self)
		self.playlist_id = playlist_id

		self.onLayoutFinish.append(self.startRun)
		self.currentSelectedMovie = None

		self["poster"] = MoviePoster()
		self["poster"].hide()

		self["page"] = Label("")
		
		
		self["col_poster"] = VideoDBPictureBox()
		
		self["covercollection"] = CoverCollection()
		
		
		self["posteractions"] = ActionMap(["WizardActions", "MediaPlayerActions", "EPGSelectActions", "MediaPlayerSeekActions", "ColorActions"],
		{
			"left": self.left,
			"right": self.right,
			"down": self.down,
			"up": self.up,
			"nextBouquet": self.nextpage,
			"prevBouquet": self.previouspage,
		}, -1)

		
		

		self.connectSelChangedTimer = eTimer()
		self.connectSelChangedTimer_Connection = self.connectSelChangedTimer.timeout.connect(self.videoDescriptionUpdate)
		
		
	def left(self):
	      self["covercollection"].MoveLeft()
	      
	def right(self):
	      self["covercollection"].MoveRight()	      
	      
	def down(self):
	      self["covercollection"].MoveDown()
	  
	def up(self):
	      self["covercollection"].MoveUp()
	
	def nextpage(self):
	      self["covercollection"].NextPage()
	      
	def previouspage(self):
	      self["covercollection"].PreviousPage()
		

	def startRun(self):
		self["covercollection"].connectSelChanged(self.listSelChanged)
		self.buildList(self.start_index, self.playlist_id)
		self.videoDescriptionUpdate()		
		
	def buildList(self, currentIndex, playlist_id=-1):
		movieID = 0
		showCollectionsinMovielist = config.plugins.videodb.showCollectionsinMovielist.value
		if playlist_id == -4: #show collections
			showCollectionsinMovielist = True
		if currentIndex == -1:
			cur = self.currentSelectedMovie
			if cur:
				movieID = cur["movie_id"]
			currentIndex = 0
		elif currentIndex == -2:
			movieID = config.plugins.videodb.lastPlayedMovieID.value
			currentIndex = 0
		self.currentSelectedMovie = None
		if self.filterMode == 9: # collections
			sqlOrder = "ORDER BY movies.released"
		else:
			sortType = 0
			if playlist_id > 0:
				connection = OpenDatabase(True, True)
				if connection is not None:
					cursor = connection.cursor()
					sql = "select sort_type from playlists where playlist_id = %d;" % playlist_id
					cursor.execute(sql)
					row = cursor.fetchone()
					if row:
					      sortType = str(row["sort_type"])
			else:
				sortType = config.plugins.videodb.moviesscreen_sortorder.value
			sqlOrder = ""
			if sortType == "0":
				sqlOrder = "ORDER BY movies.begin DESC"
			elif sortType == "1":
				sqlOrder = "ORDER BY movies.begin"
			elif sortType == "2":
				if self.searchTitle != "" or showCollectionsinMovielist == False:
					sqlOrder = "ORDER BY movies.name COLLATE NOCASE DESC"
				else:
					sqlOrder = "ORDER BY sortname COLLATE NOCASE DESC"
			elif sortType == "3":
				if self.searchTitle != "" or showCollectionsinMovielist == False:
					sqlOrder = "ORDER BY movies.name COLLATE NOCASE"
				else:
					sqlOrder = "ORDER BY sortname COLLATE NOCASE"

		if self.searchTitle != "":
			sqlWhere = sqlWhere = 'and (movies.name like "%' + self.searchTitle.replace('"','""') + '%" or movies.description like "%' + self.searchTitle.replace('"','""') + '%" or events.extdescription like "%' + self.searchTitle.replace('"','""') + '%")'
		else:
			sqlWhere = ""
		
		if self.filterTagID is not None:
			sqlFilterInnerJoin = self.sqlFilterInnerJoin 
			sqlWhere = sqlWhere + self.sqlFilterWhere
		else:
			sqlFilterInnerJoin = ""


		posterlist = []
		
		self.playlist_id = playlist_id
		if self.playlist_id == -4: # show collections
			sqlInnerJoinPlaylists = ""
			sqlWherePlaylists = 'and movies.tmdb_collection_id != 0'
		elif self.playlist_id == -3: # show unseen
			sqlInnerJoinPlaylists = ""
			if config.plugins.videodb.clientmovieposition.value:
				sqlWherePlaylists = "and (((((client_movieposition.clientmovieposition/90000)*1.0)/movies.duration)*100.0 < %d.0) or client_movieposition.clientmovieposition IS NULL)" % 95
			else:
				sqlWherePlaylists = "and (((((movies.movieposition/90000)*1.0)/movies.duration)*100.0 < %d.0) or movies.movieposition IS NULL)" % 95
		elif self.playlist_id == -2: # recently added
			sqlInnerJoinPlaylists = ""
			sqlWherePlaylists = 'and (%d - strftime("%s", movies.modified)) <= %d' % (int(time.time()) , "%s", 86400*config.plugins.videodb.recently_added_days.value)
		elif self.playlist_id != -1: # playlist
			sqlInnerJoinPlaylists = "inner join playlist_movies on movies.movie_id = playlist_movies.movie_id"
			sqlWherePlaylists = "and playlist_movies.playlist_id = %d" % self.playlist_id
		else: # standard -> all
			sqlInnerJoinPlaylists = ""
			sqlWherePlaylists = ""
		
		

		connection = OpenDatabase()
		if connection is not None:
			connection.text_factory = str
			connection.row_factory = self.dict_factory
			cursor = connection.cursor()
			if self.filterMode == 9 or self.searchTitle != "" or showCollectionsinMovielist == False:
				sql = "select movies.movie_id, movies.name, movies.description, movies.thumb_filename, cover_middle_filename, cover_filename, movies.movieposition, movies.duration, movies.begin, movies.description, movies.filesize, movies.released, movies.rating, events.extdescription, movies.wallpaper, movies.dts, movies.ac3, movies.stereo, movies.hd, movies.widescreen, res_width, res_height, movies.framerate, movies.codec, movies.tmdb_movie_id, movies.tmdb_collection_id, client_movieposition.clientmovieposition FROM Movies LEFT OUTER JOIN Events ON movies.event_id = events.event_id LEFT OUTER JOIN client_movieposition ON movies.movie_id = client_movieposition.movie_id AND client_movieposition.client_id = %d %s %s where movies.tmdb_movie_id is not null %s %s %s;" % (ClientID.instance.getClientID(), sqlFilterInnerJoin, sqlInnerJoinPlaylists, sqlWhere, sqlWherePlaylists, sqlOrder)
			else:
				if self.playlist_id == -4: # show collections
					col_count = 0 # always sort for Movie_Collections.Name
				else:
					col_count = 1 # if movie is a collection but only with one movie use movies.name for sorting
				sql = "select movies.movie_id as movie_id, movies.name as name, movies.description as description, movies.thumb_filename as thumb_filename, movies.cover_middle_filename as cover_middle_filename, movies.cover_filename as cover_filename, movies.movieposition as movieposition, movies.duration as duration, movies.begin as begin, movies.description as description, movies.filesize as filesize, movies.released as released, movies.rating as rating, events.extdescription as extdescription, movies.wallpaper as wallpaper, movies.dts as dts, movies.ac3 as ac3, movies.stereo as stereo, movies.hd as hd, movies.widescreen as widescreen, res_width, res_height, movies.framerate as framerate, movies.codec as codec, movies.tmdb_movie_id as tmdb_movie_id, movies.tmdb_collection_id as tmdb_collection_id, 0 AS col_count, '' as Movie_Collections_wallpaper, '' as Movie_Collections_thumb_filename, '' as Movie_Collections_cover_middle_filename, '' as Movie_Collections_cover_filename, '' as Movie_Collections_name, '' as Movie_Collections_overview, client_movieposition.clientmovieposition as clientmovieposition, movies.name as sortname FROM Movies LEFT OUTER JOIN Events ON movies.event_id = events.event_id LEFT OUTER JOIN client_movieposition ON movies.movie_id = client_movieposition.movie_id AND client_movieposition.client_id = %d %s %s where movies.tmdb_movie_id is not null and movies.tmdb_collection_id = 0 %s %s UNION ALL select movies.movie_id, movies.name, movies.description, movies.thumb_filename, movies.cover_middle_filename, movies.cover_filename, movies.movieposition, movies.duration, movies.begin, movies.description, movies.filesize, movies.released, movies.rating, events.extdescription, movies.wallpaper, movies.dts, movies.ac3, movies.stereo, movies.hd, movies.widescreen, res_width, res_height, movies.framerate, movies.codec, movies.tmdb_movie_id, movies.tmdb_collection_id, count(movies.movie_id) AS col_count, Movie_Collections.wallpaper as Movie_Collections_wallpaper, Movie_Collections.thumb_filename as Movie_Collections_humb_filename, Movie_Collections.cover_middle_filename as Movie_Collections_cover_middle_filename, Movie_Collections.cover_filename as Movie_Collections_cover_filename, Movie_Collections.name as Movie_Collections_name, Movie_Collections.overview as Movie_Collections_overview, client_movieposition.clientmovieposition as clientmovieposition, case when count(movies.movie_id) <= %d then movies.name else movie_collections.name END as sortname FROM Movies LEFT OUTER JOIN Events ON movies.event_id = events.event_id LEFT OUTER JOIN client_movieposition ON movies.movie_id = client_movieposition.movie_id AND client_movieposition.client_id = %d %s %s LEFT OUTER JOIN Movie_Collections ON movies.tmdb_collection_id = Movie_Collections.tmdb_collection_id where movies.tmdb_movie_id is not null and movies.tmdb_collection_id <> 0 %s %s GROUP BY movies.tmdb_collection_id %s;" % (ClientID.instance.getClientID(), sqlFilterInnerJoin, sqlInnerJoinPlaylists, sqlWhere, sqlWherePlaylists,  col_count, ClientID.instance.getClientID(), sqlFilterInnerJoin, sqlInnerJoinPlaylists, sqlWhere, sqlWherePlaylists, sqlOrder)
			cursor.execute(sql)
			list = []
			index=0
			for row in cursor:
				if movieID and movieID == row["movie_id"]:
					currentIndex = index
				list.append(((row),))
				if row.has_key("Movie_Collections_cover_filename") and row.has_key("col_count") and (row["col_count"] > 1  or self.playlist_id == -4):
				    if row["Movie_Collections_cover_filename"]:
					    posterlist.append(os_path.join(self.imagePath, row["Movie_Collections_cover_filename"]))
				    else:
					    posterlist.append("")
				else:
				    if row["cover_filename"]:
					    posterlist.append(os_path.join(self.imagePath, row["cover_filename"]))
				    else:
					    posterlist.append("")
				index+=1
			self["covercollection"].setList(list,posterlist,currentIndex)
			self.index = self["covercollection"].getCurrentIndex()
			if self.playlist_id > 0:
				cursor.execute("Select playlist_text from Playlists where playlist_id=%d;" % self.playlist_id)
				row = cursor.fetchone()
				self["playlist"].setText(_("Playlist:") + " " + row["playlist_text"])
			else:
				if self.playlist_id == -4:
					self["playlist"].setText(_("Playlist:") +  " " + _("Movie Collections"))
				elif self.playlist_id == -3:
					self["playlist"].setText(_("Playlist:") +  " " + _("Unseen"))
				elif self.playlist_id == -2:
					self["playlist"].setText(_("Playlist:") +  " " + _("Recently added"))
				else:
					self["playlist"].setText("")
			cursor.close() 
			connection.close()
			self.setPageInfo()
			self.currentSelectedMovie = self["covercollection"].getCurrent()

	def setPageInfo(self):
		self["page"].setText(_("Page %d/%d") % (self["covercollection"].getCurrentPage(), self["covercollection"].getTotalPages()))

	def listSelChanged(self, index):
		self.index = index
		self.setPageInfo()
		self.connectSelChangedTimer.start(300, True)

	def videoDescriptionUpdate(self):
		cur = self.currentSelectedMovie = self["covercollection"].getCurrent()
		if cur:
			self.currentIndex = self["covercollection"].getCurrentIndex()
			if not cur.has_key("col_count") or (cur.has_key("col_count") and cur["col_count"] < 2 and self.playlist_id != -4):
				self["col_widget"].hide()
				self["col_poster"].hide()
				self["col_overview"].hide()
				filename = ""
				if cur["wallpaper"]:
					filename = os_path.join(self.imagePath, cur["wallpaper"])
				if os_path.exists(filename):
					self.ref = eServiceReference(0x1013, 0, filename)
				else:
					self.ref = eServiceReference(0x1013, 0, DEFAULT_WALLPAPER)
				self.session.nav.playService(self.ref)
				self.setMovieData()
			else:
				self["col_widget"].show()
				self["col_poster"].show()
				self["col_overview"].show()
				self["title"].setText(cur["Movie_Collections_name"].upper())
				if cur["Movie_Collections_overview"] and cur["Movie_Collections_overview"] != "None":
					self["col_overview"].setText(cur["Movie_Collections_overview"])
				else:
					self["col_overview"].setText("")
				filename = ""
				if cur["Movie_Collections_wallpaper"]:
					filename = os_path.join(self.imagePath, cur["Movie_Collections_wallpaper"])
				if os_path.exists(filename):
					self.ref = eServiceReference(0x1013, 0, filename)
				else:
					self.ref = eServiceReference(0x1013, 0, DEFAULT_WALLPAPER)
				self.session.nav.playService(self.ref)

	def updateList(self, row):	
		self["covercollection"].updateRowData(row)
		self.setMovieData()

	def nextMovie(self):
		self["covercollection"].MoveDown()
		self.currentSelectedMovie = self["covercollection"].getCurrent()

	def previousMovie(self):
		self["covercollection"].MoveUp()
		self.currentSelectedMovie = self["covercollection"].getCurrent()

	def downloadTMDbPicturesCallback(self, value):
		if value:
			self.buildList(self["covercollection"].getCurrentIndex(), self.playlist_id)
			
class PosterwallTopThumb(PosterwallTop):

	skin = """
		<screen name="PosterwallTopThumb" position="0,0" size="1280,720" flags="wfNoBorder" title="Movies" backgroundColor="#000000">
				<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/line_1pix-fs8.png" position="0,490" size="1280,2" alphatest="on" />
				<widget name="title" font="Regular;20" position="50,500" size="540,40" transparent="0"  foregroundColor="#bcbbbb" backgroundColor="#000000" zPosition="9" />
				<widget name="page" font="Regular;16" position="1170,500" size="80,30" halign="right" transparent="0"  foregroundColor="#8a8a8a" backgroundColor="#000000" zPosition="9" />
				<eLabel text="GENRES" position="50,540" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#000000" />
				<widget name="genre" position="50,565" size="300,45" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#000000" />
				<eLabel text="YEAR" position="50,620" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#000000" />
				<widget name="year" position="50,645" size="200,20" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#000000" />
				<eLabel text="DURATION" position="380,540" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#000000" />
				<widget name="duration" position="380,565" size="250,40" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#000000" />
				<eLabel text="LAST POSITION" position="380,620" size="300,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#000000" />
				<widget name="position" position="380,645" size="200,20" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#000000" />
				<widget name="position_progress" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/progress-fs8.png" zPosition="3" position="380,675" size="50,12" transparent="0" backgroundColor="#000000" borderColor="#004051" borderWidth="1" orientation="orHorizontal" />
				<eLabel text="DIRECTOR" position="580,540" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#000000" />
				<widget name="director" position="580,565" size="300,45" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#000000" />
				<eLabel text="WRITER" position="580,620" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#000000" />
				<widget name="writer" position="580,645" size="300,45" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#000000" />
				<eLabel text="ACTORS" position="930,540" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#000000" />
				<widget name="actors" position="930,565" size="300,45" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#000000" />
				<eLabel text="RATING" position="930,620" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#000000" />
				<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/five_stars_middle_size-fs8.png" position="930,645" size="114,22" alphatest="on" />
				<widget name="rating_stars" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/five_stars_full_middle_size-fs8.png" zPosition="3" position="930,645" size="114,22" transparent="1" borderWidth="0" orientation="orHorizontal" />
				<widget name="rating" position="1060,647" size="200,20" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#000000" />
				<widget name="audio_icons" pixmaps="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/dts1.png,/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/ac3.png,/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/stereo.png" position="600,500" size="85,30" transparent="0" alphatest="blend" zPosition="3"/>
			<widget name="definition" pixmaps="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/hd.png,/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/sd.png" position="690,500" size="51,30" transparent="0" alphatest="blend" zPosition="3"/>
			<widget name="resolution" pixmaps="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/wide.png,/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/4_3.png" position="750,500" size="51,30" transparent="0" alphatest="blend" zPosition="3"/>
			<widget name="res" position="805,500" size="110,30" zPosition="4" font="Regular;18" halign="center" valign="center" transparent="0"  foregroundColor="#d8a710" backgroundColor="#000000"/>
			<widget name="framerate" position="915,500" size="170,30" zPosition="3" font="Regular;18" halign="center" valign="center" transparent="0" foregroundColor="#d8a710" backgroundColor="#000000" />
			<widget name="codec" position="1085,500" size="100,30" zPosition="3" font="Regular;18" halign="left" valign="center" transparent="0" foregroundColor="#d8a710" backgroundColor="#000000" />
			<widget name="playlist" position="50,680" size="1180,20" zPosition="10" font="Regular;16" transparent="1" foregroundColor="#8a8a8a" backgroundColor="#000000"/>
			<widget name="col_widget" position="0,500" size="1280,220" transparent="0"  foregroundColor="#bcbbbb" backgroundColor="#000000" zPosition="8" />
			<widget name="col_overview" font="Regular;24" position="50,550" size="1180,170" transparent="0"  foregroundColor="#bcbbbb" backgroundColor="#000000" zPosition="9" />
			
			
			<widget name="covercollection" position="0,0" size="1280,480" transparent="1" zPosition="10" backgroundColor="#55000000" coverSize="92,138" selectedCoverScale="1.4" unselectedCoverDimm="0.4" coverBeginPosition="125,110" coverDistance="2,2" style="0" noCoverAvailablePic="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/no_poster.jpg" />
			
			
		</screen>"""
		# 1920 Skin! Poster Thumb: <widget name="covercollection" position="0,0" size="1920,800" transparent="1" zPosition="10" backgroundColor="#55000000" coverSize="120,177" selectedCoverScale="1.5" unselectedCoverDimm="0.4" coverBeginPosition="175,155" coverDistance="23,23" style="0" noCoverAvailablePic="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/no_poster.jpg" />

class PosterwallTopThumbRight(PosterwallTop):

	skin = """
		<screen name="PosterwallTopThumbRight" position="0,0" size="1280,720" flags="wfNoBorder" title="Movies" backgroundColor="#ff000000">
				<eLabel backgroundColor="#55000000" position="0,210" size="1280,510"  zPosition="-1"/>
				<widget name="title" font="Regular;24" position="50,225" size="650,50" transparent="0"  foregroundColor="#bcbbbb" backgroundColor="#55000000" />
				<widget name="audio_icons" pixmaps="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/dts1.png,/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/ac3.png,/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/stereo.png" position="50,285" size="85,30" transparent="0" alphatest="blend" zPosition="3"/>
				<widget name="definition" pixmaps="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/hd.png,/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/sd.png" position="145,285" size="51,30" transparent="0" alphatest="blend" zPosition="3"/>
				<widget name="resolution" pixmaps="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/wide.png,/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/4_3.png" position="201,285" size="51,30" transparent="0" alphatest="blend" zPosition="3"/>
				<widget name="res" position="260,285" size="110,30" zPosition="4" font="Regular;18" halign="left" valign="center" transparent="0"  foregroundColor="#d8a710" backgroundColor="#55000000"/>
				<widget name="framerate" position="370,285" size="170,30" zPosition="3" font="Regular;18" halign="left" valign="center" transparent="0" foregroundColor="#d8a710" backgroundColor="#55000000" />
				
				<widget name="codec" position="260,310" size="100,30" zPosition="3" font="Regular;18" halign="left" valign="center" transparent="0" foregroundColor="#d8a710" backgroundColor="#55000000" />
				<eLabel text="RATING" position="50,320" size="100,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
				<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/five_stars_middle_size-fs8.png" position="50,345" size="114,22" alphatest="blend" />
				<widget name="rating_stars" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/five_stars_full_middle_size-fs8.png" zPosition="3" position="50,345" size="114,22" transparent="1" borderWidth="0" orientation="orHorizontal"/>
				<widget name="rating" position="180,347" size="200,20" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#55000000" />
				<eLabel text="GENRES" position="50,380" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
				<widget name="genre" position="50,405" size="480,22" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#55000000" />
				<eLabel text="YEAR" position="50,440" size="100,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
				<widget name="year" position="50,465" size="100,20" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#55000000" />
				<eLabel text="DURATION" position="150,440" size="120,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
				<widget name="duration" position="150,465" size="120,22" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#55000000" />
				<eLabel text="LAST POSITION" position="290,440" size="180,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
				<widget name="position" position="290,465" size="85,20" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#55000000" />
				<widget name="position_progress" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/progress-fs8.png" zPosition="3" position="360,469" size="50,12" transparent="0" backgroundColor="#55000000" borderColor="#004051" borderWidth="1" orientation="orHorizontal" />				
				<eLabel text="DIRECTOR" position="50,500" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
				<widget name="director" position="50,525" size="480,22" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#55000000" />
				<eLabel text="WRITER" position="50,560" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
				<widget name="writer" position="50,585" size="480,22" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#55000000" />
				<eLabel text="ACTORS" position="50,620" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
				<widget name="actors" position="50,645" size="480,22" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#55000000" />
				<widget name="playlist" position="50,680" size="1180,20" zPosition="10" font="Regular;16" transparent="1" foregroundColor="#8a8a8a" backgroundColor="#55000000"/>
				<widget name="col_widget" position="0,275" size="530,445" transparent="0"  foregroundColor="#bcbbbb" backgroundColor="#55000000" zPosition="8" />
				<widget name="col_overview" font="Regular;24" position="50,285" size="500,350" transparent="0"  foregroundColor="#bcbbbb" backgroundColor="#55000000" zPosition="9" />
				<widget name="playlist" position="50,680" size="500,20" zPosition="3" font="Regular;16" transparent="1" foregroundColor="#8a8a8a" />
				<widget name="covercollection" position="530,210" size="770,510" transparent="0" zPosition="10" backgroundColor="#55000000" coverSize="92,138" selectedCoverScale="1.5" unselectedCoverDimm="0.4" coverBeginPosition="70,105" coverDistance="3,3"  style="0" noCoverAvailablePic="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/no_poster.jpg"/>
			</screen>"""
			# 1920 Skin! Poster Thumb: <widget name="covercollection" position="0,0" size="1920,800" transparent="1" zPosition="10" backgroundColor="#55000000" coverSize="120,177" selectedCoverScale="1.5" unselectedCoverDimm="0.4" coverBeginPosition="175,155" coverDistance="23,23" style="0" noCoverAvailablePic="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/no_poster.jpg"/>
			
class CoverflowPosterMovies(PosterwallTop):

	skin = """
		<screen name="CoverflowPosterMovies" position="0,0" size="1280,720" flags="wfNoBorder" title="Movies" backgroundColor="#ff000000">
			<eLabel backgroundColor="#55000000" position="0,0" size="1280,70"  zPosition="-1"/>
			<widget name="title" font="Regular;20" position="50,30" size="590,40" transparent="0"  foregroundColor="#bcbbbb" backgroundColor="#55000000" zPosition="5" />
			<widget name="audio_icons" pixmaps="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/dts1.png,/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/ac3.png,/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/stereo.png" position="650,27" size="85,30" transparent="0" alphatest="blend" zPosition="3"/>
			<widget name="definition" pixmaps="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/hd.png,/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/sd.png" position="740,27" size="51,30" transparent="0" alphatest="blend" zPosition="3"/>
			<widget name="resolution" pixmaps="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/wide.png,/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/4_3.png" position="800,27" size="51,30" transparent="0" alphatest="blend" zPosition="3"/>
			<widget name="res" position="855,30" size="110,30" zPosition="4" font="Regular;18" halign="center" valign="center" transparent="0"  foregroundColor="#d8a710" backgroundColor="#55000000"/>
			<widget name="framerate" position="965,30" size="170,30" zPosition="3" font="Regular;18" halign="center" valign="center" transparent="0" foregroundColor="#d8a710" backgroundColor="#55000000" />
			<widget name="codec" position="1130,30" size="100,30" zPosition="3" font="Regular;18" halign="right" valign="center" transparent="0" foregroundColor="#d8a710" backgroundColor="#55000000" />
			<widget name="page" font="Regular;16" position="1170,659" size="110,20" halign="left" transparent="0"  foregroundColor="#8a8a8a" backgroundColor="#55000000" zPosition="4" />
			<widget name="col_widget" position="640,0" size="640,70" transparent="0"  foregroundColor="#bcbbbb" backgroundColor="#55000000" zPosition="8" />
			<widget name="playlist" position="50,680" size="1180,20" zPosition="10" font="Regular;16" transparent="1" foregroundColor="#8a8a8a" backgroundColor="#000000"/>
			<widget name="covercollection" position="0,400" size="1280,320" transparent="0" zPosition="9" backgroundColor="#55000000" coverSize="133,200" selectedCoverScale="1.5" unselectedCoverDimm="0.4"  coverflowCurrentPosition="640,153" coverflowCurrentXDistance="13" coverflowCurrentCenterDistance="60" style="1" noCoverAvailablePic="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/no_poster.jpg" />
		</screen>"""
	
	# 1920 Skin Coverflow
	#<widget name="covercollection" position="0,660" size="1920,420" transparent="0" zPosition="10" backgroundColor="#55000000" coverSize="185,278" selectedCoverScale="1.3" unselectedCoverDimm="0.4"  coverflowCurrentPosition="960,210" coverflowCurrentXDistance="23" coverflowCurrentCenterDistance="80" style="1" noCoverAvailablePic="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/no_poster.jpg" />	
	

class HighListMovies(Screen, VideoBase, MoviesBase):

	skin = """
		<screen name="HighListMovies" position="0,0" size="1280,720" flags="wfNoBorder" title="Movies" backgroundColor="#ff000000">
			<eLabel backgroundColor="#55000000" position="0,210" size="1280,510"  zPosition="-1"/>
			<widget name="title" font="Regular;24" position="50,225" size="650,50" transparent="0"  foregroundColor="#bcbbbb" backgroundColor="#55000000" />
			<widget name="audio_icons" pixmaps="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/dts1.png,/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/ac3.png,/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/stereo.png" position="50,285" size="85,30" transparent="0" alphatest="blend" zPosition="3"/>
			<widget name="definition" pixmaps="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/hd.png,/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/sd.png" position="145,285" size="51,30" transparent="0" alphatest="blend" zPosition="3"/>
			<widget name="resolution" pixmaps="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/wide.png,/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/4_3.png" position="201,285" size="51,30" transparent="0" alphatest="blend" zPosition="3"/>
			<widget name="res" position="260,285" size="130,30" zPosition="4" font="Regular;20" halign="center" valign="center" transparent="0"  foregroundColor="#d8a710" backgroundColor="#55000000"/>
			<widget name="framerate" position="400,285" size="190,30" zPosition="3" font="Regular;20" halign="center" valign="center" transparent="0" foregroundColor="#d8a710" backgroundColor="#55000000" />
			<widget name="codec" position="590,285" size="130,30" zPosition="3" font="Regular;20" halign="center" valign="center" transparent="0" foregroundColor="#d8a710" backgroundColor="#55000000" />
			<eLabel text="RATING" position="50,320" size="100,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/five_stars_middle_size-fs8.png" position="50,345" size="114,22" alphatest="blend" />
			<widget name="rating_stars" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/five_stars_full_middle_size-fs8.png" zPosition="3" position="50,345" size="114,22" transparent="1" borderWidth="0" orientation="orHorizontal"/>
			<widget name="rating" position="180,347" size="200,20" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#55000000" />
			<eLabel text="GENRES" position="50,380" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
			<widget name="genre" position="50,405" size="650,22" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#55000000" />
			<eLabel text="YEAR" position="50,440" size="100,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
			<widget name="year" position="50,465" size="100,20" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#55000000" />
			<eLabel text="DURATION" position="150,440" size="120,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
			<widget name="duration" position="150,465" size="120,22" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#55000000" />
			<eLabel text="LAST POSITION" position="290,440" size="180,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
			<widget name="position" position="290,465" size="85,20" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#55000000" />
			<widget name="position_progress" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/progress-fs8.png" zPosition="3" position="360,469" size="50,12" transparent="0" backgroundColor="#55000000" borderColor="#004051" borderWidth="1" orientation="orHorizontal" />				
			<eLabel text="DIRECTOR" position="50,500" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
			<widget name="director" position="50,525" size="650,22" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#55000000" />
			<eLabel text="WRITER" position="50,560" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
			<widget name="writer" position="50,585" size="650,22" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#55000000" />
			<eLabel text="ACTORS" position="50,620" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
			<widget name="actors" position="50,645" size="650,22" zPosition="3" font="Regular;18" transparent="0" backgroundColor="#55000000" />
			<widget name="list" transparent="1" zPosition="2" position="730,225" size="500,440" scrollbarMode="showNever" 
				backgroundPixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/background_40-fs8.png"
				selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/green_dark_transparent-fs8.png"/>
			<widget name="poster" zPosition="2" position="50,415" size="133,200" alphatest="blend" />
			<widget name="playlist" position="50,680" size="500,20" zPosition="10" font="Regular;16" transparent="0" foregroundColor="#8a8a8a" backgroundColor="#55000000"/>
			<widget name="page" position="730,680" size="500,20" zPosition="4" font="Regular;16" halign="right" transparent="0"  foregroundColor="#8a8a8a" backgroundColor="#55000000"/>
			
			<widget name="col_widget" position="0,275" size="730,445" transparent="0"  foregroundColor="#bcbbbb" backgroundColor="#55000000" zPosition="8" />
			<widget name="col_poster" zPosition="9" position="50,290" size="240,356" transparent="1" transitionDuration="200"/>
			<widget name="col_overview" font="Regular;24" position="310,290" size="400,375" transparent="0"  foregroundColor="#bcbbbb" backgroundColor="#55000000" zPosition="9" />
			
			
			
			
			
		</screen>"""

	def __init__(self, session, start_index, playlist_id):
		Screen.__init__(self, session)
		self.session = session
		self.start_index = start_index
		VideoBase.__init__(self)
		MoviesBase.__init__(self)
		self.playlist_id = playlist_id
		self["list"] = VideoList(4)

		self.onLayoutFinish.append(self.startRun)
		self.currentSelectedMovie = None

		self["poster"] = MoviePoster()
		self["poster"].hide()

		self["page"] = Label("")
		
		self["col_poster"] = VideoDBPictureBox()
		
		

		self.connectSelChangedTimer = eTimer()
		self.connectSelChangedTimer_Connection = self.connectSelChangedTimer.timeout.connect(self.videoDescriptionUpdate)

	def startRun(self):
		self.buildList(self.start_index, self.playlist_id)
		self.videoDescriptionUpdate()		
		self["list"].connectSelChanged(self.listSelChanged)
		
	def buildList(self, currentIndex, playlist_id=-1):
		movieID = 0
		showCollectionsinMovielist = config.plugins.videodb.showCollectionsinMovielist.value
		if playlist_id == -4: #show collections
			showCollectionsinMovielist = True
		if currentIndex == -1:
			cur = self.currentSelectedMovie
			if cur:
				movieID = cur["movie_id"]
			currentIndex = 0
		elif currentIndex == -2:
			movieID = config.plugins.videodb.lastPlayedMovieID.value
			currentIndex = 0
		self.currentSelectedMovie = None
		if self.filterMode == 9: # collections
			sqlOrder = "ORDER BY movies.released"
		else:		
			sortType = 0
			if playlist_id > 0:
				connection = OpenDatabase(True, True)
				if connection is not None:
					cursor = connection.cursor()
					sql = "select sort_type from playlists where playlist_id = %d;" % playlist_id
					cursor.execute(sql)
					row = cursor.fetchone()
					if row:
					      sortType = str(row["sort_type"])
			else:
				sortType = config.plugins.videodb.moviesscreen_sortorder.value
			sqlOrder = ""
			if sortType == "0":
				sqlOrder = "ORDER BY movies.begin DESC"
			elif sortType == "1":
				sqlOrder = "ORDER BY movies.begin"
			elif sortType == "2":
				if self.searchTitle != "" or showCollectionsinMovielist == False:
					sqlOrder = "ORDER BY movies.name COLLATE NOCASE DESC"
				else:
					sqlOrder = "ORDER BY sortname COLLATE NOCASE DESC"
			elif sortType == "3":
				if self.searchTitle != "" or showCollectionsinMovielist == False:
					sqlOrder = "ORDER BY movies.name COLLATE NOCASE"
				else:
					sqlOrder = "ORDER BY sortname COLLATE NOCASE"

		if self.searchTitle != "":
			sqlWhere = sqlWhere = 'and (movies.name like "%' + self.searchTitle.replace('"','""') + '%" or movies.description like "%' + self.searchTitle.replace('"','""') + '%" or events.extdescription like "%' + self.searchTitle.replace('"','""') + '%")'
		else:
			sqlWhere = ""
		
		if self.filterTagID is not None:
			sqlFilterInnerJoin = self.sqlFilterInnerJoin 
			sqlWhere = sqlWhere + self.sqlFilterWhere
		else:
			sqlFilterInnerJoin = ""
			
		self.playlist_id = playlist_id
		if self.playlist_id == -4: # show collections
			sqlInnerJoinPlaylists = ""
			sqlWherePlaylists = 'and movies.tmdb_collection_id != 0'
		elif self.playlist_id == -3: # show unseen
			sqlInnerJoinPlaylists = ""
			if config.plugins.videodb.clientmovieposition.value:
				sqlWherePlaylists = "and (((((client_movieposition.clientmovieposition/90000)*1.0)/movies.duration)*100.0 < %d.0) or client_movieposition.clientmovieposition IS NULL)" % 95
			else:
				sqlWherePlaylists = "and (((((movies.movieposition/90000)*1.0)/movies.duration)*100.0 < %d.0) or movies.movieposition IS NULL)" % 95
		elif self.playlist_id == -2: # recently added
			sqlInnerJoinPlaylists = ""
			sqlWherePlaylists = 'and (%d - strftime("%s", movies.modified)) <= %d' % (int(time.time()) , "%s", 86400*config.plugins.videodb.recently_added_days.value)
		elif self.playlist_id != -1: # playlist
			sqlInnerJoinPlaylists = "inner join playlist_movies on movies.movie_id = playlist_movies.movie_id"
			sqlWherePlaylists = "and playlist_movies.playlist_id = %d" % self.playlist_id
		else: # standard -> all
			sqlInnerJoinPlaylists = ""
			sqlWherePlaylists = ""

		connection = OpenDatabase()
		if connection is not None:
			connection.text_factory = str
			connection.row_factory = self.dict_factory
			cursor = connection.cursor()
			if self.filterMode == 9 or self.searchTitle != "" or showCollectionsinMovielist == False:
				sql = "select movies.movie_id, movies.name, movies.description, movies.thumb_filename, cover_middle_filename, cover_filename, movies.movieposition, movies.duration, movies.begin, movies.description, movies.filesize, movies.released, movies.rating, events.extdescription, movies.wallpaper, movies.dts, movies.ac3, movies.stereo, movies.hd, movies.widescreen, res_width, res_height, movies.framerate, movies.codec, movies.tmdb_movie_id, movies.tmdb_collection_id, client_movieposition.clientmovieposition FROM Movies LEFT OUTER JOIN Events ON movies.event_id = events.event_id LEFT OUTER JOIN client_movieposition ON movies.movie_id = client_movieposition.movie_id AND client_movieposition.client_id = %d %s %s where movies.tmdb_movie_id is not null %s %s %s;" % (ClientID.instance.getClientID(), sqlFilterInnerJoin, sqlInnerJoinPlaylists, sqlWhere, sqlWherePlaylists, sqlOrder)
			else:
				if self.playlist_id == -4: # show collections
					col_count = 0 # always sort for Movie_Collections.Name
				else:
					col_count = 1 # if movie is a collection but only with one movie use movies.name for sorting
				sql = "select movies.movie_id as movie_id, movies.name as name, movies.description as description, movies.thumb_filename as thumb_filename, movies.cover_middle_filename as cover_middle_filename, movies.cover_filename as cover_filename, movies.movieposition as movieposition, movies.duration as duration, movies.begin as begin, movies.description as description, movies.filesize as filesize, movies.released as released, movies.rating as rating, events.extdescription as extdescription, movies.wallpaper as wallpaper, movies.dts as dts, movies.ac3 as ac3, movies.stereo as stereo, movies.hd as hd, movies.widescreen as widescreen, res_width, res_height, movies.framerate as framerate, movies.codec as codec, movies.tmdb_movie_id as tmdb_movie_id, movies.tmdb_collection_id as tmdb_collection_id, 0 AS col_count, '' as Movie_Collections_wallpaper, '' as Movie_Collections_thumb_filename, '' as Movie_Collections_cover_middle_filename, '' as Movie_Collections_cover_filename, '' as Movie_Collections_name, '' as Movie_Collections_overview, client_movieposition.clientmovieposition as clientmovieposition, movies.name as sortname FROM Movies LEFT OUTER JOIN Events ON movies.event_id = events.event_id LEFT OUTER JOIN client_movieposition ON movies.movie_id = client_movieposition.movie_id AND client_movieposition.client_id = %d %s %s where movies.tmdb_movie_id is not null and movies.tmdb_collection_id = 0 %s %s UNION ALL select movies.movie_id, movies.name, movies.description, movies.thumb_filename, movies.cover_middle_filename, movies.cover_filename, movies.movieposition, movies.duration, movies.begin, movies.description, movies.filesize, movies.released, movies.rating, events.extdescription, movies.wallpaper, movies.dts, movies.ac3, movies.stereo, movies.hd, movies.widescreen, res_width, res_height, movies.framerate, movies.codec, movies.tmdb_movie_id, movies.tmdb_collection_id, count(movies.movie_id) AS col_count, Movie_Collections.wallpaper as Movie_Collections_wallpaper, Movie_Collections.thumb_filename as Movie_Collections_humb_filename, Movie_Collections.cover_middle_filename as Movie_Collections_cover_middle_filename, Movie_Collections.cover_filename as Movie_Collections_cover_filename, Movie_Collections.name as Movie_Collections_name, Movie_Collections.overview as Movie_Collections_overview, client_movieposition.clientmovieposition as clientmovieposition, case when count(movies.movie_id) <= %d then movies.name else movie_collections.name END as sortname FROM Movies LEFT OUTER JOIN Events ON movies.event_id = events.event_id LEFT OUTER JOIN client_movieposition ON movies.movie_id = client_movieposition.movie_id AND client_movieposition.client_id = %d %s %s LEFT OUTER JOIN Movie_Collections ON movies.tmdb_collection_id = Movie_Collections.tmdb_collection_id where movies.tmdb_movie_id is not null and movies.tmdb_collection_id <> 0 %s %s GROUP BY movies.tmdb_collection_id %s;" % (ClientID.instance.getClientID(), sqlFilterInnerJoin, sqlInnerJoinPlaylists, sqlWhere, sqlWherePlaylists,  col_count, ClientID.instance.getClientID(), sqlFilterInnerJoin, sqlInnerJoinPlaylists, sqlWhere, sqlWherePlaylists, sqlOrder)
			cursor.execute(sql)
			list = []
			index = 0
			for row in cursor:
				if movieID and movieID == row["movie_id"]:
					currentIndex = index
				list.append(((row),))
				index += 1
			self["list"].setList(list, self.playlist_id)
			self["list"].moveToIndex(currentIndex)
			self.index = self["list"].getCurrentIndex()
			
			if self.playlist_id > 0:
				cursor.execute("Select playlist_text from Playlists where playlist_id=%d;" % self.playlist_id)
				row = cursor.fetchone()
				self["playlist"].setText(_("Playlist:") + " " + row["playlist_text"])
			else:
				if self.playlist_id == -4:
					self["playlist"].setText(_("Playlist:") +  " " + _("Movie Collections"))
				elif self.playlist_id == -3:
					self["playlist"].setText(_("Playlist:") +  " " + _("Unseen"))
				elif self.playlist_id == -2:
					self["playlist"].setText(_("Playlist:") +  " " + _("Recently added"))
				else:
					self["playlist"].setText("")
			cursor.close() 
			connection.close()
			self.setPageInfo()
			self.currentSelectedMovie = self["list"].getCurrent()

	def setPageInfo(self):
		self.index = self["list"].getCurrentIndex()
		pageInfo = self["list"].calculatePages()
		self["page"].setText(_("Page %d/%d") % (pageInfo[0], pageInfo[1]))

	def listSelChanged(self):
		self.setPageInfo()
		self.connectSelChangedTimer.start(100, True)

	def videoDescriptionUpdate(self):
		cur = self.currentSelectedMovie = self["list"].getCurrent()
		if cur:
			self.currentIndex = self["list"].getCurrentIndex()
			if not cur.has_key("col_count") or (cur.has_key("col_count") and cur["col_count"] < 2 and self.playlist_id != -4):
				self["col_widget"].hide()
				#self["col_poster"].hide()
				self["col_poster"].setPicture("")
				self["col_overview"].hide()
				filename = ""
				if cur["wallpaper"]:
					filename = os_path.join(self.imagePath, cur["wallpaper"])
				if os_path.exists(filename):
					self.ref = eServiceReference(0x1013, 0, filename)
				else:
					self.ref = eServiceReference(0x1013, 0, DEFAULT_WALLPAPER)
				self.session.nav.playService(self.ref)
				if cur["cover_middle_filename"]:
					filename = os_path.join(self.imagePath, cur["cover_middle_filename"])
					if os_path.exists(filename):
						self["poster"].updatePoster(filename)
				else:
					self["poster"].hide()
				self.setMovieData()
			else:
				self["col_widget"].show()
				self["col_poster"].show()
				self["col_overview"].show()
				self["title"].setText(cur["Movie_Collections_name"].upper())
				if cur["Movie_Collections_overview"] and cur["Movie_Collections_overview"] != "None":
					self["col_overview"].setText(cur["Movie_Collections_overview"])
				else:
					self["col_overview"].setText("")
				filename = ""
				if cur["Movie_Collections_wallpaper"]:
					filename = os_path.join(self.imagePath, cur["Movie_Collections_wallpaper"])
				if os_path.exists(filename):
					self.ref = eServiceReference(0x1013, 0, filename)
				else:
					self.ref = eServiceReference(0x1013, 0, DEFAULT_WALLPAPER)
				self.session.nav.playService(self.ref)
				if cur["Movie_Collections_cover_filename"]:
					filename = os_path.join(self.imagePath, cur["Movie_Collections_cover_filename"])
					if os_path.exists(filename):
						self["col_poster"].show()
						self["col_poster"].setPicture(filename)
				else:
					self["col_poster"].setPicture("")
					self["col_poster"].hide()
					
	def updateList(self, row):	
		self["list"].updateRowData(row)
		self.setMovieData()


	def nextMovie(self):
		self["list"].moveDown()
		self.currentSelectedMovie = self["list"].getCurrent()

	def previousMovie(self):
		self["list"].moveUp()
		self.currentSelectedMovie = self["list"].getCurrent()

	def downloadTMDbPicturesCallback(self, value):
		if value:
			self.buildList(self["list"].getCurrentIndex(), self.playlist_id)
			
			
class SimpleStyleMovies(HighListMovies):

	skin = """
		<screen name="SimpleStyleMovies" position="0,0" size="1280,720" flags="wfNoBorder" title="Movies">
			<widget name="list" transparent="1" zPosition="2" position="40,40" size="1200,630" scrollbarMode="showOnDemand"/>
			<widget name="playlist" position="40,680" size="500,20" zPosition="3" font="Regular;16" transparent="1" foregroundColor="#8a8a8a" />
			<widget name="page" position="40,680" size="1200,20" zPosition="4" font="Regular;16" halign="right" transparent="1"  foregroundColor="#8a8a8a" />
		</screen>"""

	def __init__(self, session, start_index, playlist_id):
		HighListMovies.__init__(self, session, start_index, playlist_id)
		self["list"] = VideoList(9)
		
	def videoDescriptionUpdate(self):
		cur = self.currentSelectedMovie = self["list"].getCurrent()
		if cur:
			self.currentIndex = self["list"].getCurrentIndex()
			#filename = ""
			#if not cur.has_key("col_count") or (cur.has_key("col_count") and cur["col_count"] < 2):
			#	if cur["wallpaper"]:
			#		filename = os_path.join(self.imagePath, cur["wallpaper"])
			#else:
			#	if cur["Movie_Collections_wallpaper"]:
			#		filename = os_path.join(self.imagePath, cur["Movie_Collections_wallpaper"])
			#if os_path.exists(filename):
			#	self.ref = eServiceReference(0x1013, 0, filename)
			#else:
			#	self.ref = eServiceReference(0x1013, 0, DEFAULT_WALLPAPER)
			#self.session.nav.playService(self.ref)
	
	def setMovieData(self):
		pass

class VideoList(GUIComponent, object):

	GUI_WIDGET = eListbox

	def __init__(self, mode):
		GUIComponent.__init__(self)
		self.l = eListboxPythonMultiContent()
		self.l.setBuildFunc(self.buildSeriesListEntry)
		tlf = TemplatedListFonts()
		self.l.setFont(0, gFont(tlf.face(tlf.BIG), tlf.size(tlf.BIG)))
		self.l.setFont(1, gFont(tlf.face(tlf.SMALL), tlf.size(tlf.SMALL)))
		self.l.setFont(2, gFont(tlf.face(tlf.MEDIUM), tlf.size(tlf.MEDIUM)))
		self.l.setItemHeight(int(80*skinFactor))
		self.onSelectionChanged = [ ]
		self.pixmapCache = {}
		self.mode = mode
		self.selectedID = None # till DMM implements an selected flag in setBuildFunc
		self.l.setSelectableFunc(self.isSelectable)
		self.unselectedPic = self.loadPixmap("/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/unselected-fs8.png")
		self.imagePath = ClientID.instance.getImagePath()
		self.list = []
		self.totalPages = 0
		self.itemPerPage = 0
		self.itemCount = 0
		self.currentPage = 0
		self.playlist_id = -1


	def loadPixmap(self, filename):
		ptr = None
		if filename in self.pixmapCache:
			return self.pixmapCache[filename]
		else:
			if filename[-4:] == ".png":
				ptr = loadPNG(filename)
			elif filename[-4:] == ".jpg":
				ptr = loadJPG(filename)
				if not ptr:
					# sometime there are png files declared as jpg on thetvdb.org
					ptr = loadPNG(filename)
		if ptr:
			self.pixmapCache[filename] = ptr
		return ptr


	def buildSeasonListEntry(self, data):
		width = self.l.getItemSize().width()
		res = [ None ]
		text_string = _("Season %s (%d)") % (data["season"], data["season_count"])
		color = parseColor("#949390").argb()
		selcolor = parseColor("#eae9e7").argb()
		res.append((eListboxPythonMultiContent.TYPE_TEXT, 2, 0, width , 32 * skinFactor, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, text_string, color, selcolor))
		return res

	def buildAllEpisodeListEntry(self,data):
		width = self.l.getItemSize().width()
		res = [ None ]
		name = "%sx%s: %s" % (data["season"], data["episode"] , data["episodename"])
		color = parseColor("#949390").argb()
		selcolor = parseColor("#eae9e7").argb()
		res.append((eListboxPythonMultiContent.TYPE_TEXT, 2, 0, width-58 * skinFactor,38 * skinFactor, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, name, color, selcolor))
		ptr = self.loadPixmap("/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/progress-fs8.png")
		color = parseColor("#585656").argb()
		selcolor = parseColor("#004051").argb()
		movieposition = 0
		if config.plugins.videodb.clientmovieposition.value:
			if data["clientmovieposition"] is not None:
				movieposition = data["clientmovieposition"]
		else:
			movieposition = data["movieposition"]
		if movieposition > 0 and data["duration"]:
			percent = int((float(movieposition)  / 90000 / float(data["duration"])) * 100);
		else:
			percent = 0
		if percent > 100: # FIXME: i dont know why movieposition can contain weird data values...
			percent = 100
		res.append((eListboxPythonMultiContent.TYPE_PROGRESS_PIXMAP, width-54 * skinFactor, 13 * skinFactor, 50 * skinFactor,12 * skinFactor, percent, ptr, 1,color, selcolor, None ))
		return res

	def buildEpisodeListEntry(self, data):
		width = self.l.getItemSize().width()
		res = [ None ]
		name = "%s: %s" % (data["episode"] , data["episodename"])
		color = parseColor("#949390").argb()
		selcolor = parseColor("#eae9e7").argb()
		res.append((eListboxPythonMultiContent.TYPE_TEXT, 2, 0, width-58 * skinFactor,38 * skinFactor, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, name, color, selcolor))
		ptr = self.loadPixmap("/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/progress-fs8.png")
		color = parseColor("#585656").argb()
		selcolor = parseColor("#004051").argb()
		movieposition = 0
		if config.plugins.videodb.clientmovieposition.value:
			if data["clientmovieposition"] is not None:
				movieposition = data["clientmovieposition"]
		else:
			movieposition = data["movieposition"]
		if movieposition > 0 and data["duration"]:
			percent = int((float(movieposition)  / 90000 / float(data["duration"])) * 100);
		else:
			percent = 0
		if percent > 100: # FIXME: i dont know why movieposition can contain weird data values...
			percent = 100			
		res.append((eListboxPythonMultiContent.TYPE_PROGRESS_PIXMAP, width-54 * skinFactor, 13 * skinFactor, 50 * skinFactor,12 * skinFactor, percent, ptr, 1,color, selcolor, None ))
		return res


	def buildSeriesListEntry(self, data):
		width = self.l.getItemSize().width()
		res = [ None ]
		color = parseColor("#949390").argb()
		selcolor = parseColor("#eae9e7").argb()
		thumb = data["banner_small"]
		selected = (data["serie_id"] == self.selectedID)
		p = os_path.join(self.imagePath, thumb)
		ptr = self.loadPixmap(p)
		if ptr is not None:
			res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, 5, 5, 379 * skinFactor, 70 * skinFactor, ptr))
			if not selected and self.unselectedPic is not None:
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHABLEND, 5, 5, 379 * skinFactor, 70 * skinFactor, self.unselectedPic))
		else:
			res.append((eListboxPythonMultiContent.TYPE_TEXT, 0, 1, width , 28 * skinFactor, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, data["name"], color, selcolor))
		return res

	def buildSeriesListTextEntry(self, data):
		width = self.l.getItemSize().width()
		res = [ None ]
		name = "%s" % data["name"]
		color = parseColor("#949390").argb()
		selcolor = parseColor("#eae9e7").argb()
		res.append((eListboxPythonMultiContent.TYPE_TEXT, 2, 0, width,38 * skinFactor, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, name, color, selcolor))
		return res

	def buildSimpleMovieListEntry(self, data):
		width = self.l.getItemSize().width()
		res = [ None ]
		isCollection = False
		if data.has_key("col_count"):
			if data["col_count"] > 1 or self.playlist_id == -4:
				text_string = data["Movie_Collections_name"]
				isCollection = True
			else:
				text_string = data["name"]
		else:
			text_string = data["name"]
			
		res.append((eListboxPythonMultiContent.TYPE_TEXT, 0, 2, width , 25 * skinFactor, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, text_string))

		if isCollection == False:
			text = ""
			text_pos = width -5 - 50 * skinFactor
			color = parseColor("#d8a710").argb()
			if data["dts"] == 1:
				text = "DTS"
			elif data["ac3"] == 1:
				text = "AC3"
			elif data["stereo"] == 1:
				text = "Stereo"
			res.append((eListboxPythonMultiContent.TYPE_TEXT, text_pos, 30 * skinFactor, 50 * skinFactor,20 * skinFactor, 2, RT_HALIGN_RIGHT|RT_VALIGN_CENTER, text, color, color))
			
			text = ""
			if data["hd"] == 1:
				text ="HD"
			else:	
				text ="SD"
			text_pos -= 55 * skinFactor
			res.append((eListboxPythonMultiContent.TYPE_TEXT, text_pos, 30 * skinFactor, 50 * skinFactor,20 * skinFactor, 2, RT_HALIGN_RIGHT|RT_VALIGN_CENTER, text, color, color))
			
			text = ""
			if data["widescreen"] == 1:
				text = "WS"
			else:
				text = "4:3"
			text_pos -= 55 * skinFactor
			res.append((eListboxPythonMultiContent.TYPE_TEXT, text_pos, 30 * skinFactor, 50 * skinFactor,20 * skinFactor, 2, RT_HALIGN_RIGHT|RT_VALIGN_CENTER, text, color, color))
			
			res.append((eListboxPythonMultiContent.TYPE_TEXT, 0, 2, width , 25 * skinFactor, 2, RT_HALIGN_RIGHT|RT_VALIGN_CENTER, data["description"]))
			
			duration = data["duration"]
			
			if duration:
				duration_text = "%02d:%02d:%02d" % (duration/3600, duration%3600/60, duration%60)
			else:
				duration_text = ""
				
			res.append((eListboxPythonMultiContent.TYPE_TEXT, 0, 30 * skinFactor, 100 * skinFactor , 25 * skinFactor, 2, RT_HALIGN_LEFT|RT_VALIGN_CENTER, duration_text))

			movieposition = 0
			if config.plugins.videodb.clientmovieposition.value:
				if data["clientmovieposition"] is not None:
					movieposition = data["clientmovieposition"]
			else:
				movieposition = data["movieposition"]
			if movieposition > 0 and data["duration"]:
				percent = int((float(movieposition)  / 90000 / float(data["duration"])) * 100);
			else:
				percent = 0
			if percent > 100: # FIXME: i dont know why movieposition can contain weird data values...
				percent = 100
			res.append(MultiContentEntryProgress(pos=(100 * skinFactor,40 * skinFactor), size = (50 * skinFactor,6 * skinFactor), percent = percent, borderWidth = 1))
		
		else:
			res.append((eListboxPythonMultiContent.TYPE_TEXT, 0, 30 * skinFactor, width , 25 * skinFactor, 2, RT_HALIGN_LEFT|RT_VALIGN_CENTER, _("contains %d movies") % data["col_count"]))
		
		return res
				
	def buildMovieListEntry(self, data):
		width = self.l.getItemSize().width()
		res = [ None ]
		if data.has_key("col_count"):
			if data["col_count"] > 1 or self.playlist_id == -4:
				text_string = data["Movie_Collections_name"]
			else:
				text_string = data["name"]
		else:
			text_string = data["name"]
		color = parseColor("#949390").argb()
		selcolor = parseColor("#eae9e7").argb()
		res.append((eListboxPythonMultiContent.TYPE_TEXT, 2, 4, width , 32 * skinFactor, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, text_string, color, selcolor))
		return res
		
	def buildTagListEntry(self, data):
		width = self.l.getItemSize().width()
		res = [ None ]
		text_string = "%s (%s)" % (data["name"], data["moviecount"])
		color = parseColor("#949390").argb()
		selcolor = parseColor("#eae9e7").argb()
		res.append((eListboxPythonMultiContent.TYPE_TEXT, 2, 4, width , 32 * skinFactor, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, text_string, color, selcolor))
		return res
		
	def buildCastListEntry(self, data):
		width = self.l.getItemSize().width()
		res = [ None ]
		if data["character"] != "":
			text_string = _("%s as %s") % (data["name"], data["character"])
		else:
			text_string = _("%s: %s") % (data["job"], data["name"])
		color = parseColor("#949390").argb()
		selcolor = parseColor("#eae9e7").argb()
		res.append((eListboxPythonMultiContent.TYPE_TEXT, 2, 4, width , 32 * skinFactor, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, text_string, color, selcolor))
		return res

	def isSelectable(self, data):
		if data.has_key("serie_id"):
			self.selectedID = data["serie_id"]
		else:
			self.selectedID = None
		return True

	def connectSelChanged(self, fnc):
		if not fnc in self.onSelectionChanged:
			self.onSelectionChanged.append(fnc)

	def disconnectSelChanged(self, fnc):
		if fnc in self.onSelectionChanged:
			self.onSelectionChanged.remove(fnc)

	def selectionChanged(self):
		for x in self.onSelectionChanged:
			x()

	def calculatePages(self):
		if self.itemPerPage <> 0:
			currentIndex = self.instance.getCurrentIndex() + 1
			self.currentPage =  currentIndex  / self.itemPerPage
			if currentIndex  % self.itemPerPage != 0:
				self.currentPage += 1
		return (self.currentPage, self.totalPages)
	
	def getCurrent(self):
		cur = self.l.getCurrentSelection()
		return cur and cur[0]

	def postWidgetCreate(self, instance):
		instance.setContent(self.l)
		self.selectionChanged_conn = instance.selectionChanged.connect(self.selectionChanged)
		self.instance.setWrapAround(True)

	def preWidgetRemove(self, instance):
		self.selectionChanged_conn = None
		instance.setContent(None)


	def setList(self, list, playlist_id = -1):
		if self.mode == 2:
			self.l.setItemHeight(int(32*skinFactor))
			self.l.setBuildFunc(self.buildSeasonListEntry)
		elif self.mode == 3:
			self.l.setItemHeight(int(40*skinFactor))
			self.l.setBuildFunc(self.buildEpisodeListEntry)
		elif self.mode == 4:
			self.l.setItemHeight(int(40*skinFactor))
			self.l.setBuildFunc(self.buildMovieListEntry)
		elif self.mode == 5:
			self.l.setItemHeight(int(40*skinFactor))
			self.l.setBuildFunc(self.buildAllEpisodeListEntry)
		elif self.mode == 6:
			self.l.setItemHeight(int(40*skinFactor))
			self.l.setBuildFunc(self.buildSeriesListTextEntry)
		elif self.mode == 7:
			self.l.setItemHeight(int(40*skinFactor))
			self.l.setBuildFunc(self.buildTagListEntry)
		elif self.mode == 8:
			self.l.setItemHeight(int(40*skinFactor))
			self.l.setBuildFunc(self.buildCastListEntry)
		elif self.mode == 9:
			self.l.setItemHeight(int(55*skinFactor))
			self.l.setBuildFunc(self.buildSimpleMovieListEntry)
		
		self.l.setList(list)
		self.list = list
		self.playlist_id = playlist_id

		if self.l.getItemSize().height():
			self.itemPerPage = self.instance.size().height() / self.l.getItemSize().height()
			self.itemCount = len(self.list)
			if self.itemPerPage <> 0:
				self.totalPages = self.itemCount / self.itemPerPage
				if self.itemCount % self.itemPerPage <> 0:
					self.totalPages += 1

	def up(self):
		if self.instance is not None:
			self.instance.moveSelection(self.instance.moveUp)

	def down(self):
		if self.instance is not None:
			self.instance.moveSelection(self.instance.moveDown)

	def pageUp(self):
		if self.instance is not None:
			self.instance.moveSelection(self.instance.pageUp)

	def pageDown(self):
		if self.instance is not None:
			self.instance.moveSelection(self.instance.pageDown)

	def moveUp(self):
		if self.instance is not None:
			self.instance.moveSelection(self.instance.moveUp)

	def moveDown(self):
		if self.instance is not None:
			self.instance.moveSelection(self.instance.moveDown)

	def getCurrentIndex(self):
		return self.instance.getCurrentIndex()

	def updateRowData(self, row):
		index = self.getCurrentIndex()
		tmp = self.list[index]
		self.list[index] = (row,)
		self.l.invalidateEntry(index)

	def moveToIndex(self, index):
		self.instance.moveSelectionTo(index)
		
	def setMode(self, mode):
		self.mode = mode

	def getList(self):
		return self.list


class TVShowAllEpisodes:
	def __init__(self, session):
		self.session = session
		self["TVShowAllEpisodesActions"] = ActionMap(["InfobarSeekActions"],
		{
			"playpauseService": self.playAllEpisodes, 
			"unPauseService": self.playAllEpisodes, 
		}, -1)
		self.ref = None
		self.seriesSeason = None

	def playAllEpisodes(self):
		if self.currentSeries and self.currentSeries["serie_id"]:
			connection = OpenDatabase(dictFactory = True)
			if connection is not None:
				cursor = connection.cursor()
				if config.plugins.videodb.clientmovieposition.value:
					where = "(((((client_movieposition.clientmovieposition/90000)*1.0)/movies.duration)*100.0 < %d.0) or client_movieposition.clientmovieposition IS NULL)" % 95
				else:
					where = "(((((movies.movieposition/90000)*1.0)/movies.duration)*100.0 < %d.0) or movies.movieposition IS NULL)" % 95

				if self.seriesSeason is not None:
					seasonWhere = "and movies_series.season = %d" % self.seriesSeason
				else:
					seasonWhere = ""

				sql = "SELECT movies.name, movies.movie_id, movies.serviceid, movies.filename, paths.path, movies.movieposition, movies.duration, movies.begin, movies.description, movies.event_id, movies.filesize, movies.screenshot, movies.dts, movies.ac3, movies.stereo, movies.hd, movies.widescreen, movies.res_width, movies.res_height, movies.framerate, movies.codec, movies_series.episode, movies_series.season, movies_series.writer, movies_series.director, movies_series.episodename, movies_series.rating, movies_series.firstaired, movies_series.overview, mountpoints.mountpoint, client_movieposition.clientmovieposition, events.extdescription FROM Movies INNER JOIN Paths ON movies.path_id = paths.path_id INNER JOIN mountpoints on Paths.link_id = Mountpoints.link_id INNER JOIN movies_series on movies_series.movie_id = movies.movie_id LEFT OUTER JOIN client_movieposition ON movies.movie_id = client_movieposition.movie_id AND client_movieposition.client_id = %d LEFT OUTER JOIN Events ON movies.event_id = events.event_id WHERE mountpoints.client_id = %d and movies.visible = 1 and movies_series.serie_id = %d and %s %s ORDER BY movies_series.season, movies_series.episode, begin DESC;" % (ClientID.instance.getClientID(), ClientID.instance.getClientID(), self.currentSeries["serie_id"], where, seasonWhere)
				cursor.execute(sql)
				alllist = []
				movieID = None
				for row in cursor:
					if movieID is None:
						movieID = row["movie_id"]
					alllist.append(((row),))
				cursor.close() 
				connection.close()
				alllist.reverse()
				if movieID is not None:
					row = alllist[0][0]
					if row:
						name = row["name"]
						serviceID = row["serviceid"]
						filename = row["filename"]
						path = os_path.join(row["mountpoint"],row["path"])
						if os_path.exists(os_path.join(path,filename)):
							self.session.openWithCallback(self.playerClosedAllEpisodes, VideoDBPlayerModalAllEpisodes, movieID, alllist)
						else:
							self.session.open(MessageBox, _("Could not find the movie.\nEither the device is not mounted or the movie was deleted."), type = MessageBox.TYPE_INFO)
				else:
					self.session.open(MessageBox, _("No unseen episode found for this series"), type = MessageBox.TYPE_INFO)

	def playerClosedAllEpisodes(self, result = None):
		if self.ref is not None:
			self.session.nav.playService(self.ref)
		else:
			self.session.nav.stopService()
		if result == 0:
			self.close(0)


class TVShowMenu:
	def __init__(self, session):
		self.session = session

	def menu(self):
		options = []
		for sorttype in config.plugins.videodb.tvshowscreen_sortorder.choices.choices:
			options.extend(((sorttype[1], boundFunction(self.sortMovielist, sorttype[0])),))
		style = config.plugins.videodb.tvshowscreen_style.value
		counter = 0
		while True:
			if style != counter:
				text = ""
				if counter == 0:
					text = _("Style: Poster Top")
				elif counter == 1:
					text = _("Style: Thumbs Top")
				elif counter == 2:
					text = _("Style: Banner Top")
				if counter == 3:
					text = _("Style: Banner Listbox")
				elif counter == 4:
					text = _("Style: Listbox")
				elif counter == 5:
					text = _("Style: Coverflow 2D")
				options.extend(((text, boundFunction(self.setListView,counter)),))
			counter += 1
			if counter > 5:
				break
				
				
		options.extend(((_("TVDb Pictures..."), self.tvdbPictures),))

		options.extend(((_("Show logs..."), self.showScanLog),))
		options.extend(((_("Add files..."), self.addFiles),))
		self.session.openWithCallback(self.menuCallback, ChoiceBox,list = options)
		

	def menuCallback(self, ret):
		ret and ret[1]()

	def showScanLog(self):
		self.session.openWithCallback(self.movieBrowserClosed, ScanLogs, True)

	def addFiles(self):
		self.session.openWithCallback(self.movieBrowserClosed, MovieBrowser, True)
		
	def movieBrowserClosed(self, value):
		pass

	def sortMovielist(self, sorttype):
		pass
		
	def tvdbPictures(self):
		if self.currentSeries is not None:
			options = []
			options.extend(((_("Wallpaper..."), boundFunction(self.tvdbPicturesSelectionCallback,DownloadTVDbPictures.WALLPAPER)),))
			options.extend(((_("Banner..."), boundFunction(self.tvdbPicturesSelectionCallback,DownloadTVDbPictures.BANNER)),))
			options.extend(((_("Poster..."), boundFunction(self.tvdbPicturesSelectionCallback,DownloadTVDbPictures.POSTER)),))
			self.session.openWithCallback(self.menuCallback, ChoiceBox,title = _("Choose a type for TVDb pictures..."), list = options, titlebartext=_("TVDb pictures"))

	def tvdbPicturesSelectionCallback(self, bannertype):
		self.session.openWithCallback(self.downloadTVDbPicturesCallback, DownloadTVDbPictures, self.currentSeries, bannertype)
		
	def downloadTVDbPicturesCallback(self, value):
		pass

class TVShowScreen:
	def __init__(self, session):
		self.session = session
		self.currentService = self.session.nav.getCurrentlyPlayingServiceReference()
		self.session.nav.stopService()

	def open(self, index = 0):
		if ClientID.instance.getClientID() is None:
			self.session.open(MessageBox, _("Your database for VideoDB was not initialized.\nPlease enter Setup to do that."), MessageBox.TYPE_ERROR)
		else:
			if not MovieDataUpdater.instance.isRunning():
				proceed = 0
				connection = OpenDatabase(True, True)
				if connection is not None:
					cursor = connection.cursor()
					sql = "select series.serie_id from series LIMIT 1;"
					cursor.execute(sql)
					row = cursor.fetchone()
					if row:
						proceed = 1
					cursor.close() 
					connection.close()
				if proceed:
					if index == -2:
						sids = config.plugins.videodb.lastPlayedEpisodeIDs.value
						ids = sids.split(',')
						if len(ids) == 3:
							seasonData = {'season' : int(ids[1])}
							connection = OpenDatabase(True, True)
							if connection is not None:
								cursor = connection.cursor()
								sids = config.plugins.videodb.lastPlayedEpisodeIDs.value
								ids = sids.split(',')
								if len(ids) == 3:
									movieID = int(ids[2])
									sql = "Select movie_id from Movies where movie_id = %d;" % movieID
									cursor.execute(sql)
									movieData = cursor.fetchone()
									if movieData:
										sql = "select series.name, series.serie_id, series.wallpaper from series where series.serie_id=%s;" % ids[0]
										cursor.execute(sql)
										seriesData = cursor.fetchone()
										cursor.close()  
										connection.close()
										if seriesData:
											filename = ""
											if seriesData["wallpaper"]:
												filename = os_path.join(ClientID.instance.getImagePath(), seriesData["wallpaper"])
											if os_path.exists(filename):
												ref = eServiceReference(0x1013, 0, filename)
											else:
												ref = eServiceReference(0x1013, 0, DEFAULT_WALLPAPER)
											self.session.nav.playService(ref)
											self.session.openWithCallback(self.screenLastEpisodeClosed, EpisodesScreen, seasonData, seriesData, ref, True)
											return
									else:
										cursor.close()  
										connection.close()
						self.open()
					else:			
						style = config.plugins.videodb.tvshowscreen_style.value
						if style == 0:
							self.session.openWithCallback(self.screenClosed, TVPosterTop, index, "poster")
						elif style == 1:
							self.session.openWithCallback(self.screenClosed, TVSmallThumbsTop, index, "poster")
						elif style == 2:
							self.session.openWithCallback(self.screenClosed, TVBannerScreen, index, "banner_small")
						elif style == 3:
							self.session.openWithCallback(self.screenClosed, TVShow, index)
						elif style == 4:
							self.session.openWithCallback(self.screenClosed, TVShowList, index)
						elif style == 5:
							self.session.openWithCallback(self.screenClosed, TVCoverflow2D, index, "poster")
				else:
					self.session.openWithCallback(self.dialogScanForMoviesScreenCallBack, DialogScreen, _("There are no series found in the database...\nWhat do you want to do?"), [ (_("Scan for series"), 0), (_("Do nothing"), 1) ])
			else:
				self.session.openWithCallback(self.dialogShowMovieDataUpdaterScreenCallBack, DialogScreen, _("You are updating your movies with TMDb- and TVDb service right now...\nWhat do you want to do?"), [ (_("Show status"), 0), (_("Do nothing"), 1) ])
				
	def dialogShowMovieDataUpdaterScreenCallBack(self, result):
		if result:
			self.session.open(MovieDataUpdaterScreen)
			
	def dialogScanForMoviesScreenCallBack(self, result):
		if result:
			self.session.open(MovieBrowser, True)
			
	def screenLastEpisodeClosed(self, result = None):
		r = None
		if result is None:
			r = 1
		self.screenClosed(r,-3)
			

	def screenClosed(self, result = None, index = 0):
		if result and result == 1:
			self.open(index)
		else:
			self.session.nav.playService(self.currentService)
			if isinstance (self.session.current_dialog, MainMenu):
				self.session.current_dialog.closeRecursive()


class TVShowBase:
	def __init__(self):
		self.imagePath = ClientID.instance.getImagePath()
		self["actions"] = ActionMap(["WizardActions", "DirectionActions", "ColorActions", "EPGSelectActions"],
		{
			"ok": self.okPressed,
			"back": self.back,
			"info": self.info, 
			"down": self.down, 
			"up": self.up,
			"right": self.right,
			"left": self.left,
			"input_date_time": self.menu,
		}, -1)
		self.ref = None
		self["overview"] = Label("")
		self["overviewWidget"] = ScrollLabel("")
		self.infoShown = False
		self["title"] = Label("")
		self["rating"] = Label("")
		self["rating_stars"] = ProgressBar()
		self["poster"] = VideoDBPictureBox()
		self["poster"].hide()
		self["page"] = Label("")
		self.onLayoutFinish.append(self.startRun)

		
	def dict_factory(self, cursor, row):
		dictList = {}
		for idx, col in enumerate(cursor.description):
			dictList[col[0]] = row[idx]
		return dictList
			
	def info(self):
		if self.infoShown:
			self.hideDescription()
		else:		
			self["overviewWidget"].setText(self["overview"].getText())
			self.showDescription()
		self.infoShown = not self.infoShown

	def showDescription(self):
		self["overviewWidget"].show()

	def hideDescription(self):
		self["overviewWidget"].hide()

	def up(self):
		if self.infoShown:
			self["overviewWidget"].pageUp()
		else:
			self["list"].up()

	def down(self):
		if self.infoShown:
			self["overviewWidget"].pageDown()	
		else:
			self["list"].down()

	def left(self):
		if self.infoShown:
			self["overviewWidget"].pageUp()
		else:
			self["list"].pageUp()

	def right(self):
		if self.infoShown:
			self["overviewWidget"].pageDown()	
		else:
			self["list"].pageDown()

	def back(self):
		if self.infoShown:
			self.hideDescription()
			self.infoShown = False
		else:
			self.close()

	def listSelChanged(self):
		pageInfo = self["list"].calculatePages()
		self["page"].setText(_("Page %d/%d") % (pageInfo[0], pageInfo[1]))
		self.connectSelChangedTimer.start(100, True)

class TVShow(Screen, TVShowMenu, TVShowBase, TVShowAllEpisodes):

	skin = """
		<screen name="TVShow" position="0,0" size="1280,720" flags="wfNoBorder" title="TV Series" backgroundColor="#ff000000">
			<eLabel backgroundColor="#55000000" position="0,410" size="1280,288"  zPosition="0"/>
			<widget name="list" transparent="1" zPosition="2" position="840,415" size="389,240" scrollbarMode="showNever"
				selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/rahmen-breit-fs8.png"/>
			<widget name="poster" zPosition="2" position="50,415" size="185,278" transparent="1" transitionDuration="500" />
			<widget name="title" font="Regular;24" position="265,415" size="500,25" transparent="0"  zPosition="3" foregroundColor="#bcbbbb" backgroundColor="#55000000" />
			<eLabel text="GENRE" position="265,470" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
			<widget name="genre" position="415,472" size="405,40" zPosition="3" font="Regular;16" transparent="0" backgroundColor="#55000000"  />
			<eLabel text="FIRST AIRED" position="265,510" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
			<widget name="firstaired" position="415,512" size="405,22" zPosition="3" font="Regular;16" transparent="0" backgroundColor="#55000000"  />
			<eLabel text="RUNTIME" position="265,550" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
			<widget name="runtime" position="415,552" size="405,22" zPosition="3" font="Regular;16" transparent="0" backgroundColor="#55000000"  />
			<eLabel text="NETWORK" position="265,590" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
			<widget name="network" position="415,592" size="405,22" zPosition="3" font="Regular;16" transparent="0" backgroundColor="#55000000"  />
			<eLabel text="RATING" position="265,630" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" valign="center" />
			<widget name="rating" position="534,630" size="200,22" zPosition="3" font="Regular;16" transparent="0" backgroundColor="#55000000" valign="center" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/five_stars_middle_size-fs8.png" position="415,630" size="114,22" alphatest="blend" />
				<widget name="rating_stars" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/five_stars_full_middle_size-fs8.png" zPosition="3" position="415,630" size="114,22" transparent="1" borderWidth="0" orientation="orHorizontal"/>
<!-- for skinners
			<widget name="overview" position="265,450" size="500,228" zPosition="3" font="Regular;20" transparent="1"  />
-->
			<widget name="overviewWidget" backgroundColor="#55000000" position="100,50" size="1080,300"  font="Regular;26" zPosition="5"/>
			<widget name="page" position="840,675" size="389,20" zPosition="3" font="Regular;16" halign="right" transparent="0"  foregroundColor="#bcbbbb" backgroundColor="#55000000"/>


		</screen>"""
	
	def __init__(self, session, start_index):
		Screen.__init__(self, session)
		self.session = session
		self.start_index = start_index
		TVShowMenu.__init__(self, session)
		TVShowBase.__init__(self)
		TVShowAllEpisodes.__init__(self, session)
		self["genre"] = Label("")
		self["firstaired"] = Label("")
		self["runtime"] = Label("")
		self["network"] = Label("")
		self["rating"] = Label("")
		self["rating_stars"] = ProgressBar()
		self["list"] = VideoList(1)
		self.currentSeries = None
		self.sz_w = getDesktop(0).size().width()

		
	def startRun(self):
		self.buildList(self.start_index)
		self.videoDescriptionUpdate()
		self["list"].connectSelChanged(self.listSelChanged)
		self.connectSelChangedTimer = eTimer()
		self.connectSelChangedTimer_Connection = self.connectSelChangedTimer.timeout.connect(self.videoDescriptionUpdate)

	def buildList(self, currentIndex):
		connection = OpenDatabase()
		if connection is not None:
			connection.text_factory = str
			connection.row_factory = self.dict_factory
			cursor = connection.cursor()
			sortType = config.plugins.videodb.tvshowscreen_sortorder.value
			sqlOrder = ""
			if sortType == "0":
				sqlOrder = "inner join (select max(begin) as max_begin, movies_series.serie_id from movies inner join movies_series on movies_series.movie_id = movies.movie_id group by movies_series.serie_id order by max_begin DESC) as mo_se on mo_se.serie_id = series.serie_id"
			elif sortType == "1":
				sqlOrder = "inner join (select max(begin) as max_begin, movies_series.serie_id from movies inner join movies_series on movies_series.movie_id = movies.movie_id group by movies_series.serie_id order by max_begin) as mo_se on mo_se.serie_id = series.serie_id"
			elif sortType == "2":
				sqlOrder = "ORDER BY series.name DESC"
			elif sortType == "3":
				sqlOrder = "ORDER BY series.name"
			sql = "select series.name, series.serie_id, series.tvdb_serie_id, series.overview, series.banner_small, series.poster, series.wallpaper, series.genre, series.runtime, series.status, series.firstaired, series.rating, series.network, series.wallpaper, series.thumb_poster from series %s;" % (sqlOrder)
			cursor.execute(sql)
			list = []

			serieID = None
			if currentIndex == -3:
				sids = config.plugins.videodb.lastPlayedEpisodeIDs.value
				ids = sids.split(',')
				if len(ids) == 3:
					serieID = int(ids[0])
				currentIndex = 0
			index = 0
			for row in cursor:
				if serieID and serieID == row["serie_id"]:
					currentIndex = index
				list.append(((row),))
				index += 1
			self["list"].setList(list)
			cursor.close() 
			connection.close()
			if currentIndex >= 0:
				self["list"].moveToIndex(currentIndex)
		self.hideDescription()

	def videoDescriptionUpdate(self):
		cur = self.currentSeries = self["list"].getCurrent()
		if cur:
			filename = ""
			if cur["wallpaper"]:
				filename = os_path.join(self.imagePath, cur["wallpaper"])
			if os_path.exists(filename):
				self.ref = eServiceReference(0x1013, 0, filename)
			else:
				self.ref = eServiceReference(0x1013, 0, DEFAULT_WALLPAPER)
			self.session.nav.playService(self.ref)
			filename = ""
			if self.sz_w == 720 and cur["thumb_poster"]:
				filename = os_path.join(self.imagePath, cur["thumb_poster"])
			else:
				filename = os_path.join(self.imagePath, cur["poster"])
			
			if filename and os_path.exists(filename):
				self["poster"].show()
				self["poster"].setPicture(filename)
			else:
				self["poster"].hide()
			
			self["overview"].setText(cur["overview"])

			self["title"].setText(cur["name"].upper())
			self["overview"].setText(cur["overview"])
			self["genre"].setText(cur["genre"].upper())
			self["firstaired"].setText("%s (%s)" % (cur["firstaired"].upper(), cur["status"].upper()))
			self["runtime"].setText(_("%d MINUTES") % (cur["runtime"]))
			self["network"].setText(cur["network"].upper())
			
			
			if cur["rating"] != "":
				self["rating"].setText("%s / 10" % cur["rating"])
				rating = float(cur["rating"]) * 10
				self["rating_stars"].setValue(int(rating))
				self["rating_stars"].show()
			else:
 				self["rating"].setText("")
				self["rating_stars"].hide()
			
			
			
			
			
	def okPressed(self):
		currentSeries = self["list"].getCurrent()
		if currentSeries and currentSeries["serie_id"]:
			self.session.openWithCallback(self.seasonScreenClosed, SeasonScreen, currentSeries, self.ref)

	def seasonScreenClosed(self, result = None):
		if result is not None:
			if result == 0:
				self.close(0)
			elif result == 1:
				self.buildList(self["list"].getCurrentIndex())
	
	def screenClosed(self):
		self.buildList(self["list"].getCurrentIndex())
		
	def movieBrowserClosed(self, value):
		if value and value == 1:
			self.close(0)
		else:
			self.buildList(self["list"].getCurrentIndex())

	def setListView(self, value):
		config.plugins.videodb.tvshowscreen_style.value = value
		config.plugins.videodb.save()
		self.close(1, self["list"].getCurrentIndex())

	def sortMovielist(self, sorttype):
		config.plugins.videodb.tvshowscreen_sortorder.setValue(sorttype)
		config.plugins.videodb.save()
		self.buildList(self["list"].getCurrentIndex())
		
	def downloadTVDbPicturesCallback(self, value):
		if value:
			self.buildList(self["list"].getCurrentIndex())



class TVShowList(TVShow):


	

	skin = """
			<screen name="TVShowList" position="0,0" size="1280,720" flags="wfNoBorder" title="TV Series" backgroundColor="#ff000000">
				<eLabel backgroundColor="#55000000" position="0,410" size="1280,288"  zPosition="0"/>
				<widget name="list" transparent="1" zPosition="2" position="730,415" size="500,240" scrollbarMode="showNever" 
					backgroundPixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/background_40-fs8.png"
					selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/green_dark_transparent-fs8.png"/>
				<widget name="poster" zPosition="2" position="50,415" size="185,278" transparent="1" transitionDuration="500" />
				<widget name="title" font="Regular;24" position="265,415" size="450,50" transparent="0"  zPosition="3" foregroundColor="#bcbbbb" backgroundColor="#55000000" />
				<eLabel text="GENRE" position="265,470" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
				<widget name="genre" position="415,472" size="300,40" zPosition="3" font="Regular;16" transparent="0" backgroundColor="#55000000"  />
				<eLabel text="FIRST AIRED" position="265,510" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
				<widget name="firstaired" position="415,512" size="300,22" zPosition="3" font="Regular;16" transparent="0" backgroundColor="#55000000"  />
				<eLabel text="RUNTIME" position="265,550" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
				<widget name="runtime" position="415,552" size="300,22" zPosition="3" font="Regular;16" transparent="0" backgroundColor="#55000000"  />
				<eLabel text="NETWORK" position="265,590" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
				<widget name="network" position="415,592" size="300,22" zPosition="3" font="Regular;16" transparent="0" backgroundColor="#55000000"  />
				<eLabel text="RATING" position="265,630" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" valign="center"  />
				<widget name="rating" position="534,630" size="200,22" zPosition="3" font="Regular;16" transparent="0" backgroundColor="#55000000" valign="center" />
				<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/five_stars_middle_size-fs8.png" position="415,630" size="114,22" alphatest="blend" />
				<widget name="rating_stars" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/five_stars_full_middle_size-fs8.png" zPosition="3" position="415,630" size="114,22" transparent="1" borderWidth="0" orientation="orHorizontal"/>
				<!-- for skinners
				<widget name="overview" position="265,450" size="500,228" zPosition="3" font="Regular;20" transparent="1"  />
				-->
				<widget name="overviewWidget" backgroundColor="#55000000" position="100,50" size="1080,300"  font="Regular;26" zPosition="5"/>
				<widget name="page" position="730,675" size="500,20" zPosition="3" font="Regular;16" halign="right" transparent="0"  foregroundColor="#bcbbbb" backgroundColor="#55000000"/>
			</screen>"""

	
	def __init__(self, session, start_index):
		TVShow.__init__(self, session, start_index)
		self["list"] = VideoList(6)


class TVBannerScreen(Screen, TVShowMenu, TVShowAllEpisodes):
	skin = """
		<screen name="TVBannerScreen" position="0,0" size="1280,720" flags="wfNoBorder" title="TV Series" backgroundColor="#000000">
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/line_1pix-fs8.png" position="0,407" size="1280,2" alphatest="on" />
			<widget name="title" font="Regular;24" position="50,415" size="500,25" transparent="1"  foregroundColor="#bcbbbb" />
			<widget name="page" font="Regular;16" position="620,415" size="610,25" halign="right" transparent="1"  foregroundColor="#8a8a8a" />
			<widget name="description" position="50,450" size="600,228" zPosition="3" font="Regular;20" transparent="1"  />
			<eLabel text="GENRE" position="775,450" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="1" />
			<widget name="genre" position="925,452" size="305,40" zPosition="3" font="Regular;16" transparent="1"  />
			<eLabel text="FIRST AIRED" position="775,490" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="1" />
			<widget name="firstaired" position="925,492" size="305,22" zPosition="3" font="Regular;16" transparent="1"  />
			<eLabel text="RUNTIME" position="775,530" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="1" />
			<widget name="runtime" position="925,532" size="305,22" zPosition="3" font="Regular;16" transparent="1"  />
			<eLabel text="NETWORK" position="775,570" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="1" />
			<widget name="network" position="925,572" size="305,22" zPosition="3" font="Regular;16" transparent="1"  />
			<eLabel text="RATING" position="775,610" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="1" valign="center" />
			<widget name="rating" position="1044,610" size="200,22" zPosition="3" font="Regular;16" transparent="0" backgroundColor="#000000" valign="center" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/five_stars_middle_size-fs8.png" position="925,610" size="114,22" alphatest="blend" />
			<widget name="rating_stars" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/five_stars_full_middle_size-fs8.png" zPosition="3" position="925,610" size="114,22" transparent="1" borderWidth="0" orientation="orHorizontal"/>
			<widget name="covercollection" position="0,0" size="1280,400" transparent="1" zPosition="10" backgroundColor="#55000000" coverSize="379,70" selectedCoverScale="1.2" unselectedCoverDimm="0.4" coverBeginPosition="256,100" coverDistance="6,10" style="0" noCoverAvailablePic="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/no_poster.jpg" />
		</screen>"""
  
  
	def __init__(self, session, start_index, cover_field):
		self.cover_field = cover_field
		self.start_index = start_index
		self.imagePath = ClientID.instance.getImagePath()
		
		Screen.__init__(self, session)
		self.session = session
		TVShowMenu.__init__(self, session)
		TVShowAllEpisodes.__init__(self, session)
		self["actions"] = ActionMap(["WizardActions", "MediaPlayerActions", "EPGSelectActions", "OkCancelActions", "ColorActions"],
		{
			"ok": self.okPressed,
			"cancel": self.close,
			"left": self.left,
			"right": self.right,
			"up": self.up,
			"down": self.down,
			"nextBouquet": self.nextpage,
			#"downRepeated": self.nextpage,
			"prevBouquet": self.previouspage,
			#"upRepeated": self.previouspage,
			"input_date_time": self.menu,

		}, -1)
		self["title"] = Label("")
		self["description"] = Label("")
		self["genre"] = Label("")
		self["firstaired"] = Label("")
		self["runtime"] = Label("")
		self["network"] = Label("")
		self["rating"] = Label("")
		self["rating_stars"] = ProgressBar()
		self["page"] = Label("")
		
		self["covercollection"] = CoverCollection()
		
		
		
		
		self.onLayoutFinish.append(self.startRun)
		

		self.connectSelChangedTimer = eTimer()
		self.connectSelChangedTimer_Connection = self.connectSelChangedTimer.timeout.connect(self.videoDescriptionUpdate)


	def dict_factory(self, cursor, row):
		dictList = {}
		for idx, col in enumerate(cursor.description):
			dictList[col[0]] = row[idx]
		return dictList
	      
	def videoDescriptionUpdate(self):
		self.currentSeries = self["covercollection"].getCurrent()
		if self.currentSeries:
			self["title"].setText(self.currentSeries["name"].upper())
			self["description"].setText(self.currentSeries["overview"])
			self["genre"].setText(self.currentSeries["genre"].upper())
			self["firstaired"].setText("%s (%s)" % (self.currentSeries["firstaired"].upper(), self.currentSeries["status"].upper()))
			self["runtime"].setText(_("%d MINUTES") % (self.currentSeries["runtime"]))
			self["network"].setText(self.currentSeries["network"].upper())
			if self.currentSeries["rating"] != "":
				self["rating"].setText("%s / 10" % self.currentSeries["rating"])
				rating = float(self.currentSeries["rating"]) * 10
				self["rating_stars"].setValue(int(rating))
				self["rating_stars"].show()
			else:
 				self["rating"].setText("")
				self["rating_stars"].hide()
		
	def startRun(self):
		self["covercollection"].connectSelChanged(self.listSelChanged)
		self.buildList(self.start_index)

	def listSelChanged(self, index):
		self.index = index
		self.setPageInfo()
		self.connectSelChangedTimer.start(100, True)
		
	
	def setPageInfo(self):
		self["page"].setText(_("Page %d/%d") % (self["covercollection"].getCurrentPage(), self["covercollection"].getTotalPages()))
		

	def buildList(self, currentIndex):
		self.currentSeries = None
		connection = OpenDatabase()
		if connection is not None:
			connection.text_factory = str
			connection.row_factory = self.dict_factory
			cursor = connection.cursor()
			serieID = None
			if currentIndex == -3:
				sids = config.plugins.videodb.lastPlayedEpisodeIDs.value
				ids = sids.split(',')
				if len(ids) == 3:
					serieID = int(ids[0])
				currentIndex = 0
			sortType = config.plugins.videodb.tvshowscreen_sortorder.value
			sqlOrder = ""
			if sortType == "0":
				sqlOrder = "inner join (select max(begin) as max_begin, movies_series.serie_id from movies inner join movies_series on movies_series.movie_id = movies.movie_id group by movies_series.serie_id order by max_begin DESC) as mo_se on mo_se.serie_id = series.serie_id"
			elif sortType == "1":
				sqlOrder = "inner join (select max(begin) as max_begin, movies_series.serie_id from movies inner join movies_series on movies_series.movie_id = movies.movie_id group by movies_series.serie_id order by max_begin) as mo_se on mo_se.serie_id = series.serie_id"
			elif sortType == "2":
				sqlOrder = "ORDER BY series.name DESC"
			elif sortType == "3":
				sqlOrder = "ORDER BY series.name"
			sql = "select series.name, series.serie_id, series.tvdb_serie_id, series.overview, series.banner_small, series.poster, series.wallpaper, series.genre, series.runtime, series.status, series.firstaired, series.rating, series.network, series.poster, series.wallpaper, series.thumb_poster from series %s;" % (sqlOrder)
			cursor.execute(sql)
			list=[]
			posterlist=[]
			index = 0
			for row in cursor:
				filename = os_path.join(self.imagePath, row[self.cover_field])
				list.append(((row),))
				posterlist.append(filename)
				if serieID and serieID == row["serie_id"]:
					currentIndex = index
				index += 1
			cursor.close() 
			connection.close()
			self["covercollection"].setList(list,posterlist,currentIndex)

	def left(self):
	      self["covercollection"].MoveLeft()
	      
	def right(self):
	      self["covercollection"].MoveRight()	      
	      
	def down(self):
	      self["covercollection"].MoveDown()
	  
	def up(self):
	      self["covercollection"].MoveUp()
	      
	def nextpage(self):
	      self["covercollection"].NextPage()
	      
	def previouspage(self):
	      self["covercollection"].PreviousPage()
			
	def okPressed(self):
		if self.currentSeries:
			if self.currentSeries["wallpaper"]:
				filename = os_path.join(self.imagePath, self.currentSeries["wallpaper"])
				if os_path.exists(filename):
					ref = eServiceReference(0x1013, 0, filename)
				else:
					ref = eServiceReference(0x1013, 0, DEFAULT_WALLPAPER)
			else:
				ref = eServiceReference(0x1013, 0, DEFAULT_WALLPAPER)
			self.session.nav.playService(ref)
			self.session.openWithCallback(self.seasonScreenClosed, SeasonScreen, self.currentSeries, ref)

	def seasonScreenClosed(self, result = None):
		if result is not None:
			if result == 0:
				self.close(0)
			else:
				self.buildList(self.index)

	def screenClosed(self):
		self.close(1, self.index)
		
	def movieBrowserClosed(self, value):
		if value and value == 1:
			self.close(0)
		else:
			self.buildList(self.index)

	def setListView(self, value):
		config.plugins.videodb.tvshowscreen_style.value = value
		config.plugins.videodb.save()
		self.close(1, self.index)

	def sortMovielist(self, sorttype):
		config.plugins.videodb.tvshowscreen_sortorder.setValue(sorttype)
		config.plugins.videodb.save()
		self.buildList(self.index)
		
	def downloadTVDbPicturesCallback(self, value):
		if value:
			self.buildList(self.index)


class TVSmallThumbsTop(TVBannerScreen):
  
	skin = """
		<screen name="TVSmallThumbsTop" position="0,0" size="1280,720" flags="wfNoBorder" title="TV Series" backgroundColor="#000000">
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/line_1pix-fs8.png" position="0,490" size="1280,2" alphatest="on" />
			<widget name="title" font="Regular;24" position="50,498" size="500,25" transparent="1"  foregroundColor="#bcbbbb" />
			<widget name="page" font="Regular;16" position="620,498" size="610,25" halign="right" transparent="1"  foregroundColor="#8a8a8a" />
			<widget name="description" position="50,533" size="600,145" zPosition="3" font="Regular;20" transparent="1"  />
			<eLabel text="GENRE" position="775,498" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="1" />
			<widget name="genre" position="925,500" size="305,40" zPosition="3" font="Regular;16" transparent="1"  />
			<eLabel text="FIRST AIRED" position="775,538" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="1" />
			<widget name="firstaired" position="925,540" size="305,22" zPosition="3" font="Regular;16" transparent="1"  />
			<eLabel text="RUNTIME" position="775,578" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="1" />
			<widget name="runtime" position="925,580" size="305,22" zPosition="3" font="Regular;16" transparent="1"  />
			<eLabel text="NETWORK" position="775,618" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="1" />
			<widget name="network" position="925,620" size="305,22" zPosition="3" font="Regular;16" transparent="1"  />
			<eLabel text="RATING" position="775,658" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="1" valign="center" />
			<widget name="rating" position="1044,658" size="200,22" zPosition="3" font="Regular;16" transparent="0" backgroundColor="#000000" valign="center" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/five_stars_middle_size-fs8.png" position="925,658" size="114,22" alphatest="blend" />
			<widget name="rating_stars" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/five_stars_full_middle_size-fs8.png" zPosition="3" position="925,658" size="114,22" transparent="1" borderWidth="0" orientation="orHorizontal"/>
			<widget name="covercollection" position="0,0" size="1280,480" transparent="1" zPosition="10" backgroundColor="#55000000" coverSize="92,138" selectedCoverScale="1.4" unselectedCoverDimm="0.4" coverBeginPosition="125,110" coverDistance="2,2" style="0" noCoverAvailablePic="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/no_poster.jpg" />
		</screen>"""

class TVPosterTop(TVBannerScreen):
  
	skin = """
		<screen name="TVPosterTop" position="0,0" size="1280,720" flags="wfNoBorder" title="TV Series" backgroundColor="#000000">
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/line_1pix-fs8.png" position="0,490" size="1280,2" alphatest="on" />
			<widget name="title" font="Regular;24" position="50,498" size="500,25" transparent="1"  foregroundColor="#bcbbbb" />
			<widget name="page" font="Regular;16" position="620,498" size="610,25" halign="right" transparent="1"  foregroundColor="#8a8a8a" />
			<widget name="description" position="50,533" size="600,145" zPosition="3" font="Regular;20" transparent="1"  />
			<eLabel text="GENRE" position="775,498" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="1" />
			<widget name="genre" position="925,500" size="305,40" zPosition="3" font="Regular;16" transparent="1"  />
			<eLabel text="FIRST AIRED" position="775,538" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="1" />
			<widget name="firstaired" position="925,540" size="305,22" zPosition="3" font="Regular;16" transparent="1"  />
			<eLabel text="RUNTIME" position="775,578" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="1" />
			<widget name="runtime" position="925,580" size="305,22" zPosition="3" font="Regular;16" transparent="1"  />
			<eLabel text="NETWORK" position="775,618" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="1" />
			<widget name="network" position="925,620" size="305,22" zPosition="3" font="Regular;16" transparent="1"  />
			<eLabel text="RATING" position="775,658" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="1" valign="center" />
			<widget name="rating" position="1044,658" size="200,22" zPosition="3" font="Regular;16" transparent="0" backgroundColor="#000000" valign="center" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/five_stars_middle_size-fs8.png" position="925,658" size="114,22" alphatest="blend" />
			<widget name="rating_stars" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/five_stars_full_middle_size-fs8.png" zPosition="3" position="925,658" size="114,22" transparent="1" borderWidth="0" orientation="orHorizontal"/>
			<widget name="covercollection" position="0,0" size="1280,480" transparent="1" zPosition="10" backgroundColor="#55000000" coverSize="120,177" selectedCoverScale="1.5" unselectedCoverDimm="0.4" coverBeginPosition="175,155" coverDistance="13,13" style="0" noCoverAvailablePic="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/no_poster.jpg" />
		</screen>"""
	
  
class TVCoverflow2D(TVBannerScreen):

	skin = """
		<screen name="TVCoverflow2D" position="0,0" size="1280,720" flags="wfNoBorder" title="TV Series" backgroundColor="#ff000000">
			<eLabel backgroundColor="#55000000" position="0,650" size="1280,70"  zPosition="-1"/>
			<widget name="title" font="Regular;20" position="0,660" size="1280,40" transparent="0"  foregroundColor="#bcbbbb" backgroundColor="#55000000" zPosition="5" halign="center" />
			<widget name="covercollection" position="0,330" size="1280,320" transparent="0" zPosition="10" backgroundColor="#55000000" coverSize="133,200" selectedCoverScale="1.5" unselectedCoverDimm="0.4"  coverflowCurrentPosition="640,153" coverflowCurrentXDistance="13" coverflowCurrentCenterDistance="60" style="1" noCoverAvailablePic="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/no_poster.jpg" />
		</screen>"""
		
	def videoDescriptionUpdate(self):
		TVBannerScreen.videoDescriptionUpdate(self)
		if self.currentSeries:
			if self.currentSeries["wallpaper"]:
				filename = os_path.join(self.imagePath, self.currentSeries["wallpaper"])
				if os_path.exists(filename):
					ref = eServiceReference(0x1013, 0, filename)
				else:
					ref = eServiceReference(0x1013, 0, DEFAULT_WALLPAPER)
			else:
				ref = eServiceReference(0x1013, 0, DEFAULT_WALLPAPER)
			self.session.nav.playService(ref)

class SeasonScreen(TVShow, TVShowAllEpisodes):


	skin = """
		<screen name="SeasonScreen" position="0,0" size="1280,720" flags="wfNoBorder" title="TV Series" backgroundColor="#ff000000">
			<eLabel backgroundColor="#55000000" position="0,410" size="1280,288"  zPosition="0"/>
			<widget name="list" transparent="1" zPosition="2" position="845,415" size="385,278" scrollbarMode="showNever" backgroundColor="#80000000"
				backgroundPixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/background_32-fs8.png"
				selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/green_dark_transparent_32-fs8.png"/>
			<widget name="poster" zPosition="2" position="50,415" size="185,278" transparent="1" transitionDuration="500" />
			<widget name="title" font="Regular;24" position="265,415" size="500,25" transparent="0" zPosition="3" foregroundColor="#bcbbbb" backgroundColor="#55000000" />
			<eLabel text="GENRE" position="265,470" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
			<widget name="genre" position="415,472" size="405,40" zPosition="3" font="Regular;16" transparent="0" backgroundColor="#55000000"  />
			<eLabel text="FIRST AIRED" position="265,510" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
			<widget name="firstaired" position="415,512" size="405,22" zPosition="3" font="Regular;16" transparent="0" backgroundColor="#55000000"  />
			<eLabel text="RUNTIME" position="265,550" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
			<widget name="runtime" position="415,552" size="405,22" zPosition="3" font="Regular;16" transparent="0" backgroundColor="#55000000"  />
			<eLabel text="NETWORK" position="265,590" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
			<widget name="network" position="415,592" size="405,22" zPosition="3" font="Regular;16" transparent="0" backgroundColor="#55000000"  />
			<eLabel text="RATING" position="265,630" size="150,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" valign="center" />
			<widget name="rating" position="534,630" size="200,22" zPosition="3" font="Regular;16" transparent="0" backgroundColor="#55000000" valign="center" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/five_stars_middle_size-fs8.png" position="415,630" size="114,22" alphatest="blend" />
			<widget name="rating_stars" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/five_stars_full_middle_size-fs8.png" zPosition="3" position="415,630" size="114,22" transparent="1" borderWidth="0" orientation="orHorizontal"/>
			<!-- for skinners
			<widget name="overview" position="265,450" size="500,228" zPosition="3" font="Regular;20" transparent="1"  />
			-->
			<widget name="overviewWidget" backgroundColor="#55000000" position="100,50" size="1080,300"  font="Regular;26" zPosition="5"/>
		</screen>"""

	
	def __init__(self, session, seriesData, ref):
		self.session = session
		TVShow.__init__(self, session, 0)
		TVShowAllEpisodes.__init__(self, session)
		self.series_id = seriesData["serie_id"]
		if self.sz_w == 720 and seriesData["thumb_poster"]:
			self.poster = seriesData["thumb_poster"]
		else:		
			self.poster = seriesData["poster"]
		self.ref = ref
		self.seriesData = seriesData
		self["list"] = VideoList(2)

		self["title"].setText(seriesData["name"].upper())
		self["overview"].setText(seriesData["overview"])
		self["genre"].setText(seriesData["genre"].upper())
		self["firstaired"].setText("%s (%s)" % (seriesData["firstaired"].upper(), seriesData["status"].upper()))
		self["runtime"].setText(_("%d MINUTES") % (seriesData["runtime"]))
		self["network"].setText(seriesData["network"].upper())
		
		self.parent_must_reload = False
			
	def startRun(self):
		found = 0
		if self.seriesData["rating"] != "":
			self["rating"].setText(("%s / 10" % self.seriesData["rating"].upper()))
			rating = float(self.seriesData["rating"]) * 10
			self["rating_stars"].setValue(int(rating))
		else:
 			self["rating"].setText("")
			self["rating_stars"].hide()
	
	
		self.hideDescription()		
		filename = os_path.join(self.imagePath, self.poster)
		if os_path.exists(filename):
			self["poster"].show()
			self["poster"].setPicture(filename)
		connection = OpenDatabase()
		if connection is not None:
			connection.text_factory = str
			connection.row_factory = self.dict_factory
			cursor = connection.cursor()
			sql = "select movies_series.season, count(movies_series.movie_series_id) as season_count, movies_series.serie_id from movies_series where movies_series.serie_id = %d group by movies_series.serie_id, movies_series.season order by movies_series.season;" % (self.series_id)
			cursor.execute(sql)
			list = []
			for row in cursor:
				list.append(((row),))
			self["list"].setList(list)
			cursor.close() 
			connection.close()

	def playAllEpisodes(self):
		cur = self["list"].getCurrent()
		if cur and cur["serie_id"]:
			self.seriesSeason = cur["season"]
			self.currentSeries = cur # hack FIXME
			TVShowAllEpisodes.playAllEpisodes(self)

	def okPressed(self):
		cur = self["list"].getCurrent()
		if cur and cur["serie_id"]:
			self.session.openWithCallback(self.episodesScreenClosed, EpisodesScreen, cur, self.seriesData, self.ref)

	def episodesScreenClosed(self, result = None):
		if result is not None:
			if result == 0:
				self.close(0)
			elif result == 1:
				self.parent_must_reload = True
				self.startRun()

	def back(self):
		if self.infoShown:
			self.hideDescription()
			self.infoShown = False
		else:
			if self.parent_must_reload:
				self.close(1)
			else:
				self.close()

	def menu(self):
		options = []
		options.extend(((_("Add files..."), self.addFiles),))
		options.extend(((_("Mark season as seen..."), boundFunction(self.setSeasonMovieStatus,True)),))
		options.extend(((_("Mark season as unseen..."), boundFunction(self.setSeasonMovieStatus,False)),))
		options.extend(((_("Show logs..."), self.showScanLog),))
		self.session.openWithCallback(self.menuCallback, ChoiceBox,list = options)

	def menuCallback(self, ret):
		ret and ret[1]()
		
	def addFiles(self):
		self.session.openWithCallback(self.movieBrowserClosed, MovieBrowser, True)

	def setSeasonMovieStatus(self, status):
		cur = self["list"].getCurrent()
		if cur and cur["serie_id"]:
			self.seasonSelected = cur["season"]
			setAllMovieStatusInDatabase(status, self.seasonSelected, self.series_id)		

	def showScanLog(self):
		self.session.openWithCallback(self.movieBrowserClosed, ScanLogs, True)
		
	def movieBrowserClosed(self, value):
		if value and value == 1:
			self.close(0)
		else:
			self.parent_must_reload = True
			self.startRun()


class EpisodesScreen(Screen, VideoBase):

	skin = """
		<screen name="EpisodesScreen" position="0,0" size="1280,720" flags="wfNoBorder" title="TV Series" backgroundColor="#ff000000">
			<eLabel backgroundColor="#55000000" position="0,410" size="1280,288"  zPosition="-1"/>
			<widget name="list" transparent="1" zPosition="2" position="730,415" size="500,278" scrollbarMode="showNever" 
				backgroundPixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/background_40-fs8.png"
				selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/green_dark_transparent-fs8.png"/>
			<widget name="title" font="Regular;24" position="50,415" size="500,25" transparent="0" zPosition="3" foregroundColor="#bcbbbb" backgroundColor="#55000000" />
			<widget name="poster" zPosition="2" position="50,450" size="355,200" transparent="1" transitionDuration="500" />
			<eLabel text="AIRED" position="420,460" size="120,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
			<widget name="aired" position="540,462" size="180,22" zPosition="3" font="Regular;16" transparent="0" backgroundColor="#55000000"  />
			<eLabel text="RATING" position="420,510" size="120,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
			<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/five_stars_middle_size-fs8.png" position="540,510" size="114,22" alphatest="blend" />
			<widget name="rating_stars" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/five_stars_full_middle_size-fs8.png" zPosition="3" position="540,510" size="114,22" transparent="1" borderWidth="0" orientation="orHorizontal"/>
			<widget name="rating" position="540,532" size="114,22" halign="center" valign="center" zPosition="3" font="Regular;16" transparent="0" backgroundColor="#55000000"  />
			<eLabel text="DIRECTOR" position="420,560" size="120,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
			<widget name="director" position="540,562" size="180,22" zPosition="3" font="Regular;16" transparent="0" backgroundColor="#55000000"  />
			<eLabel text="WRITER" position="420,610" size="120,22" font="Regular;20" foregroundColor="#7895bc"  transparent="0" backgroundColor="#55000000" />
			<widget name="writer" position="540,612" size="180,34" zPosition="3" font="Regular;16" transparent="0" backgroundColor="#55000000"  />
			<!-- for skinners
			<widget name="overview" position="50,580" size="672,105" zPosition="1" font="Regular;20" transparent="1"  foregroundColor = "#00ffffff" />
			-->
			<widget name="audio_icons" pixmaps="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/dts1.png,/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/ac3.png,/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/stereo.png" position="50,660" size="85,30" transparent="0" alphatest="blend" zPosition="3"/>
			<widget name="definition" pixmaps="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/hd.png,/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/sd.png" position="145,660" size="51,30" transparent="0" alphatest="blend" zPosition="3"/>
			<widget name="resolution" pixmaps="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/wide.png,/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/4_3.png" position="201,660" size="51,30" transparent="0" alphatest="blend" zPosition="3"/>
			<widget name="res" position="260,660" size="130,30" zPosition="4" font="Regular;20" halign="center" valign="center" transparent="0"  foregroundColor="#d8a710" backgroundColor="#55000000"/>
			<widget name="framerate" position="400,660" size="190,30" zPosition="3" font="Regular;20" halign="center" valign="center" transparent="0" foregroundColor="#d8a710" backgroundColor="#55000000" />
			<widget name="codec" position="590,660" size="130,30" zPosition="3" font="Regular;20" halign="center" valign="center" transparent="0" foregroundColor="#d8a710" backgroundColor="#55000000" />				
		</screen>"""

	
	def __init__(self, session, seasonData, seriesData, ref, automatic = False):
		Screen.__init__(self, session)
		self.session = session
		if seriesData and seriesData.has_key("serie_id"):
			self.series_id = seriesData["serie_id"]
		else:
			self.series_id = 0
		if seasonData and seasonData.has_key("season"):
			self.season = seasonData["season"]
		else:
			self.season = 0
		VideoBase.__init__(self)
		self.ref = ref
		self["aired"] = Label("")
		self["rating"] = Label("")
		self["director"] = Label("")
		self["writer"] = Label("")
		self["overview"] = Label("")
		self["title"] = Label("")
		self["rating_stars"] = ProgressBar()
		self["rating"] = Label("")
		self["poster"] = VideoDBPictureBox()
		self["list"] = VideoList(3)
		self["audio_icons"] = MultiPixmap()
		self["definition"] = MultiPixmap()
		self["resolution"] = MultiPixmap() 
		self["framerate"] = Label("")
		self["codec"] = Label("")
		self["res"] = Label("")

		if seasonData and seriesData:
			self["title"].setText(_("SEASON %s: %s") % (seasonData["season"], seriesData["name"].upper()))

		self.currentSelectedMovie = None
		self["actions"] = ActionMap(["MovieSelectionActions", "OkCancelActions", "InfobarSeekActions"],
		{
			"contextMenu": self.menu,
			"showEventInfo": self.openEventView,
			"ok": self.okPressed,
			"cancel": self.cancel,
			"playpauseService": self.playAllEpisodes,
			"unPauseService": self.playAllEpisodes
		}, -1)
		self.connectSelChangedTimer = eTimer()
		self.connectSelChangedTimer_Connection = self.connectSelChangedTimer.timeout.connect(self.videoDescriptionUpdate)
		self.onLayoutFinish.append(self.startRun)
		self.parent_must_reload = False
		self.automatic = automatic
			
	def startRun(self):
		if self.automatic:
			index = -2
		else:
			index = 0
		found = self.buildList(index)	
		self.videoDescriptionUpdate()	
		self["list"].connectSelChanged(self.listSelChanged)	
		self.automatic = False
		
	def buildList(self, currentIndex):
		movieID = 0
		found = 0
		if currentIndex == -1:
			cur = self.currentSelectedMovie
			if cur:
				movieID = cur["movie_id"]
			currentIndex = 0
		elif currentIndex == -2:
			sids = config.plugins.videodb.lastPlayedEpisodeIDs.value
			ids = sids.split(',')
			if len(ids) == 3:
				movieID = int(ids[2])
			currentIndex = 0


		self.currentSelectedMovie = None
		connection = OpenDatabase()
		if connection is not None:
			connection.text_factory = str
			connection.row_factory = self.dict_factory
			cursor = connection.cursor()
			sql = "SELECT movies.name, movies.movie_id, movies.serviceid, movies.filename, paths.path, movies.movieposition, movies.duration, movies.begin, movies.description, movies.event_id, movies.filesize, movies.screenshot, movies.dts, movies.ac3, movies.stereo, movies.hd, movies.widescreen, movies.res_width, movies.res_height, movies.framerate, movies.codec, movies_series.episode, movies_series.season, movies_series.writer, movies_series.director, movies_series.episodename, movies_series.rating, movies_series.firstaired, movies_series.overview, mountpoints.mountpoint, client_movieposition.clientmovieposition, events.extdescription, movies_series.serie_id FROM Movies INNER JOIN Paths ON movies.path_id = paths.path_id INNER JOIN mountpoints on Paths.link_id = Mountpoints.link_id INNER JOIN movies_series on movies_series.movie_id = movies.movie_id LEFT OUTER JOIN client_movieposition ON movies.movie_id = client_movieposition.movie_id AND client_movieposition.client_id = %d LEFT OUTER JOIN Events ON movies.event_id = events.event_id WHERE mountpoints.client_id = %d and movies.visible = 1 and movies_series.season = %d and movies_series.serie_id = %d ORDER BY movies_series.episode, begin DESC;" % (ClientID.instance.getClientID(), ClientID.instance.getClientID(), self.season, self.series_id)
			cursor.execute(sql)
			list = []
			index = 0
			for row in cursor:
				if movieID and movieID == row["movie_id"]:
					currentIndex = index
					found = 1
				list.append(((row),))
				index += 1
			self["list"].setList(list)
			self["list"].moveToIndex(currentIndex)
			cursor.close() 
			connection.close()

	def listSelChanged(self):
		self.connectSelChangedTimer.start(100, True)

	def videoDescriptionUpdate(self):
		cur = self.currentSelectedMovie = self["list"].getCurrent()		
		if cur:
			if cur["screenshot"]:
				filename = os_path.join(self.imagePath, cur["screenshot"])
				if os_path.exists(filename):
					self["poster"].show()
					self["poster"].setPicture(filename)
				else:
					self["poster"].hide()
			else:
				self["poster"].hide()
		self.setMovieData()

	def setMovieData(self):
		cur = self.currentSelectedMovie
		if cur:
			self["aired"].setText(cur["firstaired"])
			if cur["rating"] != "":
				self["rating"].setText("%s / 10" % cur["rating"])
			else:
				self["rating"].setText("")
				
				
				
				
				
			if cur["rating"] !="":
				self["rating"].setText("%s / 10" % cur["rating"])
				rating = float(cur["rating"]) * 10
				self["rating_stars"].setValue(int(rating))
				self["rating_stars"].show()
			else:
 				self["rating"].setText("")
				self["rating_stars"].hide()
				
				
				
				
				
				
				
			self["director"].setText(cur["director"])
			self["writer"].setText(cur["writer"])
			self["overview"].setText(cur["overview"])
			
			
			
			if self.currentSelectedMovie["dts"] == 1:
				self["audio_icons"].setPixmapNum(0)
			elif self.currentSelectedMovie["ac3"] == 1:
				self["audio_icons"].setPixmapNum(1)
			elif self.currentSelectedMovie["stereo"] == 1:
				self["audio_icons"].setPixmapNum(2)
			if self.currentSelectedMovie["dts"] or self.currentSelectedMovie["ac3"] or self.currentSelectedMovie["stereo"]:
				self["audio_icons"].show()
			else:
				self["audio_icons"].hide()

			if self.currentSelectedMovie["hd"] == 1:
				self["definition"].setPixmapNum(0)
			else:
				self["definition"].setPixmapNum(1)

			if self.currentSelectedMovie["widescreen"] == 1:
				self["resolution"].setPixmapNum(0)
			else:
				self["resolution"].setPixmapNum(1)

			self["res"].setText("%d x %d" % (self.currentSelectedMovie["res_width"], self.currentSelectedMovie["res_height"]))
			
			
			self["framerate"].setText("%.3f frame rate" % self.currentSelectedMovie["framerate"])
			self["codec"].setText(self.currentSelectedMovie["codec"].replace("video","").upper())
			
			
			
			
			
			
			
			
			
			
			
			
		else:
			self["poster"].hide()
			self["aired"].setText("")
			self["rating"].setText("")
			self["rating_stars"].hide()
			self["director"].setText("")
			self["writer"].setText("")
			self["overview"].setText("")

	def updateMoviePositionInList(self):
		cur = self.currentSelectedMovie
		connection = OpenDatabase()
		if connection is not None:
			connection.text_factory = str
			connection.row_factory = self.dict_factory
			cursor = connection.cursor()
			sql = "SELECT movies.name, movies.movie_id, movies.serviceid, movies.filename, paths.path, movies.movieposition, movies.duration, movies.begin, movies.description, movies.event_id, movies.filesize, movies.screenshot, movies.dts, movies.ac3, movies.stereo, movies.hd, movies.widescreen, movies.res_width, movies.res_height, movies.framerate, movies.codec, movies_series.episode, movies_series.season, movies_series.writer, movies_series.director, movies_series.episodename, movies_series.rating, movies_series.firstaired, movies_series.overview, mountpoints.mountpoint, client_movieposition.clientmovieposition, events.extdescription, movies_series.serie_id FROM Movies INNER JOIN Paths ON movies.path_id = paths.path_id INNER JOIN mountpoints on Paths.link_id = Mountpoints.link_id INNER JOIN movies_series on movies_series.movie_id = movies.movie_id LEFT OUTER JOIN client_movieposition ON movies.movie_id = client_movieposition.movie_id AND client_movieposition.client_id = %d LEFT OUTER JOIN Events ON movies.event_id = events.event_id WHERE mountpoints.client_id = %d and movies.visible = 1 and movies.movie_id = %d;" % (ClientID.instance.getClientID(), ClientID.instance.getClientID(), cur["movie_id"])
			cursor.execute(sql)
			row = cursor.fetchone()
			cursor.close()  
			connection.close()
			if row:
				self.updateList(row)
				self.currentSelectedMovie = row
				self.setMovieData()

	def updateList(self, row):	
		self["list"].updateRowData(row)
		self.setMovieData()

	def cancel(self):
		if self.parent_must_reload:
			self.close(1)
		else:
			self.close()

	def menu(self):
		options = []
		options = [(_("Delete from database..."), self.askFordeleteMovieFromDatabase),]
		options.extend(((_("Delete..."), self.deleteMovie),))
		options.extend(((_("Mark as seen..."), boundFunction(self.setMovieStatus,True)),))
		options.extend(((_("Mark as unseen..."), boundFunction(self.setMovieStatus,False)),))
		options.extend(((_("Mark ALL as seen..."), boundFunction(self.setALLMovieStatus,True)),))
		options.extend(((_("Mark ALL as unseen..."), boundFunction(self.setALLMovieStatus,False)),))
		options.extend(((_("Show logs..."), self.showScanLog),))
		options.extend(((_("Add files..."), self.addFiles),))
		self.session.openWithCallback(self.menuCallback, ChoiceBox,list = options)

	def menuCallback(self, ret):
		ret and ret[1]()

	def setALLMovieStatus(self, status):
		setAllMovieStatusInDatabase(status, self.season, self.series_id)
		self.buildList(-1)
		self.videoDescriptionUpdate()
	
	def showScanLog(self):
		self.session.openWithCallback(self.movieBrowserClosed, ScanLogs, True)
	def addFiles(self):
		self.session.openWithCallback(self.movieBrowserClosed, MovieBrowser, True)
		
	def movieBrowserClosed(self, value):
		if value and value == 1:
			self.close(0)
		else:
			self.parent_must_reload = True
			self.buildList(-1)	
			self.videoDescriptionUpdate()	

	def deleteMovieFromDatabase(self, movieID, confirmed, connection, confirmed2):
		if confirmed and confirmed2:
			self.parent_must_reload = True
		VideoBase.deleteMovieFromDatabase(self, movieID, confirmed, connection, confirmed2)

	def nextMovie(self):
		self["list"].moveDown()
		self.currentSelectedMovie = self["list"].getCurrent()

	def previousMovie(self):
		self["list"].moveUp()
		self.currentSelectedMovie = self["list"].getCurrent()

	def playAllEpisodes(self):
		cur = self.currentSelectedMovie
		if cur:
			movieID = cur["movie_id"]
			row = self.getCurrentMovieData(movieID)
			if row:
				name = row["name"]
				serviceID = row["serviceid"]
				filename = row["filename"]
				path = os_path.join(row["mountpoint"],row["path"])
				if os_path.exists(os_path.join(path,filename)):
					eptuplelist = self["list"].getList()
					eptuplelist.reverse()
					self.session.openWithCallback(self.playerClosedAllEpisodes, VideoDBPlayerModalAllEpisodes, movieID, eptuplelist)
				else:
					self.session.open(MessageBox, _("Could not find the movie.\nEither the device is not mounted or the movie was deleted."), type = MessageBox.TYPE_INFO)

	def playerClosedAllEpisodes(self, result = None):
		if self.ref is not None:
			self.session.nav.playService(self.ref)
		else:
			self.session.nav.stopService()
		if result == 0:
			self.close(0)
		else:
			self.buildList(self["list"].getCurrentIndex())
			self.videoDescriptionUpdate()

class FilterListScreen(Screen):
	GENRE = 0
	ACTOR = 1
	DIRECTOR = 2
	CAST = 3
	skin = """
		<screen name="FilterListScreen" position="center,center" size="800,550" flags="wfNoBorder" title="Filter">
			<eLabel backgroundColor="#55000000" position="0,0" size="800,550"  zPosition="-1"/>
			<widget render="Label" source="title" position="5,5" size="790,40" zPosition="5" valign="center" font="Regular;24" foregroundColor="white" backgroundColor="#55000000"/>
			<ePixmap position="0,50" zPosition="4" size="140,40" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
			<ePixmap position="150,50" zPosition="4" size="140,40" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
			<ePixmap position="300,50" zPosition="4" size="140,40" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
			<ePixmap position="450,50" zPosition="4" size="140,40" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
			<widget render="Label" source="key_red" position="0,50" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
			<widget render="Label" source="key_green" position="150,50" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
			<widget render="Label" source="key_yellow" position="300,50" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
			<widget render="Label" source="key_blue" position="450,50" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
			<widget name="list" transparent="1" zPosition="2" position="0,100" size="800,390" scrollbarMode="showNever" 
				backgroundPixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/background_40_big.png"
				selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/VideoDB/icons/green_dark_transparent_big.png"/>
			<widget name="page" font="Regular;16" position="0,520" size="790,25" halign="right" transparent="0"  foregroundColor="#8a8a8a" backgroundColor="#55000000" />
		</screen>"""

	def __init__(self, session, mode, currentMovie):
		Screen.__init__(self, session)
		self.session = session		
		self.mode = mode
		if self.mode == self.CAST:
			self["list"] = VideoList(8)
		else:
			self["list"] = VideoList(7)
		self.sql = ""


		self["actionsTagList"] = ActionMap(["OkCancelActions", "ColorActions"],
		{
			"ok": self.okPressed,
			"cancel": self.cancelPressed,
			"green": self.greenPressed,
			"yellow": self.yellowPressed,
			"red": self.cancelPressed,
			"blue": self.bluePressed,
		}, -1)
		

		if self.mode == self.CAST:
			self.viewmode = "and crew.job = 'Actor'"
			self["key_green"] = StaticText("Actors")
			self["key_blue"] = StaticText(_("Misc"))
			self["key_yellow"] = StaticText(_("Director"))
			self["key_red"] = StaticText(_("Close"))
		else:
			if self.mode == self.GENRE:
				self.sortmode = "tags.tag"
			else:
				self.sortmode = "persons.name"
			self["key_green"] = StaticText("")
			self["key_blue"] = StaticText(_("Sort for count"))
			self["key_yellow"] = StaticText(_("Sort for text"))
			self["key_red"] = StaticText(_("Cancel"))
		self["title"] = StaticText("")
		self["page"] = Label("")


		if currentMovie:
			self.movieID = currentMovie["movie_id"]
			self.movieName = currentMovie["name"]
		else:
			self.movieID = 0
			self.movieName = ""


		self.currentService = self.session.nav.getCurrentlyPlayingServiceReference()
		filename = ""
		if currentMovie and currentMovie["wallpaper"]:
			filename = os_path.join(ClientID.instance.getImagePath(), currentMovie["wallpaper"])
		if self.mode == self.CAST and os_path.exists(filename):
			self.ref = eServiceReference(0x1013, 0, filename)
		else:
			self.ref = eServiceReference(0x1013, 0, DEFAULT_WALLPAPER)

		self.session.nav.playService(self.ref)

		self.onLayoutFinish.append(self.startRun)
		self.onClose.append(self.__onClose)


	def greenPressed(self):
		if self.mode == self.CAST:
			self.viewmode = "and crew.job = 'Actor'"
			self.buildList()

	def yellowPressed(self):
		if self.mode == self.CAST:
			self.viewmode = "and crew.job like 'Director%'"
		else:
			if self.mode == self.GENRE:
				self.sortmode = "tags.tag"
			else:
				self.sortmode = "persons.name"
		self.buildList()

	def bluePressed(self):
		if self.mode == self.CAST:
			self.viewmode = "and crew.job not like 'Director%' and crew.job <> 'Actor'"
		else:
			self.sortmode = "moviecount desc"
		self.buildList()

	def __onClose(self):
		self.session.nav.playService(self.currentService)

	def startRun(self):
		self.buildList()
		self["list"].connectSelChanged(self.listSelChanged)
	
			
	def getMode(self):
		return self.mode
		
	def buildList(self):
		if self.mode == self.GENRE:
			self.setTitle(_("Filter for Genre"))
			self["title"].setText(_("Filter for Genre"))
			self.sql = "select tags.tag_id as ID, tags.tag AS name , count(movies_tags.movie_id) as moviecount from tags inner join movies_tags on movies_tags.tag_id = tags.tag_id inner join movies on movies.movie_id = movies_tags.movie_id where movies.tmdb_movie_id is not null group by tags.tag_id order by %s;" % self.sortmode
		elif self.mode == self.ACTOR or self.mode == self.DIRECTOR:
			if self.mode == self.ACTOR:
				sqlW = "Actor"
				self["title"].setText(_("Filter for Actor"))
				self.setTitle(_("Filter for Actor"))
			else:
				sqlW = "Director"
				self["title"].setText(_("Filter for Director"))
				self.setTitle(_("Filter for Director"))
			self.sql = "select persons.person_id as ID, persons.name as name, count(crew.movie_id) as moviecount, crew.job from persons inner join crew on persons.person_id = crew.person_id where job='%s' group by persons.person_id order by %s;" % (sqlW, self.sortmode)
		elif self.mode == self.CAST:
			self["title"].setText(_("Crew for %s") % self.movieName)
			self.setTitle(_("Crew for %s") % self.movieName)
			self.sql = "select persons.person_id as ID, persons.name as name, crew.character, crew.job from persons inner join crew on persons.person_id = crew.person_id where crew.movie_id = %d %s order by crew.tmdb_order;" % (self.movieID, self.viewmode)
	
		if self.sql != "":
			connection = OpenDatabase(dictFactory = True)
			if connection is not None:
				connection.text_factory = str
				cursor = connection.cursor()
				cursor.execute(self.sql)
				list = []
				index = 0
				for row in cursor:
					list.append(((row),))
				self["list"].setList(list)
				self["list"].moveToIndex(0)

				cursor.close() 
				connection.close()
				self.setPageInfo()

	def setPageInfo(self):
		pageInfo = self["list"].calculatePages()
		self["page"].setText(_("Page %d/%d") % (pageInfo[0], pageInfo[1]))

	def listSelChanged(self):
		self.setPageInfo()

	def cancelPressed(self):
		self.close(-1, "", "", self.mode)
				
	def okPressed(self):
		sqlFilterInnerJoin = ""
		sqlFilterWhere = ""
		id = 0
		cur = self["list"].getCurrent()		
		if cur:
			id = cur["ID"]
			if self.mode == self.GENRE:
				sqlFilterInnerJoin = "INNER JOIN movies_tags ON movies.movie_id = movies_tags.movie_id"
			elif self.mode == self.ACTOR or self.mode == self.DIRECTOR or self.mode == self.CAST:
				sqlFilterInnerJoin = "INNER JOIN crew ON movies.movie_id = crew.movie_id"
	
			if self.mode == self.GENRE:
				sqlFilterWhere = ' and movies_tags.tag_id = %d' % id
			elif self.mode == self.ACTOR or self.mode == self.DIRECTOR or self.mode == self.CAST:
#				if self.mode == self.ACTOR:
#					sqlW = "Actor"
#				else:
#					sqlW = "Director"
				sqlFilterWhere = ' and (crew.job="%s" and crew.person_id = %d)' % (cur["job"], id)

		self.close(id, sqlFilterWhere, sqlFilterInnerJoin, self.mode)
