#
# VideoDB E2
#
# Coded by Dr.Best (c) 2013
# Support: www.dreambox-tools.info
# E-Mail: dr.best@dreambox-tools.info
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Multimedia GmbH.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Multimedia GmbH.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Multimedia GmbH.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.
#

from sqlite3 import dbapi2 as sqlite, OperationalError
from os import path as os_path, access as os_access, W_OK as os_W_OK
from Components.config import config
from Components.Network import iNetworkInfo
from Tools.HardwareInfo import HardwareInfo

from twisted.web.client import getPage as twisted_getPage, downloadPage as twisted_downloadPage, HTTPDownloader, HTTPClientFactory, _makeGetterFactory
from urllib import urlencode
from binascii import hexlify, unhexlify
from twisted.web import error
from os import remove as os_remove, makedirs as os_makedirs
from twisted.internet import defer

def getPage(url, parameter, json = False):
	videoDBDownloader = VideoDBDHTTP()
	return videoDBDownloader.getPage(url,  parameter, json)
def downloadPage(url, destination_file, parameter):
	videoDBDownloader = VideoDBDHTTP()
	return videoDBDownloader.downloadPage(url, destination_file, parameter)


class ClientID(object):
	instance = None
	def __init__(self, session, serial):
		self.session = session
		assert not ClientID.instance, "only one ClientID instance is allowed!"
		ClientID.instance = self # set instance
		self.clientID = None
		self.clientName = HardwareInfo().get_device_name()
		self.clientSerial = serial

		self.getIDFromDatabase()
		try:
			if self.clientID is None and config.plugins.videodb.databasepath.value != "":
				connection = OpenDatabase()
				if connection is None:
					config.plugins.videodb.databasepath.value = ""
					config.plugins.videodb.save()
				else:
					connection.close()
					self.setClientID()
		except: pass # this will never happen, but just to be sure, because contructor is called in autorun...
		self.cookies = {}
		from enigma import eTPM
		etpm = eTPM()
		self.staticParameter = {}
		self.staticParameter["challenge"] = ""
		self.staticParameter["rnd"] = ""
		self.staticParameter["model"] = open("/proc/stb/info/model", "r").readline().strip()
		self.staticParameter["l2cert"] = hexlify(etpm.getCert(eTPM.TPMD_DT_LEVEL2_CERT))
		self.staticParameter["l3cert"] = hexlify(etpm.getCert(eTPM.TPMD_DT_LEVEL3_CERT))
		self.timeout = 10
		self.base_tmdb_url = "http://image.tmdb.org/t/p/" # initial, but get current from webserver
		iNetworkInfo.onStateChanged.append(self.onNetworkStateChanged)

	def onNetworkStateChanged(self, state):
		if iNetworkInfo.isOnline():
			getPage("http://dbmc.dream-property.net:55680/movies2.py/getTMDBBaseUrl",  {}, False).addCallback(self.gotTMDBBaseUrl).addErrback(self.getTMDBBaseUrlError)

	def gotTMDBBaseUrl(self, result):
		if result != "error":
			ClientID.instance.base_tmdb_url = result

	def getTMDBBaseUrlError(self, error = None):
		print "[VideoDB] Error getting base url for tmdb:",  str(error.getErrorMessage())
		
	def getClientID(self):
		if not self.clientID:
			self.setClientID()
		return self.clientID

	def getClientName(self):
		return self.clientName

	def getIDFromDatabase(self):
		result = False
		if config.plugins.videodb.databasepath.value != "":
			connection = OpenDatabase(mustExist=True)
			if connection is not None:
				connection.text_factory = str
				cursor = connection.cursor()
				cursor.execute('Select client_id from clients where serial = "%s";'% (self.clientSerial))
				row = cursor.fetchone()
				if row:
					self.clientID = row[0]
					result = True
				cursor.close()
				connection.close()

				# check if new column or tables exists in database...
				connection, error = OpenDatabaseForWriting()
				if connection is not None:
					cursor = connection.cursor()
					connection.text_factory = str
					try:
						cursor.execute('Select tmdb_collection_id from movies where 1=0;')
					except:
						connection.execute('alter table movies add column tmdb_collection_id integer default 0;')
						connection.execute('CREATE TABLE IF NOT EXISTS Movie_Collections (tmdb_collection_id INTEGER NOT NULL PRIMARY KEY, name TEXT DEFAULT "", overview TEXT DEFAULT "", modified TIMESTAMP DEFAULT CURRENT_TIMESTAMP, cover_filename TEXT DEFAULT "", thumb_filename TEXT DEFAULT "", cover_middle_filename TEXT, db_modified TIMESTAMP DEFAULT CURRENT_TIMESTAMP, wallpaper TEXT DEAFULT "");')
						connection.execute('CREATE TRIGGER IF NOT EXISTS fkd_after_movies_deleted_del_collection \
					AFTER DELETE ON Movies \
					FOR EACH ROW \
						WHEN (old.tmdb_collection_id <> 0 AND (SELECT COUNT(movie_id) FROM Movies WHERE tmdb_collection_id = old.tmdb_collection_id) = 0) \
						BEGIN \
							DELETE FROM Movie_Collections WHERE tmdb_collection_id = OLD.tmdb_collection_id; \
						END; \
					')
						connection.commit()
						
					
					#####################for video web api#####################
					try:
						cursor.execute('Select last_used_ip from clients where 1=0;')
					except:
						connection.execute('alter table clients add column last_used_ip TEXT default "";')
						connection.commit()
					# unfortunately iNetwork isnt ready at this time...
					#from Components.ResourceManager import resourcemanager
					#n = resourcemanager.getResource("iNetwork")
					#r = n.ifaces["eth0"]["ip"]
					#ip = '.'.join(map(str, r))
					try: # do not crash because of getting the current ip
						ip = str(self.get_interface_ip("eth0"))
						cursor.execute('update clients set last_used_ip = "%s" where serial = "%s"' % (ip, self.clientSerial))
						connection.commit()
					except: pass # fuck that
					#####################for video web api#####################
					
					try:
						cursor.execute('Select playlist_id from Playlists where 1=0;')
					except:
						connection.execute('CREATE TABLE IF NOT EXISTS Playlists (playlist_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, playlist_text TEXT NOT NULL, autofill INTEGER DEFAULT 0, sort_type INTEGER DEFAULT 0);')
						
					try:
						cursor.execute('Select playlist_movies_id from Playlist_Movies where 1=0;')
					except:
						connection.execute('CREATE TABLE IF NOT EXISTS Playlist_Movies (playlist_movies_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, playlist_id INTEGER NOT NULL, movie_id INTEGER NOT NULL, UNIQUE(playlist_id,movie_id));')
						connection.execute('CREATE TRIGGER IF NOT EXISTS fkd_after_movies_deleted_del_from_playlist \
					AFTER DELETE ON Movies \
					FOR EACH ROW \
					BEGIN\
						DELETE FROM Playlist_Movies WHERE movie_id = OLD.movie_id; \
					END; \
					')
					try:
						cursor.execute('Select three_d from movies where 1=0;')
					except:
						connection.execute('alter table movies add column three_d INTEGER DEFAULT 0;')
					cursor.close()
					connection.close()
				
		if not result:
			self.clientID  = None
		return result
	      
	def get_interface_ip(self, ifname):
	      import socket
	      import fcntl
	      import struct
	      s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	      return socket.inet_ntoa(fcntl.ioctl(s.fileno(), 0x8915, struct.pack('256s', ifname[:15]))[20:24])	      
	
	def setClientID(self):
		self.clientID = None
		if config.plugins.videodb.databasepath.value  == "":
			return False
		result = self.getIDFromDatabase()
		if not result:
			connection, error = OpenDatabaseForWriting()
			if connection is not None:
				cursor = connection.cursor()
				cursor.execute('INSERT INTO Clients (client, serial) values (?,?);' , (self.clientName, self.clientSerial))
				self.clientID = cursor.lastrowid
				# initialize personal settings for client....
				connection.execute('INSERT INTO Settings (name, value, client_id) VALUES ("cacheListView", "", %d);' % (self.clientID))
				connection.execute('INSERT INTO Settings (name, value, client_id) VALUES ("tvdbAutomaticServiceUpdateList", "", %d);' % (self.clientID))
				connection.execute('INSERT INTO DBVersion (version) values ("1");')
				connection.commit()
				cursor.close()
				connection.close()
				result = True
		return result
		
	def getImagePath(self):
		imagepath = os_path.join(config.plugins.videodb.databasepath.value ,"videodb_images")
		if not os_path.exists(imagepath):
			os_makedirs(imagepath)
		return imagepath
	
	def getImageTempPath(self):
		imagepath = os_path.join(config.plugins.videodb.databasepath.value ,"videodb_temp_images")
		if not os_path.exists(imagepath):
			try:
				os_makedirs(imagepath)
			except:
				imagepath = "/tmp/videodb_temp_images"
				os_makedirs(imagepath)
		return imagepath
		

# i need cookies, so new HTTPDownloader is needed 
import types
class VideoDBHTTPDownloader(HTTPDownloader):
	def __init__(self, url, fileOrName,
		method='GET', postdata=None, headers=None,
		agent="dbmc download-client", supportPartial=0, cookies = None):
		self.requestedPartial = 0
		if isinstance(fileOrName, types.StringTypes):
			self.fileName = fileOrName
			self.file = None
			if supportPartial and os_path.exists(self.fileName):
				fileLength = os_path.getsize(self.fileName)
				if fileLength:
					self.requestedPartial = fileLength
					if headers == None:
						headers = {}
					headers["range"] = "bytes=%d-" % fileLength
		else:
			self.file = fileOrName
		HTTPClientFactory.__init__(self, url, method=method, postdata=postdata, headers=headers, agent=agent, cookies = cookies)
		self.deferred = defer.Deferred()
		self.waiting = 1


# i need cookies, so new HTTPDownloader is needed , tell this twisted-downloadPage
def VideoDBdownloadPage(url, file, contextFactory=None, *args, **kwargs):
	factoryFactory = lambda url, *a, **kw: VideoDBHTTPDownloader(url, file, *a, **kw)
	return _makeGetterFactory(url,factoryFactory,contextFactory=contextFactory,*args, **kwargs).deferred



class VideoDBDHTTP(object):
	GETPAGE = 1
	DOWNLOADPAGE = 2
	def __init__(self):
		self.staticParameter = ClientID.instance.staticParameter
		self.cookies = ClientID.instance.cookies
		self.timeout = 20
		self.deferred = defer.Deferred()
		self.mode = self.GETPAGE
		self.headers = {'Content-Type':'application/x-www-form-urlencoded'}

	def callbackErr(self, data, url, parameter, destination_file = None):
		print "[VideoDBDHTTP Error] : ", str(data.getErrorMessage())
		if isinstance(data.value, error.Error):
			if data.value.status == "401":
				from enigma import eTPM
				etpm = eTPM()
				if isinstance(data.value.response, str):
					self.staticParameter["challenge"] = hexlify(etpm.challenge(data.value.response))
					self.staticParameter["rnd"] = data.value.response
					p = self.staticParameter.copy()
					if parameter is not None:
						p.update(parameter)
					if self.mode == self.GETPAGE:
						twisted_getPage(url=url, agent="dbmc getPage-client", cookies=self.cookies, timeout=self.timeout, method='POST', headers=self.headers, postdata=urlencode(p)).addCallback(self.callbackOK).addErrback(self.callbackErr, url, parameter)
					else:
						VideoDBdownloadPage(url, file(destination_file, 'wb'), cookies=self.cookies, method='POST', headers=self.headers, postdata=urlencode(p)).addErrback(self.callbackErr, url, parameter, destination_file).addCallback(self.callbackOK)
				else:
					self.deferred.errback(data)
			else:
				self.deferred.errback(data)
				print data.value.response 
		else:
			self.deferred.errback(data)

	def callbackOK(self, data):
		self.deferred.callback(data)

	def getPage(self, url, parameter, json = False):
		self.mode = self.GETPAGE
		p = self.staticParameter.copy()
		p.update(parameter)
		if json:
			self.headers["Accept"] = "application/json"
		twisted_getPage(url=url, agent="dbmc getPage-client", cookies=self.cookies, timeout=self.timeout, method='POST', headers=self.headers, postdata=urlencode(p)).addCallback(self.callbackOK).addErrback(self.callbackErr, url, parameter)
		return self.deferred

	def downloadPage(self, url, destination_file, parameter):
		self.mode = self.DOWNLOADPAGE
		p = self.staticParameter.copy()
		p.update(parameter)
		VideoDBdownloadPage(url, file(destination_file, 'wb'), cookies=self.cookies, method='POST', headers=self.headers, postdata=urlencode(p)).addErrback(self.callbackErr, url, parameter, destination_file).addCallback(self.callbackOK)
		return self.deferred

##################



def OpenDatabaseForWriting(timeout = 10):
	errorString = ""
	mustExist = True
	connection = None
	
	if config.plugins.videodb.databasepath.value == "":
		return None, "Database was not initialized."
	



	connectstring = os_path.join(config.plugins.videodb.databasepath.value ,"videodb.db")
	db_exists = os_path.exists(connectstring) # dummy --> eventuell noch daten fuellen lassen
	if mustExist and not db_exists:
		return None, "Error: Can not find database file (%s)" % connectstring
	try:
		connection = sqlite.connect(connectstring, timeout=timeout)
		if not os_access(connectstring, os_W_OK):
			print "[VideoDB] Error: database file needs to be writable, can not open %s for writing..." % connectstring
			connection.close()
			return None, "Error: Database file needs to be writable, can not open %s for writing..." % connectstring
			
		connection.text_factory = str
		cursor = connection.cursor()
		try:
			cursor.execute("delete from settings where 1 = 0;") # dummy, that locks the database
			#cursor.execute("BEGIN IMMEDIATE TRANSACTION;")
		except OperationalError, msg:
			print "[VideoDB] OperationalError: %s" % msg
			errorString = "OperationalError: %s" % msg
			cursor.close()
			connection.close()
			connection = None
		return connection, errorString
			
			
	except:
		print "[VideoDB] unable to open database file: %s" % connectstring
		errorString = "Error: unable to open database file: %s" % connectstring
		return None, errorString


def dict_factory(cursor, row):
	dictList = {}
	for idx, col in enumerate(cursor.description):
		dictList[col[0]] = row[idx]
	return dictList

def OpenDatabase(mustExist=False, dictFactory = False):
	connection = None
	
	if config.plugins.videodb.databasepath.value == "":
		return None
	
	
	connectstring = os_path.join(config.plugins.videodb.databasepath.value ,"videodb.db")
	db_exists = os_path.exists(connectstring) # dummy --> eventuell noch daten fuellen lassen
	if mustExist and not db_exists:
		return None
	try:
		connection = sqlite.connect(connectstring, timeout=10)
		connection.text_factory = str
		if dictFactory:
			connection.row_factory = dict_factory

		if not os_access(connectstring, os_W_OK):
			print "[VideoDB] Error: database file needs to be writable, can not open %s for writing..." % connectstring
			connection.close()
			return None
	except:
		print "[VideoDB] unable to open database file: %s" % connectstring
		return None


	if not db_exists:
#	if 1 == 1:

		connection.execute('CREATE TABLE IF NOT EXISTS Clients (client_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, client TEXT NOT NULL, serial TEXT NOT NULL UNIQUE, last_used_ip TEXT default "");')
		
		
		connection.execute('CREATE TABLE IF NOT EXISTS Mountpoints (mountpoint_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, client_id INTEGER NOT NULL, mountpoint TEXT NOT NULL, link_id INTEGER, UNIQUE(client_id,mountpoint));')
		
		# index
		# CREATE INDEX IF NOT EXISTS mountpoints_client_id_idx ON Mountpoints(client_id);
		# CREATE INDEX IF NOT EXISTS mountpoints_link_id_idx ON Mountpoints(link_id);


		connection.execute('CREATE TABLE IF NOT EXISTS Paths (path_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, path TEXT NOT NULL, link_id INTEGER NOT NULL);')
		
		# index
		# CREATE INDEX IF NOT EXISTS paths_idx ON Paths (link_id);


		connection.execute('CREATE TABLE IF NOT EXISTS Events (event_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, eventname TEXT NOT NULL, description TEXT NOT NULL, extdescription TEXT NOT NULL, duration INTEGER NOT NULL, begintime INTEGER NOT NULL);')


#		connection.execute('CREATE TABLE IF NOT EXISTS Directories (directory_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, directory TEXT NOT NULL UNIQUE, mountpoint TEXT NOT NULL, liststyle INTEGER NOT NULL DEFAULT 1, name TEXT NOT NULL, inotify_scanner INTEGER NOT NULL DEFAULT 0);')

		connection.execute('CREATE TABLE IF NOT EXISTS Tags (tag_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, tag TEXT NOT NULL UNIQUE);')

		connection.execute('CREATE TABLE IF NOT EXISTS Servicenames (servicename_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, servicename TEXT NOT NULL);')

		connection.execute('CREATE TABLE IF NOT EXISTS Movies_Tags (movie_tag_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, movie_id INTEGER NOT NULL, tag_id INTEGER NOT NULL, UNIQUE(movie_id,tag_id));')
		
		# index
		# CREATE INDEX IF NOT EXISTS movies_tags_movie_id_idx ON Movies_Tags(movie_id);
		# CREATE INDEX IF NOT EXISTS movies_tags_tag_id_idx ON Movies_Tags(tag_id);
		

		connection.execute('CREATE TABLE IF NOT EXISTS Movies (movie_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, filename TEXT NOT NULL, path_id INTEGER NOT NULL, serviceid INTEGER NOT NULL, begin INTEGER NOT NULL, name TEXT NOT NULL, servicename_id INTEGER NOT NULL, event_id INTEGER NOT NULL, movieposition INTEGER NOT NULL, duration INTEGER NOT NULL, description TEXT NOT NULL, filesize INTEGER NOT NULL, modified TIMESTAMP DEFAULT CURRENT_TIMESTAMP, visible INTEGER NOT NULL DEFAULT 1, recording INTEGER NOT NULL DEFAULT 0, cover_filename TEXT DEFAULT "", thumb_filename TEXT DEFAULT "", tmdb_movie_id INTEGER, trash INTEGER DEFAULT 0, db_modified TIMESTAMP DEFAULT CURRENT_TIMESTAMP, ismovie INTEGER not NULL, wallpaper TEXT, screenshot TEXT, released TEXT, rating TEXT, cover_middle_filename TEXT, runtime TEXT, ac3 INTEGER, dts INTEGER, fivepointone INTEGER, stereo INTEGER, codec TEXT, container TEXT, res_width INTEGER, res_height INTEGER, framerate FLOAT, widescreen INTEGER, hd INTEGER, video_codec_text TEXT, tmdb_collection_id integer default 0, three_d INTEGER DEFAULT 0, UNIQUE(filename, path_id));')
		
		
		connection.execute('CREATE TABLE IF NOT EXISTS Movie_Collections (tmdb_collection_id INTEGER NOT NULL PRIMARY KEY, name TEXT DEFAULT "", overview TEXT DEFAULT "", modified TIMESTAMP DEFAULT CURRENT_TIMESTAMP, cover_filename TEXT DEFAULT "", thumb_filename TEXT DEFAULT "", cover_middle_filename TEXT, db_modified TIMESTAMP DEFAULT CURRENT_TIMESTAMP, wallpaper TEXT DEAFULT "");')
		
		
		connection.execute('CREATE TABLE IF NOT EXISTS ScanLogs (scanlog_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, movie_id INTEGER NOT NULL, search_type INTEGER, scanlog_text TEXT, found INTEGER, modified TIMESTAMP DEFAULT CURRENT_TIMESTAMP);')
		
		# select mountpoint, path, filename, name from scanlogs inner join movies on scanlogs.movie_id = movies.movie_id INNER JOIN Paths ON movies.path_id = paths.path_id INNER JOIN mountpoints on Paths.link_id = Mountpoints.link_id where found = 1;
		
		
		
		
		#(((('ac3', 'deu', '5.1', 1551L, 6L, 384L, 'Audio: ac3, 48000 Hz, 5.1, s16, 384 kb/s'), ('ac3', 'eng', 'stereo', 3L, 2L, 384L, 'Audio: ac3, 48000 Hz, stereo, s16, 384 kb/s')), (1L, 0L, 1L, 1L)), ('h264', 1920L, 1080L, 50.0, 3579L, 1L, 'mpegts', 0L, 1L, 'Video: h264 (High), yuv420p, 1920x1080 [PAR 1:1 DAR 16:9]'))
		
		connection.execute('CREATE TABLE IF NOT EXISTS Audio (audio_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, movie_id INTEGER NOT NULL, codec TEXT, language TEXT, description TEXT, codec_id INTEGER, channels INTEGER, bitrate INTEGER, audio_text TEXT);')

		connection.execute('CREATE TABLE IF NOT EXISTS DBVersion (dbversion_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, version TEXT);')

	
		
		# index
		# CREATE INDEX IF NOT EXISTS movies_servicename_idx ON Movies(servicename_id);
		# CREATE INDEX IF NOT EXISTS movies_event_idx ON Movies(event_id);
		# CREATE INDEX IF NOT EXISTS movies_tmdb_movie_idx ON Movies(tmdb_movie_id);
		# CREATE INDEX IF NOT EXISTS movies_path_idx ON Movies(path_id);
		# CREATE INDEX IF NOT EXISTS movies_begin_idx ON Movies(begin);
		# CREATE INDEX IF NOT EXISTS movies_name_idx ON Movies(name);

		


		connection.execute('CREATE TABLE IF NOT EXISTS Client_MoviePosition (client_movieposition_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, movie_id INTEGER NOT NULL, client_ID INTEGER NOT NULL, clientmovieposition INTEGER NOT NULL, UNIQUE(movie_id, client_id));')
		
		# index
		# CREATE INDEX IF NOT EXISTS client_movieposition_movie_id_idx ON Client_MoviePosition(movie_id);
		# CREATE INDEX IF NOT EXISTS client_movieposition_client_id_idx ON Client_MoviePosition(client_id);
		
		
		# TMDb Data

		connection.execute('CREATE TABLE IF NOT EXISTS Studios (studio_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, studio TEXT NOT NULL UNIQUE);')
		connection.execute('CREATE TABLE IF NOT EXISTS Movies_Studios (movie_studio_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, movie_id INTEGER NOT NULL, studio_id INTEGER NOT NULL, UNIQUE(movie_id,studio_id));')

		connection.execute('CREATE TABLE IF NOT EXISTS Persons (person_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, thumb TEXT DEFAULT "" );')

		connection.execute('CREATE TABLE IF NOT EXISTS Crew (crew_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, movie_id INTEGER NOT NULL, person_id  INTEGER NOT NULL, job TEXT NOT NULL, character TEXT, tmdb_order INTEGER, UNIQUE(movie_id, person_id, job));')
		
		# index
		# CREATE INDEX IF NOT EXISTS crew_movie_id_idx ON Crew(movie_id);
		# CREATE INDEX IF NOT EXISTS crew_person_id_idx ON Crew(person_id);
		# CREATE INDEX IF NOT EXISTS crew_job_idx ON Crew(job);
		


		connection.execute('CREATE TABLE IF NOT EXISTS images_to_delete (images_to_delete_id INTEGER NOT NULL PRIMARY KEY, filename TEXT DEFAULT "" );')


		#TVDb Data

		connection.execute('CREATE TABLE IF NOT EXISTS Series (serie_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, overview TEXT NOT NULL, tvdb_serie_id INTEGER NOT NULL, banner TEXT, banner_small TEXT, thumb_poster TEXT, poster TEXT, wallpaper TEXT, status TEXT, rating TEXT, network TEXT, genre TEXT, firstaired TEXT, runtime INTEGER);')
		
		# index
		# CREATE INDEX IF NOT EXISTS series_tvdb_serie_id_idx ON Series(tvdb_serie_id);

		connection.execute('CREATE TABLE IF NOT EXISTS Movies_Series (movie_series_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, movie_id INTEGER NOT NULL, serie_id INTEGER NOT NULL, season INTEGER NOT NULL, episode INTEGER NOT NULL, writer TEXT, director TEXT, episodename TEXT, firstaired TEXT, rating TEXT, overview TEXT, tvdb_episode_ID INTEGER NOT NULL, UNIQUE(movie_id,serie_id));')
		
		# index
		# CREATE INDEX IF NOT EXISTS movies_series_movie_id_idx ON Movies_Series(movie_id);
		# CREATE INDEX IF NOT EXISTS movies_series_serie_id_idx ON Movies_Series(serie_id);
		
		connection.execute('CREATE TABLE IF NOT EXISTS TVDbSeriesName (tvdb_series_name INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, originname TEXT NOT NULL, tvdbname TEXT NOT NULL, UNIQUE(originname));')
		
		
		connection.execute('CREATE TABLE IF NOT EXISTS Settings (setting_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, value BLOB, client_ID INTEGER NOT NULL);')
		
		connection.execute('CREATE TABLE IF NOT EXISTS Playlists (playlist_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, playlist_text TEXT NOT NULL, autofill INTEGER DEFAULT 0, sort_type INTEGER DEFAULT 0);')
		connection.execute('CREATE TABLE IF NOT EXISTS Playlist_Movies (playlist_movies_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, playlist_id INTEGER NOT NULL, movie_id INTEGER NOT NULL, UNIQUE(playlist_id,movie_id));')
		connection.execute('CREATE TRIGGER IF NOT EXISTS fkd_after_movies_deleted_del_from_playlist \
					AFTER DELETE ON Movies \
					FOR EACH ROW \
					BEGIN\
						DELETE FROM Playlist_Movies WHERE movie_id = OLD.movie_id; \
					END; \
					')
		
		# Trigger (unfortunately FOREIGN KEY is not working with sqlite...so I did the foreign key contraints with triggers)

		# try if no foreign-key value (directory_id) references on table directories...if so, delete row with directory_id
		# EDIT ---> deactivated this trigger... Have to think about it...
#		connection.execute('CREATE TRIGGER IF NOT EXISTS fkd_movie_directories \
#					AFTER DELETE ON Movies \
#					FOR EACH ROW \
#							WHEN ((SELECT directory_id FROM Movies WHERE directory_id = OLD.directory_id) IS NULL) \
#							BEGIN \
#								DELETE FROM Directories WHERE directory_id = OLD.directory_id; \
#							END; \
#					')



		# update db_modified with current date after updating movie (for cachelist)
		connection.execute('CREATE TRIGGER IF NOT EXISTS fkd_after_mountpoint_sinserted \
					AFTER INSERT ON Mountpoints \
					FOR EACH ROW \
					BEGIN\
						UPDATE Mountpoints set link_id = new.ROWID WHERE mountpoint_id = new.ROWID and link_id is NULL; \
					END; \
					')

					



		# update db_modified with current date after updating movie (for cachelist)
		connection.execute('CREATE TRIGGER IF NOT EXISTS fkd_after_movie_updated \
					AFTER UPDATE ON Movies \
					FOR EACH ROW \
					BEGIN\
						UPDATE Movies set db_modified = DATETIME("NOW") WHERE movie_id = OLD.movie_id; \
					END; \
					')



		# try if no foreign-key value (servicename_id) references on table servicenames...if so, delete row with servicename_id
		connection.execute('CREATE TRIGGER IF NOT EXISTS fkd_movie_servicenames \
					AFTER DELETE ON Movies \
					FOR EACH ROW \
							WHEN ((SELECT servicename_id FROM Movies WHERE servicename_id = OLD.servicename_id) IS NULL) \
							BEGIN \
								DELETE FROM Servicenames WHERE servicename_id = OLD.servicename_id; \
							END; \
					')


		# delete movies_tags with movie_id after deleting movie
		connection.execute('CREATE TRIGGER IF NOT EXISTS fkd_before_movie_deleted_movies_tags \
					AFTER DELETE ON Movies \
					FOR EACH ROW \
					BEGIN\
						DELETE FROM movies_tags WHERE movie_id = OLD.movie_id; \
					END; \
					')

		# delete events with event_id after deleting movie
		connection.execute('CREATE TRIGGER IF NOT EXISTS fkd_before_movie_deleted_events \
					AFTER DELETE ON Movies \
					FOR EACH ROW \
					BEGIN\
						DELETE FROM events WHERE event_id = OLD.event_id; \
					END; \
					')


		# check foreign-key(path_id) is in movies before deleting Paths
		connection.execute('CREATE TRIGGER IF NOT EXISTS fkd_path_id \
			BEFORE DELETE ON Paths \
			FOR EACH ROW BEGIN \
			  SELECT CASE \
			    WHEN ((SELECT path_id FROM Movies WHERE path_id = OLD.path_id) IS NOT NULL) \
			    THEN RAISE(ABORT, "delete on table Paths violates foreign key in Movies") \
			  END; \
			END; \
			');


		# check foreign-key(tag_id) is in movies_tags before deleting Tags
		connection.execute('CREATE TRIGGER IF NOT EXISTS fkd_tag_id \
			BEFORE DELETE ON Tags \
			FOR EACH ROW BEGIN \
			  SELECT CASE \
			    WHEN ((SELECT tag_id FROM Movies_Tags WHERE tag_id = OLD.tag_id) IS NOT NULL) \
			    THEN RAISE(ABORT, "delete on table Tags violates foreign key in Movies_Tags") \
			  END; \
			END; \
			');

		# check foreign-key(servicename_id) is in movies before deleting servicenames
		connection.execute('CREATE TRIGGER IF NOT EXISTS fkd_servicename_id \
			BEFORE DELETE ON Servicenames \
			FOR EACH ROW BEGIN \
			  SELECT CASE \
			    WHEN ((SELECT servicename_id FROM Movies WHERE servicename_id = OLD.servicename_id) IS NOT NULL) \
			    THEN RAISE(ABORT, "delete on table Servicenames violates foreign key in Movies") \
			  END; \
			END; \
			');

		# check foreign-key(event_id) is in movies before deleting events
		connection.execute('CREATE TRIGGER IF NOT EXISTS fkd_events_id \
			BEFORE DELETE ON Events \
			FOR EACH ROW BEGIN \
			  SELECT CASE \
			    WHEN ((SELECT event_id FROM Movies WHERE event_id = OLD.event_id) IS NOT NULL) \
			    THEN RAISE(ABORT, "delete on table Events violates foreign key in Movies") \
			  END; \
			END; \
			');

		# Triggers for TMDb tables

		# delete movies_studios with movie_id after deleting movie
		connection.execute('CREATE TRIGGER IF NOT EXISTS fkd_before_movie_deleted_movies_studios \
					AFTER DELETE ON Movies \
					FOR EACH ROW \
					BEGIN\
						DELETE FROM movies_studios WHERE movie_id = OLD.movie_id; \
					END; \
					')

		# check foreign-key(studio_id) is in movies_studios before deleting Studios
		connection.execute('CREATE TRIGGER IF NOT EXISTS fkd_studio_id \
			BEFORE DELETE ON Studios \
			FOR EACH ROW BEGIN \
			  SELECT CASE \
			    WHEN ((SELECT studio_id FROM movies_studios WHERE studio_id = OLD.studio_id) IS NOT NULL) \
			    THEN RAISE(ABORT, "delete on table Studios violates foreign key in Movies_Studios") \
			  END; \
			END; \
			');

		# check foreign-key(person_id) is in crew before deleting Persons
		connection.execute('CREATE TRIGGER IF NOT EXISTS fkd_person_id \
			BEFORE DELETE ON Persons \
			FOR EACH ROW BEGIN \
			  SELECT CASE \
			    WHEN ((SELECT person_id FROM crew WHERE person_id = OLD.person_id) IS NOT NULL) \
			    THEN RAISE(ABORT, "delete on table Persons violates foreign key in Crew") \
			  END; \
			END; \
			');


		# delete crew with movie_id after deleting movie
		connection.execute('CREATE TRIGGER IF NOT EXISTS fkd_after_movie_deleted_crew \
					AFTER DELETE ON Movies \
					FOR EACH ROW \
					BEGIN\
						DELETE FROM crew WHERE movie_id = OLD.movie_id; \
					END; \
					')

		# delete persons with person_id after deleting crew
		# try if no foreign-key value (person_id) references on table persons...if so, delete row with person_id
		connection.execute('CREATE TRIGGER IF NOT EXISTS fkd_after_crew_deleted_persons \
					AFTER DELETE ON Crew \
					FOR EACH ROW \
							WHEN ((SELECT person_id FROM crew WHERE person_id = OLD.person_id) IS NULL) \
							BEGIN \
								DELETE FROM persons WHERE person_id = OLD.person_id; \
							END; \
					')

		# try if no foreign-key value (studio_id) references on movies_studios...if so, delete row with studio_id
		connection.execute('CREATE TRIGGER IF NOT EXISTS fkd_after_movies_studio_deleted_studio \
					AFTER DELETE ON movies_studios \
					FOR EACH ROW \
							WHEN ((SELECT studio_id FROM Movies_Studios WHERE studio_id = OLD.studio_id) IS NULL) \
							BEGIN \
								DELETE FROM studios WHERE studio_id = OLD.studio_id; \
							END; \
					')

		# after deleting persons, copy thumb files to image table, easier to delete the physical files for me
		connection.execute('CREATE TRIGGER IF NOT EXISTS fkd_after_persons_deleted_copy_to_image_table \
					AFTER DELETE ON Persons \
					FOR EACH ROW \
						WHEN (old.thumb <> "" AND (SELECT COUNT(person_id) FROM crew WHERE person_id = OLD.person_id) = 0) \
						BEGIN \
							INSERT INTO images_to_delete (filename) VALUES (old.thumb); \
						END; \
					')

		# after deleting movies, copy thumb files to image table, easier to delete the physical files for me
		connection.execute('CREATE TRIGGER IF NOT EXISTS fkd_after_movies_deleted_copy_to_thumb_image_table \
					AFTER DELETE ON Movies \
					FOR EACH ROW \
						WHEN (old.thumb_filename <> "" AND (SELECT COUNT(movie_id) FROM Movies WHERE thumb_filename = old.thumb_filename) = 0) \
						BEGIN \
							INSERT INTO images_to_delete (filename) VALUES (old.thumb_filename); \
						END; \
					')

		# after deleting movies, copy cover files to image table, easier to delete the physical files for me
		connection.execute('CREATE TRIGGER IF NOT EXISTS fkd_after_movies_deleted_copy_to_cover_image_table \
					AFTER DELETE ON Movies \
					FOR EACH ROW \
						WHEN (old.cover_filename <> "" AND (SELECT COUNT(movie_id) FROM Movies WHERE cover_filename = old.cover_filename) = 0) \
						BEGIN \
							INSERT INTO images_to_delete (filename) VALUES (old.cover_filename); \
						END; \
					')


		# after deleting movies, copy cover files to image table, easier to delete the physical files for me
		connection.execute('CREATE TRIGGER IF NOT EXISTS fkd_after_movies_deleted_copy_to_wallpaper_image_table \
					AFTER DELETE ON Movies \
					FOR EACH ROW \
						WHEN (old.wallpaper <> "" AND (SELECT COUNT(movie_id) FROM Movies WHERE wallpaper = old.wallpaper) = 0) \
						BEGIN \
							INSERT INTO images_to_delete (filename) VALUES (old.wallpaper); \
						END; \
					')

		# after deleting movies, copy cover files to image table, easier to delete the physical files for me
		connection.execute('CREATE TRIGGER IF NOT EXISTS fkd_after_movies_deleted_copy_to_cover_middle_filename_image_table \
					AFTER DELETE ON Movies \
					FOR EACH ROW \
						WHEN (old.cover_middle_filename <> "" AND (SELECT COUNT(movie_id) FROM Movies WHERE cover_middle_filename = old.cover_middle_filename) = 0) \
						BEGIN \
							INSERT INTO images_to_delete (filename) VALUES (old.cover_middle_filename); \
						END; \
					')

		# after deleting movies, copy cover files to image table, easier to delete the physical files for me
		connection.execute('CREATE TRIGGER IF NOT EXISTS fkd_after_movies_deleted_copy_to_screenshot_image_table \
					AFTER DELETE ON Movies \
					FOR EACH ROW \
						WHEN (old.screenshot <> "" AND (SELECT COUNT(movie_id) FROM Movies WHERE screenshot = old.screenshot) = 0) \
						BEGIN \
							INSERT INTO images_to_delete (filename) VALUES (old.screenshot); \
						END; \
					')

					
		# Triggers for TVDb tables
		
		# delete movies_series with movie_id after deleting movie
		connection.execute('CREATE TRIGGER IF NOT EXISTS fkd_before_movie_deleted_movies_series \
					AFTER DELETE ON Movies \
					FOR EACH ROW \
					BEGIN\
						DELETE FROM movies_series WHERE movie_id = OLD.movie_id; \
					END; \
					')

		# check foreign-key(series_id) is in movies_series before deleting Series
		connection.execute('CREATE TRIGGER IF NOT EXISTS fkd_serie_id \
			BEFORE DELETE ON Series \
			FOR EACH ROW BEGIN \
			  SELECT CASE \
			    WHEN ((SELECT serie_id FROM movies_series WHERE serie_id = OLD.serie_id) IS NOT NULL) \
			    THEN RAISE(ABORT, "delete on table Series violates foreign key in Movies_Series") \
			  END; \
			END; \
			');
			
		# try if no foreign-key value (serie_id) references on movies_series...if so, delete row with serie_id
		connection.execute('CREATE TRIGGER IF NOT EXISTS fkd_after_movies_series_deleted_serie \
					AFTER DELETE ON movies_series \
					FOR EACH ROW \
							WHEN ((SELECT serie_id FROM Movies_Series WHERE serie_id = OLD.serie_id) IS NULL) \
							BEGIN \
								DELETE FROM series WHERE serie_id = OLD.serie_id; \
							END; \
					')


		# after deleting persons, copy thumb files to image table, easier to delete the physical files for me
		connection.execute('CREATE TRIGGER IF NOT EXISTS fkd_after_series_deleted_copy_to_image_table \
					AFTER DELETE ON Series \
					FOR EACH ROW \
						WHEN (old.banner <> "" AND (SELECT COUNT(serie_id) FROM Movies_Series WHERE serie_id = OLD.serie_id) = 0) \
						BEGIN \
							INSERT INTO images_to_delete (filename) VALUES (old.banner); \
						END; \
					')
					
					
		# after deleting movies, check collection for deleting
		connection.execute('CREATE TRIGGER IF NOT EXISTS fkd_after_movies_deleted_del_collection \
					AFTER DELETE ON Movies \
					FOR EACH ROW \
						WHEN (old.tmdb_collection_id <> 0 AND (SELECT COUNT(movie_id) FROM Movies WHERE tmdb_collection_id = old.tmdb_collection_id) = 0) \
						BEGIN \
							DELETE FROM Movie_Collections WHERE tmdb_collection_id = OLD.tmdb_collection_id; \
						END; \
					')

		if ClientID.instance:
			ClientID.instance.setClientID()			
	return connection
