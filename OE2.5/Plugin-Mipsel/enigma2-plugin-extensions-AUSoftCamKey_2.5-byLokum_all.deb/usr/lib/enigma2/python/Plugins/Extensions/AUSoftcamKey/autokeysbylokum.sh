#!/bin/sh
echo "*     ..:: B E K L E Y İ N İ Z ::..       *"
echo "*******************************************"
wget http://www.lokumsat.esy.es/CaMs-EmU/SoftCam.Key -qO /etc/tuxbox/config/SoftCam.Key
wget http://www.lokumsat.esy.es/CaMs-EmU/SoftCam.Key -qO /usr/keys/SoftCam.Key
wget http://www.lokumsat.esy.es/CaMs-EmU/constant.cw -qO /etc/tuxbox/config/constant.cw
wget http://www.lokumsat.esy.es/CaMs-EmU/constant.cw -qO /usr/keys/constant.cw
wget http://www.lokumsat.esy.es/CaMs-EmU/oscam.keys -qO /usr/keys/oscam.keys
wget http://www.lokumsat.esy.es/CaMs-EmU/Wicardd/wicardd.conf -qO /etc/tuxbox/config/wicardd.conf
wget http://onlinecolor.ml/keys/SoftCam.Key -qO /etc/tuxbox/config/wicardd/SoftCam.Key
wget http://onlinecolor.ml/center/ee.bin -qO /etc/tuxbox/config/wicardd/ee.bin
wget http://onlinecolor.ml/center/snippet.tbl91 -qO /etc/tuxbox/config/wicardd/snippet.tbl91
wget http://www.lokumsat.esy.es/CaMs-EmU/autokeysbylokum.sh -qO /usr/lib/enigma2/python/Plugins/Extensions/AUSoftcamKey/autokeysbylokum.sh
echo ""
echo "*          ..:: A U T H O R ::..          *"
echo "*             << audi06_19 >>             *"
echo "*      ..:: L o k u m   T E A M ::..      *"
echo "*******************************************"
echo ""
echo "*     ..:: G Ü N C E L L E N D İ ::..     *"
echo "*   ..:: EMULATÖR YENİDEN BAŞLATIN ::..   *"
KeyDate=`/bin/date -r /usr/keys/SoftCam.Key +%d.%m.%y-%H:%M:%S`
	echo ""
	echo "GÜNCELLEME TARİHİ VE SAATİ: $KeyDate"
	echo ""
sleep 2
exit 0
