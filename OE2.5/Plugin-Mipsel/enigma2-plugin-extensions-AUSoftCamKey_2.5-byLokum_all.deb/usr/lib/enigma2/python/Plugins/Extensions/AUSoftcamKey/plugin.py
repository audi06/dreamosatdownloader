# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/AUSoftcamKey/plugin.py
#### "*******************************************"
#### "*          ..:: A U T H O R ::..          *"
#### "*             << audi06_19 >>             *"
#### "*      ..:: L o k u m   T E A M ::..      *"
#### "*******************************************"
from Plugins.Plugin import PluginDescriptor
from Screens.Console import Console
from Screens.MessageBox import MessageBox

def menu(menuid, **kwargs):
    if menuid == 'mainmenu':
        return [('AUSoftcamKey',
          main,
          'AUSoftcamKey',
          1)]
    return []
def runbackup(session, result):
    if result:
        session.open(Console, title='AUSoftcamKey', cmdlist=["sh '/usr/lib/enigma2/python/Plugins/Extensions/AUSoftcamKey/autokeysbylokum.sh'"])

def main(session, **kwargs):
    session.openWithCallback(lambda r: runbackup(session, r), MessageBox, 'AUSoftcamKey \n Author << audi06_19 >> ( Lokum TEAM )\nconstant.cw ve SoftCam.Key guncellemek istiyor musunuz?', MessageBox.TYPE_YESNO, timeout=20, default=True)

def Plugins(**kwargs):
    return [PluginDescriptor(name='AUSoftcamKey', description='AUSoftcamKey for constant and softcam online', where=PluginDescriptor.WHERE_PLUGINMENU, fnc=main, icon='plugin.png')]
