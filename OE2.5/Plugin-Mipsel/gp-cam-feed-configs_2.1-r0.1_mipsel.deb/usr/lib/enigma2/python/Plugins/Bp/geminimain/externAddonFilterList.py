# -*- coding: utf-8 -*-
from gLocale import _
FilterList = [
	(_("Gemini Plugins"), _("Gemini Project Plugins"), "gemini"),
	(_("Gemini CamConf"), _("Gemini Cam Config Packages"), "gp-conf"),
	(_("Gemini SoftCamd"), _("Gemini SoftCamd Packages"), "gp-cam"),
	(_("Gemini Skins"), _("Gemini Project Skins"), "gp-skin"),
	(_("Plugins (Extensions)"), _("Plugin section"), "enigma2-plugin-extensions"),
	(_("Plugins (System)"), _("System plugin section"), "enigma2-plugin-systemplugins"),
	(_("Icons and Frame"), _("Icons and frame for Blue-Panel"), "gp-icons"),
	(_("Picons HD"), _("Channellogo for the Infobar") + " (High Definition)", "gp-picon-hd"),
	(_("Picons XPicon"), _("Channellogo for the Infobar"), "gp-picon-xpicon"), 
	(_("Picons Mini"), _("Channellogo for the Channellist"), "gp-picon-mini"),
	(_("Picons Display"), _("Channellogo for embedded or external display"), "gp-picon-display"),
	(_("Configurations"), _("Sat, Cable and Terrestrial configurations"), "gp-setting"),
	(_("Kernel-Module"), _("Kernel Module (Driver)"), "kernel-module"),
	(_("all"), _("All available packages"), "all")
	]
