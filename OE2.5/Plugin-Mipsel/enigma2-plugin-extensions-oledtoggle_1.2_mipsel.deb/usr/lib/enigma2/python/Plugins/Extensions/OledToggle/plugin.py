from Plugins.Plugin import PluginDescriptor
#import os
from os import system
                                        
def main(session, **kwargs):
        system("OLED=/proc/stb/lcd/oled_brightness;DIMM=$(cat /etc/enigma2/oled.dimm|grep -v '#'|grep config.oled.dimm|awk -F '=' '{print$2}');SET=/tmp/oled.e2;[ $(cat $OLED) != $DIMM ] && echo $(cat $OLED)>$SET && echo $DIMM>$OLED || cat $SET > $OLED")
        	
def Plugins(**kwargs):
	return [PluginDescriptor(name="OLED Powertoggle", description=_("turns on/off OLED Display"), where = PluginDescriptor.WHERE_PLUGINMENU, icon='plugin.png', fnc=main),
	PluginDescriptor(name="OLED Powertoggle", description=_("turns on/off OLED Display"), where = PluginDescriptor.WHERE_EXTENSIONSMENU, icon='plugin.png', fnc=main)]
