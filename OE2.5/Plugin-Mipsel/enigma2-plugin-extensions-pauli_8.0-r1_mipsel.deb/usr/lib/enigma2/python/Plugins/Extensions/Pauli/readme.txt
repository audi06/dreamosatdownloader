=============================================================
Pauli Neutrino Keymap V8.0 forEnigma2 by romeo-golf 
powered by gutemine and AliAbdul from 29.11.2011
=============================================================
Thanks to theflashor23 for the Neutrino keymap idea and basic
input and Thanks to AliAbdul for the keymap switching code
=============================================================
Pauli is FREEWARE, but this means also that nobody takes 
responsibility if anything goes wrong ;-)
=============================================================
Version History
=============================================================
Version 8.0  - adapt for dm7080
=============================================================
Der Englische Text ist unterhalb des Deutschen Text !
The English text is below the German text !
=============================================================
HOW-TO
=============================================================

Hallo Freunde der Neutrino-FB Tastenbelegung. Mit dem Pauli 
Neutrino Keymap Plugin fuer Enigma2 kannst du bequem 
zwischen Enigma2 und Neutrino Tastenbelegung wechseln. 
Du kannst aber auch andere Kleinigkeiten
damit veraendern wie die Funktion des Powerschalters.

Wieso Pauli? Pauli war ein Physiker aus Oesterreich und
gilt als der Entdecker des Neutrinos.  

Neutrino Keymap (Tastenbelegung der Fernbedienung):
-------------------------------------------------------------
diverse Moeglichkeiten die Fernbedienung seinen Gewohnheiten
anzupassen. Aussr den zwei fertigen Belegungen "Enigma2" und 
"Neutrino" sind noch einzelnen Anpassungen verfuegbar die aus 
dem Menue leicht abzulesen sind.

Aendern der Systemtime:
-------------------------------------------------------------
erlaubt die Eingabe des Datums und der Uhrzeit
=============================================================
Und nun viel Spass mit der Pauli Plugin !
============================================================

=============================================================
Here comes the English Version of the Documentation ...
=============================================================
HOW-TO
=============================================================

Hello, hard-core fans of the Neutrino style remote control 
keys layout. With the Pauli Neutrino Keymap Plugin for
Enigma2 you can easily toggle in an Enigma2 image 
between the Enigma2 and the Neutrino style keys. 
You can also change lots of other small things like toggle 
the Standby with DeepStandby Funktion.
 
Why Pauli ? Wolfgang Pauli was an Austrian physicist who 
discovered the Neutrino particle. 

Neutrino Keymap for the Remote control:
-------------------------------------------------------------
various possibilities to adapt the remote control to your 
needs. Besides the 2 predfined key layouts "Enigma2" and 
"Neutrino" are other minor changes possible which you can find
in the menu screen.

Changing of System Time:
-------------------------------------------------------------
allows you to manually change the date and the time of the box

=============================================================
And now have fun using the Pauli Plugin !
=============================================================

