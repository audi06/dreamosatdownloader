# BY LokumTEAM << audi06_19 >>
#!/bin/sh
echo "*     ..:: B E K L E Y İ N İ Z ::..       *"
[ -d /etc/tuxbox/config/oscampowervu ] || mkdir -p /etc/tuxbox/config/oscampowervu
[ -d /usr/keys ] || mkdir -p /usr/keys
[ -d /tmp/LokumTEAM ] || mkdir -p /tmp/LokumTEAM
#keys
wget http://www.lokumsat.esy.es/CaMs-EmU/readme.txt -qO /tmp/LokumTEAM/readme.txt
wget http://www.lokumsat.esy.es/CaMs-EmU/SoftCam.Key -qO /tmp/LokumTEAM/SoftCam.Key
wget http://www.lokumsat.esy.es/CaMs-EmU/constant.cw -qO /tmp/LokumTEAM/constant.cw
wget http://www.lokumsat.esy.es/CaMs-EmU/CCcam/AutoRoll.Key -qO /tmp/LokumTEAM/AutoRoll.Key
#script
wget http://www.lokumsat.esy.es/CaMs-EmU/autokeysbylokum.sh -qO /tmp/LokumTEAM/autokeysbylokum.sh
#
chmod 0755 /tmp/LokumTEAM/ -R
#
cd /tmp/LokumTEAM
#
cp -rd autokeysbylokum.sh /usr/lib/enigma2/python/Plugins/Extensions/AUSoftcamKey/
cp -rd AutoRoll.Key /usr/keys/
cp -rd SoftCam.Key /etc/tuxbox/config/
cp -rd SoftCam.Key /usr/keys/
cp -rd constant.cw /etc/tuxbox/config/
cp -rd constant.cw /usr/keys/
#
cd
#
more /tmp/LokumTEAM/readme.txt
#
rm /tmp/LokumTEAM/readme.txt
rm -rf /tmp/LokumTEAM
sleep 2
exit 0
