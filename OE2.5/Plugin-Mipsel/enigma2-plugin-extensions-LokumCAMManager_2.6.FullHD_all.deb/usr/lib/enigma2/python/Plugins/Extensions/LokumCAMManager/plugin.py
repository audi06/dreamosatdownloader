# Embedded file name: /usr/lib/enigma2/python/Plugins/Extensions/LokumCAMManager/plugin.py
#### "*******************************************"
#### "*          ..:: A U T H O R ::..          *"
#### "*             << audi06_19 >>             *"
#### "*      ..:: L o k u m   T E A M ::..      *"
#### "*******************************************"
from Screens.ChoiceBox import ChoiceBox
from Screens.Screen import Screen
from Components.ActionMap import ActionMap, NumberActionMap
from Components.MenuList import MenuList
from Components.Sources.List import List
from Components.FileList import FileList
from Screens.Console import Console
from Screens.MessageBox import MessageBox
from Plugins.Plugin import PluginDescriptor
from Components.Pixmap import Pixmap
from Tools import Notifications
from ServiceReference import ServiceReference
from Components.Button import Button
from Components.Label import Label
from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import SCOPE_SKIN_IMAGE, resolveFilename
import os
import urllib

class Emumanager(Screen):
    skin = '\n        \t<screen name="Menusimple" position="center,center" size="780,650" title="" >\n\n                <widget name="list" position="75,50" size="605,160" scrollbarMode="showOnDemand" />\n\t\t<!--eLabel position="70,100" zPosition="-1" size="160,69" backgroundColor="#222222" /-->\n                <widget name="info" position="160,250" zPosition="4" size="400,250" font="Regular;18" foregroundColor="#ffffff" transparent="1" halign="left" valign="center" />\n\t        <ePixmap name="red"    position="10,600"   zPosition="2" size="140,40" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />\n\t        <ePixmap name="green"  position="150,600" zPosition="2" size="140,40" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />\n\t<widget name="key_red" position="10,600" size="140,40" valign="center" halign="center" zPosition="4"  foregroundColor="white" font="Regular;20" transparent="1" shadowColor="#25062748" shadowOffset="-2,-2" /> \n        \t<widget name="key_green" position="150,600" size="140,40" valign="center" halign="center" zPosition="4"  foregroundColor="white" font="Regular;20" transparent="1" shadowColor="#25062748" shadowOffset="-2,-2" /> \n                </screen>'

    def __init__(self, session, args = 0):
        self.session = session
        Screen.__init__(self, session)
        self.skinName = 'Emumanager'
        self.index = 0
        self.sclist = []
        self.namelist = []
        self.oldService = self.session.nav.getCurrentlyPlayingServiceReference()
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions'], {'ok': self.action,
         'cancel': self.close,
         'green': self.action,
         'red': self.stop}, -1)
        self['key_green'] = Button(_('Start/Restart'))
        self['key_red'] = Button(_('Stop'))
        self.lastCam = self.readCurrent()
        self.softcamlist = []
        self['info'] = Label()
        self['list'] = MenuList(self.softcamlist)
        self.readScripts()
        title = 'LokumCAM Manager v.2.6'
        self.setTitle(title)
        self['pixmap'] = Pixmap()
        self.ecm()
        self.onShown.append(self.openTest)

    def openTest(self):
        pass

    def emuInst(self):
        self.session.open(Getipklist, 'Emu')

    def remove(self):
        self.session.open(Ipkremove)
        self.close()

    def getLastIndex(self):
        a = 0
        if len(self.namelist) > 0:
            for x in self.namelist:
                if x == self.lastCam:
                    return a
                a += 1

        else:
            return -1
        return -1

    def action(self):
        self.session.nav.playService(None)
        last = self.getLastIndex()
        var = self['list'].getSelectionIndex()
        if last > -1:
            if last == var:
                self.cmd1 = '/usr/camscript/' + self.sclist[var] + ' cam_res &'
                os.system(self.cmd1)
                print 'self.cmd1 A=', self.cmd1
                os.system('sleep 4')
            else:
                self.cmd1 = '/usr/camscript/' + self.sclist[last] + ' cam_down &'
                print 'self.cmd1 B=', self.cmd1
                os.system(self.cmd1)
                os.system('sleep 4')
                self.cmd1 = '/usr/camscript/' + self.sclist[var] + ' cam_up &'
                print 'self.cmd1 C=', self.cmd1
                os.system(self.cmd1)
        else:
            try:
                self.cmd1 = '/usr/camscript/' + self.sclist[var] + ' cam_up &'
                print 'self.cmd1 D=', self.cmd1
                os.system(self.cmd1)
                os.system('sleep 4')
            except:
                self.close()

        if last != var:
            try:
                self.lastCam = self.softcamlist[var]
                self.writeFile()
            except:
                self.close()

        self.readScripts()
        self.session.nav.playService(self.oldService)
        self.close()
        return

    def writeFile(self):
        if self.lastCam is not None:
            clist = open('/etc/clist.list', 'w')
            clist.write(self.lastCam)
            clist.close()
        stcam = open('/etc/startcam.sh', 'w')
        stcam.write('#!/bin/sh\n' + self.cmd1)
        stcam.close()
        self.cmd2 = 'chmod 755 /etc/startcam.sh &'
        os.system(self.cmd2)
        return

    def stop(self):
        self.session.nav.playService(None)
        last = self.getLastIndex()
        if last > -1:
            self.cmd1 = '/usr/camscript/' + self.sclist[last] + ' cam_down &'
            print 'self.cmd1 E=', self.cmd1
            os.system(self.cmd1)
        else:
            return
        self.lastCam = 'no'
        self.writeFile()
        os.system('sleep 4')
        self.readScripts()
        self['info'].setText(' ')
        self.session.nav.playService(self.oldService)
        return

    def readScripts(self):
        self.index = 0
        scriptliste = []
        pliste = []
        path = '/usr/camscript/'
        for root, dirs, files in os.walk(path):
            for name in files:
                scriptliste.append(name)

        self.sclist = scriptliste
        i = len(self.softcamlist)
        del self.softcamlist[0:i]
        for lines in scriptliste:
            dat = path + lines
            sfile = open(dat, 'r')
            for line in sfile:
                if line[0:3] == 'OSD':
                    nam = line[5:len(line) - 2]
                    print 'We are in Emumanager readScripts 2 nam = ', nam
                    if self.lastCam is not None:
                        if nam == self.lastCam:
                            self.softcamlist.append(nam + '\tActive')
                        else:
                            self.softcamlist.append(nam)
                        self.index += 1
                    else:
                        self.softcamlist.append(nam)
                        self.index += 1
                    pliste.append(nam)

            sfile.close()
            self['list'].setList(self.softcamlist)
            self.namelist = pliste

        return

    def readCurrent(self):
        try:
            clist = open('/etc/clist.list', 'r')
        except:
            return

        if clist is not None:
            for line in clist:
                lastcam = line

            clist.close()
        return lastcam

    def ecm(self):
        ecmf = ''
        if os.path.isfile('/tmp/ecm.info') is True:
            myfile = file('/tmp/ecm.info')
            ecmf = ''
            for line in myfile.readlines():
                print line
                ecmf = ecmf + line

            self['info'].setText(ecmf)
        else:
            self['info'].setText(ecmf)
            return

    def autocam(self):
        current = None
        try:
            clist = open('/etc/clist.list', 'r')
            print 'found list'
        except:
            return

        if clist is not None:
            for line in clist:
                current = line

            clist.close()
        print 'current =', current
        if os.path.isfile('/etc/autocam.txt') is False:
            alist = open('/etc/autocam.txt', 'w')
            alist.close()
        self.cleanauto()
        alist = open('/etc/autocam.txt', 'a')
        alist.write(self.oldService.toString() + '\n')
        last = self.getLastIndex()
        alist.write(current + '\n')
        alist.close()
        self.session.openWithCallback(self.callback, MessageBox, _('Autocam assigned to the current channel'), type=1, timeout=10)
        return

    def cleanauto(self):
        delemu = 'no'
        if os.path.isfile('/etc/autocam.txt') is False:
            return
        myfile = open('/etc/autocam.txt', 'r')
        myfile2 = open('/etc/autocam2.txt', 'w')
        icount = 0
        for line in myfile.readlines():
            print 'We are in Emumanager line, self.oldService.toString() =', line, self.oldService.toString()
            if line[:-1] == self.oldService.toString():
                delemu = 'yes'
                icount = icount + 1
                continue
            if delemu == 'yes':
                delemu = 'no'
                icount = icount + 1
                continue
            myfile2.write(line)
            icount = icount + 1

        myfile.close()
        myfile2.close()
        os.system('rm /etc/autocam.txt')
        os.system('cp /etc/autocam2.txt /etc/autocam.txt')


def startConfig(session, **kwargs):
    session.open(Emumanager)


def mainmenu(menuid):
    if menuid != 'setup':
        return []
    else:
        return [(_('LokumCAM Manager'),
          startConfig,
          'softcam',
          None)]
        return None


def autostart(reason, session = None, **kwargs):
    """called with reason=1 to during shutdown, with reason=0 at startup?"""
    print '[Softcam] Started'
    if reason == 0:
        try:
            os.system('mv /usr/bin/dccamd /usr/bin/dccamdOrig &')
            os.system('ln -sf /usr/bin /var/bin')
            os.system('ln -sf /usr/keys /var/keys')
            os.system('ln -sf /usr/scce /var/scce')
            os.system('ln -sf /usr/script/cam /var/script/cam')
            os.system('sleep 2')
            os.system('/etc/startcam.sh &')
        except:
            pass


def Plugins(**kwargs):
    return [PluginDescriptor(name=' LokumCAM Manager', description=' Emu Softcam Manager', icon='plugin.png', where=PluginDescriptor.WHERE_PLUGINMENU, fnc=startConfig), PluginDescriptor(name=' LokumCAM Manager', description=' Emu Softcam Manager', icon='plugin.png', where=[PluginDescriptor.WHERE_AUTOSTART], fnc=autostart)]
