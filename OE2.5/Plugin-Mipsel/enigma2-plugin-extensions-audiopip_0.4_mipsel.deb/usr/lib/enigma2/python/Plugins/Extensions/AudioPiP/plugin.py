# -*- coding: iso-8859-1 -*-
#
# AudioPip by gutemine
#
audiopip_version="0.4"
#
from enigma import eTimer
from Screens.InfoBar import *
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.InfoBarGenerics  import InfoBarPiP
from Screens.PictureInPicture import PictureInPicture
from Components.SystemInfo import SystemInfo
from Components.config import config, ConfigPosition
from Screens.ChannelSelection import ChannelSelection

def autostart(reason, **kwargs):
   if SystemInfo.get("NumVideoDecoders", 1) > 1:
      print "[SPLITSCEEN] resetting"
      l=open("/proc/stb/vmpeg/0/dst_left","w")
      l.write("%x" % 0)
      l.close()
      t=open("/proc/stb/vmpeg/0/dst_top","w")
      t.write("%x" % 0)
      t.close()
      h=open("/proc/stb/vmpeg/0/dst_height","w")
      h.write("%x" % 576)
      h.close()
      w=open("/proc/stb/vmpeg/0/dst_width","w")
      w.write("%x" % 720)
      w.close()
      try:
         xxx = config.av.pip.value[0]
         yyy = config.av.pip.value[1]
         www = config.av.pip.value[2]
         hhh = config.av.pip.value[3] 
      except:
         # default location
         xxx = 400
         yyy = 60
         www = 240
         hhh = 192
      l=open("/proc/stb/vmpeg/1/dst_left","w")
      l.write("%x" % xxx)
      l.close()
      t=open("/proc/stb/vmpeg/1/dst_top","w")
      t.write("%x" % yyy) 
      t.close()
      h=open("/proc/stb/vmpeg/1/dst_height","w")
      h.write("%x" % hhh)
      h.close()
      w=open("/proc/stb/vmpeg/1/dst_width","w")
      w.write("%x" % www)
      w.close()

def Plugins(**kwargs):
    return [PluginDescriptor(where = [PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART], fnc = autostart),
            PluginDescriptor(name=_("Audio Pip enable"), description=_("enable PIP fullscreen for alternate audio"), where = PluginDescriptor.WHERE_EXTENSIONSMENU, icon="audiopip.png", fnc=main)]

def main(session, **kwargs):
    session.open(AudioPip)

class AudioPip(Screen):
    def __init__(self, session, args = 0):
        Screen.__init__(self, session)
        if SystemInfo.get("NumVideoDecoders", 1) > 1:
           try:
              self.session.pipshown
           except:
              self.session.pipshown = False
           if self.session.pipshown:
              print "[AUDIOPIP] pip already shown"
              w=open("/proc/stb/vmpeg/0/dst_width","r")
              ww=w.readline().rstrip()
              w.close()
              if not ww.endswith("%x" % 720):
                 print "[AUDIOPIP] PiP is stopped"
                 self.showPiP()
                 print "[AUDIOPIP] unzooming PIP"
                 l=open("/proc/stb/vmpeg/0/dst_left","w")
                 l.write("%x" % 0)
                 l.close()
                 t=open("/proc/stb/vmpeg/0/dst_top","w")
                 t.write("%x" % 0)
                 t.close()
                 h=open("/proc/stb/vmpeg/0/dst_height","w")
                 h.write("%x" % 576)
                 h.close()
                 w=open("/proc/stb/vmpeg/0/dst_width","w")
                 w.write("%x" % 720)
                 w.close()
                 try:
                    xxx = config.av.pip.value[0]
                    yyy = config.av.pip.value[1]
                    www = config.av.pip.value[2]
                    hhh = config.av.pip.value[3] 
                 except:
                    # default location
                    xxx = 400
                    yyy = 60
                    www = 240
                    hhh = 192
                 l=open("/proc/stb/vmpeg/1/dst_left","w")
                 l.write("%x" % xxx)
                 l.close()
                 t=open("/proc/stb/vmpeg/1/dst_top","w")
                 t.write("%x" % yyy) 
                 t.close()
                 h=open("/proc/stb/vmpeg/1/dst_height","w")
                 h.write("%x" % hhh)
                 h.close()
                 w=open("/proc/stb/vmpeg/1/dst_width","w")
                 w.write("%x" % www)
                 w.close()
              else:
                 print "[AUDIOPIP] zoom PIP"
                 l=open("/proc/stb/vmpeg/0/dst_left","w")
                 l.write("%x" % 0)
                 l.close()
                 t=open("/proc/stb/vmpeg/0/dst_top","w")
                 t.write("%x" % 0)
                 t.close()
                 h=open("/proc/stb/vmpeg/0/dst_height","w")
                 h.write("%x" % 0)
                 h.close()
                 w=open("/proc/stb/vmpeg/0/dst_width","w")
                 w.write("%x" % 0)
                 w.close()
                 l=open("/proc/stb/vmpeg/1/dst_left","w")
                 l.write("%x" % 0)
                 l.close()
                 t=open("/proc/stb/vmpeg/1/dst_top","w")
                 t.write("%x" % 0)
                 t.close()
                 h=open("/proc/stb/vmpeg/1/dst_height","w")
                 h.write("%x" % 576)
                 h.close()
                 w=open("/proc/stb/vmpeg/1/dst_width","w")
                 w.write("%x" % 720)
                 w.close()
           else:
                 print "[AUDIOPIP] PiP is started"
                 self.showPiP()
                 print "[AUDIOPIP] popup PIP"
                 l=open("/proc/stb/vmpeg/0/dst_left","w")
                 l.write("%x" % 0)
                 l.close()
                 t=open("/proc/stb/vmpeg/0/dst_top","w")
                 t.write("%x" % 0)
                 t.close()
                 h=open("/proc/stb/vmpeg/0/dst_height","w")
                 h.write("%x" % 0)
                 h.close()
                 w=open("/proc/stb/vmpeg/0/dst_width","w")
                 w.write("%x" % 0)
                 w.close()
                 l=open("/proc/stb/vmpeg/1/dst_left","w")
                 l.write("%x" % 0)
                 l.close()
                 t=open("/proc/stb/vmpeg/1/dst_top","w")
                 t.write("%x" % 0)
                 t.close()
                 h=open("/proc/stb/vmpeg/1/dst_height","w")
                 h.write("%x" % 576)
                 h.close()
                 w=open("/proc/stb/vmpeg/1/dst_width","w")
                 w.write("%x" % 720)
                 w.close()
        else:
            print "[AUDIOPIP] too less video decoders"
        self.close()

    def showPiP(self):
            self.servicelist = self.session.instantiateDialog(ChannelSelection)
            if self.session.pipshown:
                     del self.session.pip
                     self.session.pipshown = False
            else:
                     self.session.pip = self.session.instantiateDialog(PictureInPicture)
                     self.session.pip.show()
                     newservice = self.session.nav.getCurrentlyPlayingServiceReference()
                     if self.session.pip.playService(newservice):
                             self.session.pipshown = True
                             self.session.pip.servicePath = self.servicelist.getCurrentServicePath()
                     else:
                             self.session.pipshown = False
                             del self.session.pip
                     self.session.nav.playService(newservice)
