# -*- coding: utf-8 -*-
#
# Dumbo Plugin (c) gutemine
#
dumbo_version="7.3"
#
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.config import config, ConfigSubsection, ConfigText, ConfigInteger, ConfigBoolean, ConfigSelection, getConfigListEntry
from Plugins.Plugin import PluginDescriptor
from Components.Pixmap import Pixmap
from Components.ConfigList import ConfigListScreen
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox 
from Screens.InputBox import InputBox
from Components.Input import Input
from Screens.ChoiceBox import ChoiceBox
from Components.AVSwitch import AVSwitch
from Components.SystemInfo import SystemInfo
from Screens.Console import Console
from enigma import eConsoleAppContainer, eDVBVolumecontrol, eTimer, quitMainloop
from Tools.LoadPixmap import LoadPixmap
from Plugins.Extensions.dBackup.plugin import *
from enigma import *
import sys, os, struct, stat, time                                               
from fcntl import ioctl                                                          
from struct import unpack                                                        
from array import array       

from twisted.web import resource, http
import gettext, datetime, time
if os.path.exists("/usr/lib/enigma2/python/Plugins/Bp/geminimain/lib/libgeminimain.so"):
	from Plugins.Bp.geminimain.lib import libgeminimain

dumbo_plugindir="/usr/lib/enigma2/python/Plugins/Extensions/Dumbo" 
dbackup_plugindir="/usr/lib/enigma2/python/Plugins/Extensions/dBackup" 
dumbo_pluginlink="/tmp/Dumbo" 
dumbo_webif="/usr/lib/enigma2/python/Plugins/Extensions/WebInterface/WebChilds/External"
dumbo_bin="%s/bin" % dumbo_pluginlink
dumbo_busy="/tmp/.dumbo"                                                      
dumbo_log="dumbo.log"                                                   
dumbo_script="/tmp/dumbo.sh"      
dumbo_maxflash=2000
dumbo_min_imagesize=950

if not os.path.exists(dumbo_pluginlink):
	os.symlink(dumbo_plugindir,dumbo_pluginlink)

dumbo_sp=[]
dumbo_sp=config.osd.language.value.split("_")
dumbo_language = dumbo_sp[0]
if os.path.exists("%s/locale/%s" % (dumbo_plugindir,dumbo_language)):
	_=gettext.Catalog('dumbo', '%s/locale' % dumbo_plugindir,dumbo_sp).gettext

yes_no_descriptions = {False: _("no"), True: _("yes")}

config.plugins.dumbo = ConfigSubsection()
config.plugins.dumbo.restpartition = ConfigBoolean(default = False, descriptions=yes_no_descriptions)
config.plugins.dumbo.restformat = ConfigBoolean(default = True, descriptions=yes_no_descriptions)
config.plugins.dumbo.restlabel = ConfigText(default = "usb", fixed_size=False, visible_width=10)
config.plugins.dumbo.sort = ConfigBoolean(default = True, descriptions=yes_no_descriptions)
config.plugins.dumbo.initrd = ConfigBoolean(default = False, descriptions=yes_no_descriptions)
config.plugins.dumbo.keep = ConfigBoolean(default = False, descriptions=yes_no_descriptions)
config.plugins.dumbo.synchronous = ConfigBoolean(default = False, descriptions=yes_no_descriptions)
config.plugins.dumbo.labelmount = ConfigBoolean(default = False, descriptions=yes_no_descriptions)
config.plugins.dumbo.extension = ConfigBoolean(default = True, descriptions=yes_no_descriptions)
# ignore harddisks = and allow Bootdevices up to 4 (32) GB and not too small either
config.plugins.dumbo.maxdevsize = ConfigInteger(default = 34000, limits = (5000, 999999))
config.plugins.dumbo.passwd = ConfigBoolean(default = False, descriptions=yes_no_descriptions)
config.plugins.dumbo.imagesize = ConfigInteger(default = 0, limits = (0,8192))

config.plugins.dumbo.rootdelay = ConfigInteger(default = 5, limits = (5,10))

use_dbackup_string=_("for Backup of Image use dBackup Plugin from gutemine")
bootedfrom_string=_("booted from")
task_string=_("Choose task")
notask_string=_("No task choosen")
device_string=_("Select device for image")
fileupload_string=_("Select image for booting")
plugin_string=_("Dumbo the Dumb Boot Plugin") 
booting_string=_("Booting") 
bootflash_string= _("boot Flash image")
backup_string=_("Backup") 
extractfailed_string=_("Extract failed") 
extract_string=_("Extract") 
execute_string=_("Execute") 
finished_string=_("%s finished\n") 
finished2_string=_("Press OK to prepare booting from %s") 
running_string=_("Dumbo is busy ...")
backupdirectory_string=_("Enter Backup path")
nodev_string=_("Sorry, no correct device selected ")
nosd_string=_("no device found, shutdown, add SD card and reboot")
nousb_string=_("no device found, shutdown, add USB stick and reboot")
nodevice_string=_("no suitable device found, shutdown, add device to USB and reboot")
nonfi_string=_("Sorry, no correct image file selected")
refresh_string=_("Refresh")
reboot_string=_("Press OK to reboot now")
wait_string=_("Press OK to check Filesystems on %s now")
smalldev_string=_("Sorry, choosen device is too small")
erase_string=_("Erase of Dumbo device done")
bootexisting_string=_("boot existing image")
refill_string=_("re-fill with image")
fill_string=_("fill with image")
delete_string=_("Delete")
flashcopy_string=_("Flash copy")
mounted_string=_("Nothing mounted at %s")
nomount_string=_("%s is still mounted, check not possible")
fsck_string=_("Filesystemcheck")
kernelfix_string=_("Fix Kernel")
checkdone_string=fsck_string+" "+_("done")

header_string  =""
header_string +="<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\""
header_string +="\"http://www.w3.org/TR/html4/loose.dtd\">"
header_string +="<head><title>Dumbo %s V%s</title>" % (plugin_string,dumbo_version)
header_string +="<link rel=\"shortcut icon\" type=\"/web-data/image/x-icon\" href=\"/web-data/img/favicon.ico\">"
header_string +="<meta content=\"text/html; charset=UTF-8\" http-equiv=\"content-type\">"
header_string +="</head><body bgcolor=\"blue\">"
header_string +="<font face=\"Tahoma, Arial, Helvetica\" color=\"white\">"
header_string +="<font size=\"3\" color=\"white\">"

dumbo_backbutton=_("use back button in browser and try again!") 
dumbo_booting=""
dumbo_booting += header_string
dumbo_booting += "<br>%s ...<br><br>" % booting_string
dumbo_booting +="<br><img src=\"/web-data/img/dumbo.png\" alt=\"%s ...\"/><br><br>" % (booting_string)

dumbo_backuping  =""
dumbo_backuping += header_string
dumbo_backuping += "<br>%s<br><br>" % running_string
dumbo_backuping +="<br><img src=\"/web-data/img/sleep.png\" alt=\"%s ...\"/><br><br>" % (backup_string)
dumbo_backuping +="<form method=\"GET\">"
dumbo_backuping +="<input name=\"command\" type=\"submit\" size=\"100px\" value=\"%s\">" % refresh_string
dumbo_backuping +="</form>"                        

dumbo_return  =""
dumbo_return += header_string
dumbo_return +="<form method=\"GET\">"
dumbo_return +="<input name=\"command\" type=\"submit\" size=\"100px\" value=\"%s\">" % refresh_string
dumbo_return +="</form>"                        

class Dumbo(Screen):
	skin = """
		<screen position="center,80" size="680,60" title="Dumb Booting" >
		<widget name="logo" position="10,10" size="100,40" transparent="1" alphatest="on" />
		<widget name="buttonred" position="120,10" size="130,40" backgroundColor="red" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;18"/>
		<widget name="buttongreen" position="260,10" size="130,40" backgroundColor="green" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;18"/>
		<widget name="buttonyellow" position="400,10" size="130,40" backgroundColor="yellow" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;18"/>
		<widget name="buttonblue" position="540,10" size="130,40" backgroundColor="blue" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;18"/>
	</screen>"""
	def __init__(self, session, args = 0):
		Screen.__init__(self, session)
		self.onShown.append(self.setWindowTitle)      
                self.onLayoutFinish.append(self.byLayoutEnd)
		self["logo"] = Pixmap()
		self["buttonred"] = Label(_("Cancel"))
		self["buttongreen"] = Label(_("Backup"))
		self["buttonyellow"] = Label(_("Booting"))
		self["buttonblue"] = Label(_("Setup"))
		self["setupActions"] = ActionMap([ "ColorActions", "SetupActions" ],
			{
			"green": self.backup,
			"red": self.leaving,
			"blue": self.config,
			"yellow": self.boot,
			"save": self.leaving,
			"cancel": self.leaving,
			})

	def setWindowTitle(self):
		if os.path.exists(dumbo_busy):   
                	self["logo"].instance.setPixmapFromFile("%s/sleep.png" % dumbo_plugindir)
		else:
                	self["logo"].instance.setPixmapFromFile("%s/dumbo.png" % dumbo_plugindir)
		k=open("/proc/cmdline","r")
		cmd=k.read()
		k.close()
		if cmd.find("root=/dev/mmcblk0") is -1: 
               		bootdevice="none"
			sp=[]
			sp=cmd.split(" ")
			print sp
			bootdevice=sp[4].replace("root=","")
		else:
			bootdevice="Flash"
               	print "[Dumbo] bootdevice %s" % bootdevice
		title_string="Dumbo "+bootedfrom_string+" "+bootdevice
		self.setTitle(title_string)

        def byLayoutEnd(self):
                self["logo"].instance.setPixmapFromFile("%s/dumbo.png" % dumbo_plugindir)

	def leaving(self):
		if os.path.exists(dumbo_busy):   
			self.session.open(MessageBox, running_string, MessageBox.TYPE_ERROR)
		else:
			self.close()

	def config(self):
		global freefilesystem
		global freememory
                freefilesystem=""
                freememory=""
		if os.path.exists(dumbo_busy):   
			self.session.open(MessageBox, running_string, MessageBox.TYPE_ERROR)
		else:
        		st = os.statvfs("/")                                                                           
		        free = st.f_bavail * st.f_frsize/1024/1024                                                               
		        total = st.f_blocks * st.f_frsize/1024/1024                                                
		        used = (st.f_blocks - st.f_bfree) * st.f_frsize/1024/1024 
			freefilesystem=_("Root Filesystem\n\ntotal: %s MB\nused:  %s MB\nfree:  %s MB") % (total,used,free)		
		      	memfree=0
		      	memtotal=0
		      	memused=0
			fm=open("/proc/meminfo")
		      	line = fm.readline()
		      	sp=line.split()
		      	memtotal=int(sp[1])/1024
		      	line = fm.readline()
		      	sp=line.split()
		      	memfree=int(sp[1])/1024
			fm.close()
			memused=memtotal-memfree
			freememory=_("Memory\n\ntotal: %i MB\nused: %i MB\nfree: %i MB") % (memtotal,memused,memfree)		
	        	self.session.open(DumboConfiguration)

	def boot(self):
		if os.path.exists(dumbo_busy):   
			self.session.open(MessageBox, running_string, MessageBox.TYPE_ERROR)
		else:
			k=open("/proc/cmdline","r")
			cmd=k.read()
			k.close()
			if cmd.find("root=/dev/mmcblk0") is -1: 
				sp=[]
				sp=cmd.split(" ")
				print sp
				bootdevice=sp[4].replace("root=","")
                		self.device=bootdevice.rstrip("1").rstrip("p")
				self.session.openWithCallback(self.askForDumboTask,ChoiceBox,task_string,self.getDumboTaskList())
			else:
				if os.path.exists("/dev/disk/by-label/DUMBO"):
       					self.session.openWithCallback(self.askForDevice,ChoiceBox,device_string,self.getDeviceList())
				else:
					found=0
					f=open("/proc/partitions","r")
					sp=[]
					devsizeunit="MB"
		 			line = f.readline()                                                    
		 			line = f.readline()                                                    
		 			line = f.readline()                                                    
					while (line):        
						sp=line.split()
			#			print sp
						devlen=len(sp[3])
						if (sp[3].startswith("sd") and devlen==3) or (sp[3].startswith("mmcblk1") and devlen==7):
							devname="/dev/%s" % sp[3]
							# make MB
							size=int(sp[2])/1024
							print devname, size
							# ignore harddisks = and allow Bootdevices up to 32GB but not smaller then 256MB
							if size < config.plugins.dumbo.maxdevsize.value and size > dumbo_min_imagesize:
								found=found+1
						line = f.readline()                                                 
					f.close()
					if found == 0:
						self.session.open(MessageBox, nodevice_string, MessageBox.TYPE_ERROR)
					else:
	       					self.session.openWithCallback(self.askForDevice,ChoiceBox,device_string,self.getDeviceList())

	def bootFlash(self,option):
        	if option is False:
			self.session.open(MessageBox, _("Sorry, booting of %s was canceled!") % "Flash", MessageBox.TYPE_ERROR)
        	else		:
			self.session.openWithCallback(self.doReboot,MessageBox, reboot_string, MessageBox.TYPE_INFO)

	def doReboot(self,option):
		if self.task == "boot":
			k=open("/proc/cmdline","r")
			cmd=k.read()
			k.close()
			os.system("umount -f /tmp/dumbo")
			if cmd.find("root=/dev/mmcblk0") is not -1: 
				print "[DUMBO] boots B"
                		cmd="select-boot-source B"
			else:
				print "[DUMBO] boots A"
                		cmd="select-boot-source A"
			print cmd
        	        os.system(cmd)
		quitMainloop(2)

	def askForDevice(self,device):
        	if device is None:
			self.session.open(MessageBox, nodev_string, MessageBox.TYPE_ERROR)
        	else:
			self.device=device[1]
			self.devicesize=device[2]
			if not os.path.exists("/tmp/dumbo"):
				os.mkdir("/tmp/dumbo")
			if os.path.exists("%s1" % self.device):
				os.system("mount -t ext4 %s2 /tmp/dumbo" % (self.device))
			self.session.openWithCallback(self.askForFlashTask,ChoiceBox,task_string,self.getFlashTaskList())

	def askForFlashTask(self,task):
        	if task is None:
                        os.system("umount -f /tmp/dumbo")
			self.session.open(MessageBox, notask_string, MessageBox.TYPE_ERROR)
        	else:
			self.task=task[1]
			if self.task == "boot":
				self.session.openWithCallback(self.doReboot,MessageBox, reboot_string, MessageBox.TYPE_INFO)
			else:
				self.bootDumbo()

	def askForDumboTask(self,task):
        	if task is None:
                        os.system("umount -f /tmp/dumbo")
			self.session.open(MessageBox, notask_string, MessageBox.TYPE_ERROR)
        	else:
			self.task=task[1]
			if self.task == "boot":
               			self.session.openWithCallback(self.bootFlash,MessageBox,_("Do you want to boot from Flash ?"), MessageBox.TYPE_YESNO)
			elif self.task == "kernelfix":
				self.nfifile="kernelfix"
      				self.session.openWithCallback(self.doExtract,MessageBox,_("Are you sure that you want to fix the Kernel ?"), MessageBox.TYPE_YESNO)
			else:
				pass

        def getFlashTaskList(self):                                               
		tasklist=[]
		if os.path.exists("/dev/disk/by-label/DUMBO"): 
        		tasklist.append((bootexisting_string,"boot"))
	        	tasklist.append((refill_string,"image"))
		      	tasklist.append((flashcopy_string, "flashcopy" ))                         
	      		tasklist.append((delete_string, "delete" ))                         
	        	tasklist.append((fsck_string,"fsck"))
	        	tasklist.append((kernelfix_string,"kernelfix"))
		else:
	        	tasklist.append((fill_string,"image"))
		      	tasklist.append(( _("Flashcopy"), "flashcopy" ))                         
		return tasklist

        def getDumboTaskList(self):                                               
		tasklist=[]
        	tasklist.append((bootflash_string,"boot"))
	        tasklist.append((kernelfix_string,"kernelfix"))
		return tasklist

	def bootDumbo(self):
		if self.task == "image":
			self.nfifile=""
			os.system("umount -f /tmp/dumbo")
			if int(self.devicesize) < (dumbo_min_imagesize):
				self.session.open(MessageBox, smalldev_string, MessageBox.TYPE_ERROR)
			else:
       				self.session.openWithCallback(self.askForImage,ChoiceBox,fileupload_string,self.getImageList())
		elif self.task == "delete":
			self.nfifile = "delete"
      			self.session.openWithCallback(self.doExtract,MessageBox,_("Are you sure that you want to erase Dumbo device %s ?") % self.device, MessageBox.TYPE_YESNO)
		elif self.task == "flashcopy":
			self.nfifile="flashcopy"
      			self.session.openWithCallback(self.doExtract,MessageBox,_("Are you sure that you want to boot a copy from Flash ?"), MessageBox.TYPE_YESNO)
		elif self.task == "kernelfix":
			self.nfifile="kernelfix"
      			self.session.openWithCallback(self.doExtract,MessageBox,_("Are you sure that you want to fix the Kernel ?"), MessageBox.TYPE_YESNO)
		elif self.task == "fsck":
			if os.path.exists("/usr/lib/enigma2/python/Plugins/Bp/geminimain/lib/libgeminimain.so"):
				libgeminimain.setHWLock(1)
			os.system("umount -f /tmp/dumbo")
			os.system("umount -f /media/%s" % config.plugins.dumbo.restlabel.value)
			if os.path.exists("%s1" % self.device):
				os.system("umount -f %s1" % self.device)
			if os.path.exists("%s2" % self.device):
				os.system("umount -f %s2" % self.device)
                	f=open("/proc/mounts", "r")
             	   	m=f.read()
			f.close()	
			if m.find("%s1" % self.device) is not -1 or m.find("%s2" % self.device) is not -1:
				if os.path.exists("/usr/lib/enigma2/python/Plugins/Bp/geminimain/lib/libgeminimain.so"):
					libgeminimain.setHWLock(0)
		    		self.session.open(MessageBox, nomount_string % self.device, MessageBox.TYPE_ERROR)
			else:
				self.session.openWithCallback(self.doCheck,MessageBox, wait_string % self.device, MessageBox.TYPE_INFO)
		else:
			print "[Dumbo] unknown command"
       
        def doCheck(self,answer):
		print "[Dumbo] is checking now ...."
	        self["logo"].instance.setPixmapFromFile("%s/sleep.png" % dumbo_plugindir)
		if os.path.exists("/usr/lib/enigma2/python/Plugins/Bp/geminimain/lib/libgeminimain.so"):
			libgeminimain.setHWLock(1)
        	open(dumbo_busy, 'a').close()   
		self.TimerDumbo = eTimer()                                       
		self.TimerDumbo.stop()                                           
		if not os.path.exists("/var/lib/opkg/status"):
			self.TimerDumbo_conn = self.TimerDumbo.timeout.connect(self.checkDone)
		else:
			self.TimerDumbo.callback.append(self.checkDone)
		self.TimerDumbo.start(5000,True)                                 
		DumboCheck(self.session,self.device)

	def checkDone(self):
		if os.path.exists(dumbo_busy):
			print "[Dumbo] checking ..."
			# not finished - continue checking ...
			self.TimerDumbo.start(5000,True)                                 
		else:
			print "[Dumbo] checking done !!!"
			self.TimerDumbo.stop()                                           
			if os.path.exists("/usr/lib/enigma2/python/Plugins/Bp/geminimain/lib/libgeminimain.so"):
				libgeminimain.setHWLock(0)
			if os.path.exists(dumbo_busy):
				os.remove(dumbo_busy)
			if os.path.exists(dumbo_script) and not config.plugins.dumbo.keep.value:
				os.remove(dumbo_script)
			if self.session:
				self.session.open(MessageBox, checkdone_string, MessageBox.TYPE_INFO)

    	def askForImage(self,image):
        	if image is None:
			self.session.open(MessageBox, nonfi_string, MessageBox.TYPE_ERROR)
        	else:
			self.nfifile=image[1]
               		self.session.openWithCallback(self.doExtract,MessageBox,_("Are you sure that you want to boot %s from %s ?") %(self.nfifile,self.device), MessageBox.TYPE_YESNO)

        def getDeviceList(self):                                               
		devlist=[]
       		found=0
		f=open("/proc/partitions","r")
		sp=[]
		devsizeunit="MB"
		line = f.readline()                                                    
		line = f.readline()                                                    
		line = f.readline()                                                    
		while (line):        
			sp=line.split()
#			print sp
			devlen=len(sp[3])
			if (sp[3].startswith("sd") and devlen==3) or (sp[3].startswith("mmcblk1") and devlen==7):
				devname="/dev/%s" % sp[3]
				# make MB
				size=int(sp[2])/1024
				print devname, size
				# ignore harddisks = and allow Bootdevices up to 32GB but not smaller then 256MB
				if size < config.plugins.dumbo.maxdevsize.value and size > dumbo_min_imagesize:
					devsize=size
					if devsize > 1024:
						devsize=size/1024
						devsizeunit="GB"
					found=found+1
					devlist.append(("%s %d %s" % (devname,devsize,devsizeunit), devname,size))
			line = f.readline()                                                 
		f.close()
		if found == 0:
			devlist.append(("no device found, shutdown, add USB stick and reboot" , "nodev", 0))
 	      	return devlist

        def getImageList(self):                                               
        	list = []                                                        
		if os.path.exists(config.plugins.dbackup.backuplocation.value):
           		for name in os.listdir(config.plugins.dbackup.backuplocation.value):                          
				if (name.endswith(".tar.gz") or name.endswith(".tar.xz")) and not name.startswith("enigma2settings") and not name.endswith("enigma2settingsbackup.tar.gz"):
                 			list.append(( name.replace(".tar.gz","").replace(".tar.xz",""), "%s/%s" % (config.plugins.dbackup.backuplocation.value,name)))                         
           	for directory in os.listdir("/media"):                          
			if os.path.isdir("/media/%s" % directory) and directory.endswith("net") is False and directory.endswith("hdd") is False:
				try:
           				for name in os.listdir("/media/%s" % directory):                          
						if (name.endswith(".tar.gz") or name.endswith(".tar.xz")) and not name.startswith("enigma2settings") and not name.endswith("enigma2settingsbackup.tar.gz"):
		                 			list.append(( name.replace(".tar.gz","").replace(".tar.xz",""), "/media/%s/%s" % (directory,name)))                         
				except:
					pass
		if config.plugins.dumbo.sort.value:
			list.sort()
		return list

	def doExtract(self,option):
		if option:
			print "[Dumbo] is extracting now ...."
	                self["logo"].instance.setPixmapFromFile("%s/sleep.png" % dumbo_plugindir)
			if os.path.exists("/usr/lib/enigma2/python/Plugins/Bp/geminimain/lib/libgeminimain.so"):
				libgeminimain.setHWLock(1)
    	        	open(dumbo_busy, 'a').close()   
			self.TimerDumbo = eTimer()                                       
			self.TimerDumbo.stop()                                           
			if not os.path.exists("/var/lib/opkg/status"):
				self.TimerDumbo_conn = self.TimerDumbo.timeout.connect(self.extractDone)
			else:
				self.TimerDumbo.callback.append(self.extractDone)
			self.TimerDumbo.start(5000,True)                                 
			DumboImage(self.session,self.device,self.nfifile)
		else:
			if os.path.exists(dumbo_busy):
				os.remove(dumbo_busy)
			print "[Dumbo] cancelled booting %s" % self.device

	def cancel(self):
		self.close(False)

	def about(self):
		self.session.open(DumboAbout)

	def backup(self):
		if os.path.exists(dumbo_busy):   
			self.session.open(MessageBox, running_string, MessageBox.TYPE_ERROR)
		else:
			self.session.open(dBackup)
#			self.session.open(MessageBox, use_dbackup_string, MessageBox.TYPE_ERROR)

	def extractDone(self):
		if os.path.exists(dumbo_busy):
			print "[Dumbo] extracting ..."
			# not finished - continue checking ...
			self.TimerDumbo.start(5000,True)                                 
		else:
			print "[Dumbo] extracting done !!!"
			self.TimerDumbo.stop()                                           
			if os.path.exists(dumbo_busy):
				os.remove(dumbo_busy)
			if os.path.exists("/usr/lib/enigma2/python/Plugins/Bp/geminimain/lib/libgeminimain.so"):
				libgeminimain.setHWLock(0)
			if os.path.exists(dumbo_script) and not config.plugins.dumbo.keep.value:
				os.remove(dumbo_script)
			if self.nfifile == "delete":
				if self.session:
					self.session.openWithCallback(self.doReboot,MessageBox, erase_string+"\n"+reboot_string, MessageBox.TYPE_INFO)
				else:
					self.doReboot(True)
				return
			else:
				if self.session:
					self.session.openWithCallback(self.doReboot,MessageBox, finished_string % self.nfifile+reboot_string, MessageBox.TYPE_INFO)
				else:
					self.doReboot(True)

	def doReboot(self,option):
		if self.task == "boot":
			k=open("/proc/cmdline","r")
			cmd=k.read()
			k.close()
			os.system("umount -f /tmp/dumbo")
			if cmd.find("root=/dev/mmcblk0") is not -1: 
				print "[DUMBO] boots B"
                		cmd="select-boot-source B"
			else:
				print "[DUMBO] boots A"
                		cmd="select-boot-source A"
			print cmd
        	        os.system(cmd)
		quitMainloop(2)

def autostart(reason,**kwargs):
	if os.path.exists(dumbo_busy):
		os.remove(dumbo_busy)
	if not os.path.exists("/tmp/dumbo"):
		os.mkdir("/tmp/dumbo")
	fsck=None
	if os.path.exists("/sbin/e2fsck"):
		fsck="/sbin/e2fsck"
	if os.path.exists("/sbin/fsck.ext2"):
		fsck="/sbin/fsck.ext2"
	if os.path.exists("/sbin/fsck.ext3"):
		fsck="/sbin/fsck.ext3"
	if os.path.exists("/sbin/fsck.ext4"):
		fsck="/sbin/fsck.ext4"
	if os.path.exists("/sbin/fsck.ext4dev"):
		fsck="/sbin/fsck.ext4dev"
	if fsck is not None:
		if not os.path.exists("/sbin/e2fsck"):
			os.link(fsck,"/sbin/e2fsck")
		if not os.path.exists("/sbin/fsck.ext2"):
			os.link(fsck,"/sbin/fsck.ext2")
		if not os.path.exists("/sbin/fsck.ext3"):
			os.link(fsck,"/sbin/fsck.ext3")
		if not os.path.exists("/sbin/fsck.ext4"):
			os.link(fsck,"/sbin/fsck.ext4")
		if not os.path.exists("/sbin/fsck.ext4dev"):
			os.link(fsck,"/sbin/fsck.ext4dev")
	mkfs=None
	if os.path.exists("/sbin/mke2fs"):
		mkfs="/sbin/mke2fs"
	if os.path.exists("/sbin/mkfs.ext2"):
		mkfs="/sbin/mkfs.ext2"
	if os.path.exists("/sbin/mkfs.ext3"):
		mkfs="/sbin/mkfs.ext3"
	if os.path.exists("/sbin/mkfs.ext4"):
		mkfs="/sbin/mkfs.ext4"
	if os.path.exists("/sbin/mkfs.ext4dev"):
		mkfs="/sbin/mkfs.ext4dev"
	if mkfs is not None:
		if not os.path.exists("/sbin/mke2fs"):
			os.link(mkfs,"/sbin/mke2fs")
		if not os.path.exists("/sbin/mkfs.ext2"):
			os.link(mkfs,"/sbin/mkfs.ext2")
		if not os.path.exists("/sbin/mkfs.ext3"):
			os.link(mkfs,"/sbin/mkfs.ext3")
		if not os.path.exists("/sbin/mkfs.ext4"):
			os.link(mkfs,"/sbin/mkfs.ext4")
		if not os.path.exists("/sbin/mkfs.ext4dev"):
			os.link(mkfs,"/sbin/mkfs.ext4dev")
	
def sessionstart(reason, **kwargs):                                               
        if reason == 0 and "session" in kwargs:                                                        
		if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/WebInterface/WebChilds/Toplevel.py"):
                        from Plugins.Extensions.WebInterface.WebChilds.Toplevel import addExternalChild
                        addExternalChild( ("dumbo", wDumbo(), "Dumbo", "1", True) )          
                else:                                                                                  
			print "[Dumbo] Webif not found"

def main(session, **kwargs):
        session.open(Dumbo)   

def Plugins(**kwargs):
        if os.path.exists("/usr/lib/enigma2/python/Plugins/Bp/geminimain") or config.plugins.dumbo.extension.value:
		return [PluginDescriptor(where = [PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART], fnc = autostart),
			PluginDescriptor(name="Dumbo", description=plugin_string, icon="dumbo.png", where=PluginDescriptor.WHERE_PLUGINMENU, fnc=main),
			PluginDescriptor(name="Dumbo", description=plugin_string, where = PluginDescriptor.WHERE_EXTENSIONSMENU, icon="g3icon_dumbo.png", fnc=main),
      			PluginDescriptor(where=PluginDescriptor.WHERE_SESSIONSTART, fnc=sessionstart, needsRestart=False)]
	else:
		return [PluginDescriptor(where = [PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART], fnc = autostart),
			PluginDescriptor(name="Dumbo", description=plugin_string, icon="dumbo.png", where=PluginDescriptor.WHERE_PLUGINMENU, fnc=main),
      			PluginDescriptor(where=PluginDescriptor.WHERE_SESSIONSTART, fnc=sessionstart, needsRestart=False)]

###############################################################################
# Dumbo Webinterface (c) gutemine
###############################################################################

class wDumbo(resource.Resource):

	def render_GET(self, req):
		file = req.args.get("file",None)
		device = req.args.get("device",None)
		directory = req.args.get("directory",None)
		command = req.args.get("command",None)
		print "[Dumbo] received %s %s %s" % (command,directory,file)
		req.setResponseCode(http.OK)
		req.setHeader('Content-type', 'text/html')
                req.setHeader('charset', 'UTF-8')
		if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/WebInterface/web-data/img/dumbo.png") is False:
			os.symlink("%s/dumbo.png" % dumbo_plugindir,"/usr/lib/enigma2/python/Plugins/Extensions/WebInterface/web-data/img/dumbo.png")
		if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/WebInterface/web-data/img/sleep.png") is False:
			os.symlink("%s/sleep.png" % dumbo_plugindir,"/usr/lib/enigma2/python/Plugins/Extensions/WebInterface/web-data/img/sleep.png")
		if os.path.exists(dumbo_busy):
			return header_string+dumbo_backuping
		htmlnfitasks = "<option value=\"delete\" class=\"blue\">%s</option>\n" % (_("Delete"))
		htmlnfitasks += "<option value=\"flashcopy\" class=\"blue\">%s</option>\n" % (_("Flashcopy"))
		htmlnfi=""
		if command is None or command[0] == refresh_string:
	 		for name in os.listdir("/tmp"):                          
				if (name.endswith(".tar.gz") or name.endswith(".tar.xz")) and not name.startswith("enigma2settings") and not name.endswith("enigma2settingsbackup.tar.gz"):
                 			name2=name.replace(".tar.gz","").replace(".tar.xz","")                         
					htmlnfi += "<option value=\"/tmp/%s\" class=\"blue\">%s</option>\n" % (name,name2)
			if os.path.exists(config.plugins.dbackup.backuplocation.value):
       				for name in os.listdir(config.plugins.dbackup.backuplocation.value):                          
					if (name.endswith(".tar.gz") or name.endswith(".tar.xz")) and not name.startswith("enigma2settings") and not name.endswith("enigma2settingsbackup.tar.gz"):
	                 			name2=name.replace(".tar.gz","").replace(".tar.xz","")                         
						htmlnfi += "<option value=\"%s/%s\" class=\"blue\">%s</option>\n" % (config.plugins.dbackup.backuplocation.value,name,name2)
       			for directory in os.listdir("/media"):                          
				if os.path.isdir("/media/%s" % directory) and directory.endswith("net") is False and directory.endswith("hdd") is False:
       					for name in os.listdir("/media/%s" % directory):                          
						if (name.endswith(".tar.gz") or name.endswith(".tar.xz")) and not name.startswith("enigma2settings") and not name.endswith("enigma2settingsbackup.tar.gz"):
		                 			name2=name.replace(".tar.gz","").replace(".tar.xz","")                         
							htmlnfi += "<option value=\"/media/%s/%s\" class=\"blue\">%s</option>\n" % (directory,name,name2)

			k=open("/proc/cmdline","r")
			cmd=k.read()
			k.close()
			if cmd.find("root=/dev/mmcblk0p1") is -1: 
	               		bootdevice="none"
				sp=[]
				sp=cmd.split(" ")
				print sp
				bootdevice=sp[4].replace("root=","")
                		self.device=bootdevice.rstrip("1").rstrip("p")
                		print "[Dumbo] bootdevice %s" % self.device
				title_string="Dumbo "+bootedfrom_string+" "+self.device
				# booted from Dumbo image hence only Flash boot possible
				self.device="none"
				boottaskflash=""
				boottaskflash += "<option value=\"boot\" class=\"blue\">%s</option>\n" % bootflash_string
				boottaskflash += "<option value=\"kernelfix\" class=\"blue\">%s</option>\n" % kernelfix_string
		 		return """
					<html>
					%s<br>
      					<u>%s (c) gutemine V%s</u><br><br><hr>%s<br><hr>
					Dumbo %s Flash @ Dreambox<br>
					<form method="GET">
					<select name="command">  
					%s
		                        <input name="command" type="reset" size=="100px">
	                        	<input name="command" type="submit" size=="100px" value=%s>
					</select>
                              	 	</form>                            
					<img src="/web-data/img/dumbo.png" alt="%s ..."/><br><br>
                        	       	<hr>
    				""" % (header_string,plugin_string,dumbo_version,title_string,booting_string,boottaskflash,execute_string, booting_string)
			else:
				self.device="none"
				title_string="Dumbo "+bootedfrom_string+" "+"Flash"
				boottask=""
				# booted from Flash  but add booting and fsck and kernelfix only when image already available
				if os.path.exists("/dev/disk/by-label/DUMBO"):
					if not os.path.exists("/tmp/dumbo"):
						os.mkdir("/tmp/dumbo")
					os.system("mount -t ext4 /dev/disk/by-label/DUMBO /tmp/dumbo")
					boottask += "<option value=\"boot\" class=\"blue\">%s</option>\n" % bootexisting_string
					boottask += "<option value=\"extract\" class=\"blue\">%s</option>\n" % refill_string
					boottask += "<option value=\"flashcopy\" class=\"blue\">%s</option>\n" % flashcopy_string
					boottask += "<option value=\"delete\" class=\"blue\">%s</option>\n" % delete_string
					boottask += "<option value=\"fsck\" class=\"blue\">%s</option>\n" % fsck_string
					boottask += "<option value=\"kernelfix\" class=\"blue\">%s</option>\n" % kernelfix_string
				else:
					boottask += "<option value=\"extract\" class=\"blue\">%s</option>\n" % extract_string
					boottask += "<option value=\"flashcopy\" class=\"blue\">%s</option>\n" % flashcopy_string
                              	found=0
				f=open("/proc/partitions","r")
				sp=[]
				devsizeunit="MB"
	 			line = f.readline()                                                    
	 			line = f.readline()                                                    
	 			line = f.readline()                                                    
	 			htmldev = "" 
				while (line):        
					sp=line.split()
					devlen=len(sp[3])
					if (sp[3].startswith("sd") and devlen==3) or (sp[3].startswith("mmcblk1") and devlen==7):
						devname="/dev/%s" % sp[3]
						# make MB
						size=int(sp[2])/1024
						print devname, size
						# ignore harddisks = and allow Bootdevices up to 32GB but not smaller then 256MB
						if size < config.plugins.dumbo.maxdevsize.value and size > dumbo_min_imagesize:
							devsize=size
							if devsize > 1024:
								devsize=size/1024
								devsizeunit="GB"
							# ignore harddisks = and allow Bootdevices up to 32GB but not smaller then 256MB
							if self.device == "none":
								found=found+1
								htmldev += "<option value=\"%s\">%s %d %s</option>\n" % (devname,devname,devsize,devsizeunit)
							else:
								if self.device == devname:
									found=found+1
									htmldev += "<option value=\"%s\">%s %d %s</option>\n" % (devname,devname,devsize,devsizeunit)
       					line = f.readline()                                                 
				f.close()
				if found == 0:
					htmldev += "<option value=\"nodev\">%s</option>\n" %  nousb_string
		 		return """
					<html>
					%s<br>
      					<u>%s (c) gutemine V%s</u><br><br><hr>%s<br><hr>
					Dumbo %s @ Dreambox<br>
					<form method="GET">
 					<select name="command">
					%s
                               		</select> 
                	       		<select name="device">%s
					</select>
        	        	       	<select name="file">%s
                	                <input name="command" type="reset" size="100px"> 
	                        	<input name="command" type="submit" size=="100px" value=%s>
					</select>
         	                      	</form>                             
					<img src="/web-data/img/dumbo.png" alt="%s ..."/><br><br>
                        	       	<hr>
    				""" % (header_string,plugin_string,dumbo_version,title_string,extract_string,boottask,htmldev,htmlnfi,execute_string,extract_string)

		elif command[0]=="boot":
			# booted from Flash ... hence we go to Dumbo Device
			# booted from Dumbo device ... hence we go to Flash
			self.doReboot(True)
			return header_string+dumbo_backuping

		elif command[0]=="fsck":
			if os.path.exists("/usr/lib/enigma2/python/Plugins/Bp/geminimain/lib/libgeminimain.so"):
				libgeminimain.setHWLock(1)
			os.system("umount -f /tmp/dumbo")
			os.system("umount -f /media/%s" % config.plugins.dumbo.restlabel.value)
			if os.path.exists("%s1" % self.device):
				os.system("umount %s1" % self.device)
			if os.path.exists("%s2" % self.device):
				os.system("umount %s2" % self.device)
                	f=open("/proc/mounts", "r")
             	   	m=f.read()
			f.close()	
			if m.find("%s1" % self.device) is not -1 or m.find("%s2" % self.device) is not -1 or m.find("%s4" % self.device) is not -1:
				if os.path.exists("/usr/lib/enigma2/python/Plugins/Bp/geminimain/lib/libgeminimain.so"):
					libgeminimain.setHWLock(0)
				return header_string+nomount_string % self.device+", "+dumbo_backbutton
			else:
				DumboCheck(False,self.device)
				return header_string+dumbo_backuping
		elif command[0]=="kernelfix":
			self.nfifile = "kernelfix"
			k=open("/proc/cmdline","r")
			cmd=k.read()
			k.close()
			if cmd.find("root=/dev/mmcblk0p1") is -1: 
	               		bootdevice="none"
				sp=[]
				sp=cmd.split(" ")
				print sp
				bootdevice=sp[4].replace("root=","")
                		self.device=bootdevice.rstrip("1").rstrip("p")
			else:
				self.device=device[0]
			DumboImage(False,self.device,self.nfifile)
			return header_string+dumbo_backuping
		elif command[0]=="delete":
			self.nfifile = "delete"
			self.device=device[0]
			DumboImage(False,self.device,self.nfifile)
			return header_string+dumbo_backuping
		elif command[0]=="flashcopy":
			self.nfifile = "flashcopy"
			self.device=device[0]
			DumboImage(False,self.device,self.nfifile)
			return header_string+dumbo_backuping
		elif command[0]=="extract":
			self.nfifile=file[0].lstrip().rstrip()
			self.device=device[0]
			print "[DUMBO] image %s device %s" % (self.nfifile,self.device)
			if os.path.exists(self.nfifile):
		 		if self.nfifile.endswith(".tar.gz") or self.nfifile.endswith(".tar.xz"):
					DumboImage(False,self.device,self.nfifile)
					return header_string+dumbo_backuping
				else:
					print "[Dumbo] wrong filename"
 					return header_string+nonfi_string+", "+dumbo_backbutton
		   	else:
				print "[Dumbo] filename not found"
				return header_string+nonfi_string+", "+dumbo_backbutton

		elif command[0]=="backup":
			return header_string+use_dbackup_string
		else:
			print "[Dumbo] unknown command"
              		return header_string+_("nothing entered")                 

	def doReboot(self,option):
		k=open("/proc/cmdline","r")
		cmd=k.read()
		k.close()
		os.system("umount -f /tmp/dumbo")
		if cmd.find("root=/dev/mmcblk0") is not -1: 
			print "[DUMBO] boots B"
                	cmd="select-boot-source B"
		else:
			print "[DUMBO] boots A"
                	cmd="select-boot-source A"
		print cmd
                os.system(cmd)
		quitMainloop(2)

class DumboImage(Screen):
	def __init__(self,session,device,nfifile):
		self.session=session
		device=device.rstrip().rstrip("\n").lstrip()
		if len(device) > 8:
			self.device=device+"p"
		else:
			self.device=device
		self.nfifile=nfifile
		print "[DUMBO] extracting image %s to %s" % (self.nfifile,self.device)
		os.system("touch %s" % dumbo_busy)
		command="#!/bin/sh -x\n"
                command += "exec > %s/%s 2>&1\n" % (config.plugins.dbackup.backuplocation.value,dumbo_log)                       
                command +="cat %s\n" % dumbo_script                       
                command +="df -h\n"                                           
		command +="systemctl stop autofs\n"
		command +="systemctl stop udev\n"
		command +="umount -f /tmp/dumbo\n"
		command +="umount -f /media/%s\n" % config.plugins.dumbo.restlabel.value
		i=0
		while i < 13:
			if os.path.exists("%s%i" % (self.device,i)):
				command +="umount -f %s%i\n" % (self.device,i)
			i=i+1
		cmd="ls -al %s > /tmp/.device" % device
		print "[DUMBO] command: %s" % cmd
		os.system(cmd)
		f=open("/tmp/.device","r")
		info=f.read()
		f.close()
		sp=[]
		sp=info.split(",")
		sp2=[]
		sp2=sp[0].split(" ")
		if sp2[len(sp2)-1].startswith("ide"):
			major=22
			minor=0
		else:
			major=int(sp2[len(sp2)-1])
			sp3=[]
			sp3=sp[1].split(" ")
			i=0
			while sp3[i] == '':
				i=i+1
			minor=int(sp3[i])
		print "[Dumbo] info %s major: %d minor: %d" % (info,major,minor)
#   		command +="partprobe %s\n" % self.device
#		command +="dd if=/dev/zero of=%s bs=2048 count=1\n" % self.device
		if not os.path.exists("%s1" % self.device):
		 	command +="mknod -m 640 %s1 b %i %i\n" % (self.device,major, minor+1)
		if not os.path.exists("%s2" % self.device):
		 	command +="mknod -m 640 %s2 b %i %i\n" % (self.device,major, minor+2)
		if self.nfifile == "delete":
	   		command +="fdisk %s << EOF\n" % (device)
			command +="d\n" 
			command +="1\n" 
			command +="d\n" 
			command +="2\n" 
			command +="d\n" 
			command +="3\n" 
			command +="d\n" 
			command +="n\n" 
			command +="p\n" 
			command +="1\n" 
			command +="\n" 
			command +="\n" 
			command +="w\n" 
	   		command +="EOF\n"
			command +="mkfs.ext4 %s1\n" % (self.device)
			# reset Boot kernel B to Flashkernel
                        command +="/usr/sbin/flash-kernel -a /usr/share/fastboot/lcd_anim.bin -m 0x10000000 -o B -c \"bmem=512M@512M memc1=768M console=ttyS0,1000000  root=/dev/mmcblk0p1 rootwait rootfstype=ext4\" /boot/vmlinux.bin*\n" 
			# and set Flash kernel A for booting
                	command +="select-boot-source A\n"
       	                command +="umount /tmp/dumbo\n"
			command +="rm %s\n" % dumbo_busy
			command +="exit 0\n"
		elif self.nfifile == "kernelfix":
			k=open("/proc/cmdline","r")
			cmd=k.read()
			k.close()
			if cmd.find("root=/dev/mmcblk0") is not -1: 
				print "[DUMBO] is doing kernelfix in Flash ..."
				# re-write Boot kernel B from Dumbo image kernel
        	                command +="mount -t ext4 /dev/disk/by-label/DUMBO /tmp/dumbo\n"
  	                        command +="/usr/sbin/flash-kernel -a /tmp/dumbo/usr/share/fastboot/lcd_anim.bin -m 0x10000000 -o B -c \"bmem=512M@512M memc1=768M console=ttyS0,1000000  root=%s1 rootwait rootfstype=ext4\" /tmp/dumbo/boot/vmlinux.bin*\n" % self.device
				# re-write Boot kernel A from Flash image kernel
  	                        command +="/usr/sbin/flash-kernel -a /usr/share/fastboot/lcd_anim.bin -m 0x10000000 -o A -c \"bmem=512M@512M memc1=768M console=ttyS0,1000000  root=/dev/mmcblk0p1 rootwait rootfstype=ext4\" /boot/vmlinux.bin*\n" 
			else:
				print "[DUMBO] is doing kernelfix in Dumbo Image ..."
				# re-write Boot kernel A from Flash image kernel
        	                command +="mkdir /tmp/root\n"
        	                command +="mount -t ext4 /dev/mmcblk0p1 /tmp/root\n"
  	                        command +="/usr/sbin/flash-kernel -a /tmp/root/usr/share/fastboot/lcd_anim.bin -m 0x10000000 -o A -c \"bmem=512M@512M memc1=768M console=ttyS0,1000000  root=/dev/mmcblk0p1 rootwait rootfstype=ext4\" /tmp/root/boot/vmlinux.bin*\n" 
        	                command +="umount /tmp/root\n"
				# re-write Boot kernel B from Dumbo image kernel
  	                        command +="/usr/sbin/flash-kernel -a /usr/share/fastboot/lcd_anim.bin -m 0x10000000 -o B -c \"bmem=512M@512M memc1=768M console=ttyS0,1000000  root=%s1 rootwait rootfstype=ext4\" /boot/vmlinux.bin*\n" % self.device
       	                command +="umount /tmp/dumbo\n"
			command +="rm %s\n" % dumbo_busy
			command +="exit 0\n"
		else:
	   		command +="fdisk %s << EOF\n" % (device)
			command +="d\n" 
			command +="1\n" 
			command +="d\n" 
			command +="2\n" 
			command +="d\n" 
			command +="3\n" 
			command +="d\n" 
			command +="n\n" 
			command +="p\n" 
			command +="1\n" 
			command +="\n" 
		        if config.plugins.dumbo.imagesize.value > 0:
   				command +="+%iM\n" % (config.plugins.dumbo.imagesize.value)
				command +="n\n" 
				command +="p\n" 
				command +="2\n" 
				command +="\n" 
			command +="\n" 
	   		command +="w\n"
	   		command +="EOF\n"
	   		command +="fdisk -l %s\n" % (device)
			command +="mkfs.ext4 -L DUMBO %s1\n" % (self.device)
			if config.plugins.dumbo.restpartition.value and config.plugins.dumbo.restformat.value:
			   	command +="mkfs.ext4 -L %s %s2\n" % (config.plugins.dumbo.restlabel.value,self.device)
		   		command +="mkdir /media/%s\n" % (config.plugins.dumbo.restlabel.value)
			command +="mkdir /tmp/dumbo\n"
			command +="mount -t ext4 %s1 /tmp/dumbo\n" % (self.device)
			command +="rm -r /tmp/dumbo\n"
			if self.nfifile == "flashcopy":
  		        	command +="mkdir /tmp/root\n"
  		        	command +="mount -o bind / /tmp/root\n"
  		        	command +="cp -RP /tmp/root/* /tmp/dumbo\n"
  		        	command +="umount /tmp/root\n"
			else:
	   			if self.nfifile.endswith(".tar.xz"):
	   				command +="tar -xvJf %s -C /tmp/dumbo\n" % (self.nfifile)
	   			elif self.nfifile.endswith(".tar.gz"):
	   				command +="tar -xvzf %s -C /tmp/dumbo\n" % (self.nfifile)
	   			elif self.nfifile.endswith(".tar.bz2"):
	   				command +="tar -xvjf %s -C /tmp/dumbo\n" % (self.nfifile)
	   			else:
	   				command +="tar -xvf %s -C /tmp/dumbo\n" % (self.nfifile)
#		        if config.plugins.dumbo.labelmount.value:
#				command +="\n"
#			else:
#				command +="\n"
			command +="rm -rf /tmp/dumbo%s\n" % dbackup_plugindir
			command +="cp -RP %s /tmp/dumbo%s\n" % (dbackup_plugindir,dbackup_plugindir)
			command +="rm -rf /tmp/dumbo%s\n" % dumbo_plugindir
			command +="cp -RP %s /tmp/dumbo%s\n" % (dumbo_plugindir,dumbo_plugindir)
			if config.plugins.dumbo.passwd.value:
            			command +="cp /etc/passwd* /tmp/dumbo/etc\n"
#    			command +="mkdir /tmp/dumbo/etc/network\n"
#          		command +="cp /etc/network/interfaces /tmp/dumbo/etc/network/interfaces\n"
#          		command +="cp /etc/resolv.conf /tmp/dumbo/etc/resolv.conf\n"
                        command +="/usr/sbin/flash-kernel -a /tmp/dumbo/usr/share/fastboot/lcd_anim.bin -m 0x10000000 -o B -c \"bmem=512M@512M memc1=768M console=ttyS0,1000000  root=%s1 rootwait rootfstype=ext4\" /tmp/dumbo/boot/vmlinux.bin*\n" % self.device
			command +="rm %s\n" % dumbo_busy
       	                command +="umount /tmp/dumbo\n"
			command +="exit 0\n"
		print command
		b=open(dumbo_script,"w")
		b.write(command)
		b.close()
		os.chmod(dumbo_script, 0777)
		start_cmd="start-stop-daemon -K -n dumbo.sh -s 9; start-stop-daemon -S -b -n dumbo.sh -x %s" % (dumbo_script)
		os.system(start_cmd)                                                           

class DumboCheck(Screen):
	def __init__(self,session,device):
	      	print "[Dumbo] starts checking"
		self.session=session
		device=device.rstrip().rstrip("\n").lstrip()
		if len(device) > 8:
			self.device=device+"p"
		else:
			self.device=device
		os.system("touch %s" % dumbo_busy)
		command ="#!/bin/sh -x\n"
                command += "exec > %s/%s 2>&1\n" % (config.plugins.dbackup.backuplocation.value,dumbo_log)                       
                command +="cat %s\n" % dumbo_script                       
                command +="df -h\n"                                           
		command +="fsck.ext4 -f -v -p %s1\n" % self.device
		if os.path.exists("%s2" % self.device):
			command +="umount /media/%s\n" % config.plugins.dumbo.restlabel.value
			command +="fsck.ext4 -f -v -p %s2\n" % self.device
			command +="mount /media/%s\n" % config.plugins.dumbo.restlabel.value
		command +="rm %s\n" % dumbo_busy
		command +="exit 0\n"
		print command
		b=open(dumbo_script,"w")
		b.write(command)
		b.close()
		os.chmod(dumbo_script, 0777)
		start_cmd="start-stop-daemon -K -n dumbo.sh -s 9; start-stop-daemon -S -b -n dumbo.sh -x %s" % (dumbo_script)
		os.system(start_cmd)                                                           

class DumboConfiguration(Screen, ConfigListScreen):
    skin = """
        <screen position="center,center" size="680,510" title="Dumbo Configuration" >
        <widget name="config" position="10,60" size="660,450" scrollbarMode="showOnDemand" />
	<widget name="logo" position="10,10" size="100,40" transparent="1" alphatest="on" />
        <widget name="buttonred" position="120,10" size="130,40" backgroundColor="red" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;18"/>
        <widget name="buttongreen" position="260,10" size="130,40" backgroundColor="green" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;18"/>
        <widget name="buttonyellow" position="400,10" size="130,40" backgroundColor="yellow" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;18"/>
        <widget name="buttonblue" position="540,10" size="130,40" backgroundColor="blue" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;18"/>
        </screen>"""

    def __init__(self, session, args = 0):
	Screen.__init__(self, session)
       	self.list = []
	k=open("/proc/cmdline","r")
	cmd=k.read()
	k.close()
	if cmd.find("root=/dev/mmcblk0") is not -1: 
        	self.list.append(getConfigListEntry(_("Dumbo Image size 0 = entire device [MB]"), config.plugins.dumbo.imagesize))
        	self.list.append(getConfigListEntry(_("Restpartition"), config.plugins.dumbo.restpartition))
        	self.list.append(getConfigListEntry(_("Restlabel"), config.plugins.dumbo.restlabel))
        	self.list.append(getConfigListEntry(_("Restformat"), config.plugins.dumbo.restformat))
        	self.list.append(getConfigListEntry(_("Ignore devices larger then [MB]"), config.plugins.dumbo.maxdevsize))
#        	self.list.append(getConfigListEntry(_("alphabetic sort"), config.plugins.dumbo.sort))
#        	self.list.append(getConfigListEntry(_("rootdelay [sec]"), config.plugins.dumbo.rootdelay))
	       	self.list.append(getConfigListEntry(_("Password copy"), config.plugins.dumbo.passwd))
#		self.list.append(getConfigListEntry(_("Initrd"), config.plugins.dumbo.initrd))
#		self.list.append(getConfigListEntry(_("Labelmount"), config.plugins.dumbo.labelmount))
       	self.list.append(getConfigListEntry(_("show in Extensions Menu"), config.plugins.dumbo.extension))

        self.onShown.append(self.setWindowTitle)
       	ConfigListScreen.__init__(self, self.list)

        # explizit check on every entry
	self.onChangedEntry = []

	self["logo"] = Pixmap()
       	self["buttonred"] = Label(_("Cancel"))
       	self["buttongreen"] = Label(_("OK"))
       	self["buttonyellow"] = Label(_("---"))
       	self["buttonblue"] = Label(_("About"))
        self["setupActions"] = ActionMap(["SetupActions", "ColorActions"],
       	{
       		"green": self.save,
        	"red": self.cancel,
	       	"yellow": self.cancel,
        	"blue": self.about,
            	"save": self.save,
            	"cancel": self.cancel,
            	"ok": self.save,
       	})
    def setWindowTitle(self):
        self.setTitle("Dumbo "+_("Setup"))
       	self["logo"].instance.setPixmapFromFile("%s/dumbo.png" % dumbo_plugindir)

    def save(self):
	if config.plugins.dumbo.imagesize.value > 0 and config.plugins.dumbo.imagesize.value < dumbo_min_imagesize:
		config.plugins.dumbo.imagesize.value = dumbo_min_imagesize
	      	config.plugins.dumbo.imagesize.save()
	if config.plugins.dumbo.imagesize.value == 0:
		config.plugins.dumbo.restpartition.value = False
		config.plugins.dumbo.restformat.value = False
	if config.plugins.dumbo.restpartition.value is False:
		config.plugins.dumbo.restformat.value = False
        for x in self["config"].list:
           x[1].save()
        self.close(True)

    def cancel(self):
        for x in self["config"].list:
           x[1].cancel()
        self.close(False)

    def about(self):
       	self.session.open(DumboAbout)

class DumboAbout(Screen):
    skin = """
        <screen position="center,center" size="680,470" title="About Dumbo" >
        <ePixmap position="290,10" size="100,100" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/Dumbo/g3icon_dumbo.png" transparent="1" alphatest="on" />   
        <widget name="buttonred" position="10,10" size="130,40" backgroundColor="red" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;18"/>
        <widget name="buttongreen" position="540,10" size="130,40" backgroundColor="green" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;18"/>
        <widget name="aboutdumbo" position="10,140" size="660,100" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;24"/>
        <widget name="freefilesystem" position="120,250" size="200,210" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;24"/>
        <widget name="freememory" position="380,250" size="200,210" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;24"/>
        </screen>"""

    def __init__(self, session, args = 0):
	Screen.__init__(self, session)
        self.onShown.append(self.setWindowTitle)

	global freefilesystem
	global freememory

       	self["buttonred"] = Label(_("Cancel"))
       	self["buttongreen"] = Label(_("OK"))
       	self["aboutdumbo"] = Label(plugin_string+" (c) gutemine V"+dumbo_version)
       	self["freefilesystem"] = Label(freefilesystem)
       	self["freememory"] = Label(freememory)
        self["setupActions"] = ActionMap(["SetupActions", "ColorActions"],
       	{
       		"green": self.cancel,
        	"red": self.cancel,
	       	"yellow": self.cancel,
        	"blue": self.cancel,
            	"save": self.cancel,
            	"cancel": self.cancel,
            	"ok": self.cancel,
       	})
    def setWindowTitle(self):
        self.setTitle( _("About")+" Dumbo")

    def cancel(self):
        self.close(False)

