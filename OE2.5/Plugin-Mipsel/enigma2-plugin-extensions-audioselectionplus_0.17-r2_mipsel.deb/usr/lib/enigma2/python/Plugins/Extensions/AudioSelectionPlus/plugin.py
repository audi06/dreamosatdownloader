# -*- coding: utf-8 -*-
#
# Audio Selection Plus Plugin by gutemine
#
audioselectionplus_version="0.17-r1"
#
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.config import config, ConfigSubsection, ConfigBoolean, ConfigInteger, getConfigListEntry, ConfigSelection
from Components.ConfigList import ConfigListScreen
from Plugins.Plugin import PluginDescriptor

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.InputBox import InputBox
from Components.Language import language
from Components.Input import Input
from Components.ActionMap import NumberActionMap
from Components.ServiceEventTracker import ServiceEventTracker
from Components.Sources.List import List
from Screens.AudioSelection import SubtitleSelection as SubtitleSelectionOri, AudioSelection as AudioSelectionOri, FOCUS_CONFIG, FOCUS_STREAMS, PAGE_AUDIO, PAGE_SUBTITLES
from Screens.InfoBarGenerics import InfoBarAudioSelection as InfoBarAudioSelectionOri
import Screens.AudioSelection
from Tools.Directories import resolveFilename, SCOPE_PLUGINS, SCOPE_LANGUAGE
from enigma import iPlayableService, eTimer
from Tools.ISO639 import LanguageCodes
import os, gettext
global last_audio_press
last_audio_press=0

asp_plugin="/usr/lib/enigma2/python/Plugins/Extensions/AudioSelectionPlus"
asp_conf="asp.conf"
if os.path.exists("/etc/enigma2/%s" % asp_conf):
	asp_conf_path="/etc/enigma2/%s" % (asp_conf)
else:
	asp_conf_path="%s/%s" % (asp_plugin,asp_conf)

yes_no_descriptions = {False: _("no"), True: _("yes")}
config.plugins.audioselectionplus = ConfigSubsection()
config.plugins.audioselectionplus.enable = ConfigBoolean(default = True, descriptions=yes_no_descriptions)
#exit after selection or not
config.plugins.audioselectionplus.audionumber = ConfigSelection(default = "zap", choices = [("exit",_("exit")), ("zap",_("zap"))])
#type
audiotype=[ ("MPEG",_("MPEG")), ("AC3",_("AC3")), ("DTS",_("DTS")), ("all",_("all")) ]
config.plugins.audioselectionplus.audiotype = ConfigSelection(default = "all", choices = audiotype)
# Audio key enhancements
audiokey=[ ("none",_("none")), ("exit",_("exit")), ("zap",_("zap")),]
config.plugins.audioselectionplus.audiokey = ConfigSelection(default = "none", choices = audiokey)
# Zero key enhancements
zerokey=[ ("none",_("none")), ("exit",_("exit")), ("zap",_("zap")),("select",_("select")), ]
config.plugins.audioselectionplus.zerokey = ConfigSelection(default = "none", choices = zerokey)

languageList = language.getLanguageList()
lang=[("none",_("none"))]

if os.path.exists(asp_conf_path):
	with open(asp_conf_path) as a:
		for line in a:
			lang.append((line.strip(),line.strip()))

lang.append(("Dolby",_("Dolby")))
for x in languageList:
	lang.append((x[1][0],_(x[1][0])))

config.plugins.audioselectionplus.audio1 = ConfigSelection(default = "none", choices = lang)
config.plugins.audioselectionplus.audio2 = ConfigSelection(default = "none", choices = lang)
config.plugins.audioselectionplus.audio3 = ConfigSelection(default = "none", choices = lang)
config.plugins.audioselectionplus.audio4 = ConfigSelection(default = "none", choices = lang)
config.plugins.audioselectionplus.audio5 = ConfigSelection(default = "none", choices = lang)
config.plugins.audioselectionplus.audio6 = ConfigSelection(default = "none", choices = lang)
config.plugins.audioselectionplus.audio7 = ConfigSelection(default = "none", choices = lang)
config.plugins.audioselectionplus.audio8 = ConfigSelection(default = "none", choices = lang)
config.plugins.audioselectionplus.audio9 = ConfigSelection(default = "none", choices = lang)
config.plugins.audioselectionplus.preselect = ConfigBoolean(default = False, descriptions=yes_no_descriptions)
config.plugins.audioselectionplus.zapping = ConfigInteger(default = 0, limits = (0, 10))

class AudioSelectionPlus(AudioSelectionOri):
	@staticmethod
	def getPreferredTrackIndex(streams):
		preflist=[
			config.plugins.audioselectionplus.audio1.value,
			config.plugins.audioselectionplus.audio2.value,
			config.plugins.audioselectionplus.audio3.value,
			config.plugins.audioselectionplus.audio4.value,
			config.plugins.audioselectionplus.audio5.value,
			config.plugins.audioselectionplus.audio6.value,
			config.plugins.audioselectionplus.audio7.value,
			config.plugins.audioselectionplus.audio8.value,
			config.plugins.audioselectionplus.audio9.value,
		]

		runningstr=_("Running")
		for value in preflist:
			en = value.upper()
			loc = _(value).upper()
			if en != "none" and loc != _("none"):
				for idx, stream in enumerate(streams):
					cfgval = config.plugins.audioselectionplus.audiotype.value
					curtype = stream[3].upper()
					curval = stream[4].upper()
					currun = stream[5] == runningstr

					if curval.find(en) > -1 or curval.find(loc) > -1 :
						if config.plugins.audioselectionplus.audiotype.value == "all":
							return (idx, currun)
						if curtype.find(cfgval) > -1:
							return (idx, currun)
			else:
				break

		return (-1, False) #nothing found

	def __init__(self, session, infobar=None, page=PAGE_AUDIO):
		AudioSelectionOri.__init__(self, session, infobar=infobar, page=page)
		self.skinName = ["AudioSelection"]
##		self.__selected_subtitle = self._AudioSelection__selected_subtitle
                self.cached_subtitle_checked = False                            
                self.__last_selected_subtitle_idx = None      

		self["plusactions"] = NumberActionMap(["InfobarAudioSelectionActions", "MenuActions", "NumberActions", "WizardActions" ],
		{
			"menu": self.keyMenu,
			"audioSelection": self.keyAudio,
			"text": self.keyText,   
			"0": self.keyZero,   
		}, -2)

		self.onShown.append(self.setLanguage)
	
	def __updatedInfo(self):
		self._AudioSelection__updatedInfo()

	def setLanguage(self):
		if config.plugins.audioselectionplus.preselect.value:
			if self.__last_selected_subtitle_idx is not None:
				# only do preselection of Audio track the first time
				return
			streams=self["streams"].list
			index, running = AudioSelectionPlus.getPreferredTrackIndex(streams)
			if index > 0 and not running:
				if len(self["streams"].list) > 1:
					self["streams"].setIndex(index)
					self.keyOk(False)

	def keyNumberGlobal(self, number):
		if number <= len(self["streams"].list):
			self["streams"].setIndex(number-1)
			if config.plugins.audioselectionplus.audionumber.value == "exit":
				self.keyOk(True)
			else:
				self.keyOk(False)
				
	def keyZero(self,number):
		self.focus = FOCUS_STREAMS
		if config.plugins.audioselectionplus.zerokey.value == "exit":
			print "[AudioSelectionPlus] Zero key triggers exit"
			self.keyOk(True)
		elif config.plugins.audioselectionplus.zerokey.value == "select":
			print "[AudioSelectionPlus] Zero key triggers preselect"
			streams=self["streams"].list
			index, running = AudioSelectionPlus.getPreferredTrackIndex(streams)
			if index > 0 and not running:
				if len(self["streams"].list) > 1:
					self["streams"].setIndex(index)
			self.keyOk(False)
		elif config.plugins.audioselectionplus.zerokey.value == "zap":
			print "[AudioSelectionPlus] Zero Key triggers zap"
			audionum=len(self["streams"].list)
			selectedidx = self["streams"].getIndex()
			if selectedidx < (audionum-1):
				self.keyDown()
			else:
				self.keyLeft()
			self.keyOk(False)
		else:
			print "[AudioSelectionPlus] Zero key triggers nothing"
			
	def keyAudio(self):
		# almost the same same as keyZero = to be eliminiated 
		self.focus = FOCUS_STREAMS
		if config.plugins.audioselectionplus.audiokey.value == "exit":
			print "[AudioSelectionPlus] Audio key triggers exit"
			self.keyOk(True)
		elif config.plugins.audioselectionplus.audiokey.value == "select":
			print "[AudioSelectionPlus] Audio key triggers preselect"
			streams=self["streams"].list
			index, running = AudioSelectionPlus.getPreferredTrackIndex(streams)
			if index > 0 and not running:
				if len(self["streams"].list) > 1:
					self["streams"].setIndex(index)
			self.keyOk(False)
		elif config.plugins.audioselectionplus.audiokey.value == "zap":
			print "[AudioSelectionPlus] Audio key triggers zap"
			audionum=len(self["streams"].list)
			selectedidx = self["streams"].getIndex()
			if selectedidx < (audionum-1):
				self.keyDown()
			else:
				self.keyLeft()
			self.keyOk(False)
		else:
			print "[AudioSelectionPlus] Audio key triggers nothing"
				
	def keyText(self):
		print "[AudioSelectionPlus] pressed TEXT"
		selectedidx = self["streams"].getIndex()
		asptext=self["streams"].list[selectedidx][4]
		print "[AudioSelectionPlus] string %s" % asptext
		exists=False
		check=asptext.strip().upper()
		if os.path.exists(asp_conf_path):
			with open(asp_conf_path) as a:
				for line in a:
					if check == line.strip().upper():
						exists=True
		for x in languageList:
			if check == x[1][0].upper() or check ==_(x[1][0]).upper():
				exists=True
		if exists:
			self.duplicateText(asptext)
		else:
			self.session.openWithCallback(self.addSearchText, InputBox, title=_g("Add to favourites"), text=asptext, maxSize=True, type=Input.TEXT) 
	
        def addSearchText(self,asptext):                                                                     
	        if asptext is None:                                                                                 
			self.session.open(MessageBox, _("empty"), MessageBox.TYPE_ERROR)
	        else:                                                                                              
	        	asptext=asptext.lstrip().rstrip()
			a=open(asp_conf_path)
			s=a.read()
			a.close()
			if s.find(asptext) is not -1:
				self.duplicateText(asptext)
			else:
				self.saveText(asptext)
				
        def saveText(self,asptext):                                                                     
			a=open(asp_conf_path,"a")
			a.write("%s\n" % asptext)
			a.close()
			self.session.open(MessageBox, _g("Added: %s") % asptext, MessageBox.TYPE_INFO)

        def duplicateText(self,asptext):                                                                     
		self.session.open(MessageBox, _g("%s already exists") % asptext, MessageBox.TYPE_ERROR)
		
	def keyOk(self, exit=True):
		if self.focus == FOCUS_STREAMS and self["streams"].list:
			cur = self["streams"].getCurrent()
			if self.settings.menupage.getValue() == PAGE_AUDIO and cur[0] is not None:
				self.changeAudio(cur[0])
				self.__updatedInfo()
			if self.settings.menupage.getValue() == PAGE_SUBTITLES and cur[0] is not None:
				if self.infobar.selected_subtitle == cur[0]:
					self.enableSubtitle(None)
					selectedidx = self["streams"].getIndex()
					self.__updatedInfo()
					self["streams"].setIndex(selectedidx)
				else:
					self.enableSubtitle(cur[0])
					self.__updatedInfo()
			if exit:
				self.close(0)
		elif self.focus == FOCUS_CONFIG:
			self.keyRight()


	def keyMenu(self):
		self.session.open(AudioConfigurationPlus)

class SubtitleSelectionPlus(AudioSelectionPlus):
	def __init__(self, session, infobar=None):
		AudioSelectionPlus.__init__(self, session, infobar, page=PAGE_SUBTITLES)
		self.skinName = ["AudioSelection"]

PluginLanguageDomain = "audioselectionplus"
PluginLanguagePath = "Extensions/AudioSelectionPlus/locale"

def localeInit():
	lang = language.getLanguage()[:2] # getLanguage returns e.g. "fi_FI" for "language_country"
 	os.environ["LANGUAGE"] = lang # Enigma doesn't set this (or LC_ALL, LC_MESSAGES, LANG). gettext needs it!
 	print "[%s] set language to [%s]" % (PluginLanguageDomain, lang)
	gettext.bindtextdomain(PluginLanguageDomain, resolveFilename(SCOPE_PLUGINS, PluginLanguagePath))

def _g(txt):
	t = gettext.dgettext(PluginLanguageDomain, txt)
	if t == txt:
		print "[AudioSelectionPlus] only default translation for %s" %(txt)
		t = gettext.gettext(txt)
	return t

localeInit()
language.addCallback(localeInit)

class AudioConfigurationPlus(Screen, ConfigListScreen):
	skin = """
		<screen position="center,center" size="650,480" title="Audio Configuration" >
		<widget name="config" position="10,10" size="630,410" scrollbarMode="showOnDemand" />
		<widget name="buttonred" position="10,430" size="150,40" backgroundColor="red" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;24"/>
		<widget name="buttongreen" position="170,430" size="150,40" backgroundColor="green" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;24"/>
		<widget name="buttonyellow" position="330,430" size="150,40" backgroundColor="yellow" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;24"/>
		<widget name="buttonblue" position="490,430" size="150,40" backgroundColor="blue" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;24"/>
		</screen>"""

	def __init__(self, session, args = 0):
		Screen.__init__(self, session)
	   	self.list = []
		self.list.append(getConfigListEntry(_g("Audio Selection Plus Menu on Audio key"), config.plugins.audioselectionplus.enable))
		self.list.append(getConfigListEntry(_g("Audio key action in Audio menu"), config.plugins.audioselectionplus.audiokey))
		self.list.append(getConfigListEntry(_g("Zero key action in Audio menu"), config.plugins.audioselectionplus.zerokey))
		self.list.append(getConfigListEntry(_g("Audio number key action in Audio menu"), config.plugins.audioselectionplus.audionumber))
		self.list.append(getConfigListEntry(_g("Audio Track preselect in Audio menu"), config.plugins.audioselectionplus.preselect))
		self.list.append(getConfigListEntry(_g("Audio Track preselect on zapping after 0-10 sec (0=disabled)"), config.plugins.audioselectionplus.zapping))
		self.list.append(getConfigListEntry(_g("Audio Track preselect type"), config.plugins.audioselectionplus.audiotype))
		self.list.append(getConfigListEntry(_g("Audio Track")+" #1", config.plugins.audioselectionplus.audio1))
		self.list.append(getConfigListEntry(_g("Audio Track")+" #2", config.plugins.audioselectionplus.audio2))
		self.list.append(getConfigListEntry(_g("Audio Track")+" #3", config.plugins.audioselectionplus.audio3))
		self.list.append(getConfigListEntry(_g("Audio Track")+" #4", config.plugins.audioselectionplus.audio4))
		self.list.append(getConfigListEntry(_g("Audio Track")+" #5", config.plugins.audioselectionplus.audio5))
		self.list.append(getConfigListEntry(_g("Audio Track")+" #6", config.plugins.audioselectionplus.audio6))
		self.list.append(getConfigListEntry(_g("Audio Track")+" #7", config.plugins.audioselectionplus.audio7))
		self.list.append(getConfigListEntry(_g("Audio Track")+" #8", config.plugins.audioselectionplus.audio8))
		self.list.append(getConfigListEntry(_g("Audio Track")+" #9", config.plugins.audioselectionplus.audio9))

		self.onShown.append(self.setWindowTitle)
	   	ConfigListScreen.__init__(self, self.list)

		# explizit check on every entry
		self.onChangedEntry = []
		self["buttonred"] = Label(_g("Cancel"))
		self["buttongreen"] = Label(_g("OK"))
		self["buttonyellow"] = Label(_g("Favourites"))
		self["buttonblue"] = Label(_g("About"))
		self["setupActions"] = ActionMap(["SetupActions", "ColorActions"],
		{
			"green": self.save,
			"red": self.cancel,
			"yellow": self.favourites,
			"blue": self.about,
			"save": self.save,
			"cancel": self.cancel,
			"ok": self.save,
		})

	def setWindowTitle(self):
		self.setTitle(_("Audio")+ " "+_("Setup"))

	def save(self):
		for x in self["config"].list:
			x[1].save()

		# rename originals
		if config.plugins.audioselectionplus.enable.value:
			Screens.AudioSelection.AudioSelection = AudioSelectionPlus
			Screens.AudioSelection.SubtitleSlection = SubtitleSelectionPlus
		else:
			Screens.AudioSelection.AudioSelection = AudioSelectionOri
			Screens.AudioSelection.SubtitleSlection = SubtitleSelectionOri
		self.close(True)

	def favourites(self):
		fav=""
		if os.path.exists(asp_conf_path):
			with open(asp_conf_path) as a:
				for line in a:
					fav=fav+"\n%s" % line.strip()
		self.session.open(MessageBox, fav, MessageBox.TYPE_INFO)
		
	def cancel(self):
		for x in self["config"].list:
			x[1].cancel()
		self.close(False)

	def about(self):
		self.session.open(MessageBox, _g("Audio Selection Plus Plugin Version %s by gutemine") % audioselectionplus_version, MessageBox.TYPE_INFO)

# rename originals on startup
if config.plugins.audioselectionplus.enable.value:
	Screens.AudioSelection.AudioSelection = AudioSelectionPlus
	Screens.AudioSelection.SubtitleSlection = SubtitleSelectionPlus
else:
	Screens.AudioSelection.AudioSelection = AudioSelectionOri
	Screens.AudioSelection.SubtitleSlection = SubtitleSelectionOri

def startAudioSelectionPlus(session, **kwargs):
	session.open(AudioConfigurationPlus)

def autostart(reason,**kwargs):
	if kwargs.has_key("session") and reason == 0:
		session = kwargs["session"]
		print "[AudioSelectionPlus] autostart checking"
		session.open(AudioSelectionCheck)

def sessionstart(reason, **kwargs):
	if reason == 0 and "session" in kwargs:
		session = kwargs["session"]
		print "[AudioSelectionPlus] sessionstart"

def Plugins(**kwargs):
	return [
		PluginDescriptor(where = [PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART], fnc = autostart),
		PluginDescriptor(name="AudioSelectionPlus", description="AudioSelectionPlus", where=PluginDescriptor.WHERE_MENU, fnc=mainconf),
		PluginDescriptor(where=PluginDescriptor.WHERE_SESSIONSTART, fnc=sessionstart, needsRestart=False)
	]

def mainconf(menuid):
	if menuid != "system":
		return [ ]
	name="%s %s" %(_("Audio"), _("Setup"))
	return [(name, startAudioSelectionPlus, "audioselectionplus",None)]


class AudioSelectionCheck(Screen):
	skin = """<screen position="center,center" size="400,300" title="Audio Selection Check" ></screen>"""
	def __init__(self,session):
		Screen.__init__(self,session)
		self.__event_tracker = ServiceEventTracker(screen=self, eventmap={
				iPlayableService.evStart: self.EventInfoChanged,
			})

	def EventInfoChanged(self):
		print "[AudioSelectionPlus] service info changed ..."
		if config.plugins.audioselectionplus.zapping.value > 0:
			print "[AudioSelectionPlus] scheduling checking ..."
			self.AudioSelectionTimer = eTimer()
			self.AudioSelectionTimer.stop()
			self.AudioSelectionTimer_conn= self.AudioSelectionTimer.timeout.connect(self.setAudioSelection)
			# after 1-10 sec all audio tracks should be there
			self.AudioSelectionTimer.start(config.plugins.audioselectionplus.zapping.value*1000,True)

	def setAudioSelection(self):
		print "[AudioSelectionPlus] checking audio tracks ..."
		self.AudioSelectionTimer.stop()
		streams = []
		numtracks=0
		service = self.session.nav.getCurrentService()
		if service:
			numtracks= service.audioTracks().getNumberOfTracks()
		print "[AudioSelectionPlus] found %d tracks ..." % numtracks
		if numtracks > 0:
			for x in range(numtracks):
				number = str(x + 1)
				i = service.audioTracks().getTrackInfo(x)
				languages = i.getLanguage().split('/')
				description = i.getDescription() or _("<unknown>")
				selected = ""
				language = ""
				cnt = 0
				for lang in languages:
					if cnt:
						language += ' / '
					if LanguageCodes.has_key(lang):
						language += LanguageCodes[lang][0]
					elif lang == "und":
						_("<unknown>")
					else:
						language += lang
					cnt += 1

				streams.append((x, "", number, description, language, selected))

			print "[AudioSelectionPlus] found streams %s" % streams
			track, running = AudioSelectionPlus.getPreferredTrackIndex(streams)

			if isinstance(track, int) and track > -1:
				print "[AudioSelectionPlus] setting track %d which is %s" % (track,streams[track])
				if numtracks == 1:
					print "[AudioSelectionPlus] only one Track found !!!"
				elif numtracks > track and not running:
					if not running:
						service.audioTracks().selectTrack(track)
						print "[AudioSelectionPlus] Track setting SUCCESSFULL !!!"
					else:
						print "[AudioSelectionPlus] Track already running !!!"
				else:
					print "[AudioSelectionPlus] Track settting FAILED !!!"
			else:
				print "[AudioSelectionPlus] found no preferred language"
