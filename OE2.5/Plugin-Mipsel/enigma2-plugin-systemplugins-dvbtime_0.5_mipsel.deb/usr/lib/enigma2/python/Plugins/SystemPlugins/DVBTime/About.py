from Screens.Screen import Screen
from Components.Sources.StaticText import StaticText
from Tools.Directories import *
import os
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ActionMap import ActionMap
from enigma import getDesktop
from os import environ as os_environ
import gettext
from Components.Language import language

def localeInit():
    lang = language.getLanguage()[:2]
    os_environ["LANGUAGE"] = lang
    print "[DVBTime] found LANGUAGE=", lang
    gettext.bindtextdomain("DVBTime", resolveFilename(SCOPE_PLUGINS, "SystemPlugins/DVBTime/locale"))

def _(txt):
    t = gettext.dgettext("DVBTime", txt)
    if t == txt:
        print "[DVBTime] fallback to default translation for", txt
        t = gettext.gettext(txt)
    return t

localeInit()
language.addCallback(localeInit)

class DVBTimeAbout(Screen):
    try:
        sz_w = getDesktop(0).size().width()
    except:
        sz_w = 720
    if sz_w == 1280:
        skin = """
        <screen name="DVBTimeAbout" position="center,center" title=" " size="1280,720" flags="wfNoBorder">
        <widget source="Title" render="Label" position="80,80" size="750,30" zPosition="3" font="Regular;26" transparent="1"/>
        <widget source="session.VideoPicture" render="Pig"  position="80,120" size="380,215" zPosition="3" backgroundColor="#ff000000"/>
        <widget source="version"              render="Label" position="550,150" size="700,50"  font="Regular;22" transparent="1" zPosition="1" halign="left" valign="center" />
        <widget source="author"               render="Label" position="600,210" size="700,50"  font="Regular;22" transparent="1" zPosition="1" halign="left" valign="center" />
        <widget source="license"              render="Label" position="650,275" size="550,50"  font="Regular;22" transparent="1" zPosition="1" halign="left" valign="center" />
        <widget source="translation"          render="Label" position="420,470" size="660,50"  font="Regular;22" transparent="1" zPosition="1" halign="left" valign="center" />
        <widget source="thanks"               render="Label" position="80,400"  size="1120,26" font="Regular;22" transparent="1" zPosition="1" halign="left" valign="center" /> 
        <ePixmap position="950,500" size="200,92" pixmap="%s" transparent="1" alphatest="blend" />
        <widget name="red" position="80,600" zPosition="1" size="15,16" pixmap="skin_default/buttons/button_red.png" transparent="1" alphatest="on" />
        <widget source="key_red" render="Label" position="100,596" zPosition="2" size="140,25" halign="left" font="Regular;22" transparent="1" />
        </screen>""" % ( resolveFilename(SCOPE_PLUGINS, "SystemPlugins/DVBTime/gp2.png" ))
    elif sz_w == 1024:
        skin = """
        <screen name="DVBTimeAbout" position="center,center" title=" " size="1024,576" flags="wfNoBorder">
        <widget source="Title" render="Label" position="80,80" size="750,30" zPosition="3" font="Regular;22" transparent="1"/>
        <widget source="session.VideoPicture" render="Pig"  position="80,120"  size="380,215" zPosition="3" backgroundColor="#ff000000"/>
        <widget source="version"     render="Label" position="500,120" size="700,50" font="Regular;20" transparent="1" zPosition="1" halign="left" valign="center" />
        <widget source="author"      render="Label" position="550,180" size="700,50" font="Regular;20" transparent="1" zPosition="1" halign="left" valign="center" />
        <widget source="license"     render="Label" position="600,245" size="550,50" font="Regular;22" transparent="1" zPosition="1" halign="left" valign="center" />
        <widget source="translation" render="Label" position="280,400" size="660,50" font="Regular;20" transparent="1" zPosition="1" halign="left" valign="center" />
        <widget source="thanks"      render="Label" position="80,500"  size="470,26" font="Regular;20" transparent="1" zPosition="1" halign="left" valign="center" />
        <ePixmap position="740,420" size="200,92" pixmap="%s" transparent="1" alphatest="blend" />
        <widget name="red" position="80,370" zPosition="1" size="15,16" pixmap="skin_default/buttons/button_red.png" transparent="1" alphatest="on" />
        <widget source="key_red" render="Label" position="100,366" zPosition="2" size="140,25" halign="left" font="Regular;20" transparent="1" />
        </screen>""" % ( resolveFilename(SCOPE_PLUGINS, "SystemPlugins/DVBTime/gp2.png" ))
    else:
        skin = """
        <screen name="DVBTimeAbout" position="center,center" size="560,400" title=" ">
        <ePixmap position="300,40" size="200,92" pixmap="%s" transparent="1" alphatest="blend" />
        <ePixmap pixmap="skin_default/buttons/red.png" zPosition="1" position="0,0" size="140,40" alphatest="on" />
        <widget source="key_red"     render="Label" position="0,0" zPosition="2" size="135,40" halign="center" valign="center" font="Regular;22" transparent="1" shadowColor="black" shadowOffset="-1,-1" /> 
        <widget source="version"     render="Label" position="10,70"   size="700,50" font="Regular;20" transparent="1" zPosition="1" halign="left" valign="center" />
        <widget source="author"      render="Label" position="40,130"  size="700,50" font="Regular;20" transparent="1" zPosition="1" halign="left" valign="center" />
        <widget source="license"     render="Label" position="70,190"  size="550,50" font="Regular;22" transparent="1" zPosition="1" halign="left" valign="center" />
        <widget source="translation" render="Label" position="5,270" size="660,50" font="Regular;20" transparent="1" zPosition="1" halign="left" valign="center" />
        <widget source="thanks"      render="Label" position="5,370"   size="470,26" font="Regular;20" transparent="1" zPosition="1" halign="left" valign="center" />
        </screen>""" % ( resolveFilename(SCOPE_PLUGINS, "SystemPlugins/DVBTime/gp2.png" ))

    def __init__(self, session):
        Screen.__init__(self, session)
        self["aboutActions"] = ActionMap(["ShortcutActions", "WizardActions", "InfobarEPGActions"],
        {
            "red": self.exit,
            "back": self.exit,
            "ok": self.exit,
        }, -1)
        self["version"] = StaticText(_("Version:\n") + '  0.4')
        self["author"] = StaticText(_("Developer:\n") + '  JackDaniel')
        self["translation"] = StaticText(_("Thanks for translation to:\n") + '  ES=titovich')
        self["thanks"] = StaticText(_("Thanks to gutemine for the help and the binarys"))
        self["license"] = StaticText(_("License:\n  GPLv3 or any later version"))
        self["key_red"] = StaticText(_("Close"))
        self["red"] = Pixmap()
        self.onLayoutFinish.append(self.setWindowTitle)

    def setWindowTitle(self):
        self.setTitle(_("About the DVBTime plugin"))

    def exit(self):
        self.close()