# -*- coding: utf-8 -*-
from gTools import cleanexit
from Screens.Screen import Screen
from Components.ActionMap import ActionMap

from os import system

class ShowMVI(Screen):
	def __init__(self, session, file):
		
		self.skin = "<screen position=\"0,0\" size=\"1,1\" flags=\"wfNoBorder\" ></screen>"
		Screen.__init__(self, session)

		self["actions"] = ActionMap(["gActions"],
		{
			"exit": self.KeyExit
		}, -1)
		
		self.mvi_active = self.session.nav.getCurrentlyPlayingServiceReference()
		self.session.nav.stopService()
		system("/usr/bin/showiframe '" + file + "'")
		
	def KeyExit(self):
		self.session.nav.playService(self.mvi_active)
		self.close()
		cleanexit(__name__)