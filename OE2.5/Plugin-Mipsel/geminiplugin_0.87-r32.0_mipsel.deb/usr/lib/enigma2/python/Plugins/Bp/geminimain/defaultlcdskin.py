# -*- coding: utf-8 -*-

lcdskin = """<screen name="%s" position="0,0" size="132,64" id="1">
		<widget source="global.CurrentTime" render="Label" position="6,2" size="120,60" font="GLCD;54" halign="center" valign="center" zPosition="1">
			<convert type="ClockToText">Format:%s</convert>
		</widget>
		<widget source="session.RecordState" render="FixedLabel" position="6,0" zPosition="2" size="120,64" text=" ">
			<convert type="ConfigEntryTest">config.usage.blinking_display_clock_during_recording,True,CheckSourceBoolean</convert>
			<convert type="ConditionalShowHide">Blink</convert>
		</widget>
	</screen>"""

lcdskinstandby = """<screen name="%s" position="0,0" size="132,64" id="1">
		<widget source="global.CurrentTime" render="Label" position="6,2" size="120,60" font="GLCD;54" halign="center" valign="center" zPosition="1">
			<convert type="ClockToText">Format:%s</convert>
		</widget>
		<eLabel position="4,0" size="124,64" backgroundColor="#00ffffff" />
		<widget source="session.RecordState" render="FixedLabel" position="6,0" zPosition="2" size="120,64" text=" ">
			<convert type="ConfigEntryTest">config.usage.blinking_display_clock_during_recording,True,CheckSourceBoolean</convert>
			<convert type="ConditionalShowHide">Blink</convert>
		</widget>
	</screen>"""
	
oledskin = """<screen name="%s" position="0,0" size="96,64" id="2">
		<widget source="global.CurrentTime" render="Label" position="2,2" size="92,60" font="GLCD;41" halign="center" valign="center" zPosition="1">
			<convert type="ClockToText">Format:%s</convert>
		</widget>
		<eLabel position="0,0" size="96,64" backgroundColor="#0000ff00" />
		<widget source="session.RecordState" render="FixedLabel" position="0,0" zPosition="2" size="96,64" text=" ">
			<convert type="ConfigEntryTest">config.usage.blinking_display_clock_during_recording,True,CheckSourceBoolean</convert>
			<convert type="ConditionalShowHide">Blink</convert>
		</widget>
	</screen>"""
	
oledskinstandby = """<screen name="%s" position="0,0" size="96,64" id="2">
		<widget source="global.CurrentTime" render="Label" position="2,2" size="92,60" font="GLCD;41" halign="center" valign="center" zPosition="1">
			<convert type="ClockToText">Format:%s</convert>
		</widget>
		<eLabel position="0,0" size="96,64" backgroundColor="#00ff0000" />
		<widget source="session.RecordState" render="FixedLabel" position="0,0" zPosition="2" size="96,64" text=" ">
			<convert type="ConfigEntryTest">config.usage.blinking_display_clock_during_recording,True,CheckSourceBoolean</convert>
			<convert type="ConditionalShowHide">Blink</convert>
		</widget>
	</screen>"""

dm900lcdskin = """<screen name="%s" position="0,0" size="400,240" id="3">
		<widget source="global.CurrentTime" render="Label" position="0,0" size="400,240" font="Display;160" halign="center" valign="center" transparent="1">
			<convert type="ClockToText">Format:%s</convert>
		</widget>
	</screen>"""
	
dm900lcdskinstandby = """<screen name="%s" position="0,0" size="400,240" id="3">
		<widget source="global.CurrentTime" render="Label" position="0,0" size="400,240" font="Display;160" halign="center" valign="center" transparent="1">
			<convert type="ClockToText">Format:%s</convert>
		</widget>
	</screen>"""