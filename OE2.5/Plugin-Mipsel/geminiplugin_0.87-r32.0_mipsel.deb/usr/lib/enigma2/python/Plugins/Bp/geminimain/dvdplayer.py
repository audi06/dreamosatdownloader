# -*- coding: utf-8 -*-
from Plugins.Extensions.DVDPlayer.plugin import DVDPlayer
from Components.ActionMap import ActionMap
	
class ExDVDPlayer(DVDPlayer):
	def __init__(self, session, dvd_device = None, dvd_filelist = [ ], args = None):
		DVDPlayer.__init__(self, session = session, dvd_device = dvd_device, dvd_filelist = dvd_filelist, args = args)
		self.skinName = "DVDPlayer"
		self["actions"] = ActionMap(["QuickButtonActions"],
		{
			"green_long":self.KeyGreenLong,
		},-1)
		
	def KeyGreenLong(self):
		from plugin import cgevent, InfoBarPlugins
		InfoBarPlugins.quickSelectGlobal(cgevent.InfobarInstance,"green_long")
