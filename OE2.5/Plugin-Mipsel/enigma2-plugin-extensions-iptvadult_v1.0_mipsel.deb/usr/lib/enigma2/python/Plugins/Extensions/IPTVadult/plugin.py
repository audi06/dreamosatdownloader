#!/usr/bin/python
# -*- coding: utf-8 -*-
from urllib2 import urlopen
from Components.MenuList import MenuList
from Components.Label import Label

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import NumberActionMap
from Components.Input import Input
from Components.Pixmap import Pixmap
from Components.FileList import FileList
from Screens.ChoiceBox import ChoiceBox
from Screens.InfoBarGenerics import *
from Screens.InfoBar import MoviePlayer, InfoBar
from Screens.Console import Console
from Components.ServiceEventTracker import ServiceEventTracker, InfoBarBase
from Plugins.Plugin import PluginDescriptor
from Components.ActionMap import ActionMap
from Components.Button import Button
from Components.SelectionList import SelectionList, SelectionEntryComponent
from Components.ScrollLabel import ScrollLabel
import Components.PluginComponent
from Screens.InputBox import InputBox

from twisted.web.client import getPage, downloadPage

import os, re
from Screens.InfoBar import MoviePlayer
from enigma import eServiceReference
from enigma import eServiceCenter
from enigma import getDesktop
from Plugins.Extensions.IPTVadult.lib.Utils import RSList, showlist


######################################################################
#                                                                    #
#   IPTVadult v.r0 : Coded by pcd@TDW, January 2016.   #
#   This is free software; you can redistribute it and/or modify it. #
#   However, you are politely requested to retain these 3 lines.     #
#                                                                    #
######################################################################

THISPLUG = "/usr/lib/enigma2/python/Plugins/Extensions/IPTVadult"
DESKHEIGHT = getDesktop(0).size().height()

class FullHD(Screen):
    skin = """
                <screen position="center,center" size="1056,831" title="IPTVadult" flags="wfNoBorder" backgroundColor="transparent">
                <eLabel position="center,center" zPosition="1" size="1050,825" backgroundColor="#000000" /> 
                <eLabel position="center,center" zPosition="-1" size="1056,831" backgroundColor="#ffffff" /> 

                        <eLabel text="IPTVadult" font="Regular;50" position="500,750" size="500,75" zPosition="4" halign="center"  foregroundColor="blue" backgroundColor="#000000" transparent="1"/> 

			<widget name="list" position="120,80" size="900,600" zPosition="4" scrollbarMode="showOnDemand" />
			<eLabel position="105,150" zPosition="-1" size="150,103" backgroundColor="#222222" />
			<widget name="info" position="75,712" zPosition="4" size="450,37" font="Regular;27" foregroundColor="#ffffff" transparent="1" halign="center" valign="center" />
		        <ePixmap name="red"    position="0,750"   zPosition="2" size="210,60" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
	                <ePixmap name="green"  position="210,750" zPosition="2" size="210,60" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
	                <!--ePixmap name="yellow" position="420,525" zPosition="2" size="210,60" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" /> 
	                <ePixmap name="blue"   position="630,525" zPosition="2" size="210,60" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" /--> 

	                <widget name="key_red" position="0,750" size="210,60" valign="center" halign="center" zPosition="4"  foregroundColor="#ffffff" font="Regular;30" transparent="1" shadowColor="#25062748" shadowOffset="-2,-2" /> 
	                <widget name="key_green" position="210,750" size="210,60" valign="center" halign="center" zPosition="4"  foregroundColor="#ffffff" font="Regular;30" transparent="1" shadowColor="#25062748" shadowOffset="-2,-2" /> 
	                <!--widget name="key_yellow" position="420,525" size="210,60" valign="center" halign="center" zPosition="4"  foregroundColor="#ffffff" font="Regular;30" transparent="1" shadowColor="#25062748" shadowOffset="-2,-2" />
	                <widget name="key_blue" position="630,525" size="210,60" valign="center" halign="center" zPosition="4"  foregroundColor="#ffffff" font="Regular;30" transparent="1" shadowColor="#25062748" shadowOffset="-2,-2" /-->
                </screen>"""


class HD(Screen):
    skin = """
		<screen position="center,center" size="704,554" title="IPTVadult" flags="wfNoBorder" backgroundColor="transparent">
                <eLabel position="center,center" zPosition="1" size="700,550" backgroundColor="#000000" /> 
                <eLabel position="center,center" zPosition="-1" size="704,554" backgroundColor="#ffffff" /> 

                        <eLabel text="IPTVadult" font="Regular;33" position="333,500" size="333,50" zPosition="4" halign="center"  foregroundColor="blue" backgroundColor="#000000" transparent="1"/> 

			<widget name="list" position="80,53" size="600,400" zPosition="4" scrollbarMode="showOnDemand" />
			<eLabel position="70,100" zPosition="-1" size="100,68" backgroundColor="#222222" />
			<widget name="info" position="50,474" zPosition="4" size="300,24" font="Regular;18" foregroundColor="#ffffff" transparent="1" halign="center" valign="center" />
		        <ePixmap name="red"    position="0,500"   zPosition="2" size="140,40" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
	                <ePixmap name="green"  position="140,500" zPosition="2" size="140,40" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
	                <!--ePixmap name="yellow" position="280,350" zPosition="2" size="140,40" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" /> 
	                <ePixmap name="blue"   position="420,350" zPosition="2" size="140,40" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" /--> 

	                <widget name="key_red" position="0,500" size="140,40" valign="center" halign="center" zPosition="4"  foregroundColor="#ffffff" font="Regular;20" transparent="1" shadowColor="#25062748" shadowOffset="-2,-2" /> 
	                <widget name="key_green" position="140,500" size="140,40" valign="center" halign="center" zPosition="4"  foregroundColor="#ffffff" font="Regular;20" transparent="1" shadowColor="#25062748" shadowOffset="-2,-2" /> 
	                <!--widget name="key_yellow" position="280,350" size="140,40" valign="center" halign="center" zPosition="4"  foregroundColor="#ffffff" font="Regular;20" transparent="1" shadowColor="#25062748" shadowOffset="-2,-2" />
	                <widget name="key_blue" position="420,350" size="140,40" valign="center" halign="center" zPosition="4"  foregroundColor="#ffffff" font="Regular;20" transparent="1" shadowColor="#25062748" shadowOffset="-2,-2" /-->
                </screen>"""

class IPTVadult(Screen):

    def __init__(self, session):
                if DESKHEIGHT > 1000:
		       self.skin = FullHD.skin
		else:
                       self.skin = HD.skin
		Screen.__init__(self, session)

#        	self["list"] = MenuList([])
        	#############################################                
		self.list = []                
#                self["list"] = List(self.list)
                self["list"] = RSList([])
                #############################################
		self["info"] = Label()
		self["key_red"] = Button(_("Exit"))
		self["key_green"] = Button(_("Select"))
                self["setupActions"] = ActionMap(["SetupActions", "ColorActions", "TimerEditActions"],
		{
			"red": self.close,
			"green": self.okClicked,
			"cancel": self.cancel,
			"ok": self.okClicked,
		}, -2)
                self.icount = 0
                self.srefOld = self.session.nav.getCurrentlyPlayingServiceReference()
                self.onLayoutFinish.append(self.openTest)

    def openTest(self):
           self.names = []
           file1 = THISPLUG + "/links18.txt"
           f1=open(file1,"r+")
           for line in f1.readlines():
                  name = line[:-1]
                  if name == "":
                         continue
                  self.names.append(name)
           self["info"].setText("")
           showlist(self.names, self["list"])
           

    def okClicked(self):
	        idx = self["list"].getSelectionIndex()
                name = self.names[idx]
                self.name = name
                if "User Playlists" in name:
                       plists = []
                       path1 = THISPLUG + "/playlists"
                       for plist in os.listdir(path1):
                               plists.append(plist)
                       self.session.open(Getlist2, plists)

#                elif "adult" in name.lower():
#                       self.allow()
                else:       
                  indic = 0
                  path = THISPLUG + "/plugins/"
                  for fname in os.listdir(path):
                       if name in fname:
                              indic = 1
                              break
                  if indic == 0:
                #################
                       dest = THISPLUG + "/plugins/" + name + ".pyo" 
                       xfile = "http://www.turk-dreamworld.com/bayraklar/Receiverler/Dreambox/TDW/e2/addons/IPTVworld/" + name + ".pyo" 
                       cmd = "wget -O '" + dest + "' '" + xfile + "' &"
                       title = _("Installing %s" %(name))
                       cmds = []
                       cmds.append(cmd)
                       self.session.openWithCallback(self.installed,Console,_(title),cmds)
                #################
                  else:
                
                       from Execlist18 import Execlist
                       sources = Execlist(self.session, name)
                       self.session.open(Getlist, sources)
                       
    def installed(self):                   
                       from Execlist18 import Execlist
                       sources = Execlist(self.session, self.name)
                       self.session.open(Getlist, sources)
                       
    def cancel(self):
#                self.session.nav.stopService()
#                self.session.nav.playService(self.srefOld)
                Screen.close(self, False)

    def makeList(self, plist):
           sources = []
           file1 = THISPLUG + "/playlists/" + plist
           f1=open(file1,"r+")
           fpage = f1.read()
           regexcat = 'EXTINF.*?,(.*?)\\n(.*?)\\n'
           match = re.compile(regexcat,re.DOTALL).findall(fpage)
           for name, url in match:
                  url = url.replace(" ", "")
                  url = url.replace("\\n", "")
                  line = name + "," + url
                  sources.append(line)
           return sources

    
    
                

    def keyLeft(self):
		self["text"].left()
	
    def keyRight(self):
		self["text"].right()
	
    def keyNumberGlobal(self, number):
		print "pressed", number
		self["text"].number(number)
                
    def allow(self):	        
                perm = config.ParentalControl.configured.value
                
                if config.ParentalControl.configured.value:
                        from Screens.InputBox import InputBox, PinInput
			self.session.openWithCallback(self.pinEntered, PinInput, pinList = [config.ParentalControl.setuppin.value], triesEntry = config.ParentalControl.retries.servicepin, title = _("Please enter the parental control pin code"), windowTitle = _("Enter pin code"))

		else:
                        self.pinEntered(True)
       
    def pinEntered(self, result):
                if result:
                       from Execlist import Execlist
                       sources = Execlist(self.session, self.name)
                       self.session.open(Getlist, sources)
		else:
			self.session.openWithCallback(self.close, MessageBox, _("The pin code you entered is wrong."), MessageBox.TYPE_ERROR)
         		self.close()
	        

class Getlist(Screen):
    def __init__(self, session, sources=[]):
		if DESKHEIGHT > 1000:
		       self.skin = FullHD.skin
		else:
                       self.skin = HD.skin

		Screen.__init__(self, session)

#        	self["list"] = MenuList([])
                #############################################                
		self.list = []                
#                self["list"] = List(self.list)
                self["list"] = RSList([])
                #############################################
		self["info"] = Label()
		self["key_red"] = Button(_("Exit"))
		self["key_green"] = Button(_("Select"))
                self["setupActions"] = ActionMap(["SetupActions", "ColorActions", "TimerEditActions"],
		{
			"red": self.close,
			"green": self.okClicked,
			"cancel": self.cancel,
			"ok": self.okClicked,
		}, -2)
                self.icount = 0
                self.sources = sources
                self.srefOld = self.session.nav.getCurrentlyPlayingServiceReference()
                self.onLayoutFinish.append(self.openTest)

    def openTest(self):
           self["info"].setText("Downloading list...")

           self.names = []
           self.urls = []
           for line in self.sources:
                  s = line.split(",")
                  self.names.append(s[0])
                  self.urls.append(s[1])
           self["info"].setText("")
           showlist(self.names, self["list"])


    def okClicked(self):
	        ientry = self["list"].getSelectionIndex()
                url = self.urls[ientry]
                name = self.names[ientry]
                self.name = name
                self.url = url
                self.play()
           
    def play(self):
               desc = " "
               url = self.url
               print "In play url =", url
               name = self.name
               if "m3u8" in url:
                            try:os.remove("/tmp/hls.avi")
                            except:pass                          
                            cmd = 'python "/usr/lib/enigma2/python/Plugins/Extensions/IPTVadult/lib/hlsclient.py" "' + url + '" "1" &'
                            os.system(cmd)
                            os.system('sleep 3')
                            url = '/tmp/hls.avi'
               self.session.open(Playstream, name, url)


    def cancel(self):
#                self.session.nav.stopService()
#                self.session.nav.playService(self.srefOld)
                Screen.close(self, False)

                

    def keyLeft(self):
		self["text"].left()
	
    def keyRight(self):
		self["text"].right()
	
    def keyNumberGlobal(self, number):
		print "pressed", number
		self["text"].number(number)
                
    def allow(self):	        
                perm = config.ParentalControl.configured.value
                
                if config.ParentalControl.configured.value:
                        from Screens.InputBox import InputBox, PinInput
			self.session.openWithCallback(self.pinEntered, PinInput, pinList = [config.ParentalControl.setuppin.value], triesEntry = config.ParentalControl.retries.servicepin, title = _("Please enter the parental control pin code"), windowTitle = _("Enter pin code"))

		else:
                        self.pinEntered(True)
       
    def pinEntered(self, result):
                if result:
                        self.session.open(Getlist, self.name, self.url)
                        self.close()
		else:
			self.session.openWithCallback(self.close, MessageBox, _("The pin code you entered is wrong."), MessageBox.TYPE_ERROR)
         		self.close()
                		
		
class Getlist2(Screen):

    def __init__(self, session, plists):
		if DESKHEIGHT > 1000:
		       self.skin = FullHD.skin
		else:
                       self.skin = HD.skin
		Screen.__init__(self, session)

#        	self["list"] = MenuList([])
                #############################################                
		self.list = []                
#                self["list"] = List(self.list)
                self["list"] = RSList([])
                #############################################
		self["info"] = Label()
		self["key_red"] = Button(_("Exit"))
		self["key_green"] = Button(_("Select"))
                self["setupActions"] = ActionMap(["SetupActions", "ColorActions", "TimerEditActions"],
		{
			"red": self.close,
			"green": self.okClicked,
			"cancel": self.cancel,
			"ok": self.okClicked,
		}, -2)
                self.plists = plists
                self.srefOld = self.session.nav.getCurrentlyPlayingServiceReference()
                self.onLayoutFinish.append(self.openTest)

    def openTest(self):
          
           self["info"].setText(" ")
#           self["list"].setList(self.plists)
           showlist(self.plists, self["list"])

    def okClicked(self):
	        ientry = self["list"].getSelectionIndex()
                plist = self.plists[ientry]
                sources = self.makeList(plist)
                self.session.open(Getlist, sources)

    def makeList(self, plist):
           sources = []
           file1 = THISPLUG + "/playlists/" + plist
           f1=open(file1,"r+")
           fpage = f1.read()
           regexcat = 'EXTINF.*?,(.*?)\\n(.*?)\\n'
           match = re.compile(regexcat,re.DOTALL).findall(fpage)
           for name, url in match:
                  url = url.replace(" ", "")
                  url = url.replace("\\n", "")
                  line = name + "," + url
                  sources.append(line)
           return sources

            
                
                
            
    def playX(self):
               desc = " "
               url = self.url
               name = self.name
               if "m3u8" in url:
                            try:os.remove("/tmp/hls.avi")
                            except:pass                          
                            cmd = 'python "/usr/lib/enigma2/python/Plugins/Extensions/IPTVadult/lib/hlsclient.py" "' + url + '" "1" &'
                            os.system(cmd)
                            os.system('sleep 3')
                            url = '/tmp/hls.avi'
               self.session.open(Playstream, name, url)

    def cancel(self):
                Screen.close(self, False)

                

    def keyLeft(self):
		self["text"].left()
	
    def keyRight(self):
		self["text"].right()
	
    def keyNumberGlobal(self, number):
		print "pressed", number
		self["text"].number(number)		
        
           		
class Playstream(Screen, InfoBarMenu, InfoBarBase, InfoBarSeek, InfoBarNotifications, InfoBarShowHide):
    
    def __init__(self, session, name, url):
		
		Screen.__init__(self, session)
                self.skinName = "MoviePlayer"
		title = "Play"
        	self["list"] = MenuList([])
		InfoBarMenu.__init__(self)
		InfoBarNotifications.__init__(self)
		InfoBarBase.__init__(self)
		InfoBarShowHide.__init__(self)
		self["actions"] = ActionMap(["WizardActions", "MoviePlayerActions", "EPGSelectActions", "MediaPlayerSeekActions", "ColorActions", "InfobarShowHideActions", "InfobarActions"],
		{
			"leavePlayer":		        self.cancel,
			"back":				self.cancel,
		}, -1)

		self.allowPiP = False
		InfoBarSeek.__init__(self, actionmap = "MediaPlayerSeekActions")
		url = url.replace(":", "%3a")
                self.url = url
                self.name = name
                self.srefOld = self.session.nav.getCurrentlyPlayingServiceReference()
                self.onLayoutFinish.append(self.openTest)

    def openTest(self):                
                url = self.url
                ref = "4097:0:1:0:0:0:0:0:0:0:" + url
                sref = eServiceReference(ref)
		sref.setName(self.name)
		self.session.nav.stopService()
		self.session.nav.playService(sref)
           

    def cancel(self):
                if os.path.exists("/tmp/hls.avi"):
                       os.remove("/tmp/hls.avi")
                self.session.nav.stopService()
                self.session.nav.playService(self.srefOld)
                self.close()

    def keyLeft(self):
		self["text"].left()
	
    def keyRight(self):
		self["text"].right()
	
    def keyNumberGlobal(self, number):
		self["text"].number(number)	

def main(session, **kwargs):
        #################
        dest = THISPLUG + "/Execlist18.pyo"
        xfile = "http://www.turk-dreamworld.com/bayraklar/Receiverler/Dreambox/TDW/e2/addons/IPTVworld/Execlist18.pyo" 
        cmd = "wget -O '" + dest + "' '" + xfile + "' &" 
        os.system(cmd)                                                
        #################
        dest = THISPLUG + "/links18.txt"
        xfile = "http://www.turk-dreamworld.com/bayraklar/Receiverler/Dreambox/TDW/e2/addons/IPTVworld/links18.txt" 
        cmd = "wget -O '" + dest + "' '" + xfile + "' &"                                                 
        os.system(cmd)
        #################

        session.open(IPTVadult)
		

def Plugins(**kwargs):
	return PluginDescriptor(name="IPTVadult", description="IPTV adult(18+)stream player", where = PluginDescriptor.WHERE_PLUGINMENU, fnc=main)
