#!/bin/sh
#####################################################
###############     <<LokumTEAM>>    ################
#####################################################
CAM="OSCamYmod_v18-56"
OSD="OSCamYmod_v18-56"
PID=`pidof $CAM`
Action=$1

cam_clean () {
	rm -rf /tmp/ecm.info /tmp/script.info /tmp/pid.info /tmp/cardinfo /tmp/cam.info /tmp/debug.txt /tmp/ecm0.info /tmp/mbox.ver /tmp/newcs.pid /tmp/share.info /tmp/share.onl /tmp/stat.info
}

cam_handle () {
		if test	-z "${PID}"	; then
				cam_up;
		else
				cam_down;
		fi;
}

cam_down ()	{
		killall	-9 $CAM
		sleep 2
		cam_clean
}

cam_up () {
		/usr/bin/$CAM -c /etc/tuxbox/config/oscamymod/ &
}

if test	"$Action" =	"cam_startup" ;	then
	if test	-z "${PID}" ; then
		cam_down
		cam_up
	else
		echo "$CAM already running, exiting..."
	fi
elif test	"$Action" =	"cam_res" ;	then
		cam_down
		cam_up
elif test "$Action"	= "cam_down" ; then
		cam_down
elif test "$Action"	= "cam_up" ; then
		cam_up
else
		cam_handle
fi

exit 0
