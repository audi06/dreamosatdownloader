#!/bin/sh
Action=$1
OSD=" SCam_3.60 "

cam_clean () {
	rm -rf /tmp/*.info /tmp/CCcam.kill /tmp/camd.socket /tmp/cardinfo /tmp/cainfo.socket /tmp/mmi.socket
}

cam_up () {
	cam_clean
	sleep 2
        /usr/bin/SCam_3.60 -k /usr/keys -s /etc/ &
	sleep 16
	/usr/bin/scamecminfo -start
}

cam_down() {
#	touch /tmp/CCcam.kill
	sleep 4
	scamecminfo -stop
        killall -9 SCam_3.60
	sleep 2
	cam_clean
}

if test "$Action" = "cam_up" ; then
	cam_up
elif test "$Action" = "cam_down" ; then
	cam_down
elif test "$Action" = "cam_res" ; then	
	cam_down
	cam_up
fi
exit 0
