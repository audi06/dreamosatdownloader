#!/bin/sh
#
# Script is part of the ConfigManager plugin
# This script is responsible to replace the settings file with the new settings file upon (re)boot
#
if [ -e /etc/enigma2/settings.new ] ; then
echo "[ConfigManager] - replacing settings"
rm /etc/enigma2/settings && mv /etc/enigma2/settings.new /etc/enigma2/settings
else
echo "[ConfigManager] - nothing to replace"
fi

exit 0