# -*- coding: utf-8 -*-
#
#  ConfigManager
#
# Coded by dre (c) 2014 - 2015
# Support: www.dreambox-tools.info
# E-Mail: dre@dreambox-tools.info
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Multimedia GmbH.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Multimedia GmbH.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Multimedia GmbH.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.

from Components.config import config, ConfigSubsection, ConfigSelection, ConfigYesNo, configfile, getConfigListEntry
from Components.ActionMap import *
from Components.ConfigList import ConfigListScreen
from Components.Label import Label
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
from Components.Pixmap import Pixmap
from Plugins.Plugin import PluginDescriptor
from Screens.HelpMenu import HelpableScreen
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.Standby import TryQuitMainloop
from Tools.Directories import fileExists, resolveFilename, SCOPE_CURRENT_SKIN
from Tools.LoadPixmap import LoadPixmap
from enigma import RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_VALIGN_CENTER, eListboxPythonMultiContent, gFont, eConsoleAppContainer
from skin import TemplatedListFonts, componentSizes
import os, re

# for localized messages
from . import _

config.plugins.configmanager = ConfigSubsection()
config.plugins.configmanager.backuppath = ConfigSelection([("/media/hdd", "/media/hdd"), ("/media/usb", "/media/usb"), ("/media/cf", "/media/cf")], default = "/media/hdd")
config.plugins.configmanager.rememberselection = ConfigYesNo(default=False)

def main(session,**kwargs):
	#check for first run
	#if not fileExists("/usr/lib/enigma2/python/Plugins/Extensions/ConfigManager/.firstrundone"):
		#os.system("touch /usr/lib/enigma2/python/Plugins/Extensions/ConfigManager/.firstrundone")
		#os.system("update-rc.d configmanager start 10 3 .")
	session.open(ConfigViewerScreen)

class ConfigMenuList(MenuList):
	SKIN_COMPONENT_KEY = "ConfigManagerList"
	SKIN_COMPONENT_ICON_HEIGHT = "iconHeight"
	SKIN_COMPONENT_ICON_WIDTH = "iconWidth"
	
	def __init__(self, list):
		MenuList.__init__(self, list, False, eListboxPythonMultiContent)
		self.l.setItemHeight(componentSizes.itemHeight(self.SKIN_COMPONENT_KEY, 25))
		tlf = TemplatedListFonts()
		self.l.setFont(0, gFont(tlf.face(tlf.SMALL), tlf.size(tlf.SMALL)))
		
def ConfigMenuListEntry(entry, value, selected = False):
	sizes = componentSizes[ConfigMenuList.SKIN_COMPONENT_KEY]
	iconWidth = sizes.get(ConfigMenuList.SKIN_COMPONENT_ICON_WIDTH, 25)
	iconHeight = sizes.get(ConfigMenuList.SKIN_COMPONENT_ICON_HEIGHT, 25)
	configEntryWidth = sizes.get(componentSizes.ITEM_WIDTH, 695)
	configEntryHeight = sizes.get(componentSizes.ITEM_HEIGHT, 25)

	res = [ (entry, value, selected) ]
	if selected is False:
		icon = LoadPixmap(cached=True, path=resolveFilename(SCOPE_CURRENT_SKIN, "skin_default/icons/lock_off.png"))
	else:
		icon = LoadPixmap(cached=True, path=resolveFilename(SCOPE_CURRENT_SKIN, "skin_default/icons/lock_on.png"))
	res.append(MultiContentEntryPixmapAlphaTest(pos=(0,0), size=(iconWidth,iconHeight), png = icon))
	res.append(MultiContentEntryText(pos=(iconWidth,0),size=(configEntryWidth, configEntryHeight), font=0, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=entry))
	res.append(MultiContentEntryText(text=value))
	return res
	
class CMPluginConfigScreen(Screen, ConfigListScreen, HelpableScreen):
	skin = """
		<screen position="center,center" size="500,140" title="Plugin Config" >
			<ePixmap pixmap="skin_default/buttons/green.png" position="10,5" size="360,40" alphatest="on" />
	    	<widget name="SaveText" position="10,5" size="360,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#1f771f" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
	    	<eLabel	position="10,50" size="480,1" backgroundColor="grey"/>
	    	<widget name="config" position="10,60" enableWrapAround="1" size="480,60"/>
		</screen>"""		
		
	def __init__(self, session, args = 0):
		self.skin = CMPluginConfigScreen.skin
		self.session = session
		Screen.__init__(self, session)
		HelpableScreen.__init__(self)
		
		self.list = []
		
		self["OkCancelActions"] = HelpableActionMap(self, "OkCancelActions",
		{
			"cancel":	(self.close, _("Close")),
		}, -1)
		
		self["ColorActions"] = HelpableActionMap(self, "ColorActions",
		{
			"green":	(self.saveConfig, _("Save config")),
		}, -1)
		
		self["SaveText"] = Label(_("Save config and close"))
		
		ConfigListScreen.__init__(self, self.list)
		
		self.list.append(getConfigListEntry(_("Back up path:"), config.plugins.configmanager.backuppath))
		self.list.append(getConfigListEntry(_("Save last selection to config:"), config.plugins.configmanager.rememberselection))
		self["config"].setList(self.list)
		
	def saveConfig(self):
		for x in self.list:
			x[1].save()
		self.close()

class CleanUpWizardScreen(Screen, HelpableScreen):

	skin = """
		<screen position="center,120" size="620,520" title="Clean Up Wizard" >
		    <widget name="ButtonRed" pixmap="skin_default/buttons/red.png" position="10,5" size="360,40" alphatest="on" />
	    	<widget name="ButtonRedText" position="10,5" size="360,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#9f1313" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
	    	<eLabel	position="10,50" size="600,1" backgroundColor="grey"/>
			<widget name="FoundConfigDescr" position="10,57" size="480,25" halign="left" font="Regular;18" />
			<widget name="FoundConfig" position="500,57" size="100,25" halign="left" font="Regular;18" />
			<widget name="LeftBehindDescr" position="10,83" size="480,25" halign="left" font="Regular;18" />
			<widget name="LeftBehind" position="500,83" size="100,25" halign="left" font="Regular;18" />	
			<eLabel	position="10,110" size="600,1" backgroundColor="grey"/>
	    	<widget name="menulist" position="10,120" enableWrapAround="1" size="600,390"/>
		</screen>"""
		
	def __init__(self, session, pluginConfigEntries):
		self.skin = CleanUpWizardScreen.skin
		self.session = session
		self.pluginConfigEntries = pluginConfigEntries
		Screen.__init__(self, session)
		HelpableScreen.__init__(self)
		
		self["OkCancelActions"] = HelpableActionMap(self, "OkCancelActions",
		{
			"ok":		(self.selectForRemoval, _("Select entry for removal")),
			"cancel":	(self.close, _("Close screen")),
		}, -1)
		
		self["ColorActions"] = HelpableActionMap(self, "ColorActions",
		{
			"red":		(self.removeSelectedEntries, _("Remove selected entries")),
		}, -1)
		
		self.menulist = []
		self.pluginConfigList = []
		self["menulist"] = ConfigMenuList([])
		
		self.selectedEntries = []
		
		self["FoundConfig"] = Label()
		self["FoundConfigDescr"] = Label(_("Config entries found:"))
		
		self["LeftBehind"] = Label()
		self["LeftBehindDescr"] = Label(_("Config entries left behind:"))
		
		self["ButtonRed"] = Pixmap()
		self["ButtonRedText"] = Label(_("Remove selected entries"))
		
		self.foundConfig = "0"
		self.leftBehind = "0"
		
		self["FoundConfig"].setText(self.foundConfig)
		self["LeftBehind"].setText(self.leftBehind)
		
		self.dirlist = ["/usr/lib/enigma2/python/Plugins/Extensions", "/usr/lib/enigma2/python/Plugins/SystemPlugins"]
		
		self.subdirlist = []
		self.subdirlist = self.getSubDirectories(self.dirlist)
		
		for i in range(len(self.subdirlist)):
			for p in range(len(self.subdirlist[i])):
				path = self.dirlist[i] + "/" + self.subdirlist[i][p]
				pyfiles = self.getpyFiles(path)
				for j in range(len(pyfiles)):
					self.content = ""
					checkFile = open(path + "/" + pyfiles[j], "r")
					self.content = checkFile.read()
					checkFile.close()
					configentries = re .findall("config\.(.*?)[\b|\=]", self.content)
					if len(configentries) > 0:
						for k in range(len(configentries)):
							if configentries[k].find(".value") == -1 and configentries[k].find(".addNotifier") == -1 and configentries[k].find("getValue") == -1 and configentries[k].find(".save()") == -1 and configentries[k].find(".index >") == -1:
								self.pluginConfigList.append("config." + configentries[k].strip())

		self.foundConfig = len(self.pluginConfigList)
		self["FoundConfig"].setText(str(self.foundConfig))
			
		for c in self.pluginConfigEntries:
			if c not in self.pluginConfigList:
				sublistFound = False
				sublistcheck = ""
				sublistcheck = re.findall("config\.plugins\.(.*?)\.([0-9])\.(.*?)$", c)
				#a sublistcheck length greater than 0 means we have a ConfigSubList
				if len(sublistcheck) > 0:
					for e in range(len(self.pluginConfigList)):
						sublistFound = False
						pos = self.pluginConfigList[e].find("[")
						if pos != -1:
							closepos = self.pluginConfigList[e].find("]")
							modEntry = "%s.%d%s" %(self.pluginConfigList[e][:pos], int(sublistcheck[0][1]), self.pluginConfigList[e][closepos+1:])
							if c == modEntry:
								sublistFound = True
								break
				if sublistFound == False:
					self.menulist.append(ConfigMenuListEntry(c, None, selected = False))
		self.differenceList = []
		self.differenceList = self.menulist
		self["menulist"].l.setList(self.menulist)
		
		self.leftBehind = len(self.menulist)
		self["LeftBehind"].setText(str(self.leftBehind))
		if self.leftBehind == 0:
			self["ButtonRed"].hide()
			self["ButtonRedText"].hide()
		
	def getSubDirectories(self, dir):
		return [ [subdirectory for subdirectory in os.listdir(directory) if os.path.isdir(os.path.join(directory,subdirectory))] for directory in dir ]

	def getpyFiles(self, path):
		return [ pyfile for pyfile in os.listdir(path)
					if os.path.isfile(os.path.join(path, pyfile)) and pyfile.endswith(".py")]
					
	def removeSelectedEntries(self):
		if fileExists("/etc/enigma2/settings"):
			try:
				origFile = open('/etc/enigma2/settings', 'r')
				self.settingsList = []
				self.settingsList = origFile.readlines()
				
				for i in range(len(self.selectedEntries)):
					for k in range(len(self.settingsList)):
						entrysplit = self.settingsList[k].split('=')
						if entrysplit[0] == self.selectedEntries[i]:
							#a dirty hack
							self.settingsList[k] = "#"
							break
				
				origFile.close()
				
				os.system("touch /etc/enigma2/settings.new")
				os.system("chmod 644 /etc/enigma2/setttings.new")
				configFile = open('/etc/enigma2/settings.new', 'w')	
				for j in range(len(self.settingsList)):
					if self.settingsList[j] != "#":
						configFile.write(self.settingsList[j])
				configFile.close()

				self.doRestart()			
				
			except IOError:
				print "couldn't read settings"
				
	def selectForRemoval(self):
		if len(self.menulist) > 0:
			selectedMenuEntry = self["menulist"].getSelectedIndex()
			if self.menulist[selectedMenuEntry][0][2] == False:
				self.selectedEntries.append(self.menulist[selectedMenuEntry][0][0])
			else:
				for k in range(len(self.selectedEntries)):
					if self.selectedEntries[k] == self.menulist[selectedMenuEntry][0][0]:
						del self.selectedEntries[k]
						break
			self.updateList(jumpToFirst=False)
		
	def updateList(self, jumpToFirst=True):
		self.menulist = []
		self.alreadyAdded = False
	
		for i in range(len(self.differenceList)):
			self.markSelectedEntries(i)

		self["menulist"].l.setList(self.menulist)
		if jumpToFirst:
			self["menulist"].moveToIndex(0)
			
	def markSelectedEntries(self, index):
		self.index = index
		self.alreadyAdded = False
		for j in range(len(self.selectedEntries)):
			if self.differenceList[self.index][0][0] == self.selectedEntries[j]:
				self.menulist.append(ConfigMenuListEntry(self.differenceList[self.index][0][0], None, selected = True))
				self.alreadyAdded = True
				break
		if self.alreadyAdded == False:
			self.menulist.append(ConfigMenuListEntry(self.differenceList[self.index][0][0], None))
		else:
			self.alreadyAdded = False
			
	def doRestart(self):
		restartbox = self.session.openWithCallback(self.restartBox,MessageBox,_("A reboot is required to load settings\nDo you want to reboot the Dreambox now?"), MessageBox.TYPE_YESNO)
		restartbox.setTitle(_("Reboot Dreambox now?"))
		
	def restartBox(self,answer):
		if answer is True:
			self.session.open(TryQuitMainloop, 2)			
	
class RestoreSelectionScreen(Screen):

	skin = """
		<screen position="center,center" size="520,80" title="Config Manager" >
			<widget name="restoreselectionlist" position="10,10" enableWrapAround="1" size="500,60" scrollbarMode="showOnDemand" />
		</screen>"""			
	
	def __init__(self, session):
		self.skin = RestoreSelectionScreen.skin
		self.session = session
		Screen.__init__(self, session)
		
		self["OkCancelActions"] = HelpableActionMap(self, "OkCancelActions",
		{
			"ok":		(self.runCommand, _("Run selected task")),
			"cancel":	(self.close, _("Close screen")),
		}, -1)
		
		self.entries = []
		self.backupdir = ""
		self.backupdir = config.plugins.configmanager.backuppath.value
		if fileExists("%s/settings.tar.gz" %(self.backupdir)):
			self.entries.append( (_("Restore settings"), 0))
			self.entries.append( (_("Merge back up into settings"), 1))

		self["restoreselectionlist"] = MenuList(self.entries)
		
	def runCommand(self):
		menuitem = self["restoreselectionlist"].getCurrent()[1]
		#restore settings
		if menuitem == 0:
			self.result = os.system("tar -xzf %s/settings.tar.gz -C /etc/enigma2/" %(self.backupdir))		
			if (int(self.result)/256)==0:
				self.doRestart()
		#merge back up	
		elif menuitem == 1:
			self.result = os.system("tar -xzf %s/settings.tar.gz -C /tmp/" %(self.backupdir))
			if (int(self.result)/256)==0:
				self.doMerge()
		
	def doMerge(self):
		self.writeFile = False
		if fileExists("/etc/enigma2/settings") and fileExists("/tmp/settings.new"):
			try:
				buf = []
				backUpFile = open('/tmp/settings.new', 'r')
				mergeList = backUpFile.readlines()
				configFile = open('/etc/enigma2/settings', 'r')
				self.writeFile = True

				for line in configFile:
					for l in range(len(mergeList)):
						if mergeList[l] != '#' and mergeList[l] != '\n':
							backupsplit = mergeList[l].split('=')
							if line.startswith(backupsplit[0]):
								line = line.replace(line, mergeList[l])
								#kinda remove the line to be able to add all lines that are not in configFile
								mergeList[l] = "#"
								break
					buf.append(line)
					
				#this is needed to add lines that are not present in configFile
				for k in range(len(mergeList)):
					if mergeList[k] != '#' and mergeList[k] != '\n':
						buf.append(mergeList[k])
								
			except IOError:
				print "couldn't read settings"
			backUpFile.close()
			configFile.close()
			
			if self.writeFile:
				os.system("touch /etc/enigma2/settings.new")
				os.system("chmod 644 /etc/enigma2/setttings.new")
				configFile = open('/etc/enigma2/settings.new', 'w')	
				for line in buf:
					configFile.write(line)
				configFile.close()
		
				self.doRestart()
	
	def doRestart(self):
		restartbox = self.session.openWithCallback(self.restartBox,MessageBox,_("A reboot is required to load settings\nDo you want to reboot the Dreambox now?"), MessageBox.TYPE_YESNO)
		restartbox.setTitle(_("Reboot Dreambox now?"))
		
	def restartBox(self,answer):
		if answer is True:
			self.session.open(TryQuitMainloop, 2)				

class ConfigBackUpScreen(Screen,HelpableScreen):

		
	skin = """
		<screen position="center,center" size="620,520" title="Config Manager - Back Up">
		    <widget name="ButtonRed" pixmap="skin_default/buttons/red.png" position="10,5" size="200,40" alphatest="on" />
	    	<widget name="ButtonRedText" position="10,5" size="200,40" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#9f1313" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
	    	<eLabel	position="10,50" size="600,1" backgroundColor="grey"/>
			<widget name="progresstext" position="10,55" size="600,25" halign="left" font="Regular;18" />	
			<eLabel	position="10,80" size="600,1" backgroundColor="grey"/>
	    	<widget name="backedUp" position="10,90" enableWrapAround="1" size="600,420"/>
		</screen>"""
	
	def __init__(self, session, selection):
		self.skin = ConfigBackUpScreen.skin
		self.session = session
		Screen.__init__(self, session)
		HelpableScreen.__init__(self)
		
		self["OkCancelActions"] = HelpableActionMap(self, "OkCancelActions",
		{
			"cancel":	(self.closeAndClean, _("Close screen")),
		}, -1)

		self["ColorActions"] = HelpableActionMap(self, "ColorActions",
		{
			"red":		(self.close, _("Close screen")),
		}, -1)
		
		self["ButtonRed"] = Pixmap()
		self["ButtonRedText"] = Label(_("Close"))	
		
		self.selection = selection
		self.backedUpList = []
		self["backedUp"] = MenuList(self.backedUpList)
		
		total = len(self.selection)
		
		self["progresstext"] = Label(_("0/%s backed up") %(total))
		
		counter = 0
		if fileExists("/etc/enigma2/settings"):
			try:
				configFile = open('/etc/enigma2/settings', 'r')
				for i in range(len(self.selection)):
					for line in configFile:
						if line.startswith(self.selection[i]):
							counter = counter+1
							self["progresstext"].setText(_("%s/%s backed up") %(counter, total))
							self.backedUpList.append(line)
							self["backedUp"].l.setList(self.backedUpList)
							break
				os.system("touch /tmp/settings.new")
				os.system("chmod 644 /tmp/setttings.new")
				
				backUpFile = open('/tmp/settings.new', 'w')	
				for k in range(len(self.backedUpList)):
					backUpFile.write(self.backedUpList[k])
				backUpFile.close()
				
				self.backupdir = ""
				self.backupdir = config.plugins.configmanager.backuppath.value
				os.system("tar -zcf %s/settings.tar.gz -C /tmp settings.new" %(self.backupdir))
				
			except IOError:
				print "couldn't read settings"
			configFile.close()
			
	def closeAndClean(self):
		os.system("rm -f /tmp/settings.new")
		self.close()
		
class ConfigViewerScreen(Screen,HelpableScreen):

	skin = """
		<screen position="center,90" size="820,600" title="Config Manager" >
		    <widget name="ButtonRed" pixmap="skin_default/buttons/red.png" position="10,5" size="200,65" alphatest="on" />
    		<widget name="ButtonGreen" pixmap="skin_default/buttons/green.png" position="210,5" size="200,65" alphatest="on" />
	    	<widget name="ButtonYellow" pixmap="skin_default/buttons/yellow.png" position="410,5" size="200,65" alphatest="on" />
	     	<widget name="ButtonBlue" pixmap="skin_default/buttons/blue.png" position="610,5" size="200,65" alphatest="on" />
	    	<widget name="ButtonRedText" position="10,5" size="200,65" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#9f1313" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
	    	<widget name="ButtonGreenText" position="210,5" size="200,65" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#1f771f" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
    		<widget name="ButtonYellowText" position="410,5" size="200,65" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#a08500" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
	    	<widget name="ButtonBlueText" position="610,5" size="200,65" zPosition="1" font="Regular;20" halign="center" valign="center" backgroundColor="#18188b" transparent="1" shadowColor="black" shadowOffset="-2,-2" />
	    	<eLabel position="10,75" size="800,1" backgroundColor="grey" />
	    	<widget name="menulist" position="10,80" size="800,325" enableWrapAround="1" scrollbarMode="showOnDemand" />
	    	<eLabel position="10,410" size="800,1" backgroundColor="grey" />
	    	<eLabel position="550,415" size="1,180" backgroundColor="grey" />
	    	<widget name="entryinfo" position="10,415" size="540,120" font="Regular;20" halign="center" valign="center" />
			<ePixmap alphatest="on" pixmap="skin_default/buttons/key_0.png" position="560,420" size="40,20"/>
			<widget name="allEntries" font="Regular;18" position="620,420" size="200,25" transparent="1"/>
			<ePixmap alphatest="on" pixmap="skin_default/buttons/key_1.png" position="560,450" size="40,20"/>
			<widget name="plugEntries" font="Regular;18" position="620,450" size="200,25" transparent="1"/>
			<ePixmap alphatest="on" pixmap="skin_default/buttons/key_2.png" position="560,480" size="40,20"/>
			<widget name="enigmaEntries" font="Regular;18" position="620,480" size="200,25" transparent="1"/>
			<widget name="key3" pixmap="skin_default/buttons/key_3.png" position="560,510" size="35,25" alphatest="on"/>
			<!--ePixmap alphatest="on" pixmap="skin_default/buttons/key_3.png" position="560,510" size="40,20"/-->
			<widget name="merlinEntries" font="Regular;18" position="620,510" size="200,25" transparent="1"/>
			<widget name="selectAll" font="Regular;18" position="620,540" size="200,25" transparent="1"/>
			<ePixmap alphatest="on" pixmap="skin_default/buttons/key_7.png" position="560,540" size="40,20"/>	
			<widget name="deselectAll" font="Regular;18" position="620,570" size="200,25" transparent="1"/>
			<ePixmap alphatest="on" pixmap="skin_default/buttons/key_9.png" position="560,570" size="40,20"/>						
		</screen>"""		
		
	def __init__(self, session, args = 0):
		self.skin = ConfigViewerScreen.skin
		self.session = session
		Screen.__init__(self, session)
		HelpableScreen.__init__(self)

		self["NumberActions"] = HelpableActionMap(self, "NumberActions",
		{
			"0":		(self.updateList, _("Show complete config")),
			"1":		(self.showPluginConfigOnly, _("Show plugin config only")),
			"2":		(self.showEnigmaConfigOnly, _("Show Enigma2 config only")),
			"3":		(self.showMerlinConfigOnly, _("Show Merlin3 config only")),
			"7":		(self.selectAll, _("Select all entries")),
			"9":		(self.deselectAll, _("Deselect all entries")),
		}, -1)
		
		self["ColorActions"] = HelpableActionMap(self, "ColorActions",
		{
			"red":		(self.removeEntries, _("Delete selected entries")),
			"green":	(self.startBackUp, _("Back up selected entries")),
			"yellow":	(self.showRestoreSelection, _("Restore from back up")),
			"blue":		(self.runCleanUpWizard, _("Run clean up wizard")),
		}, -1)
		
		self["OkCancelActions"] = HelpableActionMap(self, "OkCancelActions",
		{
			"ok":		(self.selectForBackUp, _("Select entry for back up")),
			"cancel":	(self.closePlugin, _("Close plugin")),
		}, -1)
		
		self["MenuActions"] = HelpableActionMap(self, "MenuActions",
		{
			"menu":		(self.openPluginConfig, _("Open plugin config screen")),
		}, -1)

		self["allEntries"] = Label(_("All entries"))
		self["plugEntries"] = Label(_("Plugin config only"))
		self["enigmaEntries"] = Label(_("Enigma2 config only"))
		self["merlinEntries"] = Label(_("Merlin3 config only"))
		self["selectAll"] = Label(_("Select all entries"))
		self["deselectAll"] = Label(_("Deselect all entries"))
		self["key3"] = Pixmap()
		self["ButtonRed"] = Pixmap()
		self["ButtonRedText"] = Label(_("Delete selected entries"))		
		self["ButtonGreen"] = Pixmap()
		self["ButtonGreenText"] = Label(_("Back up selected entries"))
		self["ButtonYellow"] = Pixmap()
		self["ButtonYellowText"] = Label(_("Restore from back up"))
		self["ButtonBlue"] = Pixmap()
		self["ButtonBlueText"] = Label(_("Run clean up wizard"))
		
		self["ButtonYellow"].hide()
		self["ButtonYellowText"].hide()
		self["merlinEntries"].hide()
		self["key3"].hide()
		
		self.setYellowButton()
		
		self.hasMerlinEntries = False
		
		self.menulist = []
		self.pluginConfigEntries = []
		self["menulist"] = ConfigMenuList([])
		
		self.selectedEntries = []
		if config.plugins.configmanager.rememberselection.value:
			if fileExists("/usr/lib/enigma2/python/Plugins/Extensions/ConfigManager/selection"):
				try:
					selectionFile = open('/usr/lib/enigma2/python/Plugins/Extensions/ConfigManager/selection', 'r')
					selbuf = selectionFile.readline().strip("\n[]").split(",")
					selectionFile.close()
					for k in range(len(selbuf)):
						self.selectedEntries.append(selbuf[k].strip())
				
				except IOError:
					print "couldn't read settings"
		
		self["entryinfo"] = Label()
		
		self.currentView = "ALL"
		
		self.createList()
		
		self["menulist"].onSelectionChanged.append(self.updateEntryinfo)
	
	def openPluginConfig(self):
		self.session.open(CMPluginConfigScreen)
	
	def updateEntryinfo(self):
		selectedMenuEntry = self["menulist"].getSelectedIndex()
		self["entryinfo"].setText(self.menulist[selectedMenuEntry][0][1])
	
	def readConfig(self):
		if fileExists("/etc/enigma2/settings"):
			try:
				configFile = open('/etc/enigma2/settings', 'r')
				lines = []
				for line in configFile:
					if line[0] != '#' and line != '\n':
						val = line.strip().split('=')
						lines.append([val[0],val[1]])
				return lines
			
			except IOError:
				print "couldn't read settings"
				return None

			configFile.close()

	def createList(self):
		self.data = self.readConfig()
		
		for i in range(len(self.data)):
			if self.data[i][0].startswith("config.plugins"):
				self.data[i].append("PLUGIN")
				self.pluginConfigEntries.append(self.data[i][0])
			elif self.data[i][0].startswith("config.merlin"):
				self.data[i].append("MERLIN")
				self.hasMerlinEntries = True
			else:
				self.data[i].append("ENIGMA")

			self.markSelectedEntries(i)
		
		self["menulist"].l.setList(self.menulist)
		
		if self.hasMerlinEntries:
			self.setKey3()		

		self.updateEntryinfo()

	def markSelectedEntries(self, index):
		self.index = index
		self.alreadyAdded = False
		for j in range(len(self.selectedEntries)):
			if self.data[self.index][0] == self.selectedEntries[j]:
				self.menulist.append(ConfigMenuListEntry(self.data[self.index][0], self.data[self.index][1], selected = True))
				self.alreadyAdded = True
				break
		if self.alreadyAdded == False:
			self.menulist.append(ConfigMenuListEntry(self.data[self.index][0], self.data[self.index][1]))
		else:
			self.alreadyAdded = False
			
	def updateList(self, configtype="ALL", jumpToFirst=True):
		self.menulist = []
		self.currentView = configtype
		self.alreadyAdded = False
	
		if self.currentView == "ALL":
			for i in range(len(self.data)):
				self.markSelectedEntries(i)
		else:
			for i in range(len(self.data)):
				if self.data[i][2] == self.currentView:
					self.markSelectedEntries(i)
		
		self["menulist"].l.setList(self.menulist)
		if jumpToFirst:
			self["menulist"].moveToIndex(0)
		self.updateEntryinfo()
	
	def showPluginConfigOnly(self):
		self.updateList("PLUGIN")
	
	def showMerlinConfigOnly(self):
		if self.hasMerlinEntries:
			self.updateList("MERLIN")
		
	def showEnigmaConfigOnly(self):
		self.updateList("ENIGMA")
		
	def selectAll(self):
		for k in range(len(self.menulist)):
			if self.menulist[k][0][2] == False:
				self.selectedEntries.append(self.menulist[k][0][0])
				
		if config.plugins.configmanager.rememberselection.value:
			self.saveCurrentSelection()
			
		self.updateList(self.currentView, jumpToFirst=False)
				
	def deselectAll(self):
		self.selectedEntries = []
				
		if config.plugins.configmanager.rememberselection.value:
			self.saveCurrentSelection()
			
		self.updateList(self.currentView, jumpToFirst=False)
		
	def selectForBackUp(self):
		selectedMenuEntry = self["menulist"].getSelectedIndex()
		if self.menulist[selectedMenuEntry][0][2] == False:
			self.selectedEntries.append(self.menulist[selectedMenuEntry][0][0])
		else:
			for k in range(len(self.selectedEntries)):
				if self.selectedEntries[k] == self.menulist[selectedMenuEntry][0][0]:
					del self.selectedEntries[k]
					break
		#save it to config
		if config.plugins.configmanager.rememberselection.value:
			self.saveCurrentSelection()

		self.updateList(self.currentView, jumpToFirst=False)

	def saveCurrentSelection(self):
		if not fileExists("/usr/lib/enigma2/python/Plugins/Extensions/ConfigManager/selection"):
			os.system("touch /usr/lib/enigma2/python/Plugins/Extensions/ConfigManager/selection")
		
		os.system("echo %s > /usr/lib/enigma2/python/Plugins/Extensions/ConfigManager/selection" %(self.selectedEntries))
		
	def startBackUp(self):
		self.session.openWithCallback(self.setYellowButton, ConfigBackUpScreen, self.selectedEntries)
	
	def setYellowButton(self):
		self.backupdir = ""
		self.backupdir = config.plugins.configmanager.backuppath.value
		if fileExists("%s/settings.tar.gz" %(self.backupdir)):
			self["ButtonYellow"].show()
			self["ButtonYellowText"].show()
			
	def setKey3(self):
		self["merlinEntries"].show()
		self["key3"].show()
	
	def removeEntries(self):
		confirmbox = self.session.openWithCallback(self.removeEntriesConfirmed,MessageBox,_("%d entries will be removed. Proceed?") %(len(self.selectedEntries)), MessageBox.TYPE_YESNO)
		confirmbox.setTitle(_("Config Manager"))
		
	def removeEntriesConfirmed(self, answer):
		if answer is True:
			configfile.save()
			if fileExists("/etc/enigma2/settings"):
				try:
					buf = []
					origFile = open('/etc/enigma2/settings', 'r')
					self.settingsList = []
					self.settingsList = origFile.readlines()
				
					for i in range(len(self.selectedEntries)):
						for k in range(len(self.settingsList)):
							entrysplit = self.settingsList[k].split('=')
							if entrysplit[0] == self.selectedEntries[i]:
								#a dirty hack
								self.settingsList[k] = "#"
								break
				
					origFile.close()
				
					os.system("touch /etc/enigma2/settings.new")
					os.system("chmod 644 /etc/enigma2/setttings.new")
					configFile = open('/etc/enigma2/settings.new', 'w')	
					for j in range(len(self.settingsList)):
						if self.settingsList[j] != "#":
							configFile.write(self.settingsList[j])
					configFile.close()

					self.doRestart()			
				
				except IOError:
					print "couldn't read settings"
			
	def runCleanUpWizard(self):
		self.session.open(CleanUpWizardScreen, self.pluginConfigEntries)
		
	def showRestoreSelection(self):
		self.session.open(RestoreSelectionScreen)
		
	def closePlugin(self):
		self.close()
		
	def doRestart(self):
		restartbox = self.session.openWithCallback(self.restartBox,MessageBox,_("A reboot is required to load settings\nDo you want to reboot the Dreambox now?"), MessageBox.TYPE_YESNO)
		restartbox.setTitle(_("Reboot Dreambox now?"))
		
	def restartBox(self,answer):
		if answer is True:
			self.session.open(TryQuitMainloop, 2)
		
def Plugins(**kwargs):
    return [PluginDescriptor(name="Config Manager", description=_("Plugin to view/edit settings"), where = [PluginDescriptor.WHERE_PLUGINMENU], fnc=main)]
