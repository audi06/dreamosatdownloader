#!/bin/sh
# 
# off by gutemine Version 0.7
#
OFFNAME=off
OFFBIN=/usr/bin/off
LINE="--------------------------------------"
OFFSCRIPT="/usr/script/off.sh"

case "$1" in
     start)
        echo $LINE
	echo "[OFFSCRIPT] $1: $OFFNAME"
        echo $LINE
	systemctl start $OFFNAME.service
        ;;
     stop)
	echo $LINE
	echo "[OFFSCRIPT] $1: $OFFNAME"
        echo $LINE
	systemctl stop $OFFNAME.service
	;;
     restart)
        echo $LINE
	echo "[OFFSCRIPT] $1: $OFFNAME"
        echo $LINE
	systemctl stop $OFFNAME.service
	sleep 2
	systemctl start $OFFNAME.service
	;;
     info)
        echo $LINE
	echo "[OFFSCRIPT] $1: $OFFNAME"
        echo $LINE
        if [ `ps ax | grep $OFFBIN | grep -v grep | grep -v $0 | grep -v systemctl | wc -l` -gt 0 ]; then
           echo "$OFFNAME running"
           echo $LINE
           ps ax | grep $OFFBIN | grep -v grep | grep -v $0 | grep -v systemctl
        else
           echo "$OFFNAME not running"
        fi
        echo $LINE
	systemctl status $OFFNAME.service
        echo $LINE
	if [ -e /etc/systemd/system/multi-user.target.wants/$OFFNAME.service ]; then
           echo "autostart of $OFFNAME is enabled"
           echo $LINE
        else
           echo "autostart of $OFFNAME is disabled"
           echo $LINE
        fi
	;;
     autostart | enable)
        echo $LINE
	echo "[OFFSCRIPT] $1: $OFFNAME"
        echo $LINE
        ln -sfn /lib/systemd/system/$OFFNAME.service /etc/systemd/system/multi-user.target.wants/$OFFNAME.service
        systemctl daemon-reload
	;;
     noautostart | disable)
        echo $LINE
	echo "[OFFSCRIPT] $1: $OFFNAME"
        echo $LINE
	rm /etc/systemd/system/multi-user.target.wants/$OFFNAME.service > /dev/null 2>&1
        systemctl daemon-reload
	;;
     *)
	echo "Usage: $0 start|stop|restart|info|enable|disable"
	exit 1
	;;
esac

exit 0
