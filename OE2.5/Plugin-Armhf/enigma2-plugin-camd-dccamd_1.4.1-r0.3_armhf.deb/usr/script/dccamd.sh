#!/bin/sh
CAMNAME="dccamd"
CAMBIN=dccamd
LINE="--------------------------------------"
INFOFILE="ecm.info"
SCRIPT="dccamd.sh"
# end

remove_tmp () {
	rm -rf /tmp/ecm.info /tmp/script.info /tmp/pid.info /tmp/cam.info /tmp/$INFOFILE
}

case "$1" in
     start)
	if [ -f /tmp/script.info ]; then
           RUNNING_SCRIPT=`cat /tmp/script.info`
	else
	   RUNNING_SCRIPT=$SCRIPT
	fi
	/usr/script/$RUNNING_SCRIPT stop
	sleep 2
        echo $LINE
	echo "[SCRIPT] $1: $CAMNAME"
        echo $LINE
	remove_tmp
	echo $SCRIPT > /tmp/script.info
        echo $CAMNAME > /tmp/cam.info
	systemctl start $CAMNAME.service
	systemctl start $CAMNAME.socket
        ;;
     stop)
	echo $LINE
	echo "[SCRIPT] $1: $CAMNAME"
        echo $LINE
	systemctl stop $CAMNAME.socket
	systemctl stop $CAMNAME.service
        sleep 2
	remove_tmp
	;;
     restart)
        echo $LINE
	echo "[SCRIPT] $1: $CAMNAME"
        echo $LINE
	systemctl stop $CAMNAME.socket
	systemctl stop $CAMNAME.service
	sleep 2
	remove_tmp
        sleep 5
	echo $SCRIPT > /tmp/script.info
        echo $CAMNAME > /tmp/cam.info
	systemctl start $CAMNAME.service
	systemctl start $CAMNAME.socket
	;;
     info)
        echo $LINE
	echo "[SCRIPT] $1: $CAMNAME"
        echo $LINE
        if [ -f /tmp/cam.info ]; then
           RUNNING_CAM=`cat /tmp/cam.info` 
        else
           RUNNING_CAM="no CAM" 
        fi
        echo -n "$RUNNING_CAM is started "
        if [ `ps ax | grep $CAMBIN | grep -v grep | grep -v $0 | wc -l` -gt 0 ]; then
           echo "and running"
           echo $LINE
           ps ax | grep $CAMBIN | grep -v grep | grep -v $0
        else
           echo "and not running"
        fi
        echo $LINE
	systemctl status $CAMNAME.service
        echo $LINE

	if [ -e /etc/systemd/system/multi-user.target.wants/$CAMNAME.service ]; then
           echo "autostart of $CAMNAME is enabled"
           echo $LINE
        else
           echo "autostart of $CAMNAME is disabled"
           echo $LINE
        fi
         
        if [ -f /tmp/ecm.info ]; then
           echo "Info File"
           echo $LINE
	   cat /tmp/$INFOFILE
           echo $LINE
        fi
	;;
     autostart | enable)
        echo $LINE
	echo "[SCRIPT] $1: $CAMNAME"
        echo $LINE
        rm /etc/systemd/system/multi-user.target.wants/$CAMNAME.service > /dev/null 2>&1
        ln -sfn /usr/script/$CAMNAME.service /etc/systemd/system/multi-user.target.wants/$CAMNAME.service
        rm /lib/systemd/system/$CAMNAME.service > /dev/null 2>&1
        ln -sfn /usr/script/$CAMNAME.service /lib/systemd/system/$CAMNAME.service
        rm /etc/systemd/system/sockets.target.wants/$CAMNAME.socket > /dev/null 2>&1
        ln -sfn /usr/script/$CAMNAME.socket /etc/systemd/system/sockets.target.wants/$CAMNAME.socket
        rm /lib/systemd/system/$CAMNAME.socket > /dev/null 2>&1
        ln -sfn /usr/script/$CAMNAME.socket /lib/systemd/system/$CAMNAME.socket
        systemctl daemon-reload
	;;
     noautostart | disable)
        echo $LINE
	echo "[SCRIPT] $1: $CAMNAME"
        echo $LINE
	rm /etc/systemd/system/multi-user.target.wants/$CAMNAME.service > /dev/null 2>&1
        rm /lib/systemd/system/$CAMNAME.service > /dev/null 2>&1
        rm /etc/systemd/system/sockets.target.wants/$CAMNAME.socket > /dev/null 2>&1
        rm /lib/systemd/system/$CAMNAME.socket > /dev/null 2>&1
        systemctl daemon-reload
	;;
     *)
	echo "Usage: $0 start|stop|restart|info|enable|disable"
	exit 1
	;;
esac

exit 0
