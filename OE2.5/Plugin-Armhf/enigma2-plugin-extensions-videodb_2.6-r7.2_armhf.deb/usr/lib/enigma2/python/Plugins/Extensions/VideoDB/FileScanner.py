#
# VideoDB E2
#
# Coded by Dr.Best (c) 2013
# Support: www.dreambox-tools.info
# E-Mail: dr.best@dreambox-tools.info
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Multimedia GmbH.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Multimedia GmbH.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Multimedia GmbH.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.
#


from enigma import ePythonMessagePump, eServiceReference, eBackgroundFileEraser
from threading import Thread
from os import path as os_path, walk as os_walk, listdir as os_listdir
from DatabaseConnection import OpenDatabase, OpenDatabaseForWriting, ClientID
from DatabaseFunctions import isMounted, addToDatabase, deleteMovieInDatabase, EXTENSIONS, moveMovieInDatabase
from ThreadQueue import ThreadQueue, THREAD_WORKING, THREAD_FINISHED
from time import time as time_time

# for localized messages
from . import _

class FileScanner(object):
	# this class is handling BackgroundFileScanner
	instance = None
	def __init__(self, session):
		self.session = session
		assert not FileScanner.instance, "only one FileScanner instance is allowed!"
		FileScanner.instance = self # set instance
		self.scanner = None
		self.isRunning = False
		self.callback = None
		self.updateCache = True
		self.scanner_connection = None
		self.eBackgroundFileEraser_Connection = eBackgroundFileEraser.getInstance().fileErased.connect(self.fileErased)
		try: # Merlin Feature only...
			import merlin._merlin_filemover
			from merlin.merlin_filemover import eBackgroundFileMover
			self.eBackgroundFileMover_Connection = eBackgroundFileMover.getInstance().fileMoved.connect(self.fileMoved)
		except: pass # not a merlin Image, skip that feature...

	def fileMoved(self, from_filename, to_filename):
		extension = os_path.splitext(from_filename)[1].lower()
		if extension in EXTENSIONS:
			f_path,f_filename = os_path.split(from_filename)
			t_path,t_filename = os_path.split(to_filename)
			moveMovieInDatabase(f_path, f_filename, t_path)

	def fileErased(self, deletedfilename):
		extension = os_path.splitext(deletedfilename)[1].lower()
		if extension in EXTENSIONS:
			path,filename = os_path.split(deletedfilename)
			deleteMovieInDatabase(path,filename)

	def startScanning(self, path = None, pathID = None, callback = None, updateCache = True):
		if not self.isRunning:
			self.updateCache = updateCache
			self.scanner = BackgroundFileScanner()
			self.scanner_connection = self.scanner.MessagePump.recv_msg.connect(self.gotThreadMsg) 
			if callback is not None:
				self.callback = callback
			if path:
				self.scanner.setPath(path)
			if pathID:
				self.scanner.setPathID(pathID)
			self.scanner.startScanning()
			self.isRunning = True
			return True
		else:
			return False

	def gotThreadMsg(self, msg):
		msg = self.scanner.Message.pop()
		if self.callback:
			self.callback(msg) # emit messages
		if msg[0] == THREAD_FINISHED:
			# clean up
			del self.scanner_connection
			self.callback = None
			self.scanner = None
			self.isRunning = False
			if self.updateCache:
				cache = CacheFiles.instance
				if cache:
					pass
					#cache.startCaching() # dummy --> FIXME this from directory to path
			
	def Cancel(self):
		if self.scanner and self.isRunning:
			self.scanner.Cancel()



class BackgroundFileScanner(Thread):
	def __init__(self):
		Thread.__init__(self)
		self.cancel = False
		self.path = None
		self.pathID = None
		self.messages = ThreadQueue()
		self.messagePump = ePythonMessagePump()

	def getMessagePump(self):
		return self.messagePump

	def getMessageQueue(self):
		return self.messages

	def Cancel(self):
		self.cancel = True

	MessagePump = property(getMessagePump)
	Message = property(getMessageQueue)

	def setPath(self, path):
		self.path = path

	def setPathID(self, pathID):
		self.pathID = pathID

	def startScanning(self):
		self.start()

	def run(self):
		mp = self.messagePump
		self.cancel = False
		connection, error = OpenDatabaseForWriting()
		try: #so many things  can go wrong here, I need this, otherside the thread will not send the finished flag
			if connection is not None:
				cursor = connection.cursor()
				dirCursor = None
				counter = 0
				checkTime = 0
				addedRows = 0
				updatedRows = 0
				deletedRows = 0
				if self.path:
					# scan path was set by user, scan for files incl. subfolders
					directory = self.path
					for root, subFolders, files in os_walk(directory):
						if self.cancel:
							break
						if not root.endswith("/"):
							root += "/"
						msg_text =  _("scanning %s for media files...") % root
						self.messages.push((THREAD_WORKING, msg_text))
						mp.send(0)
						for filename in files:
							extension = os_path.splitext(filename)[1].lower()
							#if extension in (".ts", ".mkv",".avi"):
							if extension in EXTENSIONS:
								if self.cancel:
									break
								result = addToDatabase(cursor, root, filename)
								if result and result[0]:
									addedRows += 1
								elif result and not result[0]:
									updatedRows += 1
				else:
					# rescan
					# if pathID was set, rescan is only for one specific dir
					sqlWhere = ""
					if self.pathID:
						sqlWhere = "and paths.path_id = %d" % self.pathID
					# get all movies from the database, needed to check if files are deleted since last scan... all remaining items in that dict have to be deleted after the rescan
					filesInDatabase = {}
					sql = "SELECT movies.movie_id, movies.filename , paths.path, mountpoints.mountpoint FROM Movies INNER JOIN Paths ON movies.path_id = paths.path_id INNER JOIN mountpoints on Paths.link_id = Mountpoints.link_id where mountpoints.client_id = %d %s;" % (ClientID.instance.getClientID(), sqlWhere)
					cursor.execute(sql)
					for row in cursor:
						filesInDatabase[os_path.join(row[3],row[2],row[1])]= (int(row[0]), os_path.join(row[3],row[2]))
					notMountedList = {} # dict for non mounted mointpoints
					# get all scanned directories and mountpoints from database, these are the basis of the rescan
					dirCursor = connection.cursor()
					sql = "SELECT paths.path, mountpoints.mountpoint FROM Paths INNER JOIN mountpoints ON Paths.link_id = Mountpoints.link_id WHERE mountpoints.client_id = %d %s;" % (ClientID.instance.getClientID(), sqlWhere)
					dirCursor.execute(sql)
					for row in dirCursor:
						directory = os_path.join(row[1],row[0])
						mountpoint = row[1]
						msg_text =  _("scanning %s for media files...") % directory
						self.messages.push((THREAD_WORKING, msg_text))
						mp.send(0)
						if notMountedList.has_key(mountpoint): # check if mountpoint-availability was already checked 
							mounted = False
						else:
							mounted = isMounted(mountpoint) # check if device is mounted
						if mounted:
							if os_path.exists(directory): # it can happen that a directory was deleted, so check it first
								files = os_listdir(directory) # check all files in path 
								for file in files:
									if self.cancel:
										break
									filename = os_path.join(directory, file)
									if os_path.isfile(filename): # only files are needed
										extension = os_path.splitext(filename)[1].lower()
										#if extension in (".ts", ".mkv",".avi"):
										if extension in EXTENSIONS:
											result = addToDatabase(cursor, directory, file) # check it ( add new or update in DB)
											if result and result[0]:
												addedRows += 1
											elif result and not result[0]:
												updatedRows += 1
											if filesInDatabase.has_key(filename): # check if filename is in database, if so, delete it from dict
												del filesInDatabase[filename]
						else: # not mounted
							notMountedList[mountpoint] = True
							msg_text =  _("%s is not mounted, can not scan...") % mountpoint
							self.messages.push((THREAD_WORKING, msg_text))
							mp.send(0)
							# it is not mounted, so delete all items with that directory from the dict... 
							# (we dont want to delete movies from the database just because of an umount device)
							for item in filesInDatabase.items():
								if item[1][1] == directory:
									del filesInDatabase[item[0]]
					dirCursor.close()
					# remaining items in filesInDatabase, these files were deleted by user since last scan, delete these now in database too
					movieIDs = ""
					for item in filesInDatabase.items():
						deletedRows += 1
						movieIDs += "%d," % item[1][0]
					if movieIDs:
						cursor.execute('DELETE FROM Movies WHERE movie_id in (%s);' % movieIDs[:-1]) # triggers will do the rest :-)
				if not self.cancel:
					connection.commit()
				cursor.close()
				connection.close()
				if self.cancel:
					self.messages.push((THREAD_FINISHED, _("Process aborted.\nPress OK to close.") ))
				else:	
					self.messages.push((THREAD_FINISHED, _("%d files added,\n%d files updated,\n%d files removed in database!\nPress OK to close." % (addedRows, updatedRows, deletedRows))))
			else:
				self.messages.push((THREAD_FINISHED, _("Error!\nCan not open database!\n%s" %error) ))
		except Exception, e:
			if connection:
				connection.close()
			self.messages.push((THREAD_FINISHED, _("Error!\nError-message:%s\nPress OK to close." % e) ))
		finally:
			mp.send(0)

