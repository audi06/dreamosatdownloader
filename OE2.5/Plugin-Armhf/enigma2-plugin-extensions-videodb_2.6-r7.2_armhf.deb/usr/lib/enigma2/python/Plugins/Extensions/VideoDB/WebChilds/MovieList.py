# -*- coding: utf-8 -*-
#
# VideoDB E2
#
# Coded by Dr.Best (c) 2013/14/15
# Support: www.dreambox-tools.info
# E-Mail: dr.best@dreambox-tools.info
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Multimedia GmbH.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Multimedia GmbH.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Multimedia GmbH.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.
#


from twisted.web import resource
from simplejson import dumps as simplejson_dumps
from Components.config import config
from Plugins.Extensions.VideoDB.DatabaseConnection import OpenDatabase, ClientID

class MovieList(resource.Resource):

	def __init__(self, session):
		self.session = session
		resource.Resource.__init__(self)

	def render_GET(self, request):
		self.args = request.args
		request.setHeader("content-type", "application/json; charset=utf-8")
		sortType = self.getArg("sortType")
		searchText = self.getArg("searchText")
		listType = self.getArg("listType")
		if listType is None or not listType.isdigit(): 
				listType = "1" # default = Movies
		if listType == "1": # movies
				sqlOrder = "ORDER BY movies.begin" # default sortType = 1
				if sortType == "0":
					  sqlOrder = "ORDER BY movies.begin DESC"
				elif sortType == "2":
					  sqlOrder = "ORDER BY sortname DESC"
				elif sortType == "3":
					  sqlOrder = "ORDER BY sortname"
				if searchText:
					sqlWhere = 'and (movies.name like "%' + searchText.replace('"','""') + '%" or movies.description like "%' + searchText.replace('"','""') + '%" or events.extdescription like "%' + searchText.replace('"','""') + '%")'
				else:
					sqlWhere = ""
				rows = ""
				collectionID = self.getArg("tmdb_collection_id")
				if collectionID and collectionID.isdigit():
					sqlOrder = "ORDER BY movies.released" # static, nothing else makes sense for collection view
					sqlWhere = " and movies.tmdb_collection_id = %d" % int(collectionID)
				connection = OpenDatabase(True, True)
				if connection is not None:
					cursor = connection.cursor()
					if collectionID and collectionID.isdigit():
						sql = "select movies.movie_id, movies.name, movies.description, movies.thumb_filename, cover_middle_filename, cover_filename, movies.movieposition, movies.duration, movies.begin, movies.description, movies.filesize, movies.released, movies.rating, events.extdescription, movies.wallpaper, movies.dts, movies.ac3, movies.stereo, movies.hd, movies.widescreen, res_width, res_height, movies.framerate, movies.codec, movies.tmdb_movie_id, movies.tmdb_collection_id, client_movieposition.clientmovieposition, movies.name as sortname FROM Movies LEFT OUTER JOIN Events ON movies.event_id = events.event_id LEFT OUTER JOIN client_movieposition ON movies.movie_id = client_movieposition.movie_id AND client_movieposition.client_id = %d where movies.tmdb_movie_id is not null %s %s;" % (ClientID.instance.getClientID(), sqlWhere, sqlOrder)
					
					else:
						sql = "select movies.movie_id as movie_id, movies.name as name, movies.description as description, movies.thumb_filename as thumb_filename, movies.cover_middle_filename as cover_middle_filename, movies.cover_filename as cover_filename, movies.movieposition as movieposition, movies.duration as duration, movies.begin as begin, movies.description as description, movies.filesize as filesize, movies.released as released, movies.rating as rating, events.extdescription as extdescription, movies.wallpaper as wallpaper, movies.dts as dts, movies.ac3 as ac3, movies.stereo as stereo, movies.hd as hd, movies.widescreen as widescreen, res_width, res_height, movies.framerate as framerate, movies.codec as codec, movies.tmdb_movie_id as tmdb_movie_id, movies.tmdb_collection_id as tmdb_collection_id, 0 AS col_count, '' as Movie_Collections_wallpaper, '' as Movie_Collections_thumb_filename, '' as Movie_Collections_cover_middle_filename, '' as Movie_Collections_cover_filename, '' as Movie_Collections_name, '' as Movie_Collections_overview, client_movieposition.clientmovieposition as clientmovieposition, movies.name as sortname FROM Movies LEFT OUTER JOIN Events ON movies.event_id = events.event_id LEFT OUTER JOIN client_movieposition ON movies.movie_id = client_movieposition.movie_id AND client_movieposition.client_id = %d where movies.tmdb_movie_id is not null and movies.tmdb_collection_id = 0 %s UNION ALL select movies.movie_id, movies.name, movies.description, movies.thumb_filename, movies.cover_middle_filename, movies.cover_filename, movies.movieposition, movies.duration, movies.begin, movies.description, movies.filesize, movies.released, movies.rating, events.extdescription, movies.wallpaper, movies.dts, movies.ac3, movies.stereo, movies.hd, movies.widescreen, res_width, res_height, movies.framerate, movies.codec, movies.tmdb_movie_id, movies.tmdb_collection_id, count(movies.movie_id) AS col_count, Movie_Collections.wallpaper as Movie_Collections_wallpaper, Movie_Collections.thumb_filename as Movie_Collections_humb_filename, Movie_Collections.cover_middle_filename as Movie_Collections_cover_middle_filename, Movie_Collections.cover_filename as Movie_Collections_cover_filename, Movie_Collections.name as Movie_Collections_name, Movie_Collections.overview as Movie_Collections_overview, client_movieposition.clientmovieposition as clientmovieposition, Movie_Collections.name as sortname FROM Movies LEFT OUTER JOIN Events ON movies.event_id = events.event_id LEFT OUTER JOIN client_movieposition ON movies.movie_id = client_movieposition.movie_id AND client_movieposition.client_id = %d LEFT OUTER JOIN Movie_Collections ON movies.tmdb_collection_id = Movie_Collections.tmdb_collection_id where movies.tmdb_movie_id is not null and movies.tmdb_collection_id <> 0 %s GROUP BY movies.tmdb_collection_id %s;" % (ClientID.instance.getClientID(),  sqlWhere, ClientID.instance.getClientID(), sqlWhere, sqlOrder)
					cursor.execute(sql)
					rows = cursor.fetchall()
					cursor.close() 
					connection.close()
				json_format = { 'clientmovieposition' : config.plugins.videodb.clientmovieposition.value, 'movies' : rows }
		else: #series
			seriesID = self.getArg("serie_id")
			season = self.getArg("season")
			if seriesID is None:
					if searchText:
						sortType = "3" # bugfix, damit kein inner-join kommt, ansonsten muesste ich was umstellen, habe ich erstmal keine Lust zu
					sqlOrder = "inner join (select max(begin) as max_begin, movies_series.serie_id from movies inner join movies_series on movies_series.movie_id = movies.movie_id group by movies_series.serie_id order by max_begin) as mo_se on mo_se.serie_id = series.serie_id"
					if sortType == "0":
						sqlOrder = "inner join (select max(begin) as max_begin, movies_series.serie_id from movies inner join movies_series on movies_series.movie_id = movies.movie_id group by movies_series.serie_id order by max_begin DESC) as mo_se on mo_se.serie_id = series.serie_id"
					elif sortType == "2":
						sqlOrder = "ORDER BY series.name DESC"
					elif sortType == "3":
						sqlOrder = "ORDER BY series.name"
					if searchText:
						sqlWhere = 'where (series.name like "%' + searchText.replace('"','""') + '%" or series.overview like "%' + searchText.replace('"','""') + '%")'
					else:
						sqlWhere = ""
					sql = "select series.name, series.serie_id, series.tvdb_serie_id, series.overview, series.banner, series.banner_small, series.poster, series.wallpaper, series.genre, series.runtime, series.status, series.firstaired, series.rating, series.network, series.wallpaper, series.thumb_poster from series %s %s;" % (sqlWhere, sqlOrder)
			else:
					if season is None or not season.isdigit():
						sql = "select movies_series.season, count(movies_series.movie_series_id) as season_count, movies_series.serie_id from movies_series where movies_series.serie_id = %d group by movies_series.serie_id, movies_series.season order by movies_series.season;" % (int(seriesID))
					else:
						sql = "SELECT movies.name, movies.movie_id, movies.serviceid, movies.filename, paths.path, movies.movieposition, movies.duration, movies.begin, movies.description, movies.event_id, movies.filesize, movies.screenshot, movies.dts, movies.ac3, movies.stereo, movies.hd, movies.widescreen, movies.res_width, movies.res_height, movies.framerate, movies.codec, movies_series.episode, movies_series.season, movies_series.writer, movies_series.director, movies_series.episodename, movies_series.rating, movies_series.firstaired, movies_series.overview, mountpoints.mountpoint, client_movieposition.clientmovieposition, events.extdescription, movies_series.serie_id FROM Movies INNER JOIN Paths ON movies.path_id = paths.path_id INNER JOIN mountpoints on Paths.link_id = Mountpoints.link_id INNER JOIN movies_series on movies_series.movie_id = movies.movie_id LEFT OUTER JOIN client_movieposition ON movies.movie_id = client_movieposition.movie_id AND client_movieposition.client_id = %d LEFT OUTER JOIN Events ON movies.event_id = events.event_id WHERE mountpoints.client_id = %d and movies.visible = 1 and movies_series.season = %d and movies_series.serie_id = %d ORDER BY movies_series.episode, begin DESC;" % (ClientID.instance.getClientID(), ClientID.instance.getClientID(), int(season), int(seriesID))
						
			rows = ""
			connection = OpenDatabase(True, True)
			if connection is not None:
					cursor = connection.cursor()
					cursor.execute(sql)
					rows = cursor.fetchall()
					cursor.close() 
					connection.close()
			json_format = { 'clientmovieposition' : config.plugins.videodb.clientmovieposition.value, 'series' : rows}
				
		return simplejson_dumps(json_format, ensure_ascii=False).encode("utf-8")
		
	def getArg(self, key):
		if key in self.args:
			return self.args[key][0]
		else:
			return None
