#
# VideoDB E2
#
# Coded by Dr.Best (c) 2013
# Support: www.dreambox-tools.info
# E-Mail: dr.best@dreambox-tools.info
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Multimedia GmbH.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Multimedia GmbH.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Multimedia GmbH.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.
#

from enigma import eServiceReference, eServiceCenter, iServiceInformation
from os import path as os_path, walk as os_walk, O_NONBLOCK as os_O_NONBLOCK, stat as os_stat, listdir as os_listdir, chdir as os_chdir, getcwd as os_getcwd, statvfs as os_statvfs, remove as os_remove
from stat import ST_MTIME as stat_ST_MTIME, ST_SIZE as stat_ST_SIZE, ST_CTIME as stat_ST_CTIME
from DatabaseConnection import OpenDatabase, OpenDatabaseForWriting, ClientID
from ServiceReference import ServiceReference
from datetime import datetime
from struct import calcsize as struct_calcsize, unpack as struct_unpack
from pickle import loads as pickle_loads, dumps as pickle_dumps, HIGHEST_PROTOCOL as pickle_HIGHEST_PROTOCOL
from sqlite3 import Binary as sqlite_binary
from Components.config import config

import _merlin_mediainfo
from merlin_mediainfo import eMediaInfo
mi = eMediaInfo()


EXTENSIONS = (".ts", ".m2ts", ".mkv",".avi", ".divx", ".mov", ".m4v", ".mp4", ".flv", ".mpg")



def sqlExecuteCommand(sqlSatement):
	connection = OpenDatabase()
	if connection is not None:
		cursor = connection.cursor()
		cursor.execute(sqlSatement)
		connection.commit()
		cursor.close()
		connection.close()

class MusicEvent(object):
	def __init__(self, tag, begin):
		self.tag = tag
		self.begin = begin

	def getEventName(self):
		return "%s - %s" % (self.tag["title"], self.tag["artist"])

	def getShortDescription(self):
		return "short album = %s" % self.tag["album"]

	def getExtendedDescription(self):
		return "extended album = %s" % self.tag["album"]

	def getDuration(self):
		return self.tag["length"]

	def getBeginTime(self):
		return self.begin

class MetaData(object):
	def __init__(self, serviceID, path, filename):
		extension = os_path.splitext(filename)[1].lower()
		self.ismovie = 1
		# get meta data from meta-file
		serviceHandler = eServiceCenter.getInstance()
		ref = eServiceReference(serviceID, 0, os_path.join(path,filename))
		info = serviceHandler.info(ref)
		serviceRef = ServiceReference(info.getInfoString(ref, iServiceInformation.sServiceref))
#		self.duration = info.getLength(ref)
		self.begin = info.getInfo(ref, iServiceInformation.sTimeCreate)
		if self.begin == -1:
			if os_path.exists(os_path.join(path,filename)): 
				fileInfo = os_stat(os_path.join(path,filename))
				self.begin = fileInfo[stat_ST_CTIME]
		self.movieLength = info.getLength(ref)
		if not self.movieLength:
			self.movieLength = 0
		self.serviceName = serviceRef.getServiceName().replace('\xc2\x86', '').replace('\xc2\x87', '')
		if not self.serviceName:
			self.serviceName = _("%s-file") % extension[1:]
		self.name = info and info.getName(ref)
		if not self.name:
			self.name = filename
		if self.name.endswith(extension):
			self.name = self.name.replace(extension,'')
		self.description = info.getInfoString(ref, iServiceInformation.sDescription)
		self.taglist = info.getInfoString(ref, iServiceInformation.sTags).split(' ')
		self.event = info.getEvent(ref)
		mediaInfo = mi.getInfos(os_path.join(path,filename))
		if mediaInfo is not None:
		
			audio_info = mediaInfo[1]
			
			self.ac3 = audio_info[0]
			self.dts = audio_info[1]
			self.FivePointOne = audio_info[2]
			self.stereo = audio_info[3]
			
			video_info = mediaInfo[0]

			self.codec = video_info[0]
			self.res_width = video_info[1]
			self.res_height = video_info[2]
			self.framerate = video_info[3]
			
			if serviceID != eServiceReference.idDVB:
				self.movieLength = video_info[4]
			
			self.hd = video_info[5]
			self.container = video_info[6]
			#video_info[7] # bitrate, not needed
			
			self.widescreen = video_info[8]
			self.video_codec_text = video_info[9]

			self.audio_infos = None #mediaInfo[2]

		
		else:
			self.ac3 = -1
			self.dts = -1
			self.FivePointOne = -1
			self.stereo = -1

			self.codec = ""
			self.res_width = -1
			self.res_height = -1
			self.framerate = -1

			self.hd = -1
			self.container = ""
			#codec = video_info[7]
			
			self.widescreen = -1
			self.video_codec_text = ""
			
			self.audio_infos = None
			
		


def isMounted(path):
	if path.endswith("/"):
		directory = path[:-1]
	else:
		directory = path
	# check if mountpoint is mounted
	if os_path.ismount(directory): 
		return True
	else:
		# unfortunately path.ismount is not working with automount correctly, because the result of that method comes to fast (false) before it is mounted...
		# my solution: change working dir to the mountpoint and see if it is mounted then ( best solution i had... :-( FIXME)
		try:
			currentWorkDir = os_getcwd() # save current dir
			os_chdir(directory) # change to mountpoint
			mounted =  os_path.ismount(directory) # check if it is mounted now
			os_chdir(currentWorkDir) # go to old working dir (and release automount folders e.g.)

			return mounted
		except OSError:
			return False # mountpoint is not available
			
def getMountPoint(path):
	if path.endswith("/"):
		directory = path[:-1]
	else:
		directory = path
	while len(directory) > 1:
		if os_path.islink(directory):
			directory = os_path.realpath(directory)
		if os_path.ismount(directory):
			return True, directory
		else:
			directory = os_path.dirname(directory[:-1])
	return False, ""



def getPathID(cursor, path):
	realpath = os_path.realpath(path)
	ismounted, mountpoint = getMountPoint(realpath)
	relativePath = os_path.relpath(realpath, mountpoint)
	if relativePath == ".": # mountpoint == relativePath
		relativePath = ""
	client_id = ClientID.instance.getClientID()
	# 1) get/set link_id
	link_id = None
	cursor.execute('SELECT link_id from Mountpoints WHERE mountpoint = "%s" and client_id = %d;' % (mountpoint, client_id))
	row = cursor.fetchone()
	if row is not None:
		link_id = row[0]
	else:
		cursor.execute('INSERT INTO Mountpoints (mountpoint, client_id) VALUES("%s",%d);' % (mountpoint, client_id))
		link_id = cursor.lastrowid # when inserting new mountpoint, link_id = mountpoint_id (set by trigger)
	# 2) get/set path_id
	path_id = None
	if link_id is not None:
		cursor.execute('SELECT path_id FROM Paths WHERE path = "%s" and link_id = %d;' % (relativePath, link_id))
		row = cursor.fetchone()
		if row is not None:
			path_id =  row[0]
		else:

			cursor.execute('INSERT INTO Paths (path, link_id) VALUES("%s",%d);' % (relativePath,link_id))
			path_id =  cursor.lastrowid
	return path_id
	
def getDirectoryID(cursor, path): # FIXME do i need this anymore? ;)
	realpath = os_path.realpath(path)
	getPathID(cursor, path)
	cursor.execute('SELECT directory_id FROM Directories WHERE directory = "%s";' % realpath)
	row = cursor.fetchone()
	if row is not None:
		return row[0]
	else:
		ismounted, mountpoint = getMountPoint(realpath)
		cursor.execute('INSERT INTO Directories (directory, mountpoint, name) VALUES("%s","%s", "%s");' % (realpath.replace('"','""'), mountpoint, realpath.replace('"','""')))
		return cursor.lastrowid
	
def getServiceNameID(cursor, servicename):
	cursor.execute('SELECT servicename_id FROM Servicenames WHERE servicename = "%s";' % (servicename.replace('"','""')))
	row = cursor.fetchone()
	if row is None:
		cursor.execute('INSERT INTO Servicenames (servicename) VALUES("%s");' % (servicename.replace('"','""')))
		return cursor.lastrowid
	else:
		return row[0]
			
def getTagIDList(cursor, taglist):
	tagIDList = []
	for tag in taglist:
		if tag:
			cursor.execute('SELECT tag_id FROM Tags WHERE tag = "%s";' % (tag.replace('"','""')))
			row = cursor.fetchone()
			if row is None:
				cursor.execute('INSERT INTO Tags (tag) VALUES("%s");' % (tag.replace('"','""')))
				tagIDList.append(cursor.lastrowid)
			else:
				tagIDList.append(row[0])
	return tagIDList

def addToDatabase(cursor, path, filename, recording = 0):
	extension = os_path.splitext(filename)[1].lower()
	if extension not in EXTENSIONS:
		return
	elif extension == ".ts":
		serviceID = eServiceReference.idDVB
	elif extension == ".m2ts": # new since 11-11-2010
		serviceID = 0x3
	else:
		serviceID =  0x1001
	realpath = os_path.realpath(path)



	ismounted, mountpoint = getMountPoint(realpath)
	relativePath = os_path.relpath(realpath, mountpoint)
	if relativePath == ".": # mountpoint == relativePath
		relativePath = ""
	client_id = ClientID.instance.getClientID()
	
	cursor.execute('SELECT movie_id, strftime("%s", modified), movies.path_id FROM Movies INNER JOIN Paths ON movies.path_id = paths.path_id INNER JOIN mountpoints on Paths.link_id = Mountpoints.link_id WHERE filename = ? and paths.path = ? and mountpoints.mountpoint = ? and mountpoints.client_id = ?;', (filename, relativePath, mountpoint, client_id))



#	cursor.execute('SELECT movie_id, strftime("%s", modified), movies.directory_id FROM Movies INNER JOIN Directories ON movies.directory_id = Directories.directory_id WHERE filename = ? and directories.directory = ?;', (filename, realpath))
	row = cursor.fetchone()
	if row is None:
		metaData = MetaData(serviceID, realpath, filename)
		# 1. Servicename
		servicenameID = getServiceNameID(cursor, metaData.serviceName)
		# 2. path
		pathID = getPathID(cursor, path)
		# 3. Tags
		tagIDList = getTagIDList(cursor, metaData.taglist)
		# 4. Event		
		eventID = -1
		if metaData.event:
			cursor.execute('INSERT INTO Events (eventname, description, extdescription, duration,begintime) VALUES("%s","%s","%s",%d,%d);' % (metaData.event.getEventName().replace('"','""'),metaData.event.getShortDescription().replace('"','""'), metaData.event.getExtendedDescription().replace('"','""'),metaData.event.getDuration(),metaData.event.getBeginTime()))
			eventID = cursor.lastrowid
		# 5. file size of movie
		fileInfo = os_stat(os_path.join(realpath,filename))
		filesize = fileInfo[stat_ST_SIZE]
		# Enigma1 support
		slice = 1
		while os_path.exists(os_path.join(realpath,"%s.%03d" % (filename,slice))):
			fileInfo = os_stat(os_path.join(realpath,"%s.%03d" % (filename,slice)))
			filesize += fileInfo[stat_ST_SIZE]
			slice += 1
		# 6. read (if available) .cuts file and get the playback-stop position from file
		movieposition = 0
		if os_path.exists(os_path.join(realpath,"%s.cuts" % (filename))):
			cuts_format = ">QI" # big endian, unsigned long long, unsigned int
			cuts_format_size = struct_calcsize(cuts_format)
			cuts_file = open(os_path.join(realpath,"%s.cuts" % (filename)), 'rb')
			if cuts_file:
				while True:
					cuts_data = cuts_file.read(cuts_format_size)
					if len(cuts_data) <> cuts_format_size: # the string must contain exactly the amount of data required by the format
						break
					cuts_unpacked_data = struct_unpack(cuts_format, cuts_data)
					if cuts_unpacked_data[1] == 3: # CUT_TYPE_LAST = 3 --> InfoBarCueSheetSupport
						movieposition = cuts_unpacked_data[0]
				cuts_file.close()
				if movieposition > (metaData.movieLength * 90000): movieposition = metaData.movieLength * 90000 # workaround for weird cuts
		# 7. Movie
		cursor.execute('INSERT INTO Movies (filename, path_id, serviceid, begin, name,servicename_id, event_id,movieposition, duration, description, filesize, recording, ismovie, ac3, dts, fivepointone, stereo, codec, container, res_width, res_height, framerate, widescreen, HD, video_codec_text) VALUES("%s",%d,%d,%d,"%s",%d,%d,%d,%d,"%s",%d,%d, %d, %d, %d, %d, %d, "%s", "%s", %d, %d, %f, %d, %d, "%s");' % (filename.replace('"','""'),pathID, serviceID, metaData.begin, metaData.name.replace('"','""'),servicenameID,eventID, movieposition, metaData.movieLength, metaData.description.replace('"','""'),filesize, recording, metaData.ismovie, metaData.ac3, metaData.dts, metaData.FivePointOne, metaData.stereo, metaData.codec, metaData.container, metaData.res_width, metaData.res_height, metaData.framerate, metaData.widescreen, metaData.hd, metaData.video_codec_text))
		movieID = cursor.lastrowid
		# 8. Tags for Movie
		for tagID in tagIDList:
			cursor.execute('INSERT INTO Movies_Tags (movie_id, tag_id) VALUES(%d,%d);' % (movieID, tagID))
		# 9 Client MoviePosition
		if config.plugins.videodb.clientmovieposition.value:
			cursor.execute("Select client_id from Clients");
			rows = cursor.fetchall()
			for row in rows:
				cursor.execute("INSERT INTO Client_MoviePosition (movie_id, client_id, clientmovieposition) VALUES (%d,%d,%d);" % (movieID,row[0],movieposition))
		if metaData.audio_infos is not None:
			for audio in metaData.audio_infos:
				# CREATE TABLE IF NOT EXISTS Audio (audio_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, movie_id INTEGER NOT NULL, codec TEXT, language TEXT, description TEXT, codec_id INTEGER, channels INTEGER, bitrate INTEGER, audio_text TEXT)
				cursor.execute('INSERT INTO Audio (movie_id, codec, language, description,codec_id, channels, bitrate, audio_text) VALUES(%d, "%s","%s","%s",%d,%d, %d, "%s");' % (movieID, audio[0], audio[1], audio[2], audio[3], audio[4], audio[5], audio[6]))
		# finish
		return (True, movieID, pathID)
	else: # already in database
		dbModified = int(row[1])
		needDBUpdate = False
		fileInfo = os_stat(os_path.join(realpath,filename))
		if fileInfo[stat_ST_MTIME] > dbModified:
			# file has been modified since last scan
			needDBUpdate = True
#########################
#		else:
#			# check meta file if available
# Edit: Do not check the meta file, because it seems that after every play of a movie the meta file has been modified...
#			if os_path.exists(os_path.join(realpath,"%s.meta" %filename)):
#				fileInfo = os_stat(os_path.join(realpath,"%s.meta" %filename))
#				if fileInfo[stat_ST_MTIME] > dbModified:
#					# meta file has been modified since last scan
#					needDBUpdate = True
#########################
		
		if needDBUpdate:
			# something has been modified...update movie in database
			movieID = row[0]
			pathID = row[2] # return value, needed!
			modified = datetime.utcnow() # modified values in database are UTC 
			# get meta data from meta-file
			metaData = MetaData(serviceID, realpath, filename)
			# 1. Servicename
			servicenameID = getServiceNameID(cursor, metaData.serviceName)
			# 2. Directory --> not needed
			# 3. Tags
			tagIDList = getTagIDList(cursor, metaData.taglist)
			# 4. Event --> not needed
			# 5. file size of movie
			filesize = fileInfo[stat_ST_SIZE]
			# Enigma1 support
			slice = 1
			while os_path.exists(os_path.join(realpath,"%s.%03d" % (filename,slice))):
				fileInfo = os_stat(os_path.join(realpath,"%s.%03d" % (filename,slice)))
				filesize += fileInfo[stat_ST_SIZE]
				slice += 1
			# 6. Movie
			cursor.execute('UPDATE Movies SET begin=%d,name="%s",servicename_id=%d,duration=%d, description="%s", filesize = %d, recording = %d, modified ="%s", ac3=%d, dts=%d, fivepointone =%d, stereo=%d, codec="%s", container="%s", res_width=%d, res_height=%d, framerate=%f, widescreen=%d, hd=%d, video_codec_text="%s" where movie_id=%d;' % (metaData.begin, metaData.name.replace('"','""'),servicenameID,metaData.movieLength, metaData.description.replace('"','""'),filesize, recording, modified, metaData.ac3, metaData.dts, metaData.FivePointOne, metaData.stereo, metaData.codec, metaData.container, metaData.res_width, metaData.res_height, metaData.framerate, metaData.widescreen, metaData.hd, metaData.video_codec_text, movieID))
			# 7. Tags for Movie
			updateMovieTagList(cursor, movieID, tagIDList)
			# 8. Audio 
			if metaData.audio_infos is not None:
				cursor.execute('DELETE FROM Audio where movie_id = %d;' % (movieID))
				for audio in metaData.audio_infos:
					cursor.execute('INSERT INTO Audio (movie_id, codec, language, description,codec_id, channels, bitrate, audio_text) VALUES(%d, "%s","%s","%s",%d,%d, %d, "%s");' % (movieID, audio[0], audio[1], audio[2], audio[3], audio[4], audio[5], audio[6]))
			# finish
			return [False, movieID, pathID]
		return None
		


def updateMovieTagList(cursor, movieID, tagIDList):
	for tagID in tagIDList:
		try: # combination of movie_id and tag_id is unique, so it may raise an unique error here... but this is faster than checking if the combination already exists...
			cursor.execute('INSERT INTO Movies_Tags (movie_id, tag_id) VALUES(%d,%d);' % (movieID, tagID))
		except: pass #  movie_id tag_id is already in db...move to next tagID

def updateFinishedRecordTimerInDatabase(cursor, path, filename):
	# the only thing we need to do here is to update the movie-duration, filesize and audio-informations after a RecordTimer has ended and set recording flag to 0
	realpath = os_path.realpath(path)
	ismounted, mountpoint = getMountPoint(realpath)
	relativePath = os_path.relpath(realpath, mountpoint)
	if relativePath == ".": # mountpoint == relativePath
		relativePath = ""
	client_id = ClientID.instance.getClientID()
	cursor.execute('SELECT movie_id, movies.path_id, serviceid FROM Movies INNER JOIN Paths ON movies.path_id = paths.path_id INNER JOIN mountpoints on Paths.link_id = Mountpoints.link_id WHERE filename = ? and paths.path = ? and mountpoints.mountpoint = ? and mountpoints.client_id = ?;', (filename, relativePath, mountpoint, client_id))
	#cursor.execute('SELECT movie_id, movies.path_id FROM Movies WHERE filename = "%s" and directories.directory = "%s";' % (filename, realpath))
	row = cursor.fetchone()
	if row is not None:
		movieID = row[0]
		pathID = row[1] # return value, needed!
		serviceID = row[2]
		modified = datetime.utcnow() # modified values in database are UTC
		filesize = 0
		# dummy and fast fix....
		if os_path.exists(os_path.join(realpath,filename)): 
			fileInfo = os_stat(os_path.join(realpath,filename))
			filesize = fileInfo[stat_ST_SIZE]
		metaData = MetaData(serviceID, realpath, filename)	
		cursor.execute('UPDATE Movies SET duration = %d, filesize = %d, modified = "%s", recording = 0, ac3=%d, dts=%d, fivepointone =%d, stereo=%d, codec="%s", container="%s", res_width=%d, res_height=%d, framerate=%f, widescreen=%d, hd=%d, video_codec_text="%s" WHERE movie_id = %d;' % (metaData.movieLength, filesize, modified, metaData.ac3, metaData.dts, metaData.FivePointOne, metaData.stereo, metaData.codec, metaData.container, metaData.res_width, metaData.res_height, metaData.framerate, metaData.widescreen, metaData.hd, metaData.video_codec_text, movieID))
		# 8. Audio 
		if metaData.audio_infos is not None:
			cursor.execute('DELETE FROM Audio where movie_id = %d;' % (movieID))
			for audio in metaData.audio_infos:
				cursor.execute('INSERT INTO Audio (movie_id, codec, language, description,codec_id, channels, bitrate, audio_text) VALUES(%d, "%s","%s","%s",%d,%d, %d, "%s");' % (movieID, audio[0], audio[1], audio[2], audio[3], audio[4], audio[5], audio[6]))
		
		
		return [False, movieID, pathID]
	else:
		# it seems that the scanner missed the start of the Recordtimer --> add new to database
		proceed = True
		result = None
		if config.plugins.videodb.recordtimerscanner_only_in_existing_directory.value:
			cursor.execute('SELECT paths.path_id FROM Paths INNER JOIN mountpoints ON Paths.link_id = Mountpoints.link_id WHERE mountpoints.client_id = ? and paths.path = ? and mountpoints.mountpoint = ?;' , (client_id, relativePath, mountpoint));
			r = cursor.fetchone()
			if r is None:
				proceed = False
		if proceed:
			return addToDatabase(cursor, path, filename, recording = 0)
		else:
			return None # FIXME --> check this !

def deleteMovieInDatabase(path, filename):
	result = False
	connection, error = OpenDatabaseForWriting()
	if connection is not None:
		realpath = os_path.realpath(path)
		connection.text_factory = str
		cursor = connection.cursor()
		realpath = os_path.realpath(path)
		ismounted, mountpoint = getMountPoint(realpath)
		relativePath = os_path.relpath(realpath, mountpoint)
		if relativePath == ".": # mountpoint == relativePath
			relativePath = ""
		client_id = ClientID.instance.getClientID()
		cursor.execute('SELECT movie_id FROM Movies INNER JOIN Paths ON movies.path_id = paths.path_id INNER JOIN mountpoints on Paths.link_id = Mountpoints.link_id WHERE filename = ? and paths.path = ? and mountpoints.mountpoint = ? and mountpoints.client_id = ?;', (filename, relativePath, mountpoint, client_id))
		row = cursor.fetchone()
		if row is not None:
			movieID = row[0]
			cursor.execute('DELETE FROM Movies WHERE movie_id = %d;' % (movieID)) # triggers will do the rest :-)
			connection.commit()
			result = True
			deleteNotNeededPhysicalImageFiles()
		cursor.close()  
		connection.close()
	if result:
		return movieID
	else:
		return None

def moveMovieInDatabase(from_path, from_filename, to_path):
	realpath = os_path.realpath(from_path)
	ismounted, mountpoint = getMountPoint(realpath)
	relativePath = os_path.relpath(realpath, mountpoint)
	if relativePath == ".": # mountpoint == relativePath
		relativePath = ""
	client_id = ClientID.instance.getClientID()
	connection, error = OpenDatabaseForWriting()
	if connection is not None:
		connection.text_factory = str
		cursor = connection.cursor()
		cursor.execute('SELECT movie_id FROM Movies INNER JOIN Paths ON movies.path_id = paths.path_id INNER JOIN mountpoints on Paths.link_id = Mountpoints.link_id WHERE filename = ? and paths.path = ? and mountpoints.mountpoint = ? and mountpoints.client_id = ?;', (from_filename, relativePath, mountpoint, client_id))
		row = cursor.fetchone()
		if row is not None:
			movieID = row[0]
			pathID = getPathID(cursor, to_path)
			modified = datetime.utcnow() # modified values in database are UTC 
			cursor.execute('UPDATE Movies SET path_id = %d, modified = "%s" WHERE movie_id = %d;' % (pathID, modified, movieID))
			connection.commit()
		cursor.close()  
		connection.close()


def updateMovieWithTMDbMovieData(movieID, eventID, cover, thumb, tmdb_movie_id, wallpaper_filename, release, rating, cover_middle_filename, runtime):
	sqlExecuteCommand('UPDATE Movies SET event_id = %d, cover_filename = "%s", thumb_filename = "%s", tmdb_movie_id = %d, wallpaper="%s", released = "%s", rating = "%s", cover_middle_filename = "%s", runtime = "%s" WHERE movie_id = %d;' % (eventID, cover, thumb, tmdb_movie_id, wallpaper_filename, release, rating, cover_middle_filename, runtime, movieID))

def getStudioIDList(cursor, studiolist):
	studioIDList = []
	for studio in studiolist:
		cursor.execute('SELECT studio_id FROM Studios WHERE studio = "%s";' % (studio.replace('"','""')))
		row = cursor.fetchone()
		if row is None:
				cursor.execute('INSERT INTO Studios (studio) VALUES("%s");' % (studio.replace('"','""')))
				studioIDList.append(cursor.lastrowid)
		else:
				studioIDList.append(row[0])
	return studioIDList

def updateMovieStudioList(cursor, movieID, studioIDList):
	for studioID in studioIDList:
		try: # combination of movie_id and studio_id is unique, so it may raise an unique error here... but this is faster than checking if the combination already exists...
			cursor.execute('INSERT INTO Movies_Studios (movie_id, studio_id) VALUES(%d,%d);' % (movieID, studioID))
		except: pass #  movie_id studio_id is already in db...move to next studioID


def getPersonID(cursor, name, thumb):
	cursor.execute('SELECT person_id FROM Persons WHERE name = "%s";' % (name.replace('"','""')))
	row = cursor.fetchone()
	if row is None:
		cursor.execute('INSERT INTO Persons (name, thumb) VALUES("%s","%s");' % (name.replace('"','""'), thumb.replace('"','""')))
		return cursor.lastrowid
	else:
		return row[0]

def updatePersonImageInDatabase(personID, thumb):
	sqlExecuteCommand('UPDATE Persons SET thumb = "%s" WHERE person_id = %d;' % (thumb, personID))



def addMovieCollectionToDatabase(cursor, check, tmdb_collection_id, name, overview, thumb_filename, cover_filename, cover_middle_filename, wallpaper):
	if check:
		cursor.execute('SELECT tmdb_collection_id FROM Movie_Collections WHERE tmdb_collection_id = %d;' % (tmdb_collection_id))
		row = cursor.fetchone()
	else:
		row = None
	if row is None:
		cursor.execute('INSERT INTO Movie_Collections (tmdb_collection_id, name, overview, thumb_filename, cover_filename, cover_middle_filename, wallpaper) VALUES(%d, "%s","%s", "%s","%s", "%s","%s");' % (tmdb_collection_id, name.replace('"','""'),overview.replace('"','""'),thumb_filename, cover_filename, cover_middle_filename, wallpaper))
		return True
	else:
		return False
	
def deleteMovieCollection(tmdb_collection_id):
	connection, error = OpenDatabaseForWriting()
	if connection is not None:
		connection.text_factory = str
		cursor = connection.cursor()
		cursor.execute("Select cover_filename, thumb_filename, cover_middle_filename, wallpaper from Movie_Collections WHERE tmdb_collection_id = %d;" % (tmdb_collection_id))
		row = cursor.fetchone()
		if row:
			if row[0]:
				cover = os_path.join(ClientID.instance.getImagePath(), row[0])
			else:
				cover = ""
			if row[1]:
				thumb = os_path.join(ClientID.instance.getImagePath(), row[1])
			else:
				thumb = ""
			if row[3]:
				wallpaper = os_path.join(ClientID.instance.getImagePath(), row[3])
			else:
				wallpaper = ""

			if row[2]:
				cover_middle = os_path.join(ClientID.instance.getImagePath(), row[2])
			else:
				cover_middle = ""
			if cover and os_path.exists(cover):
				os_remove(cover)
			if thumb and os_path.exists(thumb):
				os_remove(thumb)
			if wallpaper and os_path.exists(wallpaper):
				os_remove(wallpaper)
			if cover_middle and os_path.exists(cover_middle):
				os_remove(cover_middle)	
		cursor.execute('Update Movies set tmdb_collection_id = 0 WHERE tmdb_collection_id = %d;' % (tmdb_collection_id))
		cursor.execute('DELETE FROM Movie_Collections WHERE tmdb_collection_id = %d;' % tmdb_collection_id) 
		connection.commit()
		cursor.close()  
		connection.close()
	
def addCrewToDatabase(cursor, movieID, personID, job, character, tmdb_order):
	try: # combination of movieID, personID and job is unique, so it may raise an unique error here... but this is faster than checking if the combination already exists...
		cursor.execute('INSERT INTO Crew (movie_id, person_id, job, character, tmdb_order) VALUES(%d, %d, "%s","%s", %d);' % (movieID, personID, job.replace('"','""'), character.replace('"','""'),tmdb_order ))
	except: pass # combination of movieID, personID and job is already in db...

def updateMovieName(movieID, name):
	sqlExecuteCommand('UPDATE MOVIES SET name = "%s" WHERE movie_id = %d;' % (name.replace('"','""'), movieID))

def deleteNotNeededPhysicalImageFiles():
	# my triggers are saving image-paths to images_to_delete when data rows in movies or persons were deleted...delete now physical files...
	connection, error = OpenDatabaseForWriting()			
	if connection is not None:
		cursor = connection.cursor()
		cursor.execute('SELECT filename FROM images_to_delete;');
		for row in cursor:
			filename = os_path.join(ClientID.instance.getImagePath(), row[0])
			if os_path.exists(filename):
				os_remove(filename)
		cursor.execute('DELETE FROM images_to_delete;');
		connection.commit()
		cursor.close() 
		connection.close()


def deleteTMDbDataFromMovieInDatabase(movieID, current_eventID):
	metaData = None
	eventID = -1
	connection, error = OpenDatabaseForWriting()
	if connection is not None:
		connection.text_factory = str
		cursor = connection.cursor()
		cursor_delete = connection.cursor()
		cursor.execute("SELECT serviceid, filename, paths.path, cover_filename, thumb_filename, wallpaper, cover_middle_filename, mountpoints.mountpoint FROM movies INNER JOIN Paths ON movies.path_id = paths.path_id INNER JOIN mountpoints on Paths.link_id = Mountpoints.link_id WHERE movie_ID = %d;" % movieID)
		row = cursor.fetchone()
		if row:
			serviceID = row[0]
			filename = row[1]
			path = os_path.join(row[7], row[2])
			if row[3]:
				cover = os_path.join(ClientID.instance.getImagePath(), row[3])
			else:
				cover = ""
			if row[4]:
				thumb = os_path.join(ClientID.instance.getImagePath(), row[4])
			else:
				thumb = ""
			if row[5]:
				wallpaper = os_path.join(ClientID.instance.getImagePath(), row[5])
			else:
				wallpaper = ""

			if row[6]:
				cover_middle = os_path.join(ClientID.instance.getImagePath(), row[6])
			else:
				cover_middle = ""
			cursor_delete.execute('DELETE FROM crew WHERE movie_id = %d;' % movieID) # trigger will delete persons
			cursor_delete.execute('DELETE FROM movies_studios WHERE movie_id = %d;' % movieID) # trigger will delete studios
			cursor_delete.execute('DELETE FROM movies_tags WHERE movie_id = %d;' % movieID) 

			if cover and os_path.exists(cover):
				os_remove(cover)
			if thumb and os_path.exists(thumb):
				os_remove(thumb)
			if wallpaper and os_path.exists(wallpaper):
				os_remove(wallpaper)
			if cover_middle and os_path.exists(cover_middle):
				os_remove(cover_middle)	
			
			cursor_delete.execute('DELETE FROM Playlist_Movies WHERE movie_id = %d;' % movieID)
			realpath = os_path.realpath(path)
			eventID = -1
			metaData = MetaData(serviceID, realpath, filename)
			if metaData.event:
				if current_eventID == -1:
					cursor.execute('INSERT INTO Events (eventname, description, extdescription, duration,begintime) VALUES("%s","%s","%s",%d,%d);' % (metaData.event.getEventName().replace('"','""'),metaData.event.getShortDescription().replace('"','""'), metaData.event.getExtendedDescription().replace('"','""'),metaData.event.getDuration(),metaData.event.getBeginTime()))
					eventID = cursor.lastrowid
				else:
					cursor.execute('UPDATE events set eventname = "%s", description = "%s", extdescription = "%s",  duration = %d, begintime = %d where event_id = %d;' % (metaData.event.getEventName().replace('"','""'),metaData.event.getShortDescription().replace('"','""'), metaData.event.getExtendedDescription().replace('"','""'),metaData.event.getDuration(),metaData.event.getBeginTime(),current_eventID))
					eventID = current_eventID

			cursor.execute('UPDATE Movies set name = "%s", event_id = %d, description = "%s", thumb_filename = "", cover_filename = "", tmdb_movie_id = NULL, tmdb_collection_id = 0 WHERE movie_id = %d;' % (metaData.name.replace('"','""'),eventID, metaData.description.replace('"','""'),movieID))

		connection.commit()
		cursor.close() 
		cursor_delete.close()
		connection.close()
		deleteNotNeededPhysicalImageFiles()
	return metaData, eventID

def updateDirname(directoryID, directoryName):
	connection = OpenDatabase()
	if connection is not None:
		connection.text_factory = str
		cursor = connection.cursor()
		cursor.execute('UPDATE directories SET name = "%s" WHERE directory_id = %d;' % (directoryName, directoryID))
		connection.commit()
		cursor.close() 
		connection.close()
		
def resetDirname(directoryID):
	connection = OpenDatabase()
	if connection is not None:
		connection.text_factory = str
		cursor = connection.cursor()
		cursor.execute('UPDATE directories SET name = directory WHERE directory_id = %d;' % directoryID)
		connection.commit()
		cursor.close() 
		connection.close()		
		
def getDirectoryList():
	connection = OpenDatabase()
	if connection is not None:
		connection.text_factory = str
		cursor = connection.cursor()
		cursor.execute("SELECT path_id, path, mountpoint FROM paths INNER JOIN Mountpoints ON paths.link_id = mountpoints.link_id WHERE mountpoints.client_id = %d ORDER BY mountpoint,path;" %(ClientID.instance.getClientID()))
		rows = [(str(row[0]),os_path.join(row[2],row[1])) for row in cursor]
		rows.insert(0,("-1",_("All Folders")),)
		cursor.close()  
		connection.close()
		return rows
	else:
		return []


def getDirectoryNameList():
	connection = OpenDatabase()
	if connection is not None:
		connection.text_factory = str
		cursor = connection.cursor()
		cursor.execute("SELECT mountpoint, path FROM paths INNER JOIN Mountpoints ON paths.link_id = mountpoints.link_id WHERE mountpoints.client_id = %d ORDER BY mountpoint,path;" %(ClientID.instance.getClientID()))
		rows = [os_path.join(row[0],row[1]) for row in cursor]
		cursor.close()  
		connection.close()
		return rows
	else:
		return []

def removeDirectoryFromDatabase(directoryID):
	connection, error = OpenDatabaseForWriting()
	if connection is not None:
		cursor = connection.cursor()
		cursor.execute('DELETE FROM movies WHERE directory_id = %d;' % (directoryID)) # triggers will do the rest
		cursor.execute('DELETE FROM directories WHERE directory_id = %d;' % (directoryID)) 
		connection.commit()
		cursor.close() 
		connection.close()
		deleteNotNeededPhysicalImageFiles()

def getTMDbWriters(movieID, title = True):
	writers = ""
	connection = OpenDatabase()
	if connection is not None:
		connection.text_factory = str
		cursor = connection.cursor()
		cursor.execute('SELECT name FROM crew INNER JOIN persons ON crew.person_id = persons.person_id WHERE job="Screenplay" AND movie_id = %d;'%(movieID))
		data = ""
		count = 0
		for row in cursor:
			data +=  row[0] + ", "
			count += 1
		cursor.close()  
		connection.close()
		if data:
			if title:
				if count == 1:
					writers = _("Writer: %s\n") % data[:-2] 
				else:
					writers = _("Writers: %s\n") % data[:-2]
			else:
				writers = data[:-2] 
	return writers
	
def getTMDbActors(movieID, title = True):
	# return only the first 3 actors
	actors = ""
	connection = OpenDatabase()
	if connection is not None:
		connection.text_factory = str
		cursor = connection.cursor()
		cursor.execute('SELECT name FROM crew INNER JOIN persons ON crew.person_id = persons.person_id WHERE job="Actor" AND movie_id = %d ORDER BY tmdb_order LIMIT 3;'%(movieID))
		data = ""
		for row in cursor:
			data +=  row[0] + ", "
		cursor.close()  
		connection.close()
		if data:
			if title:
				actors = _("Actors: %s\n") % data[:-2] 
			else:
				actors = data[:-2] 
	return actors

	
def getTMDbDirectors(movieID, title = True):
	directors = ""
	connection = OpenDatabase()
	if connection is not None:
		connection.text_factory = str
		cursor = connection.cursor()
		cursor.execute('SELECT name FROM crew INNER JOIN persons ON crew.person_id = persons.person_id WHERE job="Director" AND movie_id = %d;'%(movieID))
		data = ""
		count = 0
		for row in cursor:
			data +=  row[0] + ", "
			count += 1
		cursor.close()  
		connection.close()
		if data:
			if title:
				if count == 1:
					directors = _("Director: %s\n") % data[:-2] 
				else:
					directors = _("Directors: %s\n") % data[:-2]
			else:
				directors = data[:-2] 
	return directors

def renameMovieInDatabase(movieID, name):
	connection, error = OpenDatabaseForWriting()
	if connection is not None:
		cursor = connection.cursor()
		cursor.execute('UPDATE Movies SET name = "%s" WHERE movie_id = %d;' % (name, movieID))
		connection.commit()
		cursor.close() 
		connection.close()
		return True, ""
	else:
		return False, error


def getSerieID(cursor, tvdb_seriesID, serieName, serieOverview, banner, banner_small, poster, poster_thumb, wallpaper, status, rating, network, genre, firstaired, runtime):
	serieID = 0
	cursor.execute('SELECT serie_id FROM Series WHERE tvdb_serie_id = %d;' % tvdb_seriesID)
	row = cursor.fetchone()
	if row is not None:
		serieID = row[0]
	else:
		cursor.execute('INSERT INTO Series (name, overview, tvdb_serie_id, banner, banner_small, poster, thumb_poster, wallpaper, status, rating, network, genre, firstaired, runtime) VALUES("%s","%s", %d, "%s", "%s", "%s", "%s", "%s", "%s", "%s", "%s", "%s", "%s", %d);' % (serieName.replace('"','""'), serieOverview.replace('"','""'), tvdb_seriesID, banner.replace('"','""'), banner_small.replace('"','""'), poster.replace('"','""'), poster_thumb.replace('"','""'),  wallpaper.replace('"','""'),  status.replace('"','""'), rating.replace('"','""'), network.replace('"','""'), genre.replace('"','""'), firstaired.replace('"','""'), int(runtime)))
		serieID =  cursor.lastrowid
	return serieID

def updateMoviesSeries(cursor, movieID, serieID, season, episode, writer, director, episodename, firstaired, rating, overview, tvdb_episode_id):
	try: # combination of movie_id and serie_id is unique, so it may raise an unique error here... but this is faster than checking if the combination already exists...
		cursor.execute('INSERT INTO Movies_Series (movie_id, serie_id, season, episode, writer, director, episodename, firstaired, rating, overview, tvdb_episode_id) VALUES(%d, %d, %d, %d, "%s", "%s", "%s", "%s", "%s", "%s", %d);' % (movieID, serieID, season, episode, writer.replace('"','""'), director.replace('"','""'), episodename.replace('"','""'), firstaired.replace('"','""'), rating.replace('"','""'), overview.replace('"','""'), tvdb_episode_id))
	except: pass #  movie_id serie is already in db...
		
def isSerie(movieID):
	serieID = None
	connection = OpenDatabase()
	if connection is not None:
		connection.text_factory = str
		cursor = connection.cursor()	
		cursor.execute('Select serie_id from movies_series where movie_id = %d ;' % (movieID))
		row = cursor.fetchone()
		if row is not None:
			serieID = row[0]
		cursor.close() 
		connection.close()
	return serieID


def deleteTVDbDataFromMovieInDatabase(movieID, current_eventID):
	eventID = -1
	metaData = None
	connection, error = OpenDatabaseForWriting()
	if connection is not None:
		cursor = connection.cursor()
		cursor_delete = connection.cursor()
		serieID = isSerie(movieID)
		if serieID:
			cursor_delete.execute('DELETE FROM movies_series WHERE movie_id = %d;' % movieID)
			cursor.execute("SELECT serviceid, filename, paths.path, mountpoints.mountpoint FROM movies INNER JOIN Paths ON movies.path_id = paths.path_id INNER JOIN mountpoints on Paths.link_id = Mountpoints.link_id WHERE movie_ID = %d;" % movieID)
			row = cursor.fetchone()
			if row:
				serviceID = row[0]
				filename = row[1]
				path = os_path.join(row[3], row[2])
				realpath = os_path.realpath(path)
				eventID = -1
				metaData = MetaData(serviceID, realpath, filename)
				if metaData.event:
					if current_eventID == -1:
						cursor.execute('INSERT INTO Events (eventname, description, extdescription, duration,begintime) VALUES("%s","%s","%s",%d,%d);' % (metaData.event.getEventName().replace('"','""'),metaData.event.getShortDescription().replace('"','""'), metaData.event.getExtendedDescription().replace('"','""'),metaData.event.getDuration(),metaData.event.getBeginTime()))
						eventID = cursor.lastrowid
					else:
						cursor.execute('UPDATE events set eventname = "%s", description = "%s", extdescription = "%s",  duration = %d, begintime = %d where event_id = %d;' % (metaData.event.getEventName().replace('"','""'),metaData.event.getShortDescription().replace('"','""'), metaData.event.getExtendedDescription().replace('"','""'),metaData.event.getDuration(),metaData.event.getBeginTime(),current_eventID))
						eventID = current_eventID
				cursor.execute('UPDATE Movies set name = "%s", event_id = %d, description = "%s", thumb_filename = "", cover_filename = "", tmdb_movie_id = NULL WHERE movie_id = %d;' % (metaData.name.replace('"','""'),eventID, metaData.description.replace('"','""'),movieID))
		connection.commit()
		cursor.close() 
		cursor_delete.close()
		connection.close()
	return metaData, eventID

def updateDirectoriesInotifyStatus(dirlist):
	connection = OpenDatabase()
	if connection is not None:
		connection.text_factory = str
		cursor = connection.cursor()
		for item in dirlist:
			cursor.execute('UPDATE Directories SET inotify_scanner = %d where directory_id = %d;' % (item[2], item[0]))
		connection.commit()
		cursor.close() 
		connection.close()

def getVideoDataFilterDirectories(directory, videoType, recursive = False):
	movieList = []
	connection = OpenDatabase(dictFactory = True)
	if connection is not None:
		a = len(directory)
		cursor = connection.cursor()
		if videoType == 1:
		
			if not recursive:
				cursor.execute('SELECT %d as mode, movies.name, movies.movie_id, movies.serviceid, movies.filename, movies.path_id, movies.movieposition, movies.duration, servicenames.servicename, movies.begin, movies.description, movies.event_id, movies.filesize, events.extdescription, movies.recording, movies.cover_filename, movies.thumb_filename, movies.tmdb_movie_id, movies.ismovie, paths.path, mountpoints.mountpoint, events.begintime FROM Movies INNER JOIN Servicenames ON movies.servicename_id = servicenames.servicename_id INNER JOIN Paths ON movies.path_id = paths.path_id INNER JOIN mountpoints on Paths.link_id = Mountpoints.link_id LEFT OUTER JOIN Events ON movies.event_id = events.event_id LEFT OUTER JOIN movies_series on movies_series.movie_id = movies.movie_id WHERE movies.visible = 1 and mountpoints.client_id = %d and movies.tmdb_movie_id IS NULL and movies_series.movie_series_id IS NULL and mountpoints.mountpoint || "/" || paths.path="%s";' % (99,ClientID.instance.getClientID(), directory))
				print "----nicht recursive!"
			else:
				cursor.execute('SELECT %d as mode, movies.name, movies.movie_id, movies.serviceid, movies.filename, movies.path_id, movies.movieposition, movies.duration, servicenames.servicename, movies.begin, movies.description, movies.event_id, movies.filesize, events.extdescription, movies.recording, movies.cover_filename, movies.thumb_filename, movies.tmdb_movie_id, movies.ismovie, paths.path, mountpoints.mountpoint, events.begintime FROM Movies INNER JOIN Servicenames ON movies.servicename_id = servicenames.servicename_id INNER JOIN Paths ON movies.path_id = paths.path_id INNER JOIN mountpoints on Paths.link_id = Mountpoints.link_id LEFT OUTER JOIN Events ON movies.event_id = events.event_id LEFT OUTER JOIN movies_series on movies_series.movie_id = movies.movie_id WHERE movies.visible = 1 and mountpoints.client_id = %d and movies.tmdb_movie_id IS NULL and movies_series.movie_series_id IS NULL and SUBSTR(mountpoints.mountpoint || "/" || paths.path,1,%d) ="%s";' % (99,ClientID.instance.getClientID(), a, directory))

		else:
			if not recursive:
				print "----nicht recursive!"
				cursor.execute('SELECT %d as mode, movies.name, movies.movie_id, movies.serviceid, movies.filename, movies.path_id, movies.movieposition, movies.duration, servicenames.servicename, movies.begin, movies.description, movies.event_id, movies.filesize, events.extdescription, movies.recording, movies.cover_filename, movies.thumb_filename, movies.tmdb_movie_id, movies.ismovie, paths.path, mountpoints.mountpoint, events.begintime FROM Movies INNER JOIN Servicenames ON movies.servicename_id = servicenames.servicename_id INNER JOIN Paths ON movies.path_id = paths.path_id INNER JOIN mountpoints on Paths.link_id = Mountpoints.link_id LEFT OUTER JOIN Events ON movies.event_id = events.event_id LEFT OUTER JOIN movies_series on movies_series.movie_id = movies.movie_id WHERE movies.visible = 1 and mountpoints.client_id = %d and movies.tmdb_movie_id IS NULL and movies_series.movie_series_id IS NULL and mountpoints.mountpoint || "/" || paths.path ="%s";' % (99,ClientID.instance.getClientID(), directory))
			else:
				cursor.execute('SELECT %d as mode, movies.name, movies.movie_id, movies.serviceid, movies.filename, movies.path_id, movies.movieposition, movies.duration, servicenames.servicename, movies.begin, movies.description, movies.event_id, movies.filesize, events.extdescription, movies.recording, movies.cover_filename, movies.thumb_filename, movies.tmdb_movie_id, movies.ismovie, paths.path, mountpoints.mountpoint, events.begintime FROM Movies INNER JOIN Servicenames ON movies.servicename_id = servicenames.servicename_id INNER JOIN Paths ON movies.path_id = paths.path_id INNER JOIN mountpoints on Paths.link_id = Mountpoints.link_id LEFT OUTER JOIN Events ON movies.event_id = events.event_id LEFT OUTER JOIN movies_series on movies_series.movie_id = movies.movie_id WHERE movies.visible = 1 and mountpoints.client_id = %d and movies.tmdb_movie_id IS NULL and movies_series.movie_series_id IS NULL and SUBSTR(mountpoints.mountpoint || "/" || paths.path,1,%d) ="%s";' % (99,ClientID.instance.getClientID(), a, directory))
		movieList = []
		for row in cursor:
			movieList.extend(((row,),))
		cursor.close() 
		connection.close()
	return movieList


def getSettingsDictFromDatabase(settingname):
	settings = {}
	connection = OpenDatabase()
	if connection is not None:
		connection.text_factory = str
		cursor = connection.cursor()
		cursor.execute('select value from Settings where name = "%s" and client_id = %d;' % (settingname, ClientID.instance.getClientID()))
		row = cursor.fetchone()
		if row and str(row[0]) != "":
			settings = pickle_loads(str(row[0]))
		cursor.close() 
		connection.close()
	return settings

def saveSettingsDictToDatabase(settingname, value):
	connection, error = OpenDatabaseForWriting()
	if connection is not None:
		cursor = connection.cursor()
		pdata = pickle_dumps(value, pickle_HIGHEST_PROTOCOL)
		data = sqlite_binary(pdata)
		cursor.execute('UPDATE Settings SET value = ? WHERE name = ? and client_id = ?;' , (data, settingname, ClientID.instance.getClientID()))
		connection.commit()
		cursor.close()  
		connection.close()



def setMovieStatusInDatabase(status, movieID):
		connection, error = OpenDatabaseForWriting()
		if connection is not None:
			movieposition = 0
			cursor = connection.cursor()
			if config.plugins.videodb.clientmovieposition.value:
				if status:
					cursor.execute("SELECT duration FROM movies WHERE movie_ID = %d;" % movieID)
					movieposition = cursor.fetchone()[0] * 90000
				sql = ""
				cursor.execute('select client_movieposition_id from Client_MoviePosition where movie_id = %d and client_id = %d;' % (movieID, ClientID.instance.getClientID()))
				row = cursor.fetchone()
				if row:
					sql = "UPDATE Client_MoviePosition set clientmovieposition = %d where client_movieposition_id = %d;" % (movieposition,row[0])
				else:
					sql = "INSERT INTO Client_MoviePosition (movie_id, client_id, clientmovieposition) VALUES (%d,%d,%d);" % (movieID,ClientID.instance.getClientID(),movieposition)
				cursor.execute(sql)
			else:
				if status:
					cursor.execute("UPDATE movies SET movieposition = (duration * 90000) WHERE movie_ID = %d;" % movieID) 
					cursor.execute("SELECT movieposition FROM movies WHERE movie_ID = %d;" % movieID)
					movieposition = cursor.fetchone()[0]
				else:
					cursor.execute("UPDATE movies SET movieposition = 0 WHERE movie_ID = %d;" % movieID)
			connection.commit()
			cursor.close()  
			connection.close()
			return (True, movieposition)
		else:
			return (False, error)


def setAllMovieStatusInDatabase(status, season, series_id):
		connection, error = OpenDatabaseForWriting()
		if connection is not None:
			cursor = connection.cursor()
			connection.text_factory = str
			sql = "SELECT movies.movie_id, movies.duration FROM Movies INNER JOIN Paths ON movies.path_id = paths.path_id INNER JOIN mountpoints on Paths.link_id = Mountpoints.link_id INNER JOIN movies_series on movies_series.movie_id = movies.movie_id LEFT OUTER JOIN client_movieposition ON movies.movie_id = client_movieposition.movie_id AND client_movieposition.client_id = %d WHERE mountpoints.client_id = %d and movies.visible = 1 and movies_series.season = %d and movies_series.serie_id = %d;" % (ClientID.instance.getClientID(), ClientID.instance.getClientID(), season, series_id)
			cursor.execute(sql)
			rows = cursor.fetchall()
			for row in rows:
				movieposition = 0
				movieID = row[0]
				if config.plugins.videodb.clientmovieposition.value:
					if status:
						movieposition = row[1] * 90000
					sql = ""
					cursor.execute('select client_movieposition_id from Client_MoviePosition where movie_id = %d and client_id = %d;' % (movieID, ClientID.instance.getClientID()))
					row1 = cursor.fetchone()
					if row1:
						sql = "UPDATE Client_MoviePosition set clientmovieposition = %d where client_movieposition_id = %d;" % (movieposition,row1[0])
					else:
						sql = "INSERT INTO Client_MoviePosition (movie_id, client_id, clientmovieposition) VALUES (%d,%d,%d);" % (movieID,ClientID.instance.getClientID(),movieposition)
					cursor.execute(sql)
				else:
					if status:
						cursor.execute("UPDATE movies SET movieposition = (duration * 90000) WHERE movie_ID = %d;" % movieID) 
					else:
						cursor.execute("UPDATE movies SET movieposition = 0 WHERE movie_ID = %d;" % movieID)
			connection.commit()
			cursor.close()  
			connection.close()
			return (True, "")
		else:
			return (False, error)

def deleteTVDbSeriesName(id):
	connection, error = OpenDatabaseForWriting()
	if connection is not None:
		cursor = connection.cursor()
		cursor.execute('delete from TVDbSeriesName where tvdb_series_name = %d;' % id)
		connection.commit()
		cursor.close() 
		connection.close()
		return True, ""
	else:
		return False, error

def deleteMovieFromPlaylist(id):
	connection, error = OpenDatabaseForWriting()
	if connection is not None:
		cursor = connection.cursor()
		cursor.execute('delete from Playlist_Movies where movie_id = %d;' % id)
		connection.commit()
		cursor.close() 
		connection.close()
		return True, ""
	else:
		return False, error
		
def NewScanLog(movie_id, search_type, found, text):
	connection, error = OpenDatabaseForWriting()
	if connection is not None:
		cursor = connection.cursor()
		cursor.execute('DELETE FROM ScanLogs WHERE movie_id=%d;' % movie_id)
		cursor.execute('INSERT INTO ScanLogs (movie_id, search_type, found, scanlog_text) VALUES (%d, %d, %d, "%s");' % (movie_id, search_type, found, text.replace('"','""')))
		connection.commit()
		cursor.close() 
		connection.close()
		return True, ""
		
	else:
		return False, error

def DeleteScanLog(movie_id):
	connection, error = OpenDatabaseForWriting()
	if connection is not None:
		cursor = connection.cursor()
		cursor.execute('DELETE FROM ScanLogs WHERE movie_id=%d;' % movie_id)
		connection.commit()
		cursor.close() 
		connection.close()
		return True, ""
	else:
		return False, error

def DeleteAllScanLog(search_type, found):
	connection, error = OpenDatabaseForWriting()
	if connection is not None:
		cursor = connection.cursor()
		cursor.execute('DELETE FROM ScanLogs WHERE search_type=%d and found=%d;' % (search_type, found))
		connection.commit()
		cursor.close() 
		connection.close()
		return True, ""
	else:
		return False, error

