# -*- coding: utf-8 -*-
#
# VideoDB E2
#
# Coded by Dr.Best (c) 2013
# Support: www.dreambox-tools.info
# E-Mail: dr.best@dreambox-tools.info
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Multimedia GmbH.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Multimedia GmbH.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Multimedia GmbH.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.
#

from os import path as os_path
from timer import TimerEntry
from DatabaseConnection import OpenDatabaseForWriting, OpenDatabase, ClientID
from DatabaseFunctions import addToDatabase, updateFinishedRecordTimerInDatabase, getSettingsDictFromDatabase, getMountPoint, NewScanLog
import NavigationInstance
from FileScanner import BackgroundFileScanner
from TVDb import TVDb
from ThreadQueue import ThreadQueue, THREAD_WORKING, THREAD_FINISHED
from threading import Thread
from enigma import ePythonMessagePump, eServiceReference
from Components.config import config

from TMDb import TMDb
		

class RecordTimerScanner:
	# checks database for recording flag  and clean up immediately  after enigma2 starts
	# checks if a recording is already in progress, if so add to database
	# add RecordTimer from Enigma2 to database
	# add new to db when starting recording
	# update movie-duration in database after recording
	def __init__(self, session):
		self.session = session
		init_thread = RecordTimerScannerInitThread()
		init_thread.start()
		# get timer notifications
		self.session.nav.RecordTimer.on_state_change.append(self.timerentryOnStateChange)

	def timerentryOnStateChange(self, timer):
		if hasattr(timer, "Filename") and not timer.justplay and (timer.state == TimerEntry.StateRunning or timer.state == TimerEntry.StateEnded):
			timerentryOnStateChangeThread = TimerentryOnStateChangeThread(self.session, timer)
			timerentryOnStateChangeThread.start()

class RecordTimerScannerInitThread(Thread):
	def __init__(self):
		Thread.__init__(self)
		self.messages = ThreadQueue()
		self.messagePump = ePythonMessagePump()
		self.messagePump.recv_msg.get().append(self.gotThreadMsg)
	
	def gotThreadMsg(self, msg):
		msg = self.messages.pop()
		if msg[0] == THREAD_FINISHED:
			self.messagePump.recv_msg.get().remove(self.gotThreadMsg)

	def run(self):
		mp = self.messagePump
		# check if a data-rows are still marked as recording,  this can happen when enigma2 crashed during a recording
		connection = OpenDatabase()
		if connection is not None:
			cursor = connection.cursor()
			cursor.execute('SELECT movies.filename, paths.path, mountpoints.mountpoint FROM Movies INNER JOIN Paths ON movies.path_id = paths.path_id INNER JOIN mountpoints on Paths.link_id = Mountpoints.link_id WHERE recording = %d and mountpoints.client_id = %d;' % (ClientID.instance.getClientID(), ClientID.instance.getClientID()))
			rows = cursor.fetchall()
			cursor.close()
			connection.close()
			for row in rows:
				filename = row[0]
				path = os_path.join(row[2],row[1])
				cconnection, error = OpenDatabaseForWriting(timeout = 10)
				if cconnection is not None:
					cursor = cconnection.cursor()
					updateFinishedRecordTimerInDatabase(cursor, path, filename)
					cconnection.commit()
					cursor.close()
					cconnection.close()
				else:
					print "[VideoDB] RecordTimerScanner -> updateFinishedRecordTimerInDatabase -> can not update database: %s" % error

			# if a recording starts immediately after enigma2-starting (e.g. after a crash during a recording), on_state_change for RecordTimer is not working here (recording is already running at this time!)...so check it by hand here
			if NavigationInstance.instance.getRecordings():
				for timer in NavigationInstance.instance.RecordTimer.timer_list:
					if timer.state == TimerEntry.StateRunning and not timer.justplay and hasattr(timer, "Filename"):
						recordFilename = "%s.ts" % timer.Filename
						path,filename = os_path.split(recordFilename)
						proceed = True
						result = None
						if config.plugins.videodb.recordtimerscanner_only_in_existing_directory.value:
							realpath = os_path.realpath(path)
							ismounted, mountpoint = getMountPoint(realpath)
							relativePath = os_path.relpath(realpath, mountpoint)
							if relativePath == ".": # mountpoint == relativePath
								relativePath = ""
							connection = OpenDatabase()
							if connection is not None:
								cursor = connection.cursor()
								cursor.execute('SELECT paths.path_id FROM Paths INNER JOIN mountpoints ON Paths.link_id = Mountpoints.link_id WHERE mountpoints.client_id = ? and paths.path = ? and mountpoints.mountpoint = ?;' , (ClientID.instance.getClientID(), relativePath, mountpoint));
								row = cursor.fetchone()
								cursor.close()
								if row is None:
									proceed = False
								connection.close()
						if proceed:
							connection, error = OpenDatabaseForWriting(timeout = 10)
							if connection is not None:
								cursor = connection.cursor()
								result = addToDatabase(cursor, path, filename, recording = ClientID.instance.getClientID()) 
								connection.commit()
								cursor.close()
								connection.close()
							else:
								print "[VideoDB] RecordTimerScanner -> addToDatabase --> can not update database: %s" % error
		
		self.messages.push((THREAD_FINISHED, ""))
		mp.send(0)
		
class TimerentryOnStateChangeThread(RecordTimerScannerInitThread):
	def __init__(self, session, timer):
		RecordTimerScannerInitThread.__init__(self)
		self.session = session
		self.timer = timer
		self.timerOnStateChangeModus = 1
		self.tvdb = TVDb()
		self.dataForTVMOVIE = {}
		self.seriesData = None
		self.episodeData = None
		checkTVDb = not config.plugins.videodb.tvdbAutomaticUpdate.value
		self.tmdb = TMDb(checkTVDb = checkTVDb)
		self.tmdbMovieData = None

	def gotThreadMsgTVMOVIE(self,msg):
		msg = self.messages.pop()
		if msg[0] == THREAD_FINISHED:
			self.messagePump.recv_msg.get().remove(self.gotThreadMsgTVMOVIE)
		
	def gotThreadMsg(self, msg):
		msg = self.messages.pop()
		if msg[0] == THREAD_FINISHED:
			self.messagePump.recv_msg.get().remove(self.gotThreadMsg)
			if msg[1] and msg[1][1] and self.timer.state == TimerEntry.StateEnded and config.plugins.videodb.tvdbAutomaticUpdate.value:
				movieID = msg[1][1]
				service_ref = msg[3]
				path = msg[2]
				if config.plugins.videodb.tvdbAutomaticUpdateFilterServices.value:
					tvdbAutomaticServiceUpdateList = getSettingsDictFromDatabase('tvdbAutomaticServiceUpdateList')
					proceed = False
				else:
					tvdbAutomaticServiceUpdateList = {}
					proceed = True
				self.dataForTVMOVIE = {}
				connection = OpenDatabase()
				if connection is not None:
					cursor = connection.cursor()
					if service_ref and not proceed:
						proceed = tvdbAutomaticServiceUpdateList.has_key("%s" %(service_ref))
					cursor.execute('SELECT movies.event_id, movies.name, movies.begin, movies.description, movies.filename, movies.path_id from movies where movie_id = %d;'% (movieID))
					row = cursor.fetchone()
					cursor.close()  
					connection.close()
					if row:
						self.dataForTVMOVIE["movieID"] =  movieID
						self.dataForTVMOVIE["path"] = path
						self.dataForTVMOVIE["eventID"] = row[0]
						#seriesname relation table, needed for automatic update list 
						name = self.tvdb.getRelationName(row[1].encode('utf-8','ignore'))
						self.dataForTVMOVIE["name"] =  name
						self.dataForTVMOVIE["begin"] = row[2]
						self.dataForTVMOVIE["description"] = row[3].encode('utf-8','ignore')
						self.dataForTVMOVIE["filename"] = row[4]
						self.dataForTVMOVIE["pathID"] = row[5]
						self.dataForTVMOVIE["service_ref"] = service_ref
						if not proceed:
							proceed = tvdbAutomaticServiceUpdateList.has_key(name.lower())
				if proceed and len(self.dataForTVMOVIE):
					self.tvdb.searchForSeriesNameEpisodeName(self.dataForTVMOVIE["name"], self.dataForTVMOVIE["description"], False, self.tvdbCallback)
				elif config.plugins.videodb.tmdbAutomaticUpdate.value:
					self.initializeTMDbSearch(movieID, service_ref, path)
			elif msg[1] and msg[1][1] and self.timer.state == TimerEntry.StateEnded and config.plugins.videodb.tmdbAutomaticUpdate.value:
					movieID = msg[1][1]
					service_ref = msg[3]
					path = msg[2]
					self.initializeTMDbSearch(movieID, service_ref, path)

				
				
	def tmdbCallback(self, data, infostring):
		if data:
				self.tmdbMovieData = data
				self.messagePump.recv_msg.get().append(self.gotThreadMsgTVMOVIE)
				self.timerOnStateChangeModus = 3
				self.run()
		else:
			NewScanLog(self.dataForTVMOVIE["movieID"], 2, 0, _("No unique data found"))
			print infostring
						
	def initializeTMDbSearch(self, movieID, service_ref, path):
		if config.plugins.videodb.tmdbAutomaticUpdateFilterServices.value:
			tmdbAutomaticServiceUpdateList = getSettingsDictFromDatabase('tmdbAutomaticServiceUpdateList')
			proceed = False
		else:
			tmdbAutomaticServiceUpdateList = {}
			proceed = True
		self.dataForTVMOVIE = {}
		connection = OpenDatabase()
		if connection is not None:
			cursor = connection.cursor()
			if service_ref and not proceed:
				proceed = tmdbAutomaticServiceUpdateList.has_key("%s" %(service_ref))
			cursor.execute('SELECT movies.event_id, movies.name, movies.begin, movies.description, movies.filename, movies.path_id from movies where movie_id = %d;'% (movieID))
			row = cursor.fetchone()
			cursor.close()  
			connection.close()
			if row:
				self.dataForTVMOVIE["movieID"] =  movieID
				self.dataForTVMOVIE["path"] = path
				self.dataForTVMOVIE["eventID"] = row[0]
				self.dataForTVMOVIE["begin"] = row[2]
				self.dataForTVMOVIE["description"] = row[3].encode('utf-8','ignore')
				self.dataForTVMOVIE["filename"] = row[4]
				self.dataForTVMOVIE["pathID"] = row[5]
		if proceed and len(self.dataForTVMOVIE):
			self.tmdb.searchMovie(self.timer.name,eServiceReference.idDVB, self.tmdbCallback)
	
	def tvdbCallback(self, seriesDataList, episodeDataList, error):
		if len(seriesDataList) == 1 and len(episodeDataList) == 1:
			self.messagePump.recv_msg.get().append(self.gotThreadMsgTVMOVIE)
			self.seriesData = seriesDataList[0]
			self.episodeData = episodeDataList[0]
			self.timerOnStateChangeModus = 2
			self.run()
		else:
			print "[VideoDB] No unique data found for series '%s' with episode name '%s' in TVDb..." % (self.dataForTVMOVIE["name"], self.dataForTVMOVIE["description"])
			NewScanLog(self.dataForTVMOVIE["movieID"], 1, 0, _("No unique data found"))
			if config.plugins.videodb.tmdbAutomaticUpdate.value:
				self.initializeTMDbSearch(self.dataForTVMOVIE["movieID"], self.dataForTVMOVIE["service_ref"], self.dataForTVMOVIE["path"])
	
	def run(self):
		mp = self.messagePump
		if self.timerOnStateChangeModus == 1:
			timer = self.timer
			result = None
			path = None
			try:
				path,filename = os_path.split(timer.Filename)
				proceed = True
				result = None
				if config.plugins.videodb.recordtimerscanner_only_in_existing_directory.value:
					realpath = os_path.realpath(path)
					ismounted, mountpoint = getMountPoint(realpath)
					relativePath = os_path.relpath(realpath, mountpoint)
					if relativePath == ".": # mountpoint == relativePath
						relativePath = ""
					connection = OpenDatabase()
					if connection is not None:
						cursor = connection.cursor()
						cursor.execute('SELECT paths.path_id FROM Paths INNER JOIN mountpoints ON Paths.link_id = Mountpoints.link_id WHERE mountpoints.client_id = ? and paths.path = ? and mountpoints.mountpoint = ?;' , (ClientID.instance.getClientID(), relativePath, mountpoint));
						row = cursor.fetchone()
						cursor.close()
						connection.close()
						if row is None:
							proceed = False
				if proceed:
					connection, error = OpenDatabaseForWriting(timeout=30) # give more time...
					if connection is not None:
						cursor = connection.cursor()
						if timer.state == TimerEntry.StateRunning:
							result = addToDatabase(cursor, path, "%s.ts" % filename, recording = ClientID.instance.getClientID()) 
						else: # StateEnded
							result = updateFinishedRecordTimerInDatabase(cursor, path, "%s.ts" % filename)
						connection.commit()
						cursor.close()  
						connection.close()
					else:
						print "[VideoDB] timerentryOnStateChange -> can not update database: %s" % error
				if result and result[0]:
					print "[VideoDB] Event TimerEntry: %s%s.ts has been added to database..." % (path, filename)
				elif result and not result[0]:
					print "[VideoDB] Event TimerEntry: %s%s.ts has been updated in database..." % (path, filename)
			except Exception, e:
				print "[VideoDB] Error in TimerentryOnStateChangeThread: ", str(e)
			if path:
				path = os_path.realpath(path)
			self.messages.push((THREAD_FINISHED, result,path, timer.service_ref))
			mp.send(0)
			return
		elif self.timerOnStateChangeModus == 2: # save tvdb data
			self.tvdb.saveTVDbDataToDatabase(self.seriesData, self.episodeData, self.dataForTVMOVIE["movieID"], self.dataForTVMOVIE["eventID"], self.dataForTVMOVIE["begin"], None)
			print "[VideoDB] Event TimerEntry: %s/%s has been updated with TVDb data..." % (self.dataForTVMOVIE["path"], self.dataForTVMOVIE["filename"])
		elif self.timerOnStateChangeModus == 3: # save tmdb data
			self.tmdb.saveTMBbDataToDatabase(self.tmdbMovieData, self.dataForTVMOVIE["movieID"], self.dataForTVMOVIE["eventID"], self.dataForTVMOVIE["begin"], None)
			print "[VideoDB] Event TimerEntry: %s/%s has been updated with TMDb data..." % (self.dataForTVMOVIE["path"], self.dataForTVMOVIE["filename"])
		self.messages.push((THREAD_FINISHED, [False, False, False],"", None))
		mp.send(0)
		
