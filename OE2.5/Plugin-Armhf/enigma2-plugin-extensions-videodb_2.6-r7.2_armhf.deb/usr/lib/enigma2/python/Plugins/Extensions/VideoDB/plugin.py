# -*- coding: utf-8 -*-
#
# VideoDB E2
#
# Coded by Dr.Best (c) 2013
# Support: www.dreambox-tools.info
# E-Mail: dr.best@dreambox-tools.info
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Multimedia GmbH.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Multimedia GmbH.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Multimedia GmbH.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.
#

from Plugins.Plugin import PluginDescriptor
from Components.config import config, ConfigSubsection, ConfigDirectory, ConfigText, ConfigInteger, ConfigYesNo, ConfigClock, ConfigSelection
from Screens.MessageBox import MessageBox
from Tools.HardwareInfo import HardwareInfo
from DatabaseConnection import ClientID, getPage as videodb_getPage
from MovieDataUpdater import MovieDataUpdater, MovieDataUpdaterScreen
from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_HDD

# for localized messages
from . import _

config.plugins.videodb = ConfigSubsection()
config.plugins.videodb.databasepath = ConfigDirectory(default = "")

default = ""
languageList = language.getLanguageList()
if not languageList: # no language available => display only english
	list = [ ("en", "en") ]
	default = "en"
else:
	list = [ (x[1][2].lower(),x[1][2].lower()) for x in languageList]
if default == "":
	try:
		default = config.osd.language.value.split("_")[0]
	except:
		default = "en"
	if (default, default) not in list:
		list.append((default, default))


config.plugins.videodb.language = ConfigSelection(default=default, choices=list)
config.plugins.videodb.enable_recordtimerscanner = ConfigYesNo(False)
config.plugins.videodb.recordtimerscanner_only_in_existing_directory = ConfigYesNo(True)
config.plugins.videodb.tvdbAutomaticUpdate = ConfigYesNo(False)
config.plugins.videodb.tvdbAutomaticUpdateFilterServices = ConfigYesNo(True)
config.plugins.videodb.tmdbAutomaticUpdate = ConfigYesNo(False)
config.plugins.videodb.tmdbAutomaticUpdateFilterServices = ConfigYesNo(True)
config.plugins.videodb.tvshowscreen_style = ConfigInteger(0)
config.plugins.videodb.tvshowscreen_sortorder = ConfigSelection(choices = [("0", _("Sort by date descending")), ("1", _("Sort by date ascending")), ("2", _("Sort by name descending")), ("3", _("Sort by name ascending"))], default = "3")
config.plugins.videodb.moviesscreen_style = ConfigInteger(0)
config.plugins.videodb.moviesscreen_sortorder = ConfigSelection(choices = [("0", _("Sort by date descending")), ("1", _("Sort by date ascending")), ("2", _("Sort by name descending")), ("3", _("Sort by name ascending"))], default = "0")
config.plugins.videodb.usevirtualkeyboard = ConfigYesNo(False)
config.plugins.videodb.clientmovieposition = ConfigYesNo(True)
config.plugins.videodb.searchcriteriastrong = ConfigYesNo(False)
config.plugins.videodb.checkTVDBbeforeTMDB = ConfigYesNo(False)
config.plugins.videodb.useOriginalMovieName = ConfigYesNo(False)
config.plugins.videodb.usePathNameForScanner = ConfigSelection(choices = [("0", _("Never")), ("1", _("Always")), ("2", _("Ask before scanning"))], default = "0")
config.plugins.videodb.Indicator3D = ConfigText(default="3D", fixed_size=False)

config.plugins.videodb.useTMDBFileNameParserForTSFiles = ConfigYesNo(False)

config.plugins.videodb.selectLastPlayedMovie = ConfigYesNo(False)
config.plugins.videodb.lastPlayedMovieID = ConfigInteger(0)
config.plugins.videodb.movielist_view = ConfigInteger(-1)

config.plugins.videodb.selectLastPlayedEpisode = ConfigYesNo(False)
config.plugins.videodb.lastPlayedEpisodeIDs = ConfigText(default="")


config.plugins.videodb.showMoviesinExtended = ConfigYesNo(False)
config.plugins.videodb.showMoviesinMain = ConfigYesNo(True)
config.plugins.videodb.showMoviesinPluginlist = ConfigYesNo(False)

config.plugins.videodb.showTVSeriesinExtended = ConfigYesNo(False)
config.plugins.videodb.showTVSeriesinMain = ConfigYesNo(True)
config.plugins.videodb.showTVSeriesinPluginlist = ConfigYesNo(False)

config.plugins.videodb.last_videodir = ConfigText(default=resolveFilename(SCOPE_HDD))
config.plugins.videodb.useMovieSelectionLastVideoDir = ConfigYesNo(True)
config.plugins.videodb.showCollectionsinMovielist = ConfigYesNo(True)
config.plugins.videodb.recently_added_days = ConfigInteger(default = 7, limits = (0,365)) # in days
config.plugins.videodb.standardplaylists = ConfigInteger(7)



from MoviesTVShowsScreen import MoviesScreen, TVShowScreen
from RecordTimerScanner import RecordTimerScanner
from FileScanner import FileScanner
from Setup import VideoDBConfigScreen
from MovieSelectionPlugin import MovieSelectionPlugin


def sessionstart(reason, **kwargs):
	if reason == 0 and "session" in kwargs:
		try:
			from Plugins.Extensions.WebInterface.WebChilds.Toplevel import addExternalChild
			from Plugins.Extensions.WebInterface.WebChilds.Screenpage import ScreenPage
			from twisted.python import util
			from twisted.web import static
			from os import path as os_path
			
			from WebChilds.ClientList import ClientList, SetClientName
			from WebChilds.MovieList import MovieList
			from WebChilds.VideoDBPlayer import VideoDBPlayer
			if hasattr(static.File, 'render_GET'):
				class File(static.File):
					def render_POST(self, request):
						return self.render_GET(request)
			else:
				File = static.File
			session = kwargs["session"]
			root = File(util.sibpath(__file__, "web-data"))
			root.putChild("clientList",ClientList(session))
			root.putChild("setclientname",SetClientName(session))
			root.putChild("movieList",MovieList(session))
			root.putChild("player",VideoDBPlayer(session))
			imagepath = os_path.join(config.plugins.videodb.databasepath.value ,"videodb_images")
			if os_path.exists(imagepath):
			      root.putChild('videodb_images', File(imagepath))
			addExternalChild( ("videodb", root, "VideoDB", "1", False) )
		except ImportError:
			pass # pah!

def autostart_videodb(session, **kwargs):
	
	serial = ""
	fd = open("/proc/stb/tpm/0/serial", "r")
	if fd:
		serial = fd.read()
		fd.close()
		if serial.endswith("\n"):
			serial = serial[:-1]

	ClientID(session, serial)
	FileScanner(session)
	MovieDataUpdater()
	if config.plugins.videodb.enable_recordtimerscanner.value:
		RecordTimerScanner(session)

def main_tv_series(session,**kwargs):
	d = TVShowScreen(session)
	if config.plugins.videodb.selectLastPlayedEpisode.value:
		sids = config.plugins.videodb.lastPlayedEpisodeIDs.value
		ids = sids.split(',')
		if len(ids) == 3:
			index = -2
		else:
			index = 0
	else:
		index = 0
	d.open(index)

def main_movies(session,**kwargs):
	d = MoviesScreen(session)
	if config.plugins.videodb.selectLastPlayedMovie.value:
		index = -2
	else:
		index = 0
	d.open(index, config.plugins.videodb.movielist_view.value)


def setup(session,**kwargs):
	if MovieDataUpdater.instance.isRunning():
		session.open(MessageBox, _("You are updating your movies with TMDb- and TVDb service right now...\nYou can not start the setup right now!\nTry when movie-updating is finished"), MessageBox.TYPE_ERROR)
	else:
		session.open(VideoDBConfigScreen)

def startVideoDBSetup(menuid):
	if menuid != "setup":
		return [ ]
	return [(_("VideoDB-Setup"), setup, "VideoDBSetup", None)]

	
def menu_main_tvseries(menuid, **kwargs):
	if menuid == "mainmenu":
		return [(_("TV Series"), main_tv_series, "video_db_tv_series", 46)]
	return []

def menu_main_movies(menuid, **kwargs):
	if menuid == "mainmenu":
		return [(_("Movies"), main_movies, "video_db_movies", 46)]
	return []

def main(session, **kwargs):
		session.open(VideoDBConfigScreen)
		
def movieSelectionPluginTMDB(session, service, **kwargs):
		MovieSelectionPlugin(session, service, 0, **kwargs)
		
def movieSelectionPluginTVDB(session, service, **kwargs):
		MovieSelectionPlugin(session, service, 1, **kwargs)

def Plugins(**kwargs):
	p = PluginDescriptor(where = [PluginDescriptor.WHERE_SESSIONSTART], fnc=autostart_videodb)
	p.weight = 100
	list = []
	list.append(PluginDescriptor(name="VideoDB-Setup", description=_("VideoDB-Setup"), where = [PluginDescriptor.WHERE_PLUGINMENU], icon = "video_db.png", fnc=main))
	list.append(p)
	if config.plugins.videodb.showTVSeriesinMain.value:
		list.append(PluginDescriptor(name="TV Series", description=_("Watch your recorded TV-Series"), where = [PluginDescriptor.WHERE_MENU], fnc=menu_main_tvseries))

	if config.plugins.videodb.showMoviesinMain.value:
		list.append(PluginDescriptor(name="Movies", description=_("Watch your recorded Movies"), where = [PluginDescriptor.WHERE_MENU], fnc=menu_main_movies))

	if config.plugins.videodb.showMoviesinPluginlist.value:
		list.append(PluginDescriptor(name="Movies", description=_("Watch your recorded Movies"), where = [PluginDescriptor.WHERE_PLUGINMENU], icon = "movies.png", fnc=main_movies))

	if config.plugins.videodb.showTVSeriesinPluginlist.value:
		list.append(PluginDescriptor(name="TV Series", description=_("Watch your recorded TV-Series"), where = [PluginDescriptor.WHERE_PLUGINMENU], icon = "tvseries.png", fnc=main_tv_series))

	if config.plugins.videodb.showMoviesinPluginlist.value:
		list.append(PluginDescriptor(name="Movies", description=_("Watch your recorded Movies"), where = [PluginDescriptor.WHERE_EXTENSIONSMENU], fnc=main_movies))

	if config.plugins.videodb.showTVSeriesinPluginlist.value:
		list.append(PluginDescriptor(name="TV Series", description=_("Watch your recorded TV-Series"), where = [PluginDescriptor.WHERE_EXTENSIONSMENU], fnc=main_tv_series))
		
	list.append(PluginDescriptor(name="add to VideoDB-Movies", description=_("add to VideoDB-Movie database..."), where = PluginDescriptor.WHERE_MOVIELIST, fnc=movieSelectionPluginTMDB))
	
	list.append(PluginDescriptor(name="add to VideoDB-TV Series", description=_("add to VideoDB-TV-Series database..."), where = PluginDescriptor.WHERE_MOVIELIST, fnc=movieSelectionPluginTVDB))
	list.append (PluginDescriptor(where=PluginDescriptor.WHERE_SESSIONSTART, fnc=sessionstart, needsRestart=True))
	return list
	return []

