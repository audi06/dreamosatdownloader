# -*- coding: utf-8 -*-
#
# VideoDB E2
#
# Coded by Dr.Best (c) 2013
# Support: www.dreambox-tools.info
# E-Mail: dr.best@dreambox-tools.info
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Multimedia GmbH.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Multimedia GmbH.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Multimedia GmbH.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.
#

from Screens.MessageBox import MessageBox
from Tools.BoundFunction import boundFunction
from Components.config import config

from DatabaseFunctions import addToDatabase, getMountPoint, deleteTVDbDataFromMovieInDatabase, deleteTMDbDataFromMovieInDatabase
from DatabaseConnection import OpenDatabase, OpenDatabaseForWriting, ClientID
from MovieDataUpdater import MovieDataUpdater
from TVDb import TVDbSelection
from TMDb import TMDbSelection
from os import path as os_path

# for localized messages
from . import _


def closeDialog(cur_dialog, movieID = None):
	from Screens.MovieSelection import MovieContextMenu
	if isinstance(cur_dialog, MovieContextMenu):
		cur_dialog.close()

def getMovieRow(service):
	cur = None
	path,filename = os_path.split(service.getPath())
	connection = OpenDatabase(True, True)
	if connection is not None:
		realpath = os_path.realpath(path)
		ismounted, mountpoint = getMountPoint(realpath)
		relativePath = os_path.relpath(realpath, mountpoint)
		if relativePath == ".": # mountpoint == relativePath
			relativePath = ""
		cursor = connection.cursor()
		cursor.execute('SELECT movies.name, movies.movie_id, movies.serviceid, movies.filename, movies.duration, servicenames.servicename, movies.begin, movies.description, movies.event_id, movies.filesize, movies.tmdb_movie_id, paths.path, mountpoints.mountpoint, movies_series.season, movies_series.episode FROM Movies INNER JOIN Servicenames ON movies.servicename_id = servicenames.servicename_id INNER JOIN Paths ON movies.path_id = paths.path_id INNER JOIN mountpoints on Paths.link_id = Mountpoints.link_id LEFT OUTER JOIN Movies_Series ON movies.movie_id = movies_series.movie_id WHERE movies.visible = 1 and movies.filename =? and paths.path = ? and mountpoints.mountpoint = ? and mountpoints.client_id = ? ;', (filename,relativePath, mountpoint, ClientID.instance.getClientID()))
		cur = cursor.fetchone()
		cursor.close()
		connection.close()
	return cur

def addMovie(service):
	path,filename = os_path.split(service.getPath())
	connection, error = OpenDatabaseForWriting(timeout=30) # give more time...
	if connection is not None:
		cursor = connection.cursor()
		addToDatabase(cursor, path, filename) # to do: hm, would be better in a thread...
		connection.commit()
		cursor.close()  
		connection.close()
		
def deleteDataFromMovie(session,service,mode,cur,cur_dialog,confirmed):
		if confirmed:
			movieID = cur["movie_id"]
			eventID = cur["event_id"]
			if mode and cur.has_key("season") and cur["season"] is not None:
				deleteTVDbDataFromMovieInDatabase(movieID, eventID)
			elif not mode and cur.has_key("tmdb_movie_id") and cur["tmdb_movie_id"] is not None:
				deleteTMDbDataFromMovieInDatabase(movieID, eventID)
			session.openWithCallback(boundFunction(closeDialog,cur_dialog), MessageBox, _("Movie was deleted from database..."), MessageBox.TYPE_INFO)
		else:
			closeDialog(cur_dialog)
			
def openVideoSelection(movieID, eventID, beginTime, name, path, description, serviceid, searchTitle, mode, session, cur_dialog, origname, result):
		spath = ""
		if mode:
			if result == True:
				spath = path
			session.openWithCallback(boundFunction(closeDialog,cur_dialog), TVDbSelection,movieID, eventID, beginTime, name, spath, description)
		else:
			if result == False:
				searchtitle = name
			else:
				searchtitle = searchTitle
			session.openWithCallback(boundFunction(closeDialog,cur_dialog), TMDbSelection,movieID, eventID, beginTime, searchtitle, serviceid, origname)

def MovieSelectionPlugin(session, service, mode, **kwargs):
	cur_dialog = session.current_dialog
	if MovieDataUpdater.instance.isRunning():
		session.openWithCallback(boundFunction(closeDialog,cur_dialog), MessageBox, _("You are updating your movies with TMDb- and TVDb service right now...\nTry when movie-updating is finished"), MessageBox.TYPE_ERROR)
	else:
			cur = getMovieRow(service)
			if cur and ((cur.has_key("season") and cur["season"] is not None) or (cur.has_key("tmdb_movie_id") and cur["tmdb_movie_id"] is not None)):
					if mode:
						display = _("This Recording already exists in the database with TVDb data.\nDo you want to delete the TVDb data?")
					else:
						display = _("This Recording already exists in the database with TMDb data.\nDo you want to delete the TMDb data?")
					session.openWithCallback(boundFunction(deleteDataFromMovie,session, service,mode,cur, cur_dialog),MessageBox,display, MessageBox.TYPE_YESNO)
					return
			elif cur is None:
				addMovie(service)
				cur = getMovieRow(service)
			if cur is None:
				session.openWithCallback(boundFunction(closeDialog,cur_dialog), MessageBox, _("Something went wrong...Can not add movie to database..."), MessageBox.TYPE_ERROR)
			else:
				indicator3D = config.plugins.videodb.Indicator3D.value
				movieID = cur["movie_id"]
				eventID = cur["event_id"]
				beginTime = cur["begin"]
				name = cur["name"].replace(indicator3D,'')
				path = cur["path"]
				description = cur["description"]
				serviceid = cur["serviceid"]
				if mode:
					if int(config.plugins.videodb.usePathNameForScanner.value) <= 1:
						if config.plugins.videodb.usePathNameForScanner.value == "0" : path = ""
						session.openWithCallback(boundFunction(closeDialog,cur_dialog), TVDbSelection,movieID, eventID, beginTime, name, path, description)
					else:
						session.openWithCallback(boundFunction(openVideoSelection, movieID, eventID, beginTime, name, path, description, serviceid, "", mode, session, cur_dialog, "") ,MessageBox,_("Do you want to include the pathname with the filename for video-name detection?"), MessageBox.TYPE_YESNO)
				else:
					searchTitle = path = os_path.join(cur["mountpoint"],cur["path"],name)
					origname = os_path.join(cur["mountpoint"],cur["path"],cur["name"])
					if int(config.plugins.videodb.usePathNameForScanner.value) <= 1:
						if config.plugins.videodb.usePathNameForScanner.value == "0":
							path = ""
							searchTitle = name
							origname = cur["name"]
						session.openWithCallback(boundFunction(closeDialog,cur_dialog), TMDbSelection,movieID, eventID, beginTime, searchTitle, serviceid, origname)
					else:
						session.openWithCallback(boundFunction(openVideoSelection, movieID, eventID, beginTime, name, path, description, serviceid, searchTitle, mode, session, cur_dialog, origname) ,MessageBox,_("Do you want to include the pathname with the filename for video-name detection?"), MessageBox.TYPE_YESNO)
