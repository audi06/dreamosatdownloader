# -*- coding: utf-8 -*-
#
# VideoDB E2
#
# Coded by Dr.Best (c) 2013
# Support: www.dreambox-tools.info
# E-Mail: dr.best@dreambox-tools.info
#
# This plugin is open source but it is NOT free software.
#
# This plugin may only be distributed to and executed on hardware which
# is licensed by Dream Multimedia GmbH.
# In other words:
# It's NOT allowed to distribute any parts of this plugin or its source code in ANY way
# to hardware which is NOT licensed by Dream Multimedia GmbH.
# It's NOT allowed to execute this plugin and its source code or even parts of it in ANY way
# on hardware which is NOT licensed by Dream Multimedia GmbH.
#
# If you want to use or modify the code or parts of it,
# you have to keep MY license and inform me about the modifications by mail.
#

from enigma import RT_WRAP, RT_VALIGN_CENTER, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, gFont, eListbox,eListboxPythonMultiContent, getDesktop
from Components.GUIComponent import GUIComponent
from Screens.Screen import Screen
from Components.Sources.StaticText import StaticText
from Components.ActionMap import ActionMap

from DatabaseConnection import OpenDatabase, OpenDatabaseForWriting, ClientID
from DatabaseFunctions import getMountPoint

from Screens.LocationBox import LocationBox
from Screens.MessageBox import MessageBox
from Components.config import config
from skin import TemplatedListFonts

# Check if is FullHD / UHD
DESKTOP_WIDTH = getDesktop(0).size().width()
if DESKTOP_WIDTH > 1920:
	skinFactor = 3.0
elif DESKTOP_WIDTH > 1280:
	skinFactor = 1.5
else:
	skinFactor = 1
	
# for localized messages
from . import _

class MountPointsLocationBox(LocationBox):
	def __init__(self, session, text, dir):
		inhibitDirs = ["/bin", "/boot", "/dev", "/etc", "/lib", "/proc", "/sbin", "/sys", "/usr", "/var"]
		LocationBox.__init__(self, session, text = text, currDir = dir, bookmarks = config.movielist.videodirs, autoAdd = False, editDir = False, inhibitDirs = inhibitDirs, minFree = None)
		self.skinName = "LocationBox"


class EditMountPoints(Screen):
	sz_w = getDesktop(0).size().width()
	if sz_w == 1280:
		skin = """
			<screen name="EditMountPoints" position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#00000000" title="VideoDB">
				<ePixmap position="50,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
				<ePixmap position="200,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
				<ePixmap position="350,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
				<ePixmap position="500,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
				<widget render="Label" source="key_red" position="50,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_green" position="200,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_yellow" position="350,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_blue" position="500,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget name="list" position="50,110" zPosition="2" size="1180,580" scrollbarMode="showOnDemand" transparent="0"  backgroundColor="#00000000"/>

			</screen>"""
	elif sz_w == 1024:
		skin = """
			<screen name="EditMountPoints" position="0,0" size="1024,576" flags="wfNoBorder" backgroundColor="#00000000" title="VideoDB">
				<ePixmap position="50,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
				<ePixmap position="200,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
				<ePixmap position="350,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
				<ePixmap position="500,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
				<widget render="Label" source="key_red" position="50,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_green" position="200,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_yellow" position="350,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_blue" position="500,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget name="list" position="50,110" zPosition="2" size="940,440" scrollbarMode="showOnDemand" transparent="0"  backgroundColor="#00000000"/>
			</screen>"""
	else:
		skin = """
			<screen name="EditMountPoints" position="0,0" size="720,576" flags="wfNoBorder" backgroundColor="#00000000" title="VideoDB">
				<ePixmap position="50,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
				<ePixmap position="200,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
				<ePixmap position="350,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/yellow.png" transparent="1" alphatest="on" />
				<ePixmap position="500,30" zPosition="4" size="140,40" pixmap="skin_default/buttons/blue.png" transparent="1" alphatest="on" />
				<widget render="Label" source="key_red" position="50,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_green" position="200,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_yellow" position="350,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_blue" position="500,30" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget name="list" position="50,110" zPosition="1" size="620,440" scrollbarMode="showOnDemand" transparent="0"  backgroundColor="#00000000"/>
			</screen>"""
	
	
	def __init__(self, session):
		Screen.__init__(self, session)
		self["actions"] = ActionMap(["WizardActions", "DirectionActions", "ColorActions", "EPGSelectActions"],
		{
			"back": self.close,
			"green": self.close,
			"yellow": self.add,
			"red": self.delete
			
		}, -1)
		self.title = _("Edit mountpoints")
		self["list"] = MountPointList()
		self["list"].connectSelChanged(self.selectionChanged)
		self["key_red"] = StaticText(_("Delete"))
		self["key_green"] = StaticText(_("Close"))

		self["key_yellow"] = StaticText(_("Add"))
		self["key_blue"] = StaticText("")
		
		self.add_allowed = False
		
		self.client_id = ClientID.instance.getClientID()
		if self.client_id:
			self.fillList()
		

	def fillList(self):
		self.list = []		
		connection = OpenDatabase(dictFactory = True)
		if connection is not None:
			cursor = connection.cursor()
			cursor.execute('select mountpoint_id, mountpoint, link_id, mountpoints.client_id, clients.client from mountpoints INNER JOIN Clients on mountpoints.client_id = clients.client_id')
			for row in cursor:
				cursor2 = connection.cursor()
				cursor2.execute('select mountpoint_id, mountpoint, link_id, mountpoints.client_id, clients.client from mountpoints INNER JOIN Clients on mountpoints.client_id = clients.client_id where mountpoint_id = link_id and mountpoint_id <> %d and link_id=%d order by mountpoint_id LIMIT 1' % (row["mountpoint_id"], row["link_id"] ))
				row2 = cursor2.fetchone()
				if row2 is None and row["mountpoint_id"] <> row["link_id"]:
					cursor2.execute('select mountpoint_id, mountpoint, link_id, mountpoints.client_id, clients.client from mountpoints INNER JOIN Clients on mountpoints.client_id = clients.client_id where mountpoint_id <> %d and link_id=%d order by mountpoint_id LIMIT 1' % (row["mountpoint_id"], row["link_id"] ))
					row2 = cursor2.fetchone()
				self.list.extend(((row,row2,),))
				cursor2.close()  
			cursor.close()  
			connection.close()
		self["list"].setList(self.list)
		self.selectionChanged()
		
	def selectionChanged(self):
		current = self["list"].getCurrent()
		self.add_allowed = False
		if current:
			local = current[0]
			if local:
				if local["client_id"] != self.client_id:
					connection = OpenDatabase(dictFactory = False)
					if connection is not None:
						cursor = connection.cursor()
						cursor.execute('select count(*) from mountpoints where client_id = %d and link_id=%d' % (self.client_id, local["link_id"] ))
						row = cursor.fetchone()
						if row[0] == 0:
							self["key_yellow"].setText(_("Add"))
							self.add_allowed = True
						cursor.close()  
						connection.close()
		if not self.add_allowed:
			self["key_yellow"].setText("")
			

	def add(self):
		if self.add_allowed:
			data = self["list"].getCurrent()[0]
			self.session.openWithCallback(
				self.gotPath,
				MountPointsLocationBox,
				_("Please enter a path that match the path from %s: %s") % (data["client"],data["mountpoint"]),
				"/media/"
			)
			
	def gotPath(self, res):
		if res is not None:
			if res.endswith("/"):
				path = res[:-1]
			else:
				path = res
			ismounted, mountpoint = getMountPoint(path)
			if ismounted and mountpoint == path:
				proceed = False
				connection = OpenDatabase(dictFactory = False)
				if connection is not None:
					cursor = connection.cursor()
					# link_id was already checked, no need here
					cursor.execute('select count(*) from mountpoints where client_id = %d and mountpoint="%s"' % (self.client_id, mountpoint))
					row = cursor.fetchone()
					if row[0] == 0:
						proceed = True
					cursor.close()  
					connection.close()
				if proceed:
					connection, error = OpenDatabaseForWriting(timeout=30) # give more time...
					if connection is not None:
						cursor = connection.cursor()
						data = self["list"].getCurrent()[0]
						cursor.execute('INSERT INTO Mountpoints (mountpoint, client_id, link_id) VALUES("%s",%d,%d);' % (mountpoint, self.client_id, data["link_id"]))
						connection.commit()
						cursor.close()  
						connection.close()
						self.fillList()
			else:
				self.session.open(MessageBox, _("Your selected path (%s) is not a mountpoint!\nSaving aborted.") % path, MessageBox.TYPE_ERROR)

	def delete(self):
		proceed = False
		current = self["list"].getCurrent()
		if current:
			data = current[0]
			if data:
				connection = OpenDatabase(dictFactory = False)
				if connection is not None:
					cursor = connection.cursor()
					cursor.execute('select count(*) from mountpoints where link_id=%d' % (data["link_id"]))
					row = cursor.fetchone()
					if row[0] == 1:
						# check if paths  exists for that link_id
						cursor.execute('select count(*) from paths where link_id=%d' % (data["link_id"]))
						row = cursor.fetchone()
						if row[0] == 0:
							proceed = True
						else:
							# FIXME --> ask user to delete all data realted to the mountpoint
							self.session.open(MessageBox, _("Your selected mountpoint is related to existing data in the database.\nDeleteting aborted."), MessageBox.TYPE_ERROR)
					else:
						proceed = True
					cursor.close()  
					connection.close()
				if proceed:
					self.session.openWithCallback(self.deleteConfirmed, MessageBox, _("Do you really want to delete the entry\n%s: %s\n?") % (data["client"],data["mountpoint"]))
	
	def deleteConfirmed(self, confirmed):
		if confirmed:
			connection, error = OpenDatabaseForWriting(timeout=30) # give more time...
			if connection is not None:
				cursor = connection.cursor()
				data = self["list"].getCurrent()[0]
				cursor.execute('Delete from Mountpoints where mountpoint_id = %d' % (data["mountpoint_id"]))
				connection.commit()
				cursor.close()  
				connection.close()
				self.fillList()


class MountPointList(GUIComponent, object):

	def buildListEntry(self, data, data2):
		width = self.l.getItemSize().width()
		res = [ None ]
		
		color = None
		
		if data["client_id"] == self.client_id:
			color = 0x879CC1
			
		if data2 and data2.has_key("client") and data2.has_key("mountpoint"):
			extended_string = " ( points to same paths as %s: %s )" % (data2["client"],data2["mountpoint"])
		else:
			extended_string = ""
				
		res.append((eListboxPythonMultiContent.TYPE_TEXT, 0, 0, width  , 22 * skinFactor, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, "%s: %s %s" % (data["client"],data["mountpoint"], extended_string),color))
		return res
		
	def __init__(self):
		GUIComponent.__init__(self)
		self.l = eListboxPythonMultiContent()
		self.l.setBuildFunc(self.buildListEntry)
		tlf = TemplatedListFonts()
		self.l.setFont(0, gFont(tlf.face(tlf.BIG), tlf.size(tlf.BIG)))
		self.l.setItemHeight(int(26*skinFactor))
		
		self.client_id = ClientID.instance.getClientID()
		
		self.onSelectionChanged = [ ]

	GUI_WIDGET = eListbox
	
	def postWidgetCreate(self, instance):
		instance.setContent(self.l)
		self.selectionChanged_conn = instance.selectionChanged.connect(self.selectionChanged)
		self.instance.setWrapAround(True)

	def preWidgetRemove(self, instance):
		instance.setContent(None)
		self.selectionChanged_conn = None

	def setList(self, list):
		self.l.setList(list)
	
	def getCurrentIndex(self):
		return self.instance.getCurrentIndex()
		
	def getCurrent(self):
		return self.l.getCurrentSelection()
		
	def connectSelChanged(self, fnc):
		if not fnc in self.onSelectionChanged:
			self.onSelectionChanged.append(fnc)

	def disconnectSelChanged(self, fnc):
		if fnc in self.onSelectionChanged:
			self.onSelectionChanged.remove(fnc)

	def selectionChanged(self):
		for x in self.onSelectionChanged:
			x()
