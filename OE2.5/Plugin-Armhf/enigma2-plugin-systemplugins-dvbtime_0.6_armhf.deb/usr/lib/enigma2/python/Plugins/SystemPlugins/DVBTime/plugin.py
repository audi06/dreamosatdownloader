# -*- coding: utf-8 -*-
from enigma import *
from enigma import getDesktop
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from Screens.Screen import Screen
from Screens.Standby import TryQuitMainloop, Standby
from Screens.MessageBox import MessageBox
from Screens.InputBox import InputBox
from Screens.ChoiceBox import ChoiceBox
from Components.ActionMap import ActionMap, NumberActionMap
from Components.ScrollLabel import ScrollLabel
from Components.Label import Label
from Components.GUIComponent import *
from Tools import Notifications
from Components.MenuList import MenuList
from Components.Input import Input
from Screens.Console import Console
from Plugins.Plugin import PluginDescriptor
from Components.config import config, ConfigBoolean, ConfigSubsection, ConfigText, getConfigListEntry, ConfigYesNo, ConfigSelection
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from Components.Network import iNetworkInfo
from os import environ as os_environ
import os
import gettext
from Components.Language import language
from Components.config import config
from About import DVBTimeAbout
from time import *
import time
import datetime

def localeInit():
    lang = language.getLanguage()[:2]
    os_environ["LANGUAGE"] = lang
    print "[DVBTime] found LANGUAGE=", lang
    gettext.bindtextdomain("DVBTime", resolveFilename(SCOPE_PLUGINS, "SystemPlugins/DVBTime/locale"))

def _(txt):
    t = gettext.dgettext("DVBTime", txt)
    if t == txt:
        print "[DVBTime] fallback to default translation for", txt
        t = gettext.gettext(txt)
    return t

localeInit()
language.addCallback(localeInit)

config.plugins.DVBTime = ConfigSubsection()
config.misc.useTransponderTime = ConfigBoolean(default = True)
config.plugins.DVBTime.ntpautocheck = ConfigYesNo(default = False)
config.plugins.DVBTime.tdtautocheck = ConfigYesNo(default = False)
config.plugins.DVBTime.enablemainmenu = ConfigYesNo(default = False)
config.plugins.DVBTime.showntpmessage = ConfigYesNo(default = False)
showmessage=_("Show NTP message on startup") + ": "
ntpautostart=_("NTP-Server autostart") + ": "
tdtautostart=_("DVB Time check autostart") + ": "
menuentry=_("Show Plugin in Mainmenu") + ": "
transponderupdate=_("Enigma 2 Timeupdate") + ": "

global dvbdateresult
session = None
timer = eTimer()

global ntpdateresult
session = None
timer = eTimer()

class DVBTimePlugin(Screen):
    try:
        sz_w = getDesktop(0).size().width()
    except:
        sz_w = 720
    if sz_w == 1280:
        skin = """
        <screen name="DVBTimePlugin" position="center,center" size="1280,720" title=" " flags="wfNoBorder">
        <widget source="Title" render="Label" position="80,80" size="350,30" zPosition="3" font="Regular;26" transparent="1"/>
        <ePixmap pixmap="skin_default/buttons/button_red.png" position="80,450" size="15,16" alphatest="on"/>
        <ePixmap pixmap="skin_default/buttons/button_green.png" position="80,500" size="15,16" alphatest="on"/>
        <ePixmap pixmap="skin_default/buttons/button_yellow.png" position="80,550" size="15,16" alphatest="on"/>
        <ePixmap pixmap="skin_default/buttons/button_blue.png" position="80,600" size="15,16" alphatest="on"/>
        <ePixmap pixmap="skin_default/buttons/key_menu.png" position="80,647" size="35,25" alphatest="on"/>
        <widget name="key_red" position="100,446" zPosition="1" size="500,25" font="Regular;22" halign="left" transparent="1"/>
        <widget name="key_green" position="100,496" zPosition="1" size="500,25" font="Regular;22" halign="left" transparent="1"/>
        <widget name="key_yellow" position="100,546" zPosition="1" size="500,25" font="Regular;22" halign="left" transparent="1"/>
        <widget name="key_blue" position="100,596" zPosition="1" size="500,25" font="Regular;22" halign="left" transparent="1"/>
        <widget name="key_menu" position="120,646" zPosition="1" size="400,25" font="Regular;22" halign="left" transparent="1"/>
        <ePixmap position="950,500" size="200,92" pixmap="%s" transparent="1" alphatest="blend"/>
        <widget source="session.VideoPicture" render="Pig" position="80,120" size="380,215" zPosition="3" backgroundColor="#ff000000"/>
        <widget source="menu" render="Listbox" position="550,100" size="610,260" zPosition="3" scrollbarMode="showNever">
                <convert type="TemplatedMultiContent">
                    {"template": [
                            MultiContentEntryText(pos = (10,  5), size = (608, 26), flags = RT_HALIGN_LEFT, text = 1), # index 0 is the MenuText,
                        ],
                    "fonts": [gFont("Regular", 22)],
                    "itemHeight": 35
                    }
            </convert>
        </widget>
        <widget source="menu" render="Listbox"     position="550,350" size="610,250" zPosition="3" scrollbarMode="showNever" selectionDisabled="1" transparent="1">
            <convert type="TemplatedMultiContent">
                {"template": [
                        MultiContentEntryText(pos = (0, 0), size = (610, 250), flags = RT_HALIGN_CENTER|RT_VALIGN_TOP|RT_WRAP, text = 2), # index 0 is the MenuText,
                    ],
                "fonts": [gFont("Regular", 19)],
                "itemHeight": 250
                }
            </convert>
        </widget>
        </screen>""" % ( resolveFilename(SCOPE_PLUGINS, "SystemPlugins/DVBTime/gp3.png" ))
    elif sz_w == 1024:
        skin = """
        <screen name="DVBTimePlugin" position="center,center" size="1024,576" title=" " flags="wfNoBorder">
        <widget source="Title" render="Label" position="80,80" size="350,30" zPosition="3" font="Regular;22" transparent="1"/>
        <ePixmap pixmap="skin_default/buttons/button_red.png" position="80,370" size="15,16" alphatest="on"/>
        <ePixmap pixmap="skin_default/buttons/button_green.png" position="80,400" size="15,16" alphatest="on"/>
        <ePixmap pixmap="skin_default/buttons/button_yellow.png" position="80,430" size="15,16" alphatest="on"/>
        <ePixmap pixmap="skin_default/buttons/button_blue.png" position="80,460" size="15,16" alphatest="on"/>
        <ePixmap pixmap="skin_default/buttons/key_menu.png" position="80,490" size="35,25" alphatest="on"/>
        <widget name="key_red" position="100,366" zPosition="1" size="400,25" font="Regular;20" halign="left" transparent="1"/>
        <widget name="key_green" position="100,396" zPosition="1" size="400,25" font="Regular;20" halign="left" transparent="1"/>
        <widget name="key_yellow" position="100,426" zPosition="1" size="400,25" font="Regular;20" halign="left" transparent="1"/>
        <widget name="key_blue" position="100,456" zPosition="1" size="400,25" font="Regular;20" halign="left" transparent="1"/>
        <widget name="key_menu" position="120,488" zPosition="1" size="400,25" font="Regular;20" halign="left" transparent="1"/>
        <ePixmap position="740,420" size="200,92" pixmap="%s" transparent="1" alphatest="blend"/>
        <widget source="session.VideoPicture" render="Pig" position="80,120" size="380,215" zPosition="3" backgroundColor="#ff000000"/>
        <widget source="menu" render="Listbox" position="470,100" size="470,260" zPosition="3" scrollbarMode="showNever">
                <convert type="TemplatedMultiContent">
                    {"template": [
                            MultiContentEntryText(pos = (10,  2), size = (460, 26), flags = RT_HALIGN_LEFT, text = 1), # index 0 is the MenuText,
                        ],
                    "fonts": [gFont("Regular", 20)],
                    "itemHeight": 30
                    }
            </convert>
        </widget>
        <widget source="menu" render="Listbox"     position="470,300" size="470,100" zPosition="3" scrollbarMode="showNever" selectionDisabled="1" transparent="1">
            <convert type="TemplatedMultiContent">
                {"template": [
                        MultiContentEntryText(pos = (0, 0), size = (470,100), flags = RT_HALIGN_CENTER|RT_VALIGN_TOP|RT_WRAP, text = 2), # index 0 is the MenuText,
                    ],
                "fonts": [gFont("Regular", 18)],
                "itemHeight": 100
                }
            </convert>
        </widget>
        </screen>""" % ( resolveFilename(SCOPE_PLUGINS, "SystemPlugins/DVBTime/gp3.png" ))
    else:
        skin = """
        <screen name="DVBTimePlugin" position="center,center" size="560,400" title=" ">
        <ePixmap pixmap="skin_default/buttons/red.png" position="0,0" size="140,40" alphatest="on"/>
        <ePixmap pixmap="skin_default/buttons/green.png" position="140,0" size="140,40" alphatest="on"/>
        <ePixmap pixmap="skin_default/buttons/yellow.png" position="280,0" size="140,40" alphatest="on"/>
        <ePixmap pixmap="skin_default/buttons/blue.png" position="420,0" size="140,40" alphatest="on"/>
        <ePixmap pixmap="skin_default/buttons/key_menu.png" position="5,370" size="35,25" alphatest="on"/>
        <widget name="key_red" position="0,0" zPosition="1" size="140,40" halign="center" valign="center" font="Regular;14" transparent="1" shadowColor="black" shadowOffset="-1,-1"/>
        <widget name="key_green" position="140,0" zPosition="1" size="140,40" halign="center" valign="center" font="Regular;14" transparent="1" shadowColor="black" shadowOffset="-1,-1"/>
        <widget name="key_yellow" position="280,0" zPosition="1" size="140,40" halign="center" valign="center" font="Regular;12" transparent="1" shadowColor="black" shadowOffset="-1,-1"/>
        <widget name="key_blue" position="420,0" zPosition="1" size="140,40" halign="center" valign="center" font="Regular;12" transparent="1" shadowColor="black" shadowOffset="-1,-1"/>
        <widget name="key_menu" position="45,372" zPosition="1" size="400,25" halign="left" valign="center" font="Regular;20" transparent="1" shadowColor="black" shadowOffset="-1,-1"/>
        <widget source="menu" render="Listbox" position="5,50" size="550,200" zPosition="3" scrollbarMode="showNever">
                <convert type="TemplatedMultiContent">
                    {"template": [
                            MultiContentEntryText(pos = (10,  5), size = (550, 26), flags = RT_HALIGN_LEFT, text = 1), # index 0 is the MenuText,
                        ],
                    "fonts": [gFont("Regular", 20)],
                    "itemHeight": 30
                    }
            </convert>
        </widget>
        <widget source="menu" render="Listbox"     position="5,270" size="550,100" zPosition="3" scrollbarMode="showNever" selectionDisabled="1" transparent="1">
            <convert type="TemplatedMultiContent">
                {"template": [
                        MultiContentEntryText(pos = (0, 0), size = (550,100), flags = RT_HALIGN_CENTER|RT_VALIGN_TOP|RT_WRAP, text = 2), # index 0 is the MenuText,
                    ],
                "fonts": [gFont("Regular", 18)],
                "itemHeight": 100
                }
            </convert>
        </widget>
        </screen>"""
        
    def __init__(self, session, args = 0):
        self.skin = DVBTimePlugin.skin
        self.session = session
        Screen.__init__(self, session)
        NetworkConnectionAvailable = None
        self.menu = args
        self.list = []
        self.list.append(("DVBTimecheck", (_("Check DVB Time")), _("This option check manually if there is a time difference between current system time and the transponder time.") ))
        self.list.append(("DVBTimeset", (_("Set DVB Time")), _("This option set the time from current transponder as system time.") ))
        self.list.append(("DVBTimesetforced", (_("Forced set DVB Time")), _("Setting DVB Time forced is only needed if check shows more then 30 min. time difference.\nATTENTION: With forced option make a Enigma 2 restart at the finish !") ))
        self.list.append(("changetime", _("Set system time manually"), _("This option set manually the system time by input with the remote control.") ))
        self.list.append(("checkntptime", _("Check and set with NTP-Server"), _("Comparing the system time with a central time server and set the new system time.") ))
        self.list.append(("aboutDVBTime", _("About"), _("About the DVB Time plugin.") ))
     
        self["menu"] = List(self.list)
        self["key_red"] = Label(showmessage)
        self["key_green"] = Label(ntpautostart)
        self["key_yellow"] = Label(tdtautostart)
        self["key_blue"] = Label(transponderupdate)
        self["key_menu"] = Label(menuentry)

        self["actions"] = ActionMap(["WizardActions", "DirectionActions", "ColorActions", "MenuActions", "EPGSelectActions", "InfobarActions"],
        {
            "ok": self.go,
            "exit": self.keyCancel,
            "back": self.keyCancel,
            "red": self.switchshowmessage,
            "green": self.autostartntpchecknetwork,
            "yellow": self.switchtdt,
            "blue": self.onoffautotrans,
            "menu": self.switchMainMenu
        }, -1)
        self.onShown.append(self.updateSettings)
        self.onLayoutFinish.append(self.layoutFinished)
        self.onShown.append(self.setWindowTitle)
        
    def updateSettings(self):
        showmessage_state = showmessage
        ntpautostart_state = ntpautostart
        tdtautostart_state = tdtautostart
        menuentry_state = menuentry
        transponderupdate_state = transponderupdate
        if config.plugins.DVBTime.showntpmessage.value:
            showmessage_state += _("On")
        else:
            showmessage_state += _("Off")

        if config.plugins.DVBTime.ntpautocheck.value:
            ntpautostart_state += _("On")
        else:
            ntpautostart_state += _("Off")
            
        if config.plugins.DVBTime.tdtautocheck.value:
            tdtautostart_state += _("On")
        else:
            tdtautostart_state += _("Off")
            
        if config.plugins.DVBTime.enablemainmenu.value:
            menuentry_state += _("On")
        else:
            menuentry_state += _("Off")
            
        if config.misc.useTransponderTime.value:
            transponderupdate_state += _("On")
        else:
            transponderupdate_state += _("Off")    
            
        self["key_red"].setText(showmessage_state)
        self["key_green"].setText(ntpautostart_state)
        self["key_yellow"].setText(tdtautostart_state)
        self["key_blue"].setText(transponderupdate_state)
        self["key_menu"].setText(menuentry_state)

    def layoutFinished(self):
        idx = 0
        self["menu"].index = idx

    def setWindowTitle(self):
        self.setTitle(_("DVB Time menu"))
        
    def go(self):
        current = self["menu"].getCurrent()
        if current:
            currentEntry = current[0]
            if self.menu == 0:
                if (currentEntry == "DVBTimecheck"):
                    self.session.open(Console,_("Checking DVB Time..."),["dvbdate --print"])
                elif (currentEntry == "DVBTimeset"):          
                    if config.misc.useTransponderTime.value == True:
                        self.session.open(MessageBox, _("Set DVB Time not useful,switch off Enigma 2 Timeupdate first !"), MessageBox.TYPE_INFO, timeout = 10)
                    else:
                        if config.plugins.DVBTime.ntpautocheck.value:
                            self.session.open(MessageBox, _("NTP-Server autostart is enabled,please switch off first !"), MessageBox.TYPE_INFO, timeout = 10)
                        else:
                            self.DoSetDVBTime(True)
                elif (currentEntry == "DVBTimesetforced"):          
                    if config.plugins.DVBTime.ntpautocheck.value:
                        self.session.open(MessageBox, _("NTP-Server autostart is enabled,please switch off first !"), MessageBox.TYPE_INFO, timeout = 10)
                    else:
                        if config.misc.useTransponderTime.value == True:
                            self.session.open(MessageBox, _("Forced set DVB Time not useful,switch off Enigma 2 Timeupdate first !"), MessageBox.TYPE_INFO, timeout = 10)
                        else:
                            self.DoSetDVBTimeforce(True)
                elif (currentEntry == "checkntptime"):
                    if config.misc.useTransponderTime.value == True:
                        self.session.open(MessageBox, _("Check and set with NTP-Server not useful,switch off Enigma 2 Timeupdate first !"), MessageBox.TYPE_INFO, timeout = 10)
                    else:
                        self.startnetworkcheck()               
                elif (currentEntry == "aboutDVBTime"):
                    self.session.open(DVBTimeAbout)
                elif (currentEntry == "changetime"):
                    if config.plugins.DVBTime.ntpautocheck.value:
                        self.session.open(MessageBox, _("NTP-Server autostart is enabled,please switch off first !"), MessageBox.TYPE_INFO, timeout = 10)
                    else:
                        if config.misc.useTransponderTime.value == True:
                            self.session.open(MessageBox, _("Set system time manually not useful,switch off Enigma 2 Timeupdate first !"), MessageBox.TYPE_INFO, timeout = 10)
                        else:
                            ChangeTimeWizzard(self.session)

    def autostartntpchecknetwork(self, callback = None):
        self.session.open(MessageBox, _("Check Network status.\nPlease wait..."), MessageBox.TYPE_INFO, timeout = 10)
        if callback is not None:
            self.NotifierCallback = callback
        data=iNetworkInfo.getState()
	print "[DVBTime] network status ", data
        self.checkNetworkCBautontp(data)

    def checkNetworkCBautontp(self,data):
	print "IP data", data
        if data is not None:
            if data == "online":
                DVBTimePlugin.NetworkConnectionAvailable = True
                self.session.openWithCallback(self.autostartntpcheck,MessageBox, _("Restart Enigma 2 for automatic NTP-Server check on startup (on/off) ?"), MessageBox.TYPE_YESNO)
            else:
                self.session.open(MessageBox, _("Change NTP-Server autostart not not possible:\n\nNetwork status: Unreachable !"), MessageBox.TYPE_ERROR)

    def autostartntpcheck(self,answer):
        if answer is False:
             self.skipDVBTimeautostart(_("Reason: Abort by User !"))
        if answer is True:
            if config.plugins.DVBTime.ntpautocheck.value:
                config.plugins.DVBTime.showntpmessage.setValue(False)
                config.plugins.DVBTime.showntpmessage.save()
                config.plugins.DVBTime.ntpautocheck.setValue(False)
                config.plugins.DVBTime.ntpautocheck.save()
                config.misc.useTransponderTime.setValue(True)
                config.misc.useTransponderTime.save()
            else:
                if not config.plugins.DVBTime.ntpautocheck.value:
                    config.plugins.DVBTime.ntpautocheck.setValue(True)
                    config.plugins.DVBTime.ntpautocheck.save()
                    config.plugins.DVBTime.showntpmessage.setValue(True)
                    config.plugins.DVBTime.showntpmessage.save()
                    config.plugins.DVBTime.tdtautocheck.setValue(False)
                    config.plugins.DVBTime.tdtautocheck.save()
                    config.misc.useTransponderTime.setValue(False)
                    config.misc.useTransponderTime.save()
            self.updateSettings()
            self.callRestart(True)

    def onoffautotrans(self):
        self.session.openWithCallback(self.autotransponder,MessageBox,_("Restart Enigma 2 to switch on/off Enigma 2 Timeupdate on startup ?\nATTENTION: When you switch off,all automatic time updates are disabled !!!"), MessageBox.TYPE_YESNO )       

    def autotransponder(self,answer):
        if answer is False:
             self.skipDVBTimeautostart(_("Reason: Abort by User !"))
        if answer is True:
            if config.misc.useTransponderTime.value:
                config.misc.useTransponderTime.setValue(False)
                config.misc.useTransponderTime.save()
            else:
                if not config.misc.useTransponderTime.value:
                    config.misc.useTransponderTime.setValue(True)
                    config.misc.useTransponderTime.save()
                    config.plugins.DVBTime.tdtautocheck.setValue(False)
                    config.plugins.DVBTime.tdtautocheck.save()
                    config.plugins.DVBTime.ntpautocheck.setValue(False)
                    config.plugins.DVBTime.ntpautocheck.save()
                    config.plugins.DVBTime.showntpmessage.setValue(False)                
                    config.plugins.DVBTime.showntpmessage.save() 
            self.updateSettings()
            self.callRestartTransponder(True)
            
    def switchtdt(self):
        self.session.openWithCallback(self.autostarttdtcheck,MessageBox,_("Restart Enigma 2 to display DVB Time check results on startup (on/off) ?"), MessageBox.TYPE_YESNO )       

    def autostarttdtcheck(self,answer):
        if answer is False:
             self.skipDVBTimeautostart(_("Reason: Abort by User !"))
        if answer is True:
            if config.plugins.DVBTime.tdtautocheck.value:
                config.plugins.DVBTime.tdtautocheck.setValue(False)
                config.plugins.DVBTime.tdtautocheck.save()
                config.misc.useTransponderTime.setValue(True)
                config.misc.useTransponderTime.save()
            else:
                if not config.plugins.DVBTime.tdtautocheck.value:
                    config.plugins.DVBTime.tdtautocheck.setValue(True)
                    config.plugins.DVBTime.tdtautocheck.save()
                    config.plugins.DVBTime.ntpautocheck.setValue(False)
                    config.plugins.DVBTime.ntpautocheck.save()
                    config.plugins.DVBTime.showntpmessage.setValue(False)
                    config.plugins.DVBTime.showntpmessage.save()
                    config.misc.useTransponderTime.setValue(False)
                    config.misc.useTransponderTime.save()
            self.updateSettings()
            self.callRestart(True)

    def switchMainMenu(self):
        self.session.openWithCallback(self.setMainMenu,MessageBox,_("Restarting Enigma 2 to switch on/off display\nthe DVB Time in the Mainmenu ?"), MessageBox.TYPE_YESNO )

    def setMainMenu(self,answer):
        if answer is False:
             self.skipDVBTimeautostart(_("Reason: Abort by User !"))
        if answer is True:
            if config.plugins.DVBTime.enablemainmenu.value:
                config.plugins.DVBTime.enablemainmenu.setValue(False)
                config.plugins.DVBTime.enablemainmenu.save()
            else:
                if not config.plugins.DVBTime.enablemainmenu.value:
                    config.plugins.DVBTime.enablemainmenu.setValue(True)
                    config.plugins.DVBTime.enablemainmenu.save()
            self.updateSettings()
            self.callRestart(True)

    def switchshowmessage(self):
        if config.plugins.DVBTime.ntpautocheck.value == False:
            self.session.open(MessageBox, _("That makes no sense when turned off the auto start from the NTP-Server.\nPlease switch on the autostart first !"), MessageBox.TYPE_INFO, timeout = 10)
        else:
            self.session.openWithCallback(self.onoffshowmessage,MessageBox,_("Restarting Enigma 2 to switch on/off\nthe NTP message on startup ?"), MessageBox.TYPE_YESNO )
            
    def onoffshowmessage(self,answer):
        if answer is False:
             self.skipDVBTimeautostart(_("Reason: Abort by User !"))
        if answer is True:
            if config.plugins.DVBTime.showntpmessage.value:
                config.plugins.DVBTime.showntpmessage.setValue(False)
                config.plugins.DVBTime.showntpmessage.save()
            else:
                if not config.plugins.DVBTime.showntpmessage.value:
                    config.plugins.DVBTime.showntpmessage.setValue(True)
                    config.plugins.DVBTime.showntpmessage.save()
            self.updateSettings()
            self.callRestart(True)
        
    def callRestart(self, answer):
        if answer is None:
            self.skipDVBTimeautostart(_("Reason: Answer is none"))
        if answer is False:
            self.skipDVBTimeautostart(_("Reason: Abort by User !"))
        if answer is True:
            self.session.open(TryQuitMainloop, 3)
        else:
            pass
                    
    def callRestartTransponder(self, answer):
        if answer is None:
            self.skipDVBTimeautostart(_("Reason: Answer is none"))
        if answer is False:
            self.skipDVBTimeautostart(_("Reason: Abort by User !"))
        if answer is True:
            self.session.open(TryQuitMainloop, 3)
        else:
            pass

    def skipDVBTimeautostart(self,reason):
        self.session.open(MessageBox,(_("DVB Time setting aborted:\n\n%s") % (reason)), MessageBox.TYPE_ERROR)

    def startnetworkcheck(self, callback = None):
        if callback is not None:
            self.NotifierCallback = callback
        data=iNetworkInfo.getState()
	print "[DVBTime] network status ", data
        self.checkNetworkCB(data)
        
    def checkNetworkCB(self,data):
        if data is not None:
            if data == "online":
                DVBTimePlugin.NetworkConnectionAvailable = True
                self.container=eConsoleAppContainer()
		self.container_appClosed_conn = self.container.appClosed.connect(self.finishedntp)
                self.container.execute("ntpdate tick.fh-augsburg.de time2.one4vision.de")
            else:
                self.session.open(MessageBox, _("NTP check not not possible:\n\nNetwork status: Unreachable !"), MessageBox.TYPE_ERROR)

    def finishedntp(self,retval):
        timenow = strftime("%Y:%m:%d %H:%M",localtime())
        self.session.open(MessageBox, _("NTP-Server check and system time update\nto %s successfully done.") % timenow, MessageBox.TYPE_INFO, timeout = 10)

    def DoSetDVBTime(self,answer):
        self.container=eConsoleAppContainer()
        self.container.execute("dvbdate --set")
        self.session.openWithCallback(self.finished, MessageBox, _("DVB Time update running.\nPlease wait..."), MessageBox.TYPE_INFO, timeout=10)
            
    def finished(self, answer):
        if answer is None:
            self.skipDVBTime(_("Reason: Answer is none"))
        if answer is False:
            self.skipDVBTime(_("Reason: Abort by User !"))
        if answer is True:
            timenow = strftime("%Y:%m:%d %H:%M",localtime())
            self.session.open(MessageBox,_("DVB Time updating to %s\nsuccessfully done.") % timenow, MessageBox.TYPE_INFO, timeout=10)
                        
    def DoSetDVBTimeforce(self,answer):
        if answer is None:
            self.skipDVBTime(_("Reason: Answer is none"))
        if answer is False:
            self.skipDVBTime(_("Reason: Abort by User !"))
        if answer is True:    
            self.session.openWithCallback(self.forcefinished, MessageBox,_("Setting DVB Time with forced option.\nWhen finished Enigma 2 restarts automatically !\nPlease wait..."), MessageBox.TYPE_INFO, timeout=30)
            self.container=eConsoleAppContainer()
            self.container.execute("dvbdate --set --force")

    def forcefinished(self,answer):
        if answer is None:
            self.skipDVBTime(_("Reason: Answer is none"))
        if answer is False:
            self.skipDVBTime(_("Reason: Abort by User !"))
        if answer is True:
            self.session.open(TryQuitMainloop, 3)
            
    def skipDVBTime(self,reason):
        self.session.open(MessageBox,(_("DVB Time setting aborted:\n\n%s") % (reason)), MessageBox.TYPE_ERROR)
        
    def keyCancel(self):
        self.close(None)
                            
class NTPStartup(Screen):
    skin = """
        <screen position="center,center" size="400,300" title=" " >
        </screen>"""

    def __init__(self, session):
        self.skin = NTPStartup.skin
        self.session = session        
        Screen.__init__(self, session)
        NetworkConnectionAvailable = None

        self.TimerDVBTimeStartup = eTimer()
        self.TimerDVBTimeStartup.stop()
 	self.TimerDVBTimeStartup_conn = self.TimerDVBTimeStartup.timeout.connect(self.startnetworkcheckntp)
        self.TimerDVBTimeStartup.start(3000,True)

    def startnetworkcheckntp(self, callback = None):
        if callback is not None:
            self.NotifierCallback = callback
        data=iNetworkInfo.getState()
	print "[DVBTime] network status ", data
        self.checkNetworkCBntp(data)
        
    def checkNetworkCBntp(self,data):
        if data is not None:
            if data == "online":
                DVBTimePlugin.NetworkConnectionAvailable = True
                self.TimerDVBTimeStartup.stop()
                self.container=eConsoleAppContainer()
		self.container_appClosed_conn = self.container.appClosed.connect(self.finishedntpauto)
                self.container.execute("ntpdate tick.fh-augsburg.de time2.one4vision.de")
            else:
                self.session.open(MessageBox, _("NTP check not possible:\n\nNetwork status: Unreachable !"), MessageBox.TYPE_ERROR)

    def finishedntpauto(self,retval):
        if config.plugins.DVBTime.showntpmessage.value:
            timenow = strftime("%Y:%m:%d %H:%M",localtime())
            self.session.open(MessageBox,_("NTP Time check successfully.\nSystem time set to %s finished.") % timenow, MessageBox.TYPE_INFO, timeout=10)
        else:
            pass

class DVBTimeStartup(Screen):
    skin = """
        <screen position="center,center" size="400,300" title=" " >
        </screen>"""

    def __init__(self,session):
        self.skin = DVBTimeStartup.skin
        self.session = session        
        Screen.__init__(self,session)

        self.TimerDVBTimeStartup = eTimer()
        self.TimerDVBTimeStartup.stop()
 	self.TimerDVBTimeStartup_conn = self.TimerDVBTimeStartup.timeout.connect(self.CheckDVBTimeStartup)
        self.TimerDVBTimeStartup.start(3000,True) 

    def CheckDVBTimeStartup(self):
        global dvbdateresult
        dvbdateresult=""
        self.TimerDVBTimeStartup.stop()
        self.container=eConsoleAppContainer()
	self.container_appClosed_conn = self.container.appClosed.connect(self.finished)
	self.container_dataAvail_conn = self.container.dataAvail.connect(self.dataAvail)
        self.container.execute("dvbdate --print")

    def finished(self,retval):
        global dvbdateresult
        self.session.open(MessageBox,_("DVB Time check results:\n%s") % dvbdateresult, MessageBox.TYPE_INFO, timeout=10)

    def dataAvail(self, str):
        global dvbdateresult
        dvbdateresult =str

class ChangeTimeWizzard(Screen):
    def __init__(self, session):

        self.session = session
        self.oldtime = strftime("%Y:%m:%d %H:%M",localtime())
        self.session.openWithCallback(self.askForNewTime,InputBox, windowTitle = (_("Please Enter new Systemtime:")), title=(_("OK will set new time and restart Enigma 2 !")), text="%s" % (self.oldtime), maxSize=16, type=Input.NUMBER)

    def askForNewTime(self,newclock):
        try:
           length=len(newclock)
        except:
           length=0
        if newclock is None:
            self.skipChangeTime(_("No new time input !"))
        elif (length == 16) is False:
           self.skipChangeTime(_("New time string too short !"))
        elif (newclock.count(" ") < 1) is True:
            self.skipChangeTime(_("Invalid format !"))
        elif (newclock.count(":") < 3) is True:
            self.skipChangeTime(_("Invalid format !"))
        else:
            full=[]
            full=newclock.split(" ",1)
            newdate=full[0]
            newtime=full[1]
            parts=[]
            parts=newdate.split(":",2)
            newyear=parts[0]
            newmonth=parts[1]
            newday=parts[2]
            parts=newtime.split(":",1)
            newhour=parts[0]
            newmin=parts[1]
            maxmonth = 31
            if (int(newmonth) == 4) or (int(newmonth) == 6) or (int(newmonth) == 9) or (int(newmonth) == 11) is True:
               maxmonth=30
            elif (int(newmonth) == 2) is True:
               if ((4*int(int(newyear)/4)) == int(newyear)) is True:
                  maxmonth=28
               else:
                  maxmonth=27
            if (int(newyear) < 2010) or (int(newyear) > 2050)  or (len(newyear) < 4) is True:
               self.skipChangeTime(_("Invalid year %s !") %newyear)
            elif (int(newmonth) < 0) or (int(newmonth) >12) or (len(newmonth) < 2) is True:
               self.skipChangeTime(_("Invalid month %s !") %newmonth)
            elif (int(newday) < 1) or (int(newday) > maxmonth) or (len(newday) < 2) is True:              
                self.skipChangeTime(_("Invalid day %s !") %newday)
            elif (int(newhour) < 0) or (int(newhour) > 23) or (len(newhour) < 2) is True:
               self.skipChangeTime(_("Invalid hour %s !") %newhour)
            elif (int(newmin) < 0) or (int(newmin) > 59) or (len(newmin) < 2) is True:
               self.skipChangeTime(_("Invalid minute %s !") %newmin)
            else:
               self.newtime = "%s%s%s%s%s" %(newyear,newmonth,newday,newhour,newmin)
               self.session.openWithCallback(self.DoChangeTimeRestart, MessageBox, _("Enigma 2 must be restarted to set the new Systemtime ?"), MessageBox.TYPE_YESNO)

    def DoChangeTimeRestart(self,answer):
        if answer is None:
            self.skipChangeTime(_("Answer is none"))
        if answer is False:
            self.skipChangeTime(_("Enigma 2 restart abort by user !"))
        else:
            os.system("date %s" % (self.newtime))
            quitMainloop(3)

    def skipChangeTime(self,reason):
        self.session.open(MessageBox,(_("Change Systemtime was canceled:\n\n%s") % (reason)), MessageBox.TYPE_ERROR)

def main(session,**kwargs):
    session.open(DVBTimePlugin)

def autostart(reason, **kwargs):
    global session
    if config.plugins.DVBTime.tdtautocheck.value:
        if reason == 0 and kwargs.has_key("session"):
            session = kwargs["session"]
            session.open(DVBTimeStartup)
    if config.plugins.DVBTime.ntpautocheck.value:
        if reason == 0 and kwargs.has_key("session"):
            session = kwargs["session"]
            session.open(NTPStartup)

def Setup(menuid, **kwargs):
    if menuid == "system":
        return [(_("DVB Time settings"), main, "DVBTimePlugin", None)]
    else:
        return []

def menu(menuid, **kwargs):
        if menuid == "mainmenu":
                return [(_("DVB Time"), main, "DVBTime", 44)]
        return []
       
def Plugins(**kwargs):
    if config.plugins.DVBTime.enablemainmenu.value:
        return [PluginDescriptor(where = [PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART], fnc = autostart),
                PluginDescriptor(name=_("DVB Time settings"), description=_("DVB Time checking and changing"), where = PluginDescriptor.WHERE_MENU, fnc=Setup),
                PluginDescriptor(name=_("DVB Time settings"), description =_("DVB Time checking and changing"), where = PluginDescriptor.WHERE_EXTENSIONSMENU, icon="g3icon_dvbtime.png", fnc=main),
                PluginDescriptor(name=_("DVB Time settings"), where = PluginDescriptor.WHERE_MENU, fnc=menu)]
    else:
        return [PluginDescriptor(where = [PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART], fnc = autostart),
                PluginDescriptor(name=_("DVB Time settings"), description =_("DVB Time checking and changing"), where = PluginDescriptor.WHERE_EXTENSIONSMENU, icon="g3icon_dvbtime.png", fnc=main),
                PluginDescriptor(name=_("DVB Time settings"), description=_("DVB Time checking and changing"), where = PluginDescriptor.WHERE_MENU, fnc=Setup)]       